"""Recovery policy hooks: a final placement check, failed-lift candidate choice, and release retry.

Everything is decided from the public receipt or event passed in. There is no hidden state,
there are no counters across calls, and nothing is specific to a scene.
"""

# Final placement check (finish)
MISS_THRESHOLD = 0.03      # m: horizontal gap that counts as a substantial miss
REGRASP_BUDGET = 120       # control steps needed for one full correction (out of 460;
                           # the 40-step final verification is budgeted separately)

# Failed-lift candidate choice (choose)
MIN_DISTINCT = 0.005       # m: minimum shift for a next contact to count as a new point


def _num(x):
    """Return x as a float if it is a normal finite number, else None."""
    if isinstance(x, bool) or not isinstance(x, (int, float)):
        return None
    x = float(x)
    if x != x or x in (float("inf"), float("-inf")):
        return None
    return x


def _get(d, key):
    return d.get(key) if isinstance(d, dict) else None


def finish(receipt):
    """Last chance after the inherited placement program.

    Return 'regrasp' only for a substantial miss with ample budget left, otherwise None.
    """
    if not isinstance(receipt, dict):
        return None
    gap = _num(receipt.get("xy_gap"))
    lift = _num(receipt.get("max_lift"))
    remaining = _num(receipt.get("remaining"))
    retries = _num(receipt.get("retries_left"))
    if gap is None or lift is None or remaining is None or retries is None:
        return None
    if retries < 1:
        return None
    if remaining < REGRASP_BUDGET:
        return None
    if abs(gap) < MISS_THRESHOLD:
        return None
    return "regrasp"


def _is_failed_grasp(event):
    """The hook is called on failed lifts. Treat an explicit success signal as not failed."""
    if event.get("success") is True or event.get("lifted") is True:
        return False
    if event.get("failed") is False:
        return False
    return True


def choose(event):
    """Decide what to do after a failed lift.

    'switch'   -> poor next candidate and a precise landing is needed: use the geometry
                  regrasp right away.
    'continue' -> the receiver can absorb the error and a distinct next point exists:
                  keep the native grip search.
    'inherit'  -> evidence is missing or ambiguous, or this is not a failed grasp.
    """
    if not isinstance(event, dict) or not _is_failed_grasp(event):
        return "inherit"
    if event.get("available") is not True:
        return "inherit"

    edge = event.get("edge_access")
    margin = _num(event.get("landing_margin"))
    unc = _num(event.get("uncertainty"))
    if not isinstance(edge, bool) or margin is None or unc is None:
        return "inherit"

    precise_needed = margin <= unc

    if precise_needed and not edge:
        retries = _num(event.get("retries_left"))
        if retries is not None and retries >= 1:
            return "switch"
        return "inherit"

    if not precise_needed:
        displaced = _num(event.get("displaced"))
        if displaced is None:
            return "inherit"
        reach = _num(event.get("reach_error"))
        floor = MIN_DISTINCT
        if reach is not None and abs(reach) > floor:
            floor = abs(reach)  # a shift within tracking error is effectively the same point
        if abs(displaced) > floor:
            return "continue"

    return "inherit"


def _observed_loss(loss):
    if loss is True:
        return True
    v = _num(loss)
    return v is not None and v > 0


def release(event):
    """Return 'retry_release' on observed loss after opening if the ledger allows it, else None."""
    if not isinstance(event, dict):
        return None
    if not _observed_loss(event.get("loss")):
        return None
    retries = _num(event.get("retries_left"))
    remaining = _num(event.get("remaining"))
    cost = _num(event.get("retry_cost"))
    if retries is None or remaining is None or cost is None or cost < 0:
        return None
    if retries >= 1 and remaining >= cost:
        return "retry_release"
    return None


def run(api):
    return finish(api.last())
