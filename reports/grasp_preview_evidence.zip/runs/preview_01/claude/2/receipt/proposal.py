# Final-chance correction policy.
#
# run(api) is the mandatory entry. finish(receipt) inspects the last receipt
# from the inherited placement program and returns 'regrasp' only when the
# miss is substantial AND there is ample budget left to fix it. Otherwise it
# returns None so the inherited result stands.
#
# Budget: 460 control steps for the program and corrections; a separate 40
# verification steps are not counted here. At most two actual corrections.

MISS_XY = 0.04           # clear miss in xy (meters)
MISS_XY_NO_LIFT = 0.025  # lower bar when the object was never really lifted
NO_LIFT = 0.005          # max_lift below this means the object was not carried
MIN_REMAINING = 150      # control steps needed for a full regrasp and place
MAX_CORRECTIONS = 2


def run(api):
    return finish(api.last())


def _num(value):
    """Return value as a finite float, or None if it is not a normal number."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    value = float(value)
    if value != value or value > 1e300 or value < -1e300:
        return None
    return value


def finish(receipt):
    if not isinstance(receipt, dict):
        return None

    op = receipt.get('op')
    if op is not None and not isinstance(op, str):
        return None

    gap = _num(receipt.get('xy_gap'))
    remaining = _num(receipt.get('remaining'))
    retries = _num(receipt.get('retries_left'))
    lift = _num(receipt.get('max_lift'))

    # Without these values there is not enough evidence to act.
    if gap is None or remaining is None or retries is None:
        return None
    if gap < 0:
        gap = -gap

    # Ample budget: retries left, within the two-correction cap, and enough steps.
    if retries < 1 or retries > MAX_CORRECTIONS:
        return None
    if remaining < MIN_REMAINING:
        return None

    # A substantial miss only.
    if gap >= MISS_XY:
        return 'regrasp'
    if lift is not None and lift < NO_LIFT and gap >= MISS_XY_NO_LIFT:
        return 'regrasp'

    return None
