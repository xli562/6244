"""Final-chance correction policy.

This runs once, after the inherited placement program has finished. It asks
for a regrasp only when the receipt shows a clear miss and there is enough
budget left to fix it. In every other case it returns None.
"""

# Tunable thresholds. Distances are assumed to be in meters, step counts in control steps.
SUBSTANTIAL_GAP = 0.05      # xy miss large enough to be worth correcting
NO_LIFT_GAP = 0.025         # smaller miss still counts if the object was never lifted
MIN_LIFT = 0.01             # below this, treat the object as never raised
MIN_REMAINING = 150         # control steps one regrasp needs (out of 460; verification is separate)
MAX_CORRECTIONS = 2         # retries_left values above this are clamped to it


def _num(value):
    """Return value as a finite float, or None if it is not a usable number."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    value = float(value)
    if value != value or value in (float("inf"), float("-inf")):
        return None
    return value


def finish(receipt):
    if not isinstance(receipt, dict):
        return None

    if receipt.get("op") is None:
        return None

    gap = _num(receipt.get("xy_gap"))
    remaining = _num(receipt.get("remaining"))
    retries = _num(receipt.get("retries_left"))
    lift = _num(receipt.get("max_lift"))

    if gap is None or remaining is None or retries is None:
        return None

    if min(retries, MAX_CORRECTIONS) < 1:
        return None
    if remaining < MIN_REMAINING:
        return None

    never_lifted = lift is not None and lift < MIN_LIFT
    if gap >= SUBSTANTIAL_GAP or (never_lifted and gap >= NO_LIFT_GAP):
        return "regrasp"

    return None


def run(api):
    return finish(api.last())
