"""Recovery policy: final placement check, failed-lift candidate choice, release retry.

Entry point: run(api). Uses only public observation fields, no imports.
"""

# ---------------------------------------------------------------------------
# Tunable thresholds (metres / control steps)
# ---------------------------------------------------------------------------
SUBSTANTIAL_GAP_M = 0.025   # final xy miss that is worth one more correction
MIN_REGRASP_STEPS = 120     # ample control budget for a full regrasp + place
                            # (the 40-step final verification is budgeted separately)
MIN_DISTINCT_M = 0.005      # next contact must move at least this far to be "distinct"

_INF = float("inf")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _num(value):
    """Return value as a finite float, or None if it isn't a normal number."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    value = float(value)
    if value != value or value in (_INF, -_INF):
        return None
    return value


def _flag(value):
    """Return True/False for real booleans, None otherwise."""
    return value if isinstance(value, bool) else None


def _sensor_view(event):
    """Sensor fields may arrive flat or nested under 'sensor'."""
    nested = event.get("sensor")
    return nested if isinstance(nested, dict) else event


def _is_failed_grasp(event):
    """True only when the event positively reports a failed lift/grasp."""
    for key in ("failed", "lift_failed", "grasp_failed"):
        flag = _flag(event.get(key))
        if flag is not None:
            return flag
    for key in ("success", "lifted", "lift_ok"):
        flag = _flag(event.get(key))
        if flag is not None:
            return not flag
    outcome = event.get("outcome", event.get("status"))
    if isinstance(outcome, str):
        return outcome.strip().lower() in ("fail", "failed", "failure", "dropped", "slip")
    return False


# ---------------------------------------------------------------------------
# Final opportunity after the inherited placement program
# ---------------------------------------------------------------------------
def finish(receipt):
    if not isinstance(receipt, dict):
        return None

    gap = _num(receipt.get("xy_gap"))
    remaining = _num(receipt.get("remaining"))
    retries = _num(receipt.get("retries_left"))
    if gap is None or remaining is None or retries is None:
        return None

    if retries < 1:
        return None
    if gap < SUBSTANTIAL_GAP_M:
        return None
    if remaining < MIN_REGRASP_STEPS:
        return None
    return "regrasp"


# ---------------------------------------------------------------------------
# Failed-lift decision: switch to geometry regrasp, continue native search,
# or inherit the previous decision.
# ---------------------------------------------------------------------------
def choose(event):
    if not isinstance(event, dict) or not _is_failed_grasp(event):
        return "inherit"

    s = _sensor_view(event)
    if _flag(s.get("available")) is not True:
        return "inherit"

    edge_access = _flag(s.get("edge_access"))
    margin = _num(s.get("landing_margin"))
    uncertainty = _num(s.get("uncertainty"))
    if edge_access is None or margin is None or uncertainty is None:
        return "inherit"

    retries = _num(s.get("retries_left", event.get("retries_left")))

    # Poor next candidate + precise landing required -> geometry regrasp now.
    if not edge_access and margin <= uncertainty:
        if retries is not None and retries >= 1:
            return "switch"
        return "inherit"

    # Receiver tolerates the weak-grasp error -> keep native search if the
    # next point is genuinely different from the one that just failed.
    if margin > uncertainty:
        displaced = _num(s.get("displaced"))
        if displaced is None:
            return "inherit"
        reach_error = _num(s.get("reach_error"))
        threshold = MIN_DISTINCT_M
        if reach_error is not None and reach_error > threshold:
            threshold = reach_error
        if displaced > threshold:
            return "continue"

    return "inherit"


# ---------------------------------------------------------------------------
# Release: retry only on observed loss after opening, within the public ledger.
# ---------------------------------------------------------------------------
def release(event):
    if not isinstance(event, dict):
        return None
    if _flag(event.get("loss")) is not True:
        return None

    retries = _num(event.get("retries_left"))
    remaining = _num(event.get("remaining"))
    cost = _num(event.get("retry_cost"))
    if retries is None or remaining is None or cost is None:
        return None

    if retries > 0 and remaining >= cost:
        return "retry_release"
    return None


# ---------------------------------------------------------------------------
# Mandatory entry
# ---------------------------------------------------------------------------
def run(api):
    return finish(api.last())
