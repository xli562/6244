"""Final, conservative correction hook for an inherited placement program.

Only requests a regrasp when the last receipt shows a substantial placement
miss and there is clearly enough control budget and retry allowance left to
attempt one more full pick-and-place pass. Otherwise it leaves the result alone.
"""

# Control budget: 460 control steps. The 40 final-verification steps are a
# separate allowance, so they are not subtracted from `remaining`.
CONTROL_STEPS = 460
MAX_CORRECTIONS = 2

# A full regrasp (approach, grasp, lift, transport, place, settle) needs a
# generous slice of the control budget; require roughly a third of it.
MIN_STEPS_FOR_REGRASP = 150

# Placement error thresholds (same units as xy_gap, nominally metres).
SUBSTANTIAL_GAP = 0.05      # clear miss on its own
MODERATE_GAP = 0.025        # counts as a miss only if the object never lifted
MIN_LIFT = 0.01             # below this, the object was effectively not carried


def _num(value):
    """Return a finite float, or None for missing/invalid/non-numeric input."""
    if value is None or isinstance(value, bool):
        return None
    if not isinstance(value, (int, float)):
        return None
    x = float(value)
    if x != x:                       # NaN
        return None
    if x > 1e300 or x < -1e300:      # +/- inf or absurd
        return None
    return x


def finish(receipt):
    """Return 'regrasp' for a substantial miss with ample budget, else None."""
    if not isinstance(receipt, dict):
        return None

    op = receipt.get("op")
    if op is not None and not isinstance(op, str):
        return None

    gap = _num(receipt.get("xy_gap"))
    remaining = _num(receipt.get("remaining"))
    retries = _num(receipt.get("retries_left"))
    lift = _num(receipt.get("max_lift"))

    # Without a measured gap, budget, and retry count we cannot justify acting.
    if gap is None or remaining is None or retries is None:
        return None
    if gap < 0 or remaining < 0:
        return None

    # Budget checks: at most two real corrections, and enough steps for one.
    if min(retries, MAX_CORRECTIONS) < 1:
        return None
    if min(remaining, CONTROL_STEPS) < MIN_STEPS_FOR_REGRASP:
        return None

    # Miss checks: a clearly large gap, or a moderate gap where the object
    # evidently was never carried (grasp failed rather than a small offset).
    substantial = gap >= SUBSTANTIAL_GAP
    never_lifted = lift is not None and lift < MIN_LIFT and gap >= MODERATE_GAP
    if substantial or never_lifted:
        return "regrasp"

    return None


def run(api):
    return finish(api.last())
