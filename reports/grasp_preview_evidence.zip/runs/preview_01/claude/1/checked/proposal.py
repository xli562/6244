# Final-correction, candidate-switch, and release-retry policy.
# Pure functions over public observations: no imports, no module state,
# no scene/task identifiers, no extra model calls.

# ---- budget / thresholds (metres, control steps) --------------------------
CONTROL_BUDGET = 460        # total control steps for the episode
VERIFY_RESERVE = 40         # separate final-verification window (never spent)
MAX_CORRECTIONS = 2         # actual corrections allowed
CORRECTION_STEPS = 120      # conservative cost of one regrasp+re-place pass
MISS_GAP = 0.025            # xy_gap at or above this is a substantial miss
DISTINCT_POINT = 0.005      # next candidate must move contact at least this much


def run(api):
    return finish(api.last())


# ---- helpers ---------------------------------------------------------------
def _num(x):
    """Return a finite float, or None for missing / bool / NaN / inf / non-numeric."""
    if isinstance(x, bool) or not isinstance(x, (int, float)):
        return None
    x = float(x)
    if x != x or x in (float("inf"), float("-inf")):
        return None
    return x


def _flag(x):
    """Return a real bool, or None if the evidence is not a bool."""
    return x if isinstance(x, bool) else None


def _fields(event):
    """Sensor fields may arrive flat or nested under 'sensor'."""
    if not isinstance(event, dict):
        return None
    inner = event.get("sensor")
    if isinstance(inner, dict):
        merged = dict(event)
        merged.update(inner)
        return merged
    return event


# ---- final placement correction -------------------------------------------
def finish(receipt):
    """One last chance after the inherited placement program.

    Returns 'regrasp' only for a substantial horizontal miss when a full
    correction still fits in the control budget without touching the
    verification window; otherwise None (keep the inherited result).
    """
    if not isinstance(receipt, dict):
        return None

    gap = _num(receipt.get("xy_gap"))
    remaining = _num(receipt.get("remaining"))
    retries = _num(receipt.get("retries_left"))
    if gap is None or remaining is None or retries is None:
        return None
    if gap < 0 or remaining < 0 or retries < 0:
        return None

    # max_lift is optional; if present it must be sane, otherwise the
    # receipt is untrustworthy and we leave the result alone.
    if "max_lift" in receipt and receipt.get("max_lift") is not None:
        lift = _num(receipt.get("max_lift"))
        if lift is None or lift < 0:
            return None

    if gap < MISS_GAP:
        return None                       # small miss: not worth the risk
    if retries < 1 or retries > MAX_CORRECTIONS:
        return None                       # no correction left (or bogus ledger)
    if remaining < CORRECTION_STEPS + VERIFY_RESERVE:
        return None                       # budget not ample
    return "regrasp"


# ---- failed-lift candidate choice -----------------------------------------
def _is_failed_grasp(ev):
    if _flag(ev.get("failed")) is True or _flag(ev.get("lift_failed")) is True:
        return True
    if _flag(ev.get("success")) is False or _flag(ev.get("lifted")) is False:
        return True
    outcome = ev.get("outcome")
    return isinstance(outcome, str) and outcome.lower() in ("fail", "failed", "failure")


def choose(event):
    """Decide after a failed lift whether to try the next local candidate.

    'switch'   -> next candidate is poor (no edge access) and the landing is
                  precise (landing_margin <= uncertainty): use geometry regrasp.
    'continue' -> receiver absorbs the weak-grasp error and a distinct next
                  point exists: keep the native grip search.
    'inherit'  -> missing evidence, not a failed grasp, or neither case holds.
    """
    ev = _fields(event)
    if ev is None or not _is_failed_grasp(ev):
        return "inherit"

    available = _flag(ev.get("available"))
    margin = _num(ev.get("landing_margin"))
    unc = _num(ev.get("uncertainty"))
    if available is not True or margin is None or unc is None:
        return "inherit"
    if margin < 0 or unc < 0:
        return "inherit"

    precise = margin <= unc
    edge = _flag(ev.get("edge_access"))

    if precise:
        retries = _num(ev.get("retries_left"))
        if edge is False and retries is not None and retries > 0:
            return "switch"
        return "inherit"

    displaced = _num(ev.get("displaced"))
    if displaced is not None and displaced >= DISTINCT_POINT:
        return "continue"
    return "inherit"


# ---- release retry ---------------------------------------------------------
def release(event):
    """Retry the release on observed loss after opening, if the ledger allows."""
    if not isinstance(event, dict):
        return None

    loss = event.get("loss")
    if isinstance(loss, bool):
        lost = loss
    elif _num(loss) is not None:
        lost = _num(loss) > 0
    else:
        # Fall back to support transition: supported before opening, not after.
        lost = (_flag(event.get("previous_support")) is True
                and _flag(event.get("support")) is False)
    if not lost:
        return None

    retries = _num(event.get("retries_left"))
    remaining = _num(event.get("remaining"))
    cost = _num(event.get("retry_cost"))
    if retries is None or remaining is None or cost is None or cost < 0:
        return None
    if retries > 0 and remaining >= cost:
        return "retry_release"
    return None
