def finish(receipt):
    if not isinstance(receipt, dict):
        return None

    gap = receipt.get("xy_gap")
    remaining = receipt.get("remaining")
    retries = receipt.get("retries_left")

    if receipt.get("op") != "place":
        return None
    if gap is None or remaining is None or retries is None:
        return None

    # Reserve 460 control steps and 40 final verification steps.
    # The controller's ledger owns the two actual corrections.
    if gap > 0.05 and remaining >= 460 + 40 and retries > 0:
        return "regrasp"
    return None


def choose(event):
    if not isinstance(event, dict):
        return "inherit"

    failed = (
        event.get("op") == "failed_lift"
        or event.get("failed_grasp") is True
    )
    if not failed or event.get("available") is not True:
        return "inherit"

    edge_access = event.get("edge_access")
    margin = event.get("landing_margin")
    uncertainty = event.get("uncertainty")
    displaced = event.get("displaced")
    retries = event.get("retries_left")

    if (
        edge_access is None
        or margin is None
        or uncertainty is None
        or displaced is None
        or retries is None
    ):
        return "inherit"

    if edge_access is False and margin <= uncertainty:
        return "switch" if retries > 0 else "inherit"

    if margin > uncertainty and displaced > 0:
        return "continue"

    return "inherit"


def release(event):
    if not isinstance(event, dict):
        return None

    retries = event.get("retries_left")
    remaining = event.get("remaining")
    retry_cost = event.get("retry_cost")

    if (
        event.get("loss") is True
        and retries is not None
        and remaining is not None
        and retry_cost is not None
        and retries > 0
        and remaining >= retry_cost
    ):
        return "retry_release"
    return None


def run(api):
    return finish(api.last())
