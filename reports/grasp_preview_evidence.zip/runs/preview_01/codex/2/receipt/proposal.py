def finish(receipt):
    if receipt is None:
        return None

    if (
        receipt.get("op") == "place"
        and receipt.get("xy_gap", 0) > 0.08
        and receipt.get("max_lift", 0) >= 0.04
        and receipt.get("remaining", 0) >= 460 / 2 + 40
        and receipt.get("retries_left", 0) > 0
    ):
        return "regrasp"

    return None


def run(api):
    return finish(api.last())
