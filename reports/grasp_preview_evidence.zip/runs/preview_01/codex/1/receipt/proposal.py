def finish(receipt):
    if receipt is None:
        return None
    if (
        receipt.get("op") == "place"
        and receipt.get("xy_gap", 0) > 0.05
        and receipt.get("remaining", 0) >= 460 + 40
        and 0 < receipt.get("retries_left", 0) <= 2
    ):
        return "regrasp"
    return None


def run(api):
    return finish(api.last())
