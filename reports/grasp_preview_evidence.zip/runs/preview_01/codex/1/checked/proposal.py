CONTROL_STEPS = 460
VERIFICATION_STEPS = 40
SUBSTANTIAL_MISS = 0.05
DISTINCT_POINT = 0.01


def finish(receipt):
    if not isinstance(receipt, dict):
        return None

    gap = receipt.get("xy_gap")
    remaining = receipt.get("remaining")
    retries = receipt.get("retries_left")

    if receipt.get("op") != "place":
        return None
    if gap is None or remaining is None or retries is None:
        return None

    # The controller owns the ledger and its two-correction limit.
    if (
        gap > SUBSTANTIAL_MISS
        and retries > 0
        and remaining >= CONTROL_STEPS + VERIFICATION_STEPS
    ):
        return "regrasp"
    return None


def choose(event):
    if not isinstance(event, dict):
        return "inherit"

    # This hook supplies failed-lift context; honor contrary context.
    if event.get("op", "lift") not in ("lift", "grasp"):
        return "inherit"
    if event.get("failed", True) is not True:
        return "inherit"
    if event.get("success", False) is not False:
        return "inherit"
    if event.get("available") is not True:
        return "inherit"

    reach_error = event.get("reach_error")
    width = event.get("width")
    aperture = event.get("aperture")
    edge_access = event.get("edge_access")
    displaced = event.get("displaced")
    margin = event.get("landing_margin")
    uncertainty = event.get("uncertainty")
    retries = event.get("retries_left")

    values = (
        reach_error, width, aperture, displaced,
        margin, uncertainty, retries,
    )
    if any(value is None for value in values):
        return "inherit"
    if edge_access is not True and edge_access is not False:
        return "inherit"
    if any(value < 0 for value in values) or retries <= 0:
        return "inherit"

    if edge_access is False and margin <= uncertainty:
        return "switch"

    if margin > uncertainty and displaced > max(DISTINCT_POINT, reach_error):
        return "continue"

    return "inherit"


def release(event):
    if not isinstance(event, dict):
        return None

    retries = event.get("retries_left")
    remaining = event.get("remaining")
    retry_cost = event.get("retry_cost")

    if retries is None or remaining is None or retry_cost is None:
        return None
    if (
        event.get("loss") is True
        and retries > 0
        and retry_cost >= 0
        and remaining >= retry_cost
    ):
        return "retry_release"
    return None


def run(api):
    return finish(api.last())
