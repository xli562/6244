def finish(receipt):
    if receipt is None:
        return None

    # Allow up to two corrections, each with half the control budget.
    # The separate 40-step final verification budget is untouched.
    if (
        receipt.get("op") == "place"
        and receipt.get("xy_gap", 0) > 0.10
        and receipt.get("max_lift", 0) >= 0.05
        and receipt.get("remaining", 0) >= 230
        and receipt.get("retries_left", 0) in (1, 2)
    ):
        return "regrasp"
    return None


def run(api):
    return finish(api.last())
