def run(api):
    return finish(api.last())


def finish(receipt):
    if receipt is None or receipt.get("op") != "place":
        return None

    gap = receipt.get("xy_gap")
    lift = receipt.get("max_lift")
    remaining = receipt.get("remaining")
    retries = receipt.get("retries_left")
    if gap is None or lift is None or remaining is None or retries is None:
        return None

    # Two correction allowances within 460 steps, plus 40 for verification.
    if gap > 0.05 and lift < 0.02 and remaining >= 270 and retries > 0:
        return "regrasp"
    return None


def choose(event):
    if event is None or event.get("op") != "grasp":
        return "inherit"

    failed = event.get("failed")
    success = event.get("success")
    if failed is not True and success is not False:
        return "inherit"
    if failed is False or success is True:
        return "inherit"
    if event.get("available") is not True:
        return "inherit"

    reach_error = event.get("reach_error")
    width = event.get("width")
    aperture = event.get("aperture")
    edge_access = event.get("edge_access")
    displaced = event.get("displaced")
    margin = event.get("landing_margin")
    uncertainty = event.get("uncertainty")
    retries = event.get("retries_left")

    if (
        reach_error is None
        or width is None
        or aperture is None
        or edge_access is None
        or displaced is None
        or margin is None
        or uncertainty is None
        or retries is None
    ):
        return "inherit"

    if (
        reach_error < 0
        or width < 0
        or aperture < 0
        or displaced < 0
        or margin < 0
        or uncertainty < 0
        or retries <= 0
    ):
        return "inherit"

    if edge_access is False and margin <= uncertainty:
        return "switch"

    if margin > uncertainty and displaced > 0:
        return "continue"

    return "inherit"


def release(event):
    if event is None:
        return None

    loss = event.get("loss")
    retries = event.get("retries_left")
    remaining = event.get("remaining")
    retry_cost = event.get("retry_cost")

    if (
        loss is True
        and retries is not None
        and remaining is not None
        and retry_cost is not None
        and retries > 0
        and retry_cost >= 0
        and remaining >= retry_cost
    ):
        return "retry_release"
    return None
