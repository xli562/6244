# Results of experiment 'main'

## test_id_100

| agent | condition | runs | per run | pooled | 95% Wilson (pooled) | run mean, SD | failures |
| --- | --- | --- | --- | --- | --- | --- | --- |
| reference | reference_oracle | 1 | 96 | 96/100 = 96.0% | 90.2-98.4% | - | cup_not_lifted 2, cup_not_placed_in_drawer (cup ended on: floor) 2 |
| reference | reference_twin_overfit | 1 | 15 | 15/100 = 15.0% | 9.3-23.3% | - | drawer_not_closed 77, cup_tipped_over_in_drawer 4, cup_not_placed_in_drawer (cup ended on: counter) 3 |
| claude | family | 8 | 90, 97, 94, 85, 95, 96, 92, 96 | 745/800 = 93.1% | 91.2-94.7% | 93.1, 4.0 | drawer_not_closed 27, cup_not_lifted 8, cup_tipped_over_in_drawer 7 |
| claude | family_v2 | 8 | 88, 94, 97, 90, 92, 98, 97, 93 | 749/800 = 93.6% | 91.7-95.1% | 93.6, 3.6 | drawer_not_closed 19, cup_tipped_over_in_drawer 13, cup_not_lifted 11 |
| claude | oneshot | 3 | 87, 93, 34 | 214/300 = 71.3% | 66.0-76.2% | 71.3, 32.5 | drawer_not_closed 70, cup_not_lifted 7, cup_tipped_over_in_drawer 3 |
| claude | twin | 8 | 93, 89, 82, 92, 95, 93, 97, 95 | 736/800 = 92.0% | 89.9-93.7% | 92.0, 4.7 | drawer_not_closed 26, cup_not_lifted 23, cup_tipped_over_in_drawer 7 |
| codex | family | 8 | 98, 83, 93, 92, 93, 94, 74, 61 | 688/800 = 86.0% | 83.4-88.2% | 86.0, 12.6 | drawer_not_closed 55, cup_not_lifted 41, cup_tipped_over_in_drawer 5 |
| codex | family_v2 | 8 | 91, 89, 73, 88, 85, 94, 87, 21 | 628/800 = 78.5% | 75.5-81.2% | 78.5, 24.0 | drawer_not_closed 96, cup_not_lifted 37, cup_tipped_over_in_drawer 21 |
| codex | oneshot | 3 | 0, 0, 0 | 0/300 = 0.0% | 0.0-1.3% | 0.0, 0.0 | cup_not_lifted 208, drawer_not_opened_enough 92 |
| codex | twin | 8 | 79, 80, 77, 61, 75, 80, 80, 89 | 621/800 = 77.6% | 74.6-80.4% | 77.6, 7.9 | cup_not_lifted 102, drawer_not_closed 27, cup_tipped_over_in_drawer 23 |

Differences in success rate (first minus second). 'scenes': 95% interval from resampling test scenes only. 'runs and scenes': resampling development runs and test scenes. p: permutation test on the per-run success rates.

- claude: family - twin = +1.1 points; scenes (-1.1 to +3.4); runs and scenes (-3.9 to +6.2); p = 0.662
- claude: family_v2 - twin = +1.6 points; scenes (-0.6 to +3.9); runs and scenes (-3.1 to +6.6); p = 0.512
- claude: family_v2 - family = +0.5 points; scenes (-1.6 to +2.6); runs and scenes (-4.0 to +5.2); p = 0.849
- claude: family - oneshot = +21.8 points; scenes (+17.3 to +26.3); runs and scenes (-1.4 to +57.3); p = 0.054
- claude: twin - oneshot = +20.7 points; scenes (+16.5 to +24.8); runs and scenes (-2.6 to +56.1); p = 0.087
- codex: family - twin = +8.4 points; scenes (+4.0 to +13.0); runs and scenes (-3.1 to +19.0); p = 0.140
- codex: family_v2 - twin = +0.9 points; scenes (-2.6 to +4.5); runs and scenes (-18.6 to +15.0); p = 0.969
- codex: family_v2 - family = -7.5 points; scenes (-10.9 to -4.1); runs and scenes (-28.0 to +8.4); p = 0.556
- codex: family - oneshot = +86.0 points; scenes (+82.5 to +89.2); runs and scenes (+76.0 to +94.1); p = 0.006
- codex: twin - oneshot = +77.6 points; scenes (+72.4 to +82.6); runs and scenes (+69.6 to +84.8); p = 0.006

## test_real_100

| agent | condition | runs | per run | pooled | 95% Wilson (pooled) | run mean, SD | failures |
| --- | --- | --- | --- | --- | --- | --- | --- |
| reference | reference_oracle | 1 | 90 | 90/100 = 90.0% | 82.6-94.5% | - | cup_tipped_over_in_drawer 4, cup_not_lifted 3, cup_not_placed_in_drawer (cup ended on: counter) 1 |
| reference | reference_twin_overfit | 1 | 12 | 12/100 = 12.0% | 7.0-19.8% | - | drawer_not_closed 72, cup_not_placed_in_drawer (cup ended on: floor) 5, cup_tipped_over_in_drawer 5 |
| claude | family | 8 | 81, 86, 79, 70, 84, 93, 69, 87 | 649/800 = 81.1% | 78.3-83.7% | 81.1, 8.3 | drawer_not_closed 63, cup_not_lifted 26, cup_not_placed_in_drawer (cup ended on: counter) 25 |
| claude | family_v2 | 8 | 81, 84, 90, 73, 86, 90, 93, 85 | 682/800 = 85.2% | 82.6-87.5% | 85.2, 6.3 | drawer_not_closed 39, cup_tipped_over_in_drawer 24, cup_not_lifted 22 |
| claude | oneshot | 3 | 72, 77, 53 | 202/300 = 67.3% | 61.8-72.4% | 67.3, 12.7 | drawer_not_closed 68, cup_not_placed_in_drawer (cup ended on: counter) 11, cup_not_lifted 9 |
| claude | twin | 8 | 85, 84, 62, 78, 81, 76, 90, 92 | 648/800 = 81.0% | 78.1-83.6% | 81.0, 9.4 | drawer_not_closed 57, cup_not_lifted 36, cup_tipped_over_in_drawer 26 |
| codex | family | 8 | 86, 59, 83, 66, 84, 73, 50, 75 | 576/800 = 72.0% | 68.8-75.0% | 72.0, 12.9 | drawer_not_closed 115, cup_not_lifted 61, cup_not_placed_in_drawer (cup ended on: gripper) 14 |
| codex | family_v2 | 8 | 72, 76, 74, 82, 70, 89, 86, 19 | 568/800 = 71.0% | 67.8-74.0% | 71.0, 22.1 | drawer_not_closed 118, cup_not_lifted 57, cup_tipped_over_in_drawer 18 |
| codex | oneshot | 3 | 0, 0, 0 | 0/300 = 0.0% | 0.0-1.3% | 0.0, 0.0 | cup_not_lifted 219, drawer_not_opened_enough 81 |
| codex | twin | 8 | 78, 77, 64, 57, 56, 84, 70, 86 | 572/800 = 71.5% | 68.3-74.5% | 71.5, 11.6 | cup_not_lifted 115, drawer_not_closed 52, cup_not_placed_in_drawer (cup ended on: gripper) 18 |

Differences in success rate (first minus second). 'scenes': 95% interval from resampling test scenes only. 'runs and scenes': resampling development runs and test scenes. p: permutation test on the per-run success rates.

- claude: family - twin = +0.1 points; scenes (-3.6 to +3.9); runs and scenes (-9.2 to +9.9); p = 1.000
- claude: family_v2 - twin = +4.2 points; scenes (+0.9 to +7.6); runs and scenes (-4.4 to +13.1); p = 0.339
- claude: family_v2 - family = +4.1 points; scenes (+0.4 to +7.9); runs and scenes (-4.1 to +12.8); p = 0.292
- claude: family - oneshot = +13.8 points; scenes (+7.8 to +20.0); runs and scenes (-0.4 to +29.3); p = 0.067
- claude: twin - oneshot = +13.7 points; scenes (+8.2 to +19.2); runs and scenes (-0.5 to +29.6); p = 0.075
- codex: family - twin = +0.5 points; scenes (-4.6 to +5.8); runs and scenes (-12.5 to +13.1); p = 0.951
- codex: family_v2 - twin = -0.5 points; scenes (-4.9 to +4.0); runs and scenes (-19.1 to +14.9); p = 0.976
- codex: family_v2 - family = -1.0 points; scenes (-5.2 to +3.1); runs and scenes (-19.6 to +14.7); p = 0.940
- codex: family - oneshot = +72.0 points; scenes (+67.8 to +76.0); runs and scenes (+61.9 to +81.1); p = 0.006
- codex: twin - oneshot = +71.5 points; scenes (+66.6 to +76.2); runs and scenes (+62.0 to +80.5); p = 0.006

## test_real_b_100

| agent | condition | runs | per run | pooled | 95% Wilson (pooled) | run mean, SD | failures |
| --- | --- | --- | --- | --- | --- | --- | --- |
| reference | reference_oracle | 1 | 87 | 87/100 = 87.0% | 79.0-92.2% | - | cup_not_lifted 5, cup_not_placed_in_drawer (cup ended on: counter) 3, drawer_not_closed 2 |
| reference | reference_twin_overfit | 1 | 12 | 12/100 = 12.0% | 7.0-19.8% | - | drawer_not_closed 68, cup_tipped_over_in_drawer 7, cup_not_placed_in_drawer (cup ended on: floor) 6 |
| claude | family | 8 | 85, 85, 78, 67, 81, 93, 58, 85 | 632/800 = 79.0% | 76.0-81.7% | 79.0, 11.3 | drawer_not_closed 74, cup_not_lifted 28, cup_tipped_over_in_drawer 22 |
| claude | family_v2 | 8 | 76, 79, 89, 76, 81, 84, 89, 83 | 657/800 = 82.1% | 79.3-84.6% | 82.1, 5.1 | cup_not_lifted 40, drawer_not_closed 31, cup_tipped_over_in_drawer 30 |
| claude | oneshot | 3 | 68, 68, 48 | 184/300 = 61.3% | 55.7-66.7% | 61.3, 11.5 | drawer_not_closed 65, cup_not_lifted 19, cup_tipped_over_in_drawer 16 |
| claude | twin | 8 | 81, 85, 58, 73, 80, 80, 84, 88 | 629/800 = 78.6% | 75.7-81.3% | 78.6, 9.4 | drawer_not_closed 59, cup_not_lifted 45, cup_tipped_over_in_drawer 29 |
| codex | family | 8 | 72, 60, 75, 65, 77, 73, 47, 71 | 540/800 = 67.5% | 64.2-70.7% | 67.5, 9.9 | drawer_not_closed 104, cup_not_lifted 87, cup_not_placed_in_drawer (cup ended on: gripper) 18 |
| codex | family_v2 | 8 | 70, 74, 76, 79, 63, 87, 89, 21 | 559/800 = 69.9% | 66.6-73.0% | 69.9, 21.5 | drawer_not_closed 114, cup_not_lifted 70, cup_tipped_over_in_drawer 19 |
| codex | oneshot | 3 | 0, 0, 0 | 0/300 = 0.0% | 0.0-1.3% | 0.0, 0.0 | cup_not_lifted 211, drawer_not_opened_enough 89 |
| codex | twin | 8 | 78, 74, 56, 56, 48, 80, 56, 77 | 525/800 = 65.6% | 62.3-68.8% | 65.6, 12.8 | cup_not_lifted 131, drawer_not_closed 61, cup_not_placed_in_drawer (cup ended on: gripper) 31 |

Differences in success rate (first minus second). 'scenes': 95% interval from resampling test scenes only. 'runs and scenes': resampling development runs and test scenes. p: permutation test on the per-run success rates.

- claude: family - twin = +0.4 points; scenes (-3.4 to +4.1); runs and scenes (-10.6 to +11.5); p = 0.969
- claude: family_v2 - twin = +3.5 points; scenes (-0.4 to +7.2); runs and scenes (-4.6 to +12.4); p = 0.443
- claude: family_v2 - family = +3.1 points; scenes (-1.0 to +7.0); runs and scenes (-6.1 to +13.2); p = 0.523
- claude: family - oneshot = +17.7 points; scenes (+11.5 to +24.1); runs and scenes (+2.9 to +33.4); p = 0.060
- claude: twin - oneshot = +17.3 points; scenes (+10.9 to +24.0); runs and scenes (+3.4 to +33.0); p = 0.025
- codex: family - twin = +1.9 points; scenes (-3.2 to +7.4); runs and scenes (-10.4 to +14.1); p = 0.761
- codex: family_v2 - twin = +4.2 points; scenes (-0.6 to +9.2); runs and scenes (-14.6 to +20.0); p = 0.673
- codex: family_v2 - family = +2.4 points; scenes (-1.8 to +6.5); runs and scenes (-15.3 to +17.2); p = 0.820
- codex: family - oneshot = +67.5 points; scenes (+63.1 to +71.8); runs and scenes (+58.8 to +75.4); p = 0.006
- codex: twin - oneshot = +65.6 points; scenes (+60.2 to +70.6); runs and scenes (+55.2 to +75.5); p = 0.006

## Development runs

| run | problem | dev successes per evaluation | minutes |
| --- | --- | --- | --- |
| main_claude_family_r1 | - | [8, 1, 5, 8] of 8 | 12 |
| main_claude_family_r2 | - | [3, 8] of 8 | 7 |
| main_claude_family_r3 | - | [8, 8, 0, 7, 8] of 8 | 14 |
| main_claude_family_r4 | - | [7, 8, 8] of 8 | 6 |
| main_claude_family_r5 | - | [7, 6, 6, 5, 6] of 8 | 27 |
| main_claude_family_r6 | - | [8, 8, 8, 8, 8] of 8 | 9 |
| main_claude_family_r7 | - | [8, 7, 8, 8, 8] of 8 | 11 |
| main_claude_family_r8 | - | [8, 8, 8] of 8 | 7 |
| main_claude_family_v2_r1 | - | [6, 7, 8, 8] of 8 | 11 |
| main_claude_family_v2_r2 | - | [7, 3, 8, 2, 6] of 8 | 27 |
| main_claude_family_v2_r3 | - | [3, 7, 7, 8, 8] of 8 | 15 |
| main_claude_family_v2_r4 | - | [2, 8, 8, 8, 7] of 8 | 20 |
| main_claude_family_v2_r5 | - | [4, 6, 8, 8] of 8 | 19 |
| main_claude_family_v2_r6 | - | [7, 0, 8, 8, 8] of 8 | 15 |
| main_claude_family_v2_r7 | - | [1, 8, 2, 7, 8] of 8 | 16 |
| main_claude_family_v2_r8 | - | [7, 8, 8, 8] of 8 | 13 |
| main_claude_oneshot_r1 | - | [] of 0 | 9 |
| main_claude_oneshot_r2 | - | [] of 0 | 7 |
| main_claude_oneshot_r3 | - | [] of 0 | 8 |
| main_claude_twin_r1 | - | [0, 8, 8, 7, 8] of 8 | 13 |
| main_claude_twin_r2 | - | [7, 1, 4, 7, 3] of 8 | 17 |
| main_claude_twin_r3 | - | [8, 7, 6, 8] of 8 | 11 |
| main_claude_twin_r4 | - | [6, 8, 8, 8] of 8 | 9 |
| main_claude_twin_r5 | - | [8, 8, 8] of 8 | 6 |
| main_claude_twin_r6 | - | [6, 6, 6, 7, 8] of 8 | 12 |
| main_claude_twin_r7 | - | [6, 7, 8, 8, 8] of 8 | 12 |
| main_claude_twin_r8 | - | [4, 7, 7, 0, 8] of 8 | 15 |
| main_codex_family_r1 | - | [0, 4, 6, 7, 7] of 8 | 5 |
| main_codex_family_r2 | - | [0, 2, 8, 8, 8] of 8 | 5 |
| main_codex_family_r3 | - | [0, 8, 0, 8, 8] of 8 | 4 |
| main_codex_family_r4 | - | [0, 4, 8, 8, 8] of 8 | 5 |
| main_codex_family_r5 | - | [0, 6, 1, 7, 8] of 8 | 5 |
| main_codex_family_r6 | - | [0, 0, 5, 0, 6] of 8 | 5 |
| main_codex_family_r7 | - | [0, 8, 8, 8, 8] of 8 | 5 |
| main_codex_family_r8 | - | [0, 4, 1, 7, 6] of 8 | 5 |
| main_codex_family_v2_r1 | - | [0, 5, 0, 6, 6] of 8 | 5 |
| main_codex_family_v2_r2 | - | [0, 1, 7, 8, 8] of 8 | 4 |
| main_codex_family_v2_r3 | - | [0, 0, 4, 0, 7] of 8 | 5 |
| main_codex_family_v2_r4 | - | [0, 2, 0, 4, 5] of 8 | 6 |
| main_codex_family_v2_r5 | - | [0, 3, 0, 8, 8] of 8 | 5 |
| main_codex_family_v2_r6 | - | [0, 3, 0, 3, 8] of 8 | 5 |
| main_codex_family_v2_r7 | - | [0, 2, 0, 8, 8] of 8 | 5 |
| main_codex_family_v2_r8 | - | [0, 0, 3, 0, 1] of 8 | 5 |
| main_codex_oneshot_r1 | - | [] of 0 | 2 |
| main_codex_oneshot_r2 | - | [] of 0 | 2 |
| main_codex_oneshot_r3 | - | [] of 0 | 2 |
| main_codex_twin_r1 | - | [0, 3, 0, 5, 8] of 8 | 5 |
| main_codex_twin_r2 | - | [1, 7, 6, 8, 8] of 8 | 5 |
| main_codex_twin_r3 | - | [0, 0, 0, 8, 8] of 8 | 5 |
| main_codex_twin_r4 | - | [0, 0, 1, 7, 8] of 8 | 5 |
| main_codex_twin_r5 | - | [0, 8, 8, 8, 5] of 8 | 7 |
| main_codex_twin_r6 | - | [0, 0, 0, 2, 7] of 8 | 6 |
| main_codex_twin_r7 | - | [0, 0, 8, 8, 8] of 8 | 6 |
| main_codex_twin_r8 | - | [0, 4, 6, 6, 4] of 8 | 5 |
