import math
import numpy as np


def run(api):
    counter = api.get_counter()
    objects = api.get_objects()
    high = max(
        [0.50, counter["top_z"] + 0.18]
        + [
            o["pos"][2] + o["size"][2] / 2.0 + 0.15
            for o in objects
        ]
    )

    def move(p, yaw=None, speed=0.35):
        p = [float(v) for v in p]
        for _ in range(3):
            result = api.move_to(p, yaw=yaw, speed=speed)
            if result["reached"]:
                return True
        return False

    def rise():
        p = list(api.get_ee()["pos"])
        p[2] = high
        return move(p)

    def approach_handle(offset=(0.0, 0.0, 0.0)):
        h = np.array(api.get_handle()["pos"], dtype=float)
        h += np.array(offset)
        api.open_gripper()
        if not rise():
            return False
        if not move([h[0] - 0.065, h[1], high], 0.0):
            return False
        if not move([h[0] - 0.065, h[1], h[2]], 0.0):
            return False
        if not move(h, 0.0, 0.12):
            return False
        width = api.close_gripper()
        return 0.003 < width < 0.045

    def leave_handle():
        api.open_gripper()
        p = np.array(api.get_ee()["pos"], dtype=float)
        p[0] -= 0.065
        move(p, speed=0.20)
        rise()

    # Open the drawer before picking up the cup.
    opened = False
    for offset in (
        (0.0, 0.0, 0.0),
        (0.0, 0.009, 0.0),
        (0.0, -0.009, 0.0),
        (0.009, 0.0, 0.0),
    ):
        drawer = api.get_drawer()
        if drawer["opening"] >= 0.35:
            opened = True
            break
        if not approach_handle(offset):
            leave_handle()
            continue
        before = api.get_drawer()["opening"]
        p = np.array(api.get_ee()["pos"], dtype=float)
        p[0] -= max(0.0, 0.39 - before)
        move(p, speed=0.25)
        after = api.get_drawer()["opening"]
        leave_handle()
        if after >= 0.35:
            opened = True
            break
        if after > before + 0.025:
            # A partial pull still establishes a usable handle grasp.
            api.log("Drawer moved; retrying from its updated position.")

    if not opened:
        api.log("Unable to open drawer sufficiently.")
        return

    drawer = api.get_drawer()
    cup = api.get_cup()
    objects = api.get_objects()
    center = np.array(drawer["interior_center"], dtype=float)
    size = np.array(drawer["interior_size"], dtype=float)
    radius = float(cup["radius"])
    height = float(cup["height"])

    # Reserve space for the body, handle, fingers, and perception error.
    margin = max(0.073, radius + 0.039)
    low_x = center[0] - size[0] / 2.0 + margin
    high_x = min(
        center[0] + size[0] / 2.0 - margin,
        counter["front_x"] - margin - 0.015,
    )
    low_y = center[1] - size[1] / 2.0 + margin
    high_y = center[1] + size[1] / 2.0 - margin

    def rectangle_distance(x, y, obj):
        ox, oy = obj["pos"][:2]
        sx, sy = obj["size"][:2]
        dx = max(abs(x - ox) - sx / 2.0, 0.0)
        dy = max(abs(y - oy) - sy / 2.0, 0.0)
        return math.hypot(dx, dy)

    placement = None
    best_score = -float("inf")
    if low_x <= high_x and low_y <= high_y:
        for x in np.linspace(low_x, high_x, 23):
            for y in np.linspace(low_y, high_y, 31):
                obstacle_clearance = float("inf")
                for obj in objects:
                    # Include counter objects when checking the descent column.
                    obstacle_clearance = min(
                        obstacle_clearance,
                        rectangle_distance(x, y, obj) - margin,
                    )
                if obstacle_clearance < 0.0:
                    continue
                wall_clearance = min(
                    x - low_x, high_x - x, y - low_y, high_y - y
                )
                score = min(obstacle_clearance, wall_clearance)
                score -= 0.015 * abs(y - center[1])
                if score > best_score:
                    best_score = score
                    placement = [float(x), float(y)]

    if placement is None:
        api.log("No sufficiently clear placement column.")
        return

    # Grasp across the cup body, perpendicular to its handle direction.
    held = False
    grasp_delta = None
    grasp_yaw = float(cup["yaw"])
    for dx, dy in (
        (0.0, 0.0),
        (0.0, 0.008),
        (0.0, -0.008),
        (0.008, 0.0),
        (-0.008, 0.0),
    ):
        api.open_gripper()
        if not rise():
            return
        observed = api.get_cup()
        original = np.array(observed["pos"], dtype=float)
        grasp_yaw = float(observed["yaw"])
        # Offsets are expressed in the gripper's horizontal frame.
        c, s = math.cos(grasp_yaw), math.sin(grasp_yaw)
        target = original + np.array([c * dx - s * dy, s * dx + c * dy, 0.0])
        if not move([target[0], target[1], high], grasp_yaw):
            continue
        if not move(target, grasp_yaw, 0.12):
            continue
        width = api.close_gripper()
        if not (0.025 < width < 0.079):
            continue
        lift = np.array(api.get_ee()["pos"], dtype=float)
        lift[2] += 0.085
        if not move(lift, grasp_yaw, 0.16):
            continue
        lifted = np.array(api.get_cup()["pos"], dtype=float)
        if lifted[2] - original[2] > 0.045:
            held = True
            grasp_delta = lifted - np.array(api.get_ee()["pos"], dtype=float)
            break

    if not held:
        api.open_gripper()
        rise()
        api.log("Could not verify cup pickup.")
        return

    if not rise():
        return

    # Preserve cup orientation throughout transport. Use the measured grasp
    # offset so the body, rather than merely the fingertips, reaches the site.
    target_body = np.array(
        [
            placement[0],
            placement[1],
            drawer["floor_z"] + height / 2.0 + 0.012,
        ],
        dtype=float,
    )
    target_ee = target_body - grasp_delta
    if not move([target_ee[0], target_ee[1], high], grasp_yaw):
        return
    if not move(target_ee, grasp_yaw, 0.12):
        return
    api.open_gripper()
    api.wait(0.35)
    if not rise():
        return

    # Pulling and pushing use exact fingertip displacement, avoiding cumulative
    # errors from independently estimated handle coordinates.
    for offset in (
        (0.0, 0.0, 0.0),
        (0.0, 0.009, 0.0),
        (0.0, -0.009, 0.0),
        (0.009, 0.0, 0.0),
    ):
        opening = api.get_drawer()["opening"]
        if opening <= 0.008:
            break
        if not approach_handle(offset):
            leave_handle()
            continue
        for _ in range(5):
            opening = api.get_drawer()["opening"]
            if opening <= 0.005:
                break
            p = np.array(api.get_ee()["pos"], dtype=float)
            p[0] += min(0.12, opening + 0.008)
            move(p, 0.0, 0.20)
            updated = api.get_drawer()["opening"]
            if opening - updated < 0.002:
                break
        leave_handle()
        if api.get_drawer()["opening"] <= 0.008:
            break

    api.log("Finished cup placement and drawer closure.")
