import math
import numpy as np


def run(api):
    counter = api.get_counter()
    objects = api.get_objects()
    high = max(
        [0.50, counter["top_z"] + 0.17]
        + [o["pos"][2] + o["size"][2] / 2 + 0.14 for o in objects]
    )

    def move(p, yaw=None, speed=0.30):
        result = api.move_to([float(v) for v in p], yaw=yaw, speed=speed)
        if not result["reached"] and result["error"] < 0.035:
            result = api.move_to([float(v) for v in p], yaw=yaw, speed=speed)
        return result["reached"]

    def rise():
        p = list(api.get_ee()["pos"])
        p[2] = high
        return move(p)

    def handle_grasp(xoffset=-0.012, yoffset=0.0):
        api.open_gripper()
        rise()
        h = np.array(api.get_handle()["pos"], dtype=float)
        h += [xoffset, yoffset, 0.0]
        move([h[0], h[1], high], 0.0)
        move(h, 0.0, 0.15)
        width = api.close_gripper()
        api.log("Handle grip width: %.4f" % width)
        return 0.002 < width < 0.045

    def handle_release():
        api.open_gripper()
        rise()

    # Moderate extension leaves the handle within the arm's workspace.
    for xoff in (-0.012, -0.025, 0.0, 0.010):
        opening = api.get_drawer()["opening"]
        if opening >= 0.265:
            break
        if handle_grasp(xoff):
            p = np.array(api.get_ee()["pos"], dtype=float)
            opening = api.get_drawer()["opening"]
            p[0] -= max(0.0, 0.305 - opening)
            move(p, 0.0, 0.20)
        handle_release()

    drawer = api.get_drawer()
    if drawer["opening"] < 0.245:
        api.log("Drawer opening insufficient.")
        return

    cup = api.get_cup()
    objects = api.get_objects()
    center = np.array(drawer["interior_center"], dtype=float)
    size = np.array(drawer["interior_size"], dtype=float)
    radius = cup["radius"]
    height = cup["height"]
    margin = max(0.065, radius + 0.032)
    xmin = center[0] - size[0] / 2 + margin
    xmax = min(
        center[0] + size[0] / 2 - margin,
        counter["front_x"] - 0.075,
    )
    ymin = center[1] - size[1] / 2 + margin
    ymax = center[1] + size[1] / 2 - margin

    def clearance(x, y, obj):
        dx = max(abs(x - obj["pos"][0]) - obj["size"][0] / 2, 0.0)
        dy = max(abs(y - obj["pos"][1]) - obj["size"][1] / 2, 0.0)
        return math.hypot(dx, dy) - margin

    placement = None
    best = -float("inf")
    if xmin <= xmax and ymin <= ymax:
        for x in np.linspace(xmin, xmax, 21):
            for y in np.linspace(ymin, ymax, 31):
                free = min(
                    [clearance(x, y, obj) for obj in objects]
                    + [1.0]
                )
                if free < 0:
                    continue
                score = min(
                    free, x - xmin, xmax - x, y - ymin, ymax - y
                )
                if score > best:
                    best = score
                    placement = [float(x), float(y)]
    if placement is None:
        api.log("No clear placement column.")
        return

    held = False
    delta = None
    yaw = cup["yaw"]
    for dx, dy in (
        (0.0, 0.0),
        (0.0, 0.008),
        (0.0, -0.008),
        (0.008, 0.0),
        (-0.008, 0.0),
    ):
        api.open_gripper()
        rise()
        cup = api.get_cup()
        original = np.array(cup["pos"], dtype=float)
        yaw = cup["yaw"]
        c, s = math.cos(yaw), math.sin(yaw)
        target = original + [c * dx - s * dy, s * dx + c * dy, 0.005]
        if not move([target[0], target[1], high], yaw):
            continue
        move(target, yaw, 0.12)
        width = api.close_gripper()
        api.log("Cup grip width: %.4f" % width)
        if width < 0.020 or width >= 0.079:
            continue
        lift = np.array(api.get_ee()["pos"], dtype=float)
        lift[2] += 0.085
        move(lift, yaw, 0.15)
        observed = np.array(api.get_cup()["pos"], dtype=float)
        if observed[2] > original[2] + 0.045:
            held = True
            delta = observed - np.array(api.get_ee()["pos"], dtype=float)
            break

    if not held:
        api.open_gripper()
        rise()
        api.log("Cup pickup unverified.")
        return

    if not rise():
        return
    body = np.array(
        [
            placement[0],
            placement[1],
            drawer["floor_z"] + height / 2 + 0.012,
        ],
        dtype=float,
    )
    target = body - delta
    if not move([target[0], target[1], high], yaw):
        return
    if not move(target, yaw, 0.12):
        api.log("Placement descent blocked.")
        return
    api.open_gripper()
    api.wait(0.3)
    rise()

    for xoff in (-0.012, -0.025, 0.0):
        if api.get_drawer()["opening"] <= 0.007:
            break
        if not handle_grasp(xoff):
            handle_release()
            continue
        for _ in range(4):
            opening = api.get_drawer()["opening"]
            if opening <= 0.004:
                break
            p = np.array(api.get_ee()["pos"], dtype=float)
            p[0] += min(0.11, opening + 0.006)
            move(p, 0.0, 0.18)
            if api.get_drawer()["opening"] >= opening - 0.002:
                break
        handle_release()
    api.log("Placement sequence complete.")
