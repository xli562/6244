import math
import numpy as np


def run(api):
    def move(p, yaw=None, speed=0.24):
        return api.move_to(
            np.asarray(p, dtype=float).tolist(),
            yaw=yaw,
            speed=speed,
        )["reached"]

    def ee():
        return np.array(api.get_ee()["pos"], dtype=float)

    def height():
        z = api.get_counter()["top_z"] + 0.12
        for obj in api.get_objects():
            if obj["location"] == "counter":
                z = max(
                    z,
                    obj["pos"][2] + obj["size"][2] / 2 + 0.075,
                )
        return z

    def rise():
        p = ee()
        p[2] = max(p[2], height())
        return move(p)

    def handle_grasp():
        api.open_gripper()
        rise()
        offsets = [
            (0, 0),
            (0.012, 0),
            (-0.012, 0),
            (0.024, 0),
            (-0.024, 0),
            (0.012, 0.015),
            (0.012, -0.015),
        ]
        for dx, dy in offsets:
            h = np.array(api.get_handle()["pos"], dtype=float)
            h[0] += dx
            h[1] += dy
            h[2] = min(0.225, max(0.210, h[2]))
            if h[0] < 0.24:
                h[2] = max(h[2], 0.225)

            above = h.copy()
            above[2] = height()
            if not move(above, 0.0):
                continue
            if not move(h, 0.0, 0.12):
                rise()
                continue

            width = api.close_gripper()
            if 0.004 < width < 0.075:
                return True
            api.open_gripper()
            rise()
        return False

    def release_handle(retreat=False):
        api.open_gripper()
        if retreat:
            p = ee()
            p[0] -= 0.065
            move(p, 0.0, 0.15)
        rise()

    def open_drawer():
        for _ in range(3):
            drawer = api.get_drawer()
            if drawer["opening"] >= 0.26:
                return True
            if not handle_grasp():
                return False

            drawer = api.get_drawer()
            p = ee()
            p[0] -= max(0.0, 0.305 - drawer["opening"])
            move(p, 0.0, 0.14)
            release_handle()
            if api.get_drawer()["opening"] >= 0.245:
                return True
        return False

    def placement(cup):
        drawer = api.get_drawer()
        counter = api.get_counter()
        center = np.array(drawer["interior_center"], dtype=float)
        size = np.array(drawer["interior_size"], dtype=float)
        clearance = cup["radius"] + 0.047

        low = center[:2] - size[:2] / 2 + clearance
        high = center[:2] + size[:2] / 2 - clearance
        high[0] = min(
            high[0], counter["front_x"] - clearance - 0.015
        )
        if np.any(high <= low):
            return None

        obstacles = []
        for obj in api.get_objects():
            c = np.array(obj["pos"][:2])
            s = np.array(obj["size"][:2])
            obstacles.append((c - s / 2, c + s / 2))

        best = None
        best_score = -1e9
        for x in np.linspace(low[0], high[0], 21):
            for y in np.linspace(low[1], high[1], 31):
                p = np.array([x, y])
                score = min(np.min(p - low), np.min(high - p))
                for a, b in obstacles:
                    distance = np.linalg.norm(
                        np.maximum(np.maximum(a - p, p - b), 0)
                    )
                    score = min(score, distance - clearance)
                if score >= 0 and score > best_score:
                    best = p
                    best_score = score

        if best is None:
            return None
        return np.array([
            best[0],
            best[1],
            drawer["floor_z"] + cup["height"] / 2 + 0.010,
        ])

    def pick_cup():
        offsets = [
            (0, 0),
            (-0.012, -0.012),
            (0.012, 0.012),
            (-0.012, 0.012),
            (0.012, -0.012),
            (-0.024, -0.024),
            (0.024, 0.024),
        ]
        for dx, dy in offsets:
            cup = api.get_cup()
            center = np.array(cup["pos"], dtype=float)
            yaw = (cup["yaw"] + math.pi / 2) % math.pi - math.pi / 2
            target = center + np.array([dx, dy, 0.0])

            api.open_gripper()
            rise()
            above = target.copy()
            above[2] = max(
                center[2] + 0.080,
                api.get_counter()["top_z"] + 0.105,
            )

            staging = above.copy()
            staging[0] = min(0.48, above[0])
            staging[2] = height()
            move(staging, yaw)

            if not move(above, yaw):
                above[2] -= 0.025
                if not move(above, yaw, 0.15):
                    continue
            if not move(target, yaw, 0.10):
                rise()
                continue

            width = api.close_gripper()
            if width < 0.025:
                api.open_gripper()
                move(above, yaw)
                continue

            lifted = ee()
            lifted[2] += 0.065
            move(lifted, yaw, 0.12)
            observed = api.get_cup()
            actual = np.array(observed["pos"], dtype=float)
            if actual[2] > center[2] + 0.035:
                return observed, actual - ee(), yaw

            api.open_gripper()
            move(above, yaw)
        return None

    def push_front():
        # Push away from the handle, with the palm below the counter.
        # Retreat before descending so the vertical handle cannot catch it.
        api.open_gripper()
        drawer = api.get_drawer()
        counter = api.get_counter()
        handle = np.array(api.get_handle()["pos"], dtype=float)
        p = ee()
        p[0] = min(p[0], handle[0] - 0.10)
        move(p, 0.0, 0.15)
        rise()
        api.close_gripper()

        y = drawer["interior_center"][1] - 0.135
        z = min(0.155, counter["top_z"] - 0.140)
        start_x = min(
            handle[0] - 0.09,
            counter["front_x"] - max(0.0, drawer["opening"]) - 0.11,
        )
        above = np.array([start_x, y, height()])
        move(above, 0.0)
        start = np.array([start_x, y, z])
        if not move(start, 0.0, 0.12):
            rise()
            return False

        target = np.array([counter["front_x"] - 0.018, y, z])
        move(target, 0.0, 0.08)
        api.wait(0.3)
        p = ee()
        p[0] -= 0.10
        move(p, 0.0, 0.12)
        api.open_gripper()
        rise()
        return api.get_drawer()["opening"] < 0.010

    def close_drawer():
        if not handle_grasp():
            return push_front()

        drawer = api.get_drawer()
        p = ee()
        p[0] += max(0.0, drawer["opening"] - 0.025)
        move(p, 0.0, 0.12)
        api.open_gripper()

        # Withdraw fully before lowering. A short diagonal descent can
        # catch the palm on the upper end of the vertical handle.
        h = np.array(api.get_handle()["pos"], dtype=float)
        retreat = ee()
        retreat[0] = min(retreat[0] - 0.09, h[0] - 0.10)
        move(retreat, 0.0, 0.12)

        acquired = False
        for dx in (0.0, 0.012, -0.012):
            h = np.array(api.get_handle()["pos"], dtype=float)
            h[0] += dx
            h[2] = min(0.165, max(0.150, h[2] - 0.050))
            front = h.copy()
            front[0] -= 0.09

            p = ee()
            p[0] = min(p[0], front[0])
            move(p, 0.0, 0.12)
            if not move(front, 0.0, 0.12):
                break
            move(h, 0.0, 0.09)
            width = api.close_gripper()
            if 0.004 < width < 0.075:
                acquired = True
                break
            api.open_gripper()

        if acquired:
            for _ in range(2):
                drawer = api.get_drawer()
                p = ee()
                p[0] += max(0.0, drawer["opening"]) + 0.018
                move(p, 0.0, 0.09)
                api.wait(0.2)
                if api.get_drawer()["opening"] < 0.004:
                    break

        release_handle(True)
        if api.get_drawer()["opening"] < 0.010:
            return True
        return push_front()

    if not open_drawer():
        api.log("Could not open drawer.")
        return

    if placement(api.get_cup()) is None:
        api.log("No clear placement area.")
        return

    grasp = pick_cup()
    if grasp is None:
        api.log("Cup grasp not verified.")
        return

    cup, offset, yaw = grasp
    destination = placement(cup)
    if destination is None:
        return
    target = destination - offset

    p = ee()
    transit = np.array([min(0.48, p[0]), p[1], height()])
    if not move(transit, yaw, 0.18):
        return

    above = target.copy()
    above[2] = height()
    if not move(above, yaw):
        return
    if not move(target, yaw, 0.09):
        return

    api.open_gripper()
    api.wait(0.5)
    rise()

    placed = api.get_cup()
    drawer = api.get_drawer()
    p = np.array(placed["pos"])
    center = np.array(drawer["interior_center"])
    size = np.array(drawer["interior_size"])
    inside = np.all(
        np.abs(p[:2] - center[:2]) < size[:2] / 2 - placed["radius"]
    )
    settled = abs(
        p[2] - drawer["floor_z"] - placed["height"] / 2
    ) < 0.035

    if inside and settled:
        close_drawer()
    else:
        api.log("Placement not verified.")
