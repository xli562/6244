import math
import numpy as np


def run(api):
    def move(p, yaw=None, speed=0.24):
        return api.move_to(np.asarray(p, dtype=float).tolist(),
                           yaw=yaw, speed=speed)["reached"]

    def ee():
        return np.array(api.get_ee()["pos"], dtype=float)

    def height():
        z = api.get_counter()["top_z"] + 0.12
        for o in api.get_objects():
            if o["location"] == "counter":
                z = max(z, o["pos"][2] + o["size"][2] / 2 + 0.075)
        return z

    def rise():
        p = ee()
        p[2] = max(p[2], height())
        return move(p)

    def handle_grasp():
        api.open_gripper()
        rise()
        for dx in (0.0, 0.012, -0.012, 0.024, -0.024):
            h = np.array(api.get_handle()["pos"], dtype=float)
            h[0] += dx
            h[2] += 0.025
            above = h.copy()
            above[2] = height()
            if not move(above, 0.0):
                continue
            if not move(h, 0.0, 0.12):
                rise()
                continue
            w = api.close_gripper()
            if 0.004 < w < 0.045:
                return True
            api.open_gripper()
            rise()
        return False

    def release_handle(retreat=False):
        api.open_gripper()
        if retreat:
            p = ee()
            p[0] -= 0.065
            move(p, 0.0, 0.15)
        rise()

    def open_drawer():
        for _ in range(2):
            d = api.get_drawer()
            if d["opening"] >= 0.26:
                return True
            if not handle_grasp():
                return False
            d = api.get_drawer()
            p = ee()
            p[0] -= max(0.0, 0.305 - d["opening"])
            move(p, 0.0, 0.14)
            release_handle()
            if api.get_drawer()["opening"] >= 0.245:
                return True
        return False

    def placement(cup):
        d = api.get_drawer()
        counter = api.get_counter()
        c = np.array(d["interior_center"], dtype=float)
        s = np.array(d["interior_size"], dtype=float)
        clearance = cup["radius"] + 0.047
        lo = c[:2] - s[:2] / 2 + clearance
        hi = c[:2] + s[:2] / 2 - clearance
        hi[0] = min(hi[0], counter["front_x"] - clearance - 0.015)
        if np.any(hi <= lo):
            return None
        obstacles = []
        for o in api.get_objects():
            oc = np.array(o["pos"][:2])
            os = np.array(o["size"][:2])
            obstacles.append((oc - os / 2, oc + os / 2))
        best, score_best = None, -1e9
        for x in np.linspace(lo[0], hi[0], 21):
            for y in np.linspace(lo[1], hi[1], 31):
                p = np.array([x, y])
                score = min(np.min(p - lo), np.min(hi - p))
                for a, b in obstacles:
                    distance = np.linalg.norm(
                        np.maximum(np.maximum(a - p, p - b), 0))
                    score = min(score, distance - clearance)
                if score >= 0 and score > score_best:
                    best, score_best = p, score
        if best is None:
            return None
        return np.array([best[0], best[1],
                         d["floor_z"] + cup["height"] / 2 + 0.010])

    def pick_cup():
        offsets = [(0, 0), (-0.012, -0.012), (0.012, 0.012),
                   (-0.012, 0.012), (0.012, -0.012),
                   (-0.024, -0.024), (0.024, 0.024)]
        for dx, dy in offsets:
            cup = api.get_cup()
            center = np.array(cup["pos"], dtype=float)
            yaw = (cup["yaw"] + math.pi / 2) % math.pi - math.pi / 2
            target = center + np.array([dx, dy, 0.0])
            api.open_gripper()
            rise()
            above = target.copy()
            above[2] = max(center[2] + 0.080,
                           api.get_counter()["top_z"] + 0.105)
            staging = above.copy()
            staging[0] = min(0.48, above[0])
            staging[2] = height()
            move(staging, yaw)
            if not move(above, yaw):
                above[2] -= 0.025
                if not move(above, yaw, 0.15):
                    continue
            if not move(target, yaw, 0.10):
                rise()
                continue
            w = api.close_gripper()
            if w < 0.025:
                api.open_gripper()
                move(above, yaw)
                continue
            lifted = ee()
            lifted[2] += 0.065
            move(lifted, yaw, 0.12)
            observed = api.get_cup()
            actual = np.array(observed["pos"], dtype=float)
            if actual[2] > center[2] + 0.035:
                return observed, actual - ee(), yaw
            api.open_gripper()
            move(above, yaw)
        return None

    def close_drawer():
        if not handle_grasp():
            return False

        # First move the drawer into the region where the bottom of its
        # handle can be reached.
        d = api.get_drawer()
        p = ee()
        p[0] += max(0.0, d["opening"] - 0.085)
        move(p, 0.0, 0.12)

        # Regrasp low on the vertical bar so the gripper body passes below
        # the counter during the last part of closure.
        api.open_gripper()
        retreat = ee()
        retreat[0] -= 0.035
        move(retreat, 0.0, 0.12)
        acquired = False
        for dx in (0.0, 0.012, -0.012, 0.024):
            h = np.array(api.get_handle()["pos"], dtype=float)
            h[0] += dx
            h[2] -= 0.050
            front = h.copy()
            front[0] -= 0.035
            move(front, 0.0, 0.12)
            move(h, 0.0, 0.09)
            w = api.close_gripper()
            if 0.004 < w < 0.045:
                acquired = True
                break
            api.open_gripper()
        if not acquired:
            release_handle(True)
            return False

        for _ in range(3):
            d = api.get_drawer()
            p = ee()
            p[0] += max(0.0, d["opening"]) + 0.018
            move(p, 0.0, 0.09)
            api.wait(0.2)
            if api.get_drawer()["opening"] < 0.004:
                break
        release_handle(True)
        return api.get_drawer()["opening"] < 0.010

    if not open_drawer():
        api.log("Could not open drawer.")
        return
    if placement(api.get_cup()) is None:
        api.log("No clear placement area.")
        return
    grasp = pick_cup()
    if grasp is None:
        api.log("Cup grasp not verified.")
        return
    cup, offset, yaw = grasp
    destination = placement(cup)
    if destination is None:
        return
    target = destination - offset
    p = ee()
    transit = np.array([min(0.48, p[0]), p[1], height()])
    if not move(transit, yaw, 0.18):
        return
    above = target.copy()
    above[2] = height()
    if not move(above, yaw):
        return
    if not move(target, yaw, 0.09):
        return
    api.open_gripper()
    api.wait(0.5)
    rise()
    placed = api.get_cup()
    d = api.get_drawer()
    p = np.array(placed["pos"])
    c = np.array(d["interior_center"])
    s = np.array(d["interior_size"])
    inside = np.all(np.abs(p[:2] - c[:2]) <
                    s[:2] / 2 - placed["radius"])
    settled = abs(p[2] - d["floor_z"] - placed["height"] / 2) < 0.035
    if inside and settled:
        close_drawer()
    else:
        api.log("Placement not verified.")
