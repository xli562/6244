import math
import numpy as np


def run(api):
    # All positions are obtained at runtime. Extra clearance accounts for
    # perception error and the cup's handle.
    margin = 0.020

    def move(p, yaw=None, speed=0.24):
        p = np.asarray(p, dtype=float).tolist()
        result = api.move_to(p, yaw=yaw, speed=speed)
        if not result["reached"]:
            result = api.move_to(p, yaw=yaw, speed=0.12)
        return result["reached"]

    def ee():
        return np.asarray(api.get_ee()["pos"], dtype=float)

    def safe_height():
        counter = api.get_counter()
        z = float(counter["top_z"]) + 0.18
        for obj in api.get_objects():
            if obj["location"] == "counter":
                z = max(z, obj["pos"][2] + obj["size"][2] / 2 + 0.12)
        return z

    def rise(z):
        p = ee()
        p[2] = max(p[2], z)
        return move(p)

    def grasp_handle():
        api.open_gripper()
        # A front approach avoids descending through the counter or panel.
        offsets = [(0, 0), (0, -0.009), (0, 0.009),
                   (-0.009, 0), (0.009, 0)]
        for dx, dy in offsets:
            h = np.asarray(api.get_handle()["pos"], dtype=float)
            target = h + np.array([dx, dy, 0.0])
            if not rise(safe_height()):
                return False
            front = target.copy()
            front[0] -= 0.075
            overhead = front.copy()
            overhead[2] = safe_height()
            if not move(overhead, 0.0):
                return False
            if not move(front, 0.0):
                return False
            if not move(target, 0.0, 0.10):
                api.open_gripper()
                move(front)
                continue
            width = api.close_gripper()
            if 0.004 < width < 0.045:
                return True
            api.open_gripper()
            move(front, speed=0.12)
        return False

    def release_handle():
        api.open_gripper()
        p = ee()
        p[0] -= 0.065
        move(p, speed=0.15)
        rise(safe_height())

    def open_drawer():
        for _ in range(2):
            drawer = api.get_drawer()
            if drawer["opening"] >= 0.40:
                return True
            if not grasp_handle():
                return False
            before = float(api.get_drawer()["opening"])
            target = ee()
            target[0] -= max(0.0, 0.44 - before)
            move(target, 0.0, 0.15)
            after = float(api.get_drawer()["opening"])
            release_handle()
            if after >= 0.39:
                return True
            if after <= before + 0.02:
                api.log("Handle grasp did not move the drawer; retrying.")
        return False

    def placement(cup):
        drawer = api.get_drawer()
        counter = api.get_counter()
        center = np.asarray(drawer["interior_center"], dtype=float)
        size = np.asarray(drawer["interior_size"], dtype=float)
        # Conservatively cover the body, handle, and open fingers.
        footprint = float(cup["radius"]) + 0.033
        clearance = footprint + margin
        low = center[:2] - size[:2] / 2 + clearance
        high = center[:2] + size[:2] / 2 - clearance
        high[0] = min(high[0], counter["front_x"] - clearance - 0.025)
        if np.any(high <= low):
            return None

        obstacles = []
        for obj in api.get_objects():
            c = np.asarray(obj["pos"], dtype=float)
            s = np.asarray(obj["size"], dtype=float)
            # Counter objects near the front can obstruct the descent too.
            if obj["location"] in ("drawer", "counter"):
                obstacles.append((c[:2] - s[:2] / 2,
                                  c[:2] + s[:2] / 2))

        best = None
        best_score = -1e9
        for x in np.linspace(low[0], high[0], 23):
            for y in np.linspace(low[1], high[1], 27):
                p = np.array([x, y])
                score = min(*(p - low), *(high - p))
                valid = True
                for a, b in obstacles:
                    delta = np.maximum(np.maximum(a - p, p - b), 0.0)
                    distance = float(np.linalg.norm(delta))
                    if distance < clearance:
                        valid = False
                        break
                    score = min(score, distance - clearance)
                if valid and score > best_score:
                    best_score = score
                    best = p
        if best is None:
            return None
        return np.array([best[0], best[1],
                         float(drawer["floor_z"]) +
                         float(cup["height"]) / 2 + 0.012])

    def pick_cup():
        offsets = [(0, 0), (0, -0.007), (0, 0.007),
                   (-0.007, 0), (0.007, 0)]
        for dx, dy in offsets:
            cup = api.get_cup()
            center = np.asarray(cup["pos"], dtype=float)
            yaw = float(cup["yaw"])
            target = center + np.array([dx, dy, 0.002])
            api.open_gripper()
            if not rise(safe_height()):
                return None
            above = target.copy()
            above[2] = safe_height()
            if not move(above, yaw):
                return None
            if not move(target, yaw, 0.10):
                rise(safe_height())
                continue
            width = api.close_gripper()
            if width < 0.025:
                api.open_gripper()
                rise(safe_height())
                continue

            lifted = ee()
            lifted[2] += 0.09
            if not move(lifted, yaw, 0.12):
                return None
            observed = api.get_cup()
            actual_center = np.asarray(observed["pos"], dtype=float)
            if actual_center[2] > center[2] + 0.045:
                # Preserve the measured grasp offset during placement.
                offset = actual_center - ee()
                return observed, offset, yaw
            api.open_gripper()
            rise(safe_height())
        return None

    def close_drawer():
        for _ in range(3):
            if not grasp_handle():
                return False
            before = float(api.get_drawer()["opening"])
            p = ee()
            p[0] += max(0.0, before) + 0.012
            move(p, 0.0, 0.12)
            release_handle()
            after = float(api.get_drawer()["opening"])
            if after <= 0.012:
                return True
            if after >= before - 0.005:
                api.log("Drawer closure stalled.")
        return False

    if not open_drawer():
        api.log("Unable to establish a sufficiently open drawer.")
        return

    if placement(api.get_cup()) is None:
        api.log("No unobstructed placement area.")
        return

    grasp = pick_cup()
    if grasp is None:
        api.log("Cup grasp could not be verified.")
        return
    cup, offset, yaw = grasp

    destination = placement(cup)
    if destination is None:
        api.log("Placement area is unavailable.")
        return

    target = destination - offset
    if not rise(safe_height()):
        return
    above = target.copy()
    above[2] = safe_height()
    if not move(above, yaw):
        return
    if not move(target, yaw, 0.09):
        return

    api.open_gripper()
    api.wait(0.5)
    if not rise(safe_height()):
        return

    placed = api.get_cup()
    drawer = api.get_drawer()
    p = np.asarray(placed["pos"], dtype=float)
    c = np.asarray(drawer["interior_center"], dtype=float)
    s = np.asarray(drawer["interior_size"], dtype=float)
    inside = np.all(np.abs(p[:2] - c[:2]) <
                    s[:2] / 2 - float(placed["radius"]))
    settled = abs(p[2] - (drawer["floor_z"] +
                         placed["height"] / 2)) < 0.035

    if inside and settled:
        if close_drawer():
            api.log("Cup released inside the drawer; drawer closed.")
    else:
        api.log("Cup placement could not be verified; leaving drawer open.")
