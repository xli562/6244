import math
import numpy as np


def run(api):
    counter = api.get_counter()
    initial_cup = api.get_cup()
    objects = api.get_objects()

    safe_z = max(
        counter["top_z"] + 0.17,
        initial_cup["pos"][2] + initial_cup["height"] / 2 + 0.12,
        max(
            (o["pos"][2] + o["size"][2] / 2 + 0.12 for o in objects),
            default=0.0,
        ),
    )

    def move(pos, yaw=None, speed=0.28):
        target = [float(v) for v in pos]
        result = api.move_to(target, yaw=yaw, speed=speed)
        if not result["reached"]:
            result = api.move_to(target, yaw=yaw, speed=0.12)
        return result["reached"]

    def rise():
        p = list(api.get_ee()["pos"])
        p[2] = safe_z
        return move(p)

    def approach(pos, yaw):
        if not rise():
            return False
        if not move([pos[0], pos[1], safe_z], yaw):
            return False
        return move(pos, yaw, 0.10)

    def operate_drawer(target):
        for attempt in range(3):
            drawer = api.get_drawer()
            opening = drawer["opening"]
            if abs(opening - target) < 0.012:
                return True

            api.open_gripper()
            h = list(api.get_handle()["pos"])
            h[1] += (0.0, -0.008, 0.008)[attempt]
            if not approach(h, 0.0):
                rise()
                continue
            width = api.close_gripper()
            if width < 0.004:
                api.open_gripper()
                rise()
                continue

            ee = list(api.get_ee()["pos"])
            # The slide moves toward -x when opening.
            ee[0] += opening - target
            if target == 0.0:
                ee[0] += 0.012
            move(ee, 0.0, 0.16)
            api.open_gripper()
            rise()

            after = api.get_drawer()["opening"]
            if target == 0.0 and after <= 0.012:
                return True
            if target > 0.0 and after >= target - 0.025:
                return True
        return False

    api.open_gripper()
    if not operate_drawer(0.45):
        api.log("Could not open drawer reliably.")
        return

    drawer = api.get_drawer()
    objects = api.get_objects()
    cup = api.get_cup()
    center = np.array(drawer["interior_center"], dtype=float)
    size = np.array(drawer["interior_size"], dtype=float)

    # Reserve space for the cup handle, fingers, and perception uncertainty.
    margin = cup["radius"] + 0.045
    xmin = center[0] - size[0] / 2 + margin
    xmax = min(
        center[0] + size[0] / 2 - margin,
        counter["front_x"] - margin,
    )
    ymin = center[1] - size[1] / 2 + margin
    ymax = center[1] + size[1] / 2 - margin

    if xmin >= xmax or ymin >= ymax:
        api.log("No accessible placement region.")
        return

    candidates = []
    for x in np.linspace(xmin, xmax, 19):
        for y in np.linspace(ymin, ymax, 21):
            clearance = min(
                x - (center[0] - size[0] / 2),
                center[0] + size[0] / 2 - x,
                y - (center[1] - size[1] / 2),
                center[1] + size[1] / 2 - y,
                counter["front_x"] - x,
            )
            valid = True
            for obj in objects:
                ox, oy, oz = obj["pos"]
                sx, sy, sz = obj["size"]
                # Account for every obstacle intersecting the descent column.
                if oz - sz / 2 > safe_z:
                    continue
                dx = max(abs(x - ox) - sx / 2, 0.0)
                dy = max(abs(y - oy) - sy / 2, 0.0)
                distance = math.hypot(dx, dy)
                if distance < margin:
                    valid = False
                    break
                clearance = min(clearance, distance)
            if valid:
                candidates.append((clearance, float(x), float(y)))

    if not candidates:
        api.log("No clear placement location.")
        return

    _, place_x, place_y = max(candidates)

    held = False
    grasp_offset = np.zeros(3)
    for attempt in range(5):
        cup = api.get_cup()
        p = np.array(cup["pos"], dtype=float)
        yaw = float(cup["yaw"])
        # Small offsets cover the narrow opening tolerance of the cup grasp.
        offsets = (0.0, -0.007, 0.007, -0.013, 0.013)
        closing_axis = np.array([-math.sin(yaw), math.cos(yaw), 0.0])
        target = p + offsets[attempt] * closing_axis
        api.open_gripper()
        if not approach(target, yaw):
            rise()
            continue
        width = api.close_gripper()
        if width < 0.015:
            api.open_gripper()
            rise()
            continue

        lift = list(api.get_ee()["pos"])
        lift[2] += 0.09
        move(lift, yaw, 0.12)
        lifted = api.get_cup()
        if lifted["pos"][2] > p[2] + 0.045:
            held = True
            grasp_offset = (
                np.array(lifted["pos"], dtype=float)
                - np.array(api.get_ee()["pos"], dtype=float)
            )
            cup = lifted
            break
        api.open_gripper()
        rise()

    if not held:
        api.log("Cup grasp could not be verified.")
        return

    if not rise():
        return

    # Translate the measured cup-to-fingertip offset into the release pose.
    desired_center = np.array([
        place_x,
        place_y,
        drawer["floor_z"] + cup["height"] / 2 + 0.012,
    ])
    release = desired_center - grasp_offset
    if not move([release[0], release[1], safe_z]):
        return
    if not move(release, speed=0.09):
        return

    api.open_gripper()
    api.wait(0.35)
    rise()

    placed = api.get_cup()
    current = api.get_drawer()
    pc = np.array(placed["pos"], dtype=float)
    dc = np.array(current["interior_center"], dtype=float)
    ds = np.array(current["interior_size"], dtype=float)
    inside = (
        abs(pc[0] - dc[0]) < ds[0] / 2 - placed["radius"]
        and abs(pc[1] - dc[1]) < ds[1] / 2 - placed["radius"]
        and abs(
            pc[2] - (current["floor_z"] + placed["height"] / 2)
        ) < 0.035
    )
    if inside:
        operate_drawer(0.0)
    else:
        api.log("Placement verification failed; leaving drawer open.")
