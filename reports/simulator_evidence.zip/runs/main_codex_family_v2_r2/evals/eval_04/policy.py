import math
import numpy as np


def run(api):
    counter = api.get_counter()
    objects = api.get_objects()
    transit_z = max(
        counter["top_z"] + 0.105,
        max((o["pos"][2] + o["size"][2] / 2 + 0.065
             for o in objects), default=0.0),
    )

    def move(pos, yaw=None, speed=0.25):
        p = [float(v) for v in pos]
        result = api.move_to(p, yaw=yaw, speed=speed)
        if not result["reached"] and result["error"] < 0.025:
            result = api.move_to(p, yaw=yaw, speed=0.10)
        return result["reached"]

    def rise():
        p = list(api.get_ee()["pos"])
        p[2] = transit_z
        return move(p)

    def approach(pos, yaw):
        rise()
        move([pos[0], pos[1], transit_z], yaw)
        return move(pos, yaw, 0.10)

    def operate_drawer(target):
        for attempt in range(3):
            opening = api.get_drawer()["opening"]
            if target > 0 and 0.275 <= opening <= 0.33:
                return True
            if target == 0 and opening <= 0.006:
                return True
            api.open_gripper()
            h = list(api.get_handle()["pos"])
            h[1] += (0.0, -0.007, 0.007)[attempt]
            if not approach(h, 0.0):
                rise()
                continue
            if api.close_gripper() < 0.004:
                api.open_gripper()
                rise()
                continue
            ee = list(api.get_ee()["pos"])
            ee[0] += opening - target
            if target == 0:
                ee[0] += 0.010
            move(ee, 0.0, 0.065 if target == 0 else 0.14)
            api.wait(0.2)
            api.open_gripper()
            rise()
            after = api.get_drawer()["opening"]
            if target > 0 and after >= 0.27:
                return True
            if target == 0 and after <= 0.010:
                return True
        return False

    api.open_gripper()
    if not operate_drawer(0.30):
        api.log("Drawer opening failed.")
        return

    drawer = api.get_drawer()
    objects = api.get_objects()
    cup = api.get_cup()
    center = np.array(drawer["interior_center"], dtype=float)
    size = np.array(drawer["interior_size"], dtype=float)
    margin = cup["radius"] + 0.040
    xmin = center[0] - size[0] / 2 + margin
    xmax = min(center[0] + size[0] / 2 - margin,
               counter["front_x"] - margin)
    ymin = center[1] - size[1] / 2 + margin
    ymax = center[1] + size[1] / 2 - margin
    if xmin >= xmax or ymin >= ymax:
        return

    candidates = []
    for x in np.linspace(xmin, xmax, 19):
        for y in np.linspace(ymin, ymax, 25):
            clearance = min(
                x - center[0] + size[0] / 2,
                center[0] + size[0] / 2 - x,
                y - center[1] + size[1] / 2,
                center[1] + size[1] / 2 - y,
                counter["front_x"] - x,
            )
            valid = True
            for obj in objects:
                ox, oy, oz = obj["pos"]
                sx, sy, sz = obj["size"]
                if oz - sz / 2 > transit_z:
                    continue
                distance = math.hypot(
                    max(abs(x - ox) - sx / 2, 0.0),
                    max(abs(y - oy) - sy / 2, 0.0),
                )
                if distance < margin:
                    valid = False
                    break
                clearance = min(clearance, distance)
            if valid:
                score = clearance - 0.035 * abs(y - center[1])
                candidates.append((score, float(x), float(y)))
    if not candidates:
        api.log("No clear placement location.")
        return
    _, place_x, place_y = max(candidates)

    held = False
    grasp_offset = np.zeros(3)
    for attempt in range(5):
        cup = api.get_cup()
        p = np.array(cup["pos"], dtype=float)
        # Parallel jaws have the same grasp geometry after a half turn.
        yaw = (float(cup["yaw"]) + math.pi / 2) % math.pi - math.pi / 2
        axis = np.array([-math.sin(yaw), math.cos(yaw), 0.0])
        target = p + (0.0, -0.007, 0.007, -0.013, 0.013)[attempt] * axis
        target[2] += 0.010
        api.open_gripper()
        if not approach(target, yaw):
            rise()
            continue
        width = api.close_gripper()
        if width < 0.015:
            api.open_gripper()
            rise()
            continue
        lift = list(api.get_ee()["pos"])
        lift[2] = max(lift[2] + 0.065, transit_z)
        move(lift, yaw, 0.10)
        lifted = api.get_cup()
        if lifted["pos"][2] > p[2] + 0.040:
            held = True
            grasp_offset = (np.array(lifted["pos"], dtype=float)
                            - np.array(api.get_ee()["pos"], dtype=float))
            cup_z_bias = p[2] - (counter["top_z"] + cup["height"] / 2)
            grasp_offset[2] -= cup_z_bias
            cup = lifted
            break
        api.open_gripper()
        rise()
    if not held:
        api.log("Cup grasp could not be verified.")
        return

    rise()
    release = np.array([
        place_x, place_y,
        drawer["floor_z"] + cup["height"] / 2 + 0.004,
    ]) - grasp_offset
    if not move([release[0], release[1], transit_z], speed=0.18):
        return
    if not move([release[0], release[1], release[2] + 0.040], speed=0.10):
        return
    move(release, speed=0.035)
    api.wait(0.25)
    api.open_gripper()
    api.wait(0.5)
    rise()

    placed = api.get_cup()
    current = api.get_drawer()
    pc = np.array(placed["pos"], dtype=float)
    dc = np.array(current["interior_center"], dtype=float)
    ds = np.array(current["interior_size"], dtype=float)
    inside = (
        abs(pc[0] - dc[0]) < ds[0] / 2 - placed["radius"]
        and abs(pc[1] - dc[1]) < ds[1] / 2 - placed["radius"]
        and abs(pc[2] - current["floor_z"] - placed["height"] / 2) < 0.035
    )
    if inside:
        operate_drawer(0.0)
    else:
        api.log("Placement verification failed.")
