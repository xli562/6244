import math
import numpy as np


def run(api):
    def v(p):
        return np.asarray(p, dtype=float)

    def read(fn, n=5):
        samples = [fn() for _ in range(n)]
        result = dict(samples[-1])
        for key in result:
            if isinstance(result[key], (int, float, list)):
                result[key] = np.mean(
                    [s[key] for s in samples], axis=0
                ).tolist()
        return result

    def ee():
        return v(api.get_ee()["pos"])

    def move(p, yaw=None, speed=0.24):
        p = v(p)
        result = api.move_to(p.tolist(), yaw=yaw, speed=speed)
        if result["error"] > 0.025:
            result = api.move_to(p.tolist(), yaw=yaw, speed=0.12)
        return result["error"] < 0.035

    counter = read(api.get_counter)
    cup = read(api.get_cup)
    objects = api.get_objects()
    safe_z = max(
        counter["top_z"] + 0.135,
        cup["pos"][2] + 0.105,
    )
    for obj in objects:
        safe_z = max(
            safe_z,
            obj["pos"][2] + obj["size"][2] / 2 + 0.105,
        )

    def rise():
        p = ee().copy()
        p[2] = max(safe_z, p[2])
        move(p, speed=0.30)

    def approach_handle(shift, dz):
        rise()
        api.open_gripper()
        h = v(read(api.get_handle)["pos"])
        h[0] += shift
        h[2] += dz
        p = h.copy()
        p[0] -= 0.045
        p[2] = safe_z
        move(p, yaw=0.0, speed=0.30)
        p[2] = h[2]
        move(p, yaw=0.0, speed=0.18)
        move(h, yaw=0.0, speed=0.10)
        width = api.close_gripper()
        api.log("Handle width %.4f" % width)
        return width > 0.003

    def leave_handle():
        api.open_gripper()
        p = ee().copy()
        p[0] -= 0.035
        move(p, speed=0.20)
        rise()

    drawer = read(api.get_drawer)
    for shift, dz in (
        (0.012, 0.0),
        (0.012, 0.038),
        (0.0, 0.020),
        (0.025, 0.0),
    ):
        if drawer["opening"] >= 0.30:
            break
        if approach_handle(shift, dz):
            p = ee().copy()
            p[0] -= max(0.0, 0.345 - drawer["opening"])
            move(p, yaw=0.0, speed=0.10)
        leave_handle()
        drawer = read(api.get_drawer)
        api.log("Opening %.3f" % drawer["opening"])

    if drawer["opening"] < 0.25:
        api.log("Unable to expose drawer.")
        return

    cup = read(api.get_cup)
    objects = api.get_objects()
    center = v(drawer["interior_center"])
    size = v(drawer["interior_size"])
    handle_y = read(api.get_handle)["pos"][1]

    # Reserve room for the handle, open fingers, and perception error.
    footprint = max(cup["radius"] + 0.036, 0.069)
    xmin = center[0] - size[0] / 2 + footprint + 0.020
    xmax = min(
        center[0] + size[0] / 2 - footprint - 0.020,
        counter["front_x"] - footprint - 0.026,
    )
    ymin = center[1] - size[1] / 2 + footprint + 0.020
    ymax = center[1] + size[1] / 2 - footprint - 0.020

    best = None
    best_score = -float("inf")
    if xmin <= xmax and ymin <= ymax:
        for x in np.linspace(xmin, xmax, 25):
            for y in np.linspace(ymin, ymax, 35):
                wall_clearance = min(
                    x - (center[0] - size[0] / 2),
                    center[0] + size[0] / 2 - x,
                    y - (center[1] - size[1] / 2),
                    center[1] + size[1] / 2 - y,
                    counter["front_x"] - x - 0.01,
                ) - footprint

                object_clearance = float("inf")
                for obj in objects:
                    p, s = v(obj["pos"]), v(obj["size"])
                    dx = max(abs(x - p[0]) - s[0] / 2, 0.0)
                    dy = max(abs(y - p[1]) - s[1] / 2, 0.0)
                    object_clearance = min(
                        object_clearance,
                        math.hypot(dx, dy) - footprint,
                    )

                if wall_clearance < 0.020 or object_clearance < 0.045:
                    continue

                clearance = min(
                    wall_clearance,
                    object_clearance - 0.025,
                )
                separation = abs(y - handle_y)
                score = clearance
                if separation >= 0.125:
                    score += 0.15
                if score > best_score:
                    best_score = score
                    best = np.array([x, y])

    if best is None:
        api.log("No free placement area.")
        return
    api.log("Placement %.3f %.3f" % (best[0], best[1]))

    held = False
    for shift in (0.0, -0.010, 0.010):
        cup = read(api.get_cup)
        cp = v(cup["pos"])
        yaw = float(cup["yaw"])
        rise()
        api.open_gripper()
        grasp = cp.copy()
        grasp[0] += shift
        grasp[2] += 0.007
        p = grasp.copy()
        p[2] = safe_z
        move(p, yaw=yaw, speed=0.28)
        move(grasp, yaw=yaw, speed=0.10)
        width = api.close_gripper()
        api.log("Cup width %.4f" % width)
        if width < 0.015:
            api.open_gripper()
            continue

        p = ee().copy()
        p[2] = safe_z
        move(p, yaw=yaw, speed=0.16)
        observed = v(read(api.get_cup)["pos"])
        if observed[2] > cp[2] + 0.055:
            held = True
            break
        api.open_gripper()

    if not held:
        api.log("Grasp failed.")
        return

    offset = v(read(api.get_cup)["pos"]) - ee()
    target = np.array([
        best[0],
        best[1],
        drawer["floor_z"] + cup["height"] / 2 + 0.015,
    ]) - offset

    above = target.copy()
    above[2] = safe_z
    move(above, yaw=yaw)
    move(target, yaw=yaw, speed=0.08)
    api.log("Releasing cup.")
    api.open_gripper()
    api.wait(0.5)
    rise()

    for shift, dz in (
        (0.012, 0.038),
        (0.025, 0.038),
        (0.0, 0.050),
    ):
        drawer = read(api.get_drawer)
        api.log("Closing from %.3f" % drawer["opening"])
        if drawer["opening"] < 0.005:
            break
        approach_handle(shift, dz)
        p = ee().copy()
        p[0] += drawer["opening"] + 0.035
        move(p, yaw=0.0, speed=0.10)
        api.open_gripper()
        p = ee().copy()
        p[0] -= 0.045
        move(p, yaw=0.0, speed=0.20)
        rise()

    api.log(
        "Final opening %.3f" % read(api.get_drawer)["opening"]
    )
