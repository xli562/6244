import math
import numpy as np


def run(api):
    def v(p):
        return np.asarray(p, dtype=float)

    def read(fn, n=5):
        samples = [fn() for _ in range(n)]
        result = dict(samples[-1])
        for key in result:
            if isinstance(result[key], (int, float, list)):
                result[key] = np.mean([s[key] for s in samples], axis=0).tolist()
        return result

    def ee():
        return v(api.get_ee()["pos"])

    def move(p, yaw=None, speed=0.24):
        p = v(p)
        result = api.move_to(p.tolist(), yaw=yaw, speed=speed)
        if result["error"] > 0.025:
            result = api.move_to(p.tolist(), yaw=yaw, speed=0.12)
        return result["error"] < 0.035

    counter = read(api.get_counter)
    cup = read(api.get_cup)
    objects = api.get_objects()
    safe_z = max(counter["top_z"] + 0.135, cup["pos"][2] + 0.105)
    for obj in objects:
        safe_z = max(safe_z, obj["pos"][2] + obj["size"][2] / 2 + 0.105)

    def rise():
        p = ee().copy()
        p[2] = max(safe_z, p[2])
        move(p, speed=0.30)

    def approach_handle(shift):
        rise()
        api.open_gripper()
        h = v(read(api.get_handle)["pos"])
        h[0] += shift
        h[2] += 0.038
        p = h.copy()
        p[0] -= 0.045
        p[2] = safe_z
        move(p, yaw=0.0, speed=0.30)
        p[2] = h[2]
        move(p, yaw=0.0, speed=0.18)
        move(h, yaw=0.0, speed=0.10)
        width = api.close_gripper()
        api.log("Handle width %.4f" % width)
        return width > 0.003

    def leave_handle():
        api.open_gripper()
        p = ee().copy()
        p[0] -= 0.035
        move(p, speed=0.20)
        rise()

    drawer = read(api.get_drawer)
    for shift in (0.012, 0.025, -0.008):
        if drawer["opening"] >= 0.29:
            break
        if approach_handle(shift):
            p = ee().copy()
            p[0] -= max(0.0, 0.335 - drawer["opening"])
            move(p, yaw=0.0, speed=0.10)
        leave_handle()
        drawer = read(api.get_drawer)
        api.log("Opening %.3f" % drawer["opening"])

    if drawer["opening"] < 0.24:
        api.log("Unable to expose drawer.")
        return

    cup = read(api.get_cup)
    objects = api.get_objects()
    center = v(drawer["interior_center"])
    size = v(drawer["interior_size"])
    footprint = max(cup["radius"] + 0.025, 0.058)
    xmin = center[0] - size[0] / 2 + footprint + 0.017
    xmax = min(center[0] + size[0] / 2 - footprint - 0.017,
               counter["front_x"] - footprint - 0.023)
    ymin = center[1] - size[1] / 2 + footprint + 0.017
    ymax = center[1] + size[1] / 2 - footprint - 0.017
    best = None
    best_score = -1.0
    if xmin <= xmax and ymin <= ymax:
        for x in np.linspace(xmin, xmax, 25):
            for y in np.linspace(ymin, ymax, 29):
                clearance = min(
                    x - (center[0] - size[0] / 2),
                    center[0] + size[0] / 2 - x,
                    y - (center[1] - size[1] / 2),
                    center[1] + size[1] / 2 - y,
                    counter["front_x"] - x - 0.01,
                ) - footprint
                for obj in objects:
                    p, s = v(obj["pos"]), v(obj["size"])
                    dx = max(abs(x - p[0]) - s[0] / 2, 0.0)
                    dy = max(abs(y - p[1]) - s[1] / 2, 0.0)
                    clearance = min(clearance, math.hypot(dx, dy) - footprint)
                score = clearance - 0.025 * abs(y - center[1])
                if clearance >= 0.017 and score > best_score:
                    best_score = score
                    best = np.array([x, y])
    if best is None:
        api.log("No free placement area.")
        return

    held = False
    for shift in (0.0, -0.010, 0.010):
        cup = read(api.get_cup)
        cp = v(cup["pos"])
        yaw = float(cup["yaw"])
        rise()
        api.open_gripper()
        grasp = cp.copy()
        grasp[0] += shift
        grasp[2] += 0.007
        p = grasp.copy()
        p[2] = safe_z
        move(p, yaw=yaw, speed=0.28)
        move(grasp, yaw=yaw, speed=0.10)
        width = api.close_gripper()
        api.log("Cup width %.4f" % width)
        if width < 0.015:
            api.open_gripper()
            continue
        p = ee().copy()
        p[2] = safe_z
        move(p, yaw=yaw, speed=0.16)
        observed = v(read(api.get_cup)["pos"])
        if observed[2] > cp[2] + 0.055:
            held = True
            break
        api.open_gripper()
    if not held:
        api.log("Grasp failed.")
        return

    offset = v(read(api.get_cup)["pos"]) - ee()
    target = np.array([
        best[0], best[1],
        drawer["floor_z"] + cup["height"] / 2 + 0.025,
    ]) - offset
    above = target.copy()
    above[2] = safe_z
    move(above, yaw=yaw)
    move(target, yaw=yaw, speed=0.10)
    api.log("Releasing cup.")
    api.open_gripper()
    api.wait(0.4)
    rise()

    for shift in (0.012, 0.025, -0.008):
        drawer = read(api.get_drawer)
        api.log("Closing from %.3f" % drawer["opening"])
        if drawer["opening"] < 0.008:
            break
        grasped = approach_handle(shift)
        p = ee().copy()
        p[0] += drawer["opening"] + 0.020
        move(p, yaw=0.0, speed=0.10)
        leave_handle()

    api.log("Final opening %.3f" % read(api.get_drawer)["opening"])
