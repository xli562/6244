import math
import numpy as np


def run(api):
    margin = 0.018

    def vec(p):
        return np.asarray(p, dtype=float)

    def move(p, yaw=None, speed=0.25):
        result = api.move_to(
            [float(v) for v in p], yaw=yaw, speed=speed
        )
        if not result["reached"]:
            result = api.move_to(
                [float(v) for v in p], yaw=yaw, speed=0.12
            )
        return bool(result["reached"])

    def ee():
        return vec(api.get_ee()["pos"])

    counter = api.get_counter()
    objects = api.get_objects()
    cup = api.get_cup()
    top = float(counter["top_z"])
    front = float(counter["front_x"])
    safe_z = max(top + 0.19, float(cup["pos"][2]) + 0.15)
    for obj in objects:
        p, s = vec(obj["pos"]), vec(obj["size"])
        safe_z = max(safe_z, p[2] + s[2] / 2 + 0.14)

    def rise():
        p = ee()
        p[2] = max(p[2], safe_z)
        return move(p)

    def approach_handle():
        if not rise():
            return False
        h = vec(api.get_handle()["pos"])
        approach = h.copy()
        approach[0] -= 0.065
        above = approach.copy()
        above[2] = safe_z
        api.open_gripper()
        if not move(above, yaw=0.0):
            return False
        if not move(approach, yaw=0.0, speed=0.18):
            return False
        return move(h, yaw=0.0, speed=0.10)

    def release_handle():
        api.open_gripper()
        p = ee()
        p[0] -= 0.055
        move(p, speed=0.15)
        return rise()

    # Expose enough drawer floor to lower the cup vertically.
    desired_opening = 0.43
    drawer = api.get_drawer()
    for attempt in range(3):
        opening = float(drawer["opening"])
        if opening >= desired_opening - 0.018:
            break
        if not approach_handle():
            api.log("Could not approach the drawer handle.")
            return
        width = api.close_gripper()
        if width < 0.004:
            release_handle()
            drawer = api.get_drawer()
            continue
        p = ee()
        p[0] -= max(0.0, desired_opening - opening)
        move(p, yaw=0.0, speed=0.18)
        release_handle()
        drawer = api.get_drawer()

    drawer = api.get_drawer()
    if float(drawer["opening"]) < 0.30:
        api.log("Drawer did not open sufficiently.")
        return

    # Select a free footprint, including space for the cup handle.
    cup = api.get_cup()
    objects = api.get_objects()
    center = vec(drawer["interior_center"])
    size = vec(drawer["interior_size"])
    radius = float(cup["radius"])
    height = float(cup["height"])
    footprint = max(radius + 0.033, 0.067)
    edge = footprint + margin
    xmin = center[0] - size[0] / 2 + edge
    xmax = min(
        center[0] + size[0] / 2 - edge,
        front - footprint - 0.035,
    )
    ymin = center[1] - size[1] / 2 + edge
    ymax = center[1] + size[1] / 2 - edge

    if xmin > xmax or ymin > ymax:
        api.log("No exposed placement area.")
        return

    best = None
    best_score = -float("inf")
    for x in np.linspace(xmin, xmax, 23):
        for y in np.linspace(ymin, ymax, 25):
            clearance = min(
                x - (center[0] - size[0] / 2),
                center[0] + size[0] / 2 - x,
                y - (center[1] - size[1] / 2),
                center[1] + size[1] / 2 - y,
                front - x - 0.015,
            ) - footprint
            for obj in objects:
                p, s = vec(obj["pos"]), vec(obj["size"])
                dx = max(abs(x - p[0]) - s[0] / 2, 0.0)
                dy = max(abs(y - p[1]) - s[1] / 2, 0.0)
                distance = math.hypot(dx, dy) - footprint
                clearance = min(clearance, distance)
            if clearance < margin:
                continue
            score = clearance - 0.035 * abs(x - (xmin + xmax) / 2)
            if score > best_score:
                best_score = score
                best = np.array([x, y], dtype=float)

    if best is None:
        api.log("No sufficiently clear cup placement found.")
        return

    # Close perpendicular to the direction of the cup handle.
    held = False
    for attempt in range(3):
        cup = api.get_cup()
        cp = vec(cup["pos"])
        yaw = float(cup["yaw"])
        api.open_gripper()
        if not rise():
            return
        above = np.array([cp[0], cp[1], safe_z])
        if not move(above, yaw=yaw):
            return
        grasp = cp.copy()
        grasp[2] += 0.006
        if not move(grasp, yaw=yaw, speed=0.10):
            rise()
            continue
        width = api.close_gripper()
        if width < 0.015:
            api.open_gripper()
            rise()
            continue
        lift = ee()
        lift[2] = safe_z
        if not move(lift, yaw=yaw, speed=0.18):
            return
        observed = vec(api.get_cup()["pos"])
        if observed[2] > cp[2] + 0.065:
            held = True
            break
        api.open_gripper()

    if not held:
        api.log("Cup grasp could not be verified.")
        return

    # Use the observed cup-to-fingertip offset to place the cup upright.
    offset = vec(api.get_cup()["pos"]) - ee()
    target_center = np.array([
        best[0],
        best[1],
        float(drawer["floor_z"]) + height / 2 + 0.010,
    ])
    target_ee = target_center - offset
    above = target_ee.copy()
    above[2] = max(safe_z, target_ee[2])
    if not move(above, yaw=yaw, speed=0.20):
        return
    if not move(target_ee, yaw=yaw, speed=0.09):
        api.log("Placement descent could not be completed.")
        return
    api.open_gripper()
    api.wait(0.3)
    if not rise():
        return

    # Check release before moving the drawer.
    placed = vec(api.get_cup()["pos"])
    if (np.linalg.norm(placed[:2] - best) > 0.065
            or placed[2] > float(drawer["floor_z"]) + height + 0.035):
        api.log("Cup placement could not be verified.")
        return

    for attempt in range(3):
        drawer = api.get_drawer()
        opening = float(drawer["opening"])
        if opening <= 0.008:
            break
        if not approach_handle():
            return
        width = api.close_gripper()
        if width < 0.004:
            release_handle()
            continue
        p = ee()
        p[0] += opening + 0.012
        move(p, yaw=0.0, speed=0.14)
        release_handle()

    api.open_gripper()
    api.log("Finished cup placement and drawer closure.")
