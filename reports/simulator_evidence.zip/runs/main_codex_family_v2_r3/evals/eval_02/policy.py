import math
import numpy as np


def run(api):
    def v(p):
        return np.array(p, dtype=float)

    def read(fn, n=5):
        samples = [fn() for _ in range(n)]
        result = dict(samples[-1])
        for key in result:
            if isinstance(result[key], (int, float, list)):
                result[key] = np.mean(
                    [s[key] for s in samples], axis=0
                ).tolist()
        return result

    def move(p, yaw=None, speed=0.25):
        r = api.move_to([float(x) for x in p], yaw=yaw, speed=speed)
        if not r["reached"]:
            r = api.move_to([float(x) for x in p], yaw=yaw, speed=0.12)
        return r["reached"]

    def ee():
        return v(api.get_ee()["pos"])

    counter = read(api.get_counter)
    cup = read(api.get_cup)
    objects = api.get_objects()
    safe_z = max(float(counter["top_z"]) + 0.17, cup["pos"][2] + 0.13)
    for o in objects:
        safe_z = max(safe_z, o["pos"][2] + o["size"][2] / 2 + 0.12)

    def rise():
        p = ee()
        p[2] = max(p[2], safe_z)
        return move(p, speed=0.30)

    def handle_grasp(offset=0.0):
        rise()
        h = v(read(api.get_handle)["pos"])
        h[0] += offset
        api.open_gripper()
        p = h.copy()
        p[0] -= 0.055
        p[2] = safe_z
        if not move(p, yaw=0.0, speed=0.30):
            return False
        p[2] = h[2]
        if not move(p, yaw=0.0):
            return False
        if not move(h, yaw=0.0, speed=0.10):
            return False
        move(h, yaw=0.0, speed=0.08)
        width = api.close_gripper()
        api.log("Handle grasp width: %.4f" % width)
        return width > 0.003

    def leave_handle():
        api.open_gripper()
        p = ee()
        p[0] -= 0.045
        move(p)
        rise()

    drawer = read(api.get_drawer)
    for shift in (0.012, 0.025, -0.008, 0.038):
        if drawer["opening"] >= 0.32:
            break
        if handle_grasp(shift):
            p = ee()
            p[0] -= max(0.0, 0.39 - drawer["opening"])
            move(p, yaw=0.0, speed=0.10)
        leave_handle()
        drawer = read(api.get_drawer)
        api.log("Drawer opening: %.3f" % drawer["opening"])

    if drawer["opening"] < 0.26:
        api.log("Drawer opening insufficient.")
        return

    cup = read(api.get_cup)
    objects = api.get_objects()
    c, s = v(drawer["interior_center"]), v(drawer["interior_size"])
    r, height = cup["radius"], cup["height"]
    footprint = max(r + 0.025, 0.058)
    clearance_margin = 0.018
    xmin = c[0] - s[0] / 2 + footprint + clearance_margin
    xmax = min(c[0] + s[0] / 2 - footprint - clearance_margin,
               counter["front_x"] - footprint - 0.025)
    ymin = c[1] - s[1] / 2 + footprint + clearance_margin
    ymax = c[1] + s[1] / 2 - footprint - clearance_margin
    best, score_best = None, -1.0
    if xmin <= xmax and ymin <= ymax:
        for x in np.linspace(xmin, xmax, 25):
            for y in np.linspace(ymin, ymax, 29):
                clearance = min(
                    x - (c[0] - s[0] / 2),
                    c[0] + s[0] / 2 - x,
                    y - (c[1] - s[1] / 2),
                    c[1] + s[1] / 2 - y,
                    counter["front_x"] - x - 0.01,
                ) - footprint
                for obj in objects:
                    p, size = v(obj["pos"]), v(obj["size"])
                    dx = max(abs(x - p[0]) - size[0] / 2, 0.0)
                    dy = max(abs(y - p[1]) - size[1] / 2, 0.0)
                    clearance = min(clearance, math.hypot(dx, dy) - footprint)
                if clearance >= clearance_margin and clearance > score_best:
                    best = np.array([x, y])
                    score_best = clearance
    if best is None:
        api.log("No free placement footprint.")
        return
    api.log("Placement selected: %.3f %.3f" % tuple(best))

    held = False
    for shift in (0.0, 0.012, -0.012):
        cup = read(api.get_cup)
        cp = v(cup["pos"])
        yaw = float(cup["yaw"])
        rise()
        api.open_gripper()
        grasp = cp.copy()
        grasp[0] += shift
        grasp[2] += 0.003
        p = grasp.copy()
        p[2] = safe_z
        if not move(p, yaw=yaw, speed=0.30):
            return
        if not move(grasp, yaw=yaw, speed=0.10):
            continue
        move(grasp, yaw=yaw, speed=0.08)
        width = api.close_gripper()
        api.log("Cup grasp width: %.4f" % width)
        if width < 0.015:
            api.open_gripper()
            continue
        p = ee()
        p[2] = safe_z
        move(p, yaw=yaw, speed=0.16)
        observed = v(read(api.get_cup)["pos"])
        if observed[2] > cp[2] + 0.06:
            held = True
            break
        api.open_gripper()
    if not held:
        api.log("Cup was not lifted.")
        return

    offset = v(read(api.get_cup)["pos"]) - ee()
    target = np.array([
        best[0], best[1],
        drawer["floor_z"] + height / 2 + 0.008,
    ]) - offset
    p = target.copy()
    p[2] = safe_z
    if not move(p, yaw=yaw):
        return
    if not move(target, yaw=yaw, speed=0.08):
        return
    api.open_gripper()
    api.wait(0.25)
    rise()
    api.log("Cup released inside drawer.")

    for shift in (0.012, 0.025, -0.008):
        drawer = read(api.get_drawer)
        if drawer["opening"] <= 0.007:
            break
        if handle_grasp(shift):
            p = ee()
            p[0] += drawer["opening"] + 0.015
            move(p, yaw=0.0, speed=0.12)
        leave_handle()
    api.log("Final drawer opening: %.3f" % read(api.get_drawer)["opening"])
