"""Robot program for: "Place the cup in the drawer." See TASK.md and API.md."""
import math

import numpy as np

# ---------------------------------------------------------------- constants
GRIP_OPEN = 0.08
CUP_GRIP_ABOVE_BOTTOM = 0.025   # fingertip height above cup bottom when grasping
FINGER_HALF_Y = 0.056           # half span of open fingers along closing axis
HAND_HALF_Y = 0.112             # half span of hand body along closing axis
HAND_HALF_X = 0.036             # half depth of hand / fingers across closing axis
PALM_ABOVE_TIP = 0.045          # lowest point of hand body above fingertips (conservative)
CUP_HANDLE_LEN = 0.028          # how far the cup handle sticks out of the body
SLOW = 0.06
MED = 0.10
FAST = 0.2


def wrap(a):
    return (a + math.pi) % (2 * math.pi) - math.pi


def avg_reading(fn, key, n=5):
    vals = [np.array(fn()[key], dtype=float) for _ in range(n)]
    return np.mean(vals, axis=0), np.std(vals, axis=0)


def rect_sep(c1, h1, c2, h2):
    """Separation between two axis-aligned rectangles (positive = apart)."""
    dx = abs(c1[0] - c2[0]) - (h1[0] + h2[0])
    dy = abs(c1[1] - c2[1]) - (h1[1] + h2[1])
    return max(dx, dy)


class Robot:
    def __init__(self, api):
        self.api = api

    def log(self, m):
        try:
            self.api.log(str(m))
        except Exception:
            pass

    def ee(self):
        e = self.api.get_ee()
        return np.array(e["pos"], dtype=float), e["yaw"], e["gripper_width"]

    def move(self, p, yaw=None, speed=FAST, tag=""):
        p = [float(v) for v in p]
        r = self.api.move_to(p, yaw=yaw, speed=speed)
        if not r.get("reached", True):
            pe, _, _ = self.ee()
            self.log("move %s not reached: target %s ee %s err %.4f"
                     % (tag, np.round(p, 4).tolist(), np.round(pe, 4).tolist(), r.get("error", -1)))
        return r

    def path(self, pts, yaw=None, speed=FAST, tag=""):
        r = None
        for p in pts:
            r = self.move(p, yaw=yaw, speed=speed, tag=tag)
        return r


# ---------------------------------------------------------------- perception
def read_scene(R):
    api = R.api
    counter = api.get_counter()
    top_z = float(counter["top_z"])
    front_x = float(counter["front_x"])
    dr = api.get_drawer()
    objs = api.get_objects()
    return top_z, front_x, dr, objs


def read_cup(R, n=3):
    cups = [R.api.get_cup() for _ in range(n)]
    pos = np.mean([c["pos"] for c in cups], axis=0)
    s = np.mean([math.sin(2 * c["yaw"]) for c in cups])
    co = np.mean([math.cos(2 * c["yaw"]) for c in cups])
    # yaw of the handle: average directly (handle direction matters, not mod pi)
    sy = np.mean([math.sin(c["yaw"]) for c in cups])
    cy = np.mean([math.cos(c["yaw"]) for c in cups])
    yaw = math.atan2(sy, cy)
    radius = float(np.mean([c["radius"] for c in cups]))
    height = float(np.mean([c["height"] for c in cups]))
    R.log("cup pos %s std %s yaw %.3f radius %.4f height %.4f"
          % (np.round(pos, 4).tolist(), np.round(np.std([c["pos"] for c in cups], axis=0), 4).tolist(),
             yaw, radius, height))
    return pos, yaw, radius, height


def read_handle(R, n=5):
    p, s = avg_reading(R.api.get_handle, "pos", n)
    R.log("handle %s std %s" % (np.round(p, 4).tolist(), np.round(s, 4).tolist()))
    return p


def read_drawer(R, n=3):
    drs = [R.api.get_drawer() for _ in range(n)]
    d = {
        "opening": float(np.mean([x["opening"] for x in drs])),
        "interior_center": np.mean([x["interior_center"] for x in drs], axis=0),
        "interior_size": np.mean([x["interior_size"] for x in drs], axis=0),
        "floor_z": float(np.mean([x["floor_z"] for x in drs])),
    }
    R.log("drawer opening %.4f center %s size %s floor %.4f"
          % (d["opening"], np.round(d["interior_center"], 4).tolist(),
             np.round(d["interior_size"], 4).tolist(), d["floor_z"]))
    return d


# ---------------------------------------------------------------- placement
def plan_place(drawer, objs, front_x, opening, handle_dir_x, R=None):
    """Find a cup placement (x, y) in the drawer when it is opened to `opening`.

    Returns (score, x, y). Coordinates are world coordinates at that opening.
    handle_dir_x: +1 if the cup handle will point +x, -1 if -x.
    """
    c = np.array(drawer["interior_center"], dtype=float)
    size = np.array(drawer["interior_size"], dtype=float)
    shift = opening - drawer["opening"]
    cx = c[0] - shift
    cy = c[1]
    ix_min, ix_max = cx - size[0] / 2, cx + size[0] / 2
    iy_min, iy_max = cy - size[1] / 2, cy + size[1] / 2
    floor_z = drawer["floor_z"]
    wall_top = floor_z + max(size[2], 0.06)
    tip_z = floor_z + CUP_GRIP_ABOVE_BOTTOM
    palm_z = tip_z + PALM_ABOVE_TIP

    # cup footprint extents in x (asymmetric due to handle)
    r = 0.032
    ext_minus = r + (CUP_HANDLE_LEN if handle_dir_x < 0 else 0.0)
    ext_plus = r + (CUP_HANDLE_LEN if handle_dir_x > 0 else 0.0)

    dobjs = []
    for o in objs:
        if o.get("location") != "drawer":
            continue
        p = np.array(o["pos"], dtype=float)
        s = np.array(o["size"], dtype=float)
        dobjs.append((np.array([p[0] - shift, p[1]]), s[:2] / 2, p[2] + s[2] / 2))

    best = (-1e9, None, None, -1e9)
    xs = np.arange(ix_min + 0.03, front_x, 0.005)
    ys = np.arange(iy_min + 0.04, iy_max - 0.04 + 1e-9, 0.005)
    x_pref = 0.5 * (ix_min + front_x)
    for x in xs:
        for y in ys:
            sl = []
            sl.append((x - ext_minus) - ix_min)                # front panel
            sl.append((x - HAND_HALF_X) - ix_min)              # hand vs front panel
            sl.append(ix_max - (x + ext_plus))                 # back wall
            sl.append(front_x - (x + HAND_HALF_X))             # hand vs counter front
            sl.append((y - FINGER_HALF_Y) - iy_min)
            sl.append(iy_max - (y + FINGER_HALF_Y))
            sl.append((y - r) - iy_min)
            sl.append(iy_max - (y + r))
            if palm_z < wall_top + 0.01:
                sl.append(0.5 * ((y - HAND_HALF_Y) - iy_min) + 0.005)
                sl.append(0.5 * (iy_max - (y + HAND_HALF_Y)) + 0.005)
            cxc = x + 0.5 * (ext_plus - ext_minus)
            hx = 0.5 * (ext_plus + ext_minus)
            for (op, oh, otop) in dobjs:
                sl.append(rect_sep((cxc, y), (hx, r), op, oh))
                sl.append(rect_sep((x, y), (0.012, FINGER_HALF_Y), op, oh))
                if otop > palm_z - 0.01:
                    sl.append(rect_sep((x, y), (HAND_HALF_X, HAND_HALF_Y), op, oh))
            slack = min(sl)
            score = min(slack, 0.035) - 0.05 * abs(x - x_pref) - 0.03 * abs(y - cy)
            if score > best[0]:
                best = (score, float(x), float(y), slack)
    return best


# ---------------------------------------------------------------- drawer motions
def grasp_handle(R, top_z, front_x, tries=2):
    for k in range(tries):
        x, y, z, d = handle_estimate(R, front_x)
        gz = z + 0.015
        safe_z = max(top_z + 0.09, gz + 0.12)
        R.api.open_gripper()
        pe, _, _ = R.ee()
        R.move([pe[0], pe[1], max(pe[2], safe_z)], yaw=0.0, speed=FAST, tag="lift")
        R.move([x, y, safe_z], yaw=0.0, speed=FAST, tag="above handle")
        R.move([x, y, gz + 0.04], yaw=0.0, speed=MED, tag="pre handle")
        R.move([x, y, gz], yaw=0.0, speed=SLOW, tag="handle")
        # The handle reading can be off by a couple of cm: search along x at
        # grasp height (the open fingers straddle the bar in y, so sliding in x
        # cannot hit it). Search toward the robot first (away from the panel).
        for dx in [0.0, -0.014, 0.014, -0.028, 0.028]:
            if dx != 0.0:
                pe, _, _ = R.ee()
                R.move([x + dx, y, pe[2]], yaw=0.0, speed=SLOW, tag="handle search")
            w = R.api.close_gripper()
            if 0.005 < w < 0.04:
                R.log("handle grasped at dx %.3f width %.4f" % (dx, w))
                return True, d
            R.api.open_gripper()
        R.log("handle grasp failed (try %d)" % k)
        pe, _, _ = R.ee()
        R.move([pe[0], pe[1], safe_z], speed=MED, tag="retreat")
    return False, d


def handle_estimate(R, front_x, n=3):
    """Fuse the handle reading with the handle position implied by the drawer
    interior and by the counter front + opening (median of three)."""
    h, _ = avg_reading(R.api.get_handle, "pos", n)
    d = read_drawer(R, n)
    c = d["interior_center"]
    s = d["interior_size"]
    e1 = h[0]
    e2 = c[0] - s[0] / 2 - 0.057
    e3 = front_x - 0.041 - d["opening"]
    x = float(np.median([e1, e2, e3]))
    y = float(0.5 * (h[1] + c[1])) if abs(h[1] - c[1]) < 0.03 else float(h[1])
    z = float(h[2])
    R.log("handle est x %.4f (h %.4f, drawer %.4f, front %.4f) y %.4f z %.4f"
          % (x, e1, e2, e3, y, z))
    return x, y, z, d


def release_up(R, dz=0.10, speed=MED):
    R.api.open_gripper()
    pe, _, _ = R.ee()
    R.move([pe[0], pe[1], pe[2] + dz], speed=speed, tag="release up")


def set_opening(R, target, top_z, front_x):
    """Grasp the handle and slide the drawer to the target opening."""
    d = read_drawer(R, 3)
    for attempt in range(3):
        cur = d["opening"]
        if cur > target - 0.02:
            return d
        ok, d = grasp_handle(R, top_z, front_x)
        if not ok:
            d = read_drawer(R, 3)
            continue
        cur = d["opening"]
        pe, _, _ = R.ee()
        tx = pe[0] - (target - cur)
        R.move([tx, pe[1], pe[2]], speed=0.08, tag="slide drawer")
        release_up(R, 0.10)
        d = read_drawer(R, 3)
    return d


def close_drawer(R, top_z, front_x):
    """Push the drawer shut with the closed fingers against the upper part of
    the handle bar; the hand stays above the counter top."""
    for attempt in range(3):
        x, y, z, d = handle_estimate(R, front_x)
        if d["opening"] < 0.006:
            return d
        pz = min(max(z + 0.045, top_z - 0.035), z + 0.06)
        safe_z = max(top_z + 0.09, pz + 0.12)
        sx = x - 0.05
        pe, _, _ = R.ee()
        R.move([pe[0], pe[1], max(pe[2], safe_z)], speed=FAST, tag="lift")
        R.api.close_gripper()
        R.move([sx, y, safe_z], yaw=0.0, speed=FAST, tag="above push")
        R.move([sx, y, pz], yaw=0.0, speed=MED, tag="pre push")
        tx = x + d["opening"] - 0.004
        R.move([tx, y, pz], yaw=0.0, speed=0.08, tag="push drawer")
        pe, _, _ = R.ee()
        R.move([pe[0] - 0.03, pe[1], pz], speed=MED, tag="back off")
        R.move([pe[0] - 0.03, pe[1], safe_z], speed=FAST, tag="up")
    return read_drawer(R, 3)


# ---------------------------------------------------------------- cup
def grasp_cup(R, top_z, objs):
    counter_tops = [o["pos"][2] + o["size"][2] / 2 for o in objs if o.get("location") == "counter"]
    for k in range(4):
        pos, yaw, radius, height = read_cup(R)
        psi = wrap(yaw)
        if psi > math.pi / 2:
            psi -= math.pi
        if psi < -math.pi / 2:
            psi += math.pi
        axis = np.array([-math.sin(psi), math.cos(psi)])
        bottom = 0.5 * (top_z + (pos[2] - height / 2)) if abs(pos[2] - height / 2 - top_z) < 0.02 else top_z
        gz = bottom + CUP_GRIP_ABOVE_BOTTOM
        safe_z = max([top_z + 0.14] + [t + 0.08 for t in counter_tops])
        R.api.open_gripper()
        pe, _, _ = R.ee()
        R.move([pe[0], pe[1], max(pe[2], safe_z)], speed=FAST, tag="lift")
        offsets = [0.0, 0.009, -0.009, 0.018, -0.018]
        grabbed = False
        for off in offsets:
            gx = pos[0] + off * axis[0]
            gy = pos[1] + off * axis[1]
            R.move([gx, gy, safe_z], yaw=psi, speed=FAST, tag="above cup")
            R.move([gx, gy, gz + height + 0.02], yaw=psi, speed=MED, tag="pre cup")
            R.move([gx, gy, gz], yaw=psi, speed=0.04, tag="cup")
            pe, _, _ = R.ee()
            if pe[2] > gz + 0.012:
                R.log("blocked above cup at z %.4f (target %.4f), offset %.3f" % (pe[2], gz, off))
                R.move([gx, gy, gz + height + 0.03], speed=MED, tag="back up")
                continue
            grabbed = True
            break
        if not grabbed:
            continue
        w = R.api.close_gripper()
        R.log("cup grasp width %.4f" % w)
        if w > 0.035:
            pe, _, _ = R.ee()
            tip_above_bottom = pe[2] - bottom
            R.move([pe[0], pe[1], safe_z], speed=MED, tag="lift cup")
            c = R.api.get_cup()
            if c["pos"][2] > top_z + 0.06:
                return True, psi, yaw, tip_above_bottom, safe_z
            R.log("cup not lifted (z %.4f), retrying" % c["pos"][2])
            pe, _, _ = R.ee()
            R.move([pe[0], pe[1], gz + 0.01], speed=MED, tag="put back")
        R.api.open_gripper()
        pe, _, _ = R.ee()
        R.move([pe[0], pe[1], safe_z], speed=MED, tag="retreat")
    return False, 0.0, 0.0, CUP_GRIP_ABOVE_BOTTOM, top_z + 0.14


# ---------------------------------------------------------------- main
def run(api):
    R = Robot(api)
    top_z, front_x, _, objs = read_scene(R)
    drawer = read_drawer(R)
    pe, yaw0, w0 = R.ee()
    R.log("ee start %s yaw %.3f w %.4f" % (np.round(pe, 3).tolist(), yaw0, w0))

    # Which way will the cup handle point once the gripper is rotated to yaw 0?
    pos, cyaw, _, _ = read_cup(R)
    psi = wrap(cyaw)
    if psi > math.pi / 2:
        psi -= math.pi
    if psi < -math.pi / 2:
        psi += math.pi
    k = int(round(wrap(cyaw - psi) / math.pi))
    handle_dir_x = -1 if k % 2 == 0 else 1

    # Choose how far to open the drawer.
    cur = drawer["opening"]
    chosen = None
    for D in [0.22, 0.25, 0.28, 0.31, 0.34, 0.37]:
        D_eff = max(D, cur) if cur <= 0.40 else cur
        best = plan_place(drawer, objs, front_x, D_eff, handle_dir_x)
        R.log("opening %.3f -> place score %.4f slack %.4f at (%.3f, %.3f)"
              % (D_eff, best[0], best[3] if len(best) > 3 else -1, best[1] or 0, best[2] or 0))
        if best[1] is not None and best[3] >= 0.012:
            chosen = D_eff
            break
    if chosen is None:
        chosen = max(0.30, cur) if cur <= 0.40 else cur

    if abs(chosen - cur) >= 0.02:
        drawer = set_opening(R, chosen, top_z, front_x)
    objs = api.get_objects()
    drawer = read_drawer(R)

    ok, psi, cyaw, tip_above_bottom, safe_z = grasp_cup(R, top_z, objs)
    if not ok:
        R.log("failed to grasp cup")
    # in-hand: recompute handle direction for the place yaw
    k = int(round(wrap(cyaw - psi) / math.pi))
    handle_dir_x = -1 if k % 2 == 0 else 1

    best = plan_place(drawer, objs, front_x, drawer["opening"], handle_dir_x)
    _, px, py, slack = best
    R.log("place at (%.4f, %.4f) slack %.4f tip_above_bottom %.4f" % (px, py, slack, tip_above_bottom))

    pe, _, _ = R.ee()
    R.move([pe[0], pe[1], safe_z], speed=MED, tag="lift cup")
    R.move([px, py, safe_z], yaw=0.0, speed=MED, tag="carry")
    place_tip = drawer["floor_z"] + tip_above_bottom + 0.003
    R.move([px, py, drawer["floor_z"] + 0.14], yaw=0.0, speed=MED, tag="lower")
    R.move([px, py, place_tip], yaw=0.0, speed=0.04, tag="place")
    R.api.wait(0.2)
    R.api.open_gripper()
    R.api.wait(0.2)
    pe, _, _ = R.ee()
    R.move([pe[0], pe[1], max(top_z + 0.08, pe[2] + 0.12)], speed=SLOW, tag="leave cup")
    c = api.get_cup()
    R.log("cup after place %s" % np.round(c["pos"], 4).tolist())

    close_drawer(R, top_z, front_x)
    pe, _, _ = R.ee()
    R.move([pe[0] - 0.05, pe[1], max(pe[2], top_z + 0.12)], speed=MED, tag="retreat home")
    read_drawer(R, 2)
    c = api.get_cup()
    R.log("cup final %s" % np.round(c["pos"], 4).tolist())
