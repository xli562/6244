"""Robot program for: "Place the cup in the drawer." See TASK.md and API.md.

Strategy
  1. Plan a grasp yaw for the cup (fingers perpendicular to the cup handle, clear
     of neighbouring objects).
  2. Pull the drawer open far enough that a free spot for the cup exists in the
     part of the drawer that is in front of the counter (reachable from above).
  3. Pick the cup, carry it above everything, rotate it so the gripper is at
     yaw 0 (thin side of the hand along x), lower it onto the drawer floor, release.
  4. Grasp the drawer handle again and push the drawer closed.
"""
import math

import numpy as np

# ---------------------------------------------------------------- geometry
FINGER_LEN = 0.045        # fingertip to palm
FINGER_HX = 0.012         # half size of a finger along the gripper x (thin) axis
FINGER_HY = 0.012         # half thickness of a finger along the closing axis
HAND_HX = 0.035           # half thickness of the hand (gripper x axis)
HAND_HY = 0.105           # half width of the hand (closing axis)
GRIP_OPEN = 0.08
CUP_HANDLE_EXT = 0.03     # how far the cup handle sticks out of the body

SPEED_FREE = 0.25
SPEED_NEAR = 0.10
SPEED_SLOW = 0.05


def wrap_pi(a):
    return (a + math.pi) % (2 * math.pi) - math.pi


def wrap_half_pi(a):
    """Gripper is symmetric under a rotation of pi."""
    a = wrap_pi(a)
    if a > math.pi / 2:
        a -= math.pi
    elif a <= -math.pi / 2:
        a += math.pi
    return a


def rect_points(cx, cy, yaw, hx, hy, n=5):
    c, s = math.cos(yaw), math.sin(yaw)
    pts = []
    for u in np.linspace(-hx, hx, n):
        for v in np.linspace(-hy, hy, n):
            pts.append((cx + c * u - s * v, cy + s * u + c * v))
    return pts


def disk_points(cx, cy, r, n=16):
    pts = [(cx, cy)]
    for k in range(n):
        a = 2 * math.pi * k / n
        pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    return pts


def pt_box_dist(p, box):
    (ox, oy), (sx, sy) = box
    dx = max(abs(p[0] - ox) - sx / 2, 0.0)
    dy = max(abs(p[1] - oy) - sy / 2, 0.0)
    return math.hypot(dx, dy)


def clearance(parts, obstacles):
    """parts: list of (points, zlo, zhi). obstacles: list of dict with pos/size.
    Returns the smallest horizontal distance between a part and an obstacle that
    overlaps it in height (large number if none)."""
    best = 1.0
    for o in obstacles:
        ox, oy, oz = o["pos"]
        sx, sy, sz = o["size"]
        olo, ohi = oz - sz / 2, oz + sz / 2
        box = ((ox, oy), (sx, sy))
        for pts, zlo, zhi in parts:
            if zhi < olo - 0.01 or zlo > ohi + 0.01:
                continue
            for p in pts:
                d = pt_box_dist(p, box)
                if d < best:
                    best = d
    return best


def gripper_parts(cx, cy, yaw, z_tip, finger_half_open):
    """Footprint of an open gripper whose fingertips are at z_tip."""
    c, s = math.cos(yaw), math.sin(yaw)
    parts = []
    off = finger_half_open + FINGER_HY
    for sgn in (-1, 1):
        fx = cx - s * sgn * off
        fy = cy + c * sgn * off
        parts.append((rect_points(fx, fy, yaw, FINGER_HX, FINGER_HY, 3),
                      z_tip, z_tip + FINGER_LEN))
    parts.append((rect_points(cx, cy, yaw, HAND_HX, HAND_HY, 5),
                  z_tip + FINGER_LEN, z_tip + 0.30))
    return parts


# ---------------------------------------------------------------- program
def run(api):
    def log(*a):
        try:
            api.log(" ".join(str(x) for x in a))
        except Exception:
            pass

    def ee():
        return api.get_ee()

    def mv(pos, yaw=None, speed=SPEED_FREE, tag=""):
        pos = [float(pos[0]), float(pos[1]), float(pos[2])]
        r = api.move_to(pos, yaw=yaw, speed=speed)
        if not r.get("reached", True):
            log("move", tag, "not reached", [round(v, 3) for v in pos],
                "err", round(r.get("error", -1), 4))
        return r

    def travel(xy, z_travel, z_final, yaw=None, speed_down=SPEED_NEAR, tag=""):
        """Go up to z_travel, across, then down to z_final."""
        p = ee()["pos"]
        if p[2] < z_travel - 0.005:
            mv([p[0], p[1], z_travel], tag=tag + " up")
        mv([xy[0], xy[1], z_travel], yaw=yaw, tag=tag + " across")
        if abs(z_final - z_travel) > 0.002:
            mv([xy[0], xy[1], z_final], speed=speed_down, tag=tag + " down")

    counter = api.get_counter()
    top_z = counter["top_z"]
    front_x = counter["front_x"]
    cup = api.get_cup()
    r_cup = cup["radius"]
    h_cup = cup["height"]
    objects = api.get_objects()
    counter_objs = [o for o in objects if o.get("location") == "counter"]
    log("counter", counter)
    log("cup", cup)
    log("drawer", api.get_drawer())
    log("handle", api.get_handle())
    for o in objects:
        log("obj", o)
    log("ee", ee())

    tallest = top_z
    for o in counter_objs:
        tallest = max(tallest, o["pos"][2] + o["size"][2] / 2)
    # height for moving around above the counter with an empty gripper
    z_free = max(top_z + 0.12, tallest + 0.06)

    # ------------------------------------------------ plan the cup grasp
    def plan_cup_grasp(cup):
        cx, cy, cz = cup["pos"]
        # fingertips ~3 cm above the counter, ~2.5 cm below the cup rim
        z_tip = max(cz + 0.004, top_z + 0.030)
        z_tip = min(z_tip, cz + h_cup / 2 - 0.02)
        best = None
        for dd in range(-45, 46, 5):
            delta = math.radians(dd)
            g = wrap_half_pi(cup["yaw"] + delta)
            parts = gripper_parts(cx, cy, g, z_tip, GRIP_OPEN / 2)
            cl = clearance(parts, counter_objs)
            score = min(cl, 0.03) * 10 - abs(delta) * 0.05 - abs(g) * 0.01
            if best is None or score > best[0]:
                best = (score, g, cl, delta)
        return best[1], z_tip, best[2]

    # ------------------------------------------------ drawer helpers
    def grasp_handle(x_off=0.006):
        """Returns True when the handle is held."""
        for attempt in range(3):
            h = api.get_handle()["pos"]
            api.open_gripper()
            z_above = max(h[2] + 0.12, top_z + 0.04)
            # grasp slightly on the robot side of the bar: keeps the hand off the
            # counter front when the drawer is (nearly) closed
            gx = h[0] - x_off
            travel([gx, h[1]], z_above, h[2] + 0.04, yaw=0.0, tag="handle")
            mv([gx, h[1], h[2]], yaw=0.0, speed=SPEED_SLOW, tag="handle grasp")
            w = api.close_gripper()
            log("handle grasp width", round(w, 4))
            if 0.006 < w < 0.04:
                return True
            api.open_gripper()
            p = ee()["pos"]
            mv([p[0], p[1], z_above], tag="handle retry up")
        return False

    def release_handle():
        api.open_gripper()
        p = ee()["pos"]
        mv([p[0], p[1], max(p[2] + 0.10, top_z + 0.04)], speed=SPEED_NEAR,
           tag="leave handle")

    def set_drawer(target, tol=0.015):
        """Move the drawer to opening `target` (0 = closed)."""
        for attempt in range(3):
            d = api.get_drawer()["opening"]
            log("drawer opening", round(d, 4), "target", target)
            if abs(d - target) < tol:
                return d
            if not grasp_handle(0.009 if target <= 0.001 else 0.006):
                log("could not grasp handle")
                release_handle()
                return d
            p = ee()["pos"]
            dx = d - target          # >0: push in (+x), <0: pull out (-x)
            # small overshoot when closing; the grasp is 6 mm on the robot side of
            # the bar so the hand still stays clear of the counter front
            extra = 0.008 if target <= 0.001 else 0.0
            goal = [p[0] + dx + (extra if dx > 0 else 0.0), p[1], p[2]]
            mv(goal, speed=0.07, tag="drawer slide")
            api.wait(0.3)
            release_handle()
        d = api.get_drawer()["opening"]
        log("drawer opening final", round(d, 4))
        return d

    # ------------------------------------------------ placement planning
    def find_spot(drw, shift, objs_in_drawer, grasp_info):
        """Find a cup spot in the drawer after it is pulled out by `shift` more.
        Returns (x, y, score) or None."""
        icx, icy, icz = drw["interior_center"]
        sx, sy, sz = drw["interior_size"]
        floor = drw["floor_z"]
        icx -= shift
        x_in = icx - sx / 2
        x_back = icx + sx / 2
        x_hi = min(front_x - 0.085, x_back - r_cup - CUP_HANDLE_EXT - 0.01)
        x_lo = x_in + max(0.07, r_cup + CUP_HANDLE_EXT + 0.015)
        x_pref = x_in + 0.15     # keeps the wrist clear of the drawer front panel
        y_lo = icy - sy / 2 + 0.07
        y_hi = icy + sy / 2 - 0.07
        if x_hi < x_lo or y_hi < y_lo:
            return None
        obs = []
        for o in objs_in_drawer:
            q = dict(o)
            q["pos"] = [o["pos"][0] - shift, o["pos"][1], o["pos"][2]]
            obs.append(q)
        best = None
        z_tip = floor + grasp_info
        for x in np.arange(x_hi, x_lo - 1e-9, -0.01):
            for y in np.arange(y_lo, y_hi + 1e-9, 0.01):
                parts = gripper_parts(x, y, 0.0, z_tip, GRIP_OPEN / 2)
                parts.append((disk_points(x, y, r_cup + 0.005), floor, floor + h_cup))
                for sgn in (-1, 1):
                    hp = [(x + sgn * (r_cup + t), y) for t in (0.0, 0.015, CUP_HANDLE_EXT)]
                    parts.append((hp, floor, floor + h_cup))
                cl = clearance(parts, obs)
                if cl < 0.012:
                    continue
                score = (min(cl, 0.05) * 4
                         - 0.5 * max(0.0, x_pref - x)
                         - 0.05 * abs(y - icy)
                         - 0.02 * (x_hi - x))
                if best is None or score > best[2]:
                    best = (float(x), float(y), score, x >= x_pref - 0.02)
        return best

    # ------------------------------------------------ 0. get clear
    api.open_gripper()
    p0 = ee()["pos"]
    if p0[2] < z_free:
        mv([p0[0], p0[1], z_free], tag="start up")

    g_yaw, z_tip_cup, cl_cup = plan_cup_grasp(cup)
    log("grasp yaw", round(g_yaw, 3), "clearance", round(cl_cup, 3))
    # fingertip height above the cup bottom while carrying it
    tip_above_bottom = (z_tip_cup - (cup["pos"][2] - h_cup / 2))

    # ------------------------------------------------ 1. open the drawer
    drw = api.get_drawer()
    d0 = drw["opening"]
    drawer_objs = [o for o in api.get_objects() if o.get("location") == "drawer"]
    chosen = None
    for cand in np.arange(0.27, 0.381, 0.02):
        target = max(float(cand), d0)
        spot = find_spot(drw, target - d0, drawer_objs, tip_above_bottom)
        if spot is not None and spot[3]:
            chosen = target
            break
    if chosen is None:
        chosen = max(0.30, d0)
    log("target opening", round(chosen, 3))
    if chosen - d0 > 0.01:
        set_drawer(chosen, tol=0.02)

    drw = api.get_drawer()
    drawer_objs = [o for o in api.get_objects() if o.get("location") == "drawer"]
    spot = find_spot(drw, 0.0, drawer_objs, tip_above_bottom)
    if spot is None:
        icx, icy, _ = drw["interior_center"]
        spot = (min(front_x - 0.09, icx - drw["interior_size"][0] / 2 + 0.13), icy, 0, False)
        log("no free spot found, fallback")
    log("drawer now", drw, "spot", [round(spot[0], 3), round(spot[1], 3)])

    # ------------------------------------------------ 2. pick the cup
    held = False
    for attempt in range(3):
        cup = api.get_cup()
        if attempt > 0:
            g_yaw, z_tip_cup, cl_cup = plan_cup_grasp(cup)
        cx, cy, cz = cup["pos"]
        api.open_gripper()
        travel([cx, cy], z_free, cz + 0.06, yaw=g_yaw, tag="cup")
        mv([cx, cy, z_tip_cup], yaw=g_yaw, speed=SPEED_SLOW, tag="cup grasp")
        w = api.close_gripper()
        log("cup grasp width", round(w, 4))
        if w > 2 * r_cup - 0.02:
            mv([cx, cy, cz + 0.05], speed=SPEED_NEAR, tag="cup lift")
            c2 = api.get_cup()
            if c2["pos"][2] > cz + 0.03:
                held = True
                planned = z_tip_cup - (cz - h_cup / 2)
                meas = ee()["pos"][2] - (c2["pos"][2] - h_cup / 2)
                tip_above_bottom = meas if abs(meas - planned) < 0.015 else planned
                log("cup held, tip above bottom", round(tip_above_bottom, 4))
                break
            log("cup not lifted", c2)
        api.open_gripper()
        p = ee()["pos"]
        mv([p[0], p[1], z_free], tag="cup retry up")
    if not held:
        log("failed to pick the cup")
        return

    # carry height: cup bottom above every counter object and the counter edge
    z_carry = max(tallest + 0.04 + tip_above_bottom, top_z + 0.05 + tip_above_bottom)
    p = ee()["pos"]
    mv([p[0], p[1], z_carry], speed=SPEED_NEAR, tag="carry up")
    mv([spot[0], spot[1], z_carry], yaw=0.0, speed=0.15, tag="carry across")

    # ------------------------------------------------ 3. place
    drw = api.get_drawer()
    floor = drw["floor_z"]
    z_place = floor + tip_above_bottom + 0.006
    mv([spot[0], spot[1], z_place + 0.05], yaw=0.0, speed=SPEED_NEAR, tag="place approach")
    mv([spot[0], spot[1], z_place], yaw=0.0, speed=SPEED_SLOW, tag="place")
    api.wait(0.2)
    api.open_gripper()
    api.wait(0.2)
    mv([spot[0], spot[1], top_z + 0.06], speed=SPEED_NEAR, tag="place leave")
    c3 = api.get_cup()
    log("cup after place", c3)

    # ------------------------------------------------ 4. close the drawer
    set_drawer(0.0, tol=0.007)
    p = ee()["pos"]
    mv([p[0] - 0.05, p[1], max(p[2], top_z + 0.06)], tag="retreat")
    log("final drawer", api.get_drawer())
    log("final drawer", api.get_drawer(), "cup", api.get_cup())
