import numpy as np
import math


def run(api):
    instruction = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    def pos(name):
        return np.asarray(api.pos(name), dtype=float).copy()

    def hand():
        return np.asarray(api.eef(), dtype=float).copy()

    def move(point, steps=12):
        return api.move(np.asarray(point, dtype=float), steps=steps)

    def find(fragment, pool=None):
        return next(
            (n for n in (names if pool is None else pool) if fragment in n),
            None,
        )

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        mappings = {
            "akita black bowl": ["black bowl", "bowl"],
            "porcelain mug": ["white mug"],
            "white yellow mug": [
                "yellow and white mug", "white and yellow mug", "yellow mug"
            ],
            "red coffee mug": ["red mug", "red coffee mug"],
            "cream cheese": ["cream cheese box", "cream cheese"],
            "black book": ["black book", "book"],
            "desk caddy": ["desk caddy", "caddy"],
            "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
            "flat stove": ["stove"],
            "white cabinet": ["cabinet"],
        }
        return [base] + mappings.get(base, [])

    def mentioned(name, text):
        padded = " " + text + " "
        return any(" " + a + " " in padded for a in aliases(name))

    def retreat():
        move(hand() + [0., 0., 0.12], 10)

    def grasp_offset(item, attempt=0):
        offset = np.zeros(3)
        if "bowl" in item:
            offset[:] = [0.035, 0., 0.015]
        elif "mug" in item:
            offset[:] = [0.025, 0., 0.015]
        elif "book" in item:
            offset[2] = 0.005
        elif "moka" in item:
            return np.array([
                (0., 0., -0.012),
                (0., 0.018, -0.025),
            ][attempt])
        if attempt:
            if "bowl" in item or "mug" in item:
                offset[0] *= -1.
            else:
                offset[0] += 0.018
                offset[2] -= 0.008
        return offset

    def placed(item, target, offset):
        p, q = pos(item), pos(target) + offset
        tolerance, upper = 0.065, 0.17
        if "basket" in target and "cream_cheese" in item:
            tolerance, upper = 0.045, 0.10
        if "caddy" in target:
            tolerance = 0.045
        return (
            np.linalg.norm(p[:2] - q[:2]) < tolerance
            and -0.055 < p[2] - q[2] < upper
        )

    def transport(item, target, offset=None):
        offset = np.zeros(3) if offset is None else np.asarray(offset, float)
        for attempt in range(2):
            before = pos(item)
            drop_height = 0.08
            if "cream_cheese" in item and "basket" in target:
                drop_height = 0.035
            lift = api.transfer(
                item,
                target,
                grasp=tuple(grasp_offset(item, attempt)),
                drop=tuple(offset + [0., 0., drop_height]),
            )
            after = pos(item)
            if placed(item, target, offset):
                return True

            fingertip = hand()
            if (
                lift is not None and float(lift) > 0.025
                and np.linalg.norm(after - fingertip) < 0.10
                and after[2] > before[2] + 0.025
            ):
                relative = after - fingertip
                destination = pos(target) + offset
                move(destination - relative + [0., 0., 0.16], 16)
                move(destination - relative + [0., 0., 0.035], 12)
                api.grip(False)
                retreat()
                if placed(item, target, offset):
                    return True
            api.grip(False)
        return False

    def drawer_open(cabinet, region):
        # Earliest failure: opening the drawer, before any bowl grasp.
        # Infer the cabinet's accessible face instead of assuming -world-y.
        initial = pos(region)
        base = pos(cabinet)
        starting_hand = hand()
        level = next(s for s in ("bottom", "middle", "top") if s in region)
        handle_name = next(
            (
                n for n in names
                if "handle" in n
                and (level in n or region in n)
            ),
            None,
        )

        def cardinal(vector):
            result = np.zeros(3)
            axis = int(np.argmax(np.abs(vector[:2])))
            result[axis] = 1. if vector[axis] >= 0. else -1.
            return result

        face = initial - base
        if handle_name:
            face = pos(handle_name) - initial
        if np.linalg.norm(face[:2]) < 0.025:
            face = starting_hand - base
        outward = cardinal(face)

        perpendicular = np.array([-outward[1], outward[0], 0.])
        if np.dot(perpendicular, starting_hand - base) < 0.:
            perpendicular = -perpendicular

        candidates = [
            (outward, 0.145, 0.015),
            (outward, 0.175, 0.035),
            (perpendicular, 0.145, 0.015),
        ]
        best = None
        for direction, reach, height in candidates:
            handle_before = pos(handle_name) if handle_name else None
            handle = (
                handle_before.copy() if handle_name else
                pos(region) + direction * reach + [0., 0., height]
            )
            api.grip(False)
            # Descend outside the front panel, then approach horizontally.
            staging = handle + direction * 0.085
            move(staging + [0., 0., 0.10], 9)
            move(staging, 9)
            move(handle, 12)
            contact = hand()
            contact_error = np.linalg.norm(contact - handle)
            api.grip(True)
            move(contact + direction * 0.09, 12)
            move(contact + direction * 0.19, 16)
            end = hand()

            region_delta = pos(region) - initial
            handle_delta = (
                pos(handle_name) - handle_before
                if handle_name else np.zeros(3)
            )
            observed = max(
                float(np.dot(region_delta, direction)),
                float(np.dot(handle_delta, direction)),
            )
            pull = float(np.dot(end - contact, direction))
            lateral = np.linalg.norm(
                end - contact - direction * pull
            )
            api.grip(False)
            move(end + direction * 0.035 + [0., 0., 0.09], 8)

            if observed > 0.035:
                # Handle displacement also supports fixed containment sites.
                displacement = (
                    region_delta if np.linalg.norm(region_delta[:2]) > 0.025
                    else handle_delta
                )
                center = initial + displacement
                return {
                    "initial": initial,
                    "center": center,
                    "direction": direction,
                    "handle": handle + displacement,
                    "travel": max(observed, 0.04),
                }

            # A fixed site cannot verify articulation. Keep only an accurately
            # reached, unobstructed pull as a fallback placement estimate.
            if contact_error < 0.025 and pull > 0.12 and lateral < 0.035:
                if best is None or pull > best["travel"]:
                    distance = min(pull, 0.19)
                    best = {
                        "initial": initial,
                        "center": initial + direction * distance,
                        "direction": direction,
                        "handle": handle + direction * distance,
                        "travel": distance,
                    }
                # Avoid regrasping a possibly opened drawer at its old pose.
                break
        return best

    def drawer_close(state):
        direction = state["direction"]
        handle = state["handle"]
        travel = state["travel"]
        api.grip(True)
        staging = handle + direction * 0.07
        move(staging + [0., 0., 0.07], 10)
        move(staging, 10)
        move(handle + direction * 0.015, 10)
        move(handle - direction * (travel + 0.025), 24)
        move(hand() + direction * 0.07, 8)
        retreat()
        api.grip(False)

    def turn_stove(stove, on=True):
        knob = find("switch") or find("knob") or find("button")
        center = pos(knob) if knob else pos(stove) + [0., -0.105, 0.025]
        api.grip(False)
        move(center + [0., 0., 0.09], 12)
        move(center, 14)
        api.grip(True)
        direction = 1. if on else -1.
        api.action([0., 0., 0., 0., 0., direction, 1.], steps=18)
        api.grip(False)
        retreat()
        api.action([0., 0., 0., 0., 0., -direction, -1.], steps=18)

    stove = find("flat_stove", bodies)
    if stove and ("turn on" in instruction or "turn off" in instruction):
        turn_stove(stove, "turn on" in instruction)

    cabinet = find("cabinet", bodies)
    if cabinet and "drawer" in instruction:
        level = next(
            (s for s in ("bottom", "middle", "top") if s in instruction),
            "bottom",
        )
        region = find(cabinet + "_" + level + "_region")
        if region is None:
            return
        items = [
            n for n in bodies if n != cabinet and mentioned(n, instruction)
        ]
        state = drawer_open(cabinet, region)
        if state is None:
            return
        for item in items:
            offset = state["center"] - pos(region) + [0., 0., 0.015]
            if not transport(item, region, offset):
                return
        if "close" in instruction:
            drawer_close(state)
        return

    jobs = []
    basket = find("basket", bodies)
    caddy = find("caddy", bodies)

    if basket and "basket" in instruction:
        target = find(basket + "_contain_region") or basket
        items = [
            n for n in bodies if n != basket and mentioned(n, instruction)
        ]
        for i, item in enumerate(items):
            x = (i - (len(items) - 1) / 2.) * 0.065
            offset = np.array([x, 0., 0.])
            if "cream_cheese" in item:
                offset = np.array([0.01, 0.045, 0.])
            jobs.append((item, target, offset))

    elif caddy and "caddy" in instruction:
        side = next(
            (s for s in ("back", "front", "left", "right") if s in instruction),
            "back",
        )
        target = find(caddy + "_" + side + "_contain_region") or caddy
        for item in bodies:
            if item != caddy and mentioned(item, instruction):
                jobs.append((item, target, np.zeros(3)))

    elif "plate" in instruction and (
        "left" in instruction or "right" in instruction
    ):
        plates = [n for n in bodies if n.startswith("plate_")]
        used = set()
        for side in ("left", "right"):
            marker = find("plate_" + side + "_region")
            if marker is None or not plates:
                continue
            target = min(plates, key=lambda n: np.linalg.norm(pos(n) - pos(marker)))
            end = instruction.find(side + " plate")
            if end < 0:
                continue
            start = max(
                instruction.rfind("put ", 0, end),
                instruction.rfind("place ", 0, end),
                0,
            )
            clause = instruction[start:end]
            matches = [
                n for n in bodies
                if n not in used and "mug" in n and mentioned(n, clause)
            ]
            if matches:
                item = max(
                    matches,
                    key=lambda n: max(
                        [len(a) for a in aliases(n) if a in clause] or [0]
                    ),
                )
                jobs.append((item, target, np.zeros(3)))
                used.add(item)

    elif stove and ("stove" in instruction or "on it" in instruction):
        target = find(stove + "_cook_region") or stove
        for item in bodies:
            if item != stove and mentioned(item, instruction):
                jobs.append((item, target, np.zeros(3)))

    else:
        candidates = [n for n in bodies if mentioned(n, instruction)]
        if len(candidates) >= 2:
            target_body = max(
                candidates,
                key=lambda n: max(instruction.rfind(a) for a in aliases(n)),
            )
            target = target_body
            if " in " in instruction or " into " in instruction:
                target = find(target_body + "_contain_region") or target_body
            for item in candidates:
                if item != target_body:
                    jobs.append((item, target, np.zeros(3)))

    for item, target, offset in jobs:
        if not transport(item, target, offset):
            return
