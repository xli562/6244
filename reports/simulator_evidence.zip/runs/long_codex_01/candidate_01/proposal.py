import numpy as np
import math


def run(api):
    instruction = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    def pos(name):
        return np.asarray(api.pos(name), dtype=float).copy()

    def hand():
        return np.asarray(api.eef(), dtype=float).copy()

    def move(point, steps=12):
        return api.move(np.asarray(point, dtype=float), steps=steps)

    def find(fragment, pool=None):
        return next(
            (n for n in (names if pool is None else pool) if fragment in n),
            None,
        )

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        mappings = {
            "akita black bowl": ["black bowl", "bowl"],
            "porcelain mug": ["white mug"],
            "white yellow mug": [
                "yellow and white mug", "white and yellow mug", "yellow mug"
            ],
            "red coffee mug": ["red mug", "red coffee mug"],
            "cream cheese": ["cream cheese box", "cream cheese"],
            "black book": ["black book", "book"],
            "desk caddy": ["desk caddy", "caddy"],
            "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
            "flat stove": ["stove"],
            "white cabinet": ["cabinet"],
        }
        return [base] + mappings.get(base, [])

    def mentioned(name, text):
        padded = " " + text + " "
        return any(" " + a + " " in padded for a in aliases(name))

    def retreat():
        move(hand() + [0., 0., 0.12], 10)

    def grasp_offset(item, attempt=0):
        offset = np.zeros(3)
        if "bowl" in item:
            offset[:] = [0.035, 0., 0.015]
        elif "mug" in item:
            offset[:] = [0.025, 0., 0.015]
        elif "book" in item:
            offset[2] = 0.005
        elif "moka" in item:
            # Previous grasps above the body produced no lift.
            return np.array([
                (0., 0., -0.012),
                (0., 0.018, -0.025),
            ][attempt])
        if attempt:
            if "bowl" in item or "mug" in item:
                offset[0] *= -1.
            else:
                offset[0] += 0.018
                offset[2] -= 0.008
        return offset

    def placed(item, target, offset):
        p, q = pos(item), pos(target) + offset
        tolerance = 0.065
        upper = 0.17
        if "basket" in target:
            tolerance = 0.065
            if "cream_cheese" in item:
                tolerance = 0.045
                upper = 0.10
        if "caddy" in target:
            tolerance = 0.045
        return (
            np.linalg.norm(p[:2] - q[:2]) < tolerance
            and -0.055 < p[2] - q[2] < upper
        )

    def transport(item, target, offset=None):
        offset = np.zeros(3) if offset is None else np.asarray(offset, float)
        for attempt in range(2):
            before = pos(item)
            drop_height = 0.08
            if "cream_cheese" in item and "basket" in target:
                # Lift already succeeded; repair release height and centering.
                drop_height = 0.035
            lift = api.transfer(
                item,
                target,
                grasp=tuple(grasp_offset(item, attempt)),
                drop=tuple(offset + [0., 0., drop_height]),
            )
            after = pos(item)
            if placed(item, target, offset):
                return True

            fingertip = hand()
            if (
                lift is not None and float(lift) > 0.025
                and np.linalg.norm(after - fingertip) < 0.10
                and after[2] > before[2] + 0.025
            ):
                relative = after - fingertip
                destination = pos(target) + offset
                move(destination - relative + [0., 0., 0.16], 16)
                move(destination - relative + [0., 0., 0.035], 12)
                api.grip(False)
                retreat()
                if placed(item, target, offset):
                    return True
            api.grip(False)
        return False

    def drawer_open(region):
        initial = pos(region)
        # Prefer a perceived handle over a geometric estimate.
        level = next(s for s in ("bottom", "middle", "top") if s in region)
        handle_name = next(
            (
                n for n in names
                if "handle" in n and (level in n or region in n)
            ),
            None,
        )
        best_pull = 0.
        last_handle = None
        for attempt in range(2):
            handle = (
                pos(handle_name) if handle_name
                else pos(region) + [
                    0., -0.145 if attempt == 0 else -0.17,
                    0.015 if attempt == 0 else 0.035,
                ]
            )
            api.grip(False)
            move(handle + [0., -0.08, 0.07], 10)
            move(handle, 12)
            api.grip(True)
            start_hand = hand()
            move(handle + [0., -0.19, 0.], 22)
            end_hand = hand()
            measured = initial[1] - pos(region)[1]
            pull = max(0., start_hand[1] - end_hand[1])
            best_pull = max(best_pull, pull)
            last_handle = end_hand.copy()
            api.grip(False)
            retreat()
            if measured > 0.035:
                return initial, True, None, last_handle

        # Some region positions are fixed reference sites. Lack of site
        # displacement alone must not prevent the bowl placement.
        if best_pull > 0.10:
            inferred_center = initial + [0., -min(best_pull, 0.19), 0.]
            return initial, True, inferred_center, last_handle
        return initial, False, None, last_handle

    def drawer_close(region, initial, inferred_center, last_handle):
        current = pos(region)
        travel = max(0., initial[1] - current[1])
        if inferred_center is not None:
            travel = max(travel, initial[1] - inferred_center[1])
            handle = last_handle.copy()
        else:
            handle = current + [0., -0.15, 0.015]
        if travel < 0.025:
            return
        api.grip(True)
        move(handle + [0., -0.065, 0.06], 10)
        move(handle + [0., -0.035, 0.], 10)
        move(handle + [0., travel + 0.02, 0.], 24)
        retreat()
        api.grip(False)

    def turn_stove(stove, on=True):
        knob = find("switch") or find("knob") or find("button")
        center = pos(knob) if knob else pos(stove) + [0., -0.105, 0.025]
        api.grip(False)
        move(center + [0., 0., 0.09], 12)
        move(center, 14)
        api.grip(True)
        direction = 1. if on else -1.
        api.action([0., 0., 0., 0., 0., direction, 1.], steps=18)
        api.grip(False)
        retreat()
        # Preserve the successful switch action while restoring grasp yaw
        # away from the switch before acquiring the moka pot.
        api.action([0., 0., 0., 0., 0., -direction, -1.], steps=18)

    stove = find("flat_stove", bodies)
    if stove and ("turn on" in instruction or "turn off" in instruction):
        turn_stove(stove, "turn on" in instruction)

    cabinet = find("cabinet", bodies)
    if cabinet and "drawer" in instruction:
        level = next(
            (s for s in ("bottom", "middle", "top") if s in instruction),
            "bottom",
        )
        region = find(cabinet + "_" + level + "_region")
        if region is None:
            return
        items = [
            n for n in bodies if n != cabinet and mentioned(n, instruction)
        ]
        initial, opened, inferred, last_handle = drawer_open(region)
        if not opened:
            return
        for item in items:
            offset = np.array([0., 0., 0.015])
            if inferred is not None:
                offset += inferred - pos(region)
            if not transport(item, region, offset):
                return
        if "close" in instruction:
            drawer_close(region, initial, inferred, last_handle)
        return

    jobs = []
    basket = find("basket", bodies)
    caddy = find("caddy", bodies)

    if basket and "basket" in instruction:
        target = find(basket + "_contain_region") or basket
        items = [
            n for n in bodies if n != basket and mentioned(n, instruction)
        ]
        for i, item in enumerate(items):
            x = (i - (len(items) - 1) / 2.) * 0.065
            offset = np.array([x, 0., 0.])
            if "cream_cheese" in item:
                # Keep the successful soup placement; put the wider box
                # farther from the side wall and separate it along y.
                offset = np.array([0.01, 0.045, 0.])
            jobs.append((item, target, offset))

    elif caddy and "caddy" in instruction:
        side = next(
            (s for s in ("back", "front", "left", "right") if s in instruction),
            "back",
        )
        target = find(caddy + "_" + side + "_contain_region") or caddy
        for item in bodies:
            if item != caddy and mentioned(item, instruction):
                jobs.append((item, target, np.zeros(3)))

    elif "plate" in instruction and (
        "left" in instruction or "right" in instruction
    ):
        plates = [n for n in bodies if n.startswith("plate_")]
        used = set()
        for side in ("left", "right"):
            marker = find("plate_" + side + "_region")
            if marker is None or not plates:
                continue
            target = min(plates, key=lambda n: np.linalg.norm(pos(n) - pos(marker)))
            end = instruction.find(side + " plate")
            if end < 0:
                continue
            start = max(
                instruction.rfind("put ", 0, end),
                instruction.rfind("place ", 0, end),
                0,
            )
            clause = instruction[start:end]
            matches = [
                n for n in bodies
                if n not in used and "mug" in n and mentioned(n, clause)
            ]
            if matches:
                item = max(
                    matches,
                    key=lambda n: max(
                        [len(a) for a in aliases(n) if a in clause] or [0]
                    ),
                )
                jobs.append((item, target, np.zeros(3)))
                used.add(item)

    elif stove and ("stove" in instruction or "on it" in instruction):
        target = find(stove + "_cook_region") or stove
        for item in bodies:
            if item != stove and mentioned(item, instruction):
                jobs.append((item, target, np.zeros(3)))

    else:
        candidates = [n for n in bodies if mentioned(n, instruction)]
        if len(candidates) >= 2:
            target_body = max(
                candidates,
                key=lambda n: max(instruction.rfind(a) for a in aliases(n)),
            )
            target = target_body
            if " in " in instruction or " into " in instruction:
                target = find(target_body + "_contain_region") or target_body
            for item in candidates:
                if item != target_body:
                    jobs.append((item, target, np.zeros(3)))

    for item, target, offset in jobs:
        if not transport(item, target, offset):
            return
