import math
import numpy as np


def run(api):
    def vec(p):
        return np.asarray(p, dtype=float)

    def move(p, yaw=None, speed=0.28):
        return api.move_to([float(x) for x in p], yaw=yaw, speed=speed)

    counter = api.get_counter()
    top = float(counter["top_z"])
    front = float(counter["front_x"])
    high = top + 0.17
    objects = api.get_objects()

    def handle_grasp():
        h = vec(api.get_handle()["pos"])
        p = vec(api.get_ee()["pos"])
        # Enter below the counter from the front, rather than through its edge.
        move([p[0], p[1], max(high, p[2])])
        entry_x = max(0.19, h[0] - 0.065)
        move([entry_x, h[1], high], 0.0)
        api.open_gripper()
        move([entry_x, h[1], h[2]], 0.0, 0.15)
        move(h, 0.0, 0.09)
        return api.close_gripper()

    def leave_handle():
        api.open_gripper()
        p = vec(api.get_ee()["pos"])
        move([max(0.19, p[0] - 0.045), p[1], p[2]], 0.0, 0.18)
        p = vec(api.get_ee()["pos"])
        move([p[0], p[1], high], 0.0)

    drawer = api.get_drawer()
    for attempt in range(3):
        if float(drawer["opening"]) >= 0.285:
            break
        width = handle_grasp()
        if 0.004 < width < 0.055:
            p = vec(api.get_ee()["pos"])
            p[0] -= max(0.0, 0.31 - float(drawer["opening"]))
            move(p, 0.0, 0.13)
        leave_handle()
        drawer = api.get_drawer()

    cup = api.get_cup()
    radius = float(cup["radius"])
    height = float(cup["height"])
    # Parallel jaws have pi-periodic grasp geometry.
    yaw = (float(cup["yaw"]) + math.pi / 2) % math.pi - math.pi / 2

    objects = api.get_objects()
    center = vec(drawer["interior_center"])
    size = vec(drawer["interior_size"])
    margin = radius + 0.032
    xmin = center[0] - size[0] / 2 + margin
    xmax = min(center[0] + size[0] / 2 - margin, front - margin - 0.018)
    ymin = center[1] - size[1] / 2 + margin
    ymax = center[1] + size[1] / 2 - margin
    target = None
    best = -1.0
    if xmin <= xmax:
        for x in np.linspace(xmin, xmax, 17):
            for y in np.linspace(ymin, ymax, 23):
                clearance = min(
                    x - center[0] + size[0] / 2,
                    center[0] + size[0] / 2 - x,
                    y - center[1] + size[1] / 2,
                    center[1] + size[1] / 2 - y,
                    front - x - 0.018,
                )
                for obj in objects:
                    p = vec(obj["pos"])
                    s = vec(obj["size"])
                    dx = max(abs(x - p[0]) - s[0] / 2, 0.0)
                    dy = max(abs(y - p[1]) - s[1] / 2, 0.0)
                    clearance = min(clearance, math.hypot(dx, dy))
                score = clearance - 0.015 * abs(y - center[1])
                if clearance >= margin and score > best:
                    best = score
                    target = vec([x, y, float(drawer["floor_z"]) + height / 2 + 0.01])
    if target is None:
        return

    held = False
    axis = vec([-math.sin(yaw), math.cos(yaw), 0.0])
    for correction in [0.0, 0.007, -0.007, 0.012]:
        before = vec(cup["pos"])
        grasp = before + correction * axis
        # Keep fingertips above the counter despite vertical perception bias.
        grasp[2] = max(grasp[2], top + height * 0.52)
        side_y = grasp[1] - math.copysign(0.12, grasp[1])
        api.open_gripper()
        move([0.45, side_y, high], yaw)
        move([grasp[0], side_y, top + 0.12], yaw)
        move([grasp[0], grasp[1], max(top + 0.075, grasp[2] + 0.045)], yaw)
        result = move(grasp, yaw, 0.09)
        if not result["reached"]:
            move(grasp, yaw, 0.08)
        width = api.close_gripper()
        if 0.018 < width < 0.075:
            p = vec(api.get_ee()["pos"])
            move([p[0] - 0.015, side_y, p[2] + 0.09], yaw, 0.13)
            after = vec(api.get_cup()["pos"])
            if after[2] > before[2] + 0.035:
                held = True
                offset = after - vec(api.get_ee()["pos"])
                break
        api.open_gripper()
        p = vec(api.get_ee()["pos"])
        move([p[0], p[1], top + 0.10], yaw)
        cup = api.get_cup()

    if not held:
        return

    p = vec(api.get_ee()["pos"])
    move([0.46, p[1], high], yaw, 0.20)
    destination = target - offset
    move([destination[0], destination[1], high], yaw)
    move([destination[0], destination[1], destination[2] + 0.055], yaw, 0.16)
    result = move(destination, yaw, 0.08)
    if not result["reached"]:
        result = move(destination, yaw, 0.08)
    if not result["reached"]:
        return
    api.open_gripper()
    api.wait(0.3)
    p = vec(api.get_ee()["pos"])
    move([p[0], p[1], high], yaw)

    for attempt in range(3):
        width = handle_grasp()
        if 0.004 < width < 0.055:
            p = vec(api.get_ee()["pos"])
            move([front - 0.012, p[1], p[2]], 0.0, 0.12)
            # Maintain forward pressure through tracking and perception error.
            p = vec(api.get_ee()["pos"])
            move([front + 0.008, p[1], p[2]], 0.0, 0.08)
        leave_handle()
        d = api.get_drawer()
        if float(d["opening"]) < 0.004:
            break
