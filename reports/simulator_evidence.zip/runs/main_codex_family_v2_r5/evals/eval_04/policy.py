import math
import numpy as np


def run(api):
    def v(p):
        return np.asarray(p, dtype=float)

    def move(p, yaw=None, speed=0.28):
        return api.move_to([float(q) for q in p], yaw=yaw, speed=speed)

    counter = api.get_counter()
    top = float(counter["top_z"])
    front = float(counter["front_x"])
    high = top + 0.16
    objects = api.get_objects()

    def handle_grasp():
        h = v(api.get_handle()["pos"])
        p = v(api.get_ee()["pos"])
        move([p[0], p[1], max(high, p[2])])
        x = max(0.20, h[0] - 0.065)
        move([x, h[1], high], 0.0)
        api.open_gripper()
        move([x, h[1], h[2]], 0.0, 0.15)
        move(h, 0.0, 0.09)
        return api.close_gripper()

    drawer = api.get_drawer()
    for _ in range(3):
        if float(drawer["opening"]) >= 0.285:
            break
        width = handle_grasp()
        if 0.004 < width < 0.055:
            p = v(api.get_ee()["pos"])
            p[0] -= max(0.0, 0.31 - float(drawer["opening"]))
            move(p, 0.0, 0.13)
        api.open_gripper()
        p = v(api.get_ee()["pos"])
        move([p[0], p[1], high])
        drawer = api.get_drawer()

    cup = api.get_cup()
    radius = float(cup["radius"])
    height = float(cup["height"])
    yaw = (float(cup["yaw"]) + math.pi / 2) % math.pi - math.pi / 2
    objects = api.get_objects()
    center = v(drawer["interior_center"])
    size = v(drawer["interior_size"])
    margin = radius + 0.033
    xmin = center[0] - size[0] / 2 + margin
    xmax = min(center[0] + size[0] / 2 - margin, front - margin - 0.018)
    ymin = center[1] - size[1] / 2 + margin
    ymax = center[1] + size[1] / 2 - margin
    target = None
    best = -1.0
    if xmin <= xmax:
        for x in np.linspace(xmin, xmax, 17):
            for y in np.linspace(ymin, ymax, 23):
                clearance = min(
                    x - center[0] + size[0] / 2,
                    center[0] + size[0] / 2 - x,
                    y - center[1] + size[1] / 2,
                    center[1] + size[1] / 2 - y,
                    front - x - 0.018,
                )
                for obj in objects:
                    p, s = v(obj["pos"]), v(obj["size"])
                    dx = max(abs(x - p[0]) - s[0] / 2, 0.0)
                    dy = max(abs(y - p[1]) - s[1] / 2, 0.0)
                    clearance = min(clearance, math.hypot(dx, dy))
                score = clearance - 0.02 * abs(y - center[1])
                if clearance >= margin and score > best:
                    best = score
                    target = v([x, y, float(drawer["floor_z"]) + height / 2 + 0.007])
    if target is None:
        return

    axis = v([-math.sin(yaw), math.cos(yaw), 0.0])
    held = False
    for correction in [0.0, 0.007, -0.007]:
        before = v(cup["pos"])
        grasp = before + correction * axis
        nearby = [
            o for o in objects
            if o["location"] == "counter"
            and np.linalg.norm(v(o["pos"])[:2] - before[:2]) < 0.19
        ]
        api.open_gripper()
        if nearby:
            side_y = grasp[1] - math.copysign(0.12, grasp[1])
            move([0.45, side_y, high], yaw)
            move([grasp[0], side_y, top + 0.12], yaw)
        above = grasp.copy()
        above[2] = max(top + 0.075, grasp[2] + 0.045)
        move(above, yaw)
        move(grasp, yaw, 0.10)
        width = api.close_gripper()
        if 0.015 < width < 0.075:
            p = v(api.get_ee()["pos"])
            raised = p.copy()
            if nearby:
                raised[1] -= math.copysign(0.075, grasp[1])
                raised[2] += 0.105
            else:
                raised[0] -= 0.075
                raised[2] += 0.075
            move(raised, yaw, 0.14)
            after = v(api.get_cup()["pos"])
            if after[2] > before[2] + 0.035:
                held = True
                offset = after - v(api.get_ee()["pos"])
                break
        api.open_gripper()
        p = v(api.get_ee()["pos"])
        move([p[0], p[1], top + 0.115], yaw)
        cup = api.get_cup()
    if not held:
        return

    p = v(api.get_ee()["pos"])
    move([0.46, p[1], high], yaw, 0.20)
    destination = target - offset
    move([destination[0], destination[1], high], yaw)
    move([destination[0], destination[1], destination[2] + 0.05], yaw, 0.16)
    result = move(destination, yaw, 0.08)
    if not result["reached"]:
        move(destination, yaw, 0.08)
    api.open_gripper()
    api.wait(0.3)
    p = v(api.get_ee()["pos"])
    move([p[0], p[1], high], yaw)

    # Push on the lower front panel, clear of both the handle and counter.
    # Keep the fingers closed so they cannot hook the handle during withdrawal.
    drawer = api.get_drawer()
    center = v(drawer["interior_center"])
    push_y = center[1] + 0.16
    push_z = float(drawer["floor_z"]) + 0.045
    opening = float(drawer["opening"])
    panel_x = front - opening
    move([max(0.21, panel_x - 0.09), push_y, high], 0.0)
    api.close_gripper()
    move([max(0.21, panel_x - 0.09), push_y, push_z], 0.0, 0.15)
    move([front + 0.025, push_y, push_z], 0.0, 0.10)
    api.wait(0.3)
    move([front + 0.025, push_y, push_z], 0.0, 0.08)
    p = v(api.get_ee()["pos"])
    move([p[0] - 0.08, p[1], p[2]], 0.0, 0.15)
    move([p[0] - 0.08, p[1], high], 0.0)
    api.open_gripper()
