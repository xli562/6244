import math
import numpy as np


def run(api):
    def vec(p):
        return np.asarray(p, dtype=float)

    def move(p, yaw=None, speed=0.35):
        p = [float(v) for v in p]
        result = api.move_to(p, yaw=yaw, speed=speed)
        if not result["reached"]:
            result = api.move_to(p, yaw=yaw, speed=0.20)
        return result["reached"]

    counter = api.get_counter()
    objects = api.get_objects()
    safe_z = max(
        [float(counter["top_z"]) + 0.19, 0.48]
        + [
            float(o["pos"][2]) + float(o["size"][2]) / 2 + 0.14
            for o in objects
        ]
    )

    def lift():
        p = vec(api.get_ee()["pos"])
        p[2] = safe_z
        return move(p)

    def approach_handle():
        h = vec(api.get_handle()["pos"])
        lift()
        approach = h.copy()
        approach[0] -= 0.075
        above = approach.copy()
        above[2] = safe_z
        if not move(above, 0.0):
            return False
        api.open_gripper()
        if not move(approach, 0.0):
            return False
        return move(h, 0.0, 0.12)

    def release_handle():
        api.open_gripper()
        p = vec(api.get_ee()["pos"])
        p[0] -= 0.065
        move(p, speed=0.20)
        lift()

    # Expose enough of the drawer for a vertical insertion.
    for _ in range(3):
        drawer = api.get_drawer()
        opening = float(drawer["opening"])
        if opening >= 0.415:
            break
        if not approach_handle():
            release_handle()
            continue
        width = api.close_gripper()
        if width < 0.004:
            release_handle()
            continue
        p = vec(api.get_ee()["pos"])
        p[0] -= max(0.0, 0.445 - opening)
        move(p, 0.0, 0.20)
        release_handle()

    drawer = api.get_drawer()
    if float(drawer["opening"]) < 0.29:
        api.log("Could not expose sufficient drawer space.")
        return

    cup = api.get_cup()
    radius = float(cup["radius"])
    height = float(cup["height"])
    grasp_yaw = float(cup["yaw"])

    def choose_place():
        d = api.get_drawer()
        c = vec(d["interior_center"])
        size = vec(d["interior_size"])
        obs = api.get_objects()
        # Include the handle, perception uncertainty, and wall clearance.
        margin = max(radius + 0.034, 0.066)
        xmin = c[0] - size[0] / 2 + margin
        xmax = min(
            c[0] + size[0] / 2 - margin,
            float(counter["front_x"]) - margin - 0.022,
        )
        ymin = c[1] - size[1] / 2 + margin
        ymax = c[1] + size[1] / 2 - margin
        if xmin > xmax or ymin > ymax:
            return None
        best = None
        best_score = -float("inf")
        for x in np.linspace(xmin, xmax, 19):
            for y in np.linspace(ymin, ymax, 23):
                clearance = min(
                    x - (c[0] - size[0] / 2),
                    c[0] + size[0] / 2 - x,
                    y - (c[1] - size[1] / 2),
                    c[1] + size[1] / 2 - y,
                    float(counter["front_x"]) - x - 0.022,
                )
                valid = True
                for o in obs:
                    p = vec(o["pos"])
                    s = vec(o["size"])
                    dx = max(abs(x - p[0]) - s[0] / 2, 0.0)
                    dy = max(abs(y - p[1]) - s[1] / 2, 0.0)
                    distance = math.hypot(dx, dy)
                    if distance < margin:
                        valid = False
                        break
                    clearance = min(clearance, distance)
                if valid:
                    score = clearance - 0.025 * abs(y - c[1])
                    if score > best_score:
                        best_score = score
                        best = np.array(
                            [x, y, float(d["floor_z"]) + height / 2 + 0.009]
                        )
        return best

    target = choose_place()
    if target is None:
        api.log("No clear exposed placement region.")
        return

    held = False
    offset = np.zeros(3)
    # Small lateral corrections address systematic cup-position error.
    corrections = [0.0, 0.007, -0.007, 0.012, -0.012]
    closing_axis = np.array(
        [-math.sin(grasp_yaw), math.cos(grasp_yaw), 0.0]
    )
    for correction in corrections:
        cup = api.get_cup()
        before = vec(cup["pos"])
        grasp = before + correction * closing_axis
        lift()
        api.open_gripper()
        above = grasp.copy()
        above[2] = safe_z
        if not move(above, grasp_yaw):
            continue
        if not move(grasp, grasp_yaw, 0.12):
            lift()
            continue
        width = api.close_gripper()
        if width < 0.012:
            api.open_gripper()
            lift()
            continue
        test = vec(api.get_ee()["pos"])
        test[2] += 0.085
        move(test, grasp_yaw, 0.15)
        after = vec(api.get_cup()["pos"])
        if after[2] - before[2] > 0.045:
            held = True
            offset = after - vec(api.get_ee()["pos"])
            break
        api.open_gripper()
        lift()

    if not held:
        api.log("Cup grasp could not be verified.")
        return

    lift()
    target = choose_place()
    if target is None:
        api.log("Placement region became unavailable.")
        return

    destination = target - offset
    above = destination.copy()
    above[2] = safe_z
    if not move(above, grasp_yaw):
        return

    # Descend vertically, keeping the upright cup clear of the counter edge.
    preplace = destination.copy()
    preplace[2] += 0.055
    if not move(preplace, grasp_yaw, 0.18):
        return
    if not move(destination, grasp_yaw, 0.08):
        lift()
        return
    api.open_gripper()
    api.wait(0.35)
    lift()

    placed = api.get_cup()
    d = api.get_drawer()
    pc = vec(placed["pos"])
    dc = vec(d["interior_center"])
    ds = vec(d["interior_size"])
    if (
        abs(pc[0] - dc[0]) > ds[0] / 2 - radius
        or abs(pc[1] - dc[1]) > ds[1] / 2 - radius
        or pc[2] > float(d["floor_z"]) + height + 0.025
    ):
        api.log("Cup placement could not be verified; leaving drawer open.")
        return

    for _ in range(3):
        opening = float(api.get_drawer()["opening"])
        if opening <= 0.006:
            break
        if not approach_handle():
            release_handle()
            continue
        width = api.close_gripper()
        if width < 0.004:
            release_handle()
            continue
        p = vec(api.get_ee()["pos"])
        p[0] += opening + 0.012
        move(p, 0.0, 0.16)
        release_handle()

    api.open_gripper()
