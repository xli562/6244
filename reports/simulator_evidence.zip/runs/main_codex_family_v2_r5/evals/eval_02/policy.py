import math
import numpy as np


def run(api):
    def v(p):
        return np.array(p, dtype=float)

    def move(p, yaw=None, speed=0.30):
        return api.move_to(
            [float(x) for x in p], yaw=yaw, speed=speed
        )

    counter = api.get_counter()
    top = float(counter["top_z"])
    travel_z = top + 0.115

    def handle_grasp():
        h = v(api.get_handle()["pos"])
        ee = v(api.get_ee()["pos"])
        move([ee[0], ee[1], travel_z])
        move([h[0], h[1], travel_z], 0.0)
        api.open_gripper()
        move(h, 0.0, 0.12)
        return api.close_gripper()

    drawer = api.get_drawer()
    if float(drawer["opening"]) < 0.305:
        for _ in range(2):
            if handle_grasp() > 0.004:
                p = v(api.get_ee()["pos"])
                opening = float(api.get_drawer()["opening"])
                p[0] -= max(0.0, 0.325 - opening)
                move(p, 0.0, 0.17)
            api.open_gripper()
            drawer = api.get_drawer()
            if float(drawer["opening"]) >= 0.285:
                break

    ee = v(api.get_ee()["pos"])
    move([ee[0], ee[1], travel_z])
    drawer = api.get_drawer()
    cup = api.get_cup()
    objects = api.get_objects()
    radius = float(cup["radius"])
    height = float(cup["height"])
    yaw = float(cup["yaw"])

    def placement(d):
        center = v(d["interior_center"])
        size = v(d["interior_size"])
        margin = radius + 0.033
        xmin = center[0] - size[0] / 2 + margin
        xmax = min(
            center[0] + size[0] / 2 - margin,
            float(counter["front_x"]) - margin - 0.018,
        )
        ymin = center[1] - size[1] / 2 + margin
        ymax = center[1] + size[1] / 2 - margin
        if xmin > xmax:
            return None
        best = None
        score_best = -1.0
        for x in np.linspace(xmin, xmax, 15):
            for y in np.linspace(ymin, ymax, 21):
                score = min(
                    x - center[0] + size[0] / 2,
                    center[0] + size[0] / 2 - x,
                    y - center[1] + size[1] / 2,
                    center[1] + size[1] / 2 - y,
                    float(counter["front_x"]) - x - 0.018,
                )
                for obj in objects:
                    p = v(obj["pos"])
                    s = v(obj["size"])
                    dx = max(abs(x - p[0]) - s[0] / 2, 0.0)
                    dy = max(abs(y - p[1]) - s[1] / 2, 0.0)
                    score = min(score, math.hypot(dx, dy))
                if score >= margin and score > score_best:
                    score_best = score
                    best = v([x, y, float(d["floor_z"]) + height / 2 + 0.008])
        return best

    target = placement(drawer)
    if target is None:
        api.log("No clear placement area.")
        return

    held = False
    axis = v([-math.sin(yaw), math.cos(yaw), 0.0])
    for correction in [0.0, 0.008, -0.008]:
        before = v(cup["pos"])
        grasp = before + correction * axis
        api.open_gripper()
        # A high waypoint may be outside reach; the lower grasp can still
        # be reachable, so proceed to it after checking actual position.
        above = grasp.copy()
        above[2] = max(top + 0.075, grasp[2] + 0.045)
        move(above, yaw)
        move(grasp, yaw, 0.10)
        width = api.close_gripper()
        if width > 0.015:
            ee = v(api.get_ee()["pos"])
            raised = ee.copy()
            raised[0] -= 0.075
            raised[2] += 0.075
            move(raised, yaw, 0.14)
            after = v(api.get_cup()["pos"])
            if after[2] > before[2] + 0.035:
                held = True
                offset = after - v(api.get_ee()["pos"])
                break
        api.open_gripper()
        ee = v(api.get_ee()["pos"])
        move([ee[0], ee[1], travel_z], yaw)
        cup = api.get_cup()

    if not held:
        return

    ee = v(api.get_ee()["pos"])
    clearance_z = max(travel_z, top + height / 2 + 0.065)
    for obj in objects:
        if obj["location"] == "counter":
            clearance_z = max(
                clearance_z,
                float(obj["pos"][2]) + float(obj["size"][2]) / 2
                + height / 2 + 0.045,
            )
    move([ee[0], ee[1], clearance_z], yaw)
    destination = target - offset
    move([destination[0], destination[1], clearance_z], yaw)
    move([destination[0], destination[1], destination[2] + 0.05], yaw, 0.18)
    result = move(destination, yaw, 0.08)
    if not result["reached"]:
        result = move(destination, yaw, 0.08)
    if not result["reached"]:
        return
    api.open_gripper()
    api.wait(0.25)
    ee = v(api.get_ee()["pos"])
    move([ee[0], ee[1], travel_z], yaw)

    for _ in range(2):
        drawer = api.get_drawer()
        if float(drawer["opening"]) < 0.005:
            break
        width = handle_grasp()
        if width > 0.004:
            ee = v(api.get_ee()["pos"])
            ee[0] += float(drawer["opening"]) + 0.015
            move(ee, 0.0, 0.16)
        api.open_gripper()
        ee = v(api.get_ee()["pos"])
        move([ee[0], ee[1], travel_z], 0.0)
