"""Robot program for: "Place the cup in the drawer." See TASK.md and API.md."""
import math

import numpy as np

# ---------------------------------------------------------------- constants
CUP_R_DEFAULT = 0.031
CUP_H_DEFAULT = 0.058
HANDLE_HALF_LEN = 0.0715      # half length of the vertical drawer handle bar
HANDLE_GRASP_ZOFF = [0.030, 0.015, 0.0, 0.040]  # fingertip height above grasp point
FAST = 0.20
MED = 0.12
SLOW = 0.06
DRAWER_SPEED = 0.05


# ---------------------------------------------------------------- helpers
def _log(api, msg):
    try:
        api.log(str(msg))
    except Exception:
        pass


def _fmt(p):
    return "[" + ", ".join("%.3f" % float(v) for v in p) + "]"


def wrap_pi(a):
    return (a + math.pi) % (2.0 * math.pi) - math.pi


def wrap_half(a):
    """Wrap to (-pi/2, pi/2] (gripper is symmetric under pi rotation)."""
    a = wrap_pi(a)
    if a > math.pi / 2:
        a -= math.pi
    if a <= -math.pi / 2:
        a += math.pi
    return a


def mv(api, p, yaw=None, speed=MED, tag=""):
    p = [float(p[0]), float(p[1]), float(p[2])]
    if yaw is None:
        r = api.move_to(p, speed=speed)
    else:
        r = api.move_to(p, yaw=float(yaw), speed=speed)
    try:
        reached = r.get("reached", True)
        err = r.get("error", 0.0)
    except Exception:
        reached, err = True, 0.0
    if not reached:
        ee = api.get_ee()["pos"]
        _log(api, "move %s NOT reached err=%.4f target=%s ee=%s" % (tag, err, _fmt(p), _fmt(ee)))
    return reached


def ee_pos(api):
    return np.array(api.get_ee()["pos"], dtype=float)


def travel(api, target, z_travel, yaw=None, speed=FAST, final_speed=SLOW, tag=""):
    """Lift to z_travel, move horizontally above target, descend straight down."""
    target = np.array(target, dtype=float)
    zt = max(z_travel, target[2])
    e = ee_pos(api)
    if e[2] < zt - 0.005:
        mv(api, [e[0], e[1], zt], speed=speed, tag=tag + ":lift")
    mv(api, [target[0], target[1], zt], yaw=yaw, speed=speed, tag=tag + ":over")
    if zt - target[2] > 0.06:
        mv(api, [target[0], target[1], target[2] + 0.05], yaw=yaw, speed=speed, tag=tag + ":down")
    return mv(api, target, yaw=yaw, speed=final_speed, tag=tag + ":final")


def settle_xy(api, p, yaw, tol=0.002, iters=2, max_corr=0.012, tag=""):
    """Re-command the target with the measured residual added (xy only) so the
    fingertips end up within a couple of millimetres of p."""
    p = np.array(p, dtype=float)
    cmd = p.copy()
    for _ in range(iters):
        e = ee_pos(api)
        d = p - e
        d[2] = 0.0
        if np.linalg.norm(d) < tol:
            break
        cmd = cmd + d
        off = cmd - p
        n = np.linalg.norm(off)
        if n > max_corr:
            cmd = p + off * (max_corr / n)
        api.move_to([float(cmd[0]), float(cmd[1]), float(p[2])], yaw=float(yaw), speed=0.04)
    e = ee_pos(api)
    _log(api, "settle %s residual %s" % (tag, _fmt(p - e)))
    return e


def read_cup(api, n=5):
    ps, cs, ss = [], [], []
    r = h = None
    for _ in range(n):
        c = api.get_cup()
        ps.append(c["pos"])
        cs.append(math.cos(c["yaw"]))
        ss.append(math.sin(c["yaw"]))
        r = c.get("radius", CUP_R_DEFAULT)
        h = c.get("height", CUP_H_DEFAULT)
    p = np.mean(np.array(ps, dtype=float), axis=0)
    yaw = math.atan2(np.mean(ss), np.mean(cs))
    return p, yaw, float(r), float(h)


def read_handle(api, n=5):
    ps = [api.get_handle()["pos"] for _ in range(n)]
    return np.mean(np.array(ps, dtype=float), axis=0)


def read_drawer(api, n=3):
    ds = [api.get_drawer() for _ in range(n)]
    out = {
        "opening": float(np.mean([d["opening"] for d in ds])),
        "interior_center": np.mean([d["interior_center"] for d in ds], axis=0),
        "interior_size": np.mean([d["interior_size"] for d in ds], axis=0),
        "floor_z": float(np.mean([d["floor_z"] for d in ds])),
    }
    return out


def box_gap(c1, h1, c2, h2):
    """Separation between two axis-aligned rectangles (negative = overlap)."""
    gx = abs(c1[0] - c2[0]) - (h1[0] + h2[0])
    gy = abs(c1[1] - c2[1]) - (h1[1] + h2[1])
    return max(gx, gy)


def rect_gap_rot(center, along, half_along, half_across, ob_c, ob_h):
    """Approximate gap between a rotated rectangle and an AABB (via its AABB)."""
    ca, sa = abs(math.cos(along)), abs(math.sin(along))
    hx = ca * half_along + sa * half_across
    hy = sa * half_along + ca * half_across
    return box_gap(center, (hx, hy), ob_c, ob_h)


# ---------------------------------------------------------------- drawer
def grasp_handle(api, zoff, z_travel):
    h = read_handle(api)
    _log(api, "handle at %s, grasp zoff %.3f" % (_fmt(h), zoff))
    api.open_gripper()
    target = [h[0] - 0.002, h[1], h[2] + zoff]
    above_z = h[2] + HANDLE_HALF_LEN + 0.10
    ok = travel(api, target, max(z_travel, above_z), yaw=0.0, speed=FAST,
                final_speed=SLOW, tag="handle")
    w = api.close_gripper()
    _log(api, "handle grasp width %.4f reached=%s" % (w, ok))
    return w, ok


def release_handle(api):
    api.open_gripper()
    e = ee_pos(api)
    mv(api, [e[0] - 0.01, e[1], e[2] + 0.12], speed=MED, tag="handle_release")


def move_drawer(api, target, z_travel, tol=0.012):
    for attempt in range(4):
        d = read_drawer(api)["opening"]
        delta = target - d
        _log(api, "drawer opening %.3f -> target %.3f (attempt %d)" % (d, target, attempt))
        if abs(delta) < tol and not (target <= 0.0 and d > 0.006):
            return True
        zoff = HANDLE_GRASP_ZOFF[attempt % len(HANDLE_GRASP_ZOFF)]
        w, ok = grasp_handle(api, zoff, z_travel)
        if w < 0.005 or w > 0.05:
            _log(api, "handle grasp failed (w=%.4f)" % w)
            release_handle(api)
            continue
        e = ee_pos(api)
        dx = -delta
        if target <= 0.0:
            dx += 0.012  # push slightly past the stop to make sure it is shut
        mv(api, [e[0] + dx, e[1], e[2]], speed=DRAWER_SPEED, tag="drawer_slide")
        api.wait(0.2)
        release_handle(api)
    d = read_drawer(api)["opening"]
    _log(api, "drawer final opening %.3f (target %.3f)" % (d, target))
    return abs(d - target) < tol


# ---------------------------------------------------------------- spot search
def find_spot(drawer, D, front_x, objs, strict=True):
    """Find a placement point for the cup centre (world xy) if the drawer were
    opened to D.  Gripper will be at yaw 0 (fingers close along y)."""
    d0 = drawer["opening"]
    cx, cy, _ = drawer["interior_center"]
    sx, sy, _ = drawer["interior_size"]
    floor_z = drawer["floor_z"]
    shift = D - d0
    xmin = cx - sx / 2.0 - shift
    xmax = cx + sx / 2.0 - shift
    ymin = cy - sy / 2.0
    ymax = cy + sy / 2.0
    if strict:
        mx_lo, mx_front, my, req = 0.068, 0.070, 0.112, 0.015
    else:
        mx_lo, mx_front, my, req = 0.058, 0.058, 0.075, 0.006
    x_lo = xmin + mx_lo
    x_hi = min(xmax - 0.06, front_x - mx_front)
    y_lo = ymin + my
    y_hi = ymax - my
    if x_hi < x_lo or y_hi < y_lo:
        return None
    nx = max(2, int((x_hi - x_lo) / 0.01) + 1)
    ny = max(2, int((y_hi - y_lo) / 0.01) + 1)
    best, best_s = None, -1e9
    xm = 0.5 * (x_lo + x_hi)
    for x in np.linspace(x_lo, x_hi, nx):
        for y in np.linspace(y_lo, y_hi, ny):
            gap = 0.08
            for o in objs:
                oc = (o["pos"][0] - shift, o["pos"][1])
                oh = (o["size"][0] / 2.0, o["size"][1] / 2.0)
                top = o["pos"][2] + o["size"][2] / 2.0
                g = box_gap((x, y), (0.056, 0.056), oc, oh)  # cup + open fingers
                if top > floor_z + 0.060:  # tall enough to meet the hand body
                    g = min(g, box_gap((x, y), (0.045, 0.110), oc, oh))
                gap = min(gap, g)
            if gap < req:
                continue
            s = min(gap, 0.05) - 0.15 * abs(x - xm) - 0.05 * abs(y - cy)
            if s > best_s:
                best_s, best = s, (float(x), float(y), float(gap))
    return best


# ---------------------------------------------------------------- main
def run(api):
    counter = api.get_counter()
    top_z = float(counter["top_z"])
    front_x = float(counter["front_x"])
    all_objs = api.get_objects()
    counter_objs = [o for o in all_objs if o.get("location") == "counter"]
    drawer_objs = [o for o in all_objs if o.get("location") == "drawer"]
    drawer = read_drawer(api)
    cup_p, cup_yaw, cup_r, cup_h = read_cup(api)
    _log(api, "counter top %.3f front %.3f; drawer opening %.3f centre %s size %s floor %.3f"
         % (top_z, front_x, drawer["opening"], _fmt(drawer["interior_center"]),
            _fmt(drawer["interior_size"]), drawer["floor_z"]))
    _log(api, "cup %s yaw %.2f r %.3f h %.3f" % (_fmt(cup_p), cup_yaw, cup_r, cup_h))
    for o in all_objs:
        _log(api, "obj %s %s size %s %s" % (o["name"], _fmt(o["pos"]), _fmt(o["size"]), o["location"]))

    max_top = top_z
    for o in counter_objs:
        max_top = max(max_top, o["pos"][2] + o["size"][2] / 2.0)
    # fingertip height for carrying the cup over everything on the counter
    z_safe = min(max(top_z + 0.18, max_top + 0.12), 0.70)
    # fingertip height for moves in front of the counter (drawer area)
    z_front = max(top_z + 0.08, drawer["floor_z"] + 0.30)

    # ---- 1. decide how far the drawer must be open, and open it
    d0 = drawer["opening"]
    plan = None
    if d0 <= 0.37:
        s = find_spot(drawer, d0, front_x, drawer_objs, strict=True)
        if s is not None:
            plan = (d0, s)
    if plan is None:
        for strict in (True, False):
            for D in (0.25, 0.28, 0.31, 0.22, 0.34, 0.37, 0.19, 0.40, 0.44):
                s = find_spot(drawer, D, front_x, drawer_objs, strict=strict)
                if s is not None:
                    plan = (D, s)
                    break
            if plan is not None:
                break
    if plan is None:
        plan = (0.30, None)
    _log(api, "plan: opening %.3f spot %s" % (plan[0], plan[1]))

    if abs(plan[0] - d0) > 0.012:
        e = ee_pos(api)
        if e[2] < z_safe:
            mv(api, [e[0], e[1], z_safe], speed=FAST, tag="init_lift")
        move_drawer(api, plan[0], z_front)
        e = ee_pos(api)
        mv(api, [e[0], e[1], max(e[2], z_front)], speed=FAST, tag="post_drawer_lift")

    # re-perceive the drawer at its actual position and choose the final spot
    drawer = read_drawer(api)
    drawer_objs = [o for o in api.get_objects() if o.get("location") == "drawer"]
    spot = find_spot(drawer, drawer["opening"], front_x, drawer_objs, strict=True)
    if spot is None:
        spot = find_spot(drawer, drawer["opening"], front_x, drawer_objs, strict=False)
    if spot is None:
        cx, cy, _ = drawer["interior_center"]
        sx = drawer["interior_size"][0]
        spot = (min(front_x - 0.06, cx - sx / 2.0 + 0.10), cy, 0.0)
        _log(api, "no clean spot found, using fallback")
    _log(api, "drawer opening now %.3f; place spot %s" % (drawer["opening"], _fmt(spot)))

    # ---- 2. pick the cup
    held = False
    grasp_off = 0.0
    for attempt in range(3):
        cup_p, cup_yaw, cup_r, cup_h = read_cup(api)
        # choose gripper yaw: fingers close perpendicular to the handle direction
        best_g, best_s = None, -1e9
        for k_deg in (0, 15, -15, 30, -30):
            g = wrap_half(cup_yaw + math.radians(k_deg))
            close_dir = g + math.pi / 2.0  # direction the fingers close along
            gap = 0.08
            for o in counter_objs:
                oc = (o["pos"][0], o["pos"][1])
                oh = (o["size"][0] / 2.0, o["size"][1] / 2.0)
                otop = o["pos"][2] + o["size"][2] / 2.0
                gg = rect_gap_rot(cup_p[:2], close_dir, 0.056, 0.014, oc, oh)
                if otop > cup_p[2] + 0.04:
                    gg = min(gg, rect_gap_rot(cup_p[:2], close_dir, 0.110, 0.040, oc, oh))
                gap = min(gap, gg)
            s = min(gap, 0.03) - 0.0002 * abs(k_deg)
            if s > best_s:
                best_s, best_g = s, g
        g = best_g
        cup_top = cup_p[2] + cup_h / 2.0
        # Grasp the upper band of the cup body: the handle sits lower (around
        # mid-height) and fingers lowered further can land on it.
        grasp_z = max(cup_top - 0.017, top_z + 0.020)
        grasp_off = cup_p[2] - grasp_z  # cup centre above fingertips (negative)
        _log(api, "pick attempt %d: cup %s yaw %.2f -> gripper yaw %.2f, z %.3f"
             % (attempt, _fmt(cup_p), cup_yaw, g, grasp_z))
        api.open_gripper()
        hover_z = cup_top + 0.012
        probe_z = grasp_z
        travel(api, [cup_p[0], cup_p[1], hover_z + 0.04], z_safe, yaw=g, speed=FAST,
               final_speed=MED, tag="cup_above")
        # probe at rim height: if a finger lands on the rim, shift along the
        # closing axis instead of pushing the cup over / wedging it.
        axis = np.array([-math.sin(g), math.cos(g), 0.0])  # finger closing axis
        gx, gy = cup_p[0], cup_p[1]
        for shift in (0.0, 0.007, -0.007):
            tx, ty = cup_p[0] + shift * axis[0], cup_p[1] + shift * axis[1]
            mv(api, [tx, ty, hover_z], yaw=g, speed=MED, tag="cup_hover")
            settle_xy(api, [tx, ty, hover_z], g, tag="cup_hover")
            mv(api, [tx, ty, probe_z], yaw=g, speed=0.025, tag="cup_probe")
            e = ee_pos(api)
            if e[2] - probe_z < 0.007:
                gx, gy = tx, ty
                break
            _log(api, "rim contact at shift %.3f (ee z %.4f vs %.4f)" % (shift, e[2], probe_z))
            mv(api, [tx, ty, hover_z], yaw=g, speed=0.04, tag="cup_unprobe")
        else:
            gx, gy = cup_p[0], cup_p[1]
            mv(api, [gx, gy, hover_z], yaw=g, speed=0.04, tag="cup_hover2")
            mv(api, [gx, gy, grasp_z], yaw=g, speed=0.025, tag="cup_descend")
        e = ee_pos(api)
        _log(api, "at grasp: ee %s target %s" % (_fmt(e), _fmt([gx, gy, grasp_z])))
        w = api.close_gripper()
        _log(api, "cup grasp width %.4f" % w)
        if w < 0.035 or w > 0.079:
            api.open_gripper()
            api.wait(0.3)
            e = ee_pos(api)
            mv(api, [e[0], e[1], e[2] + 0.08], speed=0.03, tag="cup_retry_lift")
            continue
        mv(api, [gx, gy, grasp_z + 0.03], speed=0.04, tag="cup_lift")
        c2, _, _, _ = read_cup(api, n=3)
        if c2[2] - cup_p[2] < 0.012:
            _log(api, "cup did not rise with gripper (dz %.4f)" % (c2[2] - cup_p[2]))
            api.open_gripper()
            e = ee_pos(api)
            mv(api, [e[0], e[1], e[2] + 0.08], speed=0.03, tag="cup_retry_lift")
            continue
        e = ee_pos(api)
        mv(api, [e[0], e[1], z_safe], speed=MED, tag="cup_lift2")
        w2 = api.get_ee()["gripper_width"]
        if w2 < 0.02:
            _log(api, "cup lost after lift (w=%.4f)" % w2)
            api.open_gripper()
            continue
        held = True
        break
    if not held:
        _log(api, "failed to pick cup")

    # ---- 3. place the cup in the drawer
    floor_z = drawer["floor_z"]
    place_z = floor_z + 0.005 + cup_h / 2.0 - grasp_off
    _log(api, "placing at %s fingertip z %.3f" % (_fmt(spot[:2]), place_z))
    e = ee_pos(api)
    mv(api, [spot[0], spot[1], z_safe], yaw=0.0, speed=MED, tag="carry")
    mv(api, [spot[0], spot[1], max(z_front, place_z + 0.12)], yaw=0.0, speed=MED, tag="carry_down")
    mv(api, [spot[0], spot[1], place_z + 0.03], yaw=0.0, speed=MED, tag="place_approach")
    mv(api, [spot[0], spot[1], place_z], yaw=0.0, speed=0.03, tag="place")
    api.wait(0.2)
    api.open_gripper()
    api.wait(0.3)
    e = ee_pos(api)
    mv(api, [e[0], e[1], e[2] + 0.06], speed=0.05, tag="place_retreat")
    mv(api, [e[0], e[1], z_front], speed=MED, tag="place_retreat2")
    c, cyaw, _, _ = read_cup(api, n=3)
    _log(api, "cup after place %s" % _fmt(c))

    # ---- 4. close the drawer
    move_drawer(api, 0.0, z_front, tol=0.006)
    e = ee_pos(api)
    mv(api, [e[0] - 0.05, e[1], max(e[2], z_front)], speed=MED, tag="final_retreat")
    d = read_drawer(api)
    c, _, _, _ = read_cup(api, n=3)
    _log(api, "final: drawer opening %.3f, cup %s" % (d["opening"], _fmt(c)))
