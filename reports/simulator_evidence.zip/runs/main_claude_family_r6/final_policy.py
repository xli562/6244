"""Robot program for: "Place the cup in the drawer." See TASK.md and API.md."""
import math

import numpy as np

# ---------------------------------------------------------------- constants
OPEN_W = 0.08            # max gripper opening
FINGER_HALF_X = 0.013    # half thickness of a finger (normal to closing axis)
FINGER_OUT = 0.052       # outer edge of open fingers from gripper centre (along closing axis)
HAND_DROP = 0.045        # conservative: hand body bottom above fingertips
HAND_HALF_LONG = 0.11    # hand half size along closing axis
HAND_HALF_SHORT = 0.04   # hand half size normal to closing axis
CUP_HANDLE_EXT = 0.030   # how far the cup handle sticks out of the body
SAFE_Z = 0.42            # free travel height of fingertips


def _avg(fn, n=4):
    vals = [fn() for _ in range(n)]
    return vals


def _mean_vec(lst):
    return np.mean(np.array(lst, dtype=float), axis=0)


def _wrap_half(a):
    """Wrap angle to (-pi/2, pi/2] (gripper is symmetric under pi)."""
    while a > math.pi / 2:
        a -= math.pi
    while a <= -math.pi / 2:
        a += math.pi
    return a


def _wrap(a):
    while a > math.pi:
        a -= 2 * math.pi
    while a <= -math.pi:
        a += 2 * math.pi
    return a


class Robot:
    def __init__(self, api):
        self.api = api

    def log(self, *a):
        try:
            self.api.log(" ".join(str(x) for x in a))
        except Exception:
            pass

    def ee(self):
        return self.api.get_ee()

    def move(self, pos, yaw=None, speed=0.15, tag=""):
        pos = [float(p) for p in pos]
        if yaw is None:
            r = self.api.move_to(pos, speed=speed)
        else:
            r = self.api.move_to(pos, yaw=float(yaw), speed=speed)
        if not r.get("reached", True):
            self.log("move %s not reached: target=%s err=%.4f ee=%s" % (
                tag, np.round(pos, 3).tolist(), r.get("error", -1),
                np.round(self.ee()["pos"], 3).tolist()))
        return r

    # ------------------------------------------------------------ perception
    def cup(self):
        rs = [self.api.get_cup() for _ in range(4)]
        pos = _mean_vec([r["pos"] for r in rs])
        s = np.mean([math.sin(2 * r["yaw"]) for r in rs])
        c = np.mean([math.cos(2 * r["yaw"]) for r in rs])
        # full yaw (handle direction) from the first reading closest to the mean
        yaw_half = math.atan2(s, c) / 2.0
        y0 = rs[0]["yaw"]
        yaw = yaw_half if abs(_wrap(y0 - yaw_half)) < math.pi / 2 else _wrap(yaw_half + math.pi)
        return {"pos": pos, "yaw": yaw, "radius": float(rs[0]["radius"]),
                "height": float(rs[0]["height"])}

    def handle(self):
        return _mean_vec([self.api.get_handle()["pos"] for _ in range(4)])

    def drawer(self):
        rs = [self.api.get_drawer() for _ in range(4)]
        return {"opening": float(np.mean([r["opening"] for r in rs])),
                "center": _mean_vec([r["interior_center"] for r in rs]),
                "size": _mean_vec([r["interior_size"] for r in rs]),
                "floor_z": float(np.mean([r["floor_z"] for r in rs]))}

    def counter(self):
        rs = [self.api.get_counter() for _ in range(4)]
        return {"top_z": float(np.mean([r["top_z"] for r in rs])),
                "front_x": float(np.mean([r["front_x"] for r in rs]))}

    def objects(self):
        return self.api.get_objects()


# ------------------------------------------------------------------ helpers
def _box_overlap(c1, h1, c2, h2):
    """Axis aligned 2D boxes, centres and half sizes."""
    return (abs(c1[0] - c2[0]) < h1[0] + h2[0]) and (abs(c1[1] - c2[1]) < h1[1] + h2[1])


def _gap(c1, h1, c2, h2):
    """Positive separation distance (chebyshev-ish) between 2D boxes (negative = overlap)."""
    dx = abs(c1[0] - c2[0]) - (h1[0] + h2[0])
    dy = abs(c1[1] - c2[1]) - (h1[1] + h2[1])
    if dx < 0 and dy < 0:
        return max(dx, dy)
    return math.hypot(max(dx, 0.0), max(dy, 0.0))


def grasp_handle(R, z_off=0.015):
    """Go to the drawer handle and close on it. Returns grasp position or None."""
    h = R.handle()
    R.log("handle at", np.round(h, 3).tolist())
    ee = R.ee()["pos"]
    above = [h[0], h[1], max(h[2] + 0.13, SAFE_Z - 0.05)]
    if ee[2] < above[2] - 0.01:
        R.move([ee[0], ee[1], above[2]], speed=0.2, tag="lift")
    R.api.open_gripper()
    R.move(above, yaw=0.0, speed=0.2, tag="above_handle")
    g = [h[0], h[1], h[2] + z_off]
    R.move(g, yaw=0.0, speed=0.08, tag="handle_descend")
    w = R.api.close_gripper()
    R.log("handle grip width %.4f" % w)
    if w < 0.004 or w > 0.05:
        return None
    return np.array(R.ee()["pos"], dtype=float)


def release_up(R, dz=0.12):
    R.api.open_gripper()
    p = R.ee()["pos"]
    R.move([p[0], p[1], max(p[2] + dz, SAFE_Z - 0.05)], speed=0.15, tag="release_up")


def set_drawer(R, target, tol=0.012, tries=3):
    """Drive the drawer to opening `target` by grasping the handle."""
    for k in range(tries):
        d = R.drawer()["opening"]
        R.log("set_drawer try %d: opening %.3f -> %.3f" % (k, d, target))
        if abs(d - target) < tol:
            return d
        gp = None
        for z_off in (0.015, 0.03, 0.0):
            gp = grasp_handle(R, z_off)
            if gp is not None:
                break
            release_up(R)
        if gp is None:
            R.log("could not grasp handle")
            continue
        delta = target - d          # +: open (move -x)
        tgt = [gp[0] - delta, gp[1], gp[2]]
        if target <= 0.0:
            tgt[0] += 0.015         # push past the closed position; the drawer stop holds it
        R.move(tgt, speed=0.08, tag="drawer_move")
        R.api.wait(0.3)
        release_up(R)
    d = R.drawer()["opening"]
    R.log("set_drawer final opening %.3f" % d)
    return d


def close_drawer(R, ct, tries=2):
    """Close the drawer by pushing the handle bar's robot-side face with closed fingers.

    No grasp, so the fingers cannot slip along the bar. The long stroke is done at
    mid-bar height and stops short of closed; the last few cm are pushed higher on
    the bar so the hand body stays above the counter top near the counter front.
    """
    d = R.drawer()["opening"]
    for k in range(tries):
        if k > 0 and d < 0.006:
            break
        h = R.handle()
        closed_x = h[0] + d
        # long stroke at the middle of the bar so the fingers cannot slide over it
        z = h[2] + 0.005
        # final few cm are pushed higher so the hand body stays above the counter top
        z_hi = h[2] + 0.033
        sx = h[0] - 0.045
        R.log("close try %d: opening %.3f handle %s push z %.3f" % (k, d, np.round(h, 3).tolist(), z))
        p = R.ee()["pos"]
        if p[2] < SAFE_Z - 0.06:
            R.move([p[0], p[1], SAFE_Z - 0.05], speed=0.15, tag="close_lift")
        R.move([sx, h[1], SAFE_Z - 0.05], yaw=0.0, speed=0.2, tag="close_above")
        R.api.close_gripper()
        if k > 0:
            # the high push stalled short: finish with a push at mid-bar height,
            # which reliably reaches the drawer stop
            z_hi = z
            R.move([sx, h[1], z], yaw=0.0, speed=0.1, tag="close_descend_lo")
        elif d > 0.06:
            R.move([sx, h[1], z], yaw=0.0, speed=0.1, tag="close_descend")
            # long stroke, stopping ~2-3 cm short of closed
            R.move([closed_x - 0.045, h[1], z], speed=0.08, tag="close_push_long")
            p = R.ee()["pos"]
            R.move([p[0] - 0.025, p[1], z], speed=0.08, tag="close_backoff")
            R.move([p[0] - 0.025, p[1], z_hi], speed=0.08, tag="close_raise")
        else:
            R.move([sx, h[1], z_hi], yaw=0.0, speed=0.1, tag="close_descend_hi")
        # gripper centre target past the closed bar centre: the bar stops the fingers first
        R.move([closed_x + 0.02, h[1], z_hi], speed=0.06, tag="close_push")
        R.api.wait(0.3)
        p = R.ee()["pos"]
        R.move([p[0] - 0.03, p[1], p[2]], speed=0.1, tag="close_back")
        R.move([p[0] - 0.03, p[1], SAFE_Z], speed=0.15, tag="close_up")
        d = R.drawer()["opening"]
    R.log("close final opening %.3f" % d)
    return d


def choose_slot(R, dr, ct, cup_r, handle_sign, hand_low_z):
    """Pick a placement position for the cup centre in the drawer frame.

    Returns (u, v, d_req): u = x offset from drawer interior x-min, v = world y,
    d_req = drawer opening needed so that the slot is reachable from above.
    handle_sign: -1 handle toward -x, +1 toward +x after rotating gripper to yaw 0.
    """
    d0 = dr["opening"]
    cx, cy = dr["center"][0], dr["center"][1]
    sx, sy = dr["size"][0], dr["size"][1]
    xmin0 = cx - sx / 2.0
    ymin, ymax = cy - sy / 2.0, cy + sy / 2.0
    wall_top = dr["floor_z"] + 0.082
    front_x = ct["front_x"]

    # cup footprint (in x: body + handle on one side)
    ext_neg = cup_r + (CUP_HANDLE_EXT if handle_sign < 0 else 0.0)
    ext_pos = cup_r + (CUP_HANDLE_EXT if handle_sign > 0 else 0.0)

    objs = []
    for o in R.objects():
        if o.get("location") != "drawer":
            continue
        p, s = o["pos"], o["size"]
        objs.append((np.array([p[0] - xmin0, p[1]]), np.array([s[0] / 2, s[1] / 2]),
                     p[2] + s[2] / 2.0, o.get("name")))

    best = None
    us = np.arange(ext_neg + 0.015, sx - ext_pos - 0.015, 0.01)
    vs = np.arange(ymin + cup_r + 0.02, ymax - cup_r - 0.02 + 1e-9, 0.01)
    for u in us:
        for v in vs:
            # cup box (x asymmetric -> use centre-shifted box)
            cc = np.array([u + (ext_pos - ext_neg) / 2.0, v])
            ch = np.array([(ext_pos + ext_neg) / 2.0, cup_r])
            fc = np.array([u, v])
            fh = np.array([FINGER_HALF_X, FINGER_OUT])
            hh = np.array([HAND_HALF_SHORT, HAND_HALF_LONG])
            # fingers must stay in drawer in y
            if v - FINGER_OUT < ymin + 0.005 or v + FINGER_OUT > ymax - 0.005:
                continue
            # hand vs walls if it is lower than the wall tops
            if hand_low_z < wall_top + 0.015:
                if v - HAND_HALF_LONG < ymin or v + HAND_HALF_LONG > ymax:
                    continue
            clear = 1.0
            ok = True
            for (oc, oh, otop, _n) in objs:
                g1 = _gap(cc, ch, oc, oh)
                g2 = _gap(fc, fh, oc, oh)
                gm = min(g1 - 0.02, g2 - 0.012)
                if otop > hand_low_z - 0.02:
                    gm = min(gm, _gap(fc, hh, oc, oh) - 0.01)
                if gm < 0:
                    ok = False
                    break
                clear = min(clear, gm)
            if not ok:
                continue
            # opening needed: cup centre world x = xmin0 - (d - d0) + u <= front_x - 0.10
            d_req = d0 + (xmin0 + u) - (front_x - 0.10)
            d_req = max(d_req, 0.0)
            cost = 0.0
            if d_req > d0:
                cost += 3.0 * (d_req - d0) + 0.05
            else:
                # no pulling needed; prefer close to the counter (more reachable)
                xw = xmin0 + u
                cost += 0.5 * abs((front_x - 0.10) - xw)
            cost += 0.3 * abs(v - cy)
            cost -= 0.5 * min(clear, 0.05)
            if best is None or cost < best[0]:
                best = (cost, u, v, d_req, clear)
    return best


def run(api):
    R = Robot(api)
    ct = R.counter()
    dr = R.drawer()
    cup = R.cup()
    ee = R.ee()
    R.log("start ee", np.round(ee["pos"], 3).tolist(), "yaw %.2f w %.3f" % (ee["yaw"], ee["gripper_width"]))
    R.log("counter", ct)
    R.log("drawer opening %.3f centre %s size %s floor %.3f" % (
        dr["opening"], np.round(dr["center"], 3).tolist(), np.round(dr["size"], 3).tolist(), dr["floor_z"]))
    R.log("cup", np.round(cup["pos"], 3).tolist(), "yaw %.2f r %.3f h %.3f" % (cup["yaw"], cup["radius"], cup["height"]))
    for o in R.objects():
        R.log("obj", o.get("name"), o.get("location"), np.round(o["pos"], 3).tolist(), np.round(o["size"], 3).tolist())

    cup_r, cup_h = cup["radius"], cup["height"]
    phi = _wrap_half(cup["yaw"])
    # after rotating gripper from phi to 0, the cup yaw becomes cup_yaw - phi (0 or pi)
    rel = _wrap(cup["yaw"] - phi)
    handle_sign = -1 if abs(rel) < math.pi / 2 else +1
    grip_off = -0.01                 # fingertip z relative to cup centre at grasp
    place_tip_z = dr["floor_z"] + cup_h / 2.0 + 0.004 + grip_off
    hand_low_z = place_tip_z + HAND_DROP

    # ------------------------------------------------ 1. choose slot, open drawer
    slot = choose_slot(R, dr, ct, cup_r, handle_sign, hand_low_z)
    if slot is None:
        R.log("no free slot found, using drawer centre")
        d_req = max(dr["opening"], 0.22)
    else:
        _c, u, v, d_req, clear = slot
        R.log("slot u=%.3f v=%.3f d_req=%.3f clear=%.3f" % (u, v, d_req, clear))
    if d_req > dr["opening"] + 0.005:
        target = min(d_req + 0.02, 0.45)
        set_drawer(R, target)
        dr = R.drawer()
        slot = choose_slot(R, dr, ct, cup_r, handle_sign, hand_low_z)
        if slot is not None and slot[3] > dr["opening"] + 0.01:
            R.log("still not open enough (need %.3f have %.3f), pulling again" % (slot[3], dr["opening"]))
            set_drawer(R, min(slot[3] + 0.02, 0.45))
            dr = R.drawer()
            slot = choose_slot(R, dr, ct, cup_r, handle_sign, hand_low_z)

    # place position in world
    cx, cy = dr["center"][0], dr["center"][1]
    xmin = cx - dr["size"][0] / 2.0
    if slot is None:
        px = min(ct["front_x"] - 0.10, cx)
        py = cy
        R.log("fallback place position")
    else:
        px = xmin + slot[1]
        py = slot[2]
        px = min(px, ct["front_x"] - 0.085)
    R.log("place target cup centre (%.3f, %.3f)" % (px, py))

    # ------------------------------------------------ 2. pick the cup
    ee = R.ee()["pos"]
    if ee[2] < SAFE_Z - 0.02:
        R.move([ee[0], ee[1], SAFE_Z], speed=0.2, tag="lift0")
    R.api.open_gripper()
    cup = R.cup()
    phi = _wrap_half(cup["yaw"])
    cp = cup["pos"]
    grasp_z = max(cp[2] + grip_off, ct["top_z"] + 0.008)
    R.move([cp[0], cp[1], SAFE_Z], yaw=phi, speed=0.2, tag="above_cup")
    # refine with a second reading now that we are above it
    cup2 = R.cup()
    cp = cup2["pos"]
    R.move([cp[0], cp[1], cp[2] + 0.08], yaw=phi, speed=0.15, tag="pre_grasp")
    R.move([cp[0], cp[1], grasp_z], yaw=phi, speed=0.06, tag="grasp_descend")
    w = R.api.close_gripper()
    R.log("cup grip width %.4f" % w)
    if w < 0.03:
        # missed: retry once with fresh perception
        R.api.open_gripper()
        R.move([cp[0], cp[1], cp[2] + 0.08], speed=0.1, tag="retry_up")
        cup3 = R.cup()
        cp = cup3["pos"]
        phi = _wrap_half(cup3["yaw"])
        R.move([cp[0], cp[1], cp[2] + 0.08], yaw=phi, speed=0.1, tag="retry_pre")
        R.move([cp[0], cp[1], max(cp[2] + grip_off, ct["top_z"] + 0.008)], yaw=phi, speed=0.05, tag="retry_descend")
        w = R.api.close_gripper()
        R.log("cup regrip width %.4f" % w)

    # lift
    tip = np.array(R.ee()["pos"], dtype=float)
    counter_tops = [ct["top_z"]]
    for o in R.objects():
        if o.get("location") == "counter":
            counter_tops.append(o["pos"][2] + o["size"][2] / 2.0)
    clear_z = max(counter_tops) + 0.04
    # fingertip height so that cup bottom clears everything
    travel_z = max(SAFE_Z, clear_z + (cup_h / 2.0 + grip_off) + 0.0)
    travel_z = min(travel_z, 0.60)
    R.move([tip[0], tip[1], tip[2] + 0.06], speed=0.06, tag="lift_cup_slow")
    R.move([tip[0], tip[1], travel_z], speed=0.15, tag="lift_cup")

    # measure where the cup sits in the hand
    eep = np.array(R.ee()["pos"], dtype=float)
    held = R.cup()
    off = held["pos"] - eep
    R.log("cup in hand offset", np.round(off, 4).tolist())
    if not (abs(off[0]) < 0.03 and abs(off[1]) < 0.03 and -0.03 < off[2] < 0.03):
        R.log("cup offset implausible, ignoring")
        off = np.array([0.0, 0.0, -grip_off])
    # rotate to yaw 0 at travel height, measure again
    R.move([eep[0], eep[1], travel_z], yaw=0.0, speed=0.15, tag="rotate")
    eep = np.array(R.ee()["pos"], dtype=float)
    held = R.cup()
    off2 = held["pos"] - eep
    if abs(off2[0]) < 0.03 and abs(off2[1]) < 0.03 and -0.03 < off2[2] < 0.03:
        off = off2
    R.log("cup offset after rotate", np.round(off, 4).tolist())

    # ------------------------------------------------ 3. place in drawer
    dr = R.drawer()
    tx, ty = px - off[0], py - off[1]
    R.move([tx, ty, travel_z], yaw=0.0, speed=0.15, tag="over_slot")
    tz = dr["floor_z"] + cup_h / 2.0 + 0.004 - off[2]
    R.move([tx, ty, tz + 0.08], yaw=0.0, speed=0.12, tag="slot_descend")
    R.move([tx, ty, tz], yaw=0.0, speed=0.04, tag="slot_place")
    R.api.wait(0.2)
    R.api.open_gripper()
    R.api.wait(0.2)
    p = R.ee()["pos"]
    R.move([p[0], p[1], max(ct["top_z"] + 0.10, p[2] + 0.12)], speed=0.1, tag="leave_cup")
    c = R.cup()
    R.log("cup after place", np.round(c["pos"], 3).tolist())

    # ------------------------------------------------ 4. close drawer
    d = close_drawer(R, ct)
    if d > 0.02:
        R.log("push did not close the drawer, trying grasp-and-push")
        d = set_drawer(R, 0.0, tol=0.012, tries=2)
    R.api.open_gripper()
    p = R.ee()["pos"]
    R.move([p[0] - 0.05, p[1], max(p[2], SAFE_Z)], speed=0.15, tag="retreat")
    c = R.cup()
    R.log("final drawer %.3f cup %s" % (d, np.round(c["pos"], 3).tolist()))
