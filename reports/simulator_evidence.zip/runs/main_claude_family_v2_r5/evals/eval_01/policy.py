"""Robot program for: "Place the cup in the drawer." See TASK.md and API.md.

Strategy
  1. Read perception several times and average.
  2. Pinch the drawer handle (fingers straddle the vertical bar), pull the drawer
     open far enough that a free spot in the drawer can be reached from above
     (the hand must stay in front of the counter face).
  3. Grasp the cup body from above with the closing axis perpendicular to the
     cup handle; retry with lateral offsets if the descent is blocked or the
     grasp width is wrong.
  4. Carry the cup above everything on the counter, rotate it so that the hand
     is narrow along x, lower it onto the drawer floor and release.
  5. Pinch the drawer handle again and push the drawer closed; verify.
"""
import math

import numpy as np

# --- geometry assumptions (Franka hand) -------------------------------------
HAND_HALF_LONG = 0.105   # half extent of the hand along the closing axis
HAND_HALF_SHORT = 0.035  # half extent of the hand across the closing axis
FINGER_LEN = 0.058       # fingertip to bottom of the hand
FINGER_HALF_OPEN = 0.052  # outer half extent of opened fingers along closing axis
CUP_HANDLE_EXT = 0.030   # how far the cup handle sticks out of the body

FAST = 0.2
NORMAL = 0.15
SLOW = 0.06


def _wrap_half(a):
    """Wrap an angle to (-pi/2, pi/2] (gripper is symmetric under pi)."""
    while a > math.pi / 2:
        a -= math.pi
    while a <= -math.pi / 2:
        a += math.pi
    return a


def _wrap(a):
    while a > math.pi:
        a -= 2 * math.pi
    while a <= -math.pi:
        a += 2 * math.pi
    return a


class Robot:
    def __init__(self, api):
        self.api = api

    def log(self, msg):
        try:
            self.api.log(str(msg))
        except Exception:
            pass

    def ee(self):
        e = self.api.get_ee()
        return np.array(e["pos"], dtype=float), float(e["yaw"]), float(e["gripper_width"])

    def move(self, pos, yaw=None, speed=NORMAL, tag=""):
        pos = [float(p) for p in pos]
        if yaw is None:
            r = self.api.move_to(pos, speed=speed)
        else:
            r = self.api.move_to(pos, yaw=float(yaw), speed=speed)
        if not r.get("reached", True):
            p, _, _ = self.ee()
            self.log("move %s not reached: target=%s ee=%s err=%.4f"
                     % (tag, np.round(pos, 4).tolist(), np.round(p, 4).tolist(), r.get("error", -1)))
        return r

    # ---------------- perception (averaged) ---------------------------------
    def cup(self, n=8):
        rs = [self.api.get_cup() for _ in range(n)]
        pos = np.mean([r["pos"] for r in rs], axis=0)
        yaws = [r["yaw"] for r in rs]
        yaw = math.atan2(np.mean([math.sin(y) for y in yaws]), np.mean([math.cos(y) for y in yaws]))
        spread = np.std([r["pos"] for r in rs], axis=0)
        self.log("cup pos=%s yaw=%.3f r=%.4f h=%.4f spread=%s"
                 % (np.round(pos, 4).tolist(), yaw, rs[0]["radius"], rs[0]["height"],
                    np.round(spread, 4).tolist()))
        return {"pos": pos, "yaw": yaw, "radius": float(np.mean([r["radius"] for r in rs])),
                "height": float(np.mean([r["height"] for r in rs]))}

    def handle(self, n=8):
        rs = [self.api.get_handle()["pos"] for _ in range(n)]
        pos = np.mean(rs, axis=0)
        self.log("handle pos=%s spread=%s" % (np.round(pos, 4).tolist(),
                                               np.round(np.std(rs, axis=0), 4).tolist()))
        return pos

    def drawer(self, n=8):
        rs = [self.api.get_drawer() for _ in range(n)]
        d = {
            "opening": float(np.mean([r["opening"] for r in rs])),
            "center": np.mean([r["interior_center"] for r in rs], axis=0),
            "size": np.mean([r["interior_size"] for r in rs], axis=0),
            "floor_z": float(np.mean([r["floor_z"] for r in rs])),
        }
        self.log("drawer opening=%.4f center=%s size=%s floor=%.4f open_spread=%.4f"
                 % (d["opening"], np.round(d["center"], 4).tolist(), np.round(d["size"], 4).tolist(),
                    d["floor_z"], float(np.std([r["opening"] for r in rs]))))
        return d

    def counter(self, n=8):
        rs = [self.api.get_counter() for _ in range(n)]
        c = {"top_z": float(np.mean([r["top_z"] for r in rs])),
             "front_x": float(np.mean([r["front_x"] for r in rs]))}
        self.log("counter top=%.4f front=%.4f" % (c["top_z"], c["front_x"]))
        return c

    def objects(self, n=4):
        reads = [self.api.get_objects() for _ in range(n)]
        out = []
        for i, o in enumerate(reads[0]):
            ps = [r[i]["pos"] for r in reads if len(r) > i and r[i]["name"] == o["name"]]
            ss = [r[i]["size"] for r in reads if len(r) > i and r[i]["name"] == o["name"]]
            out.append({"name": o["name"], "pos": np.mean(ps, axis=0), "size": np.mean(ss, axis=0),
                        "location": o["location"]})
        for o in out:
            self.log("object %s loc=%s pos=%s size=%s" % (o["name"], o["location"],
                                                          np.round(o["pos"], 3).tolist(),
                                                          np.round(o["size"], 3).tolist()))
        return out


# ---------------------------------------------------------------------------
def _rect_gap(a, b):
    """Gap between two axis-aligned rectangles (xmin, xmax, ymin, ymax); negative = overlap."""
    gx = max(b[0] - a[1], a[0] - b[1])
    gy = max(b[2] - a[3], a[2] - b[3])
    if gx < 0 and gy < 0:
        return max(gx, gy)
    return math.hypot(max(gx, 0.0), max(gy, 0.0))


def grasp_handle(R, hpos, z_safe, approach_from_high=True):
    """Pinch the vertical handle bar with yaw 0. Returns True on success."""
    x_h, y_h, z_h = float(hpos[0]), float(hpos[1]), float(hpos[2])
    pre_x = x_h - 0.10
    p, _, _ = R.ee()
    R.api.open_gripper()
    if approach_from_high:
        R.move([p[0], p[1], max(p[2], z_safe)], tag="up")
        R.move([pre_x, y_h, max(p[2], z_safe)], yaw=0.0, speed=FAST, tag="pre-handle-high")
    R.move([pre_x, y_h, z_h], yaw=0.0, tag="pre-handle")
    for dx in (0.004, 0.016, -0.008, 0.026):
        R.move([x_h + dx, y_h, z_h], yaw=0.0, speed=SLOW, tag="to-handle")
        w = R.api.close_gripper()
        R.log("handle grasp dx=%.3f width=%.4f" % (dx, w))
        if 0.006 < w < 0.035:
            return True
        R.api.open_gripper()
    return False


def release_handle(R, z_safe):
    R.api.open_gripper()
    p, _, _ = R.ee()
    R.move([p[0] - 0.08, p[1], p[2]], speed=NORMAL, tag="handle-back")
    R.move([p[0] - 0.08, p[1], z_safe], speed=FAST, tag="handle-up")


def choose_spot(drawer, d_objs, front_x, delta, ext_front, ext_back, floor_z, grasp_off):
    """Find the best cup centre in the drawer after it is pulled by `delta` more.

    Returns (score, x, y, clearance)."""
    cx, cy = drawer["center"][0] - delta, drawer["center"][1]
    sx, sy = drawer["size"][0], drawer["size"][1]
    x_in, x_out = cx - sx / 2, cx + sx / 2
    y_lo, y_hi = cy - sy / 2, cy + sy / 2
    x_max = front_x - HAND_HALF_SHORT - 0.025          # hand must stay in front of counter
    x_min = x_in + ext_front + 0.02
    x_max = min(x_max, x_out - ext_back - 0.02)
    hand_bottom = floor_z + grasp_off + FINGER_LEN
    best = None
    if x_max < x_min:
        return None
    ys = np.linspace(y_lo + HAND_HALF_LONG * 0.7, y_hi - HAND_HALF_LONG * 0.7, 25)
    xs = np.linspace(x_min, x_max, 12)
    for x in xs:
        for y in ys:
            cup_rect = (x - ext_front - 0.005, x + ext_back + 0.005, y - FINGER_HALF_OPEN, y + FINGER_HALF_OPEN)
            hand_rect = (x - HAND_HALF_SHORT, x + HAND_HALF_SHORT, y - HAND_HALF_LONG, y + HAND_HALF_LONG)
            clear = 0.08
            for o in d_objs:
                ox, oy = o["pos"][0] - delta, o["pos"][1]
                hx, hy = o["size"][0] / 2, o["size"][1] / 2
                orect = (ox - hx, ox + hx, oy - hy, oy + hy)
                clear = min(clear, _rect_gap(cup_rect, orect))
                top = o["pos"][2] + o["size"][2] / 2
                if top > hand_bottom - 0.02:
                    clear = min(clear, _rect_gap(hand_rect, orect) + 0.01)
            # wall clearance of the fingers
            clear = min(clear, (y - FINGER_HALF_OPEN) - y_lo + 0.01, y_hi - (y + FINGER_HALF_OPEN) + 0.01)
            score = min(clear, 0.05) - 0.05 * abs(y - cy) - 0.1 * abs(x - (x_max - 0.01))
            if best is None or score > best[0]:
                best = (score, float(x), float(y), float(clear))
    return best


def run(api):
    R = Robot(api)
    t_api = api

    counter = R.counter()
    top_z, front_x = counter["top_z"], counter["front_x"]
    objs = R.objects()
    c_objs = [o for o in objs if o["location"] == "counter"]
    d_objs = [o for o in objs if o["location"] == "drawer"]
    drawer = R.drawer()
    hpos = R.handle()
    cup = R.cup()

    # safe travel height for the fingertips (empty hand)
    max_obj_top = top_z
    for o in c_objs:
        max_obj_top = max(max_obj_top, o["pos"][2] + o["size"][2] / 2)
    cup_top = cup["pos"][2] + cup["height"] / 2
    z_safe = max(top_z + 0.14, max_obj_top + 0.08, cup_top + 0.08)
    R.log("z_safe=%.3f max_obj_top=%.3f" % (z_safe, max_obj_top))

    # --- cup grasp plan --------------------------------------------------------
    r_cup = cup["radius"]
    h_cup = cup["height"]
    a_cup = cup["yaw"]
    g_yaw = _wrap_half(a_cup)                 # closing axis perpendicular to the cup handle
    final_cup_yaw = _wrap(a_cup - g_yaw)      # cup yaw after rotating gripper to yaw 0: 0 or pi
    handle_toward_robot = abs(final_cup_yaw) < math.pi / 2
    ext_front = r_cup + (CUP_HANDLE_EXT if handle_toward_robot else 0.0)
    ext_back = r_cup + (0.0 if handle_toward_robot else CUP_HANDLE_EXT)
    cup_bottom_est = 0.5 * (top_z + (cup["pos"][2] - h_cup / 2))
    grasp_off = min(max(0.42 * h_cup, 0.018), h_cup - 0.02)   # fingertip height above cup bottom
    R.log("grasp yaw=%.3f final cup yaw=%.3f handle_toward_robot=%s"
          % (g_yaw, final_cup_yaw, handle_toward_robot))

    # --- how far to open the drawer ------------------------------------------
    d0 = drawer["opening"]
    max_extra = max(0.0, (hpos[0] - 0.30))      # keep handle reachable (x >= 0.30)
    max_extra = min(max_extra, max(0.0, 0.48 - d0))
    best = None
    chosen_delta = 0.0
    for delta in np.arange(0.0, max_extra + 1e-9, 0.01):
        s = choose_spot(drawer, d_objs, front_x, float(delta), ext_front, ext_back,
                        drawer["floor_z"], grasp_off)
        if s is None:
            continue
        if best is None or s[3] > best[3] + 0.005:
            best, chosen_delta = s, float(delta)
        if s[3] >= 0.04:
            best, chosen_delta = s, float(delta)
            break
    if best is None:
        chosen_delta = max_extra
        best = choose_spot(drawer, d_objs, front_x, chosen_delta, ext_front, ext_back,
                           drawer["floor_z"], grasp_off)
    # pull a bit more than strictly needed so the spot is comfortably reachable
    pull = chosen_delta
    if pull > 0:
        pull = min(pull + 0.03, max_extra)
    R.log("drawer: d0=%.3f chosen_delta=%.3f pull=%.3f spot=%s" % (d0, chosen_delta, pull, str(best)))

    # --- 1. open the drawer --------------------------------------------------
    handle_y_true = float(hpos[1])
    closed_handle_x = float(hpos[0]) + d0
    if pull > 0.005:
        ok = grasp_handle(R, hpos, z_safe)
        if ok:
            p, _, _ = R.ee()
            handle_y_true = float(p[1])
            closed_handle_x = float(p[0]) + d0
            R.move([p[0] - pull, p[1], p[2]], speed=0.08, tag="pull")
            p2, _, w = R.ee()
            R.log("after pull ee=%s width=%.4f" % (np.round(p2, 4).tolist(), w))
            release_handle(R, z_safe)
        else:
            R.log("could not grasp the handle")
            p, _, _ = R.ee()
            R.move([p[0] - 0.08, p[1], p[2]], tag="back")
            R.move([p[0] - 0.08, p[1], z_safe], tag="up")

    # re-perceive the drawer and choose the final spot
    drawer = R.drawer()
    objs2 = R.objects(n=3)
    d_objs = [o for o in objs2 if o["location"] == "drawer"]
    spot = choose_spot(drawer, d_objs, front_x, 0.0, ext_front, ext_back, drawer["floor_z"], grasp_off)
    if spot is None:
        # fall back: front-most reachable point in the centre
        spot = (0, front_x - HAND_HALF_SHORT - 0.03, drawer["center"][1], 0)
    _, px, py, pclear = spot
    R.log("place spot x=%.3f y=%.3f clearance=%.3f" % (px, py, pclear))

    # --- 2. grasp the cup ----------------------------------------------------
    cup = R.cup()
    cpos = cup["pos"]
    a_cup = cup["yaw"]
    g_yaw = _wrap_half(a_cup)
    final_cup_yaw = _wrap(a_cup - g_yaw)
    cup_bottom_est = 0.5 * (top_z + (cpos[2] - h_cup / 2))
    z_grasp = cup_bottom_est + grasp_off
    z_above = cup_bottom_est + h_cup + 0.05
    close_axis = np.array([-math.sin(g_yaw), math.cos(g_yaw), 0.0])

    p, _, _ = R.ee()
    R.move([p[0], p[1], max(p[2], z_safe)], tag="up")
    R.api.open_gripper()
    grasped = False
    offsets = [0.0, 0.012, -0.012, 0.022, -0.022]
    for k, off in enumerate(offsets):
        tgt = cpos + close_axis * off
        R.move([tgt[0], tgt[1], max(z_safe, z_above)], yaw=g_yaw, speed=FAST, tag="above-cup")
        R.move([tgt[0], tgt[1], z_above], yaw=g_yaw, speed=NORMAL, tag="above-cup-low")
        R.move([tgt[0], tgt[1], z_grasp], speed=SLOW, tag="descend-cup")
        p, _, _ = R.ee()
        if p[2] > z_grasp + 0.012:
            R.log("descent blocked at z=%.4f (target %.4f), offset %.3f" % (p[2], z_grasp, off))
            R.move([tgt[0], tgt[1], z_above], speed=SLOW, tag="retreat")
            continue
        w = R.api.close_gripper()
        R.log("cup grasp width=%.4f (expected %.4f)" % (w, 2 * r_cup))
        if 2 * r_cup - 0.025 < w < 2 * r_cup + 0.015:
            grasped = True
            break
        R.api.open_gripper()
        R.move([tgt[0], tgt[1], z_above], speed=SLOW, tag="retreat")
        # refresh perception in case the cup moved
        cpos = R.cup(n=5)["pos"]
    if not grasped:
        R.log("FAILED to grasp the cup")
        return

    p_grasp, _, _ = R.ee()
    grasp_off_actual = p_grasp[2] - cup_bottom_est

    # --- 3. carry to the drawer ----------------------------------------------
    z_carry = max(z_safe, max_obj_top + 0.05 + grasp_off_actual, top_z + 0.06 + grasp_off_actual)
    R.move([p_grasp[0], p_grasp[1], z_carry], speed=0.1, tag="lift")
    w = R.ee()[2]
    R.log("after lift width=%.4f" % w)
    # yaw so the hand is narrow along x
    R.move([px, py, z_carry], yaw=0.0, speed=NORMAL, tag="carry")
    floor_z = drawer["floor_z"]
    z_place = floor_z + grasp_off_actual
    R.move([px, py, z_place + 0.04], yaw=0.0, speed=NORMAL, tag="lower")
    R.move([px, py, z_place - 0.004], speed=0.03, tag="place")
    R.api.wait(0.2)
    R.api.open_gripper()
    R.api.wait(0.3)
    p, _, _ = R.ee()
    R.move([p[0], p[1], p[2] + 0.08], speed=0.08, tag="leave-cup")
    R.move([p[0], p[1], z_safe], speed=NORMAL, tag="leave-cup-up")
    R.cup(n=4)

    # --- 4. close the drawer -------------------------------------------------
    drawer = R.drawer()
    hnow = R.handle()
    h_est_x = closed_handle_x - drawer["opening"]
    if abs(h_est_x - hnow[0]) < 0.025:
        hx = 0.5 * (h_est_x + hnow[0])
    else:
        hx = hnow[0]
    target = np.array([hx, handle_y_true, hnow[2]])
    ok = grasp_handle(R, target, z_safe)
    if ok:
        p, _, _ = R.ee()
        push_to = p[0] + drawer["opening"] + 0.012
        R.move([push_to, p[1], p[2]], speed=0.08, tag="push")
        R.api.open_gripper()
        p, _, _ = R.ee()
        R.move([p[0] - 0.08, p[1], p[2]], tag="back")
    d = R.drawer(n=5)
    if d["opening"] > 0.008:
        # push the front of the handle bar with closed fingers
        hnow = R.handle()
        p, _, _ = R.ee()
        R.api.close_gripper()
        R.move([hnow[0] - 0.06, handle_y_true, hnow[2]], yaw=0.0, tag="pre-push2")
        R.move([hnow[0] + d["opening"] - 0.012, handle_y_true, hnow[2]], speed=0.06, tag="push2")
        p, _, _ = R.ee()
        R.move([p[0] - 0.08, p[1], p[2]], tag="back2")
        R.drawer(n=5)
    p, _, _ = R.ee()
    R.move([p[0], p[1], z_safe], tag="final-up")
    R.cup(n=4)
