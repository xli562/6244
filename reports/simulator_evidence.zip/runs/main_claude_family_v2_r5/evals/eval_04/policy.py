"""Robot program for: "Place the cup in the drawer." See TASK.md and API.md.

Strategy
  1. Perceive once (per-call noise is ~1 mm; the error is mostly a per-episode bias).
     The handle position is fused with the drawer reading and the reconstruction.
  2. Pinch the vertical drawer-handle bar (yaw 0, near its top so the hand stays
     above the counter top) and pull the drawer to ~0.27 open, so that the cup
     spot is reachable from above (hand in front of the counter face) and the
     arm's wrist stays clear of the drawer front panel.  The fingers close
     symmetrically, so a too-wide pinch tells how far the bar is off-centre:
     re-centre and pinch again.
  3. Grasp the cup body from above; the closing axis is roughly perpendicular to
     the cup handle, the exact yaw is chosen to keep clear of nearby objects.
  4. Carry the cup above everything, turn the hand to yaw 0, lower the cup onto
     the drawer floor and release.
  5. Close: push the drawer front panel with closed fingers until the drawer is
     nearly closed, then pinch the handle and push it fully closed (fallback:
     push the bar with closed fingers). Verify and repeat.
"""
import math

import numpy as np

# --- assumptions about the Franka hand / scene ---------------------------------
HAND_HALF_LONG = 0.105    # half extent of the hand along the closing axis
HAND_HALF_SHORT = 0.035   # half extent of the hand across the closing axis
FINGER_LEN = 0.058        # fingertip to bottom of the hand
FINGER_HALF_OPEN = 0.052  # outer half extent of the opened fingers (closing axis)
FINGER_HALF_W = 0.012     # half width of a finger across the closing axis
CUP_HANDLE_EXT = 0.030    # how far the cup handle sticks out of the body
ARM_PANEL_GAP = 0.17      # ee must be this far (+x) beyond the drawer front panel when low
BAR_HALF = 0.008          # half thickness of the handle bar
BAR_STANDOFF = 0.041      # handle bar in front of the drawer front
HANDLE_TO_CENTER = 0.31   # interior centre x minus handle x (from the reconstruction)
SCENE_HANDLE_Y = -0.088
SCENE_HANDLE_CLOSED_X = 0.516

FAST = 0.25
NORMAL = 0.15
SLOW = 0.06


def _wrap_half(a):
    while a > math.pi / 2:
        a -= math.pi
    while a <= -math.pi / 2:
        a += math.pi
    return a


def _wrap(a):
    while a > math.pi:
        a -= 2 * math.pi
    while a <= -math.pi:
        a += 2 * math.pi
    return a


def _median(vals):
    return float(np.median(np.array(vals, dtype=float)))


def _rect_gap(a, b):
    """Gap between axis-aligned rectangles (xmin, xmax, ymin, ymax); <0 = overlap."""
    gx = max(b[0] - a[1], a[0] - b[1])
    gy = max(b[2] - a[3], a[2] - b[3])
    if gx < 0 and gy < 0:
        return max(gx, gy)
    return math.hypot(max(gx, 0.0), max(gy, 0.0))


def _box_points(o, step=0.01):
    """Points on the outline of an object's xy bounding box."""
    x, y = o["pos"][0], o["pos"][1]
    hx, hy = o["size"][0] / 2, o["size"][1] / 2
    pts = []
    nx = max(2, int(2 * hx / step) + 1)
    ny = max(2, int(2 * hy / step) + 1)
    for t in np.linspace(-hx, hx, nx):
        pts.append((x + t, y - hy))
        pts.append((x + t, y + hy))
    for t in np.linspace(-hy, hy, ny):
        pts.append((x - hx, y + t))
        pts.append((x + hx, y + t))
    pts.append((x, y))
    return pts


def _pt_rect_dist(u, v, hu, hv):
    du, dv = abs(u) - hu, abs(v) - hv
    if du <= 0 and dv <= 0:
        return max(du, dv)
    return math.hypot(max(du, 0.0), max(dv, 0.0))


def _seg_dist(p, a, b):
    """Distance from 2-D point p to segment a-b."""
    p, a, b = np.asarray(p, float), np.asarray(a, float), np.asarray(b, float)
    ab = b - a
    L = float(ab @ ab)
    t = 0.0 if L < 1e-12 else min(1.0, max(0.0, float((p - a) @ ab) / L))
    return float(np.linalg.norm(p - (a + t * ab)))


class Robot:
    def __init__(self, api):
        self.api = api
        self.c_objs = []
        self.top_z = 0.29

    def log(self, msg):
        try:
            self.api.log(str(msg))
        except Exception:
            pass

    def ee(self):
        e = self.api.get_ee()
        return np.array(e["pos"], dtype=float), float(e["yaw"]), float(e["gripper_width"])

    def move(self, pos, yaw=None, speed=NORMAL, tag=""):
        pos = [float(p) for p in pos]
        if yaw is None:
            r = self.api.move_to(pos, speed=speed)
        else:
            r = self.api.move_to(pos, yaw=float(yaw), speed=speed)
        if not r.get("reached", True):
            self.log("NOT REACHED %s" % tag)
        return r

    def drawer(self):
        r = self.api.get_drawer()
        return {"opening": float(r["opening"]), "center": np.array(r["interior_center"], dtype=float),
                "size": np.array(r["interior_size"], dtype=float), "floor_z": float(r["floor_z"])}

    def travel_z(self, a, b, below=0.0, ignore_near=None):
        """Fingertip height for a straight move from xy a to xy b that clears all
        counter objects near the path. `below` = how far a carried object hangs
        below the fingertips."""
        z = self.top_z + 0.07 + below
        for o in self.c_objs:
            c = o["pos"][:2]
            rad = 0.5 * math.hypot(o["size"][0], o["size"][1])
            if ignore_near is not None and np.linalg.norm(c - ignore_near) < 1e-9:
                continue
            if _seg_dist(c, a, b) < rad + HAND_HALF_LONG + 0.03:
                z = max(z, o["pos"][2] + o["size"][2] / 2 + 0.035 + below)
        return z

    def transit(self, target, yaw=None, below=0.0, speed=FAST, min_z=None, tag=""):
        """Up, across, down: move the fingertips to `target` avoiding counter objects."""
        p, _, _ = self.ee()
        zt = self.travel_z(p[:2], np.asarray(target[:2], float), below)
        zt = max(zt, target[2])
        if min_z is not None:
            zt = max(zt, min_z)
        if p[2] < zt - 0.005:
            self.move([p[0], p[1], zt], speed=NORMAL, tag=tag + "-up")
        self.move([target[0], target[1], zt], yaw=yaw, speed=speed, tag=tag + "-across")
        if zt > target[2] + 0.005:
            self.move(target, yaw=yaw, speed=NORMAL, tag=tag + "-down")


# ---------------------------------------------------------------------------
def handle_grasp_z(h_z, top_z):
    """Fingertip height for pinching the handle bar: high enough that the hand
    is above the counter top, low enough that the pads stay on the bar."""
    z = top_z - FINGER_LEN + 0.010
    return float(min(max(z, h_z - 0.02), h_z + 0.045))


def pinch_handle(R, x_h, y_h, z_g, y_prior=SCENE_HANDLE_Y):
    """Pinch the vertical handle bar with yaw 0 at fingertip height z_g.
    Returns (ok, y_of_bar)."""
    pre_x = x_h - 0.07
    R.api.open_gripper()
    R.transit([pre_x, y_h, z_g], yaw=0.0, tag="pre-handle")
    closes = 0
    for dx in (0.003, 0.014, -0.009):
        R.move([x_h + dx, y_h, z_g], yaw=0.0, speed=SLOW, tag="to-handle")
        w = R.api.close_gripper()
        closes += 1
        if 0.008 < w < 0.027:
            R.log("pinched dx=%.3f w=%.4f" % (dx, w))
            return True, y_h
        if w >= 0.027 and w < 0.078:
            # the bar is between the fingers but off-centre by about m
            m = min(w / 2 - BAR_HALF - 0.0005, 0.032)
            R.log("pinch off-centre dx=%.3f w=%.4f m=%.3f" % (dx, w, m))
            first = 1.0 if y_prior >= y_h else -1.0
            for sgn in (first, -first):
                R.api.open_gripper()
                R.move([x_h + dx, y_h + sgn * m, z_g], yaw=0.0, speed=SLOW, tag="recentre")
                w2 = R.api.close_gripper()
                if 0.008 < w2 < 0.027:
                    R.log("pinched recentred y%+.3f w=%.4f" % (sgn * m, w2))
                    return True, y_h + sgn * m
                if 0.027 <= w2 < w - 0.006:
                    # got better but not yet good: go a bit further the same way
                    m2 = sgn * (m + (w2 / 2 - BAR_HALF))
                    R.api.open_gripper()
                    R.move([x_h + dx, y_h + m2, z_g], yaw=0.0, speed=SLOW, tag="recentre2")
                    w3 = R.api.close_gripper()
                    if 0.008 < w3 < 0.027:
                        return True, y_h + m2
                    break
            R.api.open_gripper()
            R.move([x_h + dx, y_h, z_g], yaw=0.0, speed=SLOW, tag="recentre-back")
            return False, y_h
        R.log("pinch miss dx=%.3f w=%.4f" % (dx, w))
        R.api.open_gripper()
    return False, y_h


def leave_handle(R):
    """Let go of the handle without dragging the drawer: open, go straight up."""
    R.api.open_gripper()
    p, _, _ = R.ee()
    R.move([p[0], p[1], p[2] + 0.09], speed=0.08, tag="handle-lift")


def choose_spot(drawer, d_objs, front_x, delta, rect, floor_z, grasp_off):
    """Best cup centre in the drawer after it has been pulled `delta` further.
    rect = (dx_min, dx_max, dy_min, dy_max) footprint of cup + handle + open fingers
    relative to the cup centre. Returns (score, x, y, clearance) or None."""
    cx, cy = drawer["center"][0] - delta, drawer["center"][1]
    sx, sy = drawer["size"][0], drawer["size"][1]
    x_in, x_out = cx - sx / 2, cx + sx / 2
    y_lo, y_hi = cy - sy / 2, cy + sy / 2
    x_max = min(front_x - HAND_HALF_SHORT - 0.025, x_out - rect[1] - 0.02)
    x_min = max(x_in - rect[0] + 0.02, x_in - 0.016 + ARM_PANEL_GAP)
    if x_max < x_min - 1e-6:
        return None
    hand_bottom = floor_z + grasp_off + FINGER_LEN
    best = None
    ys = np.linspace(y_lo + HAND_HALF_LONG + 0.005, y_hi - HAND_HALF_LONG - 0.005, 21)
    xs = np.linspace(x_min, max(x_min, x_max), 6)
    for x in xs:
        for y in ys:
            cup_rect = (x + rect[0] - 0.005, x + rect[1] + 0.005, y + rect[2], y + rect[3])
            hand_rect = (x - HAND_HALF_SHORT, x + HAND_HALF_SHORT, y - HAND_HALF_LONG, y + HAND_HALF_LONG)
            clear = 0.08
            for o in d_objs:
                ox, oy = o["pos"][0] - delta, o["pos"][1]
                hx, hy = o["size"][0] / 2, o["size"][1] / 2
                orect = (ox - hx, ox + hx, oy - hy, oy + hy)
                clear = min(clear, _rect_gap(cup_rect, orect))
                if o["pos"][2] + o["size"][2] / 2 > hand_bottom - 0.03:
                    clear = min(clear, _rect_gap(hand_rect, orect))
            clear = min(clear, cup_rect[2] - y_lo, y_hi - cup_rect[3])
            score = min(clear, 0.05) - 0.03 * abs(y - cy) - 0.05 * abs(x - x_max)
            if best is None or score > best[0]:
                best = (score, float(x), float(y), float(clear))
    return best


def cup_grasp_yaw(cup, c_objs, top_z, grasp_off):
    """Pick a gripper yaw near the cup yaw (closing axis perpendicular to the
    handle) that keeps fingers and hand clear of objects on the counter."""
    a = cup["yaw"]
    c = np.array(cup["pos"][:2])
    hand_bottom = top_z + grasp_off + FINGER_LEN
    best = None
    for d_deg in (0, -15, 15, -30, 30, -45, 45):
        g = _wrap_half(a + math.radians(d_deg))
        cax = np.array([-math.sin(g), math.cos(g)])   # closing axis
        tax = np.array([math.cos(g), math.sin(g)])    # across axis
        clear = 0.06
        for o in c_objs:
            tall = (o["pos"][2] + o["size"][2] / 2) > hand_bottom - 0.03
            for (px, py) in _box_points(o):
                rel = np.array([px, py]) - c
                v, u = float(rel @ cax), float(rel @ tax)
                clear = min(clear, _pt_rect_dist(u, v, FINGER_HALF_W + 0.005, FINGER_HALF_OPEN))
                if tall:
                    clear = min(clear, _pt_rect_dist(u, v, HAND_HALF_SHORT, HAND_HALF_LONG))
        score = min(clear, 0.03) - 0.0002 * abs(d_deg)
        if best is None or score > best[0]:
            best = (score, g, clear, d_deg)
    return best


class DrawerModel:
    """Fused estimate of where the drawer handle is."""

    def __init__(self, R, front_x):
        self.R = R
        self.front_x = front_x
        self.closed_x = None
        self.y = None

    def update(self):
        d = self.R.drawer()
        h = np.array(self.R.api.get_handle()["pos"], dtype=float)
        op = d["opening"]
        closed_candidates = [h[0] + op, d["center"][0] - HANDLE_TO_CENTER + op,
                             self.front_x - BAR_STANDOFF]
        if self.closed_x is None:
            self.closed_x = _median(closed_candidates)
        if self.y is None:
            self.y = _median([h[1], d["center"][1], SCENE_HANDLE_Y])
        hx = _median([h[0], d["center"][0] - HANDLE_TO_CENTER, self.closed_x - op])
        return d, hx, float(h[2])


def run(api):
    R = Robot(api)

    counter = api.get_counter()
    top_z, front_x = float(counter["top_z"]), float(counter["front_x"])
    R.top_z = top_z
    objs = [{"name": str(o["name"]), "location": str(o["location"]),
             "pos": np.array(o["pos"], dtype=float), "size": np.array(o["size"], dtype=float)}
            for o in api.get_objects()]
    c_objs = [o for o in objs if o["location"] != "drawer"]
    d_objs = [o for o in objs if o["location"] == "drawer"]
    R.c_objs = c_objs
    DM = DrawerModel(R, front_x)
    drawer, hx, hz = DM.update()
    c0 = api.get_cup()
    cup = {"pos": np.array(c0["pos"], dtype=float), "yaw": float(c0["yaw"]),
           "radius": float(c0["radius"]), "height": float(c0["height"])}
    r_cup, h_cup = cup["radius"], cup["height"]

    # ---- cup grasp plan -------------------------------------------------------
    grasp_off = min(max(0.42 * h_cup, 0.018), h_cup - 0.02)   # fingertips above cup bottom
    gsel = cup_grasp_yaw(cup, c_objs, top_z, grasp_off)
    g_yaw = gsel[1]
    a_f = _wrap(cup["yaw"] - g_yaw)            # cup yaw once the gripper is at yaw 0
    hp = (r_cup + CUP_HANDLE_EXT) * np.array([-math.cos(a_f), -math.sin(a_f)])
    rect = (min(-r_cup, hp[0]), max(r_cup, hp[0]),
            min(-FINGER_HALF_OPEN, hp[1]), max(FINGER_HALF_OPEN, hp[1]))

    # ---- drawer opening plan ----------------------------------------------------
    d0 = drawer["opening"]
    d_hi = min(0.31, d0 + max(0.0, hx - 0.22))
    plan_d, spot = d0, None
    if d0 >= 0.24:
        spot = choose_spot(drawer, d_objs, front_x, 0.0, rect, drawer["floor_z"], grasp_off)
    if spot is None or spot[3] < 0.03:
        best = None
        for d in np.arange(max(0.26, d0 + 0.02), d_hi + 1e-9, 0.01):
            s = choose_spot(drawer, d_objs, front_x, float(d - d0), rect, drawer["floor_z"], grasp_off)
            if s is None:
                continue
            if best is None or s[3] > best[1][3] + 0.005:
                best = (float(d), s)
            if s[3] >= 0.03:
                best = (float(d), s)
                break
        if best is not None and (spot is None or best[1][3] > spot[3] + 0.005):
            plan_d, spot = best
    pull = plan_d - d0
    R.log("plan: d0=%.3f hx=%.3f hy=%.3f closed=%.3f target_open=%.3f spot=%s gyaw=%.2f(%+d) gclear=%.3f"
          % (d0, hx, DM.y, DM.closed_x, plan_d, None if spot is None else
             [round(v, 3) for v in spot[1:]], g_yaw, gsel[3], gsel[2]))

    # ---- 1. open the drawer -----------------------------------------------------
    if pull > 0.005:
        z_g = handle_grasp_z(hz, top_z)
        ok, yb = pinch_handle(R, hx, DM.y, z_g)
        if ok:
            DM.y = yb
            p, _, _ = R.ee()
            R.move([p[0] - pull, p[1], p[2]], speed=0.06, tag="pull")
            R.api.wait(0.2)
            leave_handle(R)
        else:
            R.log("could not pinch the handle for opening")
            p, _, _ = R.ee()
            R.move([p[0] - 0.08, p[1], p[2]], tag="back")

    drawer = R.drawer()
    delta_obs = drawer["opening"] - d0
    spot = choose_spot(drawer, [dict(o, pos=o["pos"] - np.array([delta_obs, 0, 0])) for o in d_objs],
                       front_x, 0.0, rect, drawer["floor_z"], grasp_off)
    if spot is None:
        spot = (0.0, front_x - HAND_HALF_SHORT - 0.03, float(drawer["center"][1]), 0.0)
    _, px, py, pclear = spot
    R.log("opening=%.4f place x=%.3f y=%.3f clear=%.3f" % (drawer["opening"], px, py, pclear))

    # ---- 2. grasp the cup ---------------------------------------------------------
    cpos = cup["pos"]
    cup_bottom_est = 0.5 * (top_z + (cpos[2] - h_cup / 2))
    z_grasp = cup_bottom_est + grasp_off
    z_above = cup_bottom_est + h_cup + 0.035
    cax = np.array([-math.sin(g_yaw), math.cos(g_yaw), 0.0])

    R.api.open_gripper()
    grasped = False
    for off in (0.0, 0.012, -0.012, 0.022):
        tgt = cpos + cax * off
        R.transit([tgt[0], tgt[1], z_above], yaw=g_yaw, tag="cup")
        R.move([tgt[0], tgt[1], z_grasp], speed=SLOW, tag="descend-cup")
        p, _, _ = R.ee()
        if p[2] > z_grasp + 0.012:
            R.log("descent blocked z=%.4f off=%.3f" % (p[2], off))
            R.move([p[0], p[1], z_above], speed=NORMAL, tag="retreat")
            continue
        w = R.api.close_gripper()
        if 2 * r_cup - 0.027 < w < 2 * r_cup + 0.016:
            R.log("cup grasped w=%.4f off=%.3f" % (w, off))
            grasped = True
            break
        R.log("cup grasp bad w=%.4f off=%.3f" % (w, off))
        R.api.open_gripper()
        R.move([p[0], p[1], z_above], speed=SLOW, tag="retreat")
        c2 = api.get_cup()
        cpos = np.array(c2["pos"], dtype=float)
    if not grasped:
        R.log("FAILED to grasp the cup")
        return

    p_grasp, _, _ = R.ee()
    grasp_off_actual = float(p_grasp[2] - cup_bottom_est)

    # ---- 3. carry to the drawer and place ----------------------------------------
    z_place = drawer["floor_z"] + grasp_off_actual
    R.move([p_grasp[0], p_grasp[1], p_grasp[2] + 0.03], speed=0.08, tag="lift")
    R.transit([px, py, z_place + 0.035], yaw=0.0, below=grasp_off_actual, speed=NORMAL,
              min_z=top_z + grasp_off_actual + 0.04, tag="carry")
    R.move([px, py, z_place - 0.004], speed=0.03, tag="place")
    R.api.open_gripper()
    R.api.wait(0.2)
    p, _, _ = R.ee()
    R.move([p[0], p[1], top_z + 0.03], speed=0.08, tag="leave-cup")

    # ---- 4. close the drawer -------------------------------------------------------
    for attempt in range(3):
        drawer, hx, hz = DM.update()
        op = drawer["opening"]
        R.log("close %d: opening=%.4f hx=%.3f hy=%.3f closed=%.3f" % (attempt, op, hx, DM.y, DM.closed_x))
        if op < 0.005 and attempt > 0:
            break
        if op > 0.06:
            # phase A: push the drawer front panel with closed fingers, low, beside the handle
            s = 1.0 if DM.y < 0 else -1.0
            y_push = DM.y + s * 0.13   # hand (+-0.105 in y) must clear the handle bar
            panel_face = hx + BAR_STANDOFF - 0.006
            z_push = float(min(max(drawer["floor_z"] + 0.085, 0.12), top_z - 0.10))
            x_start = panel_face - 0.05
            x_end = front_x - HAND_HALF_SHORT - 0.012
            R.api.close_gripper()
            R.transit([x_start, y_push, z_push], yaw=0.0, tag="panel")
            R.move([x_end, y_push, z_push], speed=0.06, tag="panel-push")
            R.move([x_end - 0.11, y_push, z_push], speed=NORMAL, tag="panel-back")
            drawer, hx, hz = DM.update()
            op = drawer["opening"]
            R.log("after panel push opening=%.4f hx=%.3f" % (op, hx))
        # phase B: pinch the handle and push it home
        z_g = handle_grasp_z(hz, top_z)
        ok, yb = pinch_handle(R, hx, DM.y, z_g)
        if ok:
            DM.y = yb
            p, _, _ = R.ee()
            tgt = min(max(DM.closed_x + 0.010, p[0] + 0.005), front_x - 0.03)
            R.move([tgt, p[1], p[2]], speed=0.05, tag="push")
            R.api.wait(0.2)
            leave_handle(R)
        else:
            # fallback: push the bar with closed fingers at mid height
            R.api.close_gripper()
            p, _, _ = R.ee()
            R.move([p[0], p[1], p[2] + 0.06], tag="bar-up")
            R.transit([hx - 0.05, DM.y, hz], yaw=0.0, tag="bar")
            tgt = min(DM.closed_x - BAR_HALF - 0.010 + 0.006, front_x - 0.045)
            R.move([tgt, DM.y, hz], speed=0.05, tag="bar-push")
            p, _, _ = R.ee()
            R.move([p[0] - 0.04, p[1], p[2]], tag="bar-back")
            R.move([p[0] - 0.04, p[1], p[2] + 0.1], tag="bar-up2")
        d = R.drawer()["opening"]
        R.log("after push opening=%.4f" % d)
        if d < 0.005:
            break
        DM.closed_x += min(max(0.0, d - 0.002), 0.015)
    p, _, _ = R.ee()
    R.move([p[0] - 0.05, p[1], max(p[2], top_z + 0.12)], tag="final-up")
