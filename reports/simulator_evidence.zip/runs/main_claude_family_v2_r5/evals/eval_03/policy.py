"""Robot program for: "Place the cup in the drawer." See TASK.md and API.md.

Strategy
  1. Perceive once (per-call noise is ~1 mm, the error is mostly a bias).
  2. Pinch the vertical drawer-handle bar (yaw 0, near its top so the hand stays
     above the counter top) and pull the drawer to ~0.27 open, so that the cup
     spot is reachable from above (hand in front of the counter face) and the
     arm's wrist stays clear of the drawer front panel.
  3. Grasp the cup body from above; the closing axis is roughly perpendicular to
     the cup handle, the exact yaw is chosen to keep clear of nearby objects.
  4. Carry the cup above everything, turn the hand to yaw 0, lower the cup onto
     the drawer floor and release.
  5. Pinch the handle again, push the drawer closed slowly, verify, repeat.
"""
import math

import numpy as np

# --- assumptions about the Franka hand ---------------------------------------
HAND_HALF_LONG = 0.105    # half extent of the hand along the closing axis
HAND_HALF_SHORT = 0.035   # half extent of the hand across the closing axis
FINGER_LEN = 0.058        # fingertip to bottom of the hand
FINGER_HALF_OPEN = 0.052  # outer half extent of the opened fingers (closing axis)
FINGER_HALF_W = 0.012     # half width of a finger across the closing axis
CUP_HANDLE_EXT = 0.030    # how far the cup handle sticks out of the body
ARM_PANEL_GAP = 0.17      # ee must be this far (+x) beyond the drawer front panel when low

FAST = 0.25
NORMAL = 0.15
SLOW = 0.06


def _wrap_half(a):
    while a > math.pi / 2:
        a -= math.pi
    while a <= -math.pi / 2:
        a += math.pi
    return a


def _wrap(a):
    while a > math.pi:
        a -= 2 * math.pi
    while a <= -math.pi:
        a += 2 * math.pi
    return a


def _rect_gap(a, b):
    """Gap between axis-aligned rectangles (xmin, xmax, ymin, ymax); <0 = overlap."""
    gx = max(b[0] - a[1], a[0] - b[1])
    gy = max(b[2] - a[3], a[2] - b[3])
    if gx < 0 and gy < 0:
        return max(gx, gy)
    return math.hypot(max(gx, 0.0), max(gy, 0.0))


def _box_points(o, step=0.01):
    """Points on the outline of an object's xy bounding box."""
    x, y = o["pos"][0], o["pos"][1]
    hx, hy = o["size"][0] / 2, o["size"][1] / 2
    pts = []
    nx = max(2, int(2 * hx / step) + 1)
    ny = max(2, int(2 * hy / step) + 1)
    for t in np.linspace(-hx, hx, nx):
        pts.append((x + t, y - hy))
        pts.append((x + t, y + hy))
    for t in np.linspace(-hy, hy, ny):
        pts.append((x - hx, y + t))
        pts.append((x + hx, y + t))
    pts.append((x, y))
    return pts


def _pt_rect_dist(u, v, hu, hv):
    du, dv = abs(u) - hu, abs(v) - hv
    if du <= 0 and dv <= 0:
        return max(du, dv)
    return math.hypot(max(du, 0.0), max(dv, 0.0))


class Robot:
    def __init__(self, api):
        self.api = api

    def log(self, msg):
        try:
            self.api.log(str(msg))
        except Exception:
            pass

    def ee(self):
        e = self.api.get_ee()
        return np.array(e["pos"], dtype=float), float(e["yaw"]), float(e["gripper_width"])

    def move(self, pos, yaw=None, speed=NORMAL, tag=""):
        pos = [float(p) for p in pos]
        if yaw is None:
            r = self.api.move_to(pos, speed=speed)
        else:
            r = self.api.move_to(pos, yaw=float(yaw), speed=speed)
        if not r.get("reached", True):
            self.log("NOT REACHED %s" % tag)
        return r

    def drawer(self):
        r = self.api.get_drawer()
        return {"opening": float(r["opening"]), "center": np.array(r["interior_center"], dtype=float),
                "size": np.array(r["interior_size"], dtype=float), "floor_z": float(r["floor_z"])}


# ---------------------------------------------------------------------------
def handle_grasp_z(h_z, top_z):
    """Fingertip height for pinching the handle bar: high enough that the hand
    is above the counter top, low enough that the pads stay on the bar."""
    z = top_z - FINGER_LEN + 0.010
    return float(min(max(z, h_z - 0.02), h_z + 0.045))


def grasp_handle(R, x_h, y_h, z_g, z_safe):
    """Pinch the vertical handle bar with yaw 0 at fingertip height z_g."""
    pre_x = x_h - 0.07
    p, _, _ = R.ee()
    R.api.open_gripper()
    if p[2] < z_safe - 0.02:
        R.move([p[0], p[1], z_safe], tag="up")
    R.move([pre_x, y_h, z_safe], yaw=0.0, speed=FAST, tag="pre-handle-high")
    R.move([pre_x, y_h, z_g], yaw=0.0, tag="pre-handle")
    for dx in (0.004, 0.016, -0.008):
        R.move([x_h + dx, y_h, z_g], yaw=0.0, speed=SLOW, tag="to-handle")
        w = R.api.close_gripper()
        if 0.006 < w < 0.040:
            R.log("handle pinched dx=%.3f w=%.4f" % (dx, w))
            return True
        R.log("handle miss dx=%.3f w=%.4f" % (dx, w))
        R.api.open_gripper()
    return False


def release_handle(R, z_safe):
    """Let go of the handle without dragging the drawer: open, wait, go straight up."""
    R.api.open_gripper()
    R.api.wait(0.3)
    p, _, _ = R.ee()
    R.move([p[0], p[1], p[2] + 0.10], speed=0.05, tag="handle-lift")
    R.move([p[0] - 0.05, p[1], max(z_safe, p[2] + 0.10)], speed=NORMAL, tag="handle-away")


def choose_spot(drawer, d_objs, front_x, delta, rect, floor_z, grasp_off):
    """Best cup centre in the drawer after it has been pulled `delta` further.
    rect = (dx_min, dx_max, dy_min, dy_max) footprint of cup + handle + open fingers
    relative to the cup centre. Returns (score, x, y, clearance) or None."""
    cx, cy = drawer["center"][0] - delta, drawer["center"][1]
    sx, sy = drawer["size"][0], drawer["size"][1]
    x_in, x_out = cx - sx / 2, cx + sx / 2
    y_lo, y_hi = cy - sy / 2, cy + sy / 2
    x_max = min(front_x - HAND_HALF_SHORT - 0.025, x_out - rect[1] - 0.02)
    x_min = max(x_in - rect[0] + 0.02, x_in - 0.016 + ARM_PANEL_GAP)
    if x_max < x_min - 1e-6:
        return None
    hand_bottom = floor_z + grasp_off + FINGER_LEN
    best = None
    ys = np.linspace(y_lo + HAND_HALF_LONG + 0.005, y_hi - HAND_HALF_LONG - 0.005, 21)
    xs = np.linspace(x_min, max(x_min, x_max), 6)
    for x in xs:
        for y in ys:
            cup_rect = (x + rect[0] - 0.005, x + rect[1] + 0.005, y + rect[2], y + rect[3])
            hand_rect = (x - HAND_HALF_SHORT, x + HAND_HALF_SHORT, y - HAND_HALF_LONG, y + HAND_HALF_LONG)
            clear = 0.08
            for o in d_objs:
                ox, oy = o["pos"][0] - delta, o["pos"][1]
                hx, hy = o["size"][0] / 2, o["size"][1] / 2
                orect = (ox - hx, ox + hx, oy - hy, oy + hy)
                clear = min(clear, _rect_gap(cup_rect, orect))
                if o["pos"][2] + o["size"][2] / 2 > hand_bottom - 0.03:
                    clear = min(clear, _rect_gap(hand_rect, orect))
            clear = min(clear, cup_rect[2] - y_lo, y_hi - cup_rect[3])
            score = min(clear, 0.05) - 0.03 * abs(y - cy) - 0.05 * abs(x - x_max)
            if best is None or score > best[0]:
                best = (score, float(x), float(y), float(clear))
    return best


def cup_grasp_yaw(cup, c_objs, top_z, grasp_off):
    """Pick a gripper yaw near the cup yaw (closing axis perpendicular to the
    handle) that keeps fingers and hand clear of objects on the counter."""
    a = cup["yaw"]
    c = np.array(cup["pos"][:2])
    hand_bottom = top_z + grasp_off + FINGER_LEN
    best = None
    for d_deg in (0, -15, 15, -30, 30, -45, 45):
        g = _wrap_half(a + math.radians(d_deg))
        cax = np.array([-math.sin(g), math.cos(g)])   # closing axis
        tax = np.array([math.cos(g), math.sin(g)])    # across axis
        clear = 0.06
        for o in c_objs:
            tall = (o["pos"][2] + o["size"][2] / 2) > hand_bottom - 0.03
            for (px, py) in _box_points(o):
                rel = np.array([px, py]) - c
                v, u = float(rel @ cax), float(rel @ tax)
                clear = min(clear, _pt_rect_dist(u, v, FINGER_HALF_W + 0.005, FINGER_HALF_OPEN))
                if tall:
                    clear = min(clear, _pt_rect_dist(u, v, HAND_HALF_SHORT, HAND_HALF_LONG))
        score = min(clear, 0.03) - 0.0002 * abs(d_deg)
        if best is None or score > best[0]:
            best = (score, g, clear, d_deg)
    return best


def close_drawer(R, hx, hy, top_z, z_safe, closed_x_est, front_x):
    """Pinch the handle and push it to closed_x_est (+ a little). Returns opening."""
    hz = R.api.get_handle()["pos"][2]
    z_g = handle_grasp_z(hz, top_z)
    ok = grasp_handle(R, hx, hy, z_g, z_safe)
    if ok:
        p, _, _ = R.ee()
        tgt = min(max(closed_x_est + 0.010, p[0] + 0.005), front_x - 0.03)
        R.move([tgt, p[1], p[2]], speed=0.05, tag="push")
        R.api.wait(0.4)
        d_hold = R.drawer()["opening"]
        release_handle(R, z_safe)
        d = R.drawer()["opening"]
        R.log("push: target=%.3f opening held=%.4f after release=%.4f" % (tgt, d_hold, d))
        return d, True
    p, _, _ = R.ee()
    R.move([p[0] - 0.08, p[1], p[2]], tag="back")
    R.move([p[0] - 0.08, p[1], z_safe], tag="up")
    return R.drawer()["opening"], False


def run(api):
    R = Robot(api)

    counter = api.get_counter()
    top_z, front_x = float(counter["top_z"]), float(counter["front_x"])
    objs = [{"name": str(o["name"]), "location": str(o["location"]),
             "pos": np.array(o["pos"], dtype=float), "size": np.array(o["size"], dtype=float)}
            for o in api.get_objects()]
    c_objs = [o for o in objs if o["location"] != "drawer"]
    d_objs = [o for o in objs if o["location"] == "drawer"]
    drawer = R.drawer()
    hpos = np.array(api.get_handle()["pos"], dtype=float)
    c0 = api.get_cup()
    cup = {"pos": np.array(c0["pos"], dtype=float), "yaw": float(c0["yaw"]),
           "radius": float(c0["radius"]), "height": float(c0["height"])}
    r_cup, h_cup = float(cup["radius"]), float(cup["height"])

    max_obj_top = top_z
    for o in c_objs:
        max_obj_top = max(max_obj_top, o["pos"][2] + o["size"][2] / 2)
    cup_top = cup["pos"][2] + h_cup / 2
    z_safe = max(top_z + 0.15, max_obj_top + 0.09, cup_top + 0.09)

    # ---- cup grasp plan -------------------------------------------------------
    grasp_off = min(max(0.42 * h_cup, 0.018), h_cup - 0.02)   # fingertips above cup bottom
    gsel = cup_grasp_yaw(cup, c_objs, top_z, grasp_off)
    g_yaw = gsel[1]
    a_f = _wrap(cup["yaw"] - g_yaw)            # cup yaw once the gripper is at yaw 0
    hp = (r_cup + CUP_HANDLE_EXT) * np.array([-math.cos(a_f), -math.sin(a_f)])
    rect = (min(-r_cup, hp[0]), max(r_cup, hp[0]),
            min(-FINGER_HALF_OPEN, hp[1]), max(FINGER_HALF_OPEN, hp[1]))

    # ---- drawer opening plan ----------------------------------------------------
    d0 = drawer["opening"]
    d_hi = min(0.31, d0 + max(0.0, hpos[0] - 0.22))
    plan_d, spot = d0, None
    if d0 >= 0.24:
        spot = choose_spot(drawer, d_objs, front_x, 0.0, rect, drawer["floor_z"], grasp_off)
    if spot is None or spot[3] < 0.03:
        best = None
        for d in np.arange(max(0.26, d0 + 0.02), d_hi + 1e-9, 0.01):
            s = choose_spot(drawer, d_objs, front_x, float(d - d0), rect, drawer["floor_z"], grasp_off)
            if s is None:
                continue
            if best is None or s[3] > best[1][3] + 0.005:
                best = (float(d), s)
            if s[3] >= 0.03:
                best = (float(d), s)
                break
        if best is not None and (spot is None or best[1][3] > spot[3] + 0.005):
            plan_d, spot = best
    pull = plan_d - d0
    R.log("plan: d0=%.3f h=%s target_open=%.3f spot=%s gyaw=%.2f(%+d) gclear=%.3f a_f=%.2f"
          % (d0, np.round(hpos, 3).tolist(), plan_d, None if spot is None else
             [round(v, 3) for v in spot[1:]], g_yaw, gsel[3], gsel[2], a_f))

    # ---- 1. open the drawer -----------------------------------------------------
    handle_y = float(hpos[1])
    closed_x_est = float(hpos[0]) + d0
    if pull > 0.005:
        z_g = handle_grasp_z(hpos[2], top_z)
        if grasp_handle(R, float(hpos[0]), handle_y, z_g, z_safe):
            p, _, _ = R.ee()
            handle_y = float(p[1])
            closed_x_est = 0.5 * (closed_x_est + float(p[0]) - 0.002 + d0)
            R.move([p[0] - pull, p[1], p[2]], speed=0.06, tag="pull")
            R.api.wait(0.4)
            d_hold = R.drawer()["opening"]
            release_handle(R, z_safe)
            R.log("pulled: held=%.4f" % d_hold)
        else:
            p, _, _ = R.ee()
            R.move([p[0] - 0.08, p[1], p[2]], tag="back")
            R.move([p[0] - 0.08, p[1], z_safe], tag="up")

    drawer = R.drawer()
    delta_obs = drawer["opening"] - d0
    spot = choose_spot(drawer, [dict(o, pos=o["pos"] - np.array([delta_obs, 0, 0])) for o in d_objs],
                       front_x, 0.0, rect, drawer["floor_z"], grasp_off)
    if spot is None:
        spot = (0.0, front_x - HAND_HALF_SHORT - 0.03, float(drawer["center"][1]), 0.0)
    _, px, py, pclear = spot
    R.log("opening=%.4f place x=%.3f y=%.3f clear=%.3f" % (drawer["opening"], px, py, pclear))

    # ---- 2. grasp the cup ---------------------------------------------------------
    cpos = cup["pos"]
    cup_bottom_est = 0.5 * (top_z + (cpos[2] - h_cup / 2))
    z_grasp = cup_bottom_est + grasp_off
    z_above = cup_bottom_est + h_cup + 0.04
    cax = np.array([-math.sin(g_yaw), math.cos(g_yaw), 0.0])

    p, _, _ = R.ee()
    if p[2] < z_safe - 0.02:
        R.move([p[0], p[1], z_safe], tag="up")
    R.api.open_gripper()
    grasped = False
    for off in (0.0, 0.012, -0.012, 0.022, -0.022):
        tgt = cpos + cax * off
        R.move([tgt[0], tgt[1], z_safe], yaw=g_yaw, speed=FAST, tag="above-cup")
        R.move([tgt[0], tgt[1], z_above], yaw=g_yaw, speed=NORMAL, tag="above-cup-low")
        R.move([tgt[0], tgt[1], z_grasp], speed=SLOW, tag="descend-cup")
        p, _, _ = R.ee()
        if p[2] > z_grasp + 0.012:
            R.log("descent blocked z=%.4f off=%.3f" % (p[2], off))
            R.move([tgt[0], tgt[1], z_safe], speed=NORMAL, tag="retreat")
            continue
        w = R.api.close_gripper()
        if 2 * r_cup - 0.027 < w < 2 * r_cup + 0.016:
            R.log("cup grasped w=%.4f off=%.3f" % (w, off))
            grasped = True
            break
        R.log("cup grasp bad w=%.4f off=%.3f" % (w, off))
        R.api.open_gripper()
        R.move([tgt[0], tgt[1], z_safe], speed=SLOW, tag="retreat")
        c2 = api.get_cup()
        cpos = np.array(c2["pos"], dtype=float)
    if not grasped:
        R.log("FAILED to grasp the cup")
        return

    p_grasp, _, _ = R.ee()
    grasp_off_actual = float(p_grasp[2] - cup_bottom_est)

    # ---- 3. carry to the drawer and place ----------------------------------------
    z_carry = max(z_safe, max_obj_top + 0.05 + grasp_off_actual, top_z + 0.06 + grasp_off_actual)
    R.move([p_grasp[0], p_grasp[1], z_carry], speed=0.1, tag="lift")
    R.move([px, py, z_carry], yaw=0.0, speed=NORMAL, tag="carry")
    z_place = drawer["floor_z"] + grasp_off_actual
    R.move([px, py, z_place + 0.035], speed=NORMAL, tag="lower")
    R.move([px, py, z_place - 0.004], speed=0.03, tag="place")
    R.api.open_gripper()
    R.api.wait(0.3)
    p, _, _ = R.ee()
    R.move([p[0], p[1], p[2] + 0.08], speed=0.06, tag="leave-cup")
    R.move([p[0], p[1], z_safe], speed=NORMAL, tag="leave-cup-up")
    c3 = api.get_cup()
    R.log("cup now %s" % np.round(c3["pos"], 3).tolist())

    # ---- 4. close the drawer -------------------------------------------------------
    for attempt in range(3):
        d_now = R.drawer()["opening"]
        hnow = np.array(api.get_handle()["pos"], dtype=float)
        hx_est = closed_x_est - d_now
        hx = 0.5 * (hx_est + hnow[0]) if abs(hx_est - hnow[0]) < 0.02 else hnow[0]
        R.log("close attempt %d: opening=%.4f hx=%.3f (perc %.3f est %.3f)"
              % (attempt, d_now, hx, hnow[0], hx_est))
        if d_now < 0.004 and attempt > 0:
            break
        d_after, ok = close_drawer(R, hx, handle_y, top_z, z_safe, closed_x_est, front_x)
        if d_after < 0.006:
            break
        # the drawer did not close completely; the estimate of the closed position
        # was too small (or the pinch slipped): push further next time
        closed_x_est += min(max(0.0, d_after - 0.002), 0.02)
    p, _, _ = R.ee()
    if p[2] < z_safe - 0.02:
        R.move([p[0], p[1], z_safe], tag="final-up")
