import math
import numpy as np


def run(api):
    def vec(p):
        return np.asarray(p, dtype=float)

    def move(p, yaw=None, speed=0.25):
        p = vec(p).tolist()
        result = api.move_to(p, yaw=yaw, speed=speed)
        if not result["reached"]:
            result = api.move_to(p, yaw=yaw, speed=0.12)
        return result["reached"]

    def safe_height():
        counter = api.get_counter()
        height = counter["top_z"] + 0.19
        for obj in api.get_objects():
            p, s = vec(obj["pos"]), vec(obj["size"])
            height = max(height, p[2] + s[2] / 2.0 + 0.12)
        return height

    def overhead(p, yaw=None):
        p = vec(p)
        ee = vec(api.get_ee()["pos"])
        z = max(safe_height(), ee[2], p[2] + 0.10)
        if not move([ee[0], ee[1], z]):
            return False
        return move([p[0], p[1], z], yaw)

    def grasp_handle():
        api.open_gripper()
        handle = vec(api.get_handle()["pos"])
        if not overhead(handle, 0.0):
            return False
        if not move(handle, 0.0, 0.12):
            return False
        width = api.close_gripper()
        api.wait(0.15)
        return 0.004 < width < 0.045

    def release_handle():
        api.open_gripper()
        ee = vec(api.get_ee()["pos"])
        move([ee[0], ee[1], safe_height()], speed=0.18)

    def placement():
        drawer = api.get_drawer()
        counter = api.get_counter()
        cup = api.get_cup()
        center = vec(drawer["interior_center"])
        size = vec(drawer["interior_size"])

        margin = max(0.065, cup["radius"] + 0.034)
        low = center[:2] - size[:2] / 2.0 + margin
        high = center[:2] + size[:2] / 2.0 - margin
        high[0] = min(high[0], counter["front_x"] - margin)
        if np.any(high < low):
            return None

        objects = api.get_objects()
        best = None
        best_score = -1e9
        for x in np.linspace(low[0], high[0], 19):
            for y in np.linspace(low[1], high[1], 25):
                point = np.array([x, y])
                clearance = min(
                    x - (center[0] - size[0] / 2.0),
                    center[0] + size[0] / 2.0 - x,
                    y - (center[1] - size[1] / 2.0),
                    center[1] + size[1] / 2.0 - y,
                    counter["front_x"] - x,
                )
                valid = True
                for obj in objects:
                    op = vec(obj["pos"])
                    os = vec(obj["size"])
                    separation = np.abs(point - op[:2]) - os[:2] / 2.0
                    distance = np.linalg.norm(np.maximum(separation, 0.0))
                    if distance < margin:
                        valid = False
                        break
                    clearance = min(clearance, distance)
                if valid:
                    score = clearance - 0.025 * abs(y - center[1])
                    if score > best_score:
                        best_score = score
                        best = [float(x), float(y)]
        return best

    def open_drawer(target):
        # Earliest demonstrated failure: a useful opening of about 0.35 m
        # was rejected, and repeated regrasping near the robot then failed.
        # Accept an exposed, clear placement area before attempting another
        # pull. Preserve the successful handle grasp and pulling motion.
        def usable():
            return (
                api.get_drawer()["opening"] >= 0.28
                and placement() is not None
            )

        for attempt in range(3):
            before = api.get_drawer()["opening"]
            if usable():
                return True
            if before >= target - 0.015:
                return placement() is not None
            if not grasp_handle():
                release_handle()
                continue

            ee = vec(api.get_ee()["pos"])
            distance = max(0.0, target - before)
            move(ee + np.array([-distance, 0.0, 0.0]), 0.0, 0.15)
            after = api.get_drawer()["opening"]
            release_handle()

            if usable():
                return True
            if after >= target - 0.015:
                return placement() is not None
            if after < before + 0.015:
                api.log("Drawer grasp did not produce sufficient motion.")

        return usable()

    if not open_drawer(0.38):
        api.log("Unable to expose a clear drawer placement area.")
        return

    destination = placement()
    if destination is None:
        if not open_drawer(0.47):
            return
        destination = placement()
    if destination is None:
        api.log("No clear, exposed placement area found.")
        return

    held = False
    grip_offset = 0.0
    yaw = 0.0
    for attempt in range(3):
        cup = api.get_cup()
        cp = vec(cup["pos"])
        yaw = float(cup["yaw"])
        grasp = cp.copy()
        grasp[2] += min(0.006, cup["height"] * 0.1)
        api.open_gripper()
        if not overhead(grasp, yaw):
            return
        if not move(grasp, yaw, 0.10):
            return
        width = api.close_gripper()
        api.wait(0.15)
        if width < 0.018 or width > 0.079:
            api.open_gripper()
            move([grasp[0], grasp[1], safe_height()])
            continue

        lift = grasp.copy()
        lift[2] = safe_height()
        if not move(lift, yaw, 0.18):
            return
        observed = vec(api.get_cup()["pos"])
        ee = vec(api.get_ee()["pos"])
        if observed[2] > cp[2] + 0.055 and np.linalg.norm(
            observed[:2] - ee[:2]
        ) < 0.045:
            held = True
            grip_offset = ee[2] - observed[2]
            break
        api.open_gripper()

    if not held:
        api.log("Cup pickup could not be verified.")
        return

    cup = api.get_cup()
    drawer = api.get_drawer()
    cp = vec(cup["pos"])
    ee = vec(api.get_ee()["pos"])
    horizontal_offset = ee[:2] - cp[:2]
    target = np.array([
        destination[0] + horizontal_offset[0],
        destination[1] + horizontal_offset[1],
        drawer["floor_z"] + cup["height"] / 2.0 + grip_offset + 0.004,
    ])
    if not overhead(target, yaw):
        return
    if not move(target, yaw, 0.09):
        return
    api.open_gripper()
    api.wait(0.35)
    ee = vec(api.get_ee()["pos"])
    if not move([ee[0], ee[1], safe_height()], yaw, 0.16):
        return

    for attempt in range(3):
        opening = api.get_drawer()["opening"]
        if opening <= 0.008:
            break
        if not grasp_handle():
            release_handle()
            continue
        ee = vec(api.get_ee()["pos"])
        move(ee + np.array([opening + 0.003, 0.0, 0.0]), 0.0, 0.12)
        release_handle()

    drawer = api.get_drawer()
    cup = api.get_cup()
    cp = vec(cup["pos"])
    dc = vec(drawer["interior_center"])
    ds = vec(drawer["interior_size"])
    inside = (
        abs(cp[0] - dc[0]) < ds[0] / 2.0 - cup["radius"]
        and abs(cp[1] - dc[1]) < ds[1] / 2.0 - cup["radius"]
        and abs(cp[2] - drawer["floor_z"] - cup["height"] / 2.0) < 0.025
    )
    api.log(
        "Cup inside drawer: %s; drawer opening: %.3f"
        % (inside, drawer["opening"])
    )
