import math
import numpy as np


def run(api):
    def vec(p):
        return np.asarray(p, dtype=float)

    def move(p, yaw=None, speed=0.30):
        p = [float(v) for v in p]
        result = api.move_to(p, yaw=yaw, speed=speed)
        if not result["reached"]:
            result = api.move_to(p, yaw=yaw, speed=0.16)
        return result["reached"]

    counter = api.get_counter()
    objects = api.get_objects()

    # Earliest observed failure: the high cup approach was unreachable.
    # Use scene clearance, rather than retaining the initial EE height.
    safe_z = max(
        [counter["top_z"] + 0.105]
        + [
            o["pos"][2] + o["size"][2] / 2 + 0.095
            for o in objects
        ]
    )

    def rise():
        p = vec(api.get_ee()["pos"])
        p[2] = safe_z
        return move(p)

    def grasp_handle():
        api.open_gripper()
        if not rise():
            return False
        h = vec(api.get_handle()["pos"])
        approach = h.copy()
        approach[0] -= 0.055
        overhead = approach.copy()
        overhead[2] = safe_z
        if not move(overhead, yaw=0.0):
            return False
        if not move(approach, yaw=0.0):
            return False
        if not move(h, yaw=0.0, speed=0.10):
            return False
        return api.close_gripper() > 0.004

    def release_handle():
        api.open_gripper()
        p = vec(api.get_ee()["pos"])
        p[0] -= 0.045
        move(p, speed=0.18)
        return rise()

    # A moderate opening exposes space while keeping the handle reachable.
    # Avoid repeatedly pulling against the near-base reach limit.
    desired_opening = 0.30
    for attempt in range(2):
        d = api.get_drawer()
        if d["opening"] >= desired_opening - 0.012:
            break
        if not grasp_handle():
            release_handle()
            continue
        d = api.get_drawer()
        p = vec(api.get_ee()["pos"])
        p[0] -= max(0.0, desired_opening - d["opening"])
        move(p, yaw=0.0, speed=0.18)
        release_handle()

    drawer = api.get_drawer()
    cup = api.get_cup()
    objects = api.get_objects()
    radius = float(cup["radius"])
    height = float(cup["height"])

    # Preserve the successful placement clearance search.
    footprint = radius + 0.033
    center = vec(drawer["interior_center"])
    size = vec(drawer["interior_size"])
    lo = center[:2] - size[:2] / 2
    hi = center[:2] + size[:2] / 2
    xmin = lo[0] + footprint + 0.018
    xmax = min(
        hi[0] - footprint - 0.018,
        counter["front_x"] - footprint - 0.025,
    )
    ymin = lo[1] + footprint + 0.018
    ymax = hi[1] - footprint - 0.018

    if xmin >= xmax or ymin >= ymax:
        api.log("Insufficient exposed drawer area.")
        return

    best = None
    best_score = -float("inf")
    for x in np.linspace(xmin, xmax, 23):
        for y in np.linspace(ymin, ymax, 25):
            clearance = min(
                x - lo[0], hi[0] - x,
                y - lo[1], hi[1] - y,
                counter["front_x"] - x,
            ) - footprint
            valid = True
            for obj in objects:
                p = vec(obj["pos"])
                s = vec(obj["size"])
                if p[2] + s[2] / 2 < drawer["floor_z"] - 0.01:
                    continue
                dx = max(abs(x - p[0]) - s[0] / 2, 0.0)
                dy = max(abs(y - p[1]) - s[1] / 2, 0.0)
                gap = math.hypot(dx, dy) - footprint
                clearance = min(clearance, gap)
                if gap < 0.014:
                    valid = False
                    break
            if valid:
                score = clearance - 0.03 * abs(y - center[1])
                if score > best_score:
                    best_score = score
                    best = np.array([x, y], dtype=float)

    if best is None:
        api.log("No clear cup placement region.")
        return

    held = False
    grasp_offset = np.zeros(3)
    for attempt in range(2):
        cup = api.get_cup()
        p = vec(cup["pos"])
        yaw = float(cup["yaw"])
        api.open_gripper()
        if not rise():
            return
        above = p.copy()
        above[2] = safe_z
        if not move(above, yaw=yaw):
            # Lower the approach only when its entire vertical corridor
            # remains clear of nearby objects.
            lower_z = max(
                counter["top_z"] + 0.075,
                p[2] + height / 2 + 0.040,
            )
            for obj in objects:
                q = vec(obj["pos"])
                s = vec(obj["size"])
                dx = max(abs(p[0] - q[0]) - s[0] / 2, 0.0)
                dy = max(abs(p[1] - q[1]) - s[1] / 2, 0.0)
                if math.hypot(dx, dy) < footprint + 0.035:
                    lower_z = max(lower_z, q[2] + s[2] / 2 + 0.09)
            above[2] = lower_z
            if not move(above, yaw=yaw):
                continue

        grasp = p.copy()
        grasp[2] += 0.002
        if not move(grasp, yaw=yaw, speed=0.10):
            rise()
            continue
        width = api.close_gripper()
        if width < 0.015:
            api.open_gripper()
            rise()
            continue

        old_cup = vec(api.get_cup()["pos"])
        lift = vec(api.get_ee()["pos"])
        lift[2] += 0.075
        move(lift, speed=0.14)
        new_cup = vec(api.get_cup()["pos"])
        if new_cup[2] - old_cup[2] > 0.040:
            held = True
            grasp_offset = new_cup - vec(api.get_ee()["pos"])
            break
        api.open_gripper()
        rise()

    if not held:
        api.log("Cup grasp unsuccessful.")
        return

    # Move inward at the attained lift height before requesting a higher
    # transport waypoint, avoiding the distant high reach limit.
    transport = vec(api.get_ee()["pos"])
    overhead = np.array([best[0], best[1], safe_z])
    if transport[2] < safe_z - 0.012:
        inward = transport.copy()
        inward[0] -= 0.065
        clear = True
        cup_bottom = transport[2] + grasp_offset[2] - height / 2
        for obj in objects:
            q = vec(obj["pos"])
            s = vec(obj["size"])
            if (
                q[2] + s[2] / 2 + 0.020 > cup_bottom
                and q[0] + s[0] / 2 >= inward[0] - footprint
                and q[0] - s[0] / 2 <= transport[0] + footprint
                and abs(q[1] - transport[1]) < s[1] / 2 + footprint
            ):
                clear = False
                break
        if clear:
            if not move(inward, speed=0.18):
                return
    if not rise():
        return

    target = np.array([
        best[0],
        best[1],
        drawer["floor_z"] + height / 2 + 0.007,
    ]) - grasp_offset
    overhead = target.copy()
    overhead[2] = safe_z
    if not move(overhead, speed=0.23):
        return
    if not move(target, speed=0.10):
        return
    api.open_gripper()
    api.wait(0.3)
    if not rise():
        return

    # Keep the handle grasp through final correction so residual opening
    # does not require another complete approach.
    for attempt in range(2):
        if api.get_drawer()["opening"] <= 0.006:
            break
        if not grasp_handle():
            release_handle()
            continue
        for correction in range(3):
            d = api.get_drawer()
            if d["opening"] <= 0.006:
                break
            p = vec(api.get_ee()["pos"])
            p[0] += max(0.012, d["opening"] + 0.012)
            move(p, yaw=0.0, speed=0.12)
            api.wait(0.15)
        release_handle()

    api.log("Drawer opening: %.4f" % api.get_drawer()["opening"])
