import math
import numpy as np


def run(api):
    def vec(p):
        return np.asarray(p, dtype=float)

    def mean_read(getter, key, count=5):
        return np.mean([vec(getter()[key]) for _ in range(count)], axis=0)

    def move(p, yaw=None, speed=0.25):
        result = api.move_to(
            [float(v) for v in p], yaw=yaw, speed=speed
        )
        return bool(result["reached"])

    counter = api.get_counter()
    objects = api.get_objects()
    top = float(counter["top_z"])

    # The earliest demonstrated failure was an unreachable high waypoint
    # above the cup. Use obstacle-dependent transit heights instead.
    def transit_z(a, b, payload=0.0):
        z = top + 0.085 + payload
        margin = 0.065
        lower = np.minimum(a[:2], b[:2]) - margin
        upper = np.maximum(a[:2], b[:2]) + margin
        for obj in objects:
            p = vec(obj["pos"])
            s = vec(obj["size"])
            if np.all(p[:2] + s[:2] / 2 >= lower) and np.all(
                p[:2] - s[:2] / 2 <= upper
            ):
                z = max(z, p[2] + s[2] / 2 + 0.065 + payload)
        return z

    def travel_above(destination, yaw=None, payload=0.0):
        current = vec(api.get_ee()["pos"])
        destination = vec(destination)
        z = transit_z(current, destination, payload)
        raised = current.copy()
        raised[2] = z
        if not move(raised):
            return False
        above = destination.copy()
        above[2] = z
        return move(above, yaw=yaw)

    def grasp_handle():
        api.open_gripper()
        h = mean_read(api.get_handle, "pos")
        approach = h.copy()
        approach[0] -= 0.055
        if not travel_above(approach, yaw=0.0):
            return False
        if not move(approach, yaw=0.0, speed=0.18):
            return False
        if not move(h, yaw=0.0, speed=0.08):
            return False
        return api.close_gripper() > 0.004

    def release_handle():
        api.open_gripper()
        p = vec(api.get_ee()["pos"])
        p[0] -= 0.045
        move(p, speed=0.18)
        p = vec(api.get_ee()["pos"])
        p[2] = top + 0.085
        move(p)

    # Avoid pulling the handle into the robot's inner reach limit.
    desired_opening = 0.33
    for attempt in range(2):
        d = api.get_drawer()
        if d["opening"] >= desired_opening - 0.015:
            break
        if not grasp_handle():
            release_handle()
            continue
        remaining = max(0.0, desired_opening - d["opening"])
        while remaining > 0.008:
            step = min(0.08, remaining)
            p = vec(api.get_ee()["pos"])
            p[0] -= step
            if not move(p, yaw=0.0, speed=0.18):
                break
            remaining -= step
        release_handle()

    drawer = api.get_drawer()
    cup = api.get_cup()
    objects = api.get_objects()
    radius = float(cup["radius"])
    height = float(cup["height"])
    footprint = radius + 0.033
    center = vec(drawer["interior_center"])
    size = vec(drawer["interior_size"])
    lo = center[:2] - size[:2] / 2
    hi = center[:2] + size[:2] / 2
    xmin = lo[0] + footprint + 0.018
    xmax = min(
        hi[0] - footprint - 0.018,
        counter["front_x"] - footprint - 0.025,
    )
    ymin = lo[1] + footprint + 0.018
    ymax = hi[1] - footprint - 0.018

    if xmin >= xmax or ymin >= ymax:
        api.log("Insufficient exposed drawer area.")
        return

    best = None
    best_score = -float("inf")
    for x in np.linspace(xmin, xmax, 23):
        for y in np.linspace(ymin, ymax, 25):
            clearance = min(
                x - lo[0], hi[0] - x,
                y - lo[1], hi[1] - y,
                counter["front_x"] - x,
            ) - footprint
            valid = True
            for obj in objects:
                p = vec(obj["pos"])
                s = vec(obj["size"])
                if p[2] + s[2] / 2 < drawer["floor_z"] - 0.01:
                    continue
                dx = max(abs(x - p[0]) - s[0] / 2, 0.0)
                dy = max(abs(y - p[1]) - s[1] / 2, 0.0)
                gap = math.hypot(dx, dy) - footprint
                clearance = min(clearance, gap)
                if gap < 0.014:
                    valid = False
                    break
            if valid:
                score = clearance - 0.03 * abs(y - center[1])
                if score > best_score:
                    best_score = score
                    best = np.array([x, y], dtype=float)

    if best is None:
        api.log("No clear cup placement region.")
        return

    held = False
    grasp_offset = np.zeros(3)
    for attempt in range(3):
        samples = [api.get_cup() for _ in range(5)]
        p = np.mean([vec(c["pos"]) for c in samples], axis=0)
        yaw = math.atan2(
            sum(math.sin(c["yaw"]) for c in samples),
            sum(math.cos(c["yaw"]) for c in samples),
        )
        api.open_gripper()
        if not travel_above(p, yaw=yaw):
            api.log("Cup approach is obstructed or unreachable.")
            return
        grasp = p.copy()
        grasp[2] += 0.002
        if not move(grasp, yaw=yaw, speed=0.10):
            continue
        width = api.close_gripper()
        if width < 0.015:
            api.open_gripper()
            continue

        old_cup = mean_read(api.get_cup, "pos")
        lift = vec(api.get_ee()["pos"])
        lift[2] += 0.070
        move(lift, speed=0.14)
        new_cup = mean_read(api.get_cup, "pos")
        if new_cup[2] - old_cup[2] > 0.040:
            held = True
            grasp_offset = new_cup - vec(api.get_ee()["pos"])
            break
        api.open_gripper()

    if not held:
        api.log("Cup grasp unsuccessful.")
        return

    floor_z = float(np.mean([
        api.get_drawer()["floor_z"] for _ in range(5)
    ]))
    target = np.array([
        best[0], best[1], floor_z + height / 2 + 0.007
    ]) - grasp_offset

    if not travel_above(target, payload=height / 2 + 0.01):
        return
    if not move(target, speed=0.10):
        return
    api.open_gripper()
    api.wait(0.3)

    p = vec(api.get_ee()["pos"])
    p[2] = top + 0.085
    if not move(p, speed=0.20):
        return

    # Preserve handle-based closure, with short pushes and progress checks.
    for attempt in range(3):
        opening = float(api.get_drawer()["opening"])
        if opening <= 0.006:
            break
        if not grasp_handle():
            release_handle()
            continue

        for step_index in range(8):
            before = float(api.get_drawer()["opening"])
            if before <= 0.006:
                break
            p = vec(api.get_ee()["pos"])
            p[0] += min(0.065, before + 0.004)
            reached = move(p, yaw=0.0, speed=0.12)
            after = float(api.get_drawer()["opening"])
            if not reached or before - after < 0.008:
                break
        release_handle()

    api.log("Drawer opening: %.4f" % api.get_drawer()["opening"])
