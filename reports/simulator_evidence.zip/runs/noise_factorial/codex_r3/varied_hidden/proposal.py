import math
import numpy as np


def run(api):
    # Earliest demonstrated failure: the high waypoint above the cup is
    # unreachable. Use obstacle-dependent heights and a lower cup approach.
    # Also avoid repeatedly pulling the handle beyond the reachable workspace.
    def vec(p):
        return np.asarray(p, dtype=float)

    def move(p, yaw=None, speed=0.30):
        p = [float(v) for v in p]
        result = api.move_to(p, yaw=yaw, speed=speed)
        if not result["reached"]:
            result = api.move_to(p, yaw=yaw, speed=0.16)
        return result["reached"]

    counter = api.get_counter()
    objects = api.get_objects()
    top = float(counter["top_z"])
    transit_z = max(
        [top + 0.105]
        + [
            o["pos"][2] + o["size"][2] / 2 + 0.075
            for o in objects
        ]
    )

    def rise(z=None):
        p = vec(api.get_ee()["pos"])
        p[2] = max(p[2], transit_z if z is None else z)
        return move(p)

    def grasp_handle():
        api.open_gripper()
        if not rise():
            return False
        h = vec(api.get_handle()["pos"])
        approach = h.copy()
        approach[0] -= 0.045
        overhead = approach.copy()
        overhead[2] = transit_z
        if not move(overhead, yaw=0.0):
            return False
        if not move(approach, yaw=0.0):
            return False
        if not move(h, yaw=0.0, speed=0.10):
            return False
        return api.close_gripper() > 0.004

    def release_handle():
        api.open_gripper()
        p = vec(api.get_ee()["pos"])
        p[0] -= 0.035
        move(p, speed=0.18)
        return rise()

    drawer = api.get_drawer()
    h = vec(api.get_handle()["pos"])
    # Keep the pulled handle away from the robot's near-workspace limit.
    desired_opening = min(
        0.35, drawer["opening"] + max(0.0, h[0] - 0.18)
    )
    for attempt in range(2):
        d = api.get_drawer()
        if d["opening"] >= desired_opening - 0.015:
            break
        if not grasp_handle():
            release_handle()
            continue
        p = vec(api.get_ee()["pos"])
        p[0] -= max(0.0, desired_opening - d["opening"])
        move(p, yaw=0.0, speed=0.20)
        release_handle()
        after = api.get_drawer()["opening"]
        if after - d["opening"] < 0.012:
            break

    drawer = api.get_drawer()
    cup = api.get_cup()
    objects = api.get_objects()
    radius = float(cup["radius"])
    height = float(cup["height"])
    footprint = radius + 0.033
    center = vec(drawer["interior_center"])
    size = vec(drawer["interior_size"])
    lo = center[:2] - size[:2] / 2
    hi = center[:2] + size[:2] / 2
    xmin = lo[0] + footprint + 0.018
    xmax = min(
        hi[0] - footprint - 0.018,
        counter["front_x"] - footprint - 0.025,
    )
    ymin = lo[1] + footprint + 0.018
    ymax = hi[1] - footprint - 0.018

    if xmin >= xmax or ymin >= ymax:
        api.log("Insufficient exposed drawer area.")
        return

    best = None
    best_score = -float("inf")
    for x in np.linspace(xmin, xmax, 23):
        for y in np.linspace(ymin, ymax, 25):
            clearance = min(
                x - lo[0], hi[0] - x,
                y - lo[1], hi[1] - y,
                counter["front_x"] - x,
            ) - footprint
            valid = True
            for obj in objects:
                p = vec(obj["pos"])
                s = vec(obj["size"])
                if p[2] + s[2] / 2 < drawer["floor_z"] - 0.01:
                    continue
                dx = max(abs(x - p[0]) - s[0] / 2, 0.0)
                dy = max(abs(y - p[1]) - s[1] / 2, 0.0)
                gap = math.hypot(dx, dy) - footprint
                clearance = min(clearance, gap)
                if gap < 0.014:
                    valid = False
                    break
            if valid:
                score = clearance - 0.03 * abs(y - center[1])
                if score > best_score:
                    best_score = score
                    best = np.array([x, y], dtype=float)

    if best is None:
        api.log("No clear cup placement region.")
        return

    def corridor_height(a, b, clearance, base):
        z = base
        delta = b[:2] - a[:2]
        length2 = float(np.dot(delta, delta))
        for obj in objects:
            p = vec(obj["pos"])
            s = vec(obj["size"])
            if length2 > 1e-9:
                t = float(np.clip(
                    np.dot(p[:2] - a[:2], delta) / length2, 0.0, 1.0
                ))
            else:
                t = 0.0
            nearest = a[:2] + t * delta
            gap = np.maximum(np.abs(nearest - p[:2]) - s[:2] / 2, 0.0)
            if np.linalg.norm(gap) < footprint + 0.025:
                z = max(z, p[2] + s[2] / 2 + clearance)
        return z

    held = False
    grasp_offset = np.zeros(3)
    for attempt in range(3):
        cup = api.get_cup()
        p = vec(cup["pos"])
        yaw = float(cup["yaw"])
        # Parallel jaws have equivalent orientations separated by pi.
        yaw = (yaw + math.pi / 2) % math.pi - math.pi / 2
        api.open_gripper()

        current = vec(api.get_ee()["pos"])
        approach_z = corridor_height(
            current, p, 0.055,
            max(top + 0.065, p[2] + height / 2 + 0.035)
        )
        if not rise(approach_z):
            return
        above = p.copy()
        above[2] = approach_z
        if not move(above, yaw=yaw):
            # Lower only when the remaining local corridor permits it.
            actual = vec(api.get_ee()["pos"])
            lower_z = corridor_height(
                actual, p, 0.035,
                max(top + 0.045, p[2] + height / 2 + 0.018)
            )
            lowered = actual.copy()
            lowered[2] = lower_z
            if not move(lowered, yaw=yaw):
                continue
            above[2] = lower_z
            if not move(above, yaw=yaw):
                continue

        grasp = p.copy()
        grasp[2] += 0.002
        if not move(grasp, yaw=yaw, speed=0.10):
            rise(approach_z)
            continue
        width = api.close_gripper()
        if width < 0.015:
            api.open_gripper()
            rise(approach_z)
            continue

        old_cup = vec(api.get_cup()["pos"])
        lift = vec(api.get_ee()["pos"])
        lift[2] += 0.065
        move(lift, speed=0.14)
        new_cup = vec(api.get_cup()["pos"])
        if new_cup[2] - old_cup[2] > 0.035:
            held = True
            grasp_offset = new_cup - vec(api.get_ee()["pos"])
            break
        api.open_gripper()
        rise(approach_z)

    if not held:
        api.log("Cup grasp unsuccessful.")
        return

    target = np.array([
        best[0], best[1],
        drawer["floor_z"] + height / 2 + 0.007,
    ]) - grasp_offset
    current = vec(api.get_ee()["pos"])
    carry_z = corridor_height(
        current, target,
        height / 2 - grasp_offset[2] + 0.035,
        top + height / 2 - grasp_offset[2] + 0.035,
    )
    if not rise(carry_z):
        return
    overhead = target.copy()
    overhead[2] = carry_z
    if not move(overhead, speed=0.23):
        return
    if not move(target, speed=0.10):
        return
    api.open_gripper()
    api.wait(0.3)
    if not rise():
        return

    for attempt in range(2):
        d = api.get_drawer()
        if d["opening"] <= 0.006:
            break
        if not grasp_handle():
            release_handle()
            continue

        # Short pushes maintain contact and allow correction from measured
        # drawer motion rather than a single long endpoint command.
        for step in range(6):
            d = api.get_drawer()
            if d["opening"] <= 0.006:
                break
            p = vec(api.get_ee()["pos"])
            p[0] += min(0.085, d["opening"] + 0.004)
            move(p, yaw=0.0, speed=0.16)
            updated = api.get_drawer()["opening"]
            if d["opening"] - updated < 0.004:
                break
        release_handle()

    api.log("Drawer opening: %.4f" % api.get_drawer()["opening"])
