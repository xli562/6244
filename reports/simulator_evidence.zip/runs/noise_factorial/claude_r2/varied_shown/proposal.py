"""Robot program for: "Place the cup in the drawer." See TASK.md and API.md."""
import math

import numpy as np

# ---------------------------------------------------------------- constants
FINGER_OPEN_HALF = 0.05     # half span of open fingers incl. finger thickness (y in gripper frame)
FINGER_HALF_W = 0.012       # half width of a finger (x in gripper frame)
HAND_HALF_LONG = 0.108      # half length of the hand along the finger axis
HAND_HALF_SHORT = 0.040     # half depth of the hand across the finger axis
HAND_ABOVE_TIP = 0.045      # palm bottom height above fingertips
CUP_HANDLE_LEN = 0.030      # how far the cup handle sticks out of the body
BAR_HALF = 0.008            # half thickness of the drawer handle bar

TARGET_OPENING = 0.27
MAX_OPENING = 0.34
CLOSE_LEAVE = 0.015         # leave this much open after the held push (keeps hand off counter)


def _wrap_half(a):
    """Wrap to [-pi/2, pi/2] (a parallel gripper is symmetric under +pi)."""
    while a > math.pi / 2:
        a -= math.pi
    while a < -math.pi / 2:
        a += math.pi
    return a


def _wrap(a):
    while a > math.pi:
        a -= 2 * math.pi
    while a < -math.pi:
        a += 2 * math.pi
    return a


def _rect_gap(a, b):
    """Gap between two axis-aligned rectangles (xlo, xhi, ylo, yhi); negative if overlapping."""
    dx = max(b[0] - a[1], a[0] - b[1])
    dy = max(b[2] - a[3], a[2] - b[3])
    if dx > 0 and dy > 0:
        return math.hypot(dx, dy)
    return max(dx, dy)


class Robot:
    def __init__(self, api):
        self.api = api

    def log(self, m):
        try:
            self.api.log(str(m))
        except Exception:
            pass

    def ee(self):
        return self.api.get_ee()

    def move(self, p, yaw=None, speed=0.15, tag=""):
        p = [float(p[0]), float(p[1]), float(p[2])]
        if yaw is None:
            r = self.api.move_to(p, speed=speed)
        else:
            r = self.api.move_to(p, yaw=float(yaw), speed=speed)
        if not r.get("reached", True):
            e = self.ee()
            self.log("move %s not reached: target=%s err=%.4f ee=%s" % (
                tag, np.round(p, 4).tolist(), r.get("error", -1),
                np.round(e["pos"], 4).tolist()))
        return r

    def up_to(self, z, speed=0.15):
        e = self.ee()["pos"]
        if e[2] < z:
            self.move([e[0], e[1], z], speed=speed, tag="up")


def scene_info(api):
    cup = api.get_cup()
    dr = api.get_drawer()
    co = api.get_counter()
    objs = api.get_objects()
    h = api.get_handle()
    return cup, dr, co, objs, h


# ---------------------------------------------------------------- drawer
def grasp_handle(R, travel_z, z_off=None):
    """Grasp the drawer handle with yaw 0 (fingers close along y around the vertical bar).
    Returns fingertip z offset relative to handle reading, or None."""
    api = R.api
    h = api.get_handle()["pos"]
    hx, hy, hz = h
    gx = hx - 0.003
    R.api.open_gripper()
    R.up_to(travel_z)
    above = hz + 0.12
    R.move([gx, hy, max(above, travel_z)], yaw=0.0, tag="above_handle")
    R.move([gx, hy, above], yaw=0.0, tag="above_handle2")
    if z_off is None:
        target = hz
    else:
        target = hz + z_off
    R.move([gx, hy, target + 0.03], speed=0.1, tag="handle_pre")
    r = R.move([gx, hy, target], speed=0.04, tag="handle_desc")
    e = R.ee()["pos"]
    gz = target
    if e[2] > target + 0.006:
        # palm (or something) stopped us; back off slightly and grasp here
        gz = e[2] + 0.003
        R.move([gx, hy, gz], speed=0.03, tag="handle_backoff")
        R.log("handle descent blocked at z=%.4f (handle z %.4f)" % (e[2], hz))
    w = api.close_gripper()
    R.log("handle grasp width=%.4f at z=%.4f" % (w, gz))
    if w < 0.004:
        api.open_gripper()
        R.move([gx, hy, above], speed=0.1, tag="handle_fail_up")
        return None
    return gz - hz


def release_handle(R, lift_z):
    api = R.api
    api.open_gripper()
    e = R.ee()["pos"]
    # slide the fingers off the bar towards the robot, then go up
    R.move([e[0] - 0.06, e[1], e[2]], speed=0.08, tag="handle_retreat")
    R.move([e[0] - 0.06, e[1], lift_z], speed=0.15, tag="handle_lift")


def open_drawer(R, target, travel_z, state):
    api = R.api
    for attempt in range(3):
        d = api.get_drawer()["opening"]
        if d >= target - 0.012:
            return d
        z_off = grasp_handle(R, travel_z, state.get("handle_zoff"))
        if z_off is None:
            R.log("handle grasp failed, attempt %d" % attempt)
            continue
        state["handle_zoff"] = z_off
        e = R.ee()["pos"]
        pull = target - d
        R.move([e[0] - pull, e[1], e[2]], speed=0.06, tag="pull")
        d2 = api.get_drawer()["opening"]
        R.log("pulled drawer: %.4f -> %.4f (target %.3f)" % (d, d2, target))
        release_handle(R, travel_z)
    return api.get_drawer()["opening"]


def close_drawer(R, travel_z, state):
    """Held push to nearly closed, vertical release (no drag), then finish by pushing
    the bar from the robot side with closed fingers (bar stops fingers -> hand stays
    clear of the counter)."""
    api = R.api
    d = api.get_drawer()["opening"]
    bar = None          # [x, y, z, opening at which x was valid]
    hover_z = travel_z

    # ---- phase 1: held push, leaving a little gap
    if d > CLOSE_LEAVE + 0.005:
        z_off = grasp_handle(R, travel_z, state.get("handle_zoff"))
        if z_off is not None:
            state["handle_zoff"] = z_off
            e = R.ee()["pos"]
            R.move([e[0] + max(d - CLOSE_LEAVE, 0.0), e[1], e[2]], speed=0.05,
                   tag="push_held")
            d2 = api.get_drawer()["opening"]
            e2 = R.ee()["pos"]
            R.log("held push: %.4f -> %.4f" % (d, d2))
            api.open_gripper()
            api.wait(0.2)
            # release straight up: no x motion, so the handle cannot be dragged
            R.move([e2[0], e2[1], e2[2] + 0.10], speed=0.08, tag="release_up")
            d3 = api.get_drawer()["opening"]
            R.log("opening after release: %.4f" % d3)
            hr = api.get_handle()["pos"]
            bx = e2[0] + (d2 - d3)
            if abs(bx - hr[0]) > 0.015:
                R.log("bar estimate from ee %.4f disagrees with reading %.4f; using reading"
                      % (bx, hr[0]))
                bx = hr[0]
            bar = [bx, e2[1], e2[2], d3]
            hover_z = e2[2] + 0.10
        else:
            R.log("handle grasp for closing failed; pushing from behind only")

    if bar is None:
        R.up_to(travel_z)
        hr = api.get_handle()["pos"]
        d = api.get_drawer()["opening"]
        zo = state.get("handle_zoff")
        if zo is None:
            zo = 0.0
        bar = [hr[0], hr[1], hr[2] + zo, d]
        hover_z = max(travel_z, R.ee()["pos"][2])

    # ---- phase 2: push the bar from the robot side with closed fingers
    bx, by, bz, bd = bar
    api.close_gripper()
    sx = bx - 0.065
    R.move([sx, by, hover_z], yaw=0.0, speed=0.12, tag="push_start_above")
    R.move([sx, by, bz], speed=0.06, tag="push_start")
    for k in range(3):
        d = api.get_drawer()["opening"]
        if k > 0 and d < 0.003:
            break
        closed_x = bx + bd
        tx = closed_x - BAR_HALF - FINGER_HALF_W + 0.012 + 0.006 * k
        r = R.move([tx, by, bz], speed=0.04, tag="push_bar")
        d_after = api.get_drawer()["opening"]
        e = R.ee()["pos"]
        R.log("bar push %d: %.4f -> %.4f (target x %.4f, ee x %.4f)"
              % (k, d, d_after, tx, e[0]))
        if not r.get("reached", True):
            # fingers are in contact with the bar
            bx = e[0] + BAR_HALF + FINGER_HALF_W
            bd = d_after
        else:
            hr = api.get_handle()["pos"]
            bx = hr[0]
            bd = d_after
        # back off (fingers closed, behind the bar: nothing to hook)
        R.move([e[0] - 0.05, by, bz], speed=0.08, tag="push_retreat")
    R.up_to(travel_z)
    d = api.get_drawer()["opening"]
    R.log("final opening %.4f" % d)
    return d


# ---------------------------------------------------------------- placement
def cup_footprint(px, py, r, handle_sign):
    """Rectangle covered by the cup (with handle along x) and the open fingers (along y)."""
    xlo = px - r - (CUP_HANDLE_LEN if handle_sign < 0 else 0.0)
    xhi = px + r + (CUP_HANDLE_LEN if handle_sign > 0 else 0.0)
    xlo = min(xlo, px - FINGER_HALF_W)
    xhi = max(xhi, px + FINGER_HALF_W)
    ylo = py - max(r, FINGER_OPEN_HALF)
    yhi = py + max(r, FINGER_OPEN_HALF)
    return (xlo, xhi, ylo, yhi)


def choose_spot(R, dr, co, objs, r, handle_sign):
    ic = dr["interior_center"]
    isz = dr["interior_size"]
    floor_z = dr["floor_z"]
    x_lo = ic[0] - isz[0] / 2.0
    x_hi = min(ic[0] + isz[0] / 2.0, co["front_x"])
    y_lo = ic[1] - isz[1] / 2.0
    y_hi = ic[1] + isz[1] / 2.0
    hand_bottom = floor_z + 0.03 + HAND_ABOVE_TIP
    dobjs = [o for o in objs if o.get("location") == "drawer"]
    x_pref = co["front_x"] - 0.10
    best = None
    for px in np.arange(x_lo, x_hi + 1e-9, 0.005):
        for py in np.arange(y_lo, y_hi + 1e-9, 0.005):
            fp = cup_footprint(px, py, r, handle_sign)
            hand = (px - HAND_HALF_SHORT, px + HAND_HALF_SHORT,
                    py - HAND_HALF_LONG, py + HAND_HALF_LONG)
            clear = []
            # walls / reachable limits
            clear.append(fp[0] - x_lo - 0.008)              # front panel
            clear.append(co["front_x"] - hand[1] - 0.012)   # counter front (hand must stay out)
            clear.append(x_hi - fp[1] - 0.005)
            clear.append(fp[2] - y_lo - 0.008)
            clear.append(y_hi - fp[3] - 0.008)
            clear.append(hand[2] - y_lo + 0.0)              # hand over side walls
            clear.append(y_hi - hand[3] + 0.0)
            for o in dobjs:
                op, osz = o["pos"], o["size"]
                ob = (op[0] - osz[0] / 2.0, op[0] + osz[0] / 2.0,
                      op[1] - osz[1] / 2.0, op[1] + osz[1] / 2.0)
                clear.append(_rect_gap(fp, ob) - 0.012)
                if op[2] + osz[2] / 2.0 > hand_bottom - 0.01:
                    clear.append(_rect_gap(hand, ob) - 0.012)
            mc = min(clear)
            score = 10.0 * min(mc, 0.025) - 0.3 * abs(px - x_pref) - 0.15 * abs(py - ic[1])
            if best is None or score > best[0]:
                best = (score, mc, float(px), float(py))
    return best


# ---------------------------------------------------------------- main
def run(api):
    R = Robot(api)
    state = {}
    cup, dr, co, objs, h = scene_info(api)
    ee = api.get_ee()
    R.log("cup=%s" % cup)
    R.log("drawer=%s" % dr)
    R.log("counter=%s handle=%s ee=%s" % (co, h, ee))
    for o in objs:
        R.log("obj %s" % o)

    top_z = co["top_z"]
    max_top = top_z
    for o in objs:
        if o.get("location") == "counter":
            max_top = max(max_top, o["pos"][2] + o["size"][2] / 2.0)
    cup_r = cup.get("radius", 0.031)
    cup_h = cup.get("height", 0.058)
    # fingertip travel height: cup (hanging ~cup_h/2 below tips) clears everything
    travel_z = max(top_z + 0.17, max_top + cup_h / 2.0 + 0.06)
    R.log("travel_z=%.3f" % travel_z)

    # ---- 1. open the drawer far enough
    d = open_drawer(R, TARGET_OPENING, travel_z, state)
    R.log("opening after open_drawer: %.4f" % d)

    # planned yaw for grasp and handle direction after rotating to yaw 0
    cup = api.get_cup()
    g = _wrap_half(cup["yaw"])
    handle_ang = _wrap(cup["yaw"] + math.pi - g)    # after gripper rotates to yaw 0
    handle_sign = 1.0 if math.cos(handle_ang) > 0 else -1.0

    dr = api.get_drawer()
    objs = api.get_objects()
    best = choose_spot(R, dr, co, objs, cup_r, handle_sign)
    R.log("spot: %s (opening %.4f)" % (str(best), dr["opening"]))
    if best is None or best[1] < 0.0:
        if dr["opening"] < MAX_OPENING - 0.015:
            d = open_drawer(R, MAX_OPENING, travel_z, state)
            dr = api.get_drawer()
            objs = api.get_objects()
            best = choose_spot(R, dr, co, objs, cup_r, handle_sign)
            R.log("spot after opening more: %s (opening %.4f)" % (str(best), dr["opening"]))

    # ---- 2. pick the cup
    grasped = False
    grasp_off = 0.0
    for attempt in range(3):
        cup = api.get_cup()
        cx, cy, cz = cup["pos"]
        g = _wrap_half(cup["yaw"])
        api.open_gripper()
        R.up_to(travel_z)
        R.move([cx, cy, travel_z], yaw=g, tag="above_cup")
        gz = cz - 0.004
        R.move([cx, cy, cz + cup_h / 2.0 + 0.04], speed=0.12, tag="cup_pre")
        R.move([cx, cy, gz], speed=0.05, tag="cup_desc")
        w = api.close_gripper()
        R.log("cup grasp width=%.4f (attempt %d)" % (w, attempt))
        if w > 0.025:
            grasped = True
            grasp_off = gz - (cz - cup_h / 2.0)   # fingertip height above cup bottom
            break
        api.open_gripper()
        R.move([cx, cy, cz + cup_h / 2.0 + 0.06], speed=0.1, tag="cup_retry_up")
    if not grasped:
        R.log("could not grasp cup")
        return

    handle_ang = _wrap(cup["yaw"] + math.pi - g)
    handle_sign = 1.0 if math.cos(handle_ang) > 0 else -1.0

    e = R.ee()["pos"]
    R.move([e[0], e[1], e[2] + 0.06], speed=0.06, tag="cup_lift")
    R.move([e[0], e[1], travel_z], speed=0.12, tag="cup_lift2")
    w = api.get_ee()["gripper_width"]
    R.log("width after lift %.4f" % w)

    # ---- 3. place into the drawer
    dr = api.get_drawer()
    objs = api.get_objects()
    best = choose_spot(R, dr, co, objs, cup_r, handle_sign)
    R.log("final spot: %s handle_sign=%d" % (str(best), handle_sign))
    px, py = best[2], best[3]
    floor_z = dr["floor_z"]
    R.move([px, py, travel_z], yaw=0.0, speed=0.12, tag="above_spot")
    place_z = floor_z + grasp_off + 0.004
    R.move([px, py, place_z + 0.04], speed=0.1, tag="spot_pre")
    R.move([px, py, place_z], speed=0.03, tag="spot_desc")
    api.open_gripper()
    api.wait(0.3)
    e = R.ee()["pos"]
    R.move([e[0], e[1], e[2] + 0.05], speed=0.05, tag="spot_up")
    R.move([e[0], e[1], travel_z], speed=0.15, tag="spot_up2")
    c2 = api.get_cup()
    R.log("cup after place: %s" % c2)

    # ---- 4. close the drawer
    close_drawer(R, travel_z, state)
    R.up_to(travel_z)
    c3 = api.get_cup()
    R.log("cup at end: %s drawer=%s" % (c3, api.get_drawer()))
