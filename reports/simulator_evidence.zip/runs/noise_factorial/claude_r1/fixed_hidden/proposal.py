"""Robot program for: "Place the cup in the drawer." See TASK.md and API.md."""
import math

import numpy as np


FAST = 0.25
SLOW = 0.10
HANDLE_LEN = 0.03      # assumed reach of the cup handle beyond the body radius
FINGER_HALF = 0.05     # half width (along closing axis) of the open fingers
HAND_HALF = 0.11       # half width of the hand body along the closing axis
BAR_HALF = 0.008       # half thickness of the drawer handle bar
FINGER_DEPTH_HALF = 0.010  # half depth of the (closed) fingers along x at yaw 0


def wrap(a):
    return (a + math.pi) % (2 * math.pi) - math.pi


def run(api):
    def log(*a):
        api.log(" ".join(str(x) for x in a))

    def move(p, yaw=None, speed=FAST, tag=""):
        p = [float(v) for v in p]
        r = api.move_to(p, yaw=yaw, speed=speed)
        if not r.get("reached", True):
            log("move", tag, "not reached", [round(v, 3) for v in p], "err", round(r.get("error", -1), 4))
        return r

    def ee():
        return api.get_ee()

    def r3(v):
        return [round(float(x), 3) for x in v]

    counter = api.get_counter()
    top_z = counter["top_z"]
    front_x = counter["front_x"]
    cup = api.get_cup()
    drawer = api.get_drawer()
    handle = api.get_handle()
    objects = api.get_objects()
    log("counter", counter)
    log("cup", r3(cup["pos"]), "yaw", round(cup["yaw"], 3), "r", cup["radius"], "h", cup["height"])
    log("drawer open", round(drawer["opening"], 3), "ic", r3(drawer["interior_center"]),
        "is", r3(drawer["interior_size"]), "floor", round(drawer["floor_z"], 3))
    log("handle", r3(handle["pos"]))
    for o in objects:
        log("obj", o["name"], o["location"], r3(o["pos"]), r3(o["size"]))
    log("ee", ee())

    r_cup = cup["radius"]
    h_cup = cup["height"]

    # Safe travel height above everything on the counter.
    tops = [o["pos"][2] + o["size"][2] / 2 for o in objects if o["location"] == "counter"]
    max_top = max(tops + [top_z + h_cup])
    z_safe = max(top_z + 0.17, max_top + 0.12)
    log("z_safe", round(z_safe, 3))

    # ---------- grasp-yaw choice for the cup ----------
    cy = wrap(cup["yaw"])
    if abs(cy) <= 2.0:
        g_base = cy
        handle_neg_x = True       # at gripper yaw 0 the handle will point to -x
    else:
        g_base = wrap(cy + math.pi)
        handle_neg_x = False

    # Clearance of the open fingers / hand from counter objects at a given grasp yaw.
    def grasp_clearance(cp, g, gz):
        u = np.array([-math.sin(g), math.cos(g)])   # closing axis
        v = np.array([math.cos(g), math.sin(g)])    # finger depth axis
        fing_pts = []
        for s in (-1.0, 1.0):
            for a in np.linspace(0.040, 0.060, 3):
                for b in np.linspace(-0.011, 0.011, 3):
                    fing_pts.append(cp + s * a * u + b * v)
        hand_pts = [cp + a * u + b * v
                    for a in np.linspace(-HAND_HALF, HAND_HALF, 12)
                    for b in np.linspace(-0.032, 0.032, 3)]
        clr = 1.0
        for o in objects:
            if o["location"] != "counter":
                continue
            ox, oy, oz = o["pos"]
            sx, sy, sz = o["size"]
            top = oz + sz / 2
            pts = []
            if top > gz - 0.005:
                pts += fing_pts
            if top > gz + 0.04:
                pts += hand_pts
            for p in pts:
                dx = max(ox - sx / 2 - p[0], 0.0, p[0] - ox - sx / 2)
                dy = max(oy - sy / 2 - p[1], 0.0, p[1] - oy - sy / 2)
                clr = min(clr, math.hypot(dx, dy))
        return clr

    cp0 = np.array(cup["pos"][:2], dtype=float)
    gz0 = top_z + max(0.55 * h_cup, 0.028)
    delta = 0.0
    best_c = None
    for dlt in (0.0, 0.3, -0.3, 0.6, -0.6):
        if abs(g_base + dlt) > 2.25:
            continue
        c = grasp_clearance(cp0, g_base + dlt, gz0)
        log("grasp clearance delta", dlt, round(c, 4))
        if c >= 0.02:
            delta = dlt
            best_c = c
            break
        if best_c is None or c > best_c + 0.003:
            best_c = c
            delta = dlt
    g_yaw = wrap(g_base + delta)
    log("grasp yaw", round(g_yaw, 3), "delta", delta, "handle toward robot at place:", handle_neg_x)

    # ---------- placement spot selection ----------
    def rect_dist(a, b):
        # a, b = (xmin, xmax, ymin, ymax); distance between rectangles (0 if overlapping)
        dx = max(b[0] - a[1], a[0] - b[1], 0.0)
        dy = max(b[2] - a[3], a[2] - b[3], 0.0)
        return math.hypot(dx, dy) if (dx > 0 or dy > 0) else -min(a[1] - b[0], b[1] - a[0], a[3] - b[2], b[3] - a[2])

    def select_spot(dr, objs, d_fixed=None, d_max=0.30):
        c = np.array(dr["interior_center"], dtype=float)
        sx, sy, _ = dr["interior_size"]
        d0 = dr["opening"]
        floor = dr["floor_z"]
        xm = r_cup + (HANDLE_LEN if handle_neg_x else 0.0)    # extent toward -x
        xp = r_cup + (0.0 if handle_neg_x else HANDLE_LEN)    # extent toward +x
        yh = max(r_cup, FINGER_HALF)
        cd, sd = abs(math.cos(delta)), abs(math.sin(delta))
        fxh = 0.012 * cd + yh * sd           # finger footprint (rotated by place yaw)
        fyh = 0.012 * sd + yh * cd
        hxh = 0.03 * cd + HAND_HALF * sd     # hand footprint
        hyh = 0.03 * sd + HAND_HALF * cd
        xmb = max(xm, fxh)
        xpb = max(xp, fxh)
        yb = max(r_cup, fyh)
        drawer_objs = []
        for o in objs:
            if o["location"] != "drawer":
                continue
            p = np.array(o["pos"], dtype=float) - c
            s = o["size"]
            tall = (o["pos"][2] + s[2] / 2) > floor + 0.10
            drawer_objs.append(((p[0] - s[0] / 2, p[0] + s[0] / 2, p[1] - s[1] / 2, p[1] + s[1] / 2), tall))
        best = None
        for ux in np.arange(-sx / 2 + xmb + 0.012, sx / 2 - xpb - 0.012 + 1e-9, 0.01):
            for uy in np.arange(-sy / 2 + yb + 0.008, sy / 2 - yb - 0.008 + 1e-9, 0.01):
                cup_rect = (ux - xm, ux + xp, uy - r_cup, uy + r_cup)
                fing_rect = (ux - fxh, ux + fxh, uy - fyh, uy + fyh)
                hand_rect = (ux - hxh, ux + hxh, uy - hyh, uy + hyh)
                clear = 0.2
                for (b, tall) in drawer_objs:
                    clear = min(clear, rect_dist(cup_rect, b), rect_dist(fing_rect, b))
                    if tall:
                        clear = min(clear, rect_dist(hand_rect, b) + 0.01)
                if clear < 0.012:
                    continue
                # opening needed so that the spot is in front of the counter
                world_x0 = c[0] + ux                     # at current opening d0
                lim = min(front_x - 0.07, front_x - 0.03 - xp)
                d_req = d0 + (world_x0 - lim)
                if d_fixed is not None:
                    if d_req > d_fixed + 1e-6:
                        continue
                    d_use = d_fixed
                else:
                    if d_req > d_max:
                        continue
                    d_use = max(d_req, 0.0)
                # prefer spots away from the drawer front panel (keeps the arm off it)
                panel_dist = ux + sx / 2
                cost = d_use - 0.6 * min(clear, 0.05) + 0.05 * abs(uy) - 0.4 * min(panel_dist, 0.13)
                if best is None or cost < best[0]:
                    best = (cost, ux, uy, d_use, clear)
        return best

    # ---------- open the drawer ----------
    def grasp_handle(hpos, tag):
        hx, hy, hz = hpos
        api.open_gripper()
        e = ee()["pos"]
        move([e[0], e[1], max(e[2], z_safe)], tag=tag + " up")
        move([hx - 0.05, hy, max(z_safe, hz + 0.1)], yaw=0.0, tag=tag + " above")
        move([hx - 0.05, hy, hz + 0.08], yaw=0.0, tag=tag + " pre")
        move([hx, hy, hz], yaw=0.0, speed=SLOW, tag=tag + " in")
        w = api.close_gripper()
        log(tag, "handle grip width", round(w, 4))
        return w

    def release_handle(tag):
        api.open_gripper()
        e = ee()["pos"]
        move([e[0] - 0.04, e[1], e[2] + 0.02], speed=SLOW, tag=tag + " back")
        move([e[0] - 0.05, e[1], z_safe], speed=FAST, tag=tag + " up")

    plan = select_spot(drawer, objects)
    if plan is None:
        plan = select_spot(drawer, objects, d_max=0.45)
    log("plan", plan)
    d_target = 0.20 if plan is None else max(plan[3] + 0.03, 0.16)
    d_target = min(d_target, 0.38)
    log("target opening", round(d_target, 3))

    for attempt in range(3):
        drawer = api.get_drawer()
        d_now = drawer["opening"]
        if d_now >= d_target - 0.015:
            break
        handle = api.get_handle()
        hpos = handle["pos"]
        grasp_handle(hpos, "open%d" % attempt)
        pull = d_target - d_now
        move([hpos[0] - pull, hpos[1], hpos[2]], speed=SLOW, tag="pull")
        drawer = api.get_drawer()
        log("after pull opening", round(drawer["opening"], 3))
        release_handle("open%d" % attempt)
    drawer = api.get_drawer()
    objects = api.get_objects()
    log("drawer now", round(drawer["opening"], 3), r3(drawer["interior_center"]))

    spot = select_spot(drawer, objects, d_fixed=drawer["opening"])
    if spot is None:
        log("no clear spot found; using fallback")
        c = drawer["interior_center"]
        sx = drawer["interior_size"][0]
        ux = (c[0] - sx / 2 + 0.07 + min(front_x - 0.07, c[0] + sx / 2)) / 2 - c[0]
        spot = (0, ux, 0.0, drawer["opening"], 0)
    c = drawer["interior_center"]
    tx = c[0] + spot[1]
    ty = c[1] + spot[2]
    log("place target", round(tx, 3), round(ty, 3), "clear", round(spot[4], 3))

    # ---------- pick the cup ----------
    def pick_cup():
        for attempt in range(3):
            cupr = api.get_cup()
            p = cupr["pos"]
            bottom = p[2] - h_cup / 2
            if abs(bottom - top_z) < 0.025:
                bottom = top_z
            gz = bottom + max(0.55 * h_cup, 0.028)
            yaw_now = wrap(cupr["yaw"])
            gy = yaw_now if handle_neg_x else wrap(yaw_now + math.pi)
            gy = wrap(gy + delta)
            # keep the yaw choice consistent with the plan
            api.open_gripper()
            e = ee()["pos"]
            move([e[0], e[1], z_safe], tag="cup up")
            move([p[0], p[1], z_safe], yaw=gy, tag="cup above")
            move([p[0], p[1], gz + 0.06], yaw=gy, tag="cup pre")
            move([p[0], p[1], gz], yaw=gy, speed=SLOW, tag="cup down")
            w = api.close_gripper()
            log("cup grip width", round(w, 4))
            if w > 0.03:
                return gz - bottom
            log("cup grasp missed, retry")
            api.open_gripper()
            move([p[0], p[1], gz + 0.08], tag="cup retry up")
        return None

    off = pick_cup()
    if off is None:
        off = 0.035
    e = ee()["pos"]
    move([e[0], e[1], e[2] + 0.05], speed=SLOW, tag="lift")
    move([e[0], e[1], z_safe], tag="lift2")
    log("cup after lift", r3(api.get_cup()["pos"]), "w", round(ee()["gripper_width"], 4))

    # ---------- carry and place ----------
    # Place yaw = delta, so the cup ends with the same orientation as with delta = 0.
    floor = drawer["floor_z"]
    place_hi = max(top_z + 0.06, floor + off + 0.12)
    move([tx, ty, z_safe], yaw=delta, tag="carry")
    move([tx, ty, place_hi], yaw=delta, tag="over drawer")
    move([tx, ty, floor + off + 0.006], yaw=delta, speed=SLOW, tag="lower")
    api.open_gripper()
    api.wait(0.3)
    e = ee()["pos"]
    move([e[0], e[1], place_hi + 0.03], speed=SLOW, tag="retreat")
    cupr = api.get_cup()
    log("cup placed at", r3(cupr["pos"]), "yaw", round(cupr["yaw"], 3))

    # ---------- close the drawer ----------
    def push_with_fingers(tag, overshoot):
        dr = api.get_drawer()
        d = dr["opening"]
        hp = api.get_handle()["pos"]
        hc = hp[0] + d                                   # handle x when closed
        pre_x = hp[0] - BAR_HALF - FINGER_DEPTH_HALF - 0.025
        e = ee()["pos"]
        near = (abs(e[0] - pre_x) < 0.03 and abs(e[1] - hp[1]) < 0.02 and abs(e[2] - hp[2]) < 0.03)
        if near:
            api.close_gripper()
        else:
            move([e[0], e[1], max(e[2], z_safe)], tag=tag + " up")
            api.close_gripper()
            move([pre_x - 0.02, hp[1], z_safe], yaw=0.0, tag=tag + " above")
            move([pre_x - 0.02, hp[1], hp[2] + 0.08], yaw=0.0, tag=tag + " pre")
        move([pre_x, hp[1], hp[2]], yaw=0.0, speed=SLOW, tag=tag + " in")
        target_x = hc - BAR_HALF - FINGER_DEPTH_HALF + overshoot
        move([target_x, hp[1], hp[2]], yaw=0.0, speed=SLOW, tag=tag + " push")
        log(tag, "after finger push opening", round(api.get_drawer()["opening"], 3))
        e = ee()["pos"]
        move([e[0] - 0.04, e[1], e[2] + 0.02], speed=SLOW, tag=tag + " back")

    drawer = api.get_drawer()
    d_now = drawer["opening"]
    log("before close opening", round(d_now, 3))
    if d_now >= 0.005:
        if d_now > 0.04:
            # grasp-push most of the way, stop short so the hand stays clear of the counter
            hpos = api.get_handle()["pos"]
            grasp_handle(hpos, "close")
            move([hpos[0] + d_now - 0.025, hpos[1], hpos[2]], speed=SLOW, tag="push1")
            log("after push1 opening", round(api.get_drawer()["opening"], 3))
            api.open_gripper()
            e = ee()["pos"]
            move([e[0] - 0.045, e[1], e[2]], speed=SLOW, tag="close release")
        for attempt in range(3):
            d = api.get_drawer()["opening"]
            if d < 0.005:
                break
            push_with_fingers("fpush%d" % attempt, 0.008 + 0.006 * attempt)

        # fallback: original grasp-and-push close
        for attempt in range(2):
            drawer = api.get_drawer()
            d_now = drawer["opening"]
            log("fallback close opening", round(d_now, 3))
            if d_now < 0.005:
                break
            hpos = api.get_handle()["pos"]
            grasp_handle(hpos, "close%d" % attempt)
            move([hpos[0] + d_now + 0.005, hpos[1], hpos[2]], speed=SLOW, tag="push")
            log("after push opening", round(api.get_drawer()["opening"], 3))
            release_handle("close%d" % attempt)

    e = ee()["pos"]
    if e[2] < z_safe - 0.01:
        move([e[0], e[1], z_safe], tag="final up")

    drawer = api.get_drawer()
    cupr = api.get_cup()
    log("final opening", round(drawer["opening"], 3), "cup", r3(cupr["pos"]))
