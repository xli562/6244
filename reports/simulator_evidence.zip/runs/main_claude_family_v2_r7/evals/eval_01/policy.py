"""Robot program for: "Place the cup in the drawer." See TASK.md and API.md."""
import math

import numpy as np

# ---------------------------------------------------------------- constants
OPEN_TARGET = 0.24       # how far to pull the drawer out (m)
OPEN_MAX = 0.32
GRIP_OPEN = 0.08
HAND_HALF_X = 0.040      # half depth of the hand (perpendicular to finger motion)
HAND_HALF_Y = 0.110      # half width of the hand (along finger motion)
GRASP_ABOVE_BOTTOM = 0.026
HANDLE_EXT = 0.030       # how far the cup handle sticks out of the body
SLIDE_OFFSET = 0.085


def wrap(a):
    return (a + math.pi) % (2 * math.pi) - math.pi


def avg(fn, key, n=5):
    vals = [np.array(fn()[key], dtype=float) for _ in range(n)]
    return np.mean(vals, axis=0)


def avg_angle(vals):
    return math.atan2(np.mean(np.sin(vals)), np.mean(np.cos(vals)))


class Robot:
    def __init__(self, api):
        self.api = api

    def log(self, *a):
        self.api.log(" ".join(str(x) for x in a))

    def ee(self):
        e = self.api.get_ee()
        return np.array(e["pos"], dtype=float), e["yaw"], e["gripper_width"]

    def move(self, p, yaw=None, speed=0.15):
        p = [float(v) for v in p]
        r = self.api.move_to(p, yaw=yaw, speed=speed)
        if not r["reached"]:
            self.log("move not reached", np.round(p, 3).tolist(), "err", round(r["error"], 4))
        return r


# ---------------------------------------------------------------- perception
def read_cup(api, n=5):
    rs = [api.get_cup() for _ in range(n)]
    pos = np.mean([r["pos"] for r in rs], axis=0)
    yaw = avg_angle([r["yaw"] for r in rs])
    return pos, yaw, float(np.mean([r["radius"] for r in rs])), float(np.mean([r["height"] for r in rs]))


def read_drawer(api, n=5):
    rs = [api.get_drawer() for _ in range(n)]
    return {
        "opening": float(np.mean([r["opening"] for r in rs])),
        "center": np.mean([r["interior_center"] for r in rs], axis=0),
        "size": np.mean([r["interior_size"] for r in rs], axis=0),
        "floor_z": float(np.mean([r["floor_z"] for r in rs])),
    }


def read_handle(api, n=5):
    return np.mean([api.get_handle()["pos"] for _ in range(n)], axis=0)


def read_counter(api, n=5):
    rs = [api.get_counter() for _ in range(n)]
    return float(np.mean([r["top_z"] for r in rs])), float(np.mean([r["front_x"] for r in rs]))


def rect_gap(a, b):
    """Gap between axis aligned rectangles a=(x0,x1,y0,y1), b likewise. Negative if overlapping."""
    dx = max(b[0] - a[1], a[0] - b[1])
    dy = max(b[2] - a[3], a[2] - b[3])
    if dx > 0 and dy > 0:
        return math.hypot(dx, dy)
    return max(dx, dy)


def obj_rect(o, grow=0.0):
    p, s = o["pos"], o["size"]
    return (p[0] - s[0] / 2 - grow, p[0] + s[0] / 2 + grow, p[1] - s[1] / 2 - grow, p[1] + s[1] / 2 + grow)


# ---------------------------------------------------------------- main
def run(api):
    R = Robot(api)
    top_z, front_x = read_counter(api)
    objs = api.get_objects()
    R.log("counter", round(top_z, 4), round(front_x, 4))
    for o in objs:
        R.log("obj", o["name"], o["location"], np.round(o["pos"], 3).tolist(), np.round(o["size"], 3).tolist())
    # diagnostic: noise structure
    cs = [api.get_cup()["pos"] for _ in range(4)]
    R.log("cup raw reads", np.round(cs, 4).tolist())

    counter_objs = [o for o in objs if o["location"] == "counter"]
    max_top = top_z
    for o in counter_objs:
        max_top = max(max_top, o["pos"][2] + o["size"][2] / 2)
    z_safe = min(max(top_z + 0.13, max_top + 0.07, 0.40), 0.62)
    z_carry = min(max(top_z + 0.13, max_top + GRASP_ABOVE_BOTTOM + 0.06, 0.42), 0.65)
    R.log("z_safe", round(z_safe, 3), "z_carry", round(z_carry, 3))

    # go up first
    p, yaw0, _ = R.ee()
    R.log("ee start", np.round(p, 3).tolist(), round(yaw0, 3))
    R.move([p[0], p[1], max(p[2], z_safe)], speed=0.25)

    # ------------------------------------------------------------ open drawer
    dr = read_drawer(api)
    R.log("drawer", round(dr["opening"], 4), np.round(dr["center"], 3).tolist(), np.round(dr["size"], 3).tolist(), round(dr["floor_z"], 4))
    handle_grasp = None
    target = OPEN_TARGET
    if dr["opening"] < target - 0.01:
        handle_grasp = open_drawer(R, api, target, z_safe)
        dr = read_drawer(api)
        R.log("drawer after open", round(dr["opening"], 4), np.round(dr["center"], 3).tolist())

    # ------------------------------------------------------------ pick cup
    grasp = None
    for attempt in range(3):
        grasp = pick_cup(R, api, top_z, counter_objs, z_safe, z_carry)
        if grasp is not None:
            break
    if grasp is None:
        R.log("failed to pick cup")
        close_drawer(R, api, handle_grasp, z_safe)
        return
    tip_above_bottom, hs = grasp

    # ------------------------------------------------------------ place
    objs = api.get_objects()
    dr = read_drawer(api)
    spot = choose_spot(R, dr, front_x, objs, tip_above_bottom, hs)
    if spot is None and dr["opening"] < OPEN_MAX - 0.02:
        R.log("no free spot; cannot open further while holding cup")
    if spot is None:
        c = dr["center"]
        spot = (min(front_x - 0.06, c[0] - dr["size"][0] / 2 + 0.09), c[1])
    sx, sy = spot
    place_cup(R, api, sx, sy, dr["floor_z"], tip_above_bottom, z_carry, z_safe)

    # ------------------------------------------------------------ close
    close_drawer(R, api, handle_grasp, z_safe)
    dr = read_drawer(api)
    R.log("final drawer opening", round(dr["opening"], 4))
    cp, _, _, _ = read_cup(api)
    R.log("final cup", np.round(cp, 3).tolist())


def open_drawer(R, api, target, z_safe):
    """Grasp the handle and pull the drawer out to `target`. Returns grasp point used at release."""
    release = None
    for attempt in range(3):
        dr = read_drawer(api)
        if dr["opening"] >= target - 0.01:
            break
        h = read_handle(api)
        R.log("handle", np.round(h, 4).tolist())
        gx, gy, gz = h[0] - 0.003, h[1], h[2]
        R.move([gx, gy, z_safe], yaw=0.0, speed=0.25)
        R.move([gx, gy, gz + 0.06], yaw=0.0, speed=0.15)
        api.open_gripper()
        R.move([gx, gy, gz], speed=0.06)
        w = api.close_gripper()
        R.log("handle grip width", round(w, 4))
        pull = target - dr["opening"]
        R.move([gx - pull, gy, gz], speed=0.08)
        api.wait(0.2)
        e, _, _ = R.ee()
        release = e.copy()
        api.open_gripper()
        R.move([e[0] - 0.01, e[1], z_safe], speed=0.15)
        dr2 = read_drawer(api)
        R.log("opening now", round(dr2["opening"], 4), "release", np.round(e, 4).tolist())
        release = (release, dr2["opening"])
    return release


def close_drawer(R, api, handle_grasp, z_safe):
    for attempt in range(3):
        dr = read_drawer(api)
        if dr["opening"] < 0.006:
            break
        if handle_grasp is not None and attempt == 0:
            rel, op_at_rel = handle_grasp
            # drawer may have moved slightly: shift by difference of openings
            gx = rel[0] - (dr["opening"] - op_at_rel)
            gy, gz = rel[1], rel[2]
        else:
            h = read_handle(api)
            gx, gy, gz = h[0] - 0.003, h[1], h[2]
        R.log("closing from", round(gx, 4), round(gy, 4), round(gz, 4), "opening", round(dr["opening"], 4))
        R.move([gx, gy, z_safe], yaw=0.0, speed=0.25)
        R.move([gx, gy, gz + 0.06], yaw=0.0, speed=0.15)
        api.open_gripper()
        R.move([gx, gy, gz], speed=0.06)
        api.close_gripper()
        R.move([gx + dr["opening"] + 0.008, gy, gz], speed=0.08)
        api.wait(0.2)
        e, _, _ = R.ee()
        api.open_gripper()
        R.move([e[0] - 0.01, e[1], z_safe], speed=0.15)
    dr = read_drawer(api)
    R.log("opening after close", round(dr["opening"], 4))


def pick_cup(R, api, top_z, counter_objs, z_safe, z_carry):
    c, a, r, h = read_cup(api)
    R.log("cup", np.round(c, 4).tolist(), "yaw", round(a, 3), "r", round(r, 4), "h", round(h, 4))
    # gripper yaw: closing axis perpendicular to the handle direction
    g = wrap(a)
    if g > math.pi / 2:
        g -= math.pi
    if g < -math.pi / 2:
        g += math.pi
    u = np.array([-math.sin(g), math.cos(g)])   # closing axis
    v = np.array([math.cos(g), math.sin(g)])    # approach axis
    bottom = 0.5 * ((c[2] - h / 2) + top_z)
    tip_z = bottom + GRASP_ABOVE_BOTTOM

    # pick approach side (+v or -v) by obstacle clearance and reachability
    best = None
    for s in (1.0, -1.0):
        start = c[:2] + s * SLIDE_OFFSET * v
        clear = 1.0
        for o in counter_objs:
            if o["pos"][2] + o["size"][2] / 2 < tip_z - 0.005:
                continue
            orr = obj_rect(o)
            # sample hand footprint along slide
            for t in np.linspace(0, 1, 6):
                ctr = c[:2] + s * SLIDE_OFFSET * v * (1 - t)
                for du in np.linspace(-HAND_HALF_Y, HAND_HALF_Y, 9):
                    for dv in np.linspace(-HAND_HALF_X, HAND_HALF_X, 3):
                        q = ctr + du * u + dv * v
                        dx = max(orr[0] - q[0], q[0] - orr[1], 0)
                        dy = max(orr[2] - q[1], q[1] - orr[3], 0)
                        clear = min(clear, math.hypot(dx, dy))
        reach = np.linalg.norm(start)
        score = min(clear, 0.03) * 10 - max(0.0, reach - 0.62) * 5 - reach * 0.1
        R.log("side", s, "clear", round(clear, 3), "reach", round(reach, 3), "score", round(score, 3))
        if best is None or score > best[0]:
            best = (score, s, start)
    _, s, start = best

    api.open_gripper()
    R.move([start[0], start[1], z_safe], yaw=g, speed=0.25)
    R.move([start[0], start[1], tip_z + 0.05], yaw=g, speed=0.15)
    R.move([start[0], start[1], tip_z], speed=0.06)
    R.move([c[0], c[1], tip_z], speed=0.05)
    w = api.close_gripper()
    R.log("cup grip width", round(w, 4))
    if w < 0.02 or w > 0.075:
        api.open_gripper()
        e, _, _ = R.ee()
        R.move([e[0], e[1], z_safe], speed=0.15)
        return None
    e, gy, _ = R.ee()
    tip_above_bottom = e[2] - bottom
    R.move([e[0], e[1], e[2] + 0.04], speed=0.06)
    R.move([e[0], e[1], z_carry], speed=0.15)
    _, _, w2 = R.ee()
    if w2 < 0.02:
        R.log("cup lost while lifting", round(w2, 4))
        api.open_gripper()
        return None
    # handle direction after rotating gripper to yaw 0
    rel = wrap(a - g)
    hs = -1.0 if math.cos(rel) > 0 else 1.0
    R.log("grasped; tip above bottom", round(tip_above_bottom, 4), "handle dir x", hs)
    return tip_above_bottom, hs


def choose_spot(R, dr, front_x, objs, tip_above_bottom, hs):
    c, s = dr["center"], dr["size"]
    fz = dr["floor_z"]
    x0, x1 = c[0] - s[0] / 2, c[0] + s[0] / 2
    y0, y1 = c[1] - s[1] / 2, c[1] + s[1] / 2
    tip_z = fz + tip_above_bottom
    wall_top = fz + 0.082
    palm_low = tip_z + 0.045 < wall_top + 0.01
    r = 0.031
    m = 0.012
    dobjs = [o for o in objs if o["location"] == "drawer"]
    R.log("interior x", round(x0, 3), round(x1, 3), "y", round(y0, 3), round(y1, 3), "front", round(front_x, 3))
    best = None
    for x in np.arange(x0, min(x1, front_x), 0.004):
        cup_x0 = x - r - (HANDLE_EXT if hs < 0 else 0.0)
        cup_x1 = x + r + (HANDLE_EXT if hs > 0 else 0.0)
        if cup_x0 < x0 + m or cup_x1 > x1 - m:
            continue
        if x - HAND_HALF_X < x0 + 0.008 or x + HAND_HALF_X > front_x - 0.015:
            continue
        for y in np.arange(y0, y1, 0.004):
            if y - r < y0 + m or y + r > y1 - m:
                continue
            if palm_low and (y - HAND_HALF_Y < y0 + 0.005 or y + HAND_HALF_Y > y1 - 0.005):
                continue
            cup_rect = (cup_x0, cup_x1, y - r, y + r)
            hand_rect = (x - HAND_HALF_X, x + HAND_HALF_X, y - HAND_HALF_Y, y + HAND_HALF_Y)
            clear = 0.1
            for o in dobjs:
                orr = obj_rect(o)
                clear = min(clear, rect_gap(cup_rect, orr))
                if o["pos"][2] + o["size"][2] / 2 > tip_z - 0.01:
                    clear = min(clear, rect_gap(hand_rect, orr) + 0.01)
            # walls clearance
            clear = min(clear, cup_x0 - x0, x1 - cup_x1, y - r - y0, y1 - (y + r))
            score = min(clear, 0.05) - 0.02 * abs(x - (x0 + front_x) / 2) - 0.01 * abs(y - c[1])
            if best is None or score > best[0]:
                best = (score, x, y, clear)
    if best is None:
        return None
    R.log("spot", round(best[1], 3), round(best[2], 3), "clear", round(best[3], 3))
    if best[3] < 0.01:
        R.log("spot clearance small")
    return best[1], best[2]


def place_cup(R, api, x, y, floor_z, tip_above_bottom, z_carry, z_safe):
    tip_z = floor_z + tip_above_bottom + 0.008
    R.move([x, y, z_carry], yaw=0.0, speed=0.2)
    R.move([x, y, tip_z + 0.05], speed=0.12)
    R.move([x, y, tip_z], speed=0.04)
    api.wait(0.2)
    api.open_gripper()
    api.wait(0.2)
    e, _, _ = R.ee()
    R.move([e[0], e[1], e[2] + 0.05], speed=0.05)
    R.move([e[0], e[1], z_safe], speed=0.15)
    cp, _, _, _ = read_cup(api)
    R.log("cup after place", np.round(cp, 4).tolist())
