"""Robot program for: "Place the cup in the drawer." See TASK.md and API.md."""
import math

import numpy as np

# ---------------------------------------------------------------- constants
OPEN_TARGET = 0.24       # how far to pull the drawer out (m)
HAND_HALF_X = 0.040      # half depth of the hand (perpendicular to finger motion)
HAND_HALF_Y = 0.110      # half width of the hand (along finger motion)
GRASP_ABOVE_BOTTOM = 0.038   # fingertip height above cup bottom: grip the upper, cylindrical part
HANDLE_EXT = 0.030       # how far the cup handle sticks out of the body
SLIDE_OFFSET = 0.085
NREAD = 3

# reconstruction priors (SCENE.md)
P_TOP_Z = 0.292
P_FRONT_X = 0.557
P_FLOOR_Z = 0.078
P_HANDLE = (0.516, -0.088, 0.205)


def wrap(a):
    return (a + math.pi) % (2 * math.pi) - math.pi


def avg_angle(vals):
    return math.atan2(np.mean(np.sin(vals)), np.mean(np.cos(vals)))


class Robot:
    def __init__(self, api):
        self.api = api

    def log(self, *a):
        self.api.log(" ".join(str(x) for x in a))

    def ee(self):
        e = self.api.get_ee()
        return np.array(e["pos"], dtype=float), e["yaw"], e["gripper_width"]

    def move(self, p, yaw=None, speed=0.15):
        p = [float(v) for v in p]
        return self.api.move_to(p, yaw=yaw, speed=speed)

    def pmove(self, p, yaw=None, speed=0.1, tol=0.002, iters=2, max_corr=0.015):
        """Move, then correct the steady-state error of the controller."""
        p = np.array(p, dtype=float)
        cmd = p.copy()
        self.move(cmd, yaw=yaw, speed=speed)
        e = None
        for _ in range(iters):
            e, _, _ = self.ee()
            d = p - e
            if np.linalg.norm(d) < tol:
                break
            n = np.linalg.norm(d)
            if n > max_corr:
                d = d * (max_corr / n)
            cmd = cmd + d
            self.move(cmd, yaw=yaw, speed=min(speed, 0.05))
        e, _, _ = self.ee()
        return e


# ---------------------------------------------------------------- perception
def read_cup(api, n=NREAD):
    rs = [api.get_cup() for _ in range(n)]
    pos = np.mean([r["pos"] for r in rs], axis=0)
    yaw = avg_angle([r["yaw"] for r in rs])
    return pos, yaw, float(np.mean([r["radius"] for r in rs])), float(np.mean([r["height"] for r in rs]))


def read_drawer(api, n=NREAD):
    rs = [api.get_drawer() for _ in range(n)]
    return {
        "opening": float(np.mean([r["opening"] for r in rs])),
        "center": np.mean([r["interior_center"] for r in rs], axis=0),
        "size": np.mean([r["interior_size"] for r in rs], axis=0),
        "floor_z": float(np.mean([r["floor_z"] for r in rs])),
    }


def read_counter(api, n=NREAD):
    rs = [api.get_counter() for _ in range(n)]
    top = float(np.mean([r["top_z"] for r in rs]))
    front = float(np.mean([r["front_x"] for r in rs]))
    # fuse with reconstruction prior
    return (2 * top + P_TOP_Z) / 3.0, (2 * front + P_FRONT_X) / 3.0


def handle_estimate(api, front_x):
    dr = read_drawer(api)
    h = np.mean([api.get_handle()["pos"] for _ in range(NREAD)], axis=0)
    op = dr["opening"]
    hx = (2 * h[0] + 2 * (front_x - 0.041 - op) + (P_HANDLE[0] - op)) / 5.0
    hy = (2 * h[1] + dr["center"][1] + P_HANDLE[1]) / 4.0
    hz = (2 * h[2] + P_HANDLE[2]) / 3.0
    return np.array([hx, hy, hz]), op


def rect_gap(a, b):
    dx = max(b[0] - a[1], a[0] - b[1])
    dy = max(b[2] - a[3], a[2] - b[3])
    if dx > 0 and dy > 0:
        return math.hypot(dx, dy)
    return max(dx, dy)


def obj_rect(o, grow=0.0):
    p, s = o["pos"], o["size"]
    return (p[0] - s[0] / 2 - grow, p[0] + s[0] / 2 + grow, p[1] - s[1] / 2 - grow, p[1] + s[1] / 2 + grow)


# ---------------------------------------------------------------- main
def run(api):
    R = Robot(api)
    top_z, front_x = read_counter(api)
    objs = api.get_objects()
    R.log("counter", round(top_z, 4), round(front_x, 4))

    counter_objs = [o for o in objs if o["location"] == "counter"]
    max_top = top_z
    for o in counter_objs:
        max_top = max(max_top, o["pos"][2] + o["size"][2] / 2)
    z_safe = min(max(top_z + 0.13, max_top + 0.07, 0.40), 0.62)
    z_carry = min(max(top_z + 0.14, max_top + GRASP_ABOVE_BOTTOM + 0.06, 0.43), 0.65)

    p, yaw0, _ = R.ee()
    R.move([p[0], p[1], max(p[2], z_safe)], speed=0.3)

    # ------------------------------------------------------------ open drawer
    dr = read_drawer(api)
    R.log("drawer open", round(dr["opening"], 4), "floor", round(dr["floor_z"], 4))
    handle_grasp = None
    if dr["opening"] < OPEN_TARGET - 0.015:
        handle_grasp = open_drawer(R, api, OPEN_TARGET, z_safe, front_x)

    # ------------------------------------------------------------ pick cup
    grasp = None
    for attempt in range(3):
        grasp = pick_cup(R, api, top_z, counter_objs, z_safe, z_carry)
        if grasp is not None:
            break
    if grasp is None:
        R.log("failed to pick cup")
        close_drawer(R, api, handle_grasp, z_safe, front_x)
        return
    tip_above_bottom, hs = grasp

    # ------------------------------------------------------------ place
    objs = api.get_objects()
    dr = read_drawer(api)
    floor_z = (2 * dr["floor_z"] + P_FLOOR_Z) / 3.0
    spot = choose_spot(R, dr, front_x, objs, floor_z, tip_above_bottom, hs)
    if spot is None:
        c = dr["center"]
        spot = (min(front_x - 0.06, c[0] - dr["size"][0] / 2 + 0.09), c[1])
    place_cup(R, api, spot[0], spot[1], floor_z, tip_above_bottom, z_carry, z_safe)

    # ------------------------------------------------------------ close
    close_drawer(R, api, handle_grasp, z_safe, front_x)


def grasp_handle(R, api, z_safe, front_x):
    """Grasp the drawer handle; returns the fingertip position of the grasp or None."""
    h, op = handle_estimate(api, front_x)
    R.log("handle est", np.round(h, 4).tolist(), "op", round(op, 4))
    for dx in (0.0, -0.011, 0.011, -0.02):
        gx, gy, gz = h[0] + dx, h[1], h[2] - 0.005
        R.move([gx, gy, z_safe], yaw=0.0, speed=0.3)
        api.open_gripper()
        R.pmove([gx, gy, gz + 0.05], yaw=0.0, speed=0.15)
        R.pmove([gx, gy, gz], yaw=0.0, speed=0.06)
        w = api.close_gripper()
        R.log("handle grip dx", dx, "w", round(w, 4))
        if w > 0.006:
            e, _, _ = R.ee()
            return e
        api.open_gripper()
        R.move([gx, gy, gz + 0.08], speed=0.15)
    return None


def open_drawer(R, api, target, z_safe, front_x):
    release = None
    for attempt in range(3):
        dr = read_drawer(api)
        if dr["opening"] >= target - 0.015:
            break
        g = grasp_handle(R, api, z_safe, front_x)
        if g is None:
            R.log("could not grasp handle")
            break
        pull = target - dr["opening"]
        R.move([g[0] - pull, g[1], g[2]], speed=0.08)
        api.wait(0.2)
        e, _, _ = R.ee()
        api.open_gripper()
        R.move([e[0] - 0.01, e[1], z_safe], speed=0.15)
        op = read_drawer(api)["opening"]
        release = (e.copy(), op)
        R.log("opening now", round(op, 4))
    return release


def close_drawer(R, api, handle_grasp, z_safe, front_x):
    for attempt in range(3):
        dr = read_drawer(api)
        if dr["opening"] < 0.006:
            break
        ok = False
        if handle_grasp is not None and attempt == 0:
            rel, op_at_rel = handle_grasp
            gx = rel[0] - (dr["opening"] - op_at_rel)
            gy, gz = rel[1], rel[2]
            R.move([gx, gy, z_safe], yaw=0.0, speed=0.3)
            api.open_gripper()
            R.pmove([gx, gy, gz + 0.05], yaw=0.0, speed=0.15)
            R.pmove([gx, gy, gz], yaw=0.0, speed=0.06)
            w = api.close_gripper()
            ok = w > 0.006
            R.log("close regrasp w", round(w, 4))
            if ok:
                g = R.ee()[0]
            else:
                api.open_gripper()
                R.move([gx, gy, gz + 0.08], speed=0.15)
        if not ok:
            g = grasp_handle(R, api, z_safe, front_x)
        if g is not None:
            # phase 1: pull the handle most of the way in while holding it
            if dr["opening"] > 0.04:
                R.move([g[0] + dr["opening"] - 0.03, g[1], g[2]], speed=0.07)
                api.wait(0.2)
            e, _, _ = R.ee()
            # phase 2: let go, back off in front of the bar, push its front face with
            # the closed fingertips (keeps the hand body clear of the counter front)
            api.open_gripper()
            R.move([e[0] - 0.04, e[1], e[2]], speed=0.05)
            api.close_gripper()
            op = read_drawer(api)["opening"]
            R.move([e[0] + op - 0.004, e[1], e[2]], speed=0.05)
        else:
            # no grasp possible: push the handle bar with closed fingers
            h, op = handle_estimate(api, front_x)
            api.close_gripper()
            R.move([h[0] - 0.045, h[1], z_safe], yaw=0.0, speed=0.3)
            R.pmove([h[0] - 0.045, h[1], h[2]], speed=0.06)
            R.move([h[0] + op - 0.012, h[1], h[2]], speed=0.05)
        api.wait(0.2)
        e, _, _ = R.ee()
        R.move([e[0] - 0.03, e[1], e[2]], speed=0.08)
        R.move([e[0] - 0.03, e[1], z_safe], speed=0.15)
        api.open_gripper()
    R.log("opening after close", round(read_drawer(api)["opening"], 4))


def pick_cup(R, api, top_z, counter_objs, z_safe, z_carry):
    c, a, r, h = read_cup(api)
    R.log("cup", np.round(c, 4).tolist(), "yaw", round(a, 3))
    g = wrap(a)
    if g > math.pi / 2:
        g -= math.pi
    if g < -math.pi / 2:
        g += math.pi
    u = np.array([-math.sin(g), math.cos(g)])   # closing axis
    v = np.array([math.cos(g), math.sin(g)])    # approach axis (along the cup handle)
    bottom = (2 * top_z + (c[2] - h / 2)) / 3.0
    tip_z = bottom + GRASP_ABOVE_BOTTOM

    best = None
    for s in (1.0, -1.0):
        start = c[:2] + s * SLIDE_OFFSET * v
        clear = 1.0
        for o in counter_objs:
            if o["pos"][2] + o["size"][2] / 2 < tip_z - 0.005:
                continue
            orr = obj_rect(o)
            for t in np.linspace(0, 1, 6):
                ctr = c[:2] + s * SLIDE_OFFSET * v * (1 - t)
                for du in np.linspace(-HAND_HALF_Y, HAND_HALF_Y, 9):
                    for dv in np.linspace(-HAND_HALF_X, HAND_HALF_X, 3):
                        q = ctr + du * u + dv * v
                        dx = max(orr[0] - q[0], q[0] - orr[1], 0)
                        dy = max(orr[2] - q[1], q[1] - orr[3], 0)
                        clear = min(clear, math.hypot(dx, dy))
        reach = np.linalg.norm(start)
        score = min(clear, 0.03) * 10 - max(0.0, reach - 0.62) * 5 - reach * 0.1
        if best is None or score > best[0]:
            best = (score, s, start)
    _, s, start = best

    api.open_gripper()
    R.move([start[0], start[1], z_safe], yaw=g, speed=0.3)
    R.pmove([start[0], start[1], tip_z + 0.04], yaw=g, speed=0.15)
    R.pmove([start[0], start[1], tip_z], yaw=g, speed=0.05)
    tgt = np.array([c[0], c[1], tip_z])
    e = R.pmove(tgt, yaw=g, speed=0.04)
    w = api.close_gripper()
    R.log("cup grip w", round(w, 4), "side", s)
    if w < 0.01:
        api.open_gripper()
        R.move([e[0], e[1], z_safe], speed=0.15)
        return None
    # centre the grasp along v using the chord width
    w_full = 2 * r
    if w < w_full - 0.0035:
        off = math.sqrt(max(r * r - (w / 2) ** 2, 0.0))
        p0 = R.ee()[0]
        best_w, best_pos = w, p0
        last_pos = p0
        for sign in (1.0, -1.0):
            api.open_gripper()
            q = np.array([p0[0] + sign * off * v[0], p0[1] + sign * off * v[1], tip_z])
            last_pos = R.pmove(q, yaw=g, speed=0.03)
            w2 = api.close_gripper()
            R.log("recentre", sign, "off", round(off, 4), "w", round(w2, 4))
            if w2 > best_w + 0.0005:
                best_w, best_pos = w2, last_pos
            if best_w >= w_full - 0.0035:
                break
        if np.linalg.norm(best_pos - last_pos) > 0.002:
            api.open_gripper()
            R.pmove([best_pos[0], best_pos[1], tip_z], yaw=g, speed=0.03)
            w = api.close_gripper()
        else:
            w = R.ee()[2]
        if w < 0.01:
            api.open_gripper()
            e = R.ee()[0]
            R.move([e[0], e[1], z_safe], speed=0.15)
            return None
    e, _, _ = R.ee()
    tip_above_bottom = e[2] - bottom
    R.move([e[0], e[1], e[2] + 0.03], speed=0.04)
    R.move([e[0], e[1], z_carry], speed=0.12)
    _, _, w2 = R.ee()
    if w2 < 0.01:
        R.log("cup lost while lifting")
        api.open_gripper()
        return None
    rel = wrap(a - g)
    hs = -1.0 if math.cos(rel) > 0 else 1.0
    R.log("grasped w", round(w2, 4), "tab", round(tip_above_bottom, 4), "hs", hs)
    return tip_above_bottom, hs


def choose_spot(R, dr, front_x, objs, floor_z, tip_above_bottom, hs):
    c, s = dr["center"], dr["size"]
    x0, x1 = c[0] - s[0] / 2, c[0] + s[0] / 2
    y0, y1 = c[1] - s[1] / 2, c[1] + s[1] / 2
    tip_z = floor_z + tip_above_bottom
    wall_top = floor_z + 0.082
    palm_low = tip_z + 0.045 < wall_top + 0.01
    r = 0.031
    m = 0.012
    dobjs = [o for o in objs if o["location"] == "drawer"]
    best = None
    for x in np.arange(x0, min(x1, front_x), 0.004):
        cup_x0 = x - r - (HANDLE_EXT if hs < 0 else 0.0)
        cup_x1 = x + r + (HANDLE_EXT if hs > 0 else 0.0)
        if cup_x0 < x0 + m or cup_x1 > x1 - m:
            continue
        if x - HAND_HALF_X < x0 + 0.008 or x + HAND_HALF_X > front_x - 0.015:
            continue
        for y in np.arange(y0, y1, 0.004):
            if y - r < y0 + m or y + r > y1 - m:
                continue
            if palm_low and (y - HAND_HALF_Y < y0 + 0.005 or y + HAND_HALF_Y > y1 - 0.005):
                continue
            cup_rect = (cup_x0, cup_x1, y - r, y + r)
            hand_rect = (x - HAND_HALF_X, x + HAND_HALF_X, y - HAND_HALF_Y, y + HAND_HALF_Y)
            clear = 0.1
            for o in dobjs:
                orr = obj_rect(o)
                clear = min(clear, rect_gap(cup_rect, orr))
                if o["pos"][2] + o["size"][2] / 2 > tip_z - 0.01:
                    clear = min(clear, rect_gap(hand_rect, orr) + 0.01)
            clear = min(clear, cup_x0 - x0, x1 - cup_x1, y - r - y0, y1 - (y + r))
            score = min(clear, 0.05) - 0.02 * abs(x - (x0 + front_x) / 2) - 0.01 * abs(y - c[1])
            if best is None or score > best[0]:
                best = (score, x, y, clear)
    if best is None:
        return None
    R.log("spot", round(best[1], 3), round(best[2], 3), "clear", round(best[3], 3), "x0", round(x0, 3))
    return best[1], best[2]


def place_cup(R, api, x, y, floor_z, tip_above_bottom, z_carry, z_safe):
    tip_z = floor_z + tip_above_bottom - 0.003
    R.move([x, y, z_carry], yaw=0.0, speed=0.15)
    R.pmove([x, y, tip_z + 0.04], yaw=0.0, speed=0.1)
    api.wait(0.3)
    R.pmove([x, y, tip_z], speed=0.025, iters=1, max_corr=0.006)
    api.wait(0.3)
    e, _, _ = R.ee()
    R.log("place ee", np.round(e, 4).tolist(), "target z", round(tip_z, 4))
    api.open_gripper()
    api.wait(0.2)
    R.move([e[0], e[1], e[2] + 0.04], speed=0.04)
    R.move([e[0], e[1], z_safe], speed=0.15)
    cp, _, _, _ = read_cup(api, 1)
    R.log("cup after place", np.round(cp, 4).tolist())
