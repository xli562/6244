"""Robot program for: "Place the cup in the drawer." See TASK.md and API.md.

Plan
  1. Open the drawer far enough that a free spot of its floor lies in front of the
     counter (reachable from above): grasp the top part of the handle bar from above
     and pull toward the robot.
  2. Pick the cup with the fingers perpendicular to its handle.
  3. Carry it above everything, choose a free spot in the open part of the drawer
     (away from objects already in it) and set it down upright, gripper yaw 0 so the
     hand is slim along x (between drawer front panel and counter front).
  4. Release, lift out, push the drawer closed with the closed fingers against the
     handle bar, verify, retreat.
"""
import math

import numpy as np

# ---------------------------------------------------------------- constants
GRIP_MAX = 0.08
HAND_HALF_X = 0.035      # half thickness of the hand housing across the finger axis (yaw 0)
HAND_HALF_Y = 0.105      # half length of the hand housing along the finger axis (yaw 0)
FINGER_LEN = 0.055       # fingertip -> bottom of hand housing
HANDLE_BAR_HALF = 0.0715  # half length of the vertical handle bar
HANDLE_GRIP_UP = 0.035   # grasp the bar this much above the reported grasp point
TARGET_OPENING = 0.22    # how far we want the drawer open for placing
CUP_HANDLE_LEN = 0.028   # how far the cup handle sticks out of the body


def wrap(a):
    return (a + math.pi) % (2 * math.pi) - math.pi


def avg_read(fn, n=3):
    vals = [fn() for _ in range(n)]
    return vals


class Robot:
    def __init__(self, api):
        self.api = api

    def log(self, msg):
        try:
            self.api.log(str(msg))
        except Exception:
            pass

    def ee(self):
        return self.api.get_ee()

    def move(self, pos, yaw=None, speed=0.15, tag=""):
        pos = [float(p) for p in pos]
        if yaw is None:
            r = self.api.move_to(pos, speed=speed)
        else:
            r = self.api.move_to(pos, yaw=float(yaw), speed=speed)
        if not r.get("reached", True):
            self.log("move %s not reached: target=%s err=%.4f" % (tag, np.round(pos, 3), r.get("error", -1)))
        return r

    def lift_to(self, z, speed=0.15):
        e = self.ee()["pos"]
        if e[2] < z:
            self.move([e[0], e[1], z], speed=speed, tag="lift")


# ---------------------------------------------------------------- perception
def read_cup(api):
    cs = [api.get_cup() for _ in range(3)]
    pos = np.mean([c["pos"] for c in cs], axis=0)
    yaws = [c["yaw"] for c in cs]
    yaw = math.atan2(np.mean([math.sin(y) for y in yaws]), np.mean([math.cos(y) for y in yaws]))
    return {"pos": pos, "yaw": yaw, "radius": float(cs[0]["radius"]), "height": float(cs[0]["height"])}


def read_handle(api):
    return np.mean([api.get_handle()["pos"] for _ in range(3)], axis=0)


def read_drawer(api):
    ds = [api.get_drawer() for _ in range(3)]
    return {
        "opening": float(np.mean([d["opening"] for d in ds])),
        "center": np.mean([d["interior_center"] for d in ds], axis=0),
        "size": np.mean([d["interior_size"] for d in ds], axis=0),
        "floor_z": float(np.mean([d["floor_z"] for d in ds])),
    }


def safe_height(api, counter):
    top = counter["top_z"]
    hi = top
    for o in api.get_objects():
        if o.get("location") == "counter":
            hi = max(hi, o["pos"][2] + o["size"][2] / 2.0)
    # fingertip height: cup hangs ~0.035 below the fingertips
    return max(top + 0.13, hi + 0.08)


# ---------------------------------------------------------------- drawer
def grasp_handle(rb, z_safe):
    api = rb.api
    h = read_handle(api)
    gz = h[2] + HANDLE_GRIP_UP
    rb.log("handle at %s, grasp z %.3f" % (np.round(h, 3), gz))
    api.open_gripper()
    rb.lift_to(z_safe)
    rb.move([h[0], h[1], max(z_safe, gz + 0.1)], yaw=0.0, speed=0.2, tag="above handle")
    rb.move([h[0], h[1], gz + 0.05], yaw=0.0, speed=0.15, tag="near handle")
    rb.move([h[0], h[1], gz], yaw=0.0, speed=0.05, tag="handle grasp")
    w = api.close_gripper()
    rb.log("handle grip width %.4f" % w)
    return w > 0.004, h


def release_handle_up(rb, z_up):
    api = rb.api
    api.open_gripper()
    e = rb.ee()["pos"]
    rb.move([e[0], e[1], e[2] + 0.06], speed=0.08, tag="off handle")
    rb.lift_to(z_up)


def open_drawer(rb, counter, z_safe):
    api = rb.api
    d = read_drawer(api)
    rb.log("drawer start opening %.3f" % d["opening"])
    if d["opening"] >= TARGET_OPENING - 0.02:
        return d
    for attempt in range(2):
        d = read_drawer(api)
        need = TARGET_OPENING - d["opening"]
        if need < 0.02:
            break
        ok, h = grasp_handle(rb, z_safe)
        if not ok:
            rb.log("handle grasp missed, retrying")
            release_handle_up(rb, z_safe)
            continue
        e = rb.ee()["pos"]
        rb.move([e[0] - need, e[1], e[2]], speed=0.08, tag="pull drawer")
        release_handle_up(rb, z_safe)
    d = read_drawer(api)
    rb.log("drawer opening after pull %.3f" % d["opening"])
    return d


def close_drawer(rb, counter, z_up):
    api = rb.api
    d = read_drawer(api)
    h = read_handle(api)
    pz = h[2] + HANDLE_GRIP_UP
    api.close_gripper()
    x0 = h[0] - 0.038
    rb.lift_to(z_up)
    rb.move([x0, h[1], z_up], yaw=0.0, speed=0.2, tag="above push")
    rb.move([x0, h[1], pz], yaw=0.0, speed=0.12, tag="push start")
    for attempt in range(4):
        d = read_drawer(api)
        h = read_handle(api)
        # closed fingers have ~0.01 half width; bar half thickness 0.008
        closed_bar_x = h[0] + d["opening"]
        contact_x = closed_bar_x - 0.018
        target = contact_x + 0.010
        e = rb.ee()["pos"]
        pre = contact_x - 0.03
        if e[0] < pre:
            rb.move([pre, h[1], pz], speed=0.08, tag="push drawer")
        rb.move([target, h[1], pz], speed=0.025, tag="push drawer slow")
        api.wait(0.4)
        # release the pressure very slowly so the drawer does not spring back open
        e = rb.ee()["pos"]
        rb.move([e[0] - 0.012, e[1], pz], speed=0.006, tag="release push")
        e = rb.ee()["pos"]
        rb.move([e[0] - 0.012, e[1], pz], speed=0.02, tag="back off")
        api.wait(0.6)
        d2 = read_drawer(api)
        rb.log("drawer opening after push %d: %.4f" % (attempt, d2["opening"]))
        if d2["opening"] < 0.004:
            break
    e = rb.ee()["pos"]
    rb.move([e[0] - 0.02, e[1], e[2]], speed=0.1, tag="back off 2")
    rb.lift_to(z_up)
    return read_drawer(api)


# ---------------------------------------------------------------- placement spot
def box_dist(px, py, o, pad=0.0):
    """2D distance from point to an object's footprint (AABB)."""
    cx, cy = o["pos"][0], o["pos"][1]
    hx, hy = o["size"][0] / 2.0 + pad, o["size"][1] / 2.0 + pad
    dx = max(abs(px - cx) - hx, 0.0)
    dy = max(abs(py - cy) - hy, 0.0)
    return math.hypot(dx, dy)


def rect_rect_gap(c1, h1, o):
    cx, cy = o["pos"][0], o["pos"][1]
    hx, hy = o["size"][0] / 2.0, o["size"][1] / 2.0
    dx = max(abs(c1[0] - cx) - h1[0] - hx, 0.0)
    dy = max(abs(c1[1] - cy) - h1[1] - hy, 0.0)
    return math.hypot(dx, dy)


def choose_spot(rb, d, counter, cup_r, handle_dir_x, place_fz):
    """handle_dir_x: +1 if the cup handle will point +x, -1 if -x."""
    api = rb.api
    cx, cy = d["center"][0], d["center"][1]
    sx, sy = d["size"][0], d["size"][1]
    xmin, xmax = cx - sx / 2.0, cx + sx / 2.0
    ymin, ymax = cy - sy / 2.0, cy + sy / 2.0
    front_x = counter["front_x"]

    back = cup_r + (CUP_HANDLE_LEN if handle_dir_x < 0 else 0.0)
    lo = xmin + max(back, HAND_HALF_X) + 0.010
    hi = min(front_x - HAND_HALF_X - 0.012, xmax - cup_r - 0.01)
    if hi < lo:
        rb.log("placement x-range empty lo=%.3f hi=%.3f, using midpoint" % (lo, hi))
        hi = lo = 0.5 * (lo + hi)
    wall_top = d["floor_z"] + 0.082
    hand_bottom = place_fz + FINGER_LEN
    ym = 0.055 if hand_bottom > wall_top + 0.01 else HAND_HALF_Y + 0.01
    ylo, yhi = ymin + ym, ymax - ym
    if yhi < ylo:
        ylo = yhi = cy

    objs = [o for o in api.get_objects() if o.get("location") == "drawer"]
    best = None
    for x in np.linspace(lo, hi, 12):
        for y in np.linspace(ylo, yhi, 25):
            clr = 0.1
            for o in objs:
                top = o["pos"][2] + o["size"][2] / 2.0
                c = box_dist(x, y, o) - cup_r
                hpx = x + handle_dir_x * (cup_r + CUP_HANDLE_LEN * 0.8)
                c = min(c, box_dist(hpx, y, o) - 0.008)
                # open fingers
                c = min(c, rect_rect_gap((x, y), (0.012, GRIP_MAX / 2 + 0.012), o))
                if top > hand_bottom - 0.01:
                    c = min(c, rect_rect_gap((x, y), (HAND_HALF_X, HAND_HALF_Y), o))
                clr = min(clr, c)
            score = min(clr, 0.05) - 0.05 * abs(y - cy) / max(sy, 1e-3) - 0.02 * abs(x - 0.5 * (lo + hi)) / max(sx, 1e-3)
            if best is None or score > best[0]:
                best = (score, x, y, clr)
    rb.log("spot x=%.3f y=%.3f clearance=%.3f (xrange %.3f..%.3f, %d drawer objs)" %
           (best[1], best[2], best[3], lo, hi, len(objs)))
    return best[1], best[2], best[3]


# ---------------------------------------------------------------- main
def run(api):
    rb = Robot(api)
    counter = api.get_counter()
    rb.log("counter %s" % counter)
    for o in api.get_objects():
        rb.log("obj %s pos=%s size=%s loc=%s" % (o["name"], np.round(o["pos"], 3), np.round(o["size"], 3), o["location"]))
    z_safe = safe_height(api, counter)
    rb.log("z_safe %.3f" % z_safe)

    # move up first
    rb.lift_to(z_safe, speed=0.2)

    # ---- 1. open drawer
    d = open_drawer(rb, counter, z_safe)

    # ---- 2. pick the cup
    held = False
    cup = None
    grasp_offset = 0.03
    for attempt in range(3):
        cup = read_cup(api)
        a = cup["yaw"]
        g = wrap(a)
        if abs(g) > math.pi / 2:
            g = wrap(a + math.pi)
        r, hgt = cup["radius"], cup["height"]
        p = cup["pos"]
        rb.log("cup pos=%s yaw=%.3f r=%.3f h=%.3f grasp yaw=%.3f" % (np.round(p, 3), a, r, hgt, g))
        gz = max(p[2] + 0.004, counter["top_z"] + 0.022)
        api.open_gripper()
        rb.lift_to(z_safe)
        rb.move([p[0], p[1], z_safe], yaw=g, speed=0.2, tag="above cup")
        rb.move([p[0], p[1], gz + 0.06], yaw=g, speed=0.15, tag="near cup")
        rb.move([p[0], p[1], gz], yaw=g, speed=0.05, tag="cup grasp")
        w = api.close_gripper()
        rb.log("cup grip width %.4f" % w)
        if w > 0.03:
            held = True
            grasp_offset = rb.ee()["pos"][2] - counter["top_z"]
            break
        api.open_gripper()
        rb.move([p[0], p[1], z_safe], speed=0.1, tag="retreat cup")
    rb.move(list(rb.ee()["pos"][:2]) + [z_safe], speed=0.1, tag="lift cup")
    if not held:
        rb.log("failed to grasp cup")

    # yaw relation: cup yaw after placing with gripper yaw 0
    a_after = wrap(cup["yaw"] - g)
    handle_dir_x = -1 if abs(a_after) < math.pi / 2 else 1
    rb.log("cup handle will point %s" % ("+x" if handle_dir_x > 0 else "-x"))

    # ---- 3. place in drawer
    d = read_drawer(api)
    place_fz = d["floor_z"] + grasp_offset + 0.006
    x, y, clr = choose_spot(rb, d, counter, cup["radius"], handle_dir_x, place_fz)
    rb.move([x, y, z_safe], yaw=0.0, speed=0.15, tag="above spot")
    wall_top = d["floor_z"] + 0.082
    rb.move([x, y, max(place_fz + 0.05, wall_top + 0.06)], speed=0.12, tag="down spot")
    rb.move([x, y, place_fz], speed=0.04, tag="place")
    api.open_gripper()
    api.wait(0.3)
    e = rb.ee()["pos"]
    rb.move([e[0], e[1], e[2] + 0.08], speed=0.06, tag="up from cup")
    z_up = max(z_safe - 0.05, counter["top_z"] + 0.09)
    rb.lift_to(z_up)
    try:
        c2 = api.get_cup()
        rb.log("cup after place %s" % np.round(c2["pos"], 3))
    except Exception:
        pass

    # ---- 4. close drawer
    d = close_drawer(rb, counter, z_up)
    rb.log("final drawer opening %.4f" % d["opening"])
    try:
        c2 = api.get_cup()
        rb.log("cup final %s" % np.round(c2["pos"], 3))
    except Exception:
        pass
