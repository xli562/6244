import math
import numpy as np


def run(api):
    def vec(p):
        return np.array(p, dtype=float, copy=True)

    def sense_pos(reader, n=5):
        readings = [reader() for _ in range(n)]
        result = dict(readings[-1])
        result["pos"] = np.mean([r["pos"] for r in readings], axis=0).tolist()
        return result

    def move(p, yaw=None, speed=0.20, precise=False):
        p = vec(p)
        result = api.move_to(p.tolist(), yaw=yaw, speed=speed)
        actual = vec(api.get_ee()["pos"])
        residual = p - actual
        error = float(np.linalg.norm(residual))
        if precise and 0.002 < error < 0.022:
            api.move_to((p + residual).tolist(), yaw=yaw, speed=speed)
            error = float(np.linalg.norm(p - vec(api.get_ee()["pos"])))
        return error

    counter = api.get_counter()
    objects = api.get_objects()
    safe_z = max(
        [0.415, counter["top_z"] + 0.12]
        + [
            o["pos"][2] + o["size"][2] / 2.0 + 0.045
            for o in objects if o["location"] == "counter"
        ]
    )

    def rise():
        p = vec(api.get_ee()["pos"])
        p[2] = safe_z
        return move(p)

    def above(p, yaw=0.0):
        rise()
        q = vec(p)
        q[2] = safe_z
        return move(q, yaw) < 0.065

    def grasp_handle():
        api.open_gripper()
        for dx, dy in ((0.0, 0.0), (-0.008, 0.0), (0.008, 0.0)):
            h = vec(sense_pos(api.get_handle)["pos"])
            h += vec([dx, dy, 0.0])
            above(h, 0.0)
            if move(h, 0.0, 0.12, True) > 0.02:
                rise()
                continue
            w = api.close_gripper()
            if 0.005 < w < 0.045:
                return True
            api.open_gripper()
            rise()
        return False

    drawer = api.get_drawer()
    if drawer["opening"] < 0.29 or drawer["opening"] > 0.34:
        if not grasp_handle():
            api.log("Handle grasp failed.")
            return
        opening = api.get_drawer()["opening"]
        p = vec(api.get_ee()["pos"])
        p[0] += opening - 0.31
        move(p, 0.0, 0.12, True)
        api.open_gripper()
        rise()

    drawer = api.get_drawer()
    cup = sense_pos(api.get_cup)
    radius = float(cup["radius"])
    height = float(cup["height"])
    center = vec(drawer["interior_center"])
    size = vec(drawer["interior_size"])
    margin = max(radius + 0.029, 0.062)
    xmin = center[0] - size[0] / 2 + margin
    xmax = min(center[0] + size[0] / 2 - margin,
               counter["front_x"] - margin - 0.015)
    ymin = center[1] - size[1] / 2 + margin
    ymax = center[1] + size[1] / 2 - margin
    if xmin >= xmax or ymin >= ymax:
        api.log("Drawer opening insufficient.")
        return

    obstacles = [o for o in api.get_objects() if o["location"] == "drawer"]
    candidates = []
    for x in np.linspace(xmin, xmax, 25):
        for y in np.linspace(ymin, ymax, 41):
            clearance = min(x - xmin, xmax - x, y - ymin, ymax - y)
            for obj in obstacles:
                op = vec(obj["pos"])
                half = vec(obj["size"]) / 2
                dx = max(abs(x - op[0]) - half[0], 0.0)
                dy = max(abs(y - op[1]) - half[1], 0.0)
                clearance = min(clearance, math.hypot(dx, dy) - margin - 0.012)
            if clearance >= 0:
                candidates.append((clearance, float(x), float(y)))
    if not candidates:
        api.log("No clear drawer placement.")
        return
    _, px, py = max(candidates)

    held = False
    for lateral in (0.0, -0.007, 0.007):
        cup = sense_pos(api.get_cup)
        cp = vec(cup["pos"])
        yaw = (float(cup["yaw"]) + math.pi / 2) % math.pi - math.pi / 2
        target = cp.copy()
        target[0] -= math.sin(yaw) * lateral
        target[1] += math.cos(yaw) * lateral
        target[2] = max(cp[2], counter["top_z"] + height / 2) + 0.004
        api.open_gripper()
        above(target, yaw)
        if move(target, yaw, 0.09, True) > 0.020:
            rise()
            continue
        width = api.close_gripper()
        if not 0.025 < width < 0.079:
            api.open_gripper()
            rise()
            continue
        lift = vec(api.get_ee()["pos"])
        lift[2] += 0.065
        move(lift, yaw, 0.12, True)
        after = sense_pos(api.get_cup)
        if after["pos"][2] > cp[2] + 0.035:
            held = True
            break
        api.open_gripper()
        rise()

    if not held:
        api.log("Cup grasp failed.")
        return

    offset = vec(sense_pos(api.get_cup)["pos"]) - vec(api.get_ee()["pos"])
    release = vec([px, py, drawer["floor_z"] + height / 2 + 0.009]) - offset
    above(release, yaw)
    if move(release, yaw, 0.09, True) > 0.023:
        api.log("Placement blocked.")
        return
    api.open_gripper()
    api.wait(0.4)
    rise()

    placed = sense_pos(api.get_cup)
    if abs(placed["pos"][0] - px) > 0.045 or abs(placed["pos"][1] - py) > 0.045:
        api.log("Placement verification failed.")
        return

    if not grasp_handle():
        api.log("Closing handle grasp failed.")
        return
    for _ in range(3):
        opening = float(api.get_drawer()["opening"])
        p = vec(api.get_ee()["pos"])
        p[0] += max(0.012, opening + 0.009)
        move(p, 0.0, 0.12)
        if api.get_drawer()["opening"] < 0.008:
            break
    api.open_gripper()
    rise()
