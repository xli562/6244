import math
import numpy as np


def run(api):
    def v(p):
        return np.asarray(p, dtype=float)

    def move(p, yaw=None, speed=0.22):
        result = api.move_to([float(x) for x in p], yaw=yaw, speed=speed)
        return bool(result["reached"])

    counter = api.get_counter()
    objects = api.get_objects()
    safe_z = max(
        [counter["top_z"] + 0.15, 0.43]
        + [
            o["pos"][2] + o["size"][2] / 2.0 + 0.12
            for o in objects
        ]
    )

    def rise(yaw=None):
        p = v(api.get_ee()["pos"])
        p[2] = safe_z
        return move(p, yaw)

    def above(p, yaw=None):
        if not rise():
            return False
        q = v(p)
        q[2] = safe_z
        return move(q, yaw)

    def grasp_handle():
        api.open_gripper()
        for dy in (0.0, -0.009, 0.009):
            h = v(api.get_handle()["pos"])
            h[1] += dy
            if not above(h, 0.0):
                continue
            if not move(h, 0.0, 0.10):
                rise()
                continue
            width = api.close_gripper()
            if 0.005 < width < 0.045:
                return True
            api.open_gripper()
            rise()
        return False

    # Expose enough of the drawer to lower the cup vertically.
    drawer = api.get_drawer()
    if drawer["opening"] < 0.39:
        if not grasp_handle():
            api.log("Unable to grasp drawer handle.")
            return
        start_opening = float(api.get_drawer()["opening"])
        p = v(api.get_ee()["pos"])
        p[0] -= max(0.0, 0.43 - start_opening)
        move(p, 0.0, 0.14)
        api.open_gripper()
        rise()

    drawer = api.get_drawer()
    cup = api.get_cup()
    radius = float(cup["radius"])
    height = float(cup["height"])

    # Reserve clearance for the cup handle, fingers, walls, and perception.
    center = v(drawer["interior_center"])
    size = v(drawer["interior_size"])
    margin = max(radius + 0.033, 0.068)
    xmin = center[0] - size[0] / 2.0 + margin
    xmax = min(
        center[0] + size[0] / 2.0 - margin,
        counter["front_x"] - margin - 0.018,
    )
    ymin = center[1] - size[1] / 2.0 + margin
    ymax = center[1] + size[1] / 2.0 - margin

    if xmin >= xmax or ymin >= ymax:
        api.log("Insufficient exposed drawer space.")
        return

    drawer_objects = [
        o for o in api.get_objects() if o["location"] == "drawer"
    ]
    candidates = []
    for x in np.linspace(xmin, xmax, 25):
        for y in np.linspace(ymin, ymax, 29):
            clearance = min(x - xmin, xmax - x, y - ymin, ymax - y)
            valid = True
            for obj in drawer_objects:
                op = v(obj["pos"])
                half = v(obj["size"]) / 2.0
                dx = max(abs(x - op[0]) - half[0], 0.0)
                dy = max(abs(y - op[1]) - half[1], 0.0)
                distance = math.hypot(dx, dy)
                if distance < margin + 0.012:
                    valid = False
                    break
                clearance = min(clearance, distance - margin - 0.012)
            if valid:
                candidates.append((clearance, float(x), float(y)))

    if not candidates:
        api.log("No clear placement region.")
        return
    _, place_x, place_y = max(candidates)

    # Align the fingers so the cup handle lies along the open approach axis.
    held = False
    for dx, dy in ((0.0, 0.0), (0.0, -0.008), (0.0, 0.008)):
        cup = api.get_cup()
        cp = v(cup["pos"])
        yaw = float(cup["yaw"])
        target = cp + v([dx, dy, 0.0])
        api.open_gripper()
        if not above(target, yaw):
            continue
        if not move(target, yaw, 0.08):
            rise()
            continue
        width = api.close_gripper()
        if not 0.025 < width < 0.079:
            api.open_gripper()
            rise()
            continue

        initial_z = float(cp[2])
        lift = v(api.get_ee()["pos"])
        lift[2] += 0.075
        if not move(lift, yaw, 0.10):
            api.open_gripper()
            rise()
            continue
        after = api.get_cup()
        if after["pos"][2] > initial_z + 0.04:
            held = True
            break
        api.open_gripper()
        rise()

    if not held:
        api.log("Cup grasp unsuccessful.")
        return

    # Preserve the observed cup-to-fingertip offset during transport.
    ee = v(api.get_ee()["pos"])
    carried = v(api.get_cup()["pos"])
    offset = carried - ee
    desired_cup = v([
        place_x,
        place_y,
        drawer["floor_z"] + height / 2.0 + 0.008,
    ])
    release_point = desired_cup - offset

    if not above(release_point, yaw):
        api.log("Cup transport obstructed.")
        return
    if not move(release_point, yaw, 0.085):
        actual = v(api.get_ee()["pos"])
        if np.linalg.norm(actual - release_point) > 0.020:
            api.log("Placement approach obstructed.")
            return

    api.open_gripper()
    api.wait(0.35)
    rise()

    placed = api.get_cup()
    if (
        abs(placed["pos"][0] - place_x) > 0.045
        or abs(placed["pos"][1] - place_y) > 0.045
        or placed["pos"][2] > drawer["floor_z"] + height + 0.025
    ):
        api.log("Cup placement could not be verified.")
        return

    # Use the handle to close the drawer after clearing the cup.
    if not grasp_handle():
        api.log("Unable to regrasp drawer handle.")
        return

    for _ in range(3):
        opening = float(api.get_drawer()["opening"])
        p = v(api.get_ee()["pos"])
        p[0] += max(0.012, opening + 0.012)
        move(p, 0.0, 0.12)
        if api.get_drawer()["opening"] <= 0.012:
            break

    api.open_gripper()
    rise()
