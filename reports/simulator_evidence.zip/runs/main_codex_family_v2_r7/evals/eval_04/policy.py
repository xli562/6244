import math
import numpy as np


def run(api):
    def v(x):
        return np.asarray(x, dtype=float)

    def move(p, yaw=None, speed=0.3):
        return api.move_to(list(map(float, p)), yaw=yaw, speed=speed)["reached"]

    def ee():
        return v(api.get_ee()["pos"])

    def high_z():
        z = api.get_counter()["top_z"] + 0.16
        for o in api.get_objects():
            if o["location"] == "counter":
                z = max(z, o["pos"][2] + o["size"][2] / 2 + 0.10)
        return z

    def rise():
        p = ee()
        p[2] = max(p[2], high_z())
        move(p, speed=0.35)

    def handle_point():
        h = np.mean([v(api.get_handle()["pos"]) for _ in range(3)], axis=0)
        d = api.get_drawer()
        c = api.get_counter()
        h[0] = 0.65 * h[0] + 0.35 * (c["front_x"] - d["opening"] - 0.041)
        h[1] = 0.65 * h[1] + 0.35 * d["interior_center"][1]
        return h

    api.open_gripper()
    opened = api.get_drawer()["opening"] >= 0.28
    if not opened:
        for dx, dy in ((0, 0), (0.012, 0), (-0.012, 0),
                       (0.022, -0.008), (0, 0.012)):
            rise()
            h = handle_point() + v([dx, dy, 0])
            above = h.copy()
            above[2] = high_z()
            move(above, 0.0, 0.4)
            move(h, 0.0, 0.14)
            width = api.close_gripper()
            if width > 0.004:
                before = api.get_drawer()["opening"]
                p = ee()
                p[0] -= max(0, 0.33 - before)
                move(p, 0.0, 0.16)
                opened = api.get_drawer()["opening"] >= 0.265
            api.open_gripper()
            rise()
            if opened:
                break
    if not opened:
        return

    def destination(cup):
        d = api.get_drawer()
        c = api.get_counter()
        center = v(d["interior_center"])
        size = v(d["interior_size"])
        margin = max(0.067, cup["radius"] + 0.035)
        lo = center[:2] - size[:2] / 2 + margin
        hi = center[:2] + size[:2] / 2 - margin
        hi[0] = min(hi[0], c["front_x"] - margin - 0.015)
        if np.any(lo > hi):
            return None
        objects = [o for o in api.get_objects() if o["location"] == "drawer"]
        best, score = None, -1e9
        for x in np.linspace(lo[0], hi[0], 17):
            for y in np.linspace(lo[1], hi[1], 29):
                p = v([x, y])
                clear = min(x - lo[0], hi[0] - x, y - lo[1], hi[1] - y)
                valid = True
                for o in objects:
                    delta = np.abs(p - v(o["pos"])[:2]) - v(o["size"])[:2] / 2
                    dist = np.linalg.norm(np.maximum(delta, 0))
                    if dist < margin:
                        valid = False
                        break
                    clear = min(clear, dist - margin)
                ranking = clear - 0.015 * abs(y - center[1])
                if valid and ranking > score:
                    score = ranking
                    best = v([x, y, d["floor_z"] + cup["height"] / 2 + 0.004])
        return best

    cup = api.get_cup()
    if destination(cup) is None:
        return
    held = False
    offset = v([0, 0, 0])
    for dx, dy in ((0, 0), (0.008, 0), (-0.008, 0),
                   (0, 0.008), (0, -0.008)):
        cup = api.get_cup()
        p = np.mean([v(cup["pos"]), v(api.get_cup()["pos"]),
                     v(api.get_cup()["pos"])], axis=0) + v([dx, dy, 0])
        yaw = cup["yaw"]
        api.open_gripper()
        rise()
        above = p.copy()
        above[2] = high_z()
        move(above, yaw, 0.35)
        move(p, yaw, 0.12)
        width = api.close_gripper()
        if width < 0.025:
            api.open_gripper()
            rise()
            continue
        lift = ee()
        lift[2] = high_z()
        move(lift, yaw, 0.2)
        observed = v(api.get_cup()["pos"])
        if observed[2] > p[2] + 0.055:
            held = True
            offset = np.mean([observed, v(api.get_cup()["pos"]),
                              v(api.get_cup()["pos"])], axis=0) - ee()
            break
        api.open_gripper()
    if not held:
        return

    target = destination(cup)
    if target is None:
        return
    target -= offset
    rise()
    above = target.copy()
    above[2] = high_z()
    if not move(above, speed=0.22):
        return
    move(target, speed=0.10)
    # Support the cup before withdrawing the fingers.
    support = ee()
    support[2] -= 0.012
    move(support, speed=0.045)
    api.open_gripper()
    api.wait(0.6)
    api.open_gripper()
    api.wait(0.4)
    p = ee()
    p[2] += 0.08
    move(p, speed=0.06)
    rise()
    api.log("Placed cup: " + str(api.get_cup()))

    # First bring the handle into the comfortably reachable region.
    d = api.get_drawer()
    h = handle_point()
    above = h.copy()
    above[2] = high_z()
    move(above, 0.0, 0.35)
    move(h, 0.0, 0.12)
    api.close_gripper()
    p = ee()
    p[0] = api.get_counter()["front_x"] - 0.085
    move(p, 0.0, 0.16)
    api.open_gripper()
    p = ee()
    p[0] -= 0.055
    move(p, 0.0, 0.18)
    rise()

    # Use the lower portion of the vertical bar for the final push,
    # keeping the gripper palm below the counter.
    for dx in (0.0, 0.012, -0.012):
        h = handle_point()
        h[0] += dx
        h[2] -= 0.047
        approach = h.copy()
        approach[0] -= 0.055
        above = approach.copy()
        above[2] = high_z()
        move(above, 0.0, 0.3)
        move(approach, 0.0, 0.15)
        move(h, 0.0, 0.1)
        api.close_gripper()
        p = ee()
        p[0] = api.get_counter()["front_x"] - 0.015
        move(p, 0.0, 0.10)
        api.open_gripper()
        p = ee()
        p[0] -= 0.07
        move(p, 0.0, 0.15)
        rise()
        opening = api.get_drawer()["opening"]
        api.log("Final drawer opening: " + str(opening))
        if opening < 0.008:
            break
