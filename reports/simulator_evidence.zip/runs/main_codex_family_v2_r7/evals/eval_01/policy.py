import math
import numpy as np


def run(api):
    def vec(p):
        return np.asarray(p, dtype=float)

    def move(p, yaw=None, speed=0.35):
        result = api.move_to([float(v) for v in p], yaw=yaw, speed=speed)
        if not result["reached"]:
            result = api.move_to([float(v) for v in p], yaw=yaw, speed=speed)
        return result["reached"]

    def clearance():
        counter = api.get_counter()
        z = float(counter["top_z"]) + 0.18
        for obj in api.get_objects():
            if obj["location"] == "counter":
                z = max(z, obj["pos"][2] + obj["size"][2] / 2 + 0.13)
        return z

    def rise(z):
        p = vec(api.get_ee()["pos"])
        p[2] = max(p[2], z)
        return move(p)

    def open_drawer():
        if api.get_drawer()["opening"] >= 0.44:
            return True

        for dy in (0.0, -0.009, 0.009):
            api.open_gripper()
            h = vec(api.get_handle()["pos"])
            h[1] += dy
            high = clearance()
            rise(high)
            approach = h.copy()
            approach[0] -= 0.09
            above = approach.copy()
            above[2] = high
            if not move(above, 0.0):
                continue
            if not move(approach, 0.0, 0.22):
                continue
            if not move(h, 0.0, 0.12):
                continue
            width = api.close_gripper()
            if width < 0.004:
                api.open_gripper()
                move(approach, 0.0)
                continue

            before = api.get_drawer()["opening"]
            p = vec(api.get_ee()["pos"])
            p[0] -= max(0.0, 0.48 - before)
            move(p, 0.0, 0.22)
            after = api.get_drawer()["opening"]
            api.open_gripper()
            retreat = vec(api.get_ee()["pos"])
            retreat[0] -= 0.055
            move(retreat, 0.0, 0.18)
            rise(high)
            if after >= 0.43:
                return True
        return False

    def placement(cup):
        drawer = api.get_drawer()
        counter = api.get_counter()
        center = vec(drawer["interior_center"])
        size = vec(drawer["interior_size"])
        radius = float(cup["radius"])
        margin = max(0.063, radius + 0.030)
        lo = center[:2] - size[:2] / 2 + margin
        hi = center[:2] + size[:2] / 2 - margin
        hi[0] = min(hi[0], counter["front_x"] - margin - 0.02)
        if np.any(hi < lo):
            return None

        obstacles = [
            o for o in api.get_objects() if o["location"] == "drawer"
        ]
        best = None
        best_score = -1e9
        for x in np.linspace(lo[0], hi[0], 23):
            for y in np.linspace(lo[1], hi[1], 27):
                p = np.array([x, y])
                wall_distance = min(
                    x - (center[0] - size[0] / 2),
                    center[0] + size[0] / 2 - x,
                    y - (center[1] - size[1] / 2),
                    center[1] + size[1] / 2 - y,
                    counter["front_x"] - x,
                )
                free = wall_distance - margin
                valid = True
                for obj in obstacles:
                    delta = np.abs(p - vec(obj["pos"])[:2])
                    delta -= vec(obj["size"])[:2] / 2
                    distance = float(np.linalg.norm(np.maximum(delta, 0)))
                    if distance < margin:
                        valid = False
                        break
                    free = min(free, distance - margin)
                if valid:
                    score = free - 0.04 * float(np.linalg.norm(p - center[:2]))
                    if score > best_score:
                        best_score = score
                        best = [float(x), float(y),
                                drawer["floor_z"] + cup["height"] / 2 + 0.008]
        return best

    def grasp_cup():
        for offset in ((0.0, 0.0), (0.0, -0.008), (0.0, 0.008)):
            cup = api.get_cup()
            p = vec(cup["pos"])
            yaw = float(cup["yaw"])
            p[:2] += vec(offset)
            high = clearance()
            api.open_gripper()
            rise(high)
            above = p.copy()
            above[2] = high
            if not move(above, yaw):
                continue
            if not move(p, yaw, 0.15):
                continue
            width = api.close_gripper()
            if width < 0.025:
                api.open_gripper()
                rise(high)
                continue

            original = vec(cup["pos"])
            lifted = vec(api.get_ee()["pos"])
            lifted[2] = high
            move(lifted, yaw, 0.22)
            observed = vec(api.get_cup()["pos"])
            ee = vec(api.get_ee()["pos"])
            if observed[2] > original[2] + 0.055:
                return cup, observed - ee
            api.open_gripper()
        return None

    def close_drawer():
        for _ in range(2):
            drawer = api.get_drawer()
            if drawer["opening"] < 0.012:
                return True
            high = clearance()
            rise(high)
            api.open_gripper()
            h = vec(api.get_handle()["pos"])
            approach = h.copy()
            approach[0] -= 0.075
            above = approach.copy()
            above[2] = high
            move(above, 0.0)
            move(approach, 0.0, 0.22)
            move(h, 0.0, 0.12)
            api.close_gripper()
            p = vec(api.get_ee()["pos"])
            p[0] += drawer["opening"] + 0.008
            move(p, 0.0, 0.20)
            api.open_gripper()
            p = vec(api.get_ee()["pos"])
            p[0] -= 0.07
            move(p, 0.0, 0.18)
            rise(high)
        return api.get_drawer()["opening"] < 0.015

    api.open_gripper()
    if not open_drawer():
        api.log("Could not open drawer reliably.")
        return

    cup = api.get_cup()
    if placement(cup) is None:
        api.log("No clear placement area in the exposed drawer.")
        return

    grasp = grasp_cup()
    if grasp is None:
        api.log("Cup grasp could not be verified.")
        return

    cup, grasp_offset = grasp
    target = placement(cup)
    if target is None:
        api.log("Placement area unavailable.")
        return

    target = vec(target) - grasp_offset
    high = clearance()
    rise(high)
    above = target.copy()
    above[2] = high
    if not move(above, speed=0.25):
        return
    if not move(target, speed=0.12):
        return
    api.open_gripper()
    api.wait(0.3)
    rise(high)
    close_drawer()
