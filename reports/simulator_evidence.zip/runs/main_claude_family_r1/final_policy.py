"""Robot program for: "Place the cup in the drawer." See TASK.md and API.md."""
import math

import numpy as np


FAST = 0.25
SLOW = 0.10
HANDLE_LEN = 0.03      # assumed reach of the cup handle beyond the body radius
FINGER_HALF = 0.05     # half width (along closing axis) of the open fingers
HAND_HALF = 0.11       # half width of the hand body along the closing axis
HAND_DEPTH = 0.035     # half depth of the hand body across the closing axis
HAND_ABOVE = 0.045     # height of the hand body bottom above the fingertips
HANDLE_GRIP_UP = 0.01  # grasp the drawer handle bar this much above its centre


def wrap(a):
    return (a + math.pi) % (2 * math.pi) - math.pi


# Approximate reach of the arm (horizontal fingertip distance from the base)
# with the gripper pointing down, as a function of fingertip height.
def r_reach(z):
    return 0.778 - 0.44 * (z - 0.32) - 0.012


def z_reach(r):
    return 0.32 + (0.778 - 0.012 - r) / 0.44


def box_dist(px, py, b):
    """2D distance from a point to an axis-aligned box (xmin, xmax, ymin, ymax)."""
    dx = max(b[0] - px, px - b[1], 0.0)
    dy = max(b[2] - py, py - b[3], 0.0)
    return math.hypot(dx, dy)


def rect_dist(a, b):
    dx = max(b[0] - a[1], a[0] - b[1], 0.0)
    dy = max(b[2] - a[3], a[2] - b[3], 0.0)
    if dx > 0 or dy > 0:
        return math.hypot(dx, dy)
    return -min(a[1] - b[0], b[1] - a[0], a[3] - b[2], b[3] - a[2])


def run(api):
    anomalies = []

    def log(*a):
        api.log(" ".join(str(x) for x in a))

    def r3(v):
        return [round(float(x), 3) for x in v]

    def move(p, yaw=None, speed=FAST, tag="", expect_block=False):
        p = [float(v) for v in p]
        r = api.move_to(p, yaw=yaw, speed=speed)
        if not r.get("reached", True):
            log("move", tag, "not reached", r3(p), "err", round(r.get("error", -1), 4))
            if not expect_block:
                anomalies.append("move " + tag)
        return r

    def ee():
        return api.get_ee()

    counter = api.get_counter()
    top_z = counter["top_z"]
    front_x = counter["front_x"]
    cup = api.get_cup()
    drawer = api.get_drawer()
    handle = api.get_handle()
    objects = api.get_objects()
    log("counter", counter)
    log("cup", r3(cup["pos"]), "yaw", round(cup["yaw"], 3), "r", cup["radius"], "h", cup["height"])
    log("drawer open", round(drawer["opening"], 3), "ic", r3(drawer["interior_center"]),
        "is", r3(drawer["interior_size"]), "floor", round(drawer["floor_z"], 3))
    log("handle", r3(handle["pos"]))
    for o in objects:
        log("obj", o["name"], o["location"], r3(o["pos"]), r3(o["size"]))
    log("ee", ee())
    if drawer["opening"] > 0.25:
        anomalies.append("wide initial opening")

    r_cup = cup["radius"]
    h_cup = cup["height"]

    # Safe travel height above everything on the counter.
    counter_objs = [o for o in objects if o["location"] == "counter"]
    tops = [o["pos"][2] + o["size"][2] / 2 for o in counter_objs]
    max_top = max(tops + [top_z + h_cup])
    z_safe = max(top_z + 0.17, max_top + 0.12)
    log("z_safe", round(z_safe, 3))

    # ---------- grasp-yaw choice for the cup ----------
    cy = wrap(cup["yaw"])
    if abs(cy) <= 2.0:
        handle_neg_x = True       # at gripper yaw 0 the handle will point to -x
    else:
        handle_neg_x = False

    def base_yaw(cup_yaw):
        cyw = wrap(cup_yaw)
        return cyw if handle_neg_x else wrap(cyw + math.pi)

    def grasp_clearance(cx, cyy, yaw, gz):
        n = (-math.sin(yaw), math.cos(yaw))
        t = (math.cos(yaw), math.sin(yaw))
        best = 1.0
        for o in counter_objs:
            p, s = o["pos"], o["size"]
            b = (p[0] - s[0] / 2, p[0] + s[0] / 2, p[1] - s[1] / 2, p[1] + s[1] / 2)
            otop = p[2] + s[2] / 2
            pts = []
            for side in (-1, 1):
                for sn in (0.03, 0.04, 0.05):
                    for u in (-0.012, 0.0, 0.012):
                        pts.append((cx + n[0] * sn * side + t[0] * u, cyy + n[1] * sn * side + t[1] * u))
            if otop > gz + HAND_ABOVE - 0.01:
                for sn in np.linspace(-HAND_HALF, HAND_HALF, 12):
                    for u in (-HAND_DEPTH, 0.0, HAND_DEPTH):
                        pts.append((cx + n[0] * sn + t[0] * u, cyy + n[1] * sn + t[1] * u))
            for (px, py) in pts:
                best = min(best, box_dist(px, py, b))
        return best

    def choose_grasp_yaw(cupr, gz):
        g = base_yaw(cupr["yaw"])
        p = cupr["pos"]
        c0 = grasp_clearance(p[0], p[1], g, gz)
        if c0 >= 0.03:
            return g, 0.0, c0
        best = (c0 - 0.0, 0.0)
        for d in np.arange(-0.6, 0.6001, 0.1):
            c = grasp_clearance(p[0], p[1], wrap(g + d), gz)
            sc = min(c, 0.04) - 0.02 * abs(d)
            if sc > best[0]:
                best = (sc, float(d))
        d = best[1]
        return wrap(g + d), d, grasp_clearance(p[0], p[1], wrap(g + d), gz)

    # ---------- placement spot selection ----------
    def select_spot(dr, objs, d_fixed=None, d_max=0.30):
        c = np.array(dr["interior_center"], dtype=float)
        sx, sy, _ = dr["interior_size"]
        d0 = dr["opening"]
        floor = dr["floor_z"]
        xm = r_cup + (HANDLE_LEN if handle_neg_x else 0.0)    # extent toward -x
        xp = r_cup + (0.0 if handle_neg_x else HANDLE_LEN)    # extent toward +x
        yh = max(r_cup, FINGER_HALF)
        lim = min(front_x - 0.07, front_x - 0.03 - xp)
        drawer_objs = []
        for o in objs:
            if o["location"] != "drawer":
                continue
            p = np.array(o["pos"], dtype=float) - c
            s = o["size"]
            tall = (o["pos"][2] + s[2] / 2) > floor + 0.10
            drawer_objs.append(((p[0] - s[0] / 2, p[0] + s[0] / 2, p[1] - s[1] / 2, p[1] + s[1] / 2), tall))
        best = None
        for ux in np.arange(-sx / 2 + xm + 0.012, sx / 2 - xp - 0.012 + 1e-9, 0.01):
            for uy in np.arange(-sy / 2 + yh + 0.008, sy / 2 - yh - 0.008 + 1e-9, 0.01):
                cup_rect = (ux - xm, ux + xp, uy - r_cup, uy + r_cup)
                fing_rect = (ux - 0.012, ux + 0.012, uy - yh, uy + yh)
                hand_rect = (ux - HAND_DEPTH, ux + HAND_DEPTH, uy - HAND_HALF, uy + HAND_HALF)
                clear = 0.2
                for (b, tall) in drawer_objs:
                    clear = min(clear, rect_dist(cup_rect, b), rect_dist(fing_rect, b))
                    if tall:
                        clear = min(clear, rect_dist(hand_rect, b) + 0.01)
                if clear < 0.012:
                    continue
                world_x0 = c[0] + ux                     # at current opening d0
                d_req = d0 + (world_x0 - lim)
                if d_fixed is not None:
                    if d_req > d_fixed + 1e-6:
                        continue
                    # prefer spots far from the drawer front panel (arm stays extended)
                    cost = -(world_x0 - (d_fixed - d0)) - 0.6 * min(clear, 0.05) + 0.05 * abs(uy)
                    d_use = d_fixed
                else:
                    if d_req > d_max:
                        continue
                    d_use = max(d_req, 0.0)
                    cost = d_use - 0.6 * min(clear, 0.05) + 0.05 * abs(uy)
                if best is None or cost < best[0]:
                    best = (cost, ux, uy, d_use, clear)
        return best

    # ---------- drawer handle helpers ----------
    def grasp_handle(hpos, tag):
        hx, hy, hz = hpos
        gz = hz + HANDLE_GRIP_UP
        api.open_gripper()
        e = ee()["pos"]
        move([e[0], e[1], max(e[2], z_safe)], tag=tag + " up")
        move([hx - 0.05, hy, max(z_safe, gz + 0.1)], yaw=0.0, tag=tag + " above")
        for k in range(3):
            move([hx - 0.05, hy, gz + 0.06], yaw=0.0, tag=tag + " pre")
            move([hx, hy, gz], yaw=0.0, speed=SLOW, tag=tag + " in")
            w = api.close_gripper()
            log(tag, "handle grip width", round(w, 4), "ee", r3(ee()["pos"]))
            if 0.006 < w < 0.035:
                return gz
            anomalies.append(tag + " grip width %.3f" % w)
            api.open_gripper()
            e = ee()["pos"]
            move([e[0] - 0.05, e[1], e[2] + 0.02], speed=SLOW, tag=tag + " miss back")
            hx, hy, hz = api.get_handle()["pos"]
            gz = hz + HANDLE_GRIP_UP - 0.01 * (k + 1)
        return gz

    def release_handle(tag):
        api.open_gripper()
        e = ee()["pos"]
        move([e[0] - 0.04, e[1], e[2] + 0.02], speed=SLOW, tag=tag + " back")
        move([e[0] - 0.05, e[1], z_safe], speed=FAST, tag=tag + " up")

    # ---------- open the drawer ----------
    plan = select_spot(drawer, objects)
    if plan is None:
        plan = select_spot(drawer, objects, d_max=0.42)
    log("plan", plan)
    d_target = 0.20 if plan is None else max(plan[3] + 0.03, 0.16)
    d_target = min(d_target, 0.40)
    log("target opening", round(d_target, 3))

    for attempt in range(3):
        drawer = api.get_drawer()
        d_now = drawer["opening"]
        if d_now >= d_target - 0.015:
            break
        if attempt > 0:
            anomalies.append("open retry")
        hpos = api.get_handle()["pos"]
        gz = grasp_handle(hpos, "open%d" % attempt)
        pull = d_target - d_now
        move([hpos[0] - pull, hpos[1], gz], speed=SLOW, tag="pull")
        drawer = api.get_drawer()
        log("after pull opening", round(drawer["opening"], 3))
        release_handle("open%d" % attempt)
    drawer = api.get_drawer()
    objects = api.get_objects()
    log("drawer now", round(drawer["opening"], 3), r3(drawer["interior_center"]))

    spot = select_spot(drawer, objects, d_fixed=drawer["opening"])
    if spot is None:
        anomalies.append("no spot")
        log("no clear spot found; using fallback")
        c = drawer["interior_center"]
        sx = drawer["interior_size"][0]
        ux = (c[0] - sx / 2 + 0.07 + min(front_x - 0.07, c[0] + sx / 2)) / 2 - c[0]
        spot = (0, ux, 0.0, drawer["opening"], 0)
    c = drawer["interior_center"]
    tx = c[0] + spot[1]
    ty = c[1] + spot[2]
    log("place target", round(tx, 3), round(ty, 3), "clear", round(spot[4], 3))

    # ---------- pick the cup ----------
    def pick_cup():
        for attempt in range(3):
            if attempt > 0:
                anomalies.append("cup retry")
            cupr = api.get_cup()
            p = cupr["pos"]
            bottom = p[2] - h_cup / 2
            if abs(bottom - top_z) < 0.025:
                bottom = top_z
            gz = bottom + max(0.55 * h_cup, 0.028)
            gy, dlt, clr = choose_grasp_yaw(cupr, gz)
            log("cup grasp yaw", round(gy, 3), "offset", round(dlt, 2), "clearance", round(clr, 3))
            if abs(dlt) > 1e-6:
                anomalies.append("yaw offset")
            api.open_gripper()
            e = ee()["pos"]
            move([e[0], e[1], z_safe], tag="cup up")
            rc = math.hypot(p[0], p[1])
            ray = (p[0] / rc, p[1] / rc)
            # vertical approach from above, kept low enough to stay reachable
            z_h = max(gz + 0.045, min(z_safe, z_reach(rc)))
            far = rc > r_reach(gz + 0.03)
            if far:
                log("far cup, r", round(rc, 3))
            rp = min(rc, r_reach(z_safe))
            move([ray[0] * rp, ray[1] * rp, z_safe], yaw=gy, tag="cup transit")
            move([p[0], p[1], z_h], yaw=gy, tag="cup above", expect_block=far)
            move([p[0], p[1], gz + 0.045], yaw=gy, speed=SLOW, tag="cup pre", expect_block=far)
            move([p[0], p[1], gz], yaw=gy, speed=SLOW, tag="cup down", expect_block=far)
            w = api.close_gripper()
            log("cup grip width", round(w, 4), "ee", r3(ee()["pos"]))
            if w > 0.03:
                return gz - bottom, gy
            log("cup grasp missed, retry")
            api.open_gripper()
            e = ee()["pos"]
            move([e[0], e[1], gz + 0.08], tag="cup retry up")
        return None, 0.0

    off, gy = pick_cup()
    if off is None:
        off = 0.035
    # lift, moving inward as needed to stay inside the reachable workspace
    e = ee()["pos"]
    re = math.hypot(e[0], e[1])
    ue = (e[0] / re, e[1] / re)
    z1 = e[2] + 0.04
    r1 = min(re, r_reach(z1))
    move([ue[0] * r1, ue[1] * r1, z1], speed=SLOW, tag="lift")
    r2 = min(r1, r_reach(z_safe))
    move([ue[0] * r2, ue[1] * r2, z_safe], tag="lift2")
    cupr = api.get_cup()
    e = ee()
    log("cup after lift", r3(cupr["pos"]), "ee", r3(e["pos"]), "w", round(e["gripper_width"], 4))
    # offset of the cup from the fingertips, in the gripper frame
    ox = cupr["pos"][0] - e["pos"][0]
    oy = cupr["pos"][1] - e["pos"][1]
    cg, sg = math.cos(-e["yaw"]), math.sin(-e["yaw"])
    gox, goy = cg * ox - sg * oy, sg * ox + cg * oy
    if math.hypot(gox, goy) < 0.008 or math.hypot(gox, goy) > 0.04:
        gox, goy = 0.0, 0.0
    else:
        log("compensating cup offset in gripper", round(gox, 3), round(goy, 3))
    ptx, pty = tx - gox, ty - goy     # fingertip target at placement yaw 0

    # ---------- carry and place ----------
    floor = drawer["floor_z"]
    place_hi = max(top_z + 0.06, floor + off + 0.12)
    move([ptx, pty, z_safe], yaw=0.0, tag="carry")
    move([ptx, pty, place_hi], yaw=0.0, tag="over drawer")
    move([ptx, pty, floor + off + 0.006], yaw=0.0, speed=SLOW, tag="lower")
    api.open_gripper()
    api.wait(0.3)
    e = ee()["pos"]
    move([e[0], e[1], place_hi + 0.03], speed=SLOW, tag="retreat")
    cupr = api.get_cup()
    log("cup placed at", r3(cupr["pos"]), "yaw", round(cupr["yaw"], 3))

    # ---------- close the drawer ----------
    for attempt in range(3):
        drawer = api.get_drawer()
        d_now = drawer["opening"]
        log("before close opening", round(d_now, 3))
        if d_now < 0.012:
            break
        if attempt > 0:
            anomalies.append("close retry")
        hpos = api.get_handle()["pos"]
        gz = grasp_handle(hpos, "close%d" % attempt)
        move([hpos[0] + d_now + 0.01, hpos[1], gz], speed=SLOW, tag="push", expect_block=True)
        log("after push opening", round(api.get_drawer()["opening"], 3))
        release_handle("close%d" % attempt)

    drawer = api.get_drawer()
    cupr = api.get_cup()
    log("final opening", round(drawer["opening"], 3), "cup", r3(cupr["pos"]))
    if anomalies:
        log("anomalies", anomalies)
