"""Robot program for: "Place the cup in the drawer." See TASK.md and API.md."""
import math

import numpy as np

# ---------------------------------------------------------------- geometry
HAND_HALF_LEN = 0.11     # hand housing half length along the finger-closing axis
HAND_HALF_WID = 0.037    # hand housing half width perpendicular to it
HAND_ABOVE_TIP = 0.055   # height of hand housing bottom above the fingertips
FING_HALF_LEN = 0.052    # open fingers footprint, along closing axis
FING_HALF_WID = 0.013
FING_OFF = 0.045         # open finger centre offset from fingertip centre
CUP_GRASP_OFF = 0.018    # fingertip height above cup bottom when grasping
CUP_HANDLE_EXTRA = 0.026  # how far the cup handle sticks out of the body

# Reach model (fitted from observed move_to errors): fingertip p reachable
# with the gripper pointing down iff |p - (0, 0, REACH_ZC)| <= REACH_R.
REACH_R = 0.822
REACH_ZC = 0.07
R_GRASP_OK = 0.772       # cup horizontal radius up to which a top grasp is attempted directly
R_DRAG_TARGET = 0.705    # where a dragged cup should end up (radius)
HOOK_IN = 0.015          # inside finger offset from cup centre toward the robot
HOOK_REACH_MARGIN = 0.012  # observed: arm falls ~1.2 cm short of the model at rim height
HOOK_TOL = 0.020         # max distance of the inside finger from the cup centre


def _wrap_half(a):
    """wrap angle to [-pi/2, pi/2)"""
    return (a + math.pi / 2) % math.pi - math.pi / 2


def zcap(r, margin=0.01):
    """highest reachable fingertip z at horizontal radius r"""
    v = (REACH_R - margin) ** 2 - r * r
    if v <= 0:
        return REACH_ZC
    return REACH_ZC + math.sqrt(v)


def rcap(z, margin=0.005):
    """largest reachable horizontal radius at fingertip height z"""
    v = (REACH_R - margin) ** 2 - (z - REACH_ZC) ** 2
    return math.sqrt(max(v, 0.0))


def _pt_box_dist(px, py, box):
    cx, cy, hx, hy = box
    dx = max(abs(px - cx) - hx, 0.0)
    dy = max(abs(py - cy) - hy, 0.0)
    return math.hypot(dx, dy)


# Gripper yaw convention: the finger closing axis is at world angle
# theta = yaw + pi/2 (YAW_CONV = -1, standard counter-clockwise yaw, as in the
# API description: at yaw 0 the fingers close along y).
YAW_CONV = [-1]


def yaw_for_theta(theta):
    """gripper yaw that puts the finger closing axis at world angle theta"""
    if YAW_CONV[0] > 0:
        return _wrap_half(math.pi / 2 - theta)
    return _wrap_half(theta - math.pi / 2)


def _axis_dist(a, b):
    return abs(_wrap_half(a - b))


def _rect_box_clear(center, theta, half_len, half_wid, box, ns=13, nt=5):
    """min distance between a rectangle (long axis at world angle theta = finger
    closing axis) and an axis aligned box (sampled)."""
    c = np.array([math.cos(theta), math.sin(theta)])
    p = np.array([-math.sin(theta), math.cos(theta)])
    best = 1e9
    cen = np.asarray(center[:2], dtype=float)
    for s in np.linspace(-1, 1, ns):
        for t in np.linspace(-1, 1, nt):
            q = cen + s * half_len * c + t * half_wid * p
            best = min(best, _pt_box_dist(q[0], q[1], box))
    return best


def _obj_box(o, dx=0.0):
    return (o["pos"][0] + dx, o["pos"][1], o["size"][0] / 2, o["size"][1] / 2)


def _obj_top(o):
    return o["pos"][2] + o["size"][2] / 2


class Robot:
    def __init__(self, api, z_safe=0.45):
        self.api = api
        self.z_safe = z_safe

    def log(self, *a):
        try:
            self.api.log(" ".join(str(x) for x in a))
        except Exception:
            pass

    def move(self, pos, yaw=None, speed=0.15, tag=""):
        pos = [float(v) for v in pos]
        r = self.api.move_to(pos, yaw=yaw, speed=speed)
        if not r.get("reached", True):
            self.log("move not reached", tag, np.round(pos, 3).tolist(), "err", round(r.get("error", -1), 4))
        return r

    def ee(self):
        return self.api.get_ee()

    def travel(self, xy, z_end, yaw=None, speed=0.22, tag=""):
        """Go up, across at safe height (limited by reach), and to (xy, z_end)
        (z_end is reached by the last, vertical or slanted, segment)."""
        zs = self.z_safe
        ee = self.ee()["pos"]
        r0 = math.hypot(ee[0], ee[1])
        z1 = min(zs, zcap(r0))
        if ee[2] < z1 - 0.005:
            self.move([ee[0], ee[1], z1], speed=0.15, tag=tag + " up")
        rt = math.hypot(xy[0], xy[1])
        if zcap(rt) >= zs:
            self.move([xy[0], xy[1], zs], yaw=yaw, speed=speed, tag=tag + " across")
        else:
            a = np.array(ee[:2], dtype=float)
            b = np.array(xy[:2], dtype=float)
            q = a
            for t in np.linspace(0, 1, 41):
                pt = a + t * (b - a)
                if zcap(np.linalg.norm(pt)) >= zs:
                    q = pt
            self.move([q[0], q[1], zs], yaw=yaw, speed=speed, tag=tag + " across")
            zt = max(z_end, min(zs, zcap(rt)))
            self.move([xy[0], xy[1], zt], yaw=yaw, speed=0.12, tag=tag + " slant")
        self.move([xy[0], xy[1], z_end], yaw=yaw, speed=0.12, tag=tag + " down")


# ---------------------------------------------------------------- drawer
def _grasp_handle(R):
    api = R.api
    for attempt in range(3):
        h = api.get_handle()["pos"]
        hx, hy, hz = h[0] - 0.003, h[1], h[2]
        api.open_gripper()
        R.travel([hx, hy], hz + 0.06, yaw=0.0, tag="handle")
        R.move([hx, hy, hz], yaw=0.0, speed=0.06, tag="handle")
        w = api.close_gripper()
        R.log("handle grasp width", round(w, 4), "attempt", attempt)
        if w > 0.006:
            return [hx, hy, hz]
        api.open_gripper()
        R.move([hx, hy, hz + 0.10], speed=0.12, tag="retreat handle")
    return None


def _release_handle(R):
    api = R.api
    api.open_gripper()
    api.wait(0.2)
    ee = R.ee()["pos"]
    R.move([ee[0] - 0.01, ee[1], ee[2] + 0.02], speed=0.06, tag="handle off")
    R.move([ee[0] - 0.01, ee[1], R.z_safe], speed=0.15, tag="handle up")


def set_drawer(R, target, tol=0.015):
    """Bring the drawer opening to `target` by pulling / pushing the handle."""
    api = R.api
    for it in range(3):
        d = api.get_drawer()["opening"]
        R.log("drawer opening", round(d, 4), "target", round(target, 4))
        if abs(d - target) < tol:
            return d
        h = _grasp_handle(R)
        if h is None:
            R.log("could not grasp handle")
            return api.get_drawer()["opening"]
        delta = target - d   # +: open more (pull to -x)
        goal = [h[0] - delta, h[1], h[2]]
        if target <= 0.0:
            goal[0] += 0.004  # push slightly into the stop
        R.move(goal, speed=0.08, tag="drawer slide")
        api.wait(0.2)
        _release_handle(R)
    return api.get_drawer()["opening"]


# ---------------------------------------------------------------- planning
def plan_place(drawer, counter, objs, d_new, cup_r):
    """Find a cup placement spot (x, y) for drawer opening d_new.
    Returns (score, x, y, clearance) or None."""
    d_cur = drawer["opening"]
    shift = -(d_new - d_cur)
    cx, cy, _ = drawer["interior_center"]
    sx, sy, _ = drawer["interior_size"]
    floor = drawer["floor_z"]
    xmin = cx + shift - sx / 2
    front = counter["front_x"]
    lo = xmin + cup_r + CUP_HANDLE_EXTRA + 0.01
    lo = max(lo, xmin + HAND_HALF_WID + 0.012)
    lo = max(lo, 0.30)
    hi = front - 0.072
    if hi < lo:
        return None
    ylim = sy / 2 - HAND_HALF_LEN - 0.012
    ylim = max(ylim, 0.0)
    ylim = min(ylim, sy / 2 - cup_r - 0.02)
    dobjs = [o for o in objs if o.get("location") == "drawer"]
    best = None
    xs = np.arange(lo, hi + 1e-9, 0.005) if hi > lo else np.array([lo])
    ys = np.arange(cy - ylim, cy + ylim + 1e-9, 0.01) if ylim > 0 else np.array([cy])
    xmid = 0.5 * (lo + hi)
    tip_z = floor + CUP_GRASP_OFF
    for x in xs:
        for y in ys:
            clear = 0.08
            for o in dobjs:
                box = _obj_box(o, shift)
                c = _pt_box_dist(x, y, box) - (cup_r + CUP_HANDLE_EXTRA)
                if _obj_top(o) > tip_z + HAND_ABOVE_TIP - 0.01:
                    c = min(c, _rect_box_clear([x, y], math.pi / 2, HAND_HALF_LEN, HAND_HALF_WID, box))
                if _obj_top(o) > tip_z - 0.005:
                    c = min(c, _rect_box_clear([x, y], math.pi / 2, FING_HALF_LEN, FING_HALF_WID, box))
                clear = min(clear, c)
            score = min(clear, 0.04) - 0.05 * abs(x - xmid) - 0.03 * abs(y - cy)
            if best is None or score > best[0]:
                best = (score, float(x), float(y), clear)
    return best


def grasp_clear(xy, theta, objs, tip_z):
    clear = 0.1
    for o in objs:
        if o.get("location") != "counter":
            continue
        box = _obj_box(o)
        top = _obj_top(o)
        if top > tip_z + HAND_ABOVE_TIP - 0.01:
            clear = min(clear, _rect_box_clear(xy, theta, HAND_HALF_LEN, HAND_HALF_WID, box))
        if top > tip_z - 0.005:
            clear = min(clear, _rect_box_clear(xy, theta, FING_HALF_LEN, FING_HALF_WID, box))
    return clear


def choose_grasp_yaw(cup_xy, cup_yaw, objs, tip_z, avoid=()):
    """Choose the finger closing axis (world angle theta). The cup handle
    points along (-cos yaw, -sin yaw): keep the fingers well away from it.
    For cups near the reach limit prefer a tangential closing axis, so that
    falling a little short radially does not put a finger on the rim.
    Returns (score, gripper_yaw, clearance, handle_angle_dist)."""
    rc = math.hypot(cup_xy[0], cup_xy[1])
    radial = math.atan2(cup_xy[1], cup_xy[0])
    far = min(max((rc - 0.68) / 0.06, 0.0), 1.0)
    best = None
    for th in np.arange(0.0, math.pi, math.pi / 36):
        hd = _axis_dist(th, cup_yaw)
        if hd < 0.60:
            continue
        rd = _axis_dist(th, radial)
        clear = grasp_clear(cup_xy, th, objs, tip_z)
        score = (min(clear, 0.03) + 0.03 * min(hd, 0.80) / 0.80 + 0.006 * hd / (math.pi / 2)
                 + 0.04 * far * rd / (math.pi / 2))
        for av in avoid:
            if _axis_dist(th, av) < 0.30:
                score -= 0.05
        if best is None or score > best[0]:
            best = (score, yaw_for_theta(th), clear, hd, th)
    if best is None:
        th = cup_yaw + math.pi / 2
        best = (0.0, yaw_for_theta(th), 0.0, math.pi / 2, th)
    return best


def plan_drag(cxy, cup_yaw, objs, counter, bottom, rim, cup_r):
    """Plan to hook one open finger inside the cup and drag the cup to a
    reachable spot. Returns dict or None."""
    c = np.array(cxy, dtype=float)
    rc = np.linalg.norm(c)
    chat = c / max(rc, 1e-6)
    phi0 = math.atan2(-c[1], -c[0])
    hz = bottom + 0.016
    z_pre = rim + 0.007
    # inside finger sits toward the robot from the cup centre
    w = -HOOK_IN * chat
    hdirs = [np.array([-math.cos(cup_yaw), -math.sin(cup_yaw)])]
    cobjs = [o for o in objs if o.get("location") == "counter"]
    best = None
    for k in range(-8, 9):
        th = phi0 + k * math.radians(10)
        u = np.array([math.cos(th), math.sin(th)])
        F0 = c + w + FING_OFF * u
        if np.linalg.norm(F0) > rcap(z_pre, HOOK_REACH_MARGIN) + 0.003:
            continue
        g = yaw_for_theta(th)
        tall = [o for o in cobjs if _obj_top(o) > hz + HAND_ABOVE_TIP - 0.01]

        def clear_at(s):
            pc = c + max(s - 0.012, 0.0) * u
            pf = F0 + s * u
            pfw = pf + FING_OFF * u
            cl = 0.1
            for o in cobjs:
                box = _obj_box(o)
                cl = min(cl, _pt_box_dist(pc[0], pc[1], box) - (cup_r + 0.004))
                for hdv in hdirs:
                    ph = pc + (cup_r + 0.02) * hdv
                    cl = min(cl, _pt_box_dist(ph[0], ph[1], box) - 0.012)
                cl = min(cl, _pt_box_dist(pfw[0], pfw[1], box) - 0.012)
            for o in tall:
                cl = min(cl, _rect_box_clear(pf, th, HAND_HALF_LEN, HAND_HALF_WID, _obj_box(o), 9, 3))
            return cl

        if clear_at(0.0) < 0.004:
            continue
        good = None
        for s in np.arange(0.02, 0.32, 0.01):
            T = c + (s - 0.012) * u
            if T[0] - cup_r < counter["front_x"] + 0.02 or abs(T[1]) > 0.38:
                break
            if clear_at(s) < 0.004:
                break
            if good is None or np.linalg.norm(T) < good[2] - 1e-4:
                good = (float(s), T, float(np.linalg.norm(T)))
            if np.linalg.norm(T) <= R_DRAG_TARGET:
                break
        if good is None:
            continue
        s, T, rT = good
        if rc - rT < 0.015:
            continue
        reached = rT <= R_DRAG_TARGET + 1e-6
        score = (rc - rT) * 2.0 + (0.3 if reached else 0.0) - 0.3 * s - 0.03 * abs(k * math.radians(10))
        if reached:
            gy = choose_grasp_yaw(T, cup_yaw, objs, bottom + CUP_GRASP_OFF)
            score += min(gy[2], 0.03)
        if best is None or score > best["score"]:
            best = {"score": score, "u": u, "s": s, "F0": F0, "T": T, "g": g,
                    "hz": hz, "z_pre": z_pre, "rT": rT}
    return best


def drag_cup(R, plan, rim, cxy):
    api = R.api
    F0, u, s, g = plan["F0"], plan["u"], plan["s"], plan["g"]
    c = np.array(cxy[:2], dtype=float)
    api.open_gripper()
    R.travel([F0[0], F0[1]], plan["z_pre"], yaw=g, tag="hook")
    R.move([F0[0], F0[1], plan["z_pre"]], yaw=g, speed=0.06, tag="hook pre")
    ee = R.ee()["pos"]
    B = np.array(ee[:2]) - FING_OFF * u   # where the inside finger actually is
    R.log("hook pre ee", np.round(ee, 4).tolist(), "inside finger off-centre", round(float(np.linalg.norm(B - c)), 4))
    if np.linalg.norm(B - c) > HOOK_TOL:
        R.log("hook finger would miss the cup opening")
        R.move([ee[0], ee[1], plan["z_pre"] + 0.03], speed=0.06, tag="hook abort0")
        return "blocked"
    R.move([F0[0], F0[1], plan["hz"]], speed=0.04, tag="hook in")
    ee_d = R.ee()
    ee = ee_d["pos"]
    R.log("hook ee", np.round(ee, 4).tolist(), "rim", round(rim, 4), "width", ee_d.get("gripper_width"))
    if (ee[2] > rim - 0.015 or math.hypot(ee[0] - F0[0], ee[1] - F0[1]) > 0.015
            or ee_d.get("gripper_width", 0.08) < 0.075):
        R.log("hook failed to enter cup")
        R.move([ee[0], ee[1], plan["z_pre"] + 0.02], speed=0.06, tag="hook abort")
        return "blocked"
    F1 = F0 + s * u
    R.move([F1[0], F1[1], ee[2]], speed=0.05, tag="drag")
    ee = R.ee()["pos"]
    R.move([ee[0], ee[1], rim + 0.03], speed=0.05, tag="hook out")
    return "entered"


def read_cup(api, n=5):
    cs = [api.get_cup() for _ in range(n)]
    pos = np.mean([c["pos"] for c in cs], axis=0)
    yaws = [c["yaw"] for c in cs]
    yaw = math.atan2(np.mean(np.sin(yaws)), np.mean(np.cos(yaws)))
    out = dict(cs[0])
    out["pos"] = [float(v) for v in pos]
    out["yaw"] = yaw
    return out


# ---------------------------------------------------------------- main
def run(api):
    YAW_CONV[0] = -1
    cup = read_cup(api)
    drawer = api.get_drawer()
    counter = api.get_counter()
    objs = api.get_objects()
    top_z = counter["top_z"]
    cup_r = cup.get("radius", 0.031)
    cup_h = cup.get("height", 0.058)
    max_top = top_z
    for o in objs:
        if o.get("location") == "counter":
            max_top = max(max_top, _obj_top(o))
    z_safe = max(top_z + 0.13, max_top + 0.07)
    z_safe = min(z_safe, 0.75)
    R = Robot(api, z_safe)
    R.log("cup", cup)
    R.log("drawer", drawer)
    R.log("counter", counter, "handle", api.get_handle())
    R.log("objs", [(o["name"], np.round(o["pos"], 3).tolist(), np.round(o["size"], 3).tolist(), o["location"]) for o in objs])
    R.log("z_safe", round(z_safe, 3))

    # ---------------- 1. drawer opening
    d_cur = drawer["opening"]
    plan = None
    target = d_cur
    cur_plan = plan_place(drawer, counter, objs, d_cur, cup_r)
    if cur_plan is not None and cur_plan[3] >= 0.012 and d_cur <= 0.36:
        plan = cur_plan
    else:
        for d in np.arange(0.20, 0.381, 0.02):
            p = plan_place(drawer, counter, objs, float(d), cup_r)
            if p is not None and p[3] >= 0.015:
                plan, target = p, float(d)
                break
        if plan is None:
            cands = []
            for d in np.arange(0.20, 0.381, 0.02):
                p = plan_place(drawer, counter, objs, float(d), cup_r)
                if p is not None:
                    cands.append((p[3], float(d), p))
            if cands:
                cands.sort(key=lambda t: -t[0])
                target, plan = cands[0][1], cands[0][2]
            else:
                target = 0.22
    R.log("drawer target", round(target, 3), "plan", plan)

    if abs(target - d_cur) > 0.012:
        set_drawer(R, target)

    drawer = api.get_drawer()
    objs = api.get_objects()
    p = plan_place(drawer, counter, objs, drawer["opening"], cup_r)
    if p is not None:
        plan = p
    R.log("drawer now", drawer, "place plan", plan)
    if plan is None:
        cx, cy, _ = drawer["interior_center"]
        sx = drawer["interior_size"][0]
        px = 0.5 * ((cx - sx / 2) + counter["front_x"])
        plan = (0, px, cy, 0)
    place_x, place_y = plan[1], plan[2]

    # ---------------- 2. bring the cup within reach if needed
    cup = read_cup(api)
    cpos = cup["pos"]
    bottom = 0.5 * ((cpos[2] - cup_h / 2) + top_z)
    rc = math.hypot(cpos[0], cpos[1])
    R.log("cup radius", round(rc, 4))
    for drag_try in range(3):
        if rc <= R_GRASP_OK:
            break
        dp = plan_drag(cpos[:2], cup["yaw"], objs, counter, bottom, bottom + cup_h, cup_r)
        R.log("drag plan conv", YAW_CONV[0], None if dp is None else {k: (np.round(v, 3).tolist() if isinstance(v, np.ndarray) else round(v, 3)) for k, v in dp.items()})
        if dp is None:
            break
        before = np.array(cpos[:2])
        res = drag_cup(R, dp, bottom + cup_h, cpos)
        cup = read_cup(api)
        cpos = cup["pos"]
        rc = math.hypot(cpos[0], cpos[1])
        moved = float(np.linalg.norm(np.array(cpos[:2]) - before))
        R.log("cup after drag", np.round(cpos, 4).tolist(), "radius", round(rc, 4), "moved", round(moved, 4), res)
        if cpos[2] < bottom + cup_h / 2 - 0.012:
            R.log("cup seems tipped")
            break
        if res == "blocked" or moved < 0.01:
            break

    # ---------------- 3. grasp the cup
    grasped = False
    grasp_off = CUP_GRASP_OFF
    if rc > 0.80:
        R.log("cup out of reach, not attempting grasp")
    else:
        tried = []
        for attempt in range(3):
            cup = read_cup(api)
            cpos = cup["pos"]
            if cpos[2] > top_z + cup_h / 2 + 0.02:
                # cup is stuck on the open gripper: put it back down and retreat
                R.log("cup hanging on gripper", np.round(cpos, 3).tolist())
                ee = R.ee()["pos"]
                R.move([ee[0], ee[1], ee[2] - (cpos[2] - (top_z + cup_h / 2)) + 0.004], speed=0.04, tag="set down")
                api.open_gripper()
                ee = R.ee()["pos"]
                R.move([ee[0], ee[1], ee[2] + 0.08], speed=0.06, tag="away")
                cup = read_cup(api)
                cpos = cup["pos"]
            bottom = 0.5 * ((cpos[2] - cup_h / 2) + top_z)
            tip_z = max(bottom + CUP_GRASP_OFF, top_z + 0.010)
            gy = choose_grasp_yaw(cpos[:2], cup["yaw"], objs, tip_z, tried)
            g = gy[1]
            tried.append(gy[4])
            R.log("cup grasp attempt", attempt, "yaw", round(g, 3), "theta", round(gy[4], 3), "clear", round(gy[2], 3),
                  "hd", round(gy[3], 3), "tip_z", round(tip_z, 3))
            api.open_gripper()
            R.travel(cpos[:2], tip_z + 0.05, yaw=g, tag="cup")
            R.move([cpos[0], cpos[1], tip_z], yaw=g, speed=0.06, tag="cup")
            ee = R.ee()["pos"]
            if ee[2] > tip_z + 0.012:
                R.log("descent blocked at", round(ee[2], 4))
                R.move([ee[0], ee[1], tip_z + 0.07], speed=0.05, tag="unblock")
                continue
            w = api.close_gripper()
            api.wait(0.2)
            R.log("cup grasp width", round(w, 4))
            if w < 0.035 or w > 0.079:
                api.open_gripper()
                R.move([cpos[0], cpos[1], tip_z + 0.07], speed=0.1, tag="retreat cup")
                continue
            grasp_off = tip_z - bottom
            R.move([cpos[0], cpos[1], tip_z + 0.05], speed=0.08, tag="lift cup")
            c2 = read_cup(api, 3)["pos"]
            ee_rise = R.ee()["pos"][2] - ee[2]
            cup_rise = c2[2] - cpos[2]
            R.log("cup after lift", np.round(c2, 3).tolist(), "cup rise", round(cup_rise, 4), "ee rise", round(ee_rise, 4))
            # near the reach limit the arm may not rise the full 5 cm: compare
            # the cup's rise with the gripper's actual rise
            if cup_rise < max(0.012, 0.6 * ee_rise):
                R.log("cup not lifted")
                api.open_gripper()
                R.move([cpos[0], cpos[1], tip_z + 0.07], speed=0.1, tag="retreat cup2")
                continue
            grasped = True
            break
    if not grasped:
        R.log("failed to grasp cup")

    # ---------------- 4. carry and place
    if grasped:
        drawer = api.get_drawer()
        floor = drawer["floor_z"]
        place_tip = floor + grasp_off + 0.004
        R.travel([place_x, place_y], place_tip + 0.06, yaw=0.0, tag="place")
        R.move([place_x, place_y, place_tip], yaw=0.0, speed=0.04, tag="place")
        api.wait(0.2)
        api.open_gripper()
        api.wait(0.3)
        R.move([place_x, place_y, place_tip + 0.06], speed=0.06, tag="leave cup")
        R.move([place_x, place_y, z_safe], speed=0.15, tag="up from place")
        R.log("cup placed", api.get_cup())

    # ---------------- 5. close the drawer
    set_drawer(R, 0.0, tol=0.008)
    api.open_gripper()
    ee = R.ee()["pos"]
    R.move([ee[0] - 0.05, ee[1], max(ee[2], z_safe)], speed=0.15, tag="final retreat")
    R.log("done; opening", api.get_drawer()["opening"], "cup", api.get_cup())
