import math
import numpy as np


def run(api):
    def vec(p):
        return np.asarray(p, dtype=float)

    def move(p, yaw=None, speed=0.27):
        p = vec(p)
        result = api.move_to(p.tolist(), yaw=yaw, speed=speed)
        if not result["reached"]:
            result = api.move_to(p.tolist(), yaw=yaw, speed=0.12)
        return bool(result["reached"])

    def ee():
        return vec(api.get_ee()["pos"])

    def clearance():
        counter = api.get_counter()
        z = float(counter["top_z"]) + 0.17
        for obj in api.get_objects():
            p, s = vec(obj["pos"]), vec(obj["size"])
            z = max(z, p[2] + s[2] / 2.0 + 0.13)
        return z

    def rise(z):
        p = ee()
        p[2] = max(p[2], z)
        return move(p)

    def approach_handle():
        h = vec(api.get_handle()["pos"])
        safe_z = clearance()
        if not rise(safe_z):
            return False
        approach = h.copy()
        approach[0] -= 0.075
        approach[2] = safe_z
        if not move(approach, yaw=0.0):
            return False
        api.open_gripper()
        approach[2] = h[2]
        if not move(approach, yaw=0.0, speed=0.18):
            return False
        if not move(h, yaw=0.0, speed=0.09):
            return False
        width = api.close_gripper()
        api.wait(0.12)
        return width > 0.004

    def leave_handle():
        api.open_gripper()
        p = ee()
        p[0] -= 0.055
        move(p, speed=0.12)
        rise(clearance())

    def open_drawer(target):
        for _ in range(3):
            d = api.get_drawer()
            if float(d["opening"]) >= target - 0.018:
                return True
            if not approach_handle():
                leave_handle()
                continue
            start = float(api.get_drawer()["opening"])
            p = ee()
            p[0] -= max(0.0, target - start)
            move(p, yaw=0.0, speed=0.16)
            api.wait(0.15)
            achieved = float(api.get_drawer()["opening"])
            leave_handle()
            if achieved >= target - 0.018:
                return True
        return False

    def placement(cup):
        d = api.get_drawer()
        counter = api.get_counter()
        center, size = vec(d["interior_center"]), vec(d["interior_size"])
        # Include the cup handle, measurement error, and finger clearance.
        radius = float(cup["radius"]) + 0.030
        margin = radius + 0.015
        low = center[:2] - size[:2] / 2.0 + margin
        high = center[:2] + size[:2] / 2.0 - margin
        high[0] = min(high[0], float(counter["front_x"]) - margin - 0.018)
        if np.any(high <= low):
            return None

        obstacles = api.get_objects()
        best, best_score = None, -float("inf")
        for x in np.linspace(low[0], high[0], 19):
            for y in np.linspace(low[1], high[1], 23):
                point = np.array([x, y])
                wall_gap = min(*(point - low), *(high - point))
                gap = float("inf")
                valid = True
                for obj in obstacles:
                    p, s = vec(obj["pos"]), vec(obj["size"])
                    # The entire vertical insertion path must remain clear.
                    delta = np.maximum(np.abs(point - p[:2]) - s[:2] / 2.0, 0.0)
                    distance = float(np.linalg.norm(delta))
                    required = radius + 0.018
                    if distance < required:
                        valid = False
                        break
                    gap = min(gap, distance - required)
                if not valid:
                    continue
                score = min(wall_gap, gap, 0.12)
                score -= 0.025 * float(np.linalg.norm(point - center[:2]))
                if score > best_score:
                    best_score = score
                    best = np.array([
                        x, y,
                        float(d["floor_z"]) + float(cup["height"]) / 2.0 + 0.007
                    ])
        return best

    api.open_gripper()
    if not open_drawer(0.40):
        api.log("Could not establish sufficient drawer opening.")
        return

    cup = api.get_cup()
    target = placement(cup)
    if target is None:
        if not open_drawer(0.47):
            return
        cup = api.get_cup()
        target = placement(cup)
    if target is None:
        api.log("No clear placement region found.")
        return

    held = False
    offset = np.zeros(3)
    grasp_yaw = 0.0
    for attempt in range(3):
        cup = api.get_cup()
        cp = vec(cup["pos"])
        grasp_yaw = float(cup["yaw"])
        safe_z = clearance()
        if not rise(safe_z):
            return
        above = cp.copy()
        above[2] = safe_z
        if not move(above, yaw=grasp_yaw):
            return
        api.open_gripper()
        # Close across the body, perpendicular to the handle direction.
        grasp = cp.copy()
        grasp[2] += 0.002
        if not move(grasp, yaw=grasp_yaw, speed=0.10):
            rise(safe_z)
            continue
        width = api.close_gripper()
        api.wait(0.15)
        if width < 0.012:
            api.open_gripper()
            rise(safe_z)
            continue

        before = vec(api.get_cup()["pos"])
        lift = ee()
        lift[2] += 0.075
        if not move(lift, yaw=grasp_yaw, speed=0.12):
            api.log("Cup lift obstructed.")
            return
        after = vec(api.get_cup()["pos"])
        if after[2] - before[2] > 0.045:
            held = True
            offset = after - ee()
            break
        api.open_gripper()
        rise(safe_z)

    if not held:
        api.log("Cup grasp could not be verified.")
        return

    # Refresh the geometry after opening and grasping.
    cup = api.get_cup()
    target = placement(cup)
    if target is None:
        api.log("Placement region no longer clear.")
        return

    safe_z = clearance() + max(0.0, -offset[2])
    if not rise(safe_z):
        return
    place_ee = target - offset
    above = place_ee.copy()
    above[2] = safe_z
    if not move(above, yaw=grasp_yaw):
        return
    preplace = place_ee.copy()
    preplace[2] += 0.055
    if not move(preplace, yaw=grasp_yaw, speed=0.14):
        return
    if not move(place_ee, yaw=grasp_yaw, speed=0.06):
        return
    api.open_gripper()
    api.wait(0.35)
    if not rise(safe_z):
        return

    # Check that the released cup is inside before moving the drawer.
    final_cup = api.get_cup()
    d = api.get_drawer()
    p = vec(final_cup["pos"])
    c, s = vec(d["interior_center"]), vec(d["interior_size"])
    if (abs(p[0] - c[0]) > s[0] / 2.0 - float(final_cup["radius"])
            or abs(p[1] - c[1]) > s[1] / 2.0 - float(final_cup["radius"])
            or abs(p[2] - (float(d["floor_z"]) +
                          float(final_cup["height"]) / 2.0)) > 0.030):
        api.log("Cup placement could not be verified; drawer left open.")
        return

    for _ in range(3):
        opening = float(api.get_drawer()["opening"])
        if opening <= 0.006:
            break
        if not approach_handle():
            leave_handle()
            continue
        opening = float(api.get_drawer()["opening"])
        p = ee()
        p[0] += opening + 0.006
        move(p, yaw=0.0, speed=0.13)
        api.wait(0.15)
        leave_handle()

    api.open_gripper()
    api.log("Final drawer opening: %.4f" % float(api.get_drawer()["opening"]))
