import math
import numpy as np


def run(api):
    def v(p):
        return np.array(p, dtype=float)

    def ee():
        return v(api.get_ee()["pos"])

    def move(p, yaw=None, speed=0.22):
        return api.move_to([float(x) for x in p], yaw=yaw, speed=speed)

    counter = api.get_counter()
    objects = api.get_objects()
    safe_z = max(
        0.51,
        float(counter["top_z"]) + 0.19,
        max([o["pos"][2] + o["size"][2] / 2 + 0.15
             for o in objects if o["location"] == "counter"] or [0.0])
    )

    def rise():
        p = ee()
        p[2] = safe_z
        move(p, speed=0.22)

    def grasp_handle():
        rise()
        api.open_gripper()
        h = v(api.get_handle()["pos"])
        # Approach from above: a low approach in front of an open
        # drawer can lie inside the arm's unreachable inner workspace.
        h[2] = max(h[2], 0.225)
        p = h.copy()
        p[2] = safe_z
        move(p, 0.0)
        for dx, dz in ((0.0, 0.0), (-0.012, 0.0),
                       (0.012, 0.0), (0.0, -0.018)):
            target = h + v([dx, 0.0, dz])
            move(target, 0.0, 0.10)
            width = api.close_gripper()
            if 0.006 < width < 0.04:
                return True
            api.open_gripper()
            p = ee()
            p[2] = h[2] + 0.075
            move(p, 0.0, 0.15)
        rise()
        return False

    def release_handle():
        api.open_gripper()
        rise()

    drawer = api.get_drawer()
    if float(drawer["opening"]) < 0.285:
        if not grasp_handle():
            api.log("Handle grasp failed.")
            return
        opening = float(api.get_drawer()["opening"])
        p = ee()
        p[0] -= max(0.0, 0.31 - opening)
        move(p, 0.0, 0.12)
        release_handle()

    drawer = api.get_drawer()
    if float(drawer["opening"]) < 0.23:
        api.log("Insufficient drawer opening.")
        return

    cup = api.get_cup()
    objects = api.get_objects()
    radius = float(cup["radius"])
    height = float(cup["height"])
    center = v(drawer["interior_center"])
    size = v(drawer["interior_size"])
    margin = radius + 0.04
    low = center[:2] - size[:2] / 2 + margin
    high = center[:2] + size[:2] / 2 - margin
    high[0] = min(high[0], float(counter["front_x"]) - margin - 0.025)
    if np.any(high <= low):
        api.log("No accessible placement region.")
        return

    candidates = []
    for x in np.linspace(low[0], high[0], 17):
        for y in np.linspace(low[1], high[1], 23):
            point = v([x, y])
            clearance = min(*(point - low), *(high - point)) + margin
            valid = True
            for obj in objects:
                if obj["location"] != "drawer":
                    continue
                delta = np.abs(point - v(obj["pos"])[:2]) - v(obj["size"])[:2] / 2
                distance = float(np.linalg.norm(np.maximum(delta, 0)))
                if distance < margin + 0.015:
                    valid = False
                    break
                clearance = min(clearance, distance)
            if valid:
                candidates.append((clearance, x, y))
    if not candidates:
        api.log("Drawer has no clear placement space.")
        return
    _, px, py = max(candidates)

    cp = v(cup["pos"])
    yaw = float(cup["yaw"])
    axis = v([-math.sin(yaw), math.cos(yaw), 0])
    api.open_gripper()
    rise()
    held = False
    for shift in (0.0, -0.009, 0.009):
        target = cp + axis * shift
        above = target.copy()
        above[2] = safe_z
        move(above, yaw)
        if not move(target, yaw, 0.09)["reached"]:
            rise()
            continue
        width = api.close_gripper()
        if 0.025 < width < 0.079:
            p = ee()
            p[2] += 0.085
            move(p, yaw, 0.12)
            if api.get_cup()["pos"][2] > cp[2] + 0.045:
                held = True
                break
            p = ee()
            p[2] = target[2]
            move(p, yaw, 0.09)
        api.open_gripper()
        rise()
    if not held:
        api.log("Cup grasp failed.")
        return

    rise()
    offset = v(api.get_cup()["pos"]) - ee()
    dest = v([px - offset[0], py - offset[1], safe_z])
    if not move(dest, yaw, 0.20)["reached"]:
        api.log("Placement approach unreachable.")
        return
    drawer = api.get_drawer()
    dest[2] = float(drawer["floor_z"]) + height / 2 + 0.012 - offset[2]
    result = move(dest, yaw, 0.085)
    if not result["reached"] and ee()[2] - dest[2] > 0.025:
        api.log("Placement descent obstructed.")
        return
    api.open_gripper()
    api.wait(0.35)
    rise()

    if api.get_cup()["pos"][2] > float(drawer["floor_z"]) + height + 0.035:
        api.log("Cup placement not verified.")
        return

    if not grasp_handle():
        api.log("Closing handle grasp failed.")
        return
    for _ in range(2):
        opening = float(api.get_drawer()["opening"])
        if opening < 0.008:
            break
        p = ee()
        p[0] += opening + 0.008
        move(p, 0.0, 0.12)
    release_handle()
    api.log("Placement and drawer closing completed.")
