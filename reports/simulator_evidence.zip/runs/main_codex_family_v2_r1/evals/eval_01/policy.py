import math
import numpy as np


def run(api):
    def vec(p):
        return np.array(p, dtype=float)

    def move(p, yaw=None, speed=0.24):
        return api.move_to([float(v) for v in p], yaw=yaw, speed=speed)

    def ee():
        return vec(api.get_ee()["pos"])

    counter = api.get_counter()
    objects = api.get_objects()
    cup = api.get_cup()
    safe_z = max(
        float(counter["top_z"]) + 0.17,
        float(cup["pos"][2]) + float(cup["height"]) / 2 + 0.12,
        max(
            [float(o["pos"][2]) + float(o["size"][2]) / 2 + 0.12
             for o in objects if o["location"] == "counter"] or [0.0]
        ),
    )

    def rise():
        p = ee()
        p[2] = max(p[2], safe_z)
        return move(p)

    def handle_grasp():
        h = vec(api.get_handle()["pos"])
        rise()
        approach = h.copy()
        approach[0] -= 0.085
        approach[2] = safe_z
        move(approach, 0.0)
        api.open_gripper()
        approach[2] = h[2]
        if not move(approach, 0.0)["reached"]:
            return False
        for dy in (0.0, -0.012, 0.012):
            target = h.copy()
            target[1] += dy
            move(target, 0.0, 0.10)
            width = api.close_gripper()
            if 0.005 < width < 0.045:
                return True
            api.open_gripper()
            move(approach, 0.0, 0.12)
        return False

    def leave_handle():
        api.open_gripper()
        p = ee()
        p[0] -= 0.065
        move(p, 0.0, 0.15)
        rise()

    # Expose enough of the drawer for a vertical insertion.
    drawer = api.get_drawer()
    if float(drawer["opening"]) < 0.415:
        if not handle_grasp():
            api.log("Could not securely grasp the drawer handle.")
            return
        before = float(api.get_drawer()["opening"])
        p = ee()
        p[0] -= max(0.0, 0.445 - before)
        move(p, 0.0, 0.16)
        after = float(api.get_drawer()["opening"])
        leave_handle()
        if after < 0.34:
            api.log("Drawer did not open sufficiently.")
            return

    drawer = api.get_drawer()
    objects = api.get_objects()
    cup = api.get_cup()
    radius = float(cup["radius"])
    height = float(cup["height"])
    center = vec(drawer["interior_center"])
    size = vec(drawer["interior_size"])
    front_x = float(counter["front_x"])

    # Include the handle and perception uncertainty in the placement footprint.
    margin = radius + 0.045
    low = center[:2] - size[:2] / 2 + margin
    high = center[:2] + size[:2] / 2 - margin
    high[0] = min(high[0], front_x - margin - 0.025)
    if np.any(high <= low):
        api.log("No accessible drawer interior.")
        return

    obstacles = [o for o in objects if o["location"] == "drawer"]
    candidates = []
    for x in np.linspace(low[0], high[0], 15):
        for y in np.linspace(low[1], high[1], 21):
            p = np.array([x, y])
            clearance = min(*(p - low), *(high - p)) + margin
            valid = True
            for obj in obstacles:
                oc = vec(obj["pos"])[:2]
                half = vec(obj["size"])[:2] / 2
                delta = np.abs(p - oc) - half
                distance = float(np.linalg.norm(np.maximum(delta, 0.0)))
                if distance < margin + 0.015:
                    valid = False
                    break
                clearance = min(clearance, distance)
            if valid:
                candidates.append((clearance, x, y))
    if not candidates:
        api.log("No clear placement area in drawer.")
        return
    _, place_x, place_y = max(candidates)

    # A body grasp closes perpendicular to the handle's direction.
    grasp_yaw = float(cup["yaw"])
    cp = vec(cup["pos"])
    api.open_gripper()
    rise()
    top = cp.copy()
    top[2] = safe_z
    move(top, grasp_yaw)
    held = False
    closing_axis = np.array([-math.sin(grasp_yaw), math.cos(grasp_yaw), 0.0])
    for shift in (0.0, -0.009, 0.009):
        target = cp + closing_axis * shift
        top = target.copy()
        top[2] = safe_z
        move(top, grasp_yaw)
        if not move(target, grasp_yaw, 0.10)["reached"]:
            rise()
            continue
        width = api.close_gripper()
        if 0.025 < width < 0.079:
            lift = ee()
            lift[2] += 0.085
            move(lift, grasp_yaw, 0.12)
            observed = vec(api.get_cup()["pos"])
            if observed[2] > cp[2] + 0.045:
                held = True
                break
            # Release only after returning to the original support.
            down = ee()
            down[2] = target[2]
            move(down, grasp_yaw, 0.10)
        api.open_gripper()
        rise()
    if not held:
        api.log("Could not verify a secure cup grasp.")
        return

    rise()
    held_cup = api.get_cup()
    offset = vec(held_cup["pos"]) - ee()
    dest = np.array([place_x, place_y, safe_z])
    dest[:2] -= offset[:2]
    if not move(dest, grasp_yaw, 0.20)["reached"]:
        api.log("Could not reach the placement approach.")
        return

    # Set the cup down just above the estimated floor, then release.
    drawer = api.get_drawer()
    target_center_z = float(drawer["floor_z"]) + height / 2 + 0.012
    dest[2] = target_center_z - offset[2]
    result = move(dest, grasp_yaw, 0.09)
    if not result["reached"] and ee()[2] - dest[2] > 0.025:
        api.log("Placement descent was obstructed.")
        return
    api.open_gripper()
    api.wait(0.35)
    rise()

    placed = vec(api.get_cup()["pos"])
    if placed[2] > float(drawer["floor_z"]) + height + 0.035:
        api.log("Cup placement could not be verified.")
        return

    # Close from the front while keeping the fingers on the handle.
    if not handle_grasp():
        api.log("Could not grasp handle to close drawer.")
        return
    opening = float(api.get_drawer()["opening"])
    p = ee()
    p[0] += opening + 0.012
    move(p, 0.0, 0.14)
    remaining = float(api.get_drawer()["opening"])
    if remaining > 0.018:
        p = ee()
        p[0] += remaining + 0.008
        move(p, 0.0, 0.10)
    leave_handle()
    api.log("Cup released in drawer; closing motion completed.")
