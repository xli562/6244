import math
import numpy as np


def run(api):
    def vec(p):
        return np.array(p, dtype=float)

    def ee():
        return vec(api.get_ee()["pos"])

    def move(p, yaw=None, speed=0.22):
        return api.move_to([float(x) for x in p], yaw=yaw, speed=speed)

    def canonical_yaw(a):
        return (float(a) + math.pi / 2) % math.pi - math.pi / 2

    counter = api.get_counter()
    objects = api.get_objects()
    safe_z = max(
        0.51,
        float(counter["top_z"]) + 0.18,
        max([o["pos"][2] + o["size"][2] / 2 + 0.12
             for o in objects if o["location"] == "counter"] or [0.0])
    )

    def rise():
        p = ee()
        p[2] = safe_z
        move(p)

    def grasp_handle():
        rise()
        api.open_gripper()
        h = vec(api.get_handle()["pos"])
        h[2] = max(h[2], 0.225)
        p = h.copy()
        p[2] = safe_z
        move(p, 0.0)
        for dx, dz in ((0.0, 0.0), (-0.012, 0.0),
                       (0.012, 0.0), (0.0, -0.018)):
            move(h + vec([dx, 0.0, dz]), 0.0, 0.10)
            width = api.close_gripper()
            if 0.006 < width < 0.04:
                return True
            api.open_gripper()
            p = ee()
            p[2] = h[2] + 0.075
            move(p, 0.0, 0.15)
        rise()
        return False

    def release_handle():
        api.open_gripper()
        rise()

    drawer = api.get_drawer()
    if float(drawer["opening"]) < 0.285:
        if not grasp_handle():
            api.log("Unable to grasp drawer handle.")
            return
        opening = float(api.get_drawer()["opening"])
        p = ee()
        p[0] -= max(0.0, 0.31 - opening)
        move(p, 0.0, 0.12)
        release_handle()

    drawer = api.get_drawer()
    if float(drawer["opening"]) < 0.23:
        api.log("Drawer opening is insufficient.")
        return

    cup = api.get_cup()
    objects = api.get_objects()
    radius = float(cup["radius"])
    height = float(cup["height"])
    center = vec(drawer["interior_center"])
    size = vec(drawer["interior_size"])
    margin = radius + 0.04
    low = center[:2] - size[:2] / 2 + margin
    high = center[:2] + size[:2] / 2 - margin
    high[0] = min(high[0], float(counter["front_x"]) - margin - 0.025)
    if np.any(high <= low):
        return

    candidates = []
    for x in np.linspace(low[0], high[0], 17):
        for y in np.linspace(low[1], high[1], 23):
            point = vec([x, y])
            clearance = min(*(point - low), *(high - point)) + margin
            valid = True
            for obj in objects:
                if obj["location"] != "drawer":
                    continue
                delta = (np.abs(point - vec(obj["pos"])[:2])
                         - vec(obj["size"])[:2] / 2)
                distance = float(np.linalg.norm(np.maximum(delta, 0)))
                if distance < margin + 0.015:
                    valid = False
                    break
                clearance = min(clearance, distance)
            if valid:
                candidates.append((clearance, x, y))
    if not candidates:
        api.log("No clear accessible placement area.")
        return
    _, px, py = max(candidates)

    cp = vec(cup["pos"])
    yaw = canonical_yaw(cup["yaw"])
    api.open_gripper()
    rise()
    held = False
    previous_cp = cp.copy()

    for attempt in range(5):
        if attempt:
            cup = api.get_cup()
            cp = vec(cup["pos"])
            yaw = canonical_yaw(cup["yaw"])
        far = float(np.linalg.norm(cp[:2])) > 0.77
        radial = cp[:2] / max(float(np.linalg.norm(cp[:2])), 0.001)
        target = cp.copy()
        axis = vec([-math.sin(yaw), math.cos(yaw), 0.0])

        if far:
            target[:2] -= radial * 0.012
            target[2] -= 0.006
        elif attempt and np.linalg.norm(cp[:2] - previous_cp[:2]) < 0.015:
            target += axis * (-0.008 if attempt % 2 else 0.008)
        previous_cp = cp.copy()

        api.open_gripper()
        above = target.copy()
        above[2] = cp[2] + (0.055 if far else 0.095)
        high = above.copy()
        high[2] = safe_z
        move(high, yaw)
        move(above, yaw, 0.12)
        if np.linalg.norm(ee()[:2] - target[:2]) > (0.045 if far else 0.025):
            rise()
            continue

        move(target, yaw, 0.065)
        if np.linalg.norm(ee()[:2] - cp[:2]) > 0.032:
            rise()
            continue

        width = api.close_gripper()
        if 0.008 < width < 0.087:
            before = vec(api.get_cup()["pos"])
            p = ee()
            p[2] += 0.07
            if far:
                p[:2] -= radial * 0.065
            move(p, yaw, 0.09)
            after = vec(api.get_cup()["pos"])
            if after[2] > before[2] + 0.035 or after[2] > cp[2] + 0.045:
                held = True
                break
            p = ee()
            p[2] = target[2]
            move(p, yaw, 0.08)
        api.open_gripper()
        rise()

    if not held:
        api.log("Unable to verify cup grasp.")
        return

    rise()
    offset = vec(api.get_cup()["pos"]) - ee()
    dest = vec([px - offset[0], py - offset[1], safe_z])
    if not move(dest, yaw, 0.20)["reached"]:
        return

    drawer = api.get_drawer()
    floor_z = float(drawer["floor_z"])
    dest[2] = floor_z + height / 2 + 0.012 - offset[2]
    result = move(dest, yaw, 0.085)
    if not result["reached"] and ee()[2] - dest[2] > 0.025:
        api.log("Placement descent obstructed.")
        return

    api.open_gripper()
    api.wait(0.35)
    release_pos = ee()
    baseline = vec(api.get_cup()["pos"])
    probe = release_pos.copy()
    probe[2] += 0.045
    move(probe, yaw, 0.07)
    observed = vec(api.get_cup()["pos"])

    # A handle can remain caught on a finger after opening. Check release
    # near the floor so recovery does not lift the cup out of the drawer.
    for attempt in range(3):
        if observed[2] - baseline[2] < 0.025:
            break
        move(release_pos, yaw, 0.06)
        support = ee()
        support[2] -= 0.012
        move(support, yaw, 0.05)
        api.open_gripper()
        api.wait(0.25)
        yaw += 0.35 if attempt != 1 else -0.70
        move(ee(), yaw, 0.06)
        api.open_gripper()
        api.wait(0.25)
        release_pos = ee()
        baseline = vec(api.get_cup()["pos"])
        probe = release_pos.copy()
        probe[2] += 0.045
        move(probe, yaw, 0.06)
        observed = vec(api.get_cup()["pos"])

    if observed[2] - baseline[2] >= 0.025:
        move(release_pos, yaw, 0.06)
        api.open_gripper()
        api.log("Cup remains caught; left supported in drawer.")
        return

    rise()
    placed = vec(api.get_cup()["pos"])
    if placed[2] > floor_z + height + 0.035:
        api.log("Cup placement could not be verified.")
        return

    if not grasp_handle():
        return
    for _ in range(3):
        opening = float(api.get_drawer()["opening"])
        p = ee()
        p[0] += max(0.015, opening + 0.015)
        move(p, 0.0, 0.12)
        if float(api.get_drawer()["opening"]) < 0.004:
            break
    release_handle()
    api.log("Cup placement and drawer closing completed.")
