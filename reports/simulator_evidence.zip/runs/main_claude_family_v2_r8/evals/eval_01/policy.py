"""Robot program for: "Place the cup in the drawer." See TASK.md and API.md."""
import math

import numpy as np

# ---------------------------------------------------------------- geometry guesses
GRIP_MAX = 0.08          # finger opening when open
FINGER_T = 0.012         # finger thickness (along closing axis)
FINGER_W = 0.024         # finger width (perpendicular to closing axis)
HAND_HALF_U = 0.110      # hand half length along closing axis
HAND_HALF_V = 0.045      # hand half depth perpendicular to closing axis
HAND_ABOVE_TIP = 0.045   # height of the hand body bottom above the fingertips
CUP_GRASP_OFF = 0.024    # fingertip height above the cup bottom when grasping
HANDLE_REACH = 0.028     # how far the cup handle sticks out beyond the body
FRONT_CLEAR = 0.062      # hand centre must stay this far in front of counter front
SAFE_MIN_OPEN = 0.22


def wrap(a):
    return (a + math.pi) % (2 * math.pi) - math.pi


def wrap_half(a):
    return (a + math.pi / 2) % math.pi - math.pi / 2


# ---------------------------------------------------------------- perception
def avg_cup(api, n=6):
    rs = [api.get_cup() for _ in range(n)]
    pos = np.mean([r["pos"] for r in rs], axis=0)
    s = np.mean([math.sin(r["yaw"]) for r in rs])
    c = np.mean([math.cos(r["yaw"]) for r in rs])
    return {"pos": pos, "yaw": math.atan2(s, c),
            "radius": float(np.mean([r["radius"] for r in rs])),
            "height": float(np.mean([r["height"] for r in rs])),
            "spread": float(np.max(np.std([r["pos"] for r in rs], axis=0)))}


def avg_handle(api, n=6):
    return np.mean([api.get_handle()["pos"] for _ in range(n)], axis=0)


def avg_drawer(api, n=6):
    rs = [api.get_drawer() for _ in range(n)]
    return {"opening": float(np.mean([r["opening"] for r in rs])),
            "center": np.mean([r["interior_center"] for r in rs], axis=0),
            "size": np.mean([r["interior_size"] for r in rs], axis=0),
            "floor": float(np.mean([r["floor_z"] for r in rs]))}


def avg_counter(api, n=6):
    rs = [api.get_counter() for _ in range(n)]
    return (float(np.mean([r["top_z"] for r in rs])),
            float(np.mean([r["front_x"] for r in rs])))


def get_objects(api, n=4):
    lists = [api.get_objects() for _ in range(n)]
    out = []
    for i, o in enumerate(lists[0]):
        same = [l[i] for l in lists if i < len(l) and l[i]["name"] == o["name"]]
        out.append({"name": o["name"], "location": o["location"],
                    "pos": np.mean([s["pos"] for s in same], axis=0),
                    "size": np.mean([s["size"] for s in same], axis=0)})
    return out


# ---------------------------------------------------------------- 2-D clearance
def rect_points(c, th, hu, hv, n=4):
    """Sample points of a rectangle; u axis = finger closing axis at yaw th."""
    u = np.array([-math.sin(th), math.cos(th)])
    v = np.array([math.cos(th), math.sin(th)])
    pts = []
    for a in np.linspace(-1, 1, n):
        for b in np.linspace(-1, 1, n):
            pts.append(np.asarray(c) + a * hu * u + b * hv * v)
    return pts


def pt_box_dist(p, bc, bh):
    d = np.abs(np.asarray(p) - bc) - bh
    out = np.linalg.norm(np.maximum(d, 0.0))
    ins = min(max(d[0], d[1]), 0.0)
    return out + ins


def pt_rect_dist(p, c, th, hu, hv):
    u = np.array([-math.sin(th), math.cos(th)])
    v = np.array([math.cos(th), math.sin(th)])
    q = np.asarray(p) - c
    local = np.array([abs(q @ u) - hu, abs(q @ v) - hv])
    out = np.linalg.norm(np.maximum(local, 0.0))
    ins = min(max(local[0], local[1]), 0.0)
    return out + ins


def rect_box_clear(c, th, hu, hv, bc, bh):
    bc = np.asarray(bc, float)
    bh = np.asarray(bh, float)
    m = min(pt_box_dist(p, bc, bh) for p in rect_points(c, th, hu, hv))
    for a in np.linspace(-1, 1, 3):
        for b in np.linspace(-1, 1, 3):
            p = bc + np.array([a * bh[0], b * bh[1]])
            m = min(m, pt_rect_dist(p, c, th, hu, hv))
    return m


def footprint(center, gyaw, cup_yaw, R, open_w, with_hand):
    """List of rectangles (c, th, hu, hv) occupied by cup + fingers (+ hand)."""
    c = np.asarray(center[:2], float)
    rects = [(c, 0.0, R, R)]
    hd = np.array([-math.cos(cup_yaw), -math.sin(cup_yaw)])
    rects.append((c + hd * (R + HANDLE_REACH / 2), cup_yaw, 0.012, HANDLE_REACH / 2 + 0.004))
    u = np.array([-math.sin(gyaw), math.cos(gyaw)])
    off = open_w / 2 + FINGER_T / 2
    for s in (-1, 1):
        rects.append((c + s * off * u, gyaw, FINGER_T / 2, FINGER_W / 2))
    if with_hand:
        rects.append((c, gyaw, HAND_HALF_U, HAND_HALF_V))
    return rects


def clearance(rects_low, rects_hand, objs, hand_z, ):
    best = 1.0
    for o in objs:
        bc = o["pos"][:2]
        bh = o["size"][:2] / 2
        for r in rects_low:
            best = min(best, rect_box_clear(r[0], r[1], r[2], r[3], bc, bh))
        if o["pos"][2] + o["size"][2] / 2 > hand_z - 0.01:
            for r in rects_hand:
                best = min(best, rect_box_clear(r[0], r[1], r[2], r[3], bc, bh))
    return best


# ---------------------------------------------------------------- placement planning
def plan_place(dr, objs_in, front_x, cup_rel, R, open_target):
    """Best place for cup centre if the drawer were at opening open_target.
    cup_rel: cup yaw when the gripper is at yaw 0."""
    shift = -(open_target - dr["opening"])
    icx = dr["center"][0] + shift
    icy = dr["center"][1]
    sx, sy = dr["size"][0], dr["size"][1]
    x_lo_int = icx - sx / 2
    floor = dr["floor"]
    objs = []
    for o in objs_in:
        p = np.array(o["pos"], float)
        p[0] += shift
        objs.append({"pos": p, "size": np.array(o["size"], float)})
    hd = np.array([-math.cos(cup_rel), -math.sin(cup_rel)])
    ext = [R + max(0.0, s * hd[0]) * HANDLE_REACH for s in (-1, 1)]  # back(-x), front(+x)
    eyt = [R + max(0.0, s * hd[1]) * HANDLE_REACH for s in (-1, 1)]
    xmin = x_lo_int + max(ext[0] + 0.014, HAND_HALF_V + 0.008)
    xmax = front_x - max(ext[1] + 0.016, FRONT_CLEAR)
    ymin = max(icy - sy / 2 + eyt[0] + 0.014, icy - sy / 2 + HAND_HALF_U + 0.008)
    ymax = min(icy + sy / 2 - eyt[1] - 0.014, icy + sy / 2 - HAND_HALF_U - 0.008)
    if xmax < xmin or ymax < ymin:
        return None
    hand_z = floor + CUP_GRASP_OFF + HAND_ABOVE_TIP
    xmid = 0.5 * (xmin + xmax)
    best = None
    for x in np.arange(xmin, xmax + 1e-9, 0.005):
        for y in np.arange(ymin, ymax + 1e-9, 0.01):
            fp = footprint([x, y], 0.0, cup_rel, R, GRIP_MAX, True)
            cl = clearance(fp[:-1], fp[-1:], objs, hand_z) if objs else 0.2
            score = min(cl, 0.05) - 0.15 * abs(x - xmid) - 0.03 * abs(y - icy)
            if best is None or score > best[0]:
                best = (score, cl, x, y)
    return {"x": best[2], "y": best[3], "clear": best[1],
            "xwin": (xmin, xmax), "shift": shift}


# ---------------------------------------------------------------- motion helpers
class Robot:
    def __init__(self, api):
        self.api = api

    def log(self, *a):
        self.api.log(" ".join(str(x) for x in a))

    def move(self, p, yaw=None, speed=0.15, tag=""):
        r = self.api.move_to([float(p[0]), float(p[1]), float(p[2])],
                             yaw=None if yaw is None else float(yaw), speed=speed)
        if not r["reached"]:
            self.log("move not reached", tag, np.round(p, 4).tolist(), "err=%.4f" % r["error"])
        return r

    def ee(self):
        return self.api.get_ee()

    def lift_to(self, z, speed=0.15):
        e = self.ee()["pos"]
        return self.move([e[0], e[1], z], speed=speed, tag="lift")


# ---------------------------------------------------------------- drawer motions
def grasp_handle(rb, z_travel):
    api = rb.api
    for attempt in range(3):
        h = avg_handle(api)
        gx, gy, gz = h[0] - 0.003, h[1], h[2] + 0.01
        rb.move([gx, gy, z_travel], yaw=0.0, tag="above handle")
        api.open_gripper()
        rb.move([gx, gy, gz + 0.09], yaw=0.0, tag="pre handle")
        r = rb.move([gx, gy, gz], speed=0.08, tag="handle")
        w = api.close_gripper()
        rb.log("handle grasp attempt", attempt, "width=%.4f" % w, "h=", np.round(h, 4).tolist())
        if 0.004 < w < 0.04:
            return h
        api.open_gripper()
        rb.move([gx, gy, gz + 0.09], tag="retreat handle")
    return None


def release_handle(rb, z_travel):
    rb.api.open_gripper()
    e = rb.ee()["pos"]
    rb.move([e[0] - 0.01, e[1], e[2] + 0.02], speed=0.08, tag="unhook")
    rb.lift_to(z_travel)


def set_drawer(rb, target, z_travel, tol=0.015):
    api = rb.api
    for attempt in range(3):
        d = avg_drawer(api)["opening"]
        rb.log("set_drawer attempt", attempt, "opening=%.4f" % d, "target=%.4f" % target)
        if abs(d - target) < tol:
            return d
        h = grasp_handle(rb, z_travel)
        if h is None:
            rb.log("could not grasp handle")
            return d
        e = rb.ee()["pos"]
        delta = d - target  # positive => push (+x) to close
        extra = 0.012 if target <= 0.001 else 0.0
        rb.move([e[0] + delta + extra, e[1], e[2]], speed=0.08, tag="drawer slide")
        api.wait(0.3)
        release_handle(rb, z_travel)
    d = avg_drawer(api)["opening"]
    rb.log("set_drawer final opening=%.4f" % d)
    return d


# ---------------------------------------------------------------- main
def run(api):
    rb = Robot(api)
    top_z, front_x = avg_counter(api)
    cup = avg_cup(api)
    dr = avg_drawer(api)
    objs = get_objects(api)
    rb.log("counter top=%.4f front=%.4f" % (top_z, front_x))
    rb.log("cup", np.round(cup["pos"], 4).tolist(), "yaw=%.3f" % cup["yaw"],
           "R=%.4f h=%.4f spread=%.4f" % (cup["radius"], cup["height"], cup["spread"]))
    rb.log("drawer open=%.4f" % dr["opening"], "center", np.round(dr["center"], 4).tolist(),
           "size", np.round(dr["size"], 4).tolist(), "floor=%.4f" % dr["floor"])
    rb.log("handle", np.round(avg_handle(api), 4).tolist())
    for o in objs:
        rb.log("obj", o["name"], o["location"], np.round(o["pos"], 3).tolist(),
               np.round(o["size"], 3).tolist())
    rb.log("ee", api.get_ee())

    counter_objs = [o for o in objs if o["location"] != "drawer"]
    drawer_objs = [o for o in objs if o["location"] == "drawer"]
    R = cup["radius"]
    H = cup["height"]
    max_top = max([o["pos"][2] + o["size"][2] / 2 for o in counter_objs] + [top_z])
    z_carry = max(top_z + 0.06, max_top + 0.04) + CUP_GRASP_OFF
    z_travel = max(z_carry + 0.02, top_z + 0.14)
    rb.log("z_carry=%.3f z_travel=%.3f" % (z_carry, z_travel))

    # ---- choose the grasp yaw (fingers perpendicular to the cup handle, avoid neighbours)
    cpos = cup["pos"]
    bottom = 0.5 * ((cpos[2] - H / 2) + top_z)
    hand_z = bottom + CUP_GRASP_OFF + HAND_ABOVE_TIP
    best = None
    for off in (0.0, 0.2, -0.2, 0.4, -0.4):
        g = wrap_half(cup["yaw"] + off)
        fp = footprint(cpos, g, cup["yaw"], R, GRIP_MAX, True)
        cl = clearance(fp[2:-1], fp[-1:], counter_objs, hand_z) if counter_objs else 0.2
        sc = min(cl, 0.03) - 0.01 * abs(off)
        if best is None or sc > best[0]:
            best = (sc, g, cl)
    g = best[1]
    cup_rel = wrap(cup["yaw"] - g)  # cup yaw when the gripper is turned to yaw 0
    rb.log("grasp yaw=%.3f clear=%.3f cup_rel=%.3f" % (g, best[2], cup_rel))

    # ---- choose drawer opening and placement
    d0 = dr["opening"]
    chosen = None
    for D in [max(d0, SAFE_MIN_OPEN), 0.22, 0.26, 0.30, 0.34]:
        if D < d0 - 1e-6:
            continue
        pl = plan_place(dr, drawer_objs, front_x, cup_rel, R, D)
        rb.log("plan D=%.3f" % D, None if pl is None else
               "x=%.3f y=%.3f clear=%.3f" % (pl["x"], pl["y"], pl["clear"]))
        if pl is not None and pl["clear"] > 0.015:
            chosen = D
            break
    if chosen is None:
        chosen = max(d0, 0.30)
    if chosen > d0 + 0.01:
        set_drawer(rb, chosen, z_travel)

    # ---- pick the cup
    picked = False
    shifts = [0.0, 0.008, -0.008, 0.0]
    for attempt in range(4):
        cup = avg_cup(api)
        cpos = cup["pos"]
        bottom = 0.5 * ((cpos[2] - H / 2) + top_z)
        u = np.array([-math.sin(g), math.cos(g), 0.0])
        p = np.array(cpos, float) + shifts[attempt] * u
        rb.move([p[0], p[1], z_travel], yaw=g, tag="above cup")
        api.open_gripper()
        rb.move([p[0], p[1], bottom + H + 0.03], yaw=g, tag="pre cup")
        r = rb.move([p[0], p[1], bottom + CUP_GRASP_OFF], speed=0.06, tag="cup grasp")
        if not r["reached"] and r["error"] > 0.02:
            rb.log("descent blocked, retry")
            rb.lift_to(z_travel)
            continue
        w = api.close_gripper()
        api.wait(0.2)
        rb.log("cup grasp attempt", attempt, "width=%.4f" % w)
        if w < 2 * R - 0.025:
            api.open_gripper()
            rb.lift_to(z_travel)
            continue
        rb.lift_to(z_carry, speed=0.1)
        w2 = api.get_ee()["gripper_width"]
        c2 = avg_cup(api, 3)
        rb.log("after lift width=%.4f cup z=%.4f" % (w2, c2["pos"][2]))
        if w2 > 2 * R - 0.025 and c2["pos"][2] > cpos[2] + 0.03:
            picked = True
            break
        api.open_gripper()
        rb.lift_to(z_travel)
    if not picked:
        rb.log("FAILED to pick cup")

    # ---- place
    dr = avg_drawer(api)
    objs = get_objects(api)
    drawer_objs = [o for o in objs if o["location"] == "drawer"]
    # cup relative yaw as actually held
    ee = api.get_ee()
    cnow = avg_cup(api, 3)
    rel_meas = wrap(cnow["yaw"] - ee["yaw"])
    rb.log("held cup rel yaw meas=%.3f planned=%.3f" % (rel_meas, cup_rel))
    pl = plan_place(dr, drawer_objs, front_x, cup_rel, R, dr["opening"])
    if pl is None:
        rb.log("no placement window!")
        ic = dr["center"]
        pl = {"x": min(front_x - FRONT_CLEAR, ic[0]), "y": ic[1], "clear": -1}
    rb.log("place at x=%.4f y=%.4f clear=%.4f" % (pl["x"], pl["y"], pl["clear"]),
           "drawer open=%.4f" % dr["opening"])
    # cup centre offset relative to gripper (from grasp centering)
    off_xy = np.array(cnow["pos"][:2]) - np.array(ee["pos"][:2]) if picked else np.zeros(2)
    if np.linalg.norm(off_xy) > 0.02:
        off_xy = np.zeros(2)
    tx, ty = pl["x"], pl["y"]
    e = api.get_ee()["pos"]
    rb.move([e[0], e[1], z_carry], yaw=0.0, speed=0.15, tag="rotate")
    rb.move([tx, ty, z_carry], yaw=0.0, tag="over drawer")
    z_place = dr["floor"] + CUP_GRASP_OFF + 0.006
    rb.move([tx, ty, z_place + 0.05], yaw=0.0, speed=0.12, tag="descend")
    rb.move([tx, ty, z_place], yaw=0.0, speed=0.05, tag="place")
    api.wait(0.2)
    api.open_gripper()
    api.wait(0.3)
    rb.move([tx, ty, z_place + 0.07], speed=0.08, tag="clear cup")
    rb.lift_to(z_travel)
    c3 = avg_cup(api, 3)
    rb.log("cup after place", np.round(c3["pos"], 4).tolist())

    # ---- close the drawer
    set_drawer(rb, 0.0, z_travel, tol=0.008)
    e = api.get_ee()["pos"]
    rb.move([e[0] - 0.05, e[1], z_travel + 0.05], tag="retreat")
    c4 = avg_cup(api, 3)
    rb.log("final cup", np.round(c4["pos"], 4).tolist(), "drawer", avg_drawer(api)["opening"])
