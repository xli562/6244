"""Robot program for: "Place the cup in the drawer." See TASK.md and API.md.

Outline
  1. pull the drawer open far enough that the cup fits in the part in front of the counter
  2. pick the cup up from above, fingers closing across the cup body (perpendicular to its
     handle).  Perception carries an episode-constant bias of up to a few cm, but the gripper
     leaves only ~9 mm of play on either side of the cup, so every grasp is checked:
       - a finger stopped by the rim       -> retry shifted sideways
       - fingers pinched the cup wall      -> the cup sits ~3 cm to one side, retry there
       - closed on nothing                 -> retry shifted along the other axis
       - closed on the cup                 -> lift a little, confirm the cup came along
     Cup motion between attempts is tracked as the change of its perceived position, which
     cancels the perception bias.
  3. carry it above everything, lower it onto the drawer floor, let go
  4. push the drawer shut with the handle.
"""
import math

import numpy as np

TARGET_OPENING = 0.27      # how far we want the drawer open for placing
GRIP_HALF_X = 0.07         # keep gripper centre this far in front of the counter face
CUP_HANDLE_EXT = 0.03      # how far the cup handle sticks out of the body
FALLBACK_COUNTER = {"top_z": 0.292, "front_x": 0.557}


def wrap(a):
    return (a + math.pi) % (2 * math.pi) - math.pi


def wrap_half(a):
    """Wrap an angle to [-pi/2, pi/2] (the gripper is symmetric under pi)."""
    a = wrap(a)
    if a > math.pi / 2:
        a -= math.pi
    elif a < -math.pi / 2:
        a += math.pi
    return a


def r3(v):
    return [round(float(x), 4) for x in v]


class Robot:
    def __init__(self, api):
        self.api = api
        self.t = 0.0              # rough estimate of the simulated time used so far
        self.last = None          # last commanded fingertip position

    def log(self, msg):
        try:
            self.api.log(str(msg))
        except Exception:
            pass

    # ----------------------------------------------------------- perception
    def cup(self, n=3):
        ps, cs, ss, hs, rs = [], [], [], [], []
        for _ in range(n):
            c = self.api.get_cup()
            ps.append(c["pos"])
            cs.append(math.cos(c["yaw"]))
            ss.append(math.sin(c["yaw"]))
            hs.append(c["height"])
            rs.append(c["radius"])
        return {"pos": np.mean(np.array(ps, dtype=float), axis=0),
                "yaw": math.atan2(np.mean(ss), np.mean(cs)),
                "height": float(np.mean(hs)), "radius": float(np.mean(rs))}

    def handle(self, n=3):
        return np.mean([self.api.get_handle()["pos"] for _ in range(n)], axis=0)

    def drawer(self, n=3):
        ds = [self.api.get_drawer() for _ in range(n)]
        return {"opening": float(np.mean([d["opening"] for d in ds])),
                "center": np.mean([d["interior_center"] for d in ds], axis=0),
                "size": np.mean([d["interior_size"] for d in ds], axis=0),
                "floor_z": float(np.mean([d["floor_z"] for d in ds]))}

    def counter(self, n=2):
        try:
            cs = [self.api.get_counter() for _ in range(n)]
            return {"top_z": float(np.mean([c["top_z"] for c in cs])),
                    "front_x": float(np.mean([c["front_x"] for c in cs]))}
        except Exception:
            return dict(FALLBACK_COUNTER)

    def objects(self):
        try:
            lst = self.api.get_objects()
        except Exception:
            lst = []
        return [{"name": o["name"], "pos": np.array(o["pos"], dtype=float),
                 "size": np.array(o["size"], dtype=float), "location": o["location"]}
                for o in lst]

    def ee(self):
        e = self.api.get_ee()
        return np.array(e["pos"], dtype=float), e["yaw"], e["gripper_width"]

    # --------------------------------------------------------------- motion
    def move(self, pos, yaw=None, speed=0.15):
        pos = [float(v) for v in pos]
        if self.last is None:
            self.last = self.ee()[0]
        self.t += float(np.linalg.norm(np.array(pos) - self.last)) / speed + 0.3
        self.last = np.array(pos)
        if yaw is None:
            return self.api.move_to(pos, speed=speed)
        return self.api.move_to(pos, yaw=float(yaw), speed=speed)

    def close(self):
        """Close and wait for the fingers to settle; returns the settled opening.

        close_gripper() can return while the fingers are still moving (e.g. while one
        finger drags the cup along), so poll the opening until it stops changing."""
        self.api.close_gripper()
        self.t += 0.8
        prev = None
        w = self.ee()[2]
        for _ in range(8):
            self.api.wait(0.25)
            self.t += 0.25
            w = self.ee()[2]
            if prev is not None and abs(w - prev) < 0.001:
                break
            prev = w
        return w

    def open(self):
        self.api.open_gripper()
        self.api.wait(0.3)
        self.t += 0.9

    def lift_to(self, z, speed=0.15):
        p, _, _ = self.ee()
        if p[2] < z:
            self.move([p[0], p[1], z], speed=speed)


# ======================================================================  drawer
def grasp_handle(rb, counter, approach_z):
    """Grasp the drawer handle bar (fingers either side of it, closing along y)."""
    h = rb.handle()
    for dx in (0.0, -0.014, 0.014):
        gx = min(h[0] - 0.003, counter["front_x"] - 0.035) + dx
        g = np.array([gx, h[1], h[2]])
        rb.open()
        rb.move([g[0], g[1], approach_z], yaw=0.0)
        rb.move(g, speed=0.08)
        w = rb.close()
        rb.log("handle %s w=%.4f" % (r3(g), w))
        if w > 0.004:
            return g
        rb.open()
        rb.move([g[0], g[1], approach_z], speed=0.12)
    return None


def move_drawer(rb, counter, target_opening, approach_z, d=None):
    if d is None:
        d = rb.drawer()
    rb.log("drawer open %.4f c %s floor %.4f" % (d["opening"], r3(d["center"]), d["floor_z"]))
    for attempt in range(2):
        delta = target_opening - d["opening"]
        if target_opening > 0 and abs(delta) < 0.015:
            break
        if target_opening <= 0 and d["opening"] < 0.006:
            break
        if target_opening <= 0:
            delta -= 0.012          # push a little past closed
        g = grasp_handle(rb, counter, approach_z)
        if g is None:
            rb.log("could not grasp handle")
            break
        p, _, _ = rb.ee()
        rb.move([p[0] - delta, p[1], p[2]], speed=0.08)
        rb.open()
        p, _, _ = rb.ee()
        rb.move([p[0], p[1], approach_z], speed=0.12)
        d = rb.drawer()
        rb.log("drawer now %.4f" % d["opening"])
    return d


def choose_place(rb, d, counter, objs, cup_r):
    """Pick a point in the reachable part of the drawer, clear of the drawer objects."""
    cx, cy = d["center"][0], d["center"][1]
    sx, sy = d["size"][0], d["size"][1]
    xmin_in, xmax_in = cx - sx / 2.0, cx + sx / 2.0
    ymin_in, ymax_in = cy - sy / 2.0, cy + sy / 2.0
    ext_x = cup_r + CUP_HANDLE_EXT + 0.012     # handle points along +-x at yaw 0
    ext_y = 0.06                               # fingers along y
    x_lo = xmin_in + ext_x
    x_hi = min(counter["front_x"] - GRIP_HALF_X, xmax_in - ext_x)
    y_lo, y_hi = ymin_in + ext_y, ymax_in - ext_y
    if x_hi < x_lo:
        x_lo = x_hi = 0.5 * (x_lo + x_hi)
    dobj = [o for o in objs if o["location"] == "drawer"]
    best, best_score = None, -1e9
    for x in np.linspace(x_lo, x_hi, 9):
        for y in np.linspace(y_lo, y_hi, 41):
            clear = 1.0
            for o in dobj:
                gx = abs(x - o["pos"][0]) - o["size"][0] / 2.0 - ext_x
                gy = abs(y - o["pos"][1]) - o["size"][1] / 2.0 - ext_y
                clear = min(clear, max(gx, gy))
            score = min(clear, 0.04) * 10.0 - 0.2 * abs(y - cy) - 0.1 * abs(
                x - 0.5 * (x_lo + x_hi))
            if score > best_score:
                best_score, best = score, (x, y, clear)
    rb.log("place x=%.3f y=%.3f clear=%.3f" % best)
    return best[0], best[1]


# ======================================================================  cup
def pick_cup(rb, counter, objs, travel_z):
    """Grasp and lift the cup.  Returns the fingertip height above the cup bottom, or None."""
    c0 = rb.cup()
    a = c0["yaw"]
    yaw = wrap_half(a)
    u = np.array([-math.sin(yaw), math.cos(yaw)])     # finger closing axis
    v = np.array([math.cos(yaw), math.sin(yaw)])      # along the cup handle
    h = c0["height"]
    perc = c0["pos"].copy()                           # latest perceived cup centre
    bottom = 0.5 * ((perc[2] - h / 2.0) + counter["top_z"])
    rim = bottom + h
    gz = bottom + 0.022
    rb.log("cup %s yaw %.3f bottom %.4f" % (r3(perc), a, bottom))

    r = c0["radius"]
    w_ok = 2.0 * math.sqrt(max(r * r - 0.015 ** 2, 1e-6))   # chord when 15 mm off-centre
    # height for short hops between attempts: above the rim and nearby objects
    hop = rim + 0.03
    for ob in objs:
        if ob["location"] == "counter" and np.linalg.norm(ob["pos"][:2] - perc[:2]) < 0.14:
            hop = max(hop, ob["pos"][2] + ob["size"][2] / 2.0 + 0.025)
    hop = min(hop, travel_z)

    # grasp offsets (along u, along v, width accepted) from the perceived centre
    queue = [(0.0, 0.0, w_ok)]
    tried = []
    best = None                   # widest off-centre grasp seen: [w, du, dv]
    best_used = False
    for attempt in range(7):
        late = attempt > 0 and rb.t > 52.0
        if (not queue or late) and best is not None and not best_used and rb.t < 58.0:
            # nothing reached the expected width: go back to the widest grasp we found
            queue = [(best[1], best[2], 0.035)]
            best_used = True
        elif not queue or late:
            rb.log("giving up on the cup (t~%.1f)" % rb.t)
            break
        o = queue.pop(0)
        acc = o[2]
        tried.append(o)
        p = perc[:2] + o[0] * u + o[1] * v
        rb.open()
        if attempt == 0:
            rb.lift_to(travel_z)
            rb.move([p[0], p[1], travel_z], yaw=yaw)
        else:
            rb.move([p[0], p[1], hop], yaw=yaw, speed=0.1)
        rb.move([p[0], p[1], rim + 0.025], speed=0.12)
        # first go only a little below the rim: a finger resting on the rim shows up
        # without pressing the cup hard
        za = rim - 0.02
        rb.move([p[0], p[1], za], speed=0.04)
        e, _, _ = rb.ee()
        outcome = None
        w = -1.0
        if e[2] > za + 0.011:
            outcome = "rim"
        else:
            rb.move([p[0], p[1], gz], speed=0.04)
            e, _, _ = rb.ee()
            w = rb.close()
            if w >= acc:
                rb.move([p[0], p[1], e[2] + 0.04], speed=0.06)
                _, _, w2 = rb.ee()
                c1 = rb.cup()
                rose = c1["pos"][2] - perc[2]
                rb.log("try %d off %s w=%.4f lift w=%.4f rose=%.4f t~%.1f" %
                       (attempt, r3(o), w, w2, rose, rb.t))
                if w2 > 0.6 * w and rose > 0.015:
                    return e[2] - bottom
                rb.move([p[0], p[1], e[2] + 0.003], speed=0.04)
                if 0.0025 < w2 < 0.025:
                    outcome = "pinch"      # fingers ended up pinching the cup wall
                    w = w2
                else:
                    outcome = "slip"
            elif w > 0.025:
                outcome = "chord"          # closed on the cup well off its centre line
            elif w > 0.0025:
                outcome = "pinch"          # one finger went into the cup: pinched the wall
            else:
                outcome = "miss"
            rb.open()
        rb.move([p[0], p[1], max(rim + 0.03, e[2] + 0.02)], speed=0.06)
        cn = rb.cup()
        delta = cn["pos"][:2] - perc[:2]
        perc = cn["pos"]
        du, dv = float(delta @ u), float(delta @ v)
        # everything expressed relative to the newly perceived centre
        orel = (o[0] - du, o[1] - dv)
        queue = [(q[0] - du, q[1] - dv, q[2]) for q in queue]
        tried = [(q[0] - du, q[1] - dv) for q in tried]
        if best is not None:
            best = [best[0], best[1] - du, best[2] - dv]
        if outcome == "chord" and (best is None or w > best[0]):
            best = [w, orel[0], orel[1]]
        # sign hints: the perceived centre relative to where we just were
        su = -1.0 if orel[0] > 0.004 else 1.0
        sv = -1.0 if orel[1] > 0.004 else 1.0
        new = []
        if outcome == "rim":
            new = [(orel[0] + su * 0.016, orel[1]), (orel[0] - su * 0.016, orel[1])]
        elif outcome == "pinch":
            # the wall ends up between the fingertips: centre is a radius to one side
            new = [(orel[0] + su * (r - 0.001), orel[1]), (orel[0] - su * (r - 0.001), orel[1])]
        elif outcome == "chord":
            # closing centred the cup across the fingers; along the handle axis it is
            # off by the chord's distance from the centre
            ev = math.sqrt(max(r * r - (w / 2.0) ** 2, 0.0))
            new = [(orel[0], orel[1] + sv * ev), (orel[0], orel[1] - sv * ev)]
        elif outcome == "miss":
            new = [(orel[0], orel[1] + 0.022), (orel[0], orel[1] - 0.022)]
        elif outcome == "slip" and attempt < 3:
            new = [(orel[0], orel[1])]
        new = [(q[0], q[1], w_ok) for q in new]
        rb.log("try %d off %s -> %s w=%.4f, cup moved %s t~%.1f" %
               (attempt, r3(o), outcome, w, r3([du, dv]), rb.t))
        queue = new + queue
        # drop candidates we have effectively tried already
        filt = []
        for q in queue:
            if outcome != "slip" and any(abs(q[0] - t[0]) < 0.006 and abs(q[1] - t[1]) < 0.006
                                         for t in tried):
                continue
            filt.append(q)
        queue = filt
    return None


# ======================================================================  main
def run(api):
    rb = Robot(api)
    counter = rb.counter()
    objs = rb.objects()
    rb.log("counter %s objs %s" % (r3([counter["top_z"], counter["front_x"]]),
                                   [(o["name"], o["location"], r3(o["pos"]), r3(o["size"]))
                                    for o in objs]))
    top = counter["top_z"]
    for o in objs:
        if o["location"] == "counter":
            top = max(top, o["pos"][2] + o["size"][2] / 2.0)
    approach_z = counter["top_z"] + 0.06
    travel_z = max(top + 0.11, counter["top_z"] + 0.17)   # cup hangs ~4 cm below the tips

    rb.open()
    rb.lift_to(approach_z)

    # 1) open the drawer
    d = rb.drawer()
    if d["opening"] < TARGET_OPENING - 0.015:
        d = move_drawer(rb, counter, TARGET_OPENING, approach_z, d)
    rb.lift_to(travel_z)

    # 2) pick up the cup
    hold = pick_cup(rb, counter, objs, travel_z)
    if hold is None:
        rb.log("failed to pick the cup")
        rb.lift_to(travel_z)
        return
    p, _, _ = rb.ee()
    rb.move([p[0], p[1], travel_z], speed=0.1)

    # 3) place it in the drawer
    d = rb.drawer()
    objs = rb.objects()
    px, py = choose_place(rb, d, counter, objs, 0.031)
    rb.move([px, py, travel_z], yaw=0.0, speed=0.12)
    rb.move([px, py, d["floor_z"] + hold + 0.04], speed=0.1)
    rb.move([px, py, d["floor_z"] + hold + 0.006], speed=0.03)
    p, _, w = rb.ee()
    rb.log("place tips z=%.4f w=%.4f hold=%.4f t~%.1f" % (p[2], w, hold, rb.t))
    rb.open()
    rb.move([px, py, approach_z], speed=0.08)

    # 4) close the drawer
    d = move_drawer(rb, counter, 0.0, approach_z)
    rb.log("final drawer %.4f" % d["opening"])
