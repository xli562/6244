"""Robot program for: "Place the cup in the drawer." See TASK.md and API.md."""
import math

import numpy as np

# ---------------------------------------------------------------- constants
N_READ = 8                 # readings averaged per perception call
TARGET_OPENING = 0.27      # how far we want the drawer open for placing
GRIP_HALF_X = 0.07         # keep gripper centre this far in front of counter face
CUP_HANDLE_EXT = 0.03      # how far the cup handle sticks out of the body
FALLBACK_COUNTER = {"top_z": 0.292, "front_x": 0.557}


def wrap(a):
    return (a + math.pi) % (2 * math.pi) - math.pi


def wrap_half(a):
    """Wrap an angle to [-pi/2, pi/2] (gripper is symmetric under pi)."""
    a = wrap(a)
    if a > math.pi / 2:
        a -= math.pi
    elif a < -math.pi / 2:
        a += math.pi
    return a


class Robot:
    def __init__(self, api):
        self.api = api

    def log(self, msg):
        try:
            self.api.log(str(msg))
        except Exception:
            pass

    # ----------------------------------------------------------- perception
    def cup(self):
        ps, cs, ss, rs, hs = [], [], [], [], []
        for _ in range(N_READ):
            c = self.api.get_cup()
            ps.append(c["pos"])
            cs.append(math.cos(c["yaw"]))
            ss.append(math.sin(c["yaw"]))
            rs.append(c["radius"])
            hs.append(c["height"])
        ps = np.array(ps, dtype=float)
        return {"pos": ps.mean(axis=0), "std": ps.std(axis=0),
                "yaw": math.atan2(np.mean(ss), np.mean(cs)),
                "radius": float(np.mean(rs)), "height": float(np.mean(hs))}

    def handle(self):
        ps = np.array([self.api.get_handle()["pos"] for _ in range(N_READ)], dtype=float)
        return ps.mean(axis=0), ps.std(axis=0)

    def drawer(self):
        ds = [self.api.get_drawer() for _ in range(N_READ)]
        return {"opening": float(np.mean([d["opening"] for d in ds])),
                "center": np.mean([d["interior_center"] for d in ds], axis=0),
                "size": np.mean([d["interior_size"] for d in ds], axis=0),
                "floor_z": float(np.mean([d["floor_z"] for d in ds])),
                "open_std": float(np.std([d["opening"] for d in ds]))}

    def counter(self):
        try:
            cs = [self.api.get_counter() for _ in range(N_READ)]
            return {"top_z": float(np.mean([c["top_z"] for c in cs])),
                    "front_x": float(np.mean([c["front_x"] for c in cs]))}
        except Exception:
            return dict(FALLBACK_COUNTER)

    def objects(self):
        acc = {}
        for _ in range(N_READ):
            for o in self.api.get_objects():
                e = acc.setdefault(o["name"], {"pos": [], "size": [], "loc": o["location"]})
                e["pos"].append(o["pos"])
                e["size"].append(o["size"])
                e["loc"] = o["location"]
        out = []
        for n, e in acc.items():
            out.append({"name": n, "pos": np.mean(e["pos"], axis=0),
                        "size": np.mean(e["size"], axis=0), "location": e["loc"]})
        return out

    def ee(self):
        e = self.api.get_ee()
        return np.array(e["pos"], dtype=float), e["yaw"], e["gripper_width"]

    # --------------------------------------------------------------- motion
    def move(self, pos, yaw=None, speed=0.15, tag=""):
        pos = [float(v) for v in pos]
        if yaw is None:
            r = self.api.move_to(pos, speed=speed)
        else:
            r = self.api.move_to(pos, yaw=float(yaw), speed=speed)
        if not r.get("reached", True):
            self.log("move %s not reached: target=%s err=%.4f ee=%s" %
                     (tag, np.round(pos, 4), r.get("error", -1), np.round(self.ee()[0], 4)))
        return r

    def lift_to(self, z, speed=0.15):
        p, _, _ = self.ee()
        if p[2] < z:
            self.move([p[0], p[1], z], speed=speed, tag="lift")


# ======================================================================
def safe_z(rb, counter, objs, extra=0.0):
    """Height for travelling above the counter with `extra` hanging below the tips."""
    top = counter["top_z"]
    for o in objs:
        if o["location"] == "counter":
            top = max(top, o["pos"][2] + o["size"][2] / 2.0)
    return max(top + 0.06 + extra, counter["top_z"] + 0.12 + extra)


def grasp_handle(rb, counter, approach_z, yaw=0.0):
    """Grasp the drawer handle bar. Returns the grasp position or None."""
    for attempt in range(3):
        h, hstd = rb.handle()
        rb.log("handle reading %s std %s" % (np.round(h, 4), np.round(hstd, 4)))
        gx = min(h[0] - 0.003, counter["front_x"] - 0.035)
        dx = [0.0, -0.006, 0.006][attempt]
        g = np.array([gx + dx, h[1], h[2]])
        rb.api.open_gripper()
        rb.move([g[0], g[1], approach_z], yaw=yaw, tag="handle-above")
        rb.move([g[0], g[1], g[2] + 0.03], speed=0.1, tag="handle-pre")
        rb.move(g, speed=0.05, tag="handle-down")
        w = rb.api.close_gripper()
        rb.log("handle grasp width %.4f" % w)
        if w > 0.004:
            return g
        rb.api.open_gripper()
        rb.move([g[0], g[1], approach_z], speed=0.1, tag="handle-retreat")
    return None


def move_drawer(rb, counter, target_opening, approach_z):
    d = rb.drawer()
    rb.log("drawer opening %.4f (std %.4f) center %s size %s floor %.4f" %
           (d["opening"], d["open_std"], np.round(d["center"], 4),
            np.round(d["size"], 4), d["floor_z"]))
    delta = target_opening - d["opening"]
    if abs(delta) < 0.01:
        return d
    for attempt in range(2):
        g = grasp_handle(rb, counter, approach_z)
        if g is None:
            rb.log("could not grasp handle")
            break
        d0 = rb.drawer()
        delta = target_opening - d0["opening"]
        # pushing closed: overshoot a little so it really shuts
        if target_opening <= 0.0:
            delta -= 0.015
        p, _, _ = rb.ee()
        tgt = np.array([p[0] - delta, p[1], p[2]])
        rb.move(tgt, speed=0.08, tag="drawer-slide")
        rb.api.open_gripper()
        p, _, _ = rb.ee()
        rb.move([p[0], p[1], approach_z], speed=0.1, tag="handle-up")
        d = rb.drawer()
        rb.log("drawer opening after slide %.4f" % d["opening"])
        if abs(d["opening"] - target_opening) < 0.02 or (
                target_opening <= 0.0 and d["opening"] < 0.01):
            break
    return rb.drawer()


def choose_place(rb, d, counter, objs, cup_r):
    """Pick a point in the reachable part of the drawer clear of the drawer objects."""
    cx, cy = d["center"][0], d["center"][1]
    sx, sy = d["size"][0], d["size"][1]
    xmin_in, xmax_in = cx - sx / 2.0, cx + sx / 2.0
    ymin_in, ymax_in = cy - sy / 2.0, cy + sy / 2.0
    ext_x = cup_r + CUP_HANDLE_EXT + 0.012     # handle points along +-x at yaw 0
    ext_y = 0.06                               # fingers along y
    x_lo = xmin_in + ext_x
    x_hi = min(counter["front_x"] - GRIP_HALF_X, xmax_in - ext_x)
    y_lo = ymin_in + ext_y
    y_hi = ymax_in - ext_y
    if x_hi < x_lo:
        x_lo = x_hi = 0.5 * (x_lo + x_hi)
    dobj = [o for o in objs if o["location"] == "drawer"]
    best, best_score = None, -1e9
    for x in np.linspace(x_lo, x_hi, 9):
        for y in np.linspace(y_lo, y_hi, 41):
            clear = 1.0
            for o in dobj:
                ox, oy = o["pos"][0], o["pos"][1]
                hx, hy = o["size"][0] / 2.0, o["size"][1] / 2.0
                gx = abs(x - ox) - hx - ext_x
                gy = abs(y - oy) - hy - ext_y
                # separation along the better axis (positive = clear)
                sep = max(gx, gy)
                clear = min(clear, sep)
            score = min(clear, 0.04) * 10.0 - 0.2 * abs(y - cy) - 0.1 * abs(
                x - 0.5 * (x_lo + x_hi))
            if score > best_score:
                best_score, best = score, (x, y, clear)
    rb.log("place choice x=%.3f y=%.3f clear=%.3f (x %.3f..%.3f, y %.3f..%.3f)" %
           (best[0], best[1], best[2], x_lo, x_hi, y_lo, y_hi))
    return best[0], best[1]


def grasp_cup(rb, counter, objs, travel_z):
    for attempt in range(3):
        c = rb.cup()
        rb.log("cup reading pos %s std %s yaw %.3f r %.4f h %.4f" %
               (np.round(c["pos"], 4), np.round(c["std"], 4), c["yaw"], c["radius"],
                c["height"]))
        bottom = 0.5 * ((c["pos"][2] - c["height"] / 2.0) + counter["top_z"])
        gz = bottom + 0.022
        yaw = wrap_half(c["yaw"])
        x, y = c["pos"][0], c["pos"][1]
        rb.api.open_gripper()
        rb.move([x, y, travel_z], yaw=yaw, tag="cup-above")
        rb.move([x, y, gz + 0.06], speed=0.1, tag="cup-pre")
        r = rb.move([x, y, gz], speed=0.05, tag="cup-down")
        w = rb.api.close_gripper()
        rb.log("cup grasp width %.4f" % w)
        if w > 0.03:
            return bottom, gz, c
        rb.api.open_gripper()
        rb.move([x, y, travel_z], speed=0.1, tag="cup-retreat")
    return None


def run(api):
    rb = Robot(api)
    counter = rb.counter()
    objs = rb.objects()
    rb.log("counter %s" % counter)
    for o in objs:
        rb.log("obj %s %s pos %s size %s" % (o["name"], o["location"],
                                             np.round(o["pos"], 3), np.round(o["size"], 3)))
    # extra info about noise: single readings
    for _ in range(3):
        rb.log("raw cup %s" % api.get_cup())
        rb.log("raw handle %s" % api.get_handle())
    rb.log("ee %s" % api.get_ee())

    approach_z = counter["top_z"] + 0.06
    travel_z = safe_z(rb, counter, objs, extra=0.05)

    # 0) get clear of anything
    rb.api.open_gripper()
    rb.lift_to(approach_z)

    # 1) open the drawer
    d = rb.drawer()
    if d["opening"] < TARGET_OPENING - 0.01:
        d = move_drawer(rb, counter, TARGET_OPENING, approach_z)
    rb.lift_to(approach_z)

    # 2) grasp the cup
    rb.lift_to(travel_z)
    res = grasp_cup(rb, counter, objs, travel_z)
    if res is None:
        rb.log("failed to grasp cup")
        return
    bottom, gz, c = res
    hold = gz - bottom                     # tip height above cup bottom
    rb.move([c["pos"][0], c["pos"][1], travel_z], speed=0.1, tag="cup-lift")
    _, _, w = rb.ee()
    rb.log("width after lift %.4f" % w)

    # 3) place into the drawer
    d = rb.drawer()
    objs = rb.objects()
    px, py = choose_place(rb, d, counter, objs, c["radius"])
    rb.move([px, py, travel_z], yaw=0.0, speed=0.12, tag="to-drawer")
    place_z = d["floor_z"] + hold + 0.008
    rb.move([px, py, place_z + 0.05], speed=0.1, tag="place-pre")
    rb.move([px, py, place_z], speed=0.04, tag="place-down")
    rb.api.open_gripper()
    rb.api.wait(0.3)
    rb.move([px, py, approach_z], speed=0.08, tag="place-up")
    c2 = rb.cup()
    rb.log("cup after place %s" % np.round(c2["pos"], 4))

    # 4) close the drawer
    d = move_drawer(rb, counter, 0.0, approach_z)
    rb.log("final drawer opening %.4f" % d["opening"])
    c3 = rb.cup()
    rb.log("cup final %s" % np.round(c3["pos"], 4))
