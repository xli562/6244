"""Robot program for: "Place the cup in the drawer." See TASK.md and API.md.

Outline
  1. pull the drawer open far enough that a cup fits in the part in front of the counter
  2. pick the cup up.  Perception has an episode-constant bias of up to a few cm, while the
     gripper leaves only ~9 mm of play around the cup.  So the fingers are never lowered
     onto the cup: they are lowered beside it (on the side away from its handle), at
     counter height measured by touch, and slid sideways so the cup body passes between
     them; closing then centres it.  If the cup was missed or pushed, its displacement
     (perceived before/after, which cancels the bias) tells where it now is and we retry.
  3. carry it above everything, lower it into the drawer until it touches the floor, let go
  4. push the drawer shut with the handle.
"""
import math

import numpy as np

TARGET_OPENING = 0.27      # how far we want the drawer open for placing
GRIP_HALF_X = 0.07         # keep gripper centre this far in front of the counter face
CUP_HANDLE_EXT = 0.03      # how far the cup handle sticks out of the body
FINGER_OPEN = 0.04         # half opening of the gripper
SWEEP_D = 0.075            # start of the sideways slide, from the cup centre
FALLBACK_COUNTER = {"top_z": 0.292, "front_x": 0.557}


def wrap(a):
    return (a + math.pi) % (2 * math.pi) - math.pi


def wrap_half(a):
    """Wrap an angle to [-pi/2, pi/2] (the gripper is symmetric under pi)."""
    a = wrap(a)
    if a > math.pi / 2:
        a -= math.pi
    elif a < -math.pi / 2:
        a += math.pi
    return a


def r3(v):
    return [round(float(x), 4) for x in v]


class Robot:
    def __init__(self, api):
        self.api = api

    def log(self, msg):
        try:
            self.api.log(str(msg))
        except Exception:
            pass

    # ----------------------------------------------------------- perception
    def cup(self, n=3):
        ps, cs, ss, hs = [], [], [], []
        r = 0.031
        for _ in range(n):
            c = self.api.get_cup()
            ps.append(c["pos"])
            cs.append(math.cos(c["yaw"]))
            ss.append(math.sin(c["yaw"]))
            hs.append(c["height"])
            r = c["radius"]
        ps = np.array(ps, dtype=float)
        return {"pos": ps.mean(axis=0), "yaw": math.atan2(np.mean(ss), np.mean(cs)),
                "radius": float(r), "height": float(np.mean(hs))}

    def handle(self, n=3):
        return np.mean([self.api.get_handle()["pos"] for _ in range(n)], axis=0)

    def drawer(self, n=3):
        ds = [self.api.get_drawer() for _ in range(n)]
        return {"opening": float(np.mean([d["opening"] for d in ds])),
                "center": np.mean([d["interior_center"] for d in ds], axis=0),
                "size": np.mean([d["interior_size"] for d in ds], axis=0),
                "floor_z": float(np.mean([d["floor_z"] for d in ds]))}

    def counter(self, n=2):
        try:
            cs = [self.api.get_counter() for _ in range(n)]
            return {"top_z": float(np.mean([c["top_z"] for c in cs])),
                    "front_x": float(np.mean([c["front_x"] for c in cs]))}
        except Exception:
            return dict(FALLBACK_COUNTER)

    def objects(self, n=1):
        acc = {}
        for _ in range(n):
            try:
                lst = self.api.get_objects()
            except Exception:
                lst = []
            for o in lst:
                e = acc.setdefault(o["name"], {"pos": [], "size": [], "loc": o["location"]})
                e["pos"].append(o["pos"])
                e["size"].append(o["size"])
                e["loc"] = o["location"]
        return [{"name": k, "pos": np.mean(e["pos"], axis=0), "size": np.mean(e["size"], axis=0),
                 "location": e["loc"]} for k, e in acc.items()]

    def ee(self):
        e = self.api.get_ee()
        return np.array(e["pos"], dtype=float), e["yaw"], e["gripper_width"]

    # --------------------------------------------------------------- motion
    def move(self, pos, yaw=None, speed=0.15):
        pos = [float(v) for v in pos]
        if yaw is None:
            return self.api.move_to(pos, speed=speed)
        return self.api.move_to(pos, yaw=float(yaw), speed=speed)

    def lift_to(self, z, speed=0.15):
        p, _, _ = self.ee()
        if p[2] < z:
            self.move([p[0], p[1], z], speed=speed)


# ======================================================================  drawer
def grasp_handle(rb, counter, approach_z):
    """Grasp the drawer handle bar (fingers either side of it, closing along y)."""
    h = rb.handle()
    for dx in (0.0, -0.014, 0.014):
        gx = min(h[0] - 0.003, counter["front_x"] - 0.035) + dx
        g = np.array([gx, h[1], h[2]])
        rb.api.open_gripper()
        rb.move([g[0], g[1], approach_z], yaw=0.0)
        rb.move(g, speed=0.08)
        w = rb.api.close_gripper()
        rb.log("handle %s grasp w=%.4f" % (r3(g), w))
        if w > 0.004:
            return g
        rb.api.open_gripper()
        rb.move([g[0], g[1], approach_z], speed=0.12)
    return None


def move_drawer(rb, counter, target_opening, approach_z, d=None):
    if d is None:
        d = rb.drawer()
    rb.log("drawer open %.4f c %s floor %.4f" % (d["opening"], r3(d["center"]), d["floor_z"]))
    for attempt in range(2):
        delta = target_opening - d["opening"]
        if target_opening > 0 and abs(delta) < 0.015:
            break
        if target_opening <= 0 and d["opening"] < 0.006:
            break
        if target_opening <= 0:
            delta -= 0.012          # push a little past closed
        g = grasp_handle(rb, counter, approach_z)
        if g is None:
            rb.log("could not grasp handle")
            break
        p, _, _ = rb.ee()
        rb.move([p[0] - delta, p[1], p[2]], speed=0.08)
        rb.api.open_gripper()
        p, _, _ = rb.ee()
        rb.move([p[0], p[1], approach_z], speed=0.12)
        d = rb.drawer()
        rb.log("drawer now %.4f" % d["opening"])
    return d


def choose_place(rb, d, counter, objs, cup_r):
    """Pick a point in the reachable part of the drawer, clear of the drawer objects."""
    cx, cy = d["center"][0], d["center"][1]
    sx, sy = d["size"][0], d["size"][1]
    xmin_in, xmax_in = cx - sx / 2.0, cx + sx / 2.0
    ymin_in, ymax_in = cy - sy / 2.0, cy + sy / 2.0
    ext_x = cup_r + CUP_HANDLE_EXT + 0.012     # handle points along +-x at yaw 0
    ext_y = 0.06                               # fingers along y
    x_lo = xmin_in + ext_x
    x_hi = min(counter["front_x"] - GRIP_HALF_X, xmax_in - ext_x)
    y_lo, y_hi = ymin_in + ext_y, ymax_in - ext_y
    if x_hi < x_lo:
        x_lo = x_hi = 0.5 * (x_lo + x_hi)
    dobj = [o for o in objs if o["location"] == "drawer"]
    best, best_score = None, -1e9
    for x in np.linspace(x_lo, x_hi, 9):
        for y in np.linspace(y_lo, y_hi, 41):
            clear = 1.0
            for o in dobj:
                gx = abs(x - o["pos"][0]) - o["size"][0] / 2.0 - ext_x
                gy = abs(y - o["pos"][1]) - o["size"][1] / 2.0 - ext_y
                clear = min(clear, max(gx, gy))
            score = min(clear, 0.04) * 10.0 - 0.2 * abs(y - cy) - 0.1 * abs(
                x - 0.5 * (x_lo + x_hi))
            if score > best_score:
                best_score, best = score, (x, y, clear)
    rb.log("place x=%.3f y=%.3f clear=%.3f" % best)
    return best[0], best[1]


# ======================================================================  cup
def footprint_clear(objs, pt, rad):
    """Smallest gap between a disc (pt, rad) and the counter objects' boxes."""
    gap = 1.0
    for o in objs:
        if o["location"] != "counter":
            continue
        dx = max(abs(pt[0] - o["pos"][0]) - o["size"][0] / 2.0, 0.0)
        dy = max(abs(pt[1] - o["pos"][1]) - o["size"][1] / 2.0, 0.0)
        gap = min(gap, math.hypot(dx, dy) - rad)
    return gap


def pick_cup(rb, counter, objs, travel_z):
    """Returns (counter_z, grasp_z) on success, None on failure."""
    c0 = rb.cup()
    yaw = wrap_half(c0["yaw"])
    a = c0["yaw"]
    hd = np.array([-math.cos(a), -math.sin(a)])          # cup handle direction
    u = np.array([-math.sin(yaw), math.cos(yaw)])        # finger closing axis
    cup_h = c0["height"]
    perc = c0["pos"].copy()                              # last perceived cup centre
    est = perc[:2].copy()                                # current belief, cup centre
    cz = counter["top_z"]
    measured = False
    rb.log("cup %s yaw %.3f" % (r3(perc), a))

    # sweep from the side opposite the handle unless that is crowded
    sdir = hd.copy()
    d_sweep = SWEEP_D
    if footprint_clear(objs, est - SWEEP_D * hd, 0.06) < 0.0 and \
            footprint_clear(objs, est + 0.105 * hd, 0.06) > footprint_clear(
                objs, est - SWEEP_D * hd, 0.06):
        sdir = -hd
        d_sweep = 0.105
    end_extra = 0.0
    tried_u = 0
    for attempt in range(5):
        start = est - d_sweep * sdir
        end = est + end_extra * sdir
        above = cz + cup_h + 0.04
        rb.api.open_gripper()
        rb.lift_to(travel_z)
        rb.move([start[0], start[1], travel_z], yaw=yaw)
        if not measured and start[0] > counter["front_x"] + 0.03:
            # touch the counter beside the cup to know its height exactly
            tgt = cz - 0.02
            rb.move([start[0], start[1], cz + 0.02], speed=0.1)
            rb.move([start[0], start[1], tgt], speed=0.03)
            p, _, _ = rb.ee()
            if p[2] > tgt + 0.005 and abs(p[2] - cz) < 0.03:
                cz = p[2]
            measured = True
            rb.log("counter touch z=%.4f (perceived %.4f)" % (p[2], counter["top_z"]))
        gz = cz + 0.02
        rb.move([start[0], start[1], gz], speed=0.08)
        p, _, _ = rb.ee()
        if p[2] > gz + 0.012:
            rb.log("blocked at slide start z=%.4f" % p[2])
        rb.move([end[0], end[1], gz], speed=0.04)
        w = rb.api.close_gripper()
        rb.log("try %d end %s w=%.4f" % (attempt, r3(end), w))
        if w > 0.04:
            # lift a little and check we really hold it
            rb.move([end[0], end[1], gz + 0.04], speed=0.06)
            _, _, w2 = rb.ee()
            c1 = rb.cup(n=3)
            rose = c1["pos"][2] - perc[2]
            rb.log("lift test w=%.4f rose=%.4f" % (w2, rose))
            if w2 > 0.03 and rose > 0.015:
                return cz, gz
            rb.move([end[0], end[1], gz + 0.002], speed=0.04)
            rb.api.open_gripper()
        else:
            rb.api.open_gripper()
        p, _, _ = rb.ee()
        rb.move([p[0], p[1], max(above, gz + 0.06)], speed=0.1)
        rb.lift_to(travel_z)
        cn = rb.cup()
        delta = cn["pos"][:2] - perc[:2]
        perc = cn["pos"]
        du, dv = float(delta @ u), float(delta @ sdir)
        rb.log("cup now %s moved du=%.4f dv=%.4f" % (r3(perc), du, dv))
        if np.linalg.norm(delta) > 0.008 and dv > 0.01:
            # pushed ahead by one finger: it sits in front of that finger tip
            rel = perc[:2] - end
            s = 1.0 if (du if abs(du) > 0.003 else rel @ u) >= 0 else -1.0
            est = end + 0.042 * sdir + s * 0.043 * u
            end_extra = 0.0
        elif np.linalg.norm(delta) > 0.006:
            est = est + delta
            end_extra = 0.0
        else:
            # untouched: search further along the slide, then sideways
            tried_u += 1
            if tried_u == 1:
                end_extra = 0.035
            elif tried_u == 2:
                end_extra = 0.0
                est = est + 0.03 * u
            else:
                est = est - 0.06 * u
    return None


# ======================================================================  main
def run(api):
    rb = Robot(api)
    counter = rb.counter()
    objs = rb.objects()
    rb.log("counter %s objs %s" % (r3([counter["top_z"], counter["front_x"]]),
                                   [(o["name"], o["location"], r3(o["pos"]), r3(o["size"]))
                                    for o in objs]))
    top = counter["top_z"]
    for o in objs:
        if o["location"] == "counter":
            top = max(top, o["pos"][2] + o["size"][2] / 2.0)
    approach_z = counter["top_z"] + 0.06
    travel_z = max(top + 0.11, counter["top_z"] + 0.17)   # cup hangs ~4 cm below the tips

    rb.api.open_gripper()
    rb.lift_to(approach_z)

    # 1) open the drawer
    d = rb.drawer()
    if d["opening"] < TARGET_OPENING - 0.015:
        d = move_drawer(rb, counter, TARGET_OPENING, approach_z, d)
    rb.lift_to(travel_z)

    # 2) pick up the cup
    res = pick_cup(rb, counter, objs, travel_z)
    if res is None:
        rb.log("failed to pick the cup")
        rb.lift_to(travel_z)
        return
    cz, gz = res
    hold = gz - cz                       # fingertip height above the cup bottom
    p, _, _ = rb.ee()
    rb.move([p[0], p[1], travel_z], speed=0.1)

    # 3) place it in the drawer
    d = rb.drawer()
    objs = rb.objects()
    cup_r = 0.031
    px, py = choose_place(rb, d, counter, objs, cup_r)
    rb.move([px, py, travel_z], yaw=0.0, speed=0.12)
    rb.move([px, py, d["floor_z"] + hold + 0.04], speed=0.1)
    rb.move([px, py, d["floor_z"] + hold - 0.012], speed=0.03)   # until it touches
    p, _, w = rb.ee()
    rb.log("placed tips z=%.4f w=%.4f" % (p[2], w))
    rb.api.open_gripper()
    rb.api.wait(0.2)
    rb.move([px, py, approach_z], speed=0.08)

    # 4) close the drawer
    d = move_drawer(rb, counter, 0.0, approach_z)
    rb.log("final drawer %.4f" % d["opening"])
