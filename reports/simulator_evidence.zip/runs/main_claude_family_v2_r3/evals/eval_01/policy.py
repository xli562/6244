"""Robot program for: "Place the cup in the drawer." See TASK.md and API.md."""
import math

import numpy as np

# ---------------------------------------------------------------- constants
GRASP_OFF = 0.030        # fingertip height above the cup bottom when holding it
FINGER_LEN = 0.058       # fingertip -> bottom of the hand body
HAND_HALF_W = 0.105      # hand half-extent along the finger-closing axis
HAND_HALF_D = 0.035      # hand half-extent perpendicular to it
CUP_HANDLE_EXT = 0.028   # how far the cup handle sticks out of the body
BAR_HALF = 0.008         # half thickness of the drawer handle bar
FINGER_HALF_T = 0.010    # half thickness of a finger (perpendicular to closing)
MAX_OPEN = 0.42


def _v(p):
    return np.array([float(p[0]), float(p[1]), float(p[2])])


def _wrap(a):
    return (a + math.pi) % (2.0 * math.pi) - math.pi


class Robot:
    def __init__(self, api):
        self.api = api

    # ------------------------------------------------------------ basics
    def log(self, msg):
        try:
            self.api.log(str(msg))
        except Exception:
            pass

    def ee(self):
        e = self.api.get_ee()
        return _v(e["pos"]), float(e["yaw"]), float(e["gripper_width"])

    def move(self, p, yaw=None, speed=0.15):
        p = [float(p[0]), float(p[1]), float(p[2])]
        if yaw is None:
            r = self.api.move_to(p, speed=speed)
        else:
            r = self.api.move_to(p, yaw=float(yaw), speed=speed)
        return r

    def open(self):
        return float(self.api.open_gripper())

    def close(self):
        return float(self.api.close_gripper())

    # ------------------------------------------------------------ perception
    def cup(self, n=5):
        ps, cs, ss = [], 0.0, 0.0
        r = h = 0.0
        for _ in range(n):
            c = self.api.get_cup()
            ps.append(_v(c["pos"]))
            cs += math.cos(c["yaw"])
            ss += math.sin(c["yaw"])
            r += float(c["radius"])
            h += float(c["height"])
        ps = np.array(ps)
        return {"pos": ps.mean(axis=0), "spread": float(ps.std(axis=0).max()),
                "yaw": math.atan2(ss, cs), "radius": r / n, "height": h / n}

    def handle(self, n=5):
        ps = np.array([_v(self.api.get_handle()["pos"]) for _ in range(n)])
        return ps.mean(axis=0)

    def drawer(self, n=5):
        acc = None
        for _ in range(n):
            d = self.api.get_drawer()
            vals = np.array([float(d["opening"])] + [float(x) for x in d["interior_center"]]
                            + [float(x) for x in d["interior_size"]] + [float(d["floor_z"])])
            acc = vals if acc is None else acc + vals
        acc = acc / n
        return {"opening": acc[0], "center": acc[1:4], "size": acc[4:7], "floor_z": acc[7]}

    def counter(self, n=5):
        t = f = 0.0
        for _ in range(n):
            c = self.api.get_counter()
            t += float(c["top_z"])
            f += float(c["front_x"])
        return {"top_z": t / n, "front_x": f / n}

    def objects(self):
        out = []
        try:
            for o in self.api.get_objects():
                out.append({"name": o.get("name", "?"), "pos": _v(o["pos"]),
                            "size": _v(o["size"]), "location": o.get("location", "counter")})
        except Exception:
            pass
        return out

    # ------------------------------------------------------------ contact
    def descend_until_contact(self, x, y, z_start, z_min, step=0.004, speed=0.04):
        """Step down from z_start towards z_min; return the fingertip z of first contact
        (or None if nothing was touched)."""
        self.move([x, y, z_start], speed=0.08)
        ez = self.ee()[0][2]
        if ez > z_start + 0.006:
            return ez
        z = z_start
        while z > z_min + 1e-6:
            z = max(z - step, z_min)
            self.move([x, y, z], speed=speed)
            ez = self.ee()[0][2]
            if ez > z + 0.003:
                return ez
        return None


# -------------------------------------------------------------------- planning
def _rect_gap(a, b):
    """a, b = (xlo, xhi, ylo, yhi). Positive: separation distance; negative: overlap."""
    gx = max(b[0] - a[1], a[0] - b[1])
    gy = max(b[2] - a[3], a[2] - b[3])
    if gx >= 0 and gy >= 0:
        return math.hypot(gx, gy)
    return max(gx, gy)


def choose_spot(drw, objs, front_x, r, ext_minus, ext_plus, max_extra, margin):
    """Choose a spot (u, v) in the drawer frame (relative to the interior centre).
    Returns (u, v, delta) where delta is the extra pull needed, or None."""
    cx, cy = drw["center"][0], drw["center"][1]
    sx, sy = drw["size"][0], drw["size"][1]
    floor = drw["floor_z"]
    dobjs = [o for o in objs if o["location"] == "drawer"]
    best, best_s = None, -1e9
    for u in np.arange(-sx / 2 + 0.04, sx / 2 - 0.03, 0.01):
        if u - ext_minus < -sx / 2 + 0.012 or u + ext_plus > sx / 2 - 0.012:
            continue
        if u - HAND_HALF_D < -sx / 2 + 0.012:
            continue
        xw = cx + u
        delta = max(0.0, xw - (front_x - 0.085))
        if delta > max_extra:
            continue
        for v in np.arange(-sy / 2 + r + 0.02, sy / 2 - r - 0.02 + 1e-9, 0.01):
            cup_rect = (u - ext_minus, u + ext_plus, v - r - 0.012, v + r + 0.012)
            hand_rect = (u - HAND_HALF_D, u + HAND_HALF_D, v - HAND_HALF_W, v + HAND_HALF_W)
            clr = 0.10
            for o in dobjs:
                ox, oy = o["pos"][0] - cx, o["pos"][1] - cy
                hx, hy = o["size"][0] / 2, o["size"][1] / 2
                orect = (ox - hx, ox + hx, oy - hy, oy + hy)
                clr = min(clr, _rect_gap(cup_rect, orect))
                top = o["pos"][2] + o["size"][2] / 2
                if top > floor + GRASP_OFF + FINGER_LEN - 0.015:
                    clr = min(clr, _rect_gap(hand_rect, orect) + 0.01)
            if clr < margin:
                continue
            wall = sy / 2 - abs(v) - HAND_HALF_W
            s = min(clr, 0.07) + 0.5 * min(wall, 0.02) - 0.02 * abs(v) - 0.05 * delta
            if s > best_s:
                best_s, best = s, (float(u), float(v), float(delta))
    return best


# -------------------------------------------------------------------- skills
def grasp_handle(rb, hx, hy, hz, z_high):
    """Pinch the vertical handle bar (fingers closing along y). Returns ee pos or None."""
    for dx in (0.0, -0.007, 0.007):
        rb.open()
        rb.move([hx + dx, hy, z_high], yaw=0.0)
        rb.move([hx + dx, hy, hz + 0.06], yaw=0.0, speed=0.12)
        res = rb.move([hx + dx, hy, hz], speed=0.06)
        w = rb.close()
        rb.log("handle grasp dx=%.3f reached=%s w=%.4f" % (dx, res.get("reached"), w))
        if 0.004 < w < 0.045:
            return rb.ee()[0]
        rb.open()
        rb.move([hx + dx, hy, z_high], speed=0.12)
    return None


def run(api):
    rb = Robot(api)
    rb.open()

    ctr = rb.counter()
    drw0 = rb.drawer()
    h0 = rb.handle()
    objs = rb.objects()
    cup = rb.cup()
    top_z, front_x = ctr["top_z"], ctr["front_x"]
    rb.log("counter %s" % ctr)
    rb.log("drawer %s" % {k: np.round(v, 4).tolist() for k, v in drw0.items()})
    rb.log("handle %s" % np.round(h0, 4).tolist())
    rb.log("cup pos=%s yaw=%.3f r=%.4f h=%.4f spread=%.4f" % (
        np.round(cup["pos"], 4).tolist(), cup["yaw"], cup["radius"], cup["height"], cup["spread"]))
    for o in objs:
        rb.log("obj %s %s pos=%s size=%s" % (o["name"], o["location"],
                                             np.round(o["pos"], 3).tolist(), np.round(o["size"], 3).tolist()))

    r = cup["radius"] if 0.02 < cup["radius"] < 0.04 else 0.031
    ch = cup["height"] if 0.04 < cup["height"] < 0.08 else 0.058

    # safe travelling height for the fingertips (cup hangs GRASP_OFF below them)
    max_top = top_z
    for o in objs:
        if o["location"] == "counter":
            max_top = max(max_top, o["pos"][2] + o["size"][2] / 2)
    safe_z = min(max(top_z + ch + 0.09, max_top + GRASP_OFF + 0.05), 0.70)
    rb.log("safe_z %.3f" % safe_z)

    p, _, _ = rb.ee()
    rb.move([p[0], p[1], max(p[2], safe_z)])

    # grasp yaw for the cup: fingers perpendicular to the cup handle
    g = ((cup["yaw"] + math.pi / 2) % math.pi) - math.pi / 2
    handle_minus_x = math.cos(_wrap(cup["yaw"] - g)) > 0   # after rotating gripper to yaw 0
    ext_minus = r + (CUP_HANDLE_EXT if handle_minus_x else 0.0)
    ext_plus = r + (0.0 if handle_minus_x else CUP_HANDLE_EXT)
    rb.log("grasp yaw %.3f handle_minus_x %s" % (g, handle_minus_x))

    # ------------------------------------------------ plan and open the drawer
    spot = None
    for m in (0.025, 0.015, 0.005, -0.01):
        spot = choose_spot(drw0, objs, front_x, r, ext_minus, ext_plus,
                           MAX_OPEN - drw0["opening"], m)
        if spot is not None:
            break
    if spot is None:
        spot = (-drw0["size"][0] / 2 + 0.09, 0.0, max(0.0, drw0["center"][0] - drw0["size"][0] / 2 + 0.09 - (front_x - 0.085)))
    rb.log("planned spot u=%.3f v=%.3f delta=%.3f" % spot)
    delta = spot[2]

    bar = None
    z_high = max(top_z + 0.07, h0[2] + 0.12)
    if delta > 0.01:
        delta = max(delta, 0.05)
        pulled = 0.0
        for attempt in range(3):
            hh = rb.handle()
            rb.move([hh[0], hh[1], max(safe_z, z_high)], yaw=0.0)
            gp = grasp_handle(rb, hh[0], hh[1], hh[2], z_high)
            if gp is None:
                rb.log("handle grasp failed")
                continue
            remaining = delta - pulled
            o_before = rb.drawer(3)["opening"]
            rb.move([gp[0] - remaining, gp[1], gp[2]], speed=0.08)
            p, _, w = rb.ee()
            rb.log("after pull ee=%s w=%.4f" % (np.round(p, 4).tolist(), w))
            o_after = rb.drawer(3)["opening"]
            pulled += max(0.0, o_after - o_before)
            rb.open()
            bar = p.copy()
            rb.move([p[0], p[1], z_high], speed=0.12)
            rb.log("opening %.3f -> %.3f (pulled %.3f of %.3f)" % (o_before, o_after, pulled, delta))
            if pulled > delta - 0.03:
                break
    drw = rb.drawer()
    objs = rb.objects()
    rb.log("drawer now %s" % {k: np.round(v, 4).tolist() for k, v in drw.items()})
    if bar is None:
        bar = rb.handle()

    # re-plan the spot inside the now exposed area
    spot2 = None
    for m in (0.025, 0.015, 0.005, -0.01):
        spot2 = choose_spot(drw, objs, front_x, r, ext_minus, ext_plus, 0.0, m)
        if spot2 is not None:
            break
    if spot2 is None:
        spot2 = spot
    place_x = drw["center"][0] + spot2[0]
    place_y = drw["center"][1] + spot2[1]
    place_x = min(place_x, front_x - 0.06)
    floor = drw["floor_z"]
    rb.log("place spot %.3f %.3f floor %.3f" % (place_x, place_y, floor))

    # ------------------------------------------------ pick the cup
    held = False
    shifts = [0.0, 0.012, -0.012, 0.0, 0.0]
    for attempt in range(len(shifts)):
        cup = rb.cup()
        g = ((cup["yaw"] + math.pi / 2) % math.pi) - math.pi / 2
        ax = np.array([-math.sin(g), math.cos(g)])
        cx = cup["pos"][0] + shifts[attempt] * ax[0]
        cy = cup["pos"][1] + shifts[attempt] * ax[1]
        cz_bot = top_z
        rb.open()
        rb.move([cx, cy, safe_z], yaw=g)
        rb.move([cx, cy, cz_bot + ch + 0.03], speed=0.12)
        zc = rb.descend_until_contact(cx, cy, cz_bot + 0.035, cz_bot - 0.015)
        rb.log("cup attempt %d at %.3f %.3f contact=%s" % (attempt, cx, cy, zc))
        if zc is not None and zc > cz_bot + 0.03:
            rb.log("landed on the cup rim, retrying")
            rb.move([cx, cy, safe_z], speed=0.12)
            continue
        if zc is None:
            zc = rb.ee()[0][2]
        rb.move([cx, cy, zc + GRASP_OFF], speed=0.05)
        w = rb.close()
        rb.log("cup close width %.4f" % w)
        if 0.035 < w < 0.075:
            rb.move([cx, cy, zc + GRASP_OFF + 0.03], speed=0.08)
            rb.move([cx, cy, safe_z], speed=0.12)
            w = rb.ee()[2]
            if w > 0.03:
                held = True
                break
            rb.log("lost the cup while lifting (w=%.4f)" % w)
        rb.open()
        rb.move([cx, cy, safe_z], speed=0.12)
    if not held:
        rb.log("could not grasp the cup")

    # ------------------------------------------------ place the cup
    if held:
        p, _, _ = rb.ee()
        rb.move([p[0], p[1], safe_z], yaw=0.0, speed=0.10)
        rb.move([place_x, place_y, safe_z], yaw=0.0, speed=0.15)
        rb.move([place_x, place_y, floor + GRASP_OFF + 0.03], speed=0.12)
        zc = rb.descend_until_contact(place_x, place_y, floor + GRASP_OFF + 0.022,
                                      floor + GRASP_OFF - 0.018, step=0.003, speed=0.03)
        rb.log("place contact %s" % zc)
        rb.open()
        api.wait(0.3)
        p, _, _ = rb.ee()
        rb.move([p[0], p[1], max(top_z + 0.08, floor + GRASP_OFF + ch + 0.10)], speed=0.08)
        c = rb.cup(3)
        rb.log("cup after place %s" % np.round(c["pos"], 4).tolist())

    # ------------------------------------------------ close the drawer
    for attempt in range(3):
        d = rb.drawer(3)
        if d["opening"] < 0.006 and attempt > 0:
            break
        bx = bar[0] - BAR_HALF - FINGER_HALF_T - 0.017
        rb.move([bx, bar[1], z_high], yaw=0.0)
        rb.close()
        res = rb.move([bx, bar[1], bar[2]], speed=0.08)
        if rb.ee()[0][2] > bar[2] + 0.015:
            rb.log("blocked while descending in front of the bar; backing off")
            bx -= 0.015
            rb.move([bx, bar[1], z_high], speed=0.1)
            rb.move([bx, bar[1], bar[2]], speed=0.08)
        closed_bar_x = 0.5 * ((h0[0] + drw0["opening"]) + (bar[0] + d["opening"]))
        target = closed_bar_x - BAR_HALF - FINGER_HALF_T + 0.03 + 0.01 * attempt
        res = rb.move([target, bar[1], bar[2]], speed=0.08)
        p = rb.ee()[0]
        d2 = rb.drawer(3)
        rb.log("push %d: target %.3f ee_x %.3f opening %.4f" % (attempt, target, p[0], d2["opening"]))
        # bar position after pushing (finger contact face)
        bar = np.array([p[0] + BAR_HALF + FINGER_HALF_T, bar[1], bar[2]])
        rb.move([p[0] - 0.04, p[1], p[2]], speed=0.1)
        rb.move([p[0] - 0.04, p[1], z_high], speed=0.12)
        if d2["opening"] < 0.006:
            break
    rb.open()
    rb.log("done")
