"""Robot program for: "Place the cup in the drawer." See TASK.md and API.md."""
import math

import numpy as np

# ---------------------------------------------------------------- constants
GRASP_OFF = 0.032        # reported-fingertip height above the cup bottom (finger bottoms are ~1.7 cm lower)
FINGER_LEN = 0.042       # reported fingertip -> bottom of the hand body (conservative)
HAND_HALF_W = 0.105      # hand half-extent along the finger-closing axis
HAND_HALF_D = 0.035      # hand half-extent perpendicular to it
CUP_HANDLE_EXT = 0.028   # how far the cup handle sticks out of the body
MAX_OPEN = 0.42
BAR_DX = -0.004          # grasp the drawer bar slightly on the robot side (keeps hand off the counter)


def _v(p):
    return np.array([float(p[0]), float(p[1]), float(p[2])])


def _wrap(a):
    return (a + math.pi) % (2.0 * math.pi) - math.pi


class Robot:
    def __init__(self, api):
        self.api = api

    def log(self, msg):
        try:
            self.api.log(str(msg))
        except Exception:
            pass

    def ee(self):
        e = self.api.get_ee()
        return _v(e["pos"]), float(e["yaw"]), float(e["gripper_width"])

    def move(self, p, yaw=None, speed=0.15):
        p = [float(p[0]), float(p[1]), float(p[2])]
        if yaw is None:
            r = self.api.move_to(p, speed=speed)
        else:
            r = self.api.move_to(p, yaw=float(yaw), speed=speed)
        if not isinstance(r, dict):
            r = {"reached": True, "error": 0.0}
        return r

    def move_precise(self, p, yaw=None, speed=0.06, max_corr=0.02, block_up=0.015):
        """Move, then compensate the steady-state tracking error (the fingertip reading is
        exact). No correction is applied when the fingers seem blocked from below
        (ee above the target by more than block_up)."""
        p = _v(p)
        self.move(p, yaw=yaw, speed=speed)
        cmd = p.copy()
        for _ in range(2):
            e = p - self.ee()[0]
            if np.linalg.norm(e) < 0.003:
                break
            if -e[2] > block_up:      # stuck above the target: contact, do not push harder
                break
            cmd = cmd + e
            dev = cmd - p
            n = np.linalg.norm(dev)
            if n > max_corr:
                cmd = p + dev * (max_corr / n)
            self.move(cmd, speed=0.04)
        return self.ee()[0]

    def open(self):
        return float(self.api.open_gripper())

    def close(self):
        return float(self.api.close_gripper())

    # ------------------------------------------------------------ perception (averaged)
    def cup(self, n=3):
        ps, cs, ss = [], 0.0, 0.0
        r = h = 0.0
        for _ in range(n):
            c = self.api.get_cup()
            ps.append(_v(c["pos"]))
            cs += math.cos(c["yaw"])
            ss += math.sin(c["yaw"])
            r += float(c["radius"])
            h += float(c["height"])
        ps = np.array(ps)
        return {"pos": ps.mean(axis=0), "yaw": math.atan2(ss, cs), "radius": r / n, "height": h / n}

    def handle(self, n=3):
        ps = np.array([_v(self.api.get_handle()["pos"]) for _ in range(n)])
        return ps.mean(axis=0)

    def drawer(self, n=3):
        acc = None
        for _ in range(n):
            d = self.api.get_drawer()
            vals = np.array([float(d["opening"])] + [float(x) for x in d["interior_center"]]
                            + [float(x) for x in d["interior_size"]] + [float(d["floor_z"])])
            acc = vals if acc is None else acc + vals
        acc = acc / n
        return {"opening": acc[0], "center": acc[1:4], "size": acc[4:7], "floor_z": acc[7]}

    def counter(self, n=3):
        t = f = 0.0
        for _ in range(n):
            c = self.api.get_counter()
            t += float(c["top_z"])
            f += float(c["front_x"])
        return {"top_z": t / n, "front_x": f / n}

    def objects(self):
        out = []
        try:
            for o in self.api.get_objects():
                out.append({"name": o.get("name", "?"), "pos": _v(o["pos"]),
                            "size": _v(o["size"]), "location": o.get("location", "counter")})
        except Exception:
            pass
        return out


# -------------------------------------------------------------------- planning
def _rect_gap(a, b):
    """a, b = (xlo, xhi, ylo, yhi). Positive: separation distance; negative: overlap."""
    gx = max(b[0] - a[1], a[0] - b[1])
    gy = max(b[2] - a[3], a[2] - b[3])
    if gx >= 0 and gy >= 0:
        return math.hypot(gx, gy)
    return max(gx, gy)


def choose_spot(drw, objs, front_x, r, ext_minus, ext_plus, max_extra, margin):
    """Choose a spot (u, v) in the drawer frame (relative to the interior centre).
    Returns (u, v, delta) where delta is the extra pull needed, or None."""
    cx = drw["center"][0]
    cy = drw["center"][1]
    sx, sy = drw["size"][0], drw["size"][1]
    floor = drw["floor_z"]
    dobjs = [o for o in objs if o["location"] == "drawer"]
    best, best_s = None, -1e9
    for u in np.arange(-sx / 2 + 0.04, sx / 2 - 0.03, 0.01):
        if u - ext_minus < -sx / 2 + 0.015 or u + ext_plus > sx / 2 - 0.015:
            continue
        if u - HAND_HALF_D < -sx / 2 + 0.03:
            continue
        xw = cx + u
        delta = max(0.0, xw - (front_x - 0.09))
        if delta > max_extra:
            continue
        # world x after pulling, and the middle of the region reachable then
        xw_after = xw - delta
        inner_after = cx - delta - sx / 2
        x_mid = 0.5 * ((inner_after + 0.075) + (front_x - 0.07))
        for v in np.arange(-sy / 2 + r + 0.02, sy / 2 - r - 0.02 + 1e-9, 0.01):
            cup_rect = (u - ext_minus, u + ext_plus, v - r - 0.012, v + r + 0.012)
            hand_rect = (u - HAND_HALF_D, u + HAND_HALF_D, v - HAND_HALF_W, v + HAND_HALF_W)
            clr = 0.10
            for o in dobjs:
                ox, oy = o["pos"][0] - cx, o["pos"][1] - cy
                hx, hy = o["size"][0] / 2, o["size"][1] / 2
                orect = (ox - hx, ox + hx, oy - hy, oy + hy)
                clr = min(clr, _rect_gap(cup_rect, orect))
                top = o["pos"][2] + o["size"][2] / 2
                if top > floor + GRASP_OFF + FINGER_LEN - 0.02:
                    clr = min(clr, _rect_gap(hand_rect, orect) + 0.01)
            if clr < margin:
                continue
            wall = sy / 2 - abs(v) - HAND_HALF_W
            s = (min(clr, 0.07) + 0.5 * min(wall, 0.02) - 0.02 * abs(v)
                 - 0.05 * delta - 0.08 * abs(xw_after - x_mid))
            if s > best_s:
                best_s, best = s, (float(u), float(v), float(delta))
    return best


# -------------------------------------------------------------------- skills
def grasp_bar(rb, hx, hy, hz, z_high):
    """Pinch the vertical drawer handle bar (fingers closing along y). Returns ee pos or None."""
    for dx in (0.0, -0.008, 0.008):
        x = hx + BAR_DX + dx
        rb.open()
        rb.move([x, hy, z_high], yaw=0.0)
        rb.move_precise([x, hy, hz], yaw=0.0, speed=0.08)
        w = rb.close()
        rb.log("bar grasp dx=%.3f w=%.4f" % (dx, w))
        if 0.004 < w < 0.05:
            return rb.ee()[0]
        rb.open()
        rb.move([x, hy, z_high], speed=0.12)
    return None


def run(api):
    rb = Robot(api)
    rb.open()

    ctr = rb.counter()
    drw0 = rb.drawer()
    h0 = rb.handle()
    objs = rb.objects()
    cup = rb.cup()
    top_z, front_x = ctr["top_z"], ctr["front_x"]
    rb.log("ctr %.4f %.4f | drw op %.4f c %s fl %.4f | h %s | cup %s yaw %.3f" % (
        top_z, front_x, drw0["opening"], np.round(drw0["center"], 4).tolist(), drw0["floor_z"],
        np.round(h0, 4).tolist(), np.round(cup["pos"], 4).tolist(), cup["yaw"]))

    r = cup["radius"] if 0.02 < cup["radius"] < 0.045 else 0.031
    ch = cup["height"] if 0.035 < cup["height"] < 0.09 else 0.058

    # safe travelling height for the fingertips (cup hangs below them)
    max_top = top_z
    for o in objs:
        if o["location"] == "counter":
            max_top = max(max_top, o["pos"][2] + o["size"][2] / 2)
    safe_z = min(max(top_z + ch + 0.08, max_top + GRASP_OFF + 0.05), 0.65)
    z_high = max(top_z + 0.07, h0[2] + 0.12)

    p, _, _ = rb.ee()
    rb.move([p[0], p[1], max(p[2], safe_z)])

    # grasp yaw for the cup: fingers perpendicular to the cup handle
    g = ((cup["yaw"] + math.pi / 2) % math.pi) - math.pi / 2
    handle_minus_x = math.cos(_wrap(cup["yaw"] - g)) > 0   # after rotating gripper to yaw 0
    ext_minus = r + (CUP_HANDLE_EXT if handle_minus_x else 0.0)
    ext_plus = r + (0.0 if handle_minus_x else CUP_HANDLE_EXT)

    # ------------------------------------------------ plan and open the drawer
    spot = None
    for m in (0.025, 0.015, 0.005, -0.01):
        spot = choose_spot(drw0, objs, front_x, r, ext_minus, ext_plus,
                           MAX_OPEN - drw0["opening"], m)
        if spot is not None:
            break
    if spot is None:
        u = -drw0["size"][0] / 2 + 0.10
        spot = (u, 0.0, max(0.0, drw0["center"][0] + u - (front_x - 0.09)))
    rb.log("plan u=%.3f v=%.3f delta=%.3f g=%.3f hmx=%s safe_z=%.3f" % (
        spot[0], spot[1], spot[2], g, handle_minus_x, safe_z))
    delta = spot[2]

    bar = None
    if delta > 0.01:
        delta = max(delta, 0.04)
        pulled = 0.0
        for attempt in range(3):
            hh = rb.handle()
            rb.move([hh[0], hh[1], max(safe_z, z_high)], yaw=0.0)
            gp = grasp_bar(rb, hh[0], hh[1], hh[2], z_high)
            if gp is None:
                continue
            o_before = rb.drawer()["opening"]
            rb.move([gp[0] - (delta - pulled), gp[1], gp[2]], speed=0.08)
            p, _, w = rb.ee()
            o_after = rb.drawer()["opening"]
            pulled += max(0.0, o_after - o_before)
            rb.open()
            bar = p.copy()
            rb.move([p[0], p[1], z_high], speed=0.12)
            rb.log("pull: op %.3f -> %.3f, pulled %.3f/%.3f, ee %s" % (
                o_before, o_after, pulled, delta, np.round(p, 4).tolist()))
            if pulled > delta - 0.03:
                break
    drw = rb.drawer()
    objs = rb.objects()
    if bar is None:
        bar = rb.handle()
        bar[0] += BAR_DX

    # re-plan the spot inside the now exposed area
    spot2 = None
    for m in (0.025, 0.015, 0.005, -0.01):
        spot2 = choose_spot(drw, objs, front_x, r, ext_minus, ext_plus, 0.0, m)
        if spot2 is not None:
            break
    if spot2 is None:
        spot2 = spot
    place_x = min(drw["center"][0] + spot2[0], front_x - 0.065)
    place_y = drw["center"][1] + spot2[1]
    floor = drw["floor_z"]
    rb.log("drw op %.4f c %s fl %.4f | place %.3f %.3f" % (
        drw["opening"], np.round(drw["center"], 4).tolist(), floor, place_x, place_y))

    # ------------------------------------------------ pick the cup
    held = False
    grasp_off = GRASP_OFF
    rim_shifts = [0.012, -0.012]
    n_rim = 0
    shift = 0.0
    extra = 0.0
    for attempt in range(5):
        cup = rb.cup()
        g = ((cup["yaw"] + math.pi / 2) % math.pi) - math.pi / 2
        ax = np.array([-math.sin(g), math.cos(g)])
        cx = cup["pos"][0] + shift * ax[0]
        cy = cup["pos"][1] + shift * ax[1]
        shift = 0.0
        # cup bottom: counter top, cross-checked with the cup's own height reading
        bottom = 0.7 * top_z + 0.3 * (cup["pos"][2] - ch / 2)
        if abs((cup["pos"][2] - ch / 2) - top_z) > 0.02:
            bottom = cup["pos"][2] - ch / 2
        zg = bottom + GRASP_OFF + extra
        rb.open()
        rb.move([cx, cy, safe_z], yaw=g)
        rb.move([cx, cy, bottom + ch + 0.025], speed=0.12)
        ez = rb.move_precise([cx, cy, zg], speed=0.06)[2]
        if ez > zg + 0.018:
            rb.log("blocked at %.3f (target %.3f): on the rim, retry" % (ez, zg))
            rb.move([cx, cy, safe_z], speed=0.12)
            if n_rim < len(rim_shifts):
                shift = rim_shifts[n_rim]
                n_rim += 1
            continue
        w = rb.close()
        rb.log("cup %d at %.3f %.3f z %.3f (ee z %.3f) w=%.4f" % (attempt, cx, cy, zg, ez, w))
        if 0.048 < w < 0.068:
            grasp_off = ez - bottom
            rb.move([cx, cy, ez + 0.03], speed=0.08)
            rb.move([cx, cy, safe_z], speed=0.12)
            w = rb.ee()[2]
            if w > 0.03:
                held = True
                break
            rb.log("lost the cup while lifting (w=%.4f)" % w)
        elif w >= 0.068:
            extra = min(extra + 0.008, 0.016)   # fingers impeded (e.g. dragging on the counter)
        rb.open()
        rb.move([cx, cy, safe_z], speed=0.12)
    if not held:
        rb.log("could not grasp the cup")

    # ------------------------------------------------ place the cup
    if held:
        p, _, _ = rb.ee()
        rb.move([p[0], p[1], safe_z], yaw=0.0, speed=0.10)
        rb.move([place_x, place_y, safe_z], yaw=0.0, speed=0.15)
        # estimate the grasp offset again from the cup reading while it is held
        c = rb.cup()
        p, _, _ = rb.ee()
        meas = p[2] - (c["pos"][2] - ch / 2)
        if abs(meas - grasp_off) < 0.02:
            grasp_off = 0.5 * (grasp_off + meas)
        rb.move([place_x, place_y, floor + grasp_off + 0.04], speed=0.12)
        p = rb.move_precise([place_x, place_y, floor + grasp_off + 0.007], speed=0.04,
                            max_corr=0.015, block_up=0.005)
        rb.log("release at ee %s (grasp_off %.4f meas %.4f)" % (np.round(p, 4).tolist(), grasp_off, meas))
        rb.open()
        api.wait(0.3)
        rb.move([p[0], p[1], max(z_high, floor + grasp_off + ch + 0.12)], speed=0.08)

    # ------------------------------------------------ close the drawer
    for attempt in range(3):
        d = rb.drawer()
        if attempt > 0 and d["opening"] < 0.005:
            break
        gp = grasp_bar(rb, bar[0] - BAR_DX, bar[1], bar[2], z_high)
        if gp is None:
            hh = rb.handle()
            gp = grasp_bar(rb, hh[0], hh[1], hh[2], z_high)
        if gp is None:
            rb.log("cannot grasp bar to close")
            break
        target = gp[0] + d["opening"] + 0.015 + 0.01 * attempt
        rb.move([target, gp[1], gp[2]], speed=0.08)
        api.wait(0.2)
        p = rb.ee()[0]
        d2 = rb.drawer()
        rb.log("push %d: target %.3f ee_x %.3f opening %.4f" % (attempt, target, p[0], d2["opening"]))
        rb.open()
        bar = np.array([p[0], p[1], p[2]])
        rb.move([p[0], p[1], z_high], speed=0.10)
        if d2["opening"] < 0.005:
            break
    p = rb.ee()[0]
    rb.move([p[0] - 0.08, p[1], p[2]], speed=0.12)
    rb.log("done")
