"""Robot program for: "Place the cup in the drawer." See TASK.md and API.md."""
import math

import numpy as np

# ---------------------------------------------------------------- constants
HAND_HALF_LEN = 0.11     # half length of the hand along the finger-closing axis
HAND_HALF_DEPTH = 0.035  # half thickness of the hand across the closing axis
FINGER_REACH = 0.055     # finger outer extent from centre when open (0.04 + finger)
PALM_ABOVE_TIP = 0.06    # palm bottom above the fingertips
CUP_HANDLE_LEN = 0.03    # how far the cup handle sticks out of the body

D_MIN = 0.235            # smallest drawer opening we accept for placing
D_TARGET = 0.26          # opening we pull the drawer to
D_MAX = 0.55             # wider openings only give more room; never push first


def wrap(a):
    return (a + math.pi) % (2 * math.pi) - math.pi


def wrap_half(a):
    """Wrap to [-pi/2, pi/2) (parallel gripper is symmetric under pi)."""
    return (a + math.pi / 2) % math.pi - math.pi / 2


def rect_gap(a, b):
    """Gap between two axis-aligned rects (xmin, xmax, ymin, ymax); <0 = overlap."""
    dx = max(b[0] - a[1], a[0] - b[1])
    dy = max(b[2] - a[3], a[2] - b[3])
    if dx < 0 and dy < 0:
        return max(dx, dy)
    return math.hypot(max(dx, 0.0), max(dy, 0.0))


def point_rect_dist(p, r):
    dx = max(r[0] - p[0], 0.0, p[0] - r[1])
    dy = max(r[2] - p[1], 0.0, p[1] - r[3])
    if dx == 0.0 and dy == 0.0:
        return -min(p[0] - r[0], r[1] - p[0], p[1] - r[2], r[3] - p[1])
    return math.hypot(dx, dy)


class Robot:
    def __init__(self, api):
        self.api = api

    def log(self, msg):
        try:
            self.api.log(str(msg))
        except Exception:
            pass

    def ee(self):
        return self.api.get_ee()

    def move(self, pos, yaw=None, speed=0.15, tag=""):
        pos = [float(pos[0]), float(pos[1]), float(pos[2])]
        if yaw is not None:
            yaw = float(yaw)
        res = self.api.move_to(pos, yaw=yaw, speed=speed)
        if not res.get("reached", True):
            e = self.ee()
            self.log("move %s NOT reached: target=%s err=%.4f ee=%s" % (
                tag, np.round(pos, 3).tolist(), res.get("error", -1),
                np.round(e["pos"], 3).tolist()))
        return res


# ---------------------------------------------------------------- drawer
def grasp_handle(R, z_safe):
    """Go to the drawer handle from above and close on it. Returns handle pos."""
    h = np.array(R.api.get_handle()["pos"], dtype=float)
    gz = h[2] + 0.02
    e = np.array(R.ee()["pos"], dtype=float)
    R.api.open_gripper()
    above = [h[0], h[1], max(gz + 0.12, e[2])]
    # get above the handle first (high), then straight down
    if e[2] < above[2] - 0.01:
        R.move([e[0], e[1], above[2]], tag="lift-before-handle")
    R.move(above, yaw=0.0, speed=0.2, tag="above-handle")
    R.move([h[0], h[1], gz + 0.04], yaw=0.0, speed=0.15, tag="near-handle")
    R.move([h[0], h[1], gz], yaw=0.0, speed=0.06, tag="handle")
    w = R.api.close_gripper()
    R.log("handle grasp: handle=%s width=%.4f" % (np.round(h, 3).tolist(), w))
    return h, gz, w


def release_handle(R, gz):
    R.api.open_gripper()
    e = np.array(R.ee()["pos"], dtype=float)
    R.move([e[0], e[1], gz + 0.13], speed=0.15, tag="up-from-handle")


def set_drawer(R, target, z_safe, tol=0.02, tries=3):
    """Move the drawer to opening `target` using the handle."""
    for attempt in range(tries):
        d0 = R.api.get_drawer()["opening"]
        if abs(d0 - target) <= tol:
            return d0
        h, gz, w = grasp_handle(R, z_safe)
        if w < 0.004:
            R.log("handle grasp missed (width %.4f), retrying" % w)
            release_handle(R, gz)
            continue
        e = np.array(R.ee()["pos"], dtype=float)
        dx = -(target - d0)  # pulling = -x
        # pull/push in two stages so the grip does not get yanked
        R.move([e[0] + dx, e[1], e[2]], speed=0.08, tag="drawer-move")
        d1 = R.api.get_drawer()["opening"]
        R.log("drawer opening %.3f -> %.3f (target %.3f)" % (d0, d1, target))
        release_handle(R, gz)
        if abs(d1 - target) <= tol:
            return d1
    return R.api.get_drawer()["opening"]


def close_drawer(R, z_safe, tries=3):
    for attempt in range(tries):
        d0 = R.api.get_drawer()["opening"]
        if attempt > 0 and d0 < 0.006:
            break
        h, gz, w = grasp_handle(R, z_safe)
        e = np.array(R.ee()["pos"], dtype=float)
        if w < 0.004:
            # fingers closed on nothing: push with the closed fingers instead
            R.log("closing: handle not gripped, pushing")
        # overshoot a little: the drawer stops at its closed end
        R.move([e[0] + max(d0, 0.0) + 0.006, e[1], e[2]], speed=0.08, tag="drawer-close")
        d1 = R.api.get_drawer()["opening"]
        R.log("closing drawer %.3f -> %.3f" % (d0, d1))
        release_handle(R, gz)
        if d1 < 0.006:
            break
    return R.api.get_drawer()["opening"]


# ---------------------------------------------------------------- placement
def choose_place(R, cup, counter):
    dr = R.api.get_drawer()
    c = np.array(dr["interior_center"], dtype=float)
    s = np.array(dr["interior_size"], dtype=float)
    floor_z = float(dr["floor_z"])
    front_x = float(counter["front_x"])
    r = float(cup["radius"])
    x_lo_int, x_hi_int = c[0] - s[0] / 2, c[0] + s[0] / 2
    y_lo_int, y_hi_int = c[1] - s[1] / 2, c[1] + s[1] / 2
    R.log("drawer interior x[%.3f,%.3f] y[%.3f,%.3f] floor %.3f open %.3f" % (
        x_lo_int, x_hi_int, y_lo_int, y_hi_int, floor_z, dr["opening"]))

    ext = r + CUP_HANDLE_LEN  # conservative: handle could point +x or -x
    x_hi = min(front_x - ext - 0.008, front_x - HAND_HALF_DEPTH - 0.005,
               x_hi_int - ext - 0.005)
    x_lo = x_lo_int + ext + 0.01
    if x_lo > x_hi:
        # not enough room for the conservative footprint: relax handle margin
        x_hi = min(front_x - r - 0.01, front_x - HAND_HALF_DEPTH - 0.005)
        x_lo = x_lo_int + r + 0.012
        if x_lo > x_hi:
            x_lo = x_hi = 0.5 * (x_lo + x_hi)
    y_lo = y_lo_int + FINGER_REACH + 0.008
    y_hi = y_hi_int - FINGER_REACH - 0.008
    if y_lo > y_hi:
        y_lo = y_hi = c[1]

    objs = [o for o in R.api.get_objects() if o.get("location") == "drawer"]
    rects = []
    for o in objs:
        p = np.array(o["pos"], dtype=float)
        sz = np.array(o["size"], dtype=float)
        top = p[2] + sz[2] / 2
        rects.append(((p[0] - sz[0] / 2, p[0] + sz[0] / 2,
                       p[1] - sz[1] / 2, p[1] + sz[1] / 2), top, o["name"]))

    # keep away from the drawer front panel (the wrist hangs toward the robot)
    x_pref = x_hi - 0.25 * (x_hi - x_lo)
    y_pref = c[1]
    best = None
    for x in np.linspace(x_lo, x_hi, 9):
        for y in np.linspace(y_lo, y_hi, 41):
            foot = (x - ext, x + ext, y - FINGER_REACH, y + FINGER_REACH)
            hand = (x - HAND_HALF_DEPTH, x + HAND_HALF_DEPTH,
                    y - HAND_HALF_LEN, y + HAND_HALF_LEN)
            gap = 1.0
            for (rc, top, _) in rects:
                gap = min(gap, rect_gap(foot, rc))
                if top > floor_z + 0.075:
                    gap = min(gap, rect_gap(hand, rc))
            score = min(gap, 0.04) * 10.0 - 0.3 * abs(y - y_pref) - 0.2 * abs(x - x_pref)
            if best is None or score > best[0]:
                best = (score, x, y, gap)
    R.log("place choice x=%.3f y=%.3f gap=%.3f (x range %.3f..%.3f)" % (
        best[1], best[2], best[3], x_lo, x_hi))
    return best[1], best[2], floor_z


# ---------------------------------------------------------------- cup grasp
def choose_grasp_yaw(R, cup, counter_objs):
    p = np.array(cup["pos"], dtype=float)
    base = wrap_half(float(cup["yaw"]))
    cup_top = p[2] + cup["height"] / 2
    best = None
    for k, dlt in enumerate([0.0, 0.25, -0.25, 0.5, -0.5, 0.7, -0.7]):
        g = wrap_half(base + dlt)
        u = np.array([-math.sin(g), math.cos(g)])  # finger closing axis
        clear = 1.0
        for o in counter_objs:
            op = np.array(o["pos"], dtype=float)
            sz = np.array(o["size"], dtype=float)
            rc = (op[0] - sz[0] / 2, op[0] + sz[0] / 2, op[1] - sz[1] / 2, op[1] + sz[1] / 2)
            for sgn in (1, -1):
                f = p[:2] + sgn * 0.05 * u
                clear = min(clear, point_rect_dist(f, rc) - 0.012)
                if op[2] + sz[2] / 2 > cup_top - 0.01:
                    for t in np.linspace(0.0, HAND_HALF_LEN, 6):
                        q = p[:2] + sgn * t * u
                        clear = min(clear, point_rect_dist(q, rc) - 0.04)
        score = min(clear, 0.02) - 0.01 * abs(dlt)
        if best is None or score > best[0]:
            best = (score, g, clear)
    R.log("grasp yaw %.3f (cup yaw %.3f) clearance %.3f" % (best[1], cup["yaw"], best[2]))
    return best[1]


def pick_cup(R, z_travel, counter, tries=3):
    for attempt in range(tries):
        cup = R.api.get_cup()
        p = np.array(cup["pos"], dtype=float)
        objs = [o for o in R.api.get_objects() if o.get("location") != "drawer"]
        g = choose_grasp_yaw(R, cup, objs)
        gz = max(p[2] - 0.008, counter["top_z"] + 0.012)
        R.api.open_gripper()
        e = np.array(R.ee()["pos"], dtype=float)
        if e[2] < z_travel - 0.01:
            R.move([e[0], e[1], z_travel], speed=0.2, tag="lift")
        R.move([p[0], p[1], z_travel], yaw=g, speed=0.2, tag="above-cup")
        R.move([p[0], p[1], gz + 0.06], yaw=g, speed=0.15, tag="pre-grasp")
        R.move([p[0], p[1], gz], yaw=g, speed=0.06, tag="grasp")
        w = R.api.close_gripper()
        R.log("cup grasp width %.4f (cup diameter %.3f)" % (w, 2 * cup["radius"]))
        R.move([p[0], p[1], gz + 0.06], speed=0.08, tag="lift-cup-slow")
        R.move([p[0], p[1], z_travel], speed=0.15, tag="lift-cup")
        cup2 = R.api.get_cup()
        e = np.array(R.ee()["pos"], dtype=float)
        lifted = cup2["pos"][2] > p[2] + 0.05
        R.log("after lift: cup=%s ee=%s width=%.4f" % (
            np.round(cup2["pos"], 3).tolist(), np.round(e, 3).tolist(),
            R.ee()["gripper_width"]))
        if w > 0.01 and lifted:
            return cup2, e[2] - cup2["pos"][2]
        R.log("cup grasp failed, retrying")
        R.api.open_gripper()
        R.api.wait(0.5)
    return None, None


# ---------------------------------------------------------------- main
def run(api):
    R = Robot(api)
    cup = api.get_cup()
    counter = api.get_counter()
    drawer = api.get_drawer()
    handle = api.get_handle()
    objs = api.get_objects()
    ee = api.get_ee()
    R.log("cup %s" % cup)
    R.log("counter %s" % counter)
    R.log("drawer %s" % drawer)
    R.log("handle %s" % handle)
    R.log("ee %s" % ee)
    for o in objs:
        R.log("obj %s" % o)

    top_z = float(counter["top_z"])
    max_top = top_z
    for o in objs:
        if o.get("location") != "drawer":
            max_top = max(max_top, o["pos"][2] + o["size"][2] / 2)
    z_travel = min(max(top_z + 0.2, max_top + cup["height"] + 0.08), 0.75)
    R.log("z_travel %.3f" % z_travel)

    # 1) open the drawer far enough
    d = drawer["opening"]
    if d < D_MIN or d > D_MAX:
        d = set_drawer(R, D_TARGET, z_travel)
    R.log("drawer opening for placing: %.3f" % d)

    # 2) pick the cup
    cup_h, tip_minus_center = pick_cup(R, z_travel, counter)
    if cup_h is None:
        R.log("could not pick the cup")
        close_drawer(R, z_travel)
        return

    # 3) place in the drawer
    px, py, floor_z = choose_place(R, cup_h, counter)
    tip_z = floor_z + cup["height"] / 2 + tip_minus_center + 0.004
    R.move([px, py, z_travel], yaw=0.0, speed=0.15, tag="above-drawer")
    R.move([px, py, tip_z + 0.05], yaw=0.0, speed=0.12, tag="into-drawer")
    R.move([px, py, tip_z], yaw=0.0, speed=0.04, tag="place")
    api.wait(0.2)
    api.open_gripper()
    api.wait(0.3)
    R.move([px, py, top_z + 0.12], speed=0.1, tag="retreat-from-cup")
    c = api.get_cup()
    R.log("cup after release %s" % c)

    # 4) close the drawer
    d_end = close_drawer(R, z_travel)
    R.log("final drawer opening %.4f, cup %s" % (d_end, api.get_cup()["pos"]))
    e = np.array(R.ee()["pos"], dtype=float)
    R.move([e[0] - 0.05, e[1], max(e[2], top_z + 0.15)], speed=0.15, tag="park")
