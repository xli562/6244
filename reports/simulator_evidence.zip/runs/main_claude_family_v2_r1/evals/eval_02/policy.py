"""Robot program for: "Place the cup in the drawer." See TASK.md and API.md."""
import math

import numpy as np

# ---------------------------------------------------------------- constants
HAND_HALF_LONG = 0.110   # half extent of the hand along the finger-closing axis
HAND_HALF_SHORT = 0.040  # half extent of the hand perpendicular to it
FINGER_LEN = 0.050       # fingertip -> bottom of hand body
CUP_GRASP_H = 0.022      # fingertip height above the cup bottom when grasping
HANDLE_EXTRA = 0.028     # how far the cup handle sticks out past the body
BAR_R = 0.0095           # effective half thickness of the drawer handle bar
GOOD_BAR_W = 0.0135      # grip width that means the bar is held squarely
TARGET_OPENING = 0.25
MIN_OPENING = 0.20
N_AVG = 8


def wrap_pi(a):
    return (a + math.pi) % (2 * math.pi) - math.pi


def wrap_half(a):
    """Gripper is symmetric: yaw and yaw+pi are the same grasp."""
    a = wrap_pi(a)
    if a > math.pi / 2:
        a -= math.pi
    if a <= -math.pi / 2:
        a += math.pi
    return a


def seg_point_dist(p, a, b):
    p, a, b = np.asarray(p[:2]), np.asarray(a[:2]), np.asarray(b[:2])
    ab = b - a
    L = float(ab @ ab)
    t = 0.0 if L < 1e-12 else min(1.0, max(0.0, float((p - a) @ ab) / L))
    return float(np.linalg.norm(p - (a + t * ab)))


class Robot:
    def __init__(self, api):
        self.api = api
        self.top_z = 0.292
        self.front_x = 0.557
        self.counter_objs = []
        self.carrying = False

    def log(self, *args):
        try:
            self.api.log(" ".join(str(a) for a in args))
        except Exception:
            pass

    # ------------------------------------------------------------ perception
    def cup(self):
        rs = [self.api.get_cup() for _ in range(N_AVG)]
        pos = np.mean([r["pos"] for r in rs], axis=0)
        spread = np.max(np.ptp([r["pos"] for r in rs], axis=0))
        yaw = math.atan2(np.mean([math.sin(r["yaw"]) for r in rs]),
                         np.mean([math.cos(r["yaw"]) for r in rs]))
        rad = float(np.mean([r["radius"] for r in rs]))
        h = float(np.mean([r["height"] for r in rs]))
        self.log("cup pos", np.round(pos, 4), "yaw %.3f r %.4f h %.4f spread %.4f"
                 % (yaw, rad, h, spread))
        return pos, yaw, rad, h

    def handle(self):
        rs = [self.api.get_handle()["pos"] for _ in range(N_AVG)]
        p = np.mean(rs, axis=0)
        self.log("handle", np.round(p, 4), "spread %.4f" % np.max(np.ptp(rs, axis=0)))
        return p

    def drawer(self):
        rs = [self.api.get_drawer() for _ in range(N_AVG)]
        d = {
            "opening": float(np.mean([r["opening"] for r in rs])),
            "center": np.mean([r["interior_center"] for r in rs], axis=0),
            "size": np.mean([r["interior_size"] for r in rs], axis=0),
            "floor_z": float(np.mean([r["floor_z"] for r in rs])),
        }
        self.log("drawer open %.4f center" % d["opening"], np.round(d["center"], 4),
                 "size", np.round(d["size"], 4), "floor %.4f" % d["floor_z"])
        return d

    def counter(self):
        rs = [self.api.get_counter() for _ in range(N_AVG)]
        c = {"top_z": float(np.mean([r["top_z"] for r in rs])),
             "front_x": float(np.mean([r["front_x"] for r in rs]))}
        self.top_z, self.front_x = c["top_z"], c["front_x"]
        self.log("counter", c)
        return c

    def objects(self):
        objs = self.api.get_objects()
        for o in objs:
            self.log("obj", o["name"], o["location"], np.round(o["pos"], 3),
                     np.round(o["size"], 3))
        self.counter_objs = [o for o in objs if o["location"] == "counter"]
        return objs

    def ee(self):
        return np.array(self.api.get_ee()["pos"], dtype=float)

    # ---------------------------------------------------------------- motion
    def move(self, pos, yaw=None, speed=0.15, settle=True, quiet=False):
        tgt = [float(pos[0]), float(pos[1]), float(pos[2])]
        y = None if yaw is None else float(yaw)
        r = self.api.move_to(tgt, yaw=y, speed=speed)
        if settle:
            for _ in range(2):
                if r.get("error", 0.0) <= 0.004:
                    break
                r = self.api.move_to(tgt, yaw=y, speed=min(speed, 0.08))
        if not r.get("reached", True) and not quiet:
            self.log("move not reached", np.round(tgt, 4), "err %.4f" % r.get("error", -1))
        return r

    def seg_z(self, a, b):
        """Fingertip height that is safe for a straight move from a to b."""
        if self.carrying:
            z = self.top_z + 0.075
            need = 0.06
            infl = HAND_HALF_LONG + 0.02
        else:
            z = self.top_z + 0.06
            need = 0.035
            infl = HAND_HALF_LONG + 0.02
        for o in self.counter_objs:
            r = 0.5 * math.hypot(o["size"][0], o["size"][1]) + infl
            if seg_point_dist(o["pos"], a, b) < r:
                z = max(z, o["pos"][2] + o["size"][2] / 2 + need)
        return z

    def travel(self, pos, yaw=None, speed=0.2):
        """Go to travel height, go over, descend to pos."""
        e = self.ee()
        tz = max(self.seg_z(e, pos), pos[2])
        if abs(e[2] - tz) > 0.01:
            # going down at the current spot must also be safe there
            tz = max(tz, self.seg_z(e, e)) if e[2] > tz else tz
            self.move([e[0], e[1], tz], speed=speed, settle=False)
        self.move([pos[0], pos[1], tz], yaw=yaw, speed=speed, settle=False)
        return self.move(pos, yaw=yaw, speed=speed)

    def up(self, dz=None, z=None, speed=0.15):
        e = self.ee()
        if z is None:
            z = e[2] + dz
        self.move([e[0], e[1], z], speed=speed, settle=False)


# ------------------------------------------------------------- geometry help
def rect_clearance(center, yaw, half_long, half_short, box_c, box_s):
    """Approximate min clearance between a rotated rectangle (long axis along
    the finger-closing direction for gripper yaw `yaw`) and an axis-aligned
    box footprint. Negative = overlap."""
    ax_long = np.array([-math.sin(yaw), math.cos(yaw)])
    ax_short = np.array([math.cos(yaw), math.sin(yaw)])
    best = 1e9
    for u in np.linspace(-0.5, 0.5, 7):
        for v in np.linspace(-0.5, 0.5, 7):
            p = np.array([box_c[0] + u * box_s[0], box_c[1] + v * box_s[1]]) - center[:2]
            a = abs(p @ ax_long) - half_long
            b = abs(p @ ax_short) - half_short
            if a < 0 and b < 0:
                d = max(a, b)
            else:
                d = math.hypot(max(a, 0.0), max(b, 0.0))
            best = min(best, d)
    return best


# ------------------------------------------------------------------ drawer
def grasp_handle(rb):
    """Grip the handle bar squarely. Returns (handle_pos_used, grip_z) or None."""
    h = rb.handle()
    gz = h[2] + 0.02
    rb.api.open_gripper()
    rb.travel([h[0], h[1], gz + 0.05], yaw=0.0)
    rb.move([h[0], h[1], gz], yaw=0.0, speed=0.08)
    w = rb.api.close_gripper()
    rb.log("handle grip width %.4f at x %.4f" % (w, h[0]))
    if w >= GOOD_BAR_W:
        return np.array([h[0], h[1], gz])
    # partial grip on the round bar: chord width tells the x offset
    if w > 0.002:
        delta = math.sqrt(max(BAR_R ** 2 - (w / 2) ** 2, 0.0))
        delta = min(max(delta, 0.004), 0.012)
    else:
        delta = 0.012
    best = (w, h[0])
    for x in (h[0] + delta, h[0] - delta, h[0] + 2 * delta, h[0] - 2 * delta):
        rb.api.open_gripper()
        rb.move([x, h[1], gz], yaw=0.0, speed=0.05)
        w = rb.api.close_gripper()
        rb.log("handle regrip width %.4f at x %.4f" % (w, x))
        if w >= GOOD_BAR_W:
            return np.array([x, h[1], gz])
        if w > best[0]:
            best = (w, x)
    if best[0] > 0.006:
        rb.api.open_gripper()
        rb.move([best[1], h[1], gz], yaw=0.0, speed=0.05)
        w = rb.api.close_gripper()
        rb.log("handle best-effort grip width %.4f" % w)
        return np.array([best[1], h[1], gz])
    rb.api.open_gripper()
    return None


def open_drawer(rb, target):
    dr = rb.drawer()
    for attempt in range(3):
        if dr["opening"] >= target - 0.015:
            return dr
        g = grasp_handle(rb)
        if g is None:
            rb.up(dz=0.08)
            dr = rb.drawer()
            continue
        pull = target - dr["opening"]
        rb.move([g[0] - pull, g[1], g[2]], yaw=0.0, speed=0.10, settle=False)
        rb.api.open_gripper()
        rb.up(dz=0.10)
        dr = rb.drawer()
    return dr


def close_drawer(rb):
    dr = rb.drawer()
    for attempt in range(3):
        if dr["opening"] < 0.006:
            return dr
        h = rb.handle()
        gz = h[2] + 0.02
        hx_closed = h[0] + dr["opening"]
        # push the bar with the closed fingers from the robot side
        rb.api.close_gripper()
        start_x = h[0] - 0.04
        rb.travel([start_x, h[1], gz + 0.04], yaw=0.0)
        rb.move([start_x, h[1], gz], yaw=0.0, speed=0.08)
        rb.move([hx_closed + 0.02, h[1], gz], yaw=0.0, speed=0.10, settle=False,
                quiet=True)
        e = rb.ee()
        rb.move([e[0] - 0.02, e[1], e[2]], speed=0.1, settle=False, quiet=True)
        rb.up(dz=0.10)
        dr = rb.drawer()
    return dr


# --------------------------------------------------------------------- cup
def choose_grasp_yaw(cup_pos, cup_yaw, objs, counter_top):
    base = wrap_half(cup_yaw)
    best = None
    for deg in [0, 10, -10, 20, -20, 30, -30, 40, -40]:
        g = wrap_half(base + math.radians(deg))
        clear = 1e9
        for o in objs:
            if o["location"] != "counter":
                continue
            top = o["pos"][2] + o["size"][2] / 2
            c = rect_clearance(cup_pos, g, 0.065, 0.015, o["pos"], o["size"])
            clear = min(clear, c)
            if top > counter_top + CUP_GRASP_H + FINGER_LEN - 0.01:
                c = rect_clearance(cup_pos, g, HAND_HALF_LONG, HAND_HALF_SHORT,
                                   o["pos"], o["size"])
                clear = min(clear, c)
        score = min(clear, 0.03) - 0.0002 * abs(deg)
        if best is None or score > best[0]:
            best = (score, g, clear)
    return best[1], best[2]


def choose_place(rb, dr, objs):
    cx, cy = dr["center"][0], dr["center"][1]
    sx, sy = dr["size"][0], dr["size"][1]
    xmin = cx - sx / 2
    lo = xmin + 0.031 + HANDLE_EXTRA + 0.012
    hi = min(rb.front_x - HAND_HALF_SHORT - 0.012,
             cx + sx / 2 - 0.031 - HANDLE_EXTRA - 0.01)
    ylo = cy - sy / 2 + HAND_HALF_LONG + 0.01
    yhi = cy + sy / 2 - HAND_HALF_LONG - 0.01
    feasible = hi - lo > 0.0
    if not feasible:
        lo = hi = 0.5 * (lo + hi)
    if yhi < ylo:
        ylo = yhi = cy
    xs = np.linspace(lo, hi, 7)
    ys = np.linspace(ylo, yhi, 11)
    hand_bottom = dr["floor_z"] + CUP_GRASP_H + FINGER_LEN
    best = None
    for x in xs:
        for y in ys:
            p = np.array([x, y])
            clear = 0.05
            for o in objs:
                if o["location"] != "drawer":
                    continue
                c = rect_clearance(p, 0.0, 0.031 + 0.015, 0.031 + HANDLE_EXTRA,
                                   o["pos"], o["size"])
                clear = min(clear, c)
                top = o["pos"][2] + o["size"][2] / 2
                if top > hand_bottom - 0.01:
                    c = rect_clearance(p, 0.0, HAND_HALF_LONG, HAND_HALF_SHORT,
                                       o["pos"], o["size"])
                    clear = min(clear, c)
            mx = 0.5 * (lo + hi)
            score = min(clear, 0.04) - 0.05 * abs(x - mx) - 0.02 * abs(y - cy)
            if best is None or score > best[0]:
                best = (score, x, y, clear)
    rb.log("place region x[%.3f %.3f] y[%.3f %.3f] -> (%.3f, %.3f) clear %.3f"
           % (lo, hi, ylo, yhi, best[1], best[2], best[3]))
    return best[1], best[2], best[3], feasible


def pick_cup(rb, objs):
    offsets = [0.0, 0.0, 0.010, -0.010]
    off_i = 0
    for attempt in range(4):
        pos, yaw, rad, h = rb.cup()
        bottom = 0.5 * ((pos[2] - h / 2) + rb.top_z)
        g, clear = choose_grasp_yaw(pos, yaw, objs, rb.top_z)
        ax = np.array([-math.sin(g), math.cos(g), 0.0])
        tgt = pos + ax * offsets[min(off_i, len(offsets) - 1)]
        rb.log("grasp yaw %.3f (cup yaw %.3f) clear %.3f off %.3f"
               % (g, yaw, clear, offsets[min(off_i, len(offsets) - 1)]))
        gz = bottom + CUP_GRASP_H
        rb.api.open_gripper()
        rb.travel([tgt[0], tgt[1], bottom + h + 0.03], yaw=g)
        r = rb.move([tgt[0], tgt[1], gz], yaw=g, speed=0.05)
        if rb.ee()[2] - gz > 0.008:
            rb.log("blocked while descending onto cup; retry")
            rb.up(dz=0.05)
            off_i += 1
            continue
        w = rb.api.close_gripper()
        rb.log("cup grip width %.4f" % w)
        if w < 2 * rad - 0.015 or w > 0.078:
            rb.api.open_gripper()
            rb.up(dz=0.06)
            continue
        rb.carrying = True
        rb.up(dz=0.06, speed=0.08)
        p2, _, _, _ = rb.cup()
        if p2[2] - pos[2] < 0.03:
            rb.log("cup not lifted")
            rb.carrying = False
            rb.api.open_gripper()
            rb.up(dz=0.04)
            continue
        hang = rb.ee()[2] - (p2[2] - h / 2)
        return True, hang
    return False, CUP_GRASP_H


def run(api):
    rb = Robot(api)
    rb.counter()
    objs = rb.objects()
    rb.log("ee", api.get_ee())

    # 1. open the drawer far enough
    dr = open_drawer(rb, TARGET_OPENING)
    if dr["opening"] < MIN_OPENING:
        dr = open_drawer(rb, TARGET_OPENING)

    # 2. pick the cup
    ok, hang = pick_cup(rb, objs)
    rb.log("picked", ok, "hang %.4f" % hang)

    # 3. place it in the drawer
    if ok:
        dr = rb.drawer()
        objs = rb.objects()
        px, py, clear, feasible = choose_place(rb, dr, objs)
        hang = min(max(hang, 0.012), 0.035)
        pz = dr["floor_z"] + hang + 0.008
        rb.travel([px, py, pz + 0.05], yaw=0.0, speed=0.15)
        rb.move([px, py, pz], yaw=0.0, speed=0.05)
        rb.api.open_gripper()
        rb.carrying = False
        rb.up(z=max(rb.top_z + 0.06, pz + 0.12), speed=0.1)

    # 4. close the drawer
    dr = close_drawer(rb)
    rb.log("final opening %.4f" % dr["opening"])
