"""Robot program for: "Place the cup in the drawer." See TASK.md and API.md."""
import math

import numpy as np

# ---------------------------------------------------------------- constants
HAND_HALF_LONG = 0.110   # half extent of the hand along the finger-closing axis
HAND_HALF_SHORT = 0.040  # half extent of the hand perpendicular to it
FINGER_LEN = 0.050       # fingertip -> bottom of hand body
CUP_GRASP_H = 0.022      # fingertip height above the cup bottom when grasping
HANDLE_EXTRA = 0.028     # how far the cup handle sticks out past the body
TARGET_OPENING = 0.28
MIN_TRAVEL_Z = 0.42
N_AVG = 5


def wrap_pi(a):
    return (a + math.pi) % (2 * math.pi) - math.pi


def wrap_half(a):
    """Gripper is symmetric: yaw and yaw+pi are the same grasp."""
    a = wrap_pi(a)
    if a > math.pi / 2:
        a -= math.pi
    if a <= -math.pi / 2:
        a += math.pi
    return a


class Robot:
    def __init__(self, api):
        self.api = api
        self.travel_z = MIN_TRAVEL_Z

    def log(self, *args):
        try:
            self.api.log(" ".join(str(a) for a in args))
        except Exception:
            pass

    # ------------------------------------------------------------ perception
    def cup(self):
        rs = [self.api.get_cup() for _ in range(N_AVG)]
        pos = np.mean([r["pos"] for r in rs], axis=0)
        spread = np.max(np.ptp([r["pos"] for r in rs], axis=0))
        yaw = math.atan2(np.mean([math.sin(r["yaw"]) for r in rs]),
                         np.mean([math.cos(r["yaw"]) for r in rs]))
        rad = float(np.mean([r["radius"] for r in rs]))
        h = float(np.mean([r["height"] for r in rs]))
        self.log("cup pos", np.round(pos, 4), "yaw %.3f r %.4f h %.4f spread %.4f"
                 % (yaw, rad, h, spread))
        return pos, yaw, rad, h

    def handle(self):
        rs = [self.api.get_handle()["pos"] for _ in range(N_AVG)]
        p = np.mean(rs, axis=0)
        self.log("handle", np.round(p, 4), "spread %.4f" % np.max(np.ptp(rs, axis=0)))
        return p

    def drawer(self):
        rs = [self.api.get_drawer() for _ in range(N_AVG)]
        d = {
            "opening": float(np.mean([r["opening"] for r in rs])),
            "center": np.mean([r["interior_center"] for r in rs], axis=0),
            "size": np.mean([r["interior_size"] for r in rs], axis=0),
            "floor_z": float(np.mean([r["floor_z"] for r in rs])),
        }
        self.log("drawer open %.4f center" % d["opening"], np.round(d["center"], 4),
                 "size", np.round(d["size"], 4), "floor %.4f" % d["floor_z"])
        return d

    def counter(self):
        rs = [self.api.get_counter() for _ in range(N_AVG)]
        c = {"top_z": float(np.mean([r["top_z"] for r in rs])),
             "front_x": float(np.mean([r["front_x"] for r in rs]))}
        self.log("counter", c)
        return c

    def objects(self):
        objs = self.api.get_objects()
        for o in objs:
            self.log("obj", o["name"], o["location"], np.round(o["pos"], 3),
                     np.round(o["size"], 3))
        return objs

    def ee(self):
        return self.api.get_ee()

    # ---------------------------------------------------------------- motion
    def move(self, pos, yaw=None, speed=0.15):
        r = self.api.move_to([float(pos[0]), float(pos[1]), float(pos[2])],
                             yaw=None if yaw is None else float(yaw), speed=speed)
        if not r.get("reached", True):
            self.log("move not reached", np.round(pos, 4), "err %.4f" % r.get("error", -1))
        return r

    def travel(self, pos, yaw=None, speed=0.18):
        """Lift to travel height, go over, descend to pos."""
        e = np.array(self.ee()["pos"])
        tz = max(self.travel_z, pos[2])
        if e[2] < tz - 0.01:
            self.move([e[0], e[1], tz], speed=speed)
        self.move([pos[0], pos[1], tz], yaw=yaw, speed=speed)
        return self.move(pos, yaw=yaw, speed=speed)

    def up(self, z=None, speed=0.15):
        e = np.array(self.ee()["pos"])
        self.move([e[0], e[1], self.travel_z if z is None else z], speed=speed)


# ------------------------------------------------------------- geometry help
def rect_clearance(center, yaw, half_long, half_short, box_c, box_s):
    """Approximate min clearance between a rotated rectangle (long axis along
    the finger-closing direction for gripper yaw `yaw`) and an axis-aligned
    box footprint. Negative = overlap."""
    ax_long = np.array([-math.sin(yaw), math.cos(yaw)])
    ax_short = np.array([math.cos(yaw), math.sin(yaw)])
    best = 1e9
    for u in np.linspace(-0.5, 0.5, 7):
        for v in np.linspace(-0.5, 0.5, 7):
            p = np.array([box_c[0] + u * box_s[0], box_c[1] + v * box_s[1]]) - center[:2]
            a = abs(p @ ax_long) - half_long
            b = abs(p @ ax_short) - half_short
            if a < 0 and b < 0:
                d = max(a, b)
            else:
                d = math.hypot(max(a, 0.0), max(b, 0.0))
            best = min(best, d)
    return best


# ------------------------------------------------------------------ skills
def open_drawer(rb, target):
    for attempt in range(3):
        dr = rb.drawer()
        if dr["opening"] >= target - 0.015:
            return dr
        h = rb.handle()
        gz = h[2] + 0.02
        rb.api.open_gripper()
        rb.travel([h[0] - 0.005, h[1], gz + 0.06], yaw=0.0)
        rb.move([h[0], h[1], gz], yaw=0.0, speed=0.08)
        w = rb.api.close_gripper()
        rb.log("handle grip width %.4f" % w)
        if w < 0.004:
            rb.api.open_gripper()
            rb.move([h[0] - 0.06, h[1], gz], speed=0.1)
            rb.up()
            continue
        pull = target - dr["opening"]
        rb.move([h[0] - pull, h[1], gz], yaw=0.0, speed=0.10)
        rb.api.open_gripper()
        e = np.array(rb.ee()["pos"])
        rb.move([e[0] - 0.06, e[1], e[2]], speed=0.12)
        rb.up()
    return rb.drawer()


def close_drawer(rb):
    for attempt in range(3):
        dr = rb.drawer()
        if dr["opening"] < 0.004:
            return dr
        h = rb.handle()
        gz = h[2] + 0.02
        rb.api.open_gripper()
        rb.travel([h[0] - 0.005, h[1], gz + 0.06], yaw=0.0)
        rb.move([h[0], h[1], gz], yaw=0.0, speed=0.08)
        w = rb.api.close_gripper()
        rb.log("handle grip width %.4f" % w)
        if w < 0.004:
            # push with the closed fingers on the bar's front side instead
            rb.api.open_gripper()
            rb.move([h[0] - 0.05, h[1], gz], speed=0.1)
            rb.api.close_gripper()
            rb.move([h[0] - 0.03, h[1], gz], speed=0.1)
        target_x = h[0] + dr["opening"] + 0.008
        rb.move([target_x, h[1], gz], yaw=0.0, speed=0.10)
        rb.api.open_gripper()
        e = np.array(rb.ee()["pos"])
        rb.move([e[0] - 0.06, e[1], e[2]], speed=0.12)
        rb.up()
    return rb.drawer()


def choose_grasp_yaw(cup_pos, cup_yaw, objs, counter_top):
    base = wrap_half(cup_yaw)
    best = None
    for deg in [0, 10, -10, 20, -20, 30, -30, 40, -40]:
        g = wrap_half(base + math.radians(deg))
        clear = 1e9
        for o in objs:
            if o["location"] != "counter":
                continue
            top = o["pos"][2] + o["size"][2] / 2
            # fingers region: always relevant
            c = rect_clearance(cup_pos, g, 0.065, 0.015, o["pos"], o["size"])
            clear = min(clear, c)
            if top > counter_top + CUP_GRASP_H + FINGER_LEN - 0.01:
                c = rect_clearance(cup_pos, g, HAND_HALF_LONG, HAND_HALF_SHORT,
                                   o["pos"], o["size"])
                clear = min(clear, c)
        score = min(clear, 0.03) - 0.0002 * abs(deg)
        if best is None or score > best[0]:
            best = (score, g, clear)
    return best[1], best[2]


def choose_place(rb, dr, ct, objs):
    cx, cy = dr["center"][0], dr["center"][1]
    sx, sy = dr["size"][0], dr["size"][1]
    xmin = cx - sx / 2
    xmax = min(cx + sx / 2, ct["front_x"])
    lo = xmin + 0.031 + HANDLE_EXTRA + 0.012
    hi = min(ct["front_x"] - HAND_HALF_SHORT - 0.012, cx + sx / 2 - 0.031 - HANDLE_EXTRA - 0.01)
    ylo = cy - sy / 2 + HAND_HALF_LONG + 0.01
    yhi = cy + sy / 2 - HAND_HALF_LONG - 0.01
    if hi < lo:
        mid = 0.5 * (lo + hi)
        lo = hi = mid
    if yhi < ylo:
        ylo = yhi = cy
    xs = np.linspace(lo, hi, 7)
    ys = np.linspace(ylo, yhi, 11)
    hand_bottom = dr["floor_z"] + CUP_GRASP_H + FINGER_LEN
    best = None
    for x in xs:
        for y in ys:
            p = np.array([x, y])
            clear = 0.05
            for o in objs:
                if o["location"] != "drawer":
                    continue
                # cup + fingers footprint (yaw 0: fingers along y, handle along x)
                c = rect_clearance(p, 0.0, 0.031 + 0.015, 0.031 + HANDLE_EXTRA,
                                   o["pos"], o["size"])
                clear = min(clear, c)
                top = o["pos"][2] + o["size"][2] / 2
                if top > hand_bottom - 0.01:
                    c = rect_clearance(p, 0.0, HAND_HALF_LONG, HAND_HALF_SHORT,
                                       o["pos"], o["size"])
                    clear = min(clear, c)
            mx = 0.5 * (lo + hi)
            score = min(clear, 0.04) - 0.05 * abs(x - mx) - 0.02 * abs(y - cy)
            if best is None or score > best[0]:
                best = (score, x, y, clear)
    rb.log("place region x[%.3f %.3f] y[%.3f %.3f] -> (%.3f, %.3f) clear %.3f"
           % (lo, hi, ylo, yhi, best[1], best[2], best[3]))
    return best[1], best[2], best[3]


def pick_cup(rb, ct, objs):
    for attempt in range(3):
        pos, yaw, rad, h = rb.cup()
        bottom = 0.5 * ((pos[2] - h / 2) + ct["top_z"])
        g, clear = choose_grasp_yaw(pos, yaw, objs, ct["top_z"])
        rb.log("grasp yaw %.3f (cup yaw %.3f) clear %.3f" % (g, yaw, clear))
        gz = bottom + CUP_GRASP_H
        rb.api.open_gripper()
        rb.travel([pos[0], pos[1], bottom + h + 0.04], yaw=g)
        r = rb.move([pos[0], pos[1], gz], yaw=g, speed=0.06)
        if not r["reached"]:
            rb.log("blocked while descending onto cup; retry")
            rb.up()
            continue
        w = rb.api.close_gripper()
        rb.log("cup grip width %.4f" % w)
        if w < 2 * rad - 0.015 or w > 0.078:
            rb.api.open_gripper()
            rb.up()
            continue
        rb.up()
        p2, _, _, _ = rb.cup()
        if p2[2] - pos[2] < 0.04:
            rb.log("cup not lifted")
            rb.api.open_gripper()
            continue
        hang = rb.ee()["pos"][2] - (p2[2] - h / 2)
        return True, hang, h
    return False, CUP_GRASP_H, 0.058


def run(api):
    rb = Robot(api)
    ct = rb.counter()
    objs = rb.objects()
    tops = [o["pos"][2] + o["size"][2] / 2 for o in objs if o["location"] == "counter"]
    if tops:
        rb.travel_z = max(MIN_TRAVEL_Z, max(tops) + 0.12)
    rb.log("travel z %.3f" % rb.travel_z)
    e = rb.ee()
    rb.log("ee", e)
    rb.up()

    # 1. open the drawer far enough
    dr = open_drawer(rb, TARGET_OPENING)

    # 2. pick the cup
    ok, hang, h = pick_cup(rb, ct, objs)
    rb.log("picked", ok, "hang %.4f" % hang)

    # 3. place it in the drawer
    dr = rb.drawer()
    objs = rb.objects()
    px, py, clear = choose_place(rb, dr, ct, objs)
    hang = min(max(hang, 0.012), 0.035)
    pz = dr["floor_z"] + hang + 0.008
    rb.travel([px, py, pz + 0.06], yaw=0.0)
    rb.move([px, py, pz], yaw=0.0, speed=0.05)
    rb.api.open_gripper()
    rb.up()

    # 4. close the drawer
    dr = close_drawer(rb)
    rb.up()
    pos, yaw, rad, h = rb.cup()
    rb.log("final opening %.4f" % dr["opening"])
