"""Robot program for: "Place the cup in the drawer." See TASK.md and API.md.

Strategy
  1. Perceive (averaging several readings).
  2. Make sure the drawer is open far enough that a free spot for the cup exists in
     the part of the drawer that is reachable from above (in front of the counter).
     The drawer is moved by grasping its vertical handle bar (fingers straddle it
     along y).  If the drawer is so far out that the handle is out of reach, it is
     first pushed in by grasping the top edge of a side wall.
  3. Pick the cup with a side approach: the fingers are lowered next to the cup
     (after probing the counter height by touch) and slid horizontally so the cup
     body enters between the open fingers; the closing axis is perpendicular to the
     cup handle.  Closing centres the cup, which tolerates perception error.
  4. Carry the cup high, rotate the gripper to yaw 0 (hand's long axis along y so
     it fits between drawer front panel and counter), lower it until it touches the
     drawer floor, release, retreat upward.
  5. Grasp the handle again and push the drawer shut, release, retreat.
"""
import math

import numpy as np

# ---------------------------------------------------------------- constants
FREE_SPEED = 0.3
CARRY_SPEED = 0.2
SLOW = 0.05

CUP_R_DEFAULT = 0.031
GRIP_OPEN = 0.08

HANDLE_LEN = 0.143          # vertical handle bar length
HANDLE_MIN_X = 0.285        # do not try to grasp the handle closer to the robot than this
WINDOW_TARGET = 0.20        # wanted reachable length of drawer interior (x) in front of counter
WINDOW_MAX = 0.245

# fingertip height above the touched counter when grasping the cup: the grasp axis
# must be ABOVE the cup's centre of mass, otherwise the cup swings over in the fingers
GRASP_ABOVE_COUNTER = 0.036
COUNTER_TO_FLOOR = 0.292 - 0.078

# gripper footprint model (half extents along closing axis c, along u) and z ranges
# relative to the fingertip z
def gripper_parts(z, carrying):
    parts = [
        (0.052, 0.013, z - 0.01, z + 0.045),   # fingers
        (0.106, 0.036, z + 0.045, z + 0.13),   # hand
        (0.065, 0.065, z + 0.13, z + 0.45),    # wrist / forearm
    ]
    if carrying:
        parts.append((0.056, 0.056, z - 0.02, z + 0.05))  # cup incl. handle
    return parts


# ---------------------------------------------------------------- helpers
def wrap_pi(a):
    return (a + math.pi) % (2.0 * math.pi) - math.pi


def wrap_half(a):
    a = wrap_pi(a)
    if a > math.pi / 2:
        a -= math.pi
    if a < -math.pi / 2:
        a += math.pi
    return a


def obb_aabb_overlap(cx, cy, yaw, hc, hu, bx, by, bhx, bhy):
    u = np.array([math.cos(yaw), math.sin(yaw)])
    c = np.array([-math.sin(yaw), math.cos(yaw)])
    d = np.array([bx - cx, by - cy])
    for ax in (np.array([1.0, 0.0]), np.array([0.0, 1.0]), u, c):
        r1 = hu * abs(u @ ax) + hc * abs(c @ ax)
        r2 = bhx * abs(ax[0]) + bhy * abs(ax[1])
        if abs(d @ ax) > r1 + r2:
            return False
    return True


def pose_collides(x, y, z, yaw, objs, margin, carrying=False):
    for (hc, hu, z0, z1) in gripper_parts(z, carrying):
        for o in objs:
            ox, oy, oz = o["pos"]
            sx, sy, sz = o["size"]
            if oz - sz / 2 - margin * 0.5 > z1 or oz + sz / 2 + margin * 0.5 < z0:
                continue
            if obb_aabb_overlap(x, y, yaw, hc, hu, ox, oy,
                                sx / 2 + margin, sy / 2 + margin):
                return True
    return False


def path_collides(p0, p1, yaw, objs, margin, carrying=False, step=0.01):
    p0 = np.asarray(p0, float)
    p1 = np.asarray(p1, float)
    n = max(1, int(np.linalg.norm(p1 - p0) / step))
    for i in range(n + 1):
        p = p0 + (p1 - p0) * (i / n)
        if pose_collides(p[0], p[1], p[2], yaw, objs, margin, carrying):
            return True
    return False


class Robot(object):
    def __init__(self, api):
        self.api = api
        self.travel_z = 0.42
        self.ct = 0.292
        self.objs_counter = []
        self.t = 0.0   # rough estimate of elapsed simulated time

    def open(self):
        self.t += 0.6
        return self.api.open_gripper()

    def close(self):
        self.t += 0.8
        return self.api.close_gripper()

    def log(self, msg):
        try:
            self.api.log(str(msg))
        except Exception:
            pass

    def ee(self):
        e = self.api.get_ee()
        return np.array(e["pos"], float), float(e["yaw"]), float(e["gripper_width"])

    def move(self, pos, yaw=None, speed=FREE_SPEED, tag=""):
        pos = [float(v) for v in pos]
        try:
            cur = np.array(self.api.get_ee()["pos"], float)
            self.t += float(np.linalg.norm(np.array(pos) - cur)) / max(speed, 1e-3) + 0.25
        except Exception:
            self.t += 1.0
        if yaw is None:
            r = self.api.move_to(pos, speed=speed)
        else:
            r = self.api.move_to(pos, yaw=float(yaw), speed=speed)
        if not r.get("reached", True):
            self.log("move %s not reached: target=%s err=%.4f" %
                     (tag, np.round(pos, 4).tolist(), r.get("error", -1)))
        return r

    def path_travel_z(self, p0, p1, carrying):
        """Lowest safe height for a horizontal move from p0 to p1 (xy)."""
        base = self.ct + (0.14 if carrying else 0.10)
        a = np.array(p0[:2], float)
        b = np.array(p1[:2], float)
        ab = b - a
        L2 = float(ab @ ab)
        tz = base
        for o in self.objs_counter:
            c = np.array(o["pos"][:2], float)
            t = 0.0 if L2 < 1e-9 else min(1.0, max(0.0, float((c - a) @ ab) / L2))
            dist = float(np.linalg.norm(a + t * ab - c))
            half = 0.5 * math.hypot(o["size"][0], o["size"][1])
            if dist - half < 0.17:
                top = o["pos"][2] + o["size"][2] / 2
                tz = max(tz, top + (0.16 if carrying else 0.12))
        return min(tz, 0.65)

    def transit(self, target, yaw=None, speed=FREE_SPEED, final_speed=None, travel_z=None,
                carrying=False):
        """Go up to a safe travel height, across, then straight down to target."""
        p, _, _ = self.ee()
        tz = self.path_travel_z(p, target, carrying)
        if travel_z is not None:
            tz = max(tz, travel_z)
        tz = max(tz, target[2])
        if p[2] < tz - 0.005:
            self.move([p[0], p[1], tz], speed=speed, tag="lift")
        self.move([target[0], target[1], tz], yaw=yaw, speed=speed, tag="across")
        if tz - target[2] > 0.002:
            self.move(target, speed=final_speed or speed, tag="down")

    # ------------------------------------------------------------ perception
    def cup(self, n=2):
        rs = [self.api.get_cup() for _ in range(n)]
        pos = np.mean([r["pos"] for r in rs], axis=0)
        yaw = math.atan2(np.mean([math.sin(r["yaw"]) for r in rs]),
                         np.mean([math.cos(r["yaw"]) for r in rs]))
        rad = float(np.mean([r.get("radius", CUP_R_DEFAULT) for r in rs]))
        h = float(np.mean([r.get("height", 0.058) for r in rs]))
        return {"pos": pos, "yaw": yaw, "radius": rad, "height": h}

    def handle(self, n=1):
        return np.mean([self.api.get_handle()["pos"] for _ in range(n)], axis=0)

    def drawer(self, n=1):
        rs = [self.api.get_drawer() for _ in range(n)]
        return {
            "opening": float(np.mean([r["opening"] for r in rs])),
            "ic": np.mean([r["interior_center"] for r in rs], axis=0),
            "isz": np.mean([r["interior_size"] for r in rs], axis=0),
            "floor_z": float(np.mean([r["floor_z"] for r in rs])),
        }

    def counter(self, n=1):
        rs = [self.api.get_counter() for _ in range(n)]
        return (float(np.mean([r["top_z"] for r in rs])),
                float(np.mean([r["front_x"] for r in rs])))

    def objects(self, n=1):
        acc = {}
        order = []
        for _ in range(n):
            for i, o in enumerate(self.api.get_objects()):
                key = "%s#%d" % (o.get("name", "obj"), i)
                if key not in acc:
                    acc[key] = []
                    order.append(key)
                acc[key].append(o)
        out = []
        for k in order:
            lst = acc[k]
            out.append({
                "name": lst[0].get("name", "obj"),
                "pos": np.mean([o["pos"] for o in lst], axis=0),
                "size": np.mean([o["size"] for o in lst], axis=0),
                "location": lst[0].get("location", "counter"),
            })
        return out


# ---------------------------------------------------------------- drawer handling
def grasp_handle(rb, attempts=4):
    api = rb.api
    for attempt in range(min(attempts, 4)):
        h = rb.handle()
        dx = [0.0, 0.008, -0.008, 0.0][attempt]
        dz = [0.0, 0.0, 0.0, -0.015][attempt]
        top = h[2] + HANDLE_LEN / 2
        zg = h[2] + 0.032 + dz
        rb.open()
        rb.transit([h[0] + dx, h[1], top + 0.03], yaw=0.0, final_speed=0.2,
                   travel_z=top + 0.06)
        r = rb.move([h[0] + dx, h[1], zg], speed=SLOW, tag="handle-descend")
        w = rb.close()
        p, _, _ = rb.ee()
        rb.log("handle grasp attempt %d: handle=%s ee=%s width=%.4f" %
               (attempt, np.round(h, 4).tolist(), np.round(p, 4).tolist(), w))
        if 0.004 < w < 0.05:
            return True
        rb.open()
        rb.move([p[0], p[1], top + 0.06], speed=0.1, tag="handle-retreat")
    return False


def release_and_lift(rb, dz=0.09, speed=0.1):
    rb.open()
    rb.api.wait(0.2)
    rb.t += 0.2
    p, _, _ = rb.ee()
    rb.move([p[0], p[1], p[2] + dz], speed=speed, tag="release-lift")


def move_drawer(rb, delta, speed=0.08, attempts=4):
    """delta > 0 pulls the drawer out by delta, delta < 0 pushes it in.
    Returns (grasped, blocked): blocked means the motion was stopped early,
    i.e. the drawer hit its end stop."""
    if not grasp_handle(rb, attempts):
        rb.log("could not grasp handle")
        return False, False
    p, _, _ = rb.ee()
    target = [p[0] - delta, p[1], p[2]]
    r = rb.move(target, speed=speed, tag="drawer")
    rb.api.wait(0.15)
    rb.t += 0.15
    p2, _, _ = rb.ee()
    blocked = abs(p2[0] - target[0]) > 0.008
    rb.log("drawer moved by ee dx=%.4f (wanted %.4f) blocked=%s" % (p2[0] - p[0], -delta, blocked))
    release_and_lift(rb)
    return True, blocked


def wall_push(rb, target_opening, front_x):
    """Push an over-extended drawer in by grasping the top edge of a side wall."""
    api = rb.api
    for it in range(3):
        d = rb.drawer()
        if d["opening"] <= target_opening + 0.015:
            return
        icx, icy, _ = d["ic"]
        sx, sy, _ = d["isz"]
        x_min = icx - sx / 2
        walls = [icy + sy / 2 + 0.007, icy - sy / 2 - 0.007]
        wall_y = min(walls, key=abs)
        wall_top = d["floor_z"] + 0.082
        xg = max(x_min + 0.04, 0.33)
        x_end = min(front_x - 0.075, xg + (d["opening"] - target_opening))
        rb.log("wall push %d: opening=%.3f wall_y=%.3f xg=%.3f x_end=%.3f" %
               (it, d["opening"], wall_y, xg, x_end))
        if x_end - xg < 0.02:
            return
        rb.open()
        rb.transit([xg, wall_y, wall_top + 0.05], yaw=0.0, final_speed=0.15)
        rb.move([xg, wall_y, wall_top - 0.025], speed=SLOW, tag="wall-descend")
        w = rb.close()
        if not (0.003 < w < 0.05):
            rb.log("wall grasp failed, width %.4f" % w)
            release_and_lift(rb, dz=0.12)
            continue
        p, _, _ = rb.ee()
        rb.move([x_end, p[1], p[2]], speed=0.08, tag="wall-push")
        release_and_lift(rb, dz=0.12)


# ---------------------------------------------------------------- placement planning
def drawer_geometry(d, front_x):
    icx, icy, _ = d["ic"]
    sx, sy, _ = d["isz"]
    e1 = icx - sx / 2
    e2 = front_x - d["opening"] + 0.016
    x_min = 0.5 * (e1 + e2) if abs(e1 - e2) < 0.03 else e1
    x_min = max(x_min, e1)  # be conservative (the front panel is the hard limit)
    return x_min, icy - sy / 2, icy + sy / 2


def place_z_estimate(d, z_contact):
    """Fingertip z at which the held cup touches the drawer floor."""
    est_perc = d["floor_z"] + GRASP_ABOVE_COUNTER + 0.004
    if z_contact is None:
        return est_perc
    est_geom = z_contact + GRASP_ABOVE_COUNTER - COUNTER_TO_FLOOR
    if abs(est_geom - est_perc) > 0.03:
        return est_perc
    return 0.5 * (est_geom + est_perc)


def plan_place(rb, d, objs_drawer, front_x, z_place):
    x_min, y_lo, y_hi = drawer_geometry(d, front_x)
    x_a = x_min + 0.06
    x_b = front_x - 0.068
    if x_b < x_a:
        return None, x_min
    y_a = y_lo + 0.118
    y_b = y_hi - 0.118
    if y_b < y_a:
        y_a = y_b = 0.5 * (y_lo + y_hi)
    xs = np.arange(x_a, x_b + 1e-9, 0.01) if x_b - x_a > 0.01 else np.array([0.5 * (x_a + x_b)])
    ys = np.arange(y_a, y_b + 1e-9, 0.01) if y_b - y_a > 0.01 else np.array([0.5 * (y_a + y_b)])
    xc = 0.5 * (x_a + x_b)
    yc = 0.5 * (y_lo + y_hi)
    for margin in (0.04, 0.03, 0.02, 0.012):
        feas = []
        for x in xs:
            for y in ys:
                if not pose_collides(x, y, z_place, 0.0, objs_drawer, margin, carrying=True):
                    feas.append((x, y))
        if feas:
            best = min(feas, key=lambda q: 1.5 * abs(q[0] - xc) + abs(q[1] - yc))
            rb.log("place plan: margin=%.3f spot=(%.3f, %.3f) window x [%.3f, %.3f]" %
                   (margin, best[0], best[1], x_a, x_b))
            return (best[0], best[1]), x_min
    return None, x_min


# ---------------------------------------------------------------- pick planning
def plan_pick(rb, cup, objs, ct, front_x):
    cx, cy = cup["pos"][0], cup["pos"][1]
    a = cup["yaw"]
    hdir = np.array([-math.cos(a), -math.sin(a)])
    D = cup["radius"] + 0.055
    zg = ct + GRASP_ABOVE_COUNTER
    best = None
    for delta in (0.0, 0.2, -0.2, 0.35, -0.35):
        g = wrap_half(a + delta)
        u = np.array([math.cos(g), math.sin(g)])
        for s in (1.0, -1.0):
            sx, sy = cx + s * D * u[0], cy + s * D * u[1]
            r = math.hypot(sx, sy)
            if r > 0.84 or r < 0.28:
                continue
            on_counter = (sx > front_x + 0.03) and abs(sy) < 0.43
            ok_margin = None
            for margin in (0.035, 0.02, 0.008):
                if path_collides([sx, sy, zg + 0.25], [sx, sy, zg], g, objs, margin):
                    continue
                if path_collides([sx, sy, zg], [cx, cy, zg], g, objs, margin):
                    continue
                ok_margin = margin
                break
            if ok_margin is None:
                continue
            cost = abs(delta) * 0.6 + (0.0 if on_counter else 0.25)
            cost += (0.035 - ok_margin) * 8.0
            if float(np.dot(s * u, hdir)) > 0:   # starting on the handle side
                cost += 0.03
            if best is None or cost < best[0]:
                best = (cost, g, np.array([sx, sy]), on_counter, ok_margin)
    return best


def pick_cup(rb, ct, front_x, objs_counter):
    api = rb.api
    z_contact_used = None
    for attempt in range(3):
        cup = rb.cup()
        rb.log("cup: pos=%s yaw=%.3f r=%.4f h=%.4f" %
               (np.round(cup["pos"], 4).tolist(), cup["yaw"], cup["radius"], cup["height"]))
        cx, cy = cup["pos"][0], cup["pos"][1]
        plan = plan_pick(rb, cup, objs_counter, ct, front_x)
        rb.open()
        if plan is None:
            rb.log("no side approach found, using top-down grasp")
            g = wrap_half(cup["yaw"])
            zg = ct + GRASP_ABOVE_COUNTER + 0.005
            top = ct + cup["height"] + 0.04
            rb.transit([cx, cy, top], yaw=g, final_speed=0.15)
            rb.move([cx, cy, zg], speed=SLOW, tag="topdown")
            z_contact = None
        else:
            _, g, start, on_counter, margin = plan
            rb.log("pick plan: yaw=%.3f start=%s on_counter=%s margin=%.3f" %
                   (g, np.round(start, 4).tolist(), on_counter, margin))
            rb.transit([start[0], start[1], ct + 0.035], yaw=g, final_speed=0.15)
            z_contact = None
            if on_counter:
                r = rb.move([start[0], start[1], ct - 0.03], speed=0.04, tag="probe")
                p, _, _ = rb.ee()
                if r.get("error", 0.0) > 0.004 and abs(p[2] - ct) < 0.03:
                    z_contact = float(p[2])
                rb.log("counter probe: ee z=%.4f perceived top=%.4f -> contact=%s" %
                       (p[2], ct, z_contact))
            base = z_contact if z_contact is not None else ct
            zg = base + GRASP_ABOVE_COUNTER
            rb.move([start[0], start[1], zg], speed=SLOW, tag="to-grasp-height")
            rb.move([cx, cy, zg], speed=0.05, tag="slide-in")
        w = rb.close()
        rb.log("cup grasp width %.4f" % w)
        p, _, _ = rb.ee()
        if 0.035 < w < 0.078:
            rb.move([p[0], p[1], p[2] + 0.04], speed=0.06, tag="lift-cup")
            _, _, w2 = rb.ee()
            if w2 > 0.03:
                return True, (z_contact if z_contact is not None else None)
            rb.log("cup lost during lift (width %.4f)" % w2)
        rb.open()
        p, _, _ = rb.ee()
        rb.move([p[0], p[1], ct + 0.12], speed=0.1, tag="retry-lift")
        if z_contact is not None:
            z_contact_used = z_contact
    return False, z_contact_used


# ---------------------------------------------------------------- main
def run(api):
    rb = Robot(api)
    ct, front_x = rb.counter()
    objs = rb.objects()
    objs_counter = [o for o in objs if o["location"] != "drawer"]
    tallest = max([o["pos"][2] + o["size"][2] / 2 for o in objs_counter] + [ct])
    rb.travel_z = float(min(0.62, max(0.42, tallest + 0.16)))
    rb.ct = ct
    rb.objs_counter = objs_counter
    rb.log("counter top=%.4f front_x=%.4f travel_z=%.3f n_objs=%d" %
           (ct, front_x, rb.travel_z, len(objs)))
    if objs:
        rb.log("objs: " + "; ".join("%s %s %s %s" % (o["name"], o["location"][0],
                                                    np.round(o["pos"], 3).tolist(),
                                                    np.round(o["size"], 3).tolist())
                                     for o in objs))
    rb.open()

    # ---------------- 1. drawer opening
    d0 = rb.drawer()
    h0 = rb.handle()
    closed_handle_x = 0.5 * ((h0[0] + d0["opening"]) + 0.516)
    rb.log("drawer: opening=%.4f ic=%s isz=%s floor=%.4f handle=%s" %
           (d0["opening"], np.round(d0["ic"], 4).tolist(), np.round(d0["isz"], 4).tolist(),
            d0["floor_z"], np.round(h0, 4).tolist()))
    if h0[0] < HANDLE_MIN_X:
        wall_push(rb, min(closed_handle_x - HANDLE_MIN_X, WINDOW_TARGET + 0.025), front_x)

    z_place_guess = d0["floor_z"] + GRASP_ABOVE_COUNTER + 0.004
    want = WINDOW_TARGET
    spot = None
    for it in range(4):
        d = rb.drawer()
        objs = rb.objects()
        objs_drawer = [o for o in objs if o["location"] == "drawer"]
        x_min, _, _ = drawer_geometry(d, front_x)
        window = front_x - x_min
        spot, _ = plan_place(rb, d, objs_drawer, front_x, z_place_guess)
        rb.log("drawer check %d: opening=%.4f window=%.4f spot=%s" % (it, d["opening"], window, spot))
        if spot is not None and window >= want - 0.02:
            break
        if spot is not None and it >= 2:
            break
        if spot is None:
            want = max(want, window) + 0.03
        want = min(want, WINDOW_MAX)
        h = rb.handle()
        max_delta = h[0] - (HANDLE_MIN_X - 0.01)
        delta = min(want - window + 0.004, max_delta)
        if delta < 0.008:
            break
        move_drawer(rb, delta)

    # ---------------- 2. pick the cup
    ct_objs = [o for o in rb.objects() if o["location"] != "drawer"]
    ok, z_contact = pick_cup(rb, ct, front_x, ct_objs)
    if not ok:
        rb.log("failed to pick cup")

    # ---------------- 3. place it in the drawer
    if ok:
        d = rb.drawer()
        objs_drawer = [o for o in rb.objects() if o["location"] == "drawer"]
        z_place = place_z_estimate(d, z_contact)
        spot, _ = plan_place(rb, d, objs_drawer, front_x, z_place)
        if spot is None:
            x_min, y_lo, y_hi = drawer_geometry(d, front_x)
            spot = (0.5 * (x_min + 0.06 + front_x - 0.068), 0.5 * (y_lo + y_hi))
            rb.log("no collision-free spot; using window centre %s" % (spot,))
        rb.log("placing at (%.3f, %.3f), floor-contact ee z est %.4f" % (spot[0], spot[1], z_place))
        rb.transit([spot[0], spot[1], z_place + 0.035], yaw=0.0, speed=CARRY_SPEED,
                   final_speed=0.12, carrying=True)
        rb.move([spot[0], spot[1], z_place - 0.008], speed=0.03, tag="place-contact")
        api.wait(0.2)
        rb.open()
        api.wait(0.3)
        rb.t += 0.5
        p, _, _ = rb.ee()
        rb.move([p[0], p[1], p[2] + 0.10], speed=0.08, tag="place-retreat")
        c = rb.cup(n=1)
        rb.log("cup after place: pos=%s" % np.round(c["pos"], 4).tolist())

    # ---------------- 4. close the drawer
    # The push target lies beyond the estimated closed position; when the drawer
    # reaches its end stop the motion is blocked, which tells us it is shut
    # (perception of the opening alone is too inaccurate for that decision).
    for it in range(4):
        d = rb.drawer()
        h = rb.handle()
        est = 0.5 * (d["opening"] + max(0.0, closed_handle_x - h[0]))
        rb.log("close %d: opening=%.4f handle_x=%.4f est=%.4f" % (it, d["opening"], h[0], est))
        if it == 0 and est < 0.004 and d["opening"] < 0.006:
            break
        if it >= 1 and rb.t > 74.0:
            rb.log("out of time (est %.1f s), stopping" % rb.t)
            break
        if h[0] < HANDLE_MIN_X - 0.02:
            wall_push(rb, closed_handle_x - HANDLE_MIN_X, front_x)
            continue
        # The fingers hold the bar by friction only; at the end stop they slip along
        # the bar until they meet the drawer front (~3 cm), so overshoot by more than
        # that to get a genuine "blocked" signal.
        grasped, blocked = move_drawer(rb, -(est + 0.05), speed=0.08,
                                       attempts=2 if it > 0 else 4)
        if grasped and blocked:
            break
        if it >= 1 and d["opening"] < 0.012:
            break
    rb.log("final drawer opening %.4f" % rb.drawer()["opening"])
