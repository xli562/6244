def run(api):
    api.original()
    for _ in range(2):
        receipt = api.last()
        if not receipt:
            return
        used = receipt.get("steps_used")
        remaining = receipt.get("remaining")
        if used is None or remaining is None:
            return
        if min(remaining, 500 - used) <= 0:
            return
        if receipt.get("op") not in ("place", "placement"):
            return
        lift, gap = receipt.get("max_lift"), receipt.get("xy_gap")
        if lift is None or gap is None or lift < 0 or gap <= 0.01:
            return
        api.adjust("grasp_next" if lift <= 0.005 else "recenter")


def after(api, event):
    remaining = event.get("remaining")
    previous = event.get("previous_strategies")
    if remaining is None or remaining <= 0 or previous is None:
        return None
    if len(previous) >= 2:
        return None
    reason = event.get("reason")
    if reason not in ("no_effect", "wrong_direction", "shortfall"):
        return None

    before, now = event.get("before"), event.get("after")
    if not isinstance(before, dict) or not isinstance(now, dict):
        return None
    desired = event.get("desired")
    start, end = before.get("joint_fraction"), now.get("joint_fraction")
    if start is not None and end is not None:
        if desired not in ("low", "high"):
            return None
        if not (0 <= start <= 1 and 0 <= end <= 1):
            return None
        target = 0 if desired == "low" else 1
        if abs(target - end) <= 0.02:
            return None
        return "joint_" + desired

    if desired != "at_target":
        return None
    start, end = before.get("item_xyz"), now.get("item_xyz")
    gap, prior_gap = now.get("gap"), before.get("gap")
    motion = event.get("hand_motion")
    if start is None or end is None or gap is None or prior_gap is None:
        return None
    if len(start) != 3 or len(end) != 3:
        return None
    if gap <= 0.01 or prior_gap < 0 or motion is None or motion < 0:
        return None
    moved_squared = sum((a - b) ** 2 for a, b in zip(start, end))
    if moved_squared > 0.005 ** 2:
        return "recenter"
    if motion > 0.005:
        return "grasp_next"
    return None
