def run(api):
    api.original()
    for _ in range(2):
        r = api.last()
        if r is None:
            return
        if any(k not in r for k in
               ("op", "steps_used", "remaining", "max_lift", "xy_gap")):
            return
        used, left = r["steps_used"], r["remaining"]
        if used is None or left is None or not (0 <= used < 500):
            return
        if not (0 < left <= 500 - used):
            return

        op = r["op"]
        if op in ("open", "extend"):
            strategy = "joint_high"
        elif op in ("close", "retract"):
            strategy = "joint_low"
        elif op in ("pick", "place", "transfer"):
            lift, gap = r["max_lift"], r["xy_gap"]
            if lift is None or gap is None:
                return
            if lift == 0 and gap > 0:
                strategy = "grasp_next"
            elif lift > 0 and gap > 0:
                strategy = "recenter"
            else:
                return
        else:
            return
        api.adjust(strategy)
