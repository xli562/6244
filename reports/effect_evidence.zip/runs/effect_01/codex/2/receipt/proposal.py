def run(api):
    api.original()
    words = set(api.instruction.lower().replace("-", " ").split())
    used = set()
    for _ in range(2):
        r = api.last()
        if not isinstance(r, dict):
            return
        fields = ("steps_used", "remaining", "max_lift", "xy_gap")
        if any(not isinstance(r.get(k), (int, float)) for k in fields):
            return
        steps, remaining, lift, gap = (r[k] for k in fields)
        if not (0 <= steps < 500 and remaining > 0 and lift >= 0 and gap >= 0):
            return
        op = r.get("op")
        if not isinstance(op, str):
            return
        semantics = set(op.lower().replace("_", " ").replace("-", " ").split())
        if semantics & {"joint", "open", "close"}:
            direction = semantics & {"open", "close"}
            if not direction:
                direction = words & {"open", "close"}
            if len(direction) != 1:
                return
            strategy = "joint_high" if "open" in direction else "joint_low"
        elif semantics & {"pick", "place", "transfer"}:
            if gap <= 0:
                return
            strategy = "grasp_next" if lift == 0 else "recenter"
        else:
            return
        if strategy in used:
            return
        used.add(strategy)
        api.adjust(strategy)
