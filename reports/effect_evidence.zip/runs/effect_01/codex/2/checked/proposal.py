def run(api):
    api.original()
    for _ in range(2):
        r = api.last()
        if not r or r.get("op") not in ("place", "put", "relocate"):
            return
        used, left = r.get("steps_used"), r.get("remaining")
        lift, gap = r.get("max_lift"), r.get("xy_gap")
        if any(v is None for v in (used, left, lift, gap)):
            return
        if used < 0 or min(left, 500 - used) < 50:
            return
        # A lifted item with a persistent placement gap supports realignment.
        if lift <= 0.02 or gap <= 0.03:
            return
        api.adjust("recenter")


def after(api, event):
    e = event
    if e.get("reason") not in ("no_effect", "wrong_direction", "shortfall"):
        return None
    history = e.get("previous_strategies")
    left = e.get("remaining")
    if history is None or left is None or len(history) >= 2 or left < 50:
        return None

    before, current = e.get("before"), e.get("after")
    if not isinstance(before, dict) or not isinstance(current, dict):
        return None

    desired = e.get("desired")
    if desired in ("low", "high"):
        start = before.get("joint_fraction")
        end = current.get("joint_fraction")
        if start is None or end is None:
            return None
        if not (0 <= start <= 1 and 0 <= end <= 1):
            return None
        if desired == "low" and end > 0.05:
            return "joint_low"
        if desired == "high" and end < 0.95:
            return "joint_high"
        return None

    if desired != "at_target":
        return None
    start, end = before.get("item_xyz"), current.get("item_xyz")
    gap, motion = current.get("gap"), e.get("hand_motion")
    if start is None or end is None or gap is None or motion is None:
        return None
    if len(start) != 3 or len(end) != 3 or gap <= 0.02:
        return None
    displacement2 = sum((end[i] - start[i]) ** 2 for i in range(3))
    if displacement2 <= 0.005 ** 2:
        return "grasp_next" if motion >= 0.02 else None
    return "recenter"
