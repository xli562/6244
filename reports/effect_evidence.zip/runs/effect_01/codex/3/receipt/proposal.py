def run(api):
    api.original()
    spent = 0
    tried = set()

    for _ in range(2):
        r = api.last()
        if not isinstance(r, dict):
            return

        used, remaining = r.get("steps_used"), r.get("remaining")
        if not all(type(v) is int and v >= 0 for v in (used, remaining)):
            return
        spent += used  # Conservative if receipts report cumulative usage.
        if min(remaining, 500 - spent) <= 0:
            return

        op = r.get("op")
        if op == "open":
            strategy = "joint_high"
        elif op == "close":
            strategy = "joint_low"
        elif op in ("pick", "place", "pick_place"):
            lift, gap = r.get("max_lift"), r.get("xy_gap")
            if not all(type(v) in (int, float) and 0 <= v < float("inf")
                       for v in (lift, gap)):
                return
            if lift == 0:
                strategy = "grasp_next"
            elif gap > 0:
                strategy = "recenter"
            else:
                return
        else:
            return

        if strategy in tried:
            return
        tried.add(strategy)
        api.adjust(strategy)
