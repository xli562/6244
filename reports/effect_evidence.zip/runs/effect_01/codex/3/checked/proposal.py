def run(api):
    api.original()
    used = []
    for _ in range(2):
        r = api.last()
        if not r or min(r.get("remaining", 0),
                        500 - r.get("steps_used", 500)) < 25:
            return
        if r.get("op") not in ("place", "position", "transfer"):
            return
        gap, lift = r.get("xy_gap"), r.get("max_lift")
        if gap is None or lift is None or gap <= 0.02:
            return
        strategy = "recenter" if lift > 0.01 else "grasp_next"
        if strategy in used:
            return
        used.append(strategy)
        api.adjust(strategy)


def after(api, event):
    tried = event.get("previous_strategies", ())
    if len(tried) >= 2 or event.get("remaining", 0) < 25:
        return None
    if event.get("reason") not in ("no_effect", "wrong_direction", "shortfall"):
        return None

    before, current = event.get("before", {}), event.get("after", {})
    desired = event.get("desired")
    start, end = before.get("joint_fraction"), current.get("joint_fraction")
    if desired in ("low", "high") and start is not None and end is not None:
        if not (0 <= start <= 1 and 0 <= end <= 1):
            return None
        target = 0 if desired == "low" else 1
        if abs(end - target) <= 0.03:
            return None
        return "joint_low" if desired == "low" else "joint_high"

    if desired != "at_target":
        return None
    p, q = before.get("item_xyz"), current.get("item_xyz")
    gap = current.get("gap")
    if p is None or q is None or gap is None or gap <= 0.02:
        return None
    if len(p) != 3 or len(q) != 3:
        return None
    moved = sum((a - b) ** 2 for a, b in zip(p, q))
    if moved <= 0.005 ** 2:
        motion = event.get("hand_motion")
        if motion is None or motion < 0.01:
            return None
        return "grasp_next"
    if moved >= 0.01 ** 2:
        return "recenter"
    return None
