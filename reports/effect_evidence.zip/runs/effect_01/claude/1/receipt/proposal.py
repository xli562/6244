def run(api):
    api.original()
    w = set((api.instruction or "").lower().replace(",", " ").replace(".", " ").split())
    hi = len(w & {"open", "pull", "raise", "extend", "unfold"})
    lo = len(w & {"close", "shut", "push", "lower", "fold", "retract"})
    place = w & {"put", "place", "move", "stack", "insert", "drop", "transfer", "set", "pick"}
    tried = []
    for _ in range(2):
        r = api.last()
        if not isinstance(r, dict):
            return
        rem, used = r.get("remaining") or 0, r.get("steps_used") or 0
        if rem < max(40, min(used, 150)):
            return
        op = str(r.get("op") or "").lower()
        lift, gap = r.get("max_lift"), r.get("xy_gap")
        if ((hi or lo) and not place) or "joint" in op or "artic" in op:
            if not (hi or lo):
                return
            s = "joint_high" if hi >= lo else "joint_low"
            if s in tried:
                s = "repeat"
        else:
            if lift is None and gap is None:
                return
            if lift is not None and lift < 0.02:
                order = ["grasp_next", "recenter"]
            elif gap is not None and gap > 0.02:
                order = ["recenter", "grasp_next"]
            else:
                order = ["recenter", "repeat"]
            s = next((x for x in order if x not in tried), None)
        if s is None or s in tried:
            return
        tried.append(s)
        api.adjust(s)
