HIGH = {'open', 'pull', 'raise', 'lift', 'up', 'extend', 'unfold'}
LOW = {'close', 'shut', 'push', 'lower', 'down', 'retract', 'fold'}
MIN_STEPS, LIFT_OK, GAP_OK, MOVED = 40, 0.02, 0.03, 0.01


def words(text):
    return set(str(text or '').lower().replace(',', ' ').replace('.', ' ').split())


def direction(text):
    w = words(text)
    if w & LOW:
        return 'low'
    if w & HIGH:
        return 'high'
    return None


def dist(p, q):
    if p is None or q is None:
        return 0.0
    return sum((a - b) ** 2 for a, b in zip(p, q)) ** 0.5


def choose_from_receipt(r, instruction, tried):
    if r is None or (r.get('remaining') or 0) < MIN_STEPS:
        return None
    gap, lift = r.get('xy_gap'), r.get('max_lift')
    if gap is None:  # articulated role: drive toward the instructed endpoint
        d = direction(instruction)
        return 'joint_' + d if d else (None if 'repeat' in tried else 'repeat')
    if lift is None or lift < LIFT_OK:  # item never left support: change grasp
        return 'grasp_next'
    if gap > GAP_OK:  # carried but missed destination: realign
        return 'grasp_next' if tried.count('recenter') else 'recenter'
    return None if 'repeat' in tried else 'repeat'


def run(api):
    api.original()
    tried, last_gap = [], None
    for _ in range(2):
        r = api.last()
        if r is None:
            return
        gap = r.get('xy_gap')
        if tried and gap is not None and last_gap is not None and gap >= last_gap - 1e-3 \
                and tried[-1] == 'recenter':
            tried.append('recenter')  # no improvement; force a switch
        s = choose_from_receipt(r, api.instruction, tried)
        if s is None:
            return
        api.adjust(s)
        tried.append(s)
        last_gap = gap


def after(api, event):
    prev = list(event.get('previous_strategies') or [])
    if len(prev) >= 2 or (event.get('remaining') or 0) < MIN_STEPS:
        return None
    b, a = event.get('before') or {}, event.get('after') or {}
    reason, desired = event.get('reason'), event.get('desired')

    if 'joint_fraction' in a:  # articulated role
        if desired in ('low', 'high'):
            return 'joint_' + desired
        delta = (a.get('joint_fraction') or 0.0) - (b.get('joint_fraction') or 0.0)
        if reason == 'wrong_direction':
            return 'joint_low' if delta > 0 else 'joint_high'
        if reason == 'shortfall' and abs(delta) > 1e-3:
            return 'joint_high' if delta > 0 else 'joint_low'
        d = direction(event.get('instruction'))
        return 'joint_' + d if d else None

    if 'item_xyz' in a:  # placement
        gap = a.get('gap')
        if gap is not None and gap <= GAP_OK and reason != 'wrong_direction':
            return None
        moved = dist(b.get('item_xyz'), a.get('item_xyz')) > MOVED
        if not moved:
            return 'grasp_next'
        if prev.count('recenter') and (gap is None or gap >= (b.get('gap') or gap)):
            return 'grasp_next'
        return 'recenter'
    return None
