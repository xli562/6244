# Compact general recovery policy: operation semantics only, no object-specific logic.

GAP_TOL = 0.03    # m: placement counts as missed beyond this horizontal gap
LIFT_MIN = 0.02   # m: lifts below this mean the grasp never really held the item
MOVE_MIN = 0.01   # m: item displacement that counts as "moved"
MIN_STEPS = 25    # don't start a correction with less budget than this

HIGH_WORDS = {"open", "pull", "raise", "extend", "unfold", "lift"}
LOW_WORDS = {"close", "shut", "push", "lower", "retract", "fold"}


def words(*texts):
    out = set()
    for t in texts:
        for w in str(t or "").lower().replace("_", " ").replace("-", " ").split():
            out.add(w.strip(".,;:!?'\""))
    return out


def joint_goal(op, instruction):
    """Desired articulation endpoint from operation verbs: 'high', 'low' or None."""
    w = words(op, instruction)
    hi, lo = bool(w & HIGH_WORDS), bool(w & LOW_WORDS)
    if hi != lo:
        return "high" if hi else "low"
    return None


def enough(remaining):
    return remaining is not None and remaining >= MIN_STEPS


def choose(receipt, instruction, used):
    """Pick a strategy from an ordinary action receipt, or None if evidence is weak."""
    gap = receipt.get("xy_gap")
    if gap is not None:                       # placement-style operation
        if gap <= GAP_TOL:
            return None                       # nothing measurable to fix
        lift = receipt.get("max_lift")
        if lift is None or lift < LIFT_MIN:
            return "grasp_next"               # item likely never held
        return "recenter"                     # carried but missed destination
    goal = joint_goal(receipt.get("op"), instruction)
    return "joint_" + goal if goal else None  # articulated: drive to endpoint


def run(api):
    api.original()                            # prior planner; ends control if it succeeds
    used = []
    while len(used) < 2:
        r = api.last()
        if not r or not enough(r.get("remaining")):
            return
        s = choose(r, api.instruction, used)
        if s is None:
            return
        used.append(s)
        api.adjust(s)


def after(api, event):
    """Return a strategy immediately after a measured failed effect, or None."""
    prev = list(event.get("previous_strategies") or [])
    if len(prev) >= 2 or not enough(event.get("remaining")):
        return None
    before = event.get("before") or {}
    after_ = event.get("after") or {}
    reason = event.get("reason")
    desired = event.get("desired")

    # Articulated role: always prefer the desired joint endpoint.
    if "joint_fraction" in after_ or "joint_fraction" in before:
        goal = desired if desired in ("low", "high") else joint_goal(
            event.get("op"), event.get("instruction"))
        if goal:
            return "joint_" + goal
        return "repeat" if reason == "shortfall" else None

    # Placement: vary grasp if the item stayed put, realign if it moved but missed.
    b, a = before.get("item_xyz"), after_.get("item_xyz")
    if b is None or a is None:
        return None
    moved = sum((x - y) ** 2 for x, y in zip(a, b)) ** 0.5 > MOVE_MIN
    if not moved:
        return "grasp_next"
    gap = after_.get("gap")
    if gap is not None and gap <= GAP_TOL and reason != "wrong_direction":
        return None
    return "recenter"
