def run(api):
    api.original()
    r = api.last()
    text = (str((r or {}).get('op') or '') + ' ' + str(api.instruction or '')).lower()
    words = set(''.join(c if c.isalpha() else ' ' for c in text).split())
    tried = []
    for _ in range(2):
        if not isinstance(r, dict) or (r.get('remaining') or 0) < 40:
            return
        lift, gap = r.get('max_lift'), r.get('xy_gap')
        if words & {'close', 'shut'}:
            s = 'joint_low'
        elif words & {'open'}:
            s = 'joint_high'
        elif lift is None and gap is None:
            return
        elif lift is not None and lift < 0.02:
            s = 'grasp_next'
        elif gap is not None and gap > 0.03:
            s = 'recenter'
        else:
            s = 'repeat'
        if s in tried:
            s = {'grasp_next': 'recenter', 'recenter': 'repeat'}.get(s)
            if s is None or s in tried:
                return
        tried.append(s)
        api.adjust(s)
        r = api.last()
