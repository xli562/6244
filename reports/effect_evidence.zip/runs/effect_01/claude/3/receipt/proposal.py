OPEN_WORDS = ("open", "pull out", "pull open", "slide out", "raise", "unfold")
CLOSE_WORDS = ("close", "shut", "push in", "push closed", "slide in", "lower", "fold")
LIFT_MIN = 0.02      # m: below this the item was never really held
GAP_MAX = 0.03       # m: above this the item landed off-target
MIN_STEPS = 40       # floor on the step cost estimate for any correction


def _num(rec, key):
    v = rec.get(key) if rec else None
    return float(v) if isinstance(v, (int, float)) else 0.0


def _articulation_direction(text):
    t = (text or "").lower()
    o = max((t.rfind(w) for w in OPEN_WORDS), default=-1)
    c = max((t.rfind(w) for w in CLOSE_WORDS), default=-1)
    if o < 0 and c < 0:
        return None
    return "joint_high" if o > c else "joint_low"


def _choose(rec, instruction):
    op = str(rec.get("op") or "").lower()
    joint = _articulation_direction(op) or _articulation_direction(instruction)
    if joint and not any(w in op for w in ("pick", "place", "put", "move")):
        return joint
    lift, gap = _num(rec, "max_lift"), _num(rec, "xy_gap")
    if lift < LIFT_MIN:
        return "grasp_next"
    if gap > GAP_MAX:
        return "recenter"
    return "repeat"


def run(api):
    api.original()
    rec = api.last()
    for _ in range(2):
        if not rec:
            return
        remaining = _num(rec, "remaining")
        cost = max(_num(rec, "steps_used"), MIN_STEPS)
        if remaining < cost:
            return
        strategy = _choose(rec, api.instruction)
        api.adjust(strategy)
        new = api.last()
        if not new:
            return
        # If nothing measurable changed, a different correction is unlikely to be
        # justified by evidence; stop rather than burn the shared budget.
        if (strategy == "repeat"
                and _num(new, "max_lift") <= _num(rec, "max_lift")
                and _num(new, "xy_gap") >= _num(rec, "xy_gap")):
            return
        rec = new
