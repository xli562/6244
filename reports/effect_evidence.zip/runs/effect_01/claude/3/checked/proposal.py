MIN_STEPS = 30    # smallest remaining budget worth spending on a correction
LIFT_OK = 0.02    # m; item counts as lifted above this
GAP_OK = 0.03     # m; item counts as at the destination below this
MOVE_OK = 0.01    # m; item counts as displaced above this
HAND_OK = 0.005   # m; hand counts as having moved above this

HIGH = ('open', 'pull', 'raise', 'lift', 'extend', 'unfold')
LOW = ('close', 'shut', 'push', 'lower', 'retract', 'fold')
PLACE = ('place', 'put', 'set', 'stack', 'insert', 'drop', 'transfer', 'move')


def semantics(op, instruction=None):
    """Map an op (falling back to instruction verbs only) to 'high', 'low', 'place' or None."""
    for text in (op, instruction):
        words = str(text or '').lower().replace('_', ' ').split()
        for w in words:
            if w in HIGH:
                return 'high'
            if w in LOW:
                return 'low'
            if w in PLACE:
                return 'place'
    return None


def dist(p, q):
    try:
        return sum((float(a) - float(b)) ** 2 for a, b in zip(p, q)) ** 0.5
    except (TypeError, ValueError):
        return None


def affordable(remaining, cost=0):
    return (remaining or 0) >= max(MIN_STEPS, (cost or 0) // 2)


def choose(instruction, receipt, used):
    """Pick a correction from an ordinary action receipt, or None."""
    kind = semantics(receipt.get('op'), instruction)
    if kind in ('high', 'low'):
        return 'joint_' + kind
    if kind != 'place':
        return None
    lift, gap = receipt.get('max_lift'), receipt.get('xy_gap')
    if lift is None and gap is None:
        return None
    if lift is not None and lift < LIFT_OK:
        return 'grasp_next'               # never got the item up: change grasp
    if gap is not None and gap > GAP_OK:
        return 'recenter'                 # carried but missed: realign then place
    if 'repeat' not in used:
        return 'repeat'                   # near target but unfinished: retry same action
    return None


def run(api):
    api.original()                        # prior universal planner; ends control if it finishes
    used = []
    while len(used) < 2:
        r = api.last()
        if not r or not affordable(r.get('remaining'), r.get('steps_used')):
            return
        s = choose(api.instruction, r, used)
        if s is None:
            return
        api.adjust(s)
        used.append(s)


def after(api, event):
    """New deployment: called right after a failed intended effect; returns a strategy or None."""
    prev = event.get('previous_strategies') or []
    if len(prev) >= 2 or not affordable(event.get('remaining')):
        return None
    before, now = event.get('before') or {}, event.get('after') or {}
    desired, reason = event.get('desired'), event.get('reason')

    # Articulated role: always drive toward the desired joint endpoint.
    if 'joint_fraction' in now or 'joint_fraction' in before or desired in ('low', 'high'):
        d = desired if desired in ('low', 'high') else semantics(event.get('op'), event.get('instruction'))
        return 'joint_' + d if d in ('low', 'high') else None

    # Placement: use measured item displacement and residual gap.
    moved = dist(before.get('item_xyz'), now.get('item_xyz'))
    hand = event.get('hand_motion')
    if reason == 'no_effect' and hand is not None and hand < HAND_OK and 'repeat' not in prev:
        return 'repeat'                   # action barely executed: reissue it
    if moved is None or moved < MOVE_OK:
        return 'grasp_next'               # item stayed put: vary the grasp
    gap = now.get('gap')
    if (gap is not None and gap > GAP_OK) or reason in ('wrong_direction', 'shortfall'):
        return 'recenter'                 # item moved but missed: realign then place
    return 'recenter' if 'recenter' not in prev else 'grasp_next'
