def run(api):
    target = api.relative_target("desk_caddy_1", "right", "inside")
    api.arrange([("black_book_1", target)])
