def run(api):
    api.drawer("wooden_cabinet_1_top_region", "open")
    api.arrange([("akita_black_bowl_1", "wooden_cabinet_1_top_region")])
