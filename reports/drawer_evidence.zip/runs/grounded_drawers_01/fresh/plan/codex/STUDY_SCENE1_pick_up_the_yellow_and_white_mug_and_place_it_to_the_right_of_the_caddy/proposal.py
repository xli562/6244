def run(api):
    target = api.relative_target("desk_caddy_1", "right", "outside")
    api.arrange([("white_yellow_mug_1", target)])
