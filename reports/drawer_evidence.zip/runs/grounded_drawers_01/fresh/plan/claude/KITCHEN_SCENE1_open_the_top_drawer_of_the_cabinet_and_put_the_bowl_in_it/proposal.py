def run(api):
    # Open the top drawer of the cabinet
    api.drawer("wooden_cabinet_1_top_region", "open")
    # Put the bowl inside the opened top drawer
    api.arrange([("akita_black_bowl_1", "wooden_cabinet_1_top_region")])
