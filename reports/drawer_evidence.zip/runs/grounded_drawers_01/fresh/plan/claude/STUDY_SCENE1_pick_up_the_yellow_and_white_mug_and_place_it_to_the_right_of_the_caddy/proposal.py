def run(api):
    # "to the right of the caddy" -> a table location NEXT TO the caddy (outside),
    # not the caddy's right compartment (desk_caddy_1_right_contain_region).
    target = api.relative_target("desk_caddy_1", "right", "outside")
    if target is None:
        target = api.nearest(
            "study_table_desk_caddy_right_region",
            ["study_table_desk_caddy_right_region"],
        )
    if target is None:
        return api.fallback()
    api.arrange([("white_yellow_mug_1", target)])
