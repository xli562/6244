def run(api):
    # Close the top drawer of the cabinet (use the drawer's top region, not the countertop)
    api.drawer("wooden_cabinet_1_top_region", "close")
    # Put the black bowl on top of the cabinet (on its top surface, not inside a drawer)
    api.arrange([("akita_black_bowl_1", "wooden_cabinet_1_top_side")])
