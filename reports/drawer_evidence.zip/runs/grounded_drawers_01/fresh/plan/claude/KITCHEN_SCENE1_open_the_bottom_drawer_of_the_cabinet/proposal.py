def run(api):
    api.drawer("wooden_cabinet_1_bottom_region", "open")
