def run(api):
    # "right compartment of the caddy" -> a compartment IN the fixture -> relation 'inside'
    target = api.relative_target("desk_caddy_1", "right", "inside")
    if target is None:
        target = "desk_caddy_1_right_contain_region"
    api.arrange([("black_book_1", target)])
