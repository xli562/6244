def run(api):
    # "open the microwave": a hinged-door action, not a sliding drawer.
    # No shared skill supports it (api.drawer is for drawers only, and
    # arrange/relative_target are placement skills), so defer to the old policy.
    return api.fallback()
