import numpy as np
import math


def run(api):
    instruction = " ".join(
        api.instruction.lower().replace("-", " ").split()
    )
    names = list(api.names())
    bodies = [
        name for name in names
        if "region" not in name
        and not name.endswith("_side")
        and name.rsplit("_", 1)[-1].isdigit()
    ]

    cabinets = [name for name in bodies if "cabinet" in name]
    if "drawer" not in instruction or not cabinets:
        return api.fallback()

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        extra = {
            "akita black bowl": ["black bowl", "bowl"],
            "porcelain mug": ["white mug"],
            "white yellow mug": [
                "yellow and white mug", "white and yellow mug", "yellow mug"
            ],
            "red coffee mug": ["red mug"],
            "cream cheese": ["cream cheese box"],
            "black book": ["book"],
            "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        }
        return [base] + extra.get(base, [])

    def mentions(name, text):
        padded = " " + text + " "
        return [
            (padded.find(" " + alias + " "), len(alias))
            for alias in aliases(name)
            if " " + alias + " " in padded
        ]

    cabinet_matches = [
        name for name in cabinets if mentions(name, instruction)
    ]
    if len(cabinet_matches) == 1:
        cabinet = cabinet_matches[0]
    elif len(cabinets) == 1:
        cabinet = cabinets[0]
    else:
        return api.fallback()

    # Prepare the complete plan before issuing any physical commands.
    words = instruction.replace(",", " ").replace(".", " ").split()
    verbs = {"open", "close", "shut", "put", "place"}
    starts = [i for i, word in enumerate(words) if word in verbs]
    if not starts or starts[0] != 0:
        return api.fallback()

    clauses = [
        words[start:starts[i + 1] if i + 1 < len(starts) else len(words)]
        for i, start in enumerate(starts)
    ]
    plan = []
    last_region = None

    for clause in clauses:
        verb = clause[0]
        text = " ".join(clause)
        level = next(
            (word for word in clause if word in ("top", "middle", "bottom")),
            None,
        )

        if verb in ("open", "close", "shut"):
            if level is not None:
                region = cabinet + "_" + level + "_region"
            else:
                region = last_region
            if region not in names:
                return api.fallback()
            plan.append(("drawer", region, "open" if verb == "open" else "close"))
            last_region = region
            continue

        # "On top of it" refers to the cabinet's surface, not its top drawer.
        surface = (
            "on top" in text
            or "onto the top" in text
            or "on the cabinet" in text
            or "onto the cabinet" in text
            or ("on " in text and mentions(cabinet, text))
        )
        if surface:
            target = cabinet + "_top_side"
        elif any(word in clause for word in ("in", "into", "inside")):
            if level is not None:
                target = cabinet + "_" + level + "_region"
            else:
                target = last_region
        else:
            return api.fallback()

        if target not in names:
            return api.fallback()

        # Match only the object phrase, excluding the destination.
        destination_start = next(
            (
                i for i in range(1, len(clause))
                if clause[i] in ("on", "onto", "in", "into", "inside")
            ),
            len(clause),
        )
        object_text = " ".join(clause[1:destination_start])
        matches = []
        for name in bodies:
            if name == cabinet:
                continue
            hits = mentions(name, object_text)
            if hits:
                first, specificity = min(hits, key=lambda hit: (-hit[1], hit[0]))
                matches.append((first, specificity, name))

        if not matches:
            return api.fallback()

        # Ambiguous duplicate objects require the previous policy's resolver.
        for i, entry in enumerate(matches):
            if any(entry[:2] == other[:2] for other in matches[i + 1:]):
                return api.fallback()

        matches.sort(key=lambda entry: entry[0])
        for _, _, item in matches:
            plan.append(("place", item, target))

    # Earliest failure repaired: a close request must close the named drawer,
    # rather than opening it and placing the bowl inside before closing.
    # Execute sequentially; never replay completed actions through fallback.
    for kind, subject, destination in plan:
        if kind == "drawer":
            result = api.drawer(subject, destination)
        else:
            result = api.arrange([(subject, destination)])
        if result is False:
            return
