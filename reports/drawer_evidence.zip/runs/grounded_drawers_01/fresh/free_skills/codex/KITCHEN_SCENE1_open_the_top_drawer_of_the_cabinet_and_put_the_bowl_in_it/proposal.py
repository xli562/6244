import numpy as np
import math


def run(api):
    instruction = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n
        and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    def pos(name):
        return np.asarray(api.pos(name), dtype=float).copy()

    def move(point, steps=12):
        return api.move(np.asarray(point, dtype=float), steps=steps)

    def find(fragment, pool=None):
        return next(
            (n for n in (names if pool is None else pool) if fragment in n),
            None,
        )

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        mappings = {
            "akita black bowl": ["black bowl", "bowl"],
            "porcelain mug": ["white mug"],
            "white yellow mug": [
                "yellow and white mug", "white and yellow mug", "yellow mug"
            ],
            "red coffee mug": ["red mug", "red coffee mug"],
            "cream cheese": ["cream cheese box", "cream cheese"],
            "black book": ["black book", "book"],
            "desk caddy": ["desk caddy", "caddy"],
            "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
            "flat stove": ["stove"],
            "white cabinet": ["cabinet"],
            "wooden cabinet": ["cabinet"],
        }
        return [base] + mappings.get(base, [])

    def mention_index(name, text):
        indices = []
        padded = " " + text + " "
        for alias in aliases(name):
            index = padded.find(" " + alias + " ")
            if index >= 0:
                indices.append(index)
        return min(indices) if indices else -1

    def mentioned(name, text):
        return mention_index(name, text) >= 0

    def ordered_items(text, excluded=()):
        return sorted(
            [
                n for n in bodies
                if n not in excluded and mentioned(n, text)
            ],
            key=lambda n: mention_index(n, text),
        )

    def retreat():
        move(np.asarray(api.eef(), dtype=float) + [0., 0., 0.12], 10)

    def grasp_offset(item, attempt=0):
        offset = np.zeros(3)
        if "bowl" in item:
            offset[:] = [0.035, 0., 0.015]
        elif "mug" in item:
            offset[:] = [0.025, 0., 0.015]
        elif "book" in item:
            offset[2] = 0.005
        elif "moka" in item:
            offset[2] = 0.025
        if attempt:
            if "bowl" in item or "mug" in item:
                offset[0] *= -1.
            else:
                offset[0] += 0.018
                offset[2] -= 0.008
        return offset

    def placed(item, target, offset):
        p, q = pos(item), pos(target) + offset
        tolerance = 0.065
        if "basket" in target:
            tolerance = 0.09
        if "caddy" in target:
            tolerance = 0.045
        return (
            np.linalg.norm(p[:2] - q[:2]) < tolerance
            and -0.055 < p[2] - q[2] < 0.17
        )

    def transport(item, target, offset):
        offset = np.asarray(offset, dtype=float)
        for attempt in range(2):
            before = pos(item)
            lift = api.transfer(
                item,
                target,
                grasp=tuple(grasp_offset(item, attempt)),
                drop=tuple(offset + [0., 0., 0.08]),
            )
            after = pos(item)
            if placed(item, target, offset):
                return True

            hand = np.asarray(api.eef(), dtype=float)
            if (
                lift is not None and float(lift) > 0.025
                and np.linalg.norm(after - hand) < 0.10
                and after[2] > before[2] + 0.025
            ):
                relative = after - hand
                destination = pos(target) + offset
                move(destination - relative + [0., 0., 0.16], 16)
                move(destination - relative + [0., 0., 0.045], 12)
                api.grip(False)
                retreat()
                if placed(item, target, offset):
                    return True
            api.grip(False)
        return False

    def turn_stove(stove, on):
        knob = find("switch") or find("knob") or find("button")
        center = pos(knob) if knob else pos(stove) + [0., -0.105, 0.025]
        api.grip(False)
        move(center + [0., 0., 0.09], 12)
        move(center, 14)
        api.grip(True)
        api.action(
            [0., 0., 0., 0., 0., 1. if on else -1., 1.], steps=18
        )
        api.grip(False)
        retreat()

    cabinet = find("cabinet", bodies)

    if cabinet and "drawer" in instruction:
        # Repair the earliest subgoal: operate the named drawer with the
        # shared physical skill instead of guessing handle geometry.
        events = []
        for verb, kind in (
            ("open", "open"), ("close", "close"), ("shut", "close"),
            ("put", "place"), ("place", "place"), ("insert", "place"),
        ):
            start = 0
            while True:
                index = instruction.find(verb, start)
                if index < 0:
                    break
                end = index + len(verb)
                if (
                    (index == 0 or instruction[index - 1] == " ")
                    and (end == len(instruction) or instruction[end] == " ")
                ):
                    events.append((index, kind))
                start = end
        events.sort()

        default_level = next(
            (s for s in ("bottom", "middle", "top") if s in instruction),
            "bottom",
        )
        current_region = cabinet + "_" + default_level + "_region"
        plan = []
        for i, (index, kind) in enumerate(events):
            end = events[i + 1][0] if i + 1 < len(events) else len(instruction)
            clause = instruction[index:end]
            level = next(
                (s for s in ("bottom", "middle", "top")
                 if s + " drawer" in clause),
                None,
            )
            if level:
                current_region = cabinet + "_" + level + "_region"
            if current_region not in names:
                return api.fallback()
            if kind == "place":
                items = ordered_items(clause, (cabinet,))
                if not items:
                    return api.fallback()
                plan.append(("place", current_region, items))
            else:
                plan.append((kind, current_region, []))

        if not plan:
            return api.fallback()

        for kind, region, items in plan:
            if kind == "place":
                result = api.arrange([(item, region) for item in items])
            else:
                result = api.drawer(region, kind)
            if result is False:
                return
        return

    jobs = []
    basket = find("basket", bodies)
    caddy = find("caddy", bodies)
    stove = find("flat_stove", bodies)

    if basket and "basket" in instruction:
        target = find(basket + "_contain_region") or basket
        items = ordered_items(instruction, (basket,))
        for i, item in enumerate(items):
            x = (i - (len(items) - 1) / 2.) * 0.065
            jobs.append((item, target, np.array([x, 0., 0.])))

    elif caddy and "caddy" in instruction:
        side = next(
            (s for s in ("back", "front", "left", "right")
             if s in instruction),
            None,
        )
        if side:
            outside = any(
                phrase in instruction
                for phrase in (
                    "next to", "beside", "to the left of", "to the right of",
                    "in front of", "behind",
                )
            )
            target = api.relative_target(
                caddy, side, "outside" if outside else "inside"
            )
        else:
            target = find(caddy + "_contain_region")
        if target is None:
            return api.fallback()
        for item in ordered_items(instruction, (caddy,)):
            jobs.append((item, target, np.zeros(3)))

    elif "plate" in instruction and (
        "left" in instruction or "right" in instruction
    ):
        plates = [n for n in bodies if n.startswith("plate_")]
        used = set()
        sides = sorted(
            ("left", "right"),
            key=lambda side: instruction.find(side + " plate")
        )
        for side in sides:
            end = instruction.find(side + " plate")
            if end < 0:
                continue
            marker = find("plate_" + side + "_region")
            if marker is None or not plates:
                return api.fallback()
            target = api.nearest(marker, plates)
            start = max(
                instruction.rfind("put ", 0, end),
                instruction.rfind("place ", 0, end),
                0,
            )
            clause = instruction[start:end]
            matches = [
                n for n in bodies
                if n not in used and "mug" in n and mentioned(n, clause)
            ]
            if matches:
                item = max(
                    matches,
                    key=lambda n: max(
                        [len(a) for a in aliases(n) if a in clause] or [0]
                    ),
                )
                jobs.append((item, target, np.zeros(3)))
                used.add(item)

    elif stove and ("stove" in instruction or "on it" in instruction):
        target = find(stove + "_cook_region") or stove
        for item in ordered_items(instruction, (stove,)):
            jobs.append((item, target, np.zeros(3)))

    else:
        candidates = ordered_items(instruction)
        if len(candidates) >= 2:
            target_body = max(
                candidates,
                key=lambda n: max(instruction.rfind(a) for a in aliases(n)),
            )
            target = target_body
            if "cabinet" in target_body and (
                "on top" in instruction or "on the cabinet" in instruction
            ):
                target = find(target_body + "_top_side") or target_body
            elif " in " in instruction or " into " in instruction:
                target = find(target_body + "_contain_region") or target_body
            for item in candidates:
                if item != target_body:
                    jobs.append((item, target, np.zeros(3)))

    switch_index = -1
    on = False
    if stove:
        for phrase, state in (("turn on", True), ("turn off", False)):
            index = instruction.find(phrase)
            if index >= 0:
                switch_index, on = index, state
                break

    placement_index = min(
        [instruction.find(v) for v in ("put ", "place ", "insert ")
         if instruction.find(v) >= 0] or [len(instruction)]
    )
    switch_first = switch_index >= 0 and switch_index < placement_index

    if not jobs and switch_index < 0:
        return api.fallback()

    if switch_first:
        turn_stove(stove, on)

    for item, target, offset in jobs:
        if not transport(item, target, offset):
            return

    if switch_index >= 0 and not switch_first:
        turn_stove(stove, on)
