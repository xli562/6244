import numpy as np
import math


def run(api):
    instruction = " ".join(
        api.instruction.lower().replace("-", " ").split()
    )
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n
        and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    def find(fragment, pool=None):
        return next(
            (n for n in (names if pool is None else pool) if fragment in n),
            None,
        )

    # Targeted repair: the previous program produced no action for opening
    # a microwave. It is a hinged door, so do not apply the drawer skill.
    # Delegate before performing any actions, preserving instruction order.
    microwave = find("microwave", bodies)
    if microwave and "microwave" in instruction and (
        "open" in instruction or "close" in instruction
    ):
        return api.fallback()

    def pos(name):
        return np.asarray(api.pos(name), dtype=float).copy()

    def move(point, steps=12):
        return api.move(np.asarray(point, dtype=float), steps=steps)

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        mappings = {
            "akita black bowl": ["black bowl", "bowl"],
            "white bowl": ["white bowl", "bowl"],
            "porcelain mug": ["white mug"],
            "white yellow mug": [
                "yellow and white mug", "white and yellow mug", "yellow mug"
            ],
            "red coffee mug": ["red mug", "red coffee mug"],
            "cream cheese": ["cream cheese box", "cream cheese"],
            "black book": ["black book", "book"],
            "desk caddy": ["desk caddy", "caddy"],
            "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
            "flat stove": ["stove"],
            "white cabinet": ["cabinet"],
        }
        return [base] + mappings.get(base, [])

    def mentioned(name, text):
        padded = " " + text + " "
        return any(" " + a + " " in padded for a in aliases(name))

    def retreat():
        move(np.asarray(api.eef(), dtype=float) + [0., 0., 0.12], 10)

    def grasp_offset(item, attempt=0):
        offset = np.zeros(3)
        if "bowl" in item:
            offset[:] = [0.035, 0., 0.015]
        elif "mug" in item:
            offset[:] = [0.025, 0., 0.015]
        elif "book" in item:
            offset[2] = 0.005
        elif "moka" in item:
            offset[2] = 0.025
        if attempt:
            if "bowl" in item or "mug" in item:
                offset[0] *= -1.
            else:
                offset[0] += 0.018
                offset[2] -= 0.008
        return offset

    def placed(item, target, offset):
        p, q = pos(item), pos(target) + offset
        tolerance = 0.065
        if "basket" in target:
            tolerance = 0.09
        if "caddy" in target:
            tolerance = 0.045
        return (
            np.linalg.norm(p[:2] - q[:2]) < tolerance
            and -0.055 < p[2] - q[2] < 0.17
        )

    def transport(item, target, offset=None):
        offset = np.zeros(3) if offset is None else np.asarray(offset, float)
        for attempt in range(2):
            before = pos(item)
            lift = api.transfer(
                item,
                target,
                grasp=tuple(grasp_offset(item, attempt)),
                drop=tuple(offset + [0., 0., 0.08]),
            )
            after = pos(item)
            if placed(item, target, offset):
                return True

            hand = np.asarray(api.eef(), dtype=float)
            if (
                lift is not None and float(lift) > 0.025
                and np.linalg.norm(after - hand) < 0.10
                and after[2] > before[2] + 0.025
            ):
                relative = after - hand
                destination = pos(target) + offset
                move(destination - relative + [0., 0., 0.16], 16)
                move(destination - relative + [0., 0., 0.045], 12)
                api.grip(False)
                retreat()
                if placed(item, target, offset):
                    return True
            api.grip(False)
        return False

    # Use the named sliding-drawer skill. Unsupported combinations are
    # delegated before executing anything, rather than replayed after progress.
    cabinet = find("cabinet", bodies)
    if cabinet and "drawer" in instruction:
        levels = [
            level for level in ("bottom", "middle", "top")
            if level in instruction
        ]
        if len(levels) != 1:
            return api.fallback()
        region = find(cabinet + "_" + levels[0] + "_region")
        if region is None:
            return api.fallback()

        items = [
            n for n in bodies if n != cabinet and mentioned(n, instruction)
        ]
        opening = instruction.find("open")
        closing = instruction.find("close")
        putting = min(
            [instruction.find(v) for v in ("put ", "place ")
             if v in instruction] or [-1]
        )

        if closing >= 0 and (
            (opening >= 0 and closing < opening)
            or (putting >= 0 and closing < putting)
        ):
            return api.fallback()
        if items and putting < 0:
            return api.fallback()
        if opening >= 0:
            api.drawer(region, "open")
        if items:
            api.arrange([(item, region) for item in items])
        if closing >= 0:
            api.drawer(region, "close")
        if opening < 0 and closing < 0 and not items:
            return api.fallback()
        return

    # Let the previous policy handle switches and their sequencing.
    stove = find("flat_stove", bodies)
    if "turn on" in instruction or "turn off" in instruction:
        return api.fallback()

    jobs = []
    basket = find("basket", bodies)
    caddy = find("caddy", bodies)

    if basket and "basket" in instruction:
        target = find(basket + "_contain_region") or basket
        items = [
            n for n in bodies if n != basket and mentioned(n, instruction)
        ]
        for i, item in enumerate(items):
            x = (i - (len(items) - 1) / 2.) * 0.065
            jobs.append((item, target, np.array([x, 0., 0.])))

    elif caddy and "caddy" in instruction:
        directions = [
            s for s in ("back", "front", "left", "right")
            if s in instruction
        ]
        if len(directions) != 1:
            return api.fallback()
        outside = any(
            phrase in instruction
            for phrase in (
                "next to", "beside", "outside", "to the left of",
                "to the right of", "in front of", "behind"
            )
        )
        relation = "outside" if outside else "inside"
        target = api.relative_target(caddy, directions[0], relation)
        if target is None:
            return api.fallback()
        for item in bodies:
            if item != caddy and mentioned(item, instruction):
                jobs.append((item, target, np.zeros(3)))

    elif "plate" in instruction and (
        "left" in instruction or "right" in instruction
    ):
        plates = [n for n in bodies if n.startswith("plate_")]
        used = set()
        sides = sorted(
            ("left", "right"),
            key=lambda s: instruction.find(s + " plate")
            if s + " plate" in instruction else len(instruction),
        )
        for side in sides:
            end = instruction.find(side + " plate")
            if end < 0:
                continue
            marker = find("plate_" + side + "_region")
            if marker is None or not plates:
                return api.fallback()
            target = api.nearest(marker, plates)
            start = max(
                instruction.rfind("put ", 0, end),
                instruction.rfind("place ", 0, end),
                0,
            )
            clause = instruction[start:end]
            matches = [
                n for n in bodies
                if n not in used and "mug" in n and mentioned(n, clause)
            ]
            if matches:
                item = max(
                    matches,
                    key=lambda n: max(
                        [len(a) for a in aliases(n) if a in clause] or [0]
                    ),
                )
                jobs.append((item, target, np.zeros(3)))
                used.add(item)

    elif stove and ("stove" in instruction or "on it" in instruction):
        target = find(stove + "_cook_region") or stove
        for item in bodies:
            if item != stove and mentioned(item, instruction):
                jobs.append((item, target, np.zeros(3)))

    else:
        candidates = [n for n in bodies if mentioned(n, instruction)]
        if len(candidates) >= 2:
            target_body = max(
                candidates,
                key=lambda n: max(instruction.rfind(a) for a in aliases(n)),
            )
            target = target_body
            if "on top of" in instruction or "on the top of" in instruction:
                target = find(target_body + "_top_side") or target_body
            elif " in " in instruction or " into " in instruction:
                target = find(target_body + "_contain_region") or target_body
            for item in candidates:
                if item != target_body:
                    jobs.append((item, target, np.zeros(3)))

    if not jobs:
        return api.fallback()

    for item, target, offset in jobs:
        # Repair only the earliest unresolved placement. Never replay the
        # complete instruction after any preceding placements have succeeded.
        if not transport(item, target, offset):
            return
