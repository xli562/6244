import numpy as np
import math


def run(api):
    instruction = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n
        and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    def find(fragment, pool=None):
        pool = names if pool is None else pool
        return next((n for n in pool if fragment in n), None)

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        mapping = {
            "akita black bowl": ["black bowl", "bowl"],
            "porcelain mug": ["white mug"],
            "white yellow mug": [
                "yellow and white mug", "white and yellow mug", "yellow mug"
            ],
            "red coffee mug": ["red mug"],
            "cream cheese": ["cream cheese box"],
            "black book": ["book"],
            "desk caddy": ["caddy"],
            "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
            "flat stove": ["stove"],
            "white cabinet": ["cabinet"],
        }
        return [base] + mapping.get(base, [])

    def mentions(name, text):
        padded = " " + text + " "
        return [
            a for a in aliases(name)
            if " " + a + " " in padded
        ]

    def mentioned(name, text):
        return bool(mentions(name, text))

    def mention_index(name, text):
        matches = mentions(name, text)
        return min((text.find(a) for a in matches), default=len(text))

    def ordered_items(text, excluded=()):
        result = [
            n for n in bodies
            if n not in excluded and mentioned(n, text)
        ]
        return sorted(result, key=lambda n: mention_index(n, text))

    def relative_spec(text):
        # Outside relations must be recognized before compartment relations.
        for direction in ("left", "right", "front", "back"):
            if direction in ("left", "right"):
                phrases = [
                    "to the " + direction + " of",
                    "on the " + direction + " of",
                    direction + " of",
                ]
            elif direction == "front":
                phrases = ["in front of"]
            else:
                phrases = ["behind", "in back of", "at the back of"]
            if any(phrase in text for phrase in phrases):
                return direction, "outside"

        for direction in ("left", "right", "front", "back"):
            if direction in text.split():
                if any(word in text.split() for word in (
                    "in", "into", "inside", "compartment", "section"
                )):
                    return direction, "inside"
        return None

    def resolve_target(body, text):
        spatial = relative_spec(text)
        if spatial is not None:
            direction, relation = spatial
            return api.relative_target(body, direction, relation)

        if "cabinet" in body and any(
            phrase in text for phrase in ("on top", "on the top", "on the cabinet")
        ):
            return find(body + "_top_side")

        if "stove" in body:
            return find(body + "_cook_region") or body

        if "basket" in body or any(
            word in text.split() for word in ("in", "into", "inside")
        ):
            return find(body + "_contain_region") or body

        return body

    def split_actions(text):
        # Split only before verbs, preserving names such as "yellow and white".
        verbs = (
            "pick", "put", "place", "move", "open", "close",
            "turn", "switch", "push", "pull"
        )
        text = text.replace(",", " ").replace(".", " ").replace(";", " then ")
        for verb in verbs:
            for separator in ("and then ", "then ", "and "):
                text = text.replace(separator + verb + " ", "|" + verb + " ")
        return [" ".join(part.split()) for part in text.split("|") if part.strip()]

    clauses = split_actions(instruction)
    plan = []
    pending_items = []
    last_target = None
    last_drawer = None

    for clause in clauses:
        words = clause.split()
        cabinet = find("cabinet", bodies)
        fixture = next(
            (
                n for n in bodies
                if ("caddy" in n or "basket" in n)
                and mentioned(n, clause)
            ),
            None,
        )

        drawer_reference = (
            "drawer" in clause
            or (
                last_drawer is not None
                and any(word in words for word in ("it", "inside"))
            )
        )

        if cabinet and drawer_reference:
            level = next(
                (s for s in ("bottom", "middle", "top") if s in words),
                None,
            )
            if level is not None:
                region = find(cabinet + "_" + level + "_region")
            else:
                region = last_drawer or find(cabinet + "_bottom_region")
            if region is None:
                return api.fallback()

            last_drawer = region
            last_target = region
            if words[0] in ("open", "close"):
                plan.append(("drawer", region, words[0]))
                continue

            items = ordered_items(clause, (cabinet,)) or pending_items
            if not items:
                return api.fallback()
            for item in items:
                plan.append(("place", item, region))
            pending_items = []
            continue

        # Unsupported manipulations retain the previous policy. Planning occurs
        # before execution, so fallback cannot replay completed actions.
        if words[0] in ("turn", "switch", "push", "pull", "open", "close"):
            return api.fallback()

        candidates = ordered_items(clause)

        # "Pick up X and place it ..." is one placement, not two grasps.
        if clause.startswith("pick up ") and not any(
            phrase in clause for phrase in (
                " on ", " in ", " into ", " inside ", " to ", " behind "
            )
        ):
            pending_items = candidates
            continue

        target = None
        target_body = None

        if fixture is not None:
            target_body = fixture
            target = resolve_target(fixture, clause)

        elif "plate" in clause and any(s in words for s in ("left", "right")):
            plates = [n for n in bodies if n.startswith("plate_")]
            side = next(s for s in ("left", "right") if s in words)
            marker = find("plate_" + side + "_region")
            if marker is not None and plates:
                target_body = api.nearest(marker, plates)
                target = target_body

        elif candidates:
            if len(candidates) >= 2 or pending_items:
                target_body = candidates[-1]
                target = resolve_target(target_body, clause)
            elif any(phrase in clause for phrase in ("on it", "into it", "inside it")):
                target = last_target

        elif last_target is not None:
            target = last_target

        if target is None:
            return api.fallback()

        items = [n for n in candidates if n != target_body]
        if not items:
            items = [n for n in pending_items if n != target_body]
        if not items:
            return api.fallback()

        for item in items:
            plan.append(("place", item, target))
        pending_items = []
        last_target = target

    if pending_items or not plan:
        return api.fallback()

    # Execute in instruction order. Shared skills handle physical manipulation.
    # In particular, "right of the caddy" uses an outside table region, whereas
    # "in the right compartment" uses an inside region.
    for kind, subject, destination in plan:
        if kind == "drawer":
            result = api.drawer(subject, destination)
        else:
            result = api.arrange([(subject, destination)])

        # Stop at an explicitly reported failure; never replay prior successes.
        if result is False:
            return
