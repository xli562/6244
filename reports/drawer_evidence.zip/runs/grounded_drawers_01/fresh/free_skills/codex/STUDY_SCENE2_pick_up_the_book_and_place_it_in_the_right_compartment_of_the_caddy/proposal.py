import numpy as np
import math


def run(api):
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n
        and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    def find(fragment):
        return next((n for n in names if fragment in n), None)

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        mapping = {
            "akita black bowl": ["black bowl", "bowl"],
            "porcelain mug": ["white mug", "mug"],
            "white yellow mug": [
                "yellow and white mug", "white and yellow mug",
                "yellow mug", "mug",
            ],
            "red coffee mug": ["red coffee mug", "red mug", "mug"],
            "cream cheese": ["cream cheese box", "cream cheese"],
            "black book": ["black book", "book"],
            "desk caddy": ["desk caddy", "caddy"],
            "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
            "flat stove": ["stove"],
            "white cabinet": ["cabinet"],
        }
        return list(set([base] + mapping.get(base, [])))

    def mentions(clause):
        padded = " " + clause + " "
        hits = []
        for body in bodies:
            for alias in aliases(body):
                needle = " " + alias + " "
                start = 0
                while True:
                    index = padded.find(needle, start)
                    if index < 0:
                        break
                    hits.append((index, index + len(needle) - 2, body))
                    start = index + 1

        # Prefer "red coffee mug" to the overlapping generic "mug".
        hits.sort(key=lambda h: (-(h[1] - h[0]), h[0]))
        selected = []
        for hit in hits:
            if not any(
                hit[0] <= old[1] and old[0] <= hit[1]
                for old in selected
            ):
                selected.append(hit)
        return sorted(selected)

    def unique(items):
        return list(dict.fromkeys(items))

    # Separate actions at verb boundaries without losing spatial wording.
    words = text.split()
    starts = []
    verbs = {
        "pick", "put", "place", "move", "insert", "stack",
        "open", "close", "shut", "turn", "switch",
    }
    for i, word in enumerate(words):
        if word.strip(",.;") in verbs:
            starts.append(i)

    if not starts:
        return api.fallback()

    clauses = []
    for j, start in enumerate(starts):
        stop = starts[j + 1] if j + 1 < len(starts) else len(words)
        clauses.append(" ".join(words[start:stop]).strip(" ,.;"))

    plan = []
    carried = []
    last_fixture = None
    last_drawer = None
    unsupported = False

    for clause in clauses:
        verb = clause.split()[0]
        hits = mentions(clause)
        objects = unique([h[2] for h in hits])

        if verb == "pick":
            carried = objects
            continue

        if verb in ("turn", "switch"):
            unsupported = True
            break

        if verb in ("open", "close", "shut"):
            cabinet = next(
                (n for n in objects if "cabinet" in n), None
            )
            cabinet = cabinet or next(
                (n for n in bodies if "cabinet" in n), None
            )
            level = next(
                (s for s in ("top", "middle", "bottom")
                 if s in clause.split()),
                None,
            )
            region = None
            if cabinet and level:
                region = find(cabinet + "_" + level + "_region")
            if region is None and level is None:
                region = last_drawer
            if region is None:
                unsupported = True
                break
            plan.append(("drawer", region,
                         "open" if verb == "open" else "close"))
            last_drawer = region
            last_fixture = cabinet
            continue

        # The destination follows the final placement preposition.
        padded = " " + clause + " "
        separators = [
            " into ", " inside ", " in ", " onto ", " on ", " to ",
        ]
        boundaries = [
            (padded.find(separator), separator)
            for separator in separators
            if padded.find(separator) >= 0
        ]
        if not boundaries:
            unsupported = True
            break

        boundary, separator = min(boundaries, key=lambda x: x[0])
        source_text = padded[:boundary].strip()
        destination_text = padded[boundary + len(separator):].strip()

        items = unique([h[2] for h in mentions(source_text)])
        if not items:
            items = list(carried)

        destination_hits = mentions(destination_text)
        reference = destination_hits[-1][2] if destination_hits else None
        if reference is None:
            if "drawer" in destination_text:
                reference = last_fixture or next(
                    (n for n in bodies if "cabinet" in n), None
                )
            elif any(w in destination_text.split() for w in ("it", "there")):
                reference = last_fixture

        target = None
        if reference is not None:
            direction = next(
                (w.strip(",.;") for w in destination_text.split()
                 if w.strip(",.;") in ("left", "right", "front", "back")),
                None,
            )
            outside = any(
                phrase in destination_text
                for phrase in (
                    "next to", "beside", "to the left of",
                    "to the right of", "in front of", "behind",
                    "at the back of",
                )
            )
            if "behind" in destination_text:
                direction = "back"

            if "drawer" in destination_text:
                level = next(
                    (s for s in ("top", "middle", "bottom")
                     if s in destination_text.split()),
                    None,
                )
                target = (
                    find(reference + "_" + level + "_region")
                    if level else last_drawer
                )
            elif (
                "cabinet" in reference
                and ("top" in destination_text or separator in (" on ", " onto "))
            ):
                target = find(reference + "_top_side")
            elif direction and ("caddy" in reference or outside):
                # Repair the earliest failed subgoal: resolve the requested
                # compartment through the shared spatial skill.
                target = api.relative_target(
                    reference, direction,
                    "outside" if outside else "inside",
                )
            elif direction and "plate" in reference:
                marker = find("plate_" + direction + "_region")
                plates = [n for n in bodies if n.startswith("plate_")]
                if marker and plates:
                    target = api.nearest(marker, plates)
            elif "stove" in reference:
                target = find(reference + "_cook_region") or reference
            elif separator in (" in ", " into ", " inside "):
                target = find(reference + "_contain_region") or reference
            else:
                target = reference

        if not items or target is None:
            unsupported = True
            break

        for item in items:
            if item != reference:
                plan.append(("place", item, target))
        carried = items
        last_fixture = reference

    # Fall back before executing any partial plan, preserving action order.
    if unsupported or not plan:
        return api.fallback()

    for kind, first, second in plan:
        if kind == "drawer":
            result = api.drawer(first, second)
        else:
            # Use the shared physical placement skill rather than the old
            # book grasp offsets. Never replay completed placements.
            result = api.arrange([(first, second)])
        if result is False:
            return
