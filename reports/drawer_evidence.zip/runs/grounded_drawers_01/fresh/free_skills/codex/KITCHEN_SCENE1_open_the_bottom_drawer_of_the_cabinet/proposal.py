import numpy as np
import math


def run(api):
    instruction = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n
        and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    def find(fragment, pool=None):
        pool = names if pool is None else pool
        return next((n for n in pool if fragment in n), None)

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        mappings = {
            "akita black bowl": ["black bowl", "bowl"],
            "porcelain mug": ["white mug"],
            "white yellow mug": [
                "yellow and white mug", "white and yellow mug", "yellow mug"
            ],
            "red coffee mug": ["red mug"],
            "cream cheese": ["cream cheese box"],
            "black book": ["book"],
            "desk caddy": ["caddy"],
            "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
            "flat stove": ["stove"],
            "white cabinet": ["cabinet"],
            "wooden cabinet": ["cabinet"],
        }
        return [base] + mappings.get(base, [])

    def mentioned(name, text):
        return any(a in text for a in aliases(name))

    def pos(name):
        return np.asarray(api.pos(name), dtype=float).copy()

    def move(point, steps=12):
        return api.move(np.asarray(point, dtype=float), steps=steps)

    def retreat():
        move(np.asarray(api.eef(), dtype=float) + [0., 0., 0.12], 10)

    def grasp_offset(item, attempt=0):
        offset = np.zeros(3)
        if "bowl" in item:
            offset[:] = [0.035, 0., 0.015]
        elif "mug" in item:
            offset[:] = [0.025, 0., 0.015]
        elif "book" in item:
            offset[2] = 0.005
        elif "moka" in item:
            offset[2] = 0.025
        if attempt:
            if "bowl" in item or "mug" in item:
                offset[0] *= -1.
            else:
                offset[0] += 0.018
                offset[2] -= 0.008
        return offset

    def placed(item, target, offset):
        p, q = pos(item), pos(target) + offset
        tolerance = 0.065
        if "basket" in target:
            tolerance = 0.09
        if "caddy" in target:
            tolerance = 0.045
        return (
            np.linalg.norm(p[:2] - q[:2]) < tolerance
            and -0.055 < p[2] - q[2] < 0.17
        )

    def transport(item, target, offset=None):
        offset = np.zeros(3) if offset is None else np.asarray(offset, float)
        for attempt in range(2):
            before = pos(item)
            lift = api.transfer(
                item,
                target,
                grasp=tuple(grasp_offset(item, attempt)),
                drop=tuple(offset + [0., 0., 0.08]),
            )
            after = pos(item)
            if placed(item, target, offset):
                return True
            hand = np.asarray(api.eef(), dtype=float)
            if (
                lift is not None and float(lift) > 0.025
                and np.linalg.norm(after - hand) < 0.10
                and after[2] > before[2] + 0.025
            ):
                relative = after - hand
                destination = pos(target) + offset
                move(destination - relative + [0., 0., 0.16], 16)
                move(destination - relative + [0., 0., 0.045], 12)
                api.grip(False)
                retreat()
                if placed(item, target, offset):
                    return True
            api.grip(False)
        return False

    cabinet = find("cabinet", bodies)

    # Repair the earliest failed subgoal: use the drawer skill with the
    # exact drawer region, instead of guessing the handle position.
    if cabinet and "drawer" in instruction:
        clauses = []
        start = 0
        action_words = (
            "open", "close", "shut", "put", "place", "pick", "take", "insert"
        )
        words = instruction.split()
        for i, word in enumerate(words):
            if word in action_words and i > start:
                clauses.append(" ".join(words[start:i]))
                start = i
        clauses.append(" ".join(words[start:]))

        default_level = next(
            (s for s in ("bottom", "middle", "top") if s in instruction),
            "bottom",
        )
        level = default_level
        pending_items = []

        # Validate the regions before taking any actions.
        for clause in clauses:
            selected = next(
                (s for s in ("bottom", "middle", "top") if s in clause),
                level,
            )
            region = cabinet + "_" + selected + "_region"
            if region not in names:
                api.fallback()
                return
            level = selected

        level = default_level
        for clause in clauses:
            level = next(
                (s for s in ("bottom", "middle", "top") if s in clause),
                level,
            )
            region = cabinet + "_" + level + "_region"
            first = clause.split()[0] if clause.split() else ""
            items = [
                n for n in bodies
                if n != cabinet and mentioned(n, clause)
            ]

            if first == "open":
                result = api.drawer(region, "open")
                if result is False:
                    return
            elif first in ("close", "shut"):
                result = api.drawer(region, "close")
                if result is False:
                    return
            elif first in ("pick", "take"):
                pending_items = items
            elif first in ("put", "place", "insert"):
                items = items or pending_items
                if not items:
                    return
                result = api.arrange([(item, region) for item in items])
                if result is False:
                    return
                pending_items = []
        return

    def turn_stove(stove, on=True):
        knob = find("switch") or find("knob") or find("button")
        center = pos(knob) if knob else pos(stove) + [0., -0.105, 0.025]
        api.grip(False)
        move(center + [0., 0., 0.09], 12)
        move(center, 14)
        api.grip(True)
        api.action(
            [0., 0., 0., 0., 0., 1. if on else -1., 1.],
            steps=18,
        )
        api.grip(False)
        retreat()

    stove = find("flat_stove", bodies)
    switch_at = -1
    if stove:
        switch_at = instruction.find("turn on")
        if switch_at < 0:
            switch_at = instruction.find("turn off")
    placement_at = min(
        [instruction.find(w) for w in ("put ", "place ")
         if instruction.find(w) >= 0] or [len(instruction)]
    )
    switch_first = switch_at >= 0 and switch_at < placement_at
    if switch_first:
        turn_stove(stove, "turn on" in instruction)

    jobs = []
    basket = find("basket", bodies)
    caddy = find("caddy", bodies)

    if basket and "basket" in instruction:
        target = find(basket + "_contain_region") or basket
        items = [
            n for n in bodies if n != basket and mentioned(n, instruction)
        ]
        for i, item in enumerate(items):
            x = (i - (len(items) - 1) / 2.) * 0.065
            jobs.append((item, target, np.array([x, 0., 0.])))

    elif caddy and "caddy" in instruction:
        side = next(
            (s for s in ("back", "front", "left", "right")
             if s in instruction),
            "back",
        )
        outside = any(
            phrase in instruction
            for phrase in (
                "next to", "to the left of", "to the right of",
                "in front of", "behind",
            )
        )
        if "behind" in instruction:
            side = "back"
        target = api.relative_target(
            caddy, side, "outside" if outside else "inside"
        )
        if target is None:
            api.fallback()
            return
        for item in bodies:
            if item != caddy and mentioned(item, instruction):
                jobs.append((item, target, np.zeros(3)))

    elif "plate" in instruction and (
        "left" in instruction or "right" in instruction
    ):
        plates = [n for n in bodies if n.startswith("plate_")]
        used = set()
        ordered_sides = sorted(
            ("left", "right"),
            key=lambda s: instruction.find(s + " plate")
            if s + " plate" in instruction else len(instruction),
        )
        for side in ordered_sides:
            marker = find("plate_" + side + "_region")
            end = instruction.find(side + " plate")
            if marker is None or not plates or end < 0:
                continue
            target = api.nearest(marker, plates)
            start = max(
                instruction.rfind("put ", 0, end),
                instruction.rfind("place ", 0, end),
                0,
            )
            clause = instruction[start:end]
            matches = [
                n for n in bodies
                if n not in used and "mug" in n and mentioned(n, clause)
            ]
            if matches:
                item = max(
                    matches,
                    key=lambda n: max(
                        [len(a) for a in aliases(n) if a in clause] or [0]
                    ),
                )
                jobs.append((item, target, np.zeros(3)))
                used.add(item)

    elif cabinet and any(
        phrase in instruction
        for phrase in ("on top", "top of the cabinet", "top of the wooden cabinet")
    ):
        target = cabinet + "_top_side"
        if target in names:
            for item in bodies:
                if item != cabinet and mentioned(item, instruction):
                    jobs.append((item, target, np.zeros(3)))

    elif stove and ("stove" in instruction or "on it" in instruction):
        target = find(stove + "_cook_region") or stove
        for item in bodies:
            if item != stove and mentioned(item, instruction):
                jobs.append((item, target, np.zeros(3)))

    else:
        candidates = [n for n in bodies if mentioned(n, instruction)]
        if len(candidates) >= 2:
            target_body = max(
                candidates,
                key=lambda n: max(instruction.rfind(a) for a in aliases(n)),
            )
            target = target_body
            if " in " in instruction or " into " in instruction:
                target = find(target_body + "_contain_region") or target_body
            for item in candidates:
                if item != target_body:
                    jobs.append((item, target, np.zeros(3)))

    for item, target, offset in jobs:
        if not transport(item, target, offset):
            return

    if switch_at >= 0 and not switch_first:
        turn_stove(stove, "turn on" in instruction)
    elif not jobs and switch_at < 0:
        api.fallback()
