import math
import numpy as np


def run(api):
    instruction = " ".join(
        api.instruction.lower().replace("-", " ").split()
    )
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n
        and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    def pos(name):
        return np.asarray(api.pos(name), dtype=float).copy()

    def move(point, steps=12):
        return api.move(np.asarray(point, dtype=float), steps=steps)

    def find(fragment, pool=None):
        pool = names if pool is None else pool
        if fragment in pool:
            return fragment
        return next((n for n in pool if fragment in n), None)

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        mappings = {
            "akita black bowl": ["black bowl", "bowl"],
            "porcelain mug": ["white mug"],
            "white yellow mug": [
                "yellow and white mug", "white and yellow mug", "yellow mug"
            ],
            "red coffee mug": ["red mug"],
            "cream cheese": ["cream cheese box"],
            "black book": ["book"],
            "desk caddy": ["caddy"],
            "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
            "flat stove": ["stove"],
            "white cabinet": ["cabinet"],
            "wooden cabinet": ["cabinet"],
        }
        return [base] + mappings.get(base, [])

    def mentioned(name, text):
        text = " " + text + " "
        return any(" " + a + " " in text for a in aliases(name))

    def retreat(height=0.12):
        move(np.asarray(api.eef(), float) + [0., 0., height], 10)

    def grasp_offset(item, attempt=0):
        offset = np.zeros(3)
        if "bowl" in item:
            offset[:] = [0.035, 0., 0.015]
        elif "mug" in item:
            offset[:] = [0.025, 0., 0.015]
        elif "book" in item:
            offset[2] = 0.005
        elif "moka" in item:
            offset[2] = 0.025
        if attempt:
            if "bowl" in item or "mug" in item:
                offset[0] *= -1.
            else:
                offset += [0.018, 0., -0.008]
        return offset

    def placed(item, target, offset):
        delta = pos(item) - (pos(target) + offset)
        tolerance = 0.065
        if "basket" in target:
            tolerance = 0.09
        elif "caddy" in target:
            tolerance = 0.045
        return (
            np.linalg.norm(delta[:2]) < tolerance
            and -0.055 < delta[2] < 0.17
        )

    def transport(item, target, offset=None):
        offset = np.zeros(3) if offset is None else np.asarray(offset, float)
        for attempt in range(2):
            before = pos(item)
            lift = api.transfer(
                item, target,
                grasp=tuple(grasp_offset(item, attempt)),
                drop=tuple(offset + [0., 0., 0.08]),
            )
            after = pos(item)
            if placed(item, target, offset):
                return True

            hand = np.asarray(api.eef(), float)
            if (
                lift is not None and float(lift) > 0.025
                and np.linalg.norm(after - hand) < 0.10
                and after[2] > before[2] + 0.025
            ):
                relative = after - hand
                destination = pos(target) + offset
                move(destination - relative + [0., 0., 0.16], 16)
                move(destination - relative + [0., 0., 0.045], 12)
                api.grip(False)
                retreat()
                if placed(item, target, offset):
                    return True
            api.grip(False)
        return False

    def drawer_open(region):
        initial = pos(region)
        # Repair the earliest subgoal: verify handle acquisition with a
        # short pull before committing to the full opening motion.
        # The cabinet's top_side is a surface, not a drawer handle.
        probes = [
            (np.array([0., -0.145, 0.015]), np.array([0., -1., 0.])),
            (np.array([0., -0.170, -0.015]), np.array([0., -1., 0.])),
            (np.array([0., 0.145, 0.015]), np.array([0., 1., 0.])),
        ]
        best_direction = None
        best_offset = None

        for offset, outward in probes:
            current = pos(region)
            displacement = current - initial
            if np.linalg.norm(displacement[:2]) > 0.10:
                return initial, True, best_direction, best_offset

            handle = current + offset
            api.grip(False)
            hand = np.asarray(api.eef(), float)
            safe_z = max(hand[2], handle[2] + 0.11)
            move([hand[0], hand[1], safe_z], 7)
            approach = handle + outward * 0.075
            move([approach[0], approach[1], safe_z], 9)
            move(approach, 8)
            move(handle, 10)
            api.grip(True)

            acquired_at = pos(region)
            hand = np.asarray(api.eef(), float)
            move(hand + outward * 0.055, 12)
            motion = pos(region) - acquired_at
            along = float(np.dot(motion, outward))

            if along > 0.012:
                best_direction, best_offset = outward, offset
                opened_distance = float(np.dot(pos(region) - initial, outward))
                remaining = max(0., 0.17 - opened_distance)
                if remaining > 0.005:
                    hand = np.asarray(api.eef(), float)
                    move(hand + outward * remaining, 22)

                opened_distance = float(np.dot(pos(region) - initial, outward))
                api.grip(False)
                move(np.asarray(api.eef(), float) + outward * 0.045, 6)
                retreat()
                if opened_distance > 0.10:
                    return initial, True, outward, offset
                # Preserve partial opening and reacquire the moved handle.
            else:
                api.grip(False)
                move(np.asarray(api.eef(), float) + outward * 0.05, 6)
                retreat(0.09)

        return initial, False, best_direction, best_offset

    def drawer_close(region, initial, outward, offset):
        if outward is None:
            return
        travel = float(np.dot(pos(region) - initial, outward))
        if travel < 0.025:
            return
        handle = pos(region) + offset
        api.grip(True)
        move(handle + outward * 0.065 + [0., 0., 0.07], 10)
        move(handle + outward * 0.035, 10)
        move(handle - outward * (travel + 0.015), 24)
        retreat()
        api.grip(False)

    def turn_stove(stove, on=True):
        knob = find("switch") or find("knob") or find("button")
        center = pos(knob) if knob else pos(stove) + [0., -0.105, 0.025]
        api.grip(False)
        move(center + [0., 0., 0.09], 12)
        move(center, 14)
        api.grip(True)
        api.action(
            [0., 0., 0., 0., 0., 1. if on else -1., 1.], steps=18
        )
        api.grip(False)
        retreat()

    stove = find("flat_stove", bodies)
    if stove and ("turn on" in instruction or "turn off" in instruction):
        turn_stove(stove, "turn on" in instruction)

    cabinet = find("cabinet", bodies)
    if cabinet and "drawer" in instruction:
        level = next(
            (s for s in ("bottom", "middle", "top") if s in instruction),
            "bottom",
        )
        region = find(cabinet + "_" + level + "_region")
        if region is None:
            return
        items = [
            n for n in bodies
            if n != cabinet and mentioned(n, instruction)
        ]
        initial, opened, outward, handle_offset = drawer_open(region)
        if not opened:
            return
        # Opening is now complete. Placement retries never reopen the drawer.
        for item in items:
            if not transport(item, region, [0., 0., 0.015]):
                return
        if "close" in instruction:
            drawer_close(region, initial, outward, handle_offset)
        return

    jobs = []
    basket = find("basket", bodies)
    caddy = find("caddy", bodies)

    if basket and "basket" in instruction:
        target = find(basket + "_contain_region") or basket
        items = [
            n for n in bodies
            if n != basket and mentioned(n, instruction)
        ]
        for i, item in enumerate(items):
            x = (i - (len(items) - 1) / 2.) * 0.065
            jobs.append((item, target, np.array([x, 0., 0.])))

    elif caddy and "caddy" in instruction:
        side = next(
            (s for s in ("back", "front", "left", "right") if s in instruction),
            "back",
        )
        target = find(caddy + "_" + side + "_contain_region") or caddy
        for item in bodies:
            if item != caddy and mentioned(item, instruction):
                jobs.append((item, target, np.zeros(3)))

    elif "plate" in instruction and (
        "left" in instruction or "right" in instruction
    ):
        plates = [n for n in bodies if n.startswith("plate_")]
        used = set()
        for side in ("left", "right"):
            marker = find("plate_" + side + "_region")
            if marker is None or not plates:
                continue
            target = min(
                plates, key=lambda n: np.linalg.norm(pos(n) - pos(marker))
            )
            end = instruction.find(side + " plate")
            if end < 0:
                continue
            start = max(
                instruction.rfind("put ", 0, end),
                instruction.rfind("place ", 0, end), 0,
            )
            clause = instruction[start:end]
            matches = [
                n for n in bodies
                if n not in used and "mug" in n and mentioned(n, clause)
            ]
            if matches:
                item = max(
                    matches,
                    key=lambda n: max(
                        [len(a) for a in aliases(n) if a in clause] or [0]
                    ),
                )
                jobs.append((item, target, np.zeros(3)))
                used.add(item)

    elif stove and ("stove" in instruction or "on it" in instruction):
        target = find(stove + "_cook_region") or stove
        for item in bodies:
            if item != stove and mentioned(item, instruction):
                jobs.append((item, target, np.zeros(3)))

    else:
        candidates = [n for n in bodies if mentioned(n, instruction)]
        if len(candidates) >= 2:
            target_body = max(
                candidates,
                key=lambda n: max(instruction.rfind(a) for a in aliases(n)),
            )
            target = target_body
            if " in " in instruction or " into " in instruction:
                target = find(target_body + "_contain_region") or target_body
            for item in candidates:
                if item != target_body:
                    jobs.append((item, target, np.zeros(3)))

    for item, target, offset in jobs:
        if not transport(item, target, offset):
            return
