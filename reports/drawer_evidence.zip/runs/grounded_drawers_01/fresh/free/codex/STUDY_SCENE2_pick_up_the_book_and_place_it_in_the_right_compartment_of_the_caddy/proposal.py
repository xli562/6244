import math
import numpy as np


def run(api):
    instruction = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n
        and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    def pos(name):
        return np.asarray(api.pos(name), dtype=float).copy()

    def move(point, steps=12):
        return api.move(np.asarray(point, dtype=float), steps=steps)

    def find(fragment, pool=None):
        pool = names if pool is None else pool
        if fragment in pool:
            return fragment
        return next((n for n in pool if fragment in n), None)

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        mappings = {
            "akita black bowl": ["black bowl", "bowl"],
            "porcelain mug": ["white mug", "mug"],
            "white yellow mug": [
                "yellow and white mug", "white and yellow mug", "yellow mug"
            ],
            "red coffee mug": ["red mug", "coffee mug", "mug"],
            "cream cheese": ["cream cheese box"],
            "black book": ["book"],
            "desk caddy": ["caddy"],
            "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
            "flat stove": ["stove"],
            "white cabinet": ["cabinet"],
        }
        return [base] + mappings.get(base, [])

    def mention_score(name, text):
        padded = " " + text.replace(",", " ").replace(".", " ") + " "
        return max(
            [len(a) for a in aliases(name) if " " + a + " " in padded]
            or [0]
        )

    def selected(text, excluded=()):
        candidates = [
            n for n in bodies
            if n not in excluded and mention_score(n, text)
        ]
        # A specific mug description should not select every mug.
        result = []
        for n in candidates:
            score = mention_score(n, text)
            if score <= 4 and any(
                other != n
                and n.rsplit("_", 2)[-2] == other.rsplit("_", 2)[-2]
                and mention_score(other, text) > score
                for other in candidates
            ):
                continue
            result.append(n)
        return result

    def retreat():
        move(np.asarray(api.eef(), float) + [0., 0., 0.12], 10)

    def grasp_offset(item, attempt=0):
        if "book" in item:
            # Retry the acquisition at an edge if the central pinch fails.
            return np.array([
                (0., 0.035, -0.035)[min(attempt, 2)],
                0.,
                0.005 if attempt == 0 else 0.,
            ])
        offset = np.zeros(3)
        if "bowl" in item:
            offset[:] = [0.035, 0., 0.015]
        elif "mug" in item:
            offset[:] = [0.025, 0., 0.015]
        elif "moka" in item:
            offset[2] = 0.025
        if attempt:
            if "bowl" in item or "mug" in item:
                offset[0] *= -1.
            else:
                offset += [0.018, 0., -0.008]
        return offset

    def placed(item, target, offset):
        delta = pos(item) - (pos(target) + offset)
        tolerance = 0.065
        if "basket" in target:
            tolerance = 0.09
        if "caddy" in target:
            # Distinguish the requested compartment from its neighbors.
            tolerance = 0.03
        return (
            np.linalg.norm(delta[:2]) < tolerance
            and -0.055 < delta[2] < 0.13
        )

    def precise_book_placement(item, target, offset, attempt):
        before = pos(item)
        grasp = before + grasp_offset(item, attempt)
        api.grip(False)
        hand = np.asarray(api.eef(), float)
        clearance = max(hand[2], grasp[2] + 0.15, pos(target)[2] + 0.20)
        move([hand[0], hand[1], clearance], 10)
        move([grasp[0], grasp[1], clearance], 14)
        move(grasp + [0., 0., 0.04], 10)
        move(grasp, 10)
        api.grip(True)
        move(grasp + [0., 0., 0.12], 16)

        lifted = pos(item)
        hand = np.asarray(api.eef(), float)
        if lifted[2] - before[2] < 0.035:
            api.grip(False)
            retreat()
            return False

        # Test that the book follows the fingers before crossing the caddy.
        relative = lifted - hand
        move(hand + [0., 0., 0.025], 6)
        new_hand = np.asarray(api.eef(), float)
        if np.linalg.norm((pos(item) - new_hand) - relative) > 0.025:
            api.grip(False)
            retreat()
            return False
        relative = pos(item) - new_hand

        destination = pos(target) + offset
        above = destination - relative + [0., 0., 0.18]
        clearance = max(new_hand[2], above[2])
        move([new_hand[0], new_hand[1], clearance], 8)
        move([above[0], above[1], clearance], 18)
        move(above, 10)

        # Correct using the held object's position, not the fingertip position.
        for height in (0.10, 0.055, 0.025):
            desired = destination + [0., 0., height]
            correction = desired - pos(item)
            move(np.asarray(api.eef(), float) + correction, 10)

        api.grip(False)
        retreat()
        return placed(item, target, offset)

    def transport(item, target, offset=None):
        offset = np.zeros(3) if offset is None else np.asarray(offset, float)
        if placed(item, target, offset):
            return True

        # Preserve the usual transfer first. Repair only the failed item.
        before = pos(item)
        lift = api.transfer(
            item, target,
            grasp=tuple(grasp_offset(item)),
            drop=tuple(offset + [0., 0., 0.08]),
        )
        if placed(item, target, offset):
            return True

        after = pos(item)
        hand = np.asarray(api.eef(), float)
        if (
            lift is not None and float(lift) > 0.025
            and after[2] > before[2] + 0.025
            and np.linalg.norm(after - hand) < 0.10
        ):
            relative = after - hand
            move(hand + [0., 0., 0.025], 6)
            hand = np.asarray(api.eef(), float)
            if np.linalg.norm(pos(item) - hand - relative) < 0.02:
                relative = pos(item) - hand
                destination = pos(target) + offset
                above = destination - relative + [0., 0., 0.17]
                clearance = max(hand[2], above[2])
                move([hand[0], hand[1], clearance], 8)
                move([above[0], above[1], clearance], 16)
                move(above, 8)
                move(destination - relative + [0., 0., 0.03], 14)
                api.grip(False)
                retreat()
                if placed(item, target, offset):
                    return True

        api.grip(False)
        if "book" in item and "caddy" in target:
            return precise_book_placement(item, target, offset, 1)

        api.transfer(
            item, target,
            grasp=tuple(grasp_offset(item, 1)),
            drop=tuple(offset + [0., 0., 0.06]),
        )
        return placed(item, target, offset)

    def drawer_open(region):
        initial = pos(region)
        for attempt in range(2):
            handle = pos(region) + np.array(
                [0., -0.145, 0.015] if attempt == 0
                else [0., -0.17, 0.035]
            )
            api.grip(False)
            move(handle + [0., -0.08, 0.08], 12)
            move(handle, 14)
            api.grip(True)
            move(handle + [0., -0.18, 0.], 22)
            api.grip(False)
            retreat()
            if pos(region)[1] < initial[1] - 0.035:
                return initial, True
        return initial, False

    def drawer_close(region, initial):
        current = pos(region)
        travel = max(0., initial[1] - current[1])
        if travel < 0.025:
            return
        handle = current + [0., -0.15, 0.015]
        api.grip(True)
        move(handle + [0., -0.065, 0.06], 10)
        move(handle + [0., -0.035, 0.], 10)
        move(handle + [0., travel + 0.02, 0.], 24)
        retreat()
        api.grip(False)

    def turn_stove(stove, on):
        knob = find("switch") or find("knob") or find("button")
        center = pos(knob) if knob else pos(stove) + [0., -0.105, 0.025]
        api.grip(False)
        move(center + [0., 0., 0.09], 12)
        move(center, 14)
        api.grip(True)
        api.action(
            [0., 0., 0., 0., 0., 1. if on else -1., 1.],
            steps=18,
        )
        api.grip(False)
        retreat()

    stove = find("flat_stove", bodies)
    if stove and ("turn on" in instruction or "turn off" in instruction):
        turn_stove(stove, "turn on" in instruction)

    cabinet = find("cabinet", bodies)
    if cabinet and "drawer" in instruction:
        level = next(
            (s for s in ("bottom", "middle", "top") if s in instruction),
            "bottom",
        )
        region = find(cabinet + "_" + level + "_region")
        if region is None:
            return
        initial, opened = drawer_open(region)
        if not opened:
            return
        for item in selected(instruction, (cabinet,)):
            if not transport(item, region, [0., 0., 0.015]):
                return
        if "close" in instruction:
            drawer_close(region, initial)
        return

    jobs = []
    basket = find("basket", bodies)
    caddy = find("caddy", bodies)

    if basket and "basket" in instruction:
        target = find(basket + "_contain_region") or basket
        items = selected(instruction, (basket,))
        for i, item in enumerate(items):
            x = (i - (len(items) - 1) / 2.) * 0.065
            jobs.append((item, target, np.array([x, 0., 0.])))

    elif caddy and "caddy" in instruction:
        side = next(
            (s for s in ("right", "left", "front", "back")
             if s + " compartment" in instruction
             or s + " section" in instruction
             or s + " side" in instruction),
            None,
        )
        if side is None:
            side = next(
                (s for s in ("back", "front", "left", "right")
                 if s in instruction),
                "back",
            )
        target = find(caddy + "_" + side + "_contain_region")
        if target is None:
            return
        for item in selected(instruction, (caddy,)):
            jobs.append((item, target, np.zeros(3)))

    elif "plate" in instruction and (
        "left" in instruction or "right" in instruction
    ):
        plates = [n for n in bodies if n.startswith("plate_")]
        used = set()
        for side in ("left", "right"):
            marker = find("plate_" + side + "_region")
            end = instruction.find(side + " plate")
            if marker is None or not plates or end < 0:
                continue
            target = min(
                plates, key=lambda n: np.linalg.norm(pos(n) - pos(marker))
            )
            start = max(
                instruction.rfind("put ", 0, end),
                instruction.rfind("place ", 0, end),
                0,
            )
            matches = [
                n for n in selected(instruction[start:end])
                if n not in used and n not in plates
            ]
            if matches:
                item = max(
                    matches,
                    key=lambda n: mention_score(n, instruction[start:end]),
                )
                jobs.append((item, target, np.zeros(3)))
                used.add(item)

    elif stove and ("stove" in instruction or "on it" in instruction):
        target = find(stove + "_cook_region") or stove
        for item in selected(instruction, (stove,)):
            jobs.append((item, target, np.zeros(3)))

    else:
        candidates = selected(instruction)
        if len(candidates) >= 2:
            target_body = max(
                candidates,
                key=lambda n: max(instruction.rfind(a) for a in aliases(n)),
            )
            target = target_body
            if " in " in instruction or " into " in instruction:
                target = find(target_body + "_contain_region") or target_body
            for item in candidates:
                if item != target_body:
                    jobs.append((item, target, np.zeros(3)))

    for item, target, offset in jobs:
        if not transport(item, target, offset):
            return
