import numpy as np
import math


def run(api):
    instruction = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n
        and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    def pos(name):
        return np.asarray(api.pos(name), dtype=float).copy()

    def move(point, steps=12):
        return api.move(np.asarray(point, dtype=float), steps=steps)

    def find(fragment, pool=None):
        return next(
            (n for n in (names if pool is None else pool) if fragment in n),
            None,
        )

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        mappings = {
            "akita black bowl": ["black bowl", "bowl"],
            "porcelain mug": ["white mug"],
            "white yellow mug": [
                "yellow and white mug", "white and yellow mug", "yellow mug"
            ],
            "red coffee mug": ["red mug", "red coffee mug"],
            "cream cheese": ["cream cheese box", "cream cheese"],
            "black book": ["black book", "book"],
            "desk caddy": ["desk caddy", "caddy"],
            "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
            "flat stove": ["stove"],
            "white cabinet": ["cabinet"],
            "wooden cabinet": ["cabinet"],
        }
        return [base] + mappings.get(base, [])

    def mentioned(name, text):
        return any(a in text for a in aliases(name))

    def retreat(height=0.12):
        move(np.asarray(api.eef(), dtype=float) + [0., 0., height], 10)

    def grasp_offset(item, attempt=0):
        offset = np.zeros(3)
        if "bowl" in item:
            offset[:] = [0.035, 0., 0.015]
        elif "mug" in item:
            offset[:] = [0.025, 0., 0.015]
        elif "book" in item:
            offset[2] = 0.005
        elif "moka" in item:
            offset[2] = 0.025
        if attempt:
            if "bowl" in item or "mug" in item:
                offset[0] *= -1.
            else:
                offset[0] += 0.018
                offset[2] -= 0.008
        return offset

    def placed(item, target, offset):
        p, q = pos(item), pos(target) + offset
        tolerance = 0.09 if "basket" in target else 0.065
        if "caddy" in target:
            tolerance = 0.045
        return (
            np.linalg.norm(p[:2] - q[:2]) < tolerance
            and -0.055 < p[2] - q[2] < 0.17
        )

    def transport(item, target, offset=None):
        offset = np.zeros(3) if offset is None else np.asarray(offset, float)
        for attempt in range(2):
            before = pos(item)
            lift = api.transfer(
                item, target,
                grasp=tuple(grasp_offset(item, attempt)),
                drop=tuple(offset + [0., 0., 0.08]),
            )
            after = pos(item)
            if placed(item, target, offset):
                return True
            hand = np.asarray(api.eef(), dtype=float)
            if (
                lift is not None and float(lift) > 0.025
                and np.linalg.norm(after - hand) < 0.10
                and after[2] > before[2] + 0.025
            ):
                relative = after - hand
                destination = pos(target) + offset
                move(destination - relative + [0., 0., 0.16], 16)
                move(destination - relative + [0., 0., 0.045], 12)
                api.grip(False)
                retreat()
                if placed(item, target, offset):
                    return True
            api.grip(False)
        return False

    def drawer_open(cabinet, region, level, ample=False):
        initial = pos(region)
        # Repair handle acquisition before attempting any later subgoal.
        # Prefer a perceived handle; otherwise probe nearby handle heights.
        handle_names = [
            n for n in names
            if ("handle" in n or "pull" in n)
            and (level in n or cabinet in n)
        ]
        handle_name = min(
            handle_names, key=lambda n: np.linalg.norm(pos(n) - initial)
        ) if handle_names else None

        candidates = [
            (0.145, 0.015),
            (0.170, 0.035),
            (0.145, -0.020),
        ]
        attempts = len(candidates) if ample else 2
        best_travel = 0.
        successful_offset = np.array([0., -0.145, 0.015])

        for depth, height in candidates[:attempts]:
            offset = np.array([0., -depth, height])
            handle = pos(handle_name) if handle_name else pos(region) + offset
            api.grip(False)

            # Approach from outside the cabinet, then descend onto the handle.
            move(handle + [0., -0.09, 0.09], 10)
            move(handle + [0., 0., 0.06], 10)
            move(handle, 12)
            api.grip(True)

            hand = np.asarray(api.eef(), dtype=float).copy()
            before_pull = pos(region)

            # A short pull tests acquisition without consuming a full stroke.
            move(hand + [0., -0.065, 0.], 12)
            current = pos(region)
            travel = initial[1] - current[1]
            acquired = before_pull[1] - current[1] > 0.012

            if acquired:
                successful_offset = offset
                # Preserve this grasp and extend the same successful pull.
                remaining = max(0., 0.17 - travel)
                if remaining > 0.01:
                    hand = np.asarray(api.eef(), dtype=float).copy()
                    move(hand + [0., -remaining, 0.], 22)
                travel = initial[1] - pos(region)[1]

            best_travel = max(best_travel, travel)
            api.grip(False)
            # Leave along the opening before lifting past the drawer above.
            hand = np.asarray(api.eef(), dtype=float).copy()
            move(hand + [0., -0.045, 0.], 6)
            retreat(0.09)

            if travel >= 0.10:
                return initial, True, successful_offset

            # A partial opening is retained; subsequent probes use the
            # drawer's current position rather than the original location.
            if acquired:
                successful_offset = offset

        return initial, best_travel >= 0.10, successful_offset

    def drawer_close(region, initial, handle_offset=None):
        travel = max(0., initial[1] - pos(region)[1])
        if travel < 0.025:
            return
        if handle_offset is None:
            handle_offset = np.array([0., -0.15, 0.015])
        handle = pos(region) + handle_offset
        api.grip(True)
        move(handle + [0., -0.065, 0.06], 10)
        move(handle + [0., -0.035, 0.], 10)
        move(handle + [0., travel + 0.02, 0.], 24)
        retreat()
        api.grip(False)

    def turn_stove(stove, on=True):
        knob = find("switch") or find("knob") or find("button")
        center = pos(knob) if knob else pos(stove) + [0., -0.105, 0.025]
        api.grip(False)
        move(center + [0., 0., 0.09], 12)
        move(center, 14)
        api.grip(True)
        api.action(
            [0., 0., 0., 0., 0., 1. if on else -1., 1.], steps=18
        )
        api.grip(False)
        retreat()

    stove = find("flat_stove", bodies)
    if stove and ("turn on" in instruction or "turn off" in instruction):
        turn_stove(stove, on="turn on" in instruction)

    cabinet = find("cabinet", bodies)
    if cabinet and "drawer" in instruction:
        level = next(
            (s for s in ("bottom", "middle", "top") if s in instruction),
            "bottom",
        )
        region = find(cabinet + "_" + level + "_region")
        if region is None:
            return
        items = [
            n for n in bodies if n != cabinet and mentioned(n, instruction)
        ]
        initial, opened, handle_offset = drawer_open(
            cabinet, region, level, ample=not items
        )
        if not opened:
            return
        for item in items:
            if not transport(item, region, [0., 0., 0.015]):
                return
        if "close" in instruction:
            drawer_close(region, initial, handle_offset)
        return

    jobs = []
    basket = find("basket", bodies)
    caddy = find("caddy", bodies)

    if basket and "basket" in instruction:
        target = find(basket + "_contain_region") or basket
        items = [
            n for n in bodies if n != basket and mentioned(n, instruction)
        ]
        for i, item in enumerate(items):
            x = (i - (len(items) - 1) / 2.) * 0.065
            jobs.append((item, target, np.array([x, 0., 0.])))

    elif caddy and "caddy" in instruction:
        side = next(
            (s for s in ("back", "front", "left", "right") if s in instruction),
            "back",
        )
        target = find(caddy + "_" + side + "_contain_region") or caddy
        for item in bodies:
            if item != caddy and mentioned(item, instruction):
                jobs.append((item, target, np.zeros(3)))

    elif "plate" in instruction and (
        "left" in instruction or "right" in instruction
    ):
        plates = [n for n in bodies if n.startswith("plate_")]
        used = set()
        for side in ("left", "right"):
            marker = find("plate_" + side + "_region")
            if marker is None or not plates:
                continue
            target = min(
                plates, key=lambda n: np.linalg.norm(pos(n) - pos(marker))
            )
            end = instruction.find(side + " plate")
            if end < 0:
                continue
            start = max(
                instruction.rfind("put ", 0, end),
                instruction.rfind("place ", 0, end), 0,
            )
            clause = instruction[start:end]
            matches = [
                n for n in bodies
                if n not in used and "mug" in n and mentioned(n, clause)
            ]
            if matches:
                item = max(
                    matches,
                    key=lambda n: max(
                        [len(a) for a in aliases(n) if a in clause] or [0]
                    ),
                )
                jobs.append((item, target, np.zeros(3)))
                used.add(item)

    elif stove and ("stove" in instruction or "on it" in instruction):
        target = find(stove + "_cook_region") or stove
        for item in bodies:
            if item != stove and mentioned(item, instruction):
                jobs.append((item, target, np.zeros(3)))

    else:
        candidates = [n for n in bodies if mentioned(n, instruction)]
        if len(candidates) >= 2:
            target_body = max(
                candidates,
                key=lambda n: max(instruction.rfind(a) for a in aliases(n)),
            )
            target = target_body
            if " in " in instruction or " into " in instruction:
                target = find(target_body + "_contain_region") or target_body
            for item in candidates:
                if item != target_body:
                    jobs.append((item, target, np.zeros(3)))

    for item, target, offset in jobs:
        if not transport(item, target, offset):
            return
