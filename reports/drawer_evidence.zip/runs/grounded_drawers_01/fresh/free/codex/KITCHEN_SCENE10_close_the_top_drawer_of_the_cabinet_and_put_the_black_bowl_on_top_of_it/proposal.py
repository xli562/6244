import math
import numpy as np


def run(api):
    instruction = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n
        and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    def pos(name):
        return np.asarray(api.pos(name), dtype=float).copy()

    def move(point, steps=12):
        return api.move(np.asarray(point, dtype=float), steps=steps)

    def find(fragment, pool=None):
        candidates = names if pool is None else pool
        return next((n for n in candidates if fragment in n), None)

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        mappings = {
            "akita black bowl": ["black bowl", "bowl"],
            "porcelain mug": ["white mug"],
            "white yellow mug": [
                "yellow and white mug", "white and yellow mug", "yellow mug"
            ],
            "red coffee mug": ["red mug", "red coffee mug"],
            "cream cheese": ["cream cheese box", "cream cheese"],
            "black book": ["black book", "book"],
            "desk caddy": ["desk caddy", "caddy"],
            "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
            "flat stove": ["stove"],
            "white cabinet": ["cabinet"],
            "wooden cabinet": ["cabinet"],
        }
        return [base] + mappings.get(base, [])

    def mentioned(name, text):
        return any(a in text for a in aliases(name))

    def retreat():
        move(np.asarray(api.eef(), dtype=float) + [0., 0., 0.12], 10)

    def grasp_offset(item, attempt=0):
        offset = np.zeros(3)
        if "bowl" in item:
            offset[:] = [0.035, 0., 0.015]
        elif "mug" in item:
            offset[:] = [0.025, 0., 0.015]
        elif "book" in item:
            offset[2] = 0.005
        elif "moka" in item:
            offset[2] = 0.025
        if attempt:
            if "bowl" in item or "mug" in item:
                offset[0] *= -1.
            else:
                offset[0] += 0.018
                offset[2] -= 0.008
        return offset

    def placed(item, target, offset):
        p, q = pos(item), pos(target) + offset
        tolerance = 0.065
        if "basket" in target:
            tolerance = 0.09
        elif "caddy" in target:
            tolerance = 0.045
        return (
            np.linalg.norm(p[:2] - q[:2]) < tolerance
            and -0.055 < p[2] - q[2] < 0.17
        )

    def transport(item, target, offset=None):
        offset = np.zeros(3) if offset is None else np.asarray(offset, float)
        for attempt in range(2):
            before = pos(item)
            lift = api.transfer(
                item, target,
                grasp=tuple(grasp_offset(item, attempt)),
                drop=tuple(offset + [0., 0., 0.08]),
            )
            after = pos(item)
            if placed(item, target, offset):
                return True

            hand = np.asarray(api.eef(), dtype=float)
            if (
                lift is not None and float(lift) > 0.025
                and np.linalg.norm(after - hand) < 0.10
                and after[2] > before[2] + 0.025
            ):
                relative = after - hand
                destination = pos(target) + offset
                move(destination - relative + [0., 0., 0.16], 16)
                move(destination - relative + [0., 0., 0.045], 12)
                api.grip(False)
                retreat()
                if placed(item, target, offset):
                    return True
            api.grip(False)
        return False

    def drawer_open(region):
        initial = pos(region)
        for attempt in range(2):
            handle = pos(region) + np.array(
                [0., -0.145, 0.015] if attempt == 0
                else [0., -0.17, 0.035]
            )
            api.grip(False)
            move(handle + [0., -0.09, 0.08], 12)
            move(handle, 14)
            api.grip(True)
            move(handle + [0., -0.18, 0.], 22)
            api.grip(False)
            retreat()
            if pos(region)[1] < initial[1] - 0.035:
                return initial, True
        return initial, False

    def drawer_close(region, initial=None):
        # A close-only task starts with an open drawer. Do not open it first
        # or use its initially open position as the desired closed position.
        if initial is not None:
            travel = max(0., initial[1] - pos(region)[1])
            if travel < 0.015:
                return True
            push_distance = travel + 0.025
        else:
            push_distance = 0.25

        for attempt in range(2):
            before = pos(region)
            handle = before + [0., -0.15, 0.015 + attempt * 0.02]
            api.grip(True)
            move(handle + [0., -0.08, 0.09], 12)
            move(handle + [0., -0.045, 0.], 12)

            # Push the drawer front inward, allowing the joint's physical
            # stop to set its closed position.
            start = handle + [0., -0.045, 0.]
            for fraction in (0.35, 0.7, 1.):
                move(start + [0., push_distance * fraction, 0.], 10)

            after = pos(region)
            move(np.asarray(api.eef(), dtype=float) + [0., -0.06, 0.], 8)
            retreat()
            api.grip(False)

            if initial is not None:
                if after[1] >= initial[1] - 0.015:
                    return True
                push_distance = max(0.05, initial[1] - after[1] + 0.025)
            elif after[1] - before[1] > 0.025:
                return True
        return False

    def turn_stove(stove, on=True):
        knob = find("switch") or find("knob") or find("button")
        center = pos(knob) if knob else pos(stove) + [0., -0.105, 0.025]
        api.grip(False)
        move(center + [0., 0., 0.09], 12)
        move(center, 14)
        api.grip(True)
        api.action(
            [0., 0., 0., 0., 0., 1. if on else -1., 1.], steps=18
        )
        api.grip(False)
        retreat()

    stove = find("flat_stove", bodies)
    if stove and ("turn on" in instruction or "turn off" in instruction):
        turn_stove(stove, on="turn on" in instruction)

    cabinet = find("cabinet", bodies)
    if cabinet and "drawer" in instruction:
        level = next(
            (s for s in ("bottom", "middle", "top") if s in instruction),
            "bottom",
        )
        region = find(cabinet + "_" + level + "_region")
        if region is None:
            return

        items = [
            n for n in bodies if n != cabinet and mentioned(n, instruction)
        ]
        on_top = any(s in instruction for s in (
            "on top", "on the cabinet", "onto the cabinet",
        ))
        into_drawer = any(s in instruction for s in (
            " in ", " into ", " inside ",
        )) and not on_top

        if "close" in instruction and not into_drawer:
            if not drawer_close(region):
                return
            if on_top:
                target = find(cabinet + "_top_side")
                if target is None:
                    return
                for item in items:
                    if not transport(item, target):
                        return
            return

        initial, opened = drawer_open(region)
        if not opened:
            return
        if into_drawer:
            for item in items:
                if not transport(item, region, [0., 0., 0.015]):
                    return
        if "close" in instruction:
            if not drawer_close(region, initial):
                return
        if on_top:
            target = find(cabinet + "_top_side")
            if target is not None:
                for item in items:
                    if not transport(item, target):
                        return
        return

    jobs = []
    basket = find("basket", bodies)
    caddy = find("caddy", bodies)

    if basket and "basket" in instruction:
        target = find(basket + "_contain_region") or basket
        items = [
            n for n in bodies if n != basket and mentioned(n, instruction)
        ]
        for i, item in enumerate(items):
            x = (i - (len(items) - 1) / 2.) * 0.065
            jobs.append((item, target, np.array([x, 0., 0.])))

    elif caddy and "caddy" in instruction:
        side = next(
            (s for s in ("back", "front", "left", "right") if s in instruction),
            "back",
        )
        target = find(caddy + "_" + side + "_contain_region") or caddy
        for item in bodies:
            if item != caddy and mentioned(item, instruction):
                jobs.append((item, target, np.zeros(3)))

    elif "plate" in instruction and (
        "left" in instruction or "right" in instruction
    ):
        plates = [n for n in bodies if n.startswith("plate_")]
        used = set()
        for side in ("left", "right"):
            marker = find("plate_" + side + "_region")
            if marker is None or not plates:
                continue
            target = min(
                plates, key=lambda n: np.linalg.norm(pos(n) - pos(marker))
            )
            end = instruction.find(side + " plate")
            if end < 0:
                continue
            start = max(
                instruction.rfind("put ", 0, end),
                instruction.rfind("place ", 0, end),
                0,
            )
            clause = instruction[start:end]
            matches = [
                n for n in bodies
                if n not in used and "mug" in n and mentioned(n, clause)
            ]
            if matches:
                item = max(
                    matches,
                    key=lambda n: max(
                        [len(a) for a in aliases(n) if a in clause] or [0]
                    ),
                )
                jobs.append((item, target, np.zeros(3)))
                used.add(item)

    elif stove and ("stove" in instruction or "on it" in instruction):
        target = find(stove + "_cook_region") or stove
        for item in bodies:
            if item != stove and mentioned(item, instruction):
                jobs.append((item, target, np.zeros(3)))

    else:
        candidates = [n for n in bodies if mentioned(n, instruction)]
        if len(candidates) >= 2:
            def last_mention(name):
                return max(instruction.rfind(a) for a in aliases(name))

            target_body = max(candidates, key=last_mention)
            target = target_body
            if " in " in instruction or " into " in instruction:
                target = find(target_body + "_contain_region") or target_body
            elif "cabinet" in target_body:
                target = find(target_body + "_top_side") or target_body
            for item in candidates:
                if item != target_body:
                    jobs.append((item, target, np.zeros(3)))

    for item, target, offset in jobs:
        if not transport(item, target, offset):
            return
