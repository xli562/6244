def run(api):
    raise ValueError("CLI program rejected: line 298: use of 'getattr' is not allowed")
