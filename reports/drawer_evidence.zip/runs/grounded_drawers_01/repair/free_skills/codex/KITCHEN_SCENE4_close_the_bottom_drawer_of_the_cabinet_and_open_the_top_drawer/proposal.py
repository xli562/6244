import numpy as np
import math


def run(api):
    text = api.instruction.lower().replace("-", " ")
    for punctuation in ",.;:!?":
        text = text.replace(punctuation, " ")
    words = text.split()
    names = list(api.names())

    # Repair the earliest failure: the old policy unconditionally opened
    # one drawer, even when the first requested action was to close it.
    # Keep other tasks on the previous policy.
    if "drawer" not in text:
        api.fallback()
        return

    verbs = {
        "open", "close", "put", "place", "pick", "take", "move",
        "turn", "push", "pull", "insert", "remove", "stack",
    }
    boundaries = [i for i, word in enumerate(words) if word in verbs]

    # Resolve the complete sequence before executing any physical action.
    # Unsupported instructions fall back before any completed work can replay.
    plan = []
    previous_region = None

    for index, start in enumerate(boundaries):
        stop = boundaries[index + 1] if index + 1 < len(boundaries) else len(words)
        clause = words[start:stop]
        operation = clause[0]

        if operation not in ("open", "close"):
            api.fallback()
            return

        levels = [level for level in ("bottom", "middle", "top")
                  if level in clause]
        if len(levels) > 1:
            api.fallback()
            return

        if levels:
            suffix = "_" + levels[0] + "_region"
            candidates = [
                name for name in names
                if "cabinet" in name and name.endswith(suffix)
            ]
            if len(candidates) != 1:
                api.fallback()
                return
            region = candidates[0]
        elif previous_region is not None and (
            "it" in clause or "drawer" in clause
        ):
            region = previous_region
        else:
            api.fallback()
            return

        plan.append((region, operation))
        previous_region = region

    if not plan:
        api.fallback()
        return

    # Execute in English instruction order, preserving completed operations.
    # The supplied skill handles physical drawer acquisition and motion.
    for region, operation in plan:
        result = api.drawer(region, operation)
        if result is False:
            return
