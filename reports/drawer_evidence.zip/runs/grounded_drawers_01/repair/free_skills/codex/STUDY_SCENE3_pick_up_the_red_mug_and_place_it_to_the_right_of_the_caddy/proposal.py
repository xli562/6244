import numpy as np
import math


def run(api):
    instruction = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n
        and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    def find(fragment, pool=None):
        return next(
            (n for n in (names if pool is None else pool) if fragment in n),
            None,
        )

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        mappings = {
            "akita black bowl": ["black bowl", "bowl"],
            "porcelain mug": ["white mug"],
            "white yellow mug": [
                "yellow and white mug", "white and yellow mug", "yellow mug"
            ],
            "red coffee mug": ["red mug"],
            "cream cheese": ["cream cheese box"],
            "black book": ["book"],
            "desk caddy": ["caddy"],
            "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
            "flat stove": ["stove"],
            "white cabinet": ["cabinet"],
        }
        return [base] + mappings.get(base, [])

    def mentioned(name, text):
        padded = " " + text + " "
        return any(" " + a + " " in padded for a in aliases(name))

    def mention_index(name, text):
        hits = [text.find(a) for a in aliases(name) if a in text]
        return min(hits) if hits else len(text)

    def items_in(text, exclude=()):
        return sorted(
            [
                n for n in bodies
                if n not in exclude and mentioned(n, text)
            ],
            key=lambda n: mention_index(n, text),
        )

    def spatial_relation(text):
        # Outside locations and inside compartments are distinct targets.
        # Match complete phrases before considering standalone directions.
        for direction in ("left", "right", "front", "back"):
            phrases = {
                "left": ("to the left of", "on the left of", "left of"),
                "right": ("to the right of", "on the right of", "right of"),
                "front": ("in front of",),
                "back": ("behind", "in back of", "at the back of"),
            }[direction]
            if any(phrase in text for phrase in phrases):
                return direction, "outside"

        if any(
            phrase in text
            for phrase in ("inside", "into", " in ", "compartment")
        ):
            words = text.split()
            for direction in ("left", "right", "front", "back"):
                if direction in words:
                    return direction, "inside"
        return None

    def region_for(body, suffix):
        exact = body + "_" + suffix
        return exact if exact in names else find(exact)

    cabinet = find("cabinet", bodies)
    caddy = find("caddy", bodies)
    basket = find("basket", bodies)
    stove = find("flat_stove", bodies)

    # Split only at new action verbs. Keep "pick up ... and place it ..."
    # together so the object remains available to the placement clause.
    verbs = (
        "put ", "place ", "open ", "close ", "turn on ", "turn off ",
        "pick up ",
    )
    text = instruction.replace(",", " ").replace(".", " ")
    for separator in (" and then ", " then ", " and "):
        for verb in verbs:
            text = text.replace(separator + verb, "|" + verb)
    clauses = [" ".join(c.split()) for c in text.split("|") if c.strip()]

    # Resolve every subgoal before executing anything. Unsupported tasks can
    # use the old policy without replaying actions already completed here.
    plan = []
    held_names = []
    last_target = None

    for clause in clauses:
        if clause.startswith("pick up "):
            held_names = items_in(clause)
            if not held_names:
                api.fallback()
                return
            # Actual pickup is performed by arrange with the following place.
            continue

        if "drawer" in clause or (
            cabinet and clause.startswith(("open ", "close "))
        ):
            level = next(
                (s for s in ("bottom", "middle", "top") if s in clause),
                None,
            )
            if level is None and last_target and "region" in last_target:
                region = last_target
            elif cabinet and level:
                region = region_for(cabinet, level + "_region")
            else:
                region = None

            if not region:
                api.fallback()
                return

            if clause.startswith("open "):
                plan.append(("drawer", region, "open"))
                last_target = region
                continue
            if clause.startswith("close "):
                plan.append(("drawer", region, "close"))
                last_target = region
                continue

            objects = items_in(clause, (cabinet,))
            if not objects:
                objects = held_names
            if not objects:
                api.fallback()
                return
            plan.append(("arrange", [(n, region) for n in objects]))
            held_names = objects
            last_target = region
            continue

        if "turn on" in clause or "turn off" in clause:
            # Delegate unsupported switch manipulation before any action.
            api.fallback()
            return

        references = items_in(clause)
        target_body = None
        for fixture in (caddy, basket, cabinet, stove):
            if fixture and mentioned(fixture, clause):
                target_body = fixture
                break

        if target_body is None and len(references) >= 2:
            target_body = max(
                references,
                key=lambda n: max(
                    clause.rfind(a) for a in aliases(n) if a in clause
                ),
            )

        objects = [n for n in references if n != target_body]
        if not objects:
            objects = held_names

        target = None
        relation = spatial_relation(clause)
        if target_body and relation:
            direction, kind = relation
            # In particular, "to the right of the caddy" must resolve to
            # the table region outside the caddy, not its right compartment.
            target = api.relative_target(target_body, direction, kind)
        elif target_body == caddy and caddy:
            target = region_for(caddy, "contain_region")
            if target is None:
                # Do not silently substitute a compartment for a vague task.
                api.fallback()
                return
        elif target_body == basket and basket:
            target = region_for(basket, "contain_region") or basket
        elif target_body == cabinet and cabinet:
            if "on top" in clause or "on the cabinet" in clause:
                target = region_for(cabinet, "top_side")
        elif target_body == stove and stove:
            target = region_for(stove, "cook_region") or stove
        elif target_body:
            target = target_body
            if " into " in clause or " in " in clause:
                target = region_for(target_body, "contain_region") or target_body
        elif any(p in clause for p in ("inside it", "in it", "into it", "on it")):
            target = last_target

        # Resolve a left/right plate by its observed location.
        for direction in ("left", "right"):
            if direction + " plate" in clause:
                plates = [n for n in bodies if n.startswith("plate_")]
                marker = find("plate_" + direction + "_region")
                if marker and plates:
                    target = api.nearest(marker, plates)
                    objects = [
                        n for n in references
                        if n not in plates
                    ] or held_names
                break

        if not target or not objects:
            api.fallback()
            return

        objects = [n for n in objects if n != target]
        if not objects:
            api.fallback()
            return
        plan.append(("arrange", [(n, target) for n in objects]))
        held_names = objects
        last_target = target

    if not plan:
        api.fallback()
        return

    for operation in plan:
        if operation[0] == "drawer":
            result = api.drawer(operation[1], operation[2])
        else:
            result = api.arrange(operation[1])
        # Never restart the old policy after completing earlier subgoals.
        if result is False:
            return
