def run(api):
    # "to the right of the caddy" -> a table location NEXT TO the caddy (outside), not a compartment in it
    target = api.relative_target("desk_caddy_1", "right", "outside")
    if not target:
        target = api.nearest("study_table_desk_caddy_right_region",
                             ["study_table_desk_caddy_right_region"])
    if not target:
        return api.fallback()
    api.arrange([("red_coffee_mug_1", target)])
