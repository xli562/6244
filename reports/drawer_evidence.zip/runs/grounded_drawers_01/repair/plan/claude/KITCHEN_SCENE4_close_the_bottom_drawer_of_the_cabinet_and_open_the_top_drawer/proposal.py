def run(api):
    api.drawer("white_cabinet_1_bottom_region", "close")
    api.drawer("white_cabinet_1_top_region", "open")
