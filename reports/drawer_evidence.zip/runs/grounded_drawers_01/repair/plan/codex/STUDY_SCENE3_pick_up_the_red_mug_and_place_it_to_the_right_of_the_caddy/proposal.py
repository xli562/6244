def run(api):
    target = api.relative_target("desk_caddy_1", "right", "outside")
    api.arrange([("red_coffee_mug_1", target)])
