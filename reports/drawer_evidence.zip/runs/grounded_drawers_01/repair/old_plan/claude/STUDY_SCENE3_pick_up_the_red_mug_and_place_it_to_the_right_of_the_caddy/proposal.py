def run(api):
    api.arrange([("red_coffee_mug_1", "study_table_desk_caddy_right_region")])
