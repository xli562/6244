import math
import numpy as np

COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown',
          'wooden', 'pink', 'orange'}
PLACE_VERBS = ('place', 'put', 'set', 'move', 'stack')
PREPS = ('onto', 'into', 'inside', 'on', 'in', 'to')
DIRS = ('left', 'right', 'front', 'back')


def _words(s):
    s = ''.join(c if c.isalnum() else ' ' for c in s.lower())
    return s.split()


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _P(api, n):
    return np.array(api.pos(n), dtype=float)


def _split(words):
    """item phrase = everything before the last placing verb plus the
    verb's object; target phrase = words after the first preposition
    that follows the placing verb."""
    vi = None
    for i, w in enumerate(words):
        if w in PLACE_VERBS:
            vi = i
    if vi is None:
        return words, []
    after = words[vi + 1:]
    pi = None
    for i, w in enumerate(after):
        if w in PREPS:
            pi = i
            break
    if pi is None:
        return words[:vi] + after, []
    obj = [w for w in after[:pi] if w not in ('it', 'them', 'the', 'a', 'up')]
    return words[:vi] + obj, after[pi + 1:]


def _dir_key(api, d):
    # same convention as the previous policy: left = +y, front = -x
    return {'left': lambda n: -_P(api, n)[1],
            'right': lambda n: _P(api, n)[1],
            'front': lambda n: _P(api, n)[0],
            'back': lambda n: -_P(api, n)[0]}[d]


def _resolve_book(api, bodies, item_w, target_owner):
    books = [b for b in bodies if 'book' in b and b != target_owner]
    if not books:
        return None
    W = set(item_w)
    want = W & COLORS
    if want:
        col = [b for b in books if want & set(b.split('_'))]
        if col:
            books = col
    if len(books) > 1:
        for d in DIRS:
            if d in W:
                books = sorted(books, key=_dir_key(api, d))
                break
        else:
            books = sorted(books)
    return books[0]


def _resolve_target(api, names, bodies, tw):
    T = set(tw)
    owner, best = None, 0
    for b in bodies:
        if 'book' in b:
            continue
        toks = set(b.split('_')) - {str(i) for i in range(10)}
        m = len(toks & T)
        if m > best:
            best, owner = m, b
    if owner is None:
        return None, None
    regs = [n for n in names if _is_region(n) and n.startswith(owner + '_')]
    if not regs:
        return owner, owner
    compartment = bool(T & {'layer', 'compartment', 'shelf_level', 'level', 'inside', 'in'})
    bestr, bs = None, -1e9
    for r in regs:
        suf = set(r[len(owner) + 1:].split('_'))
        s = 3 * len((suf - {'region', 'side', 'contain'}) & T)
        if 'side' in suf:
            # "on top of X" -> top_side ; "top layer/compartment" -> region
            s += 4 if ('top' in T and not compartment) else -4
        if s > bs:
            bs, bestr = s, r
    return bestr, owner


def _placed(api, item, target):
    ip, tp = _P(api, item), _P(api, target)
    return np.linalg.norm(ip[:2] - tp[:2]) < 0.10 and ip[2] > tp[2] - 0.05


def _recover(api):
    try:
        api.grip(False)
        e = np.array(api.eef(), dtype=float)
        api.move(e + np.array([0, 0, 0.12]), steps=15)
    except Exception:
        pass


def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    words = _words(api.instruction)

    if 'book' not in words and 'books' not in words:
        api.fallback()
        return

    item_w, tw = _split(words)
    target, owner = _resolve_target(api, names, bodies, tw)
    book = api.nearest("study_table_yellow_book_left_init_region", [n for n in bodies if "book" in n])
    if target is None or book is None:
        api.fallback()
        return

    # Step 1-3: thin_edge grasp of the selected book onto the resolved target
    for grasp in ('thin_edge', 'thin_edge', 'standard'):
        try:
            api.place_with(book, target, grasp)
        except Exception:
            _recover(api)
            continue
        if _placed(api, book, target):
            return
        _recover(api)
