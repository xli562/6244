import numpy as np

COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown',
          'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'and', 'to', 'up', 'top',
        'left', 'right', 'front', 'back', 'bottom', 'middle', 'side',
        'its', 'please', 'then', 'drawer', 'compartment', 'on', 'in',
        'into', 'onto', 'inside', 'next', 'both'}
ALIAS = {'akita_black_bowl': 'black bowl', 'chefmate_8_frypan': 'frying pan frypan',
         'flat_stove': 'stove', 'porcelain_mug': 'white mug cup',
         'white_yellow_mug': 'white yellow mug cup', 'red_coffee_mug': 'red mug cup',
         'microwave': 'microwave oven', 'cream_cheese': 'cream cheese box',
         'butter': 'butter box', 'chocolate_pudding': 'chocolate pudding box'}
VERBS = {'put', 'place', 'close', 'shut', 'open', 'pick', 'move', 'set',
         'turn', 'switch', 'stack', 'take'}
LEVELS = ('top', 'middle', 'bottom')
DIRS = ('left', 'right', 'front', 'back')


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    w |= set(ALIAS.get(base, '').split())
    return w


def _resolve(api, bodies, ws, exclude=()):
    W = set(w for w in ws if w not in STOP)
    if not W:
        return None
    best, cands = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best:
            best, cands = s, [b]
        elif s == best:
            cands.append(b)
    if not cands:
        return None
    if len(cands) > 1:
        key = {'left': lambda p: p[1], 'right': lambda p: -p[1],
               'front': lambda p: -p[0], 'back': lambda p: p[0]}
        for d in DIRS:
            if d in ws:
                cands.sort(key=lambda c: key[d](np.array(api.pos(c), float)))
                break
        else:
            cands.sort()
    return cands[0]


def _grasp_for(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


def _clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if w == 'then' or (w == 'and' and (nxt in VERBS or nxt == 'then')):
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return out


def _fixture(api, bodies, names, ws, last_fix):
    f = _resolve(api, bodies, ws)
    if f is None or not any(n.startswith(f + '_') and _is_region(n) for n in names):
        cab = [b for b in bodies if 'cabinet' in b]
        f = last_fix or (cab[0] if cab else None)
    return f


def _drawer_region(names, fix, ws, last_drawer):
    lvl = next((l for l in LEVELS if l in ws), None)
    if lvl and fix and fix + '_' + lvl + '_region' in names:
        return fix + '_' + lvl + '_region'
    return last_drawer


def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    words = _words(api.instruction)
    if any(w in words for w in ('turn', 'switch', 'stove', 'microwave', 'pick')):
        return api.fallback()

    plan, last_fix, last_drawer, last_item = [], None, None, None
    for c in _clauses(words):
        v, rest = c[0], c[1:]
        if v in ('open', 'close', 'shut'):
            if 'drawer' not in rest and 'drawers' not in rest:
                return api.fallback()
            fix = _fixture(api, bodies, names, rest, last_fix)
            reg = _drawer_region(names, fix, rest, last_drawer)
            if reg is None:
                return api.fallback()
            plan.append(('drawer', reg, 'open' if v == 'open' else 'close'))
            last_fix, last_drawer = fix, reg
            continue
        # placement clause: split item / target at first preposition
        idx = next((i for i, w in enumerate(rest)
                    if w in ('on', 'onto', 'in', 'into', 'inside', 'to', 'next')
                    and i > 0), None)
        if idx is None:
            return api.fallback()
        iw, tw = rest[:idx], rest[idx:]
        item = last_item if iw in (['it'], ['them']) else _resolve(api, bodies, iw)
        if item is None:
            return api.fallback()
        target = None
        tset = set(tw)
        ref_ws = [w for w in tw if w not in STOP]
        if 'top' in tset and 'of' in tset and ('drawer' not in tset):
            # "on top of X" / "on top of it" -> surface of the fixture
            fix = _resolve(api, bodies, ref_ws, exclude=(item,)) if ref_ws else last_fix
            fix = fix or last_fix
            if fix and fix + '_top_side' in names:
                target = fix + '_top_side'
            elif fix:
                target = fix
        elif 'drawer' in tset or (tw[-1:] == ['it'] and last_drawer
                                   and tset & {'in', 'into', 'inside'}):
            fix = _fixture(api, bodies, names, tw, last_fix)
            target = _drawer_region(names, fix, tw, last_drawer)
        else:
            d = next((x for x in DIRS if x in tset), None)
            ref = _resolve(api, bodies, ref_ws, exclude=(item,)) if ref_ws else last_fix
            if d and ref and ('of' in tset or 'next' in tset):
                rel = 'inside' if tset & {'in', 'into', 'inside'} else 'outside'
                try:
                    target = api.relative_target(ref, d, rel)
                except Exception:
                    target = None
            if target is None and ref:
                regs = [n for n in names if n.startswith(ref + '_') and _is_region(n)]
                try:
                    target = api.nearest(regs[0], [ref] + regs) if regs else ref
                except Exception:
                    target = ref
        if target is None:
            return api.fallback()
        plan.append(('place', item, target, _grasp_for(item)))
        last_item = item

    if not plan:
        return api.fallback()

    # execute strictly in instruction order
    for step in plan:
        try:
            if step[0] == 'drawer':
                api.drawer(step[1], step[2])
            else:
                _, item, target, g = step
                for _ in range(2):
                    api.place_with(item, target, g)
                    ip = np.array(api.pos(item), float)
                    tp = np.array(api.pos(target), float)
                    if np.linalg.norm(ip[:2] - tp[:2]) < 0.08 and ip[2] > tp[2] - 0.05:
                        break
        except Exception:
            try:
                api.grip(False)
                e = np.array(api.eef(), float)
                api.move(e + np.array([0, 0, 0.1]), steps=10)
            except Exception:
                pass
