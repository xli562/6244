import math
import numpy as np

ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl', 'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup', 'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup', 'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop', 'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy',
    'black_book': 'black book', 'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle', 'butter': 'butter box',
    'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet', 'wooden_cabinet': 'wooden cabinet',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack', 'microwave': 'microwave oven',
    'basket': 'basket', 'plate': 'plate',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown', 'wooden', 'pink', 'orange'}
DIRS = ('left', 'right', 'front', 'back')
LEVELS = ('top', 'middle', 'bottom')
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'its', 'that', 'is',
        'please', 'then', 'compartment', 'compartments', 'side', 'next', 'beside', 'drawer',
        'drawers', 'part', 'section', 'slot', 'area', 'region', 'inside', 'into', 'onto',
        'in', 'on', 'at'} | set(DIRS) | set(LEVELS)
PLACE_V = {'put', 'place', 'move', 'set', 'stack', 'insert', 'drop', 'store'}
PICK_V = {'pick', 'grab', 'lift', 'take'}
VERBS = PLACE_V | PICK_V | {'open', 'close', 'shut', 'turn', 'switch', 'push', 'pull'}
PREPS = ('into', 'onto', 'inside', 'in', 'on', 'to', 'next', 'beside', 'at')
REL_NEXT = ('compartment', 'compartments', 'of', 'side', 'part', 'section', 'slot', 'region', 'area')


class Unsupported(Exception):
    pass


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return w


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def resolve(api, bodies, raw, exclude=()):
    W = set(w for w in raw if w not in STOP)
    if not W:
        return None
    best, cands = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, cands = s, [b]
        elif abs(s - best) < 1e-9:
            cands.append(b)
    if not cands:
        return None
    if len(cands) > 1:  # disambiguate "the left bowl" etc.
        for w in DIRS:
            if w in raw:
                key = {'left': lambda p: -p[1], 'right': lambda p: p[1],
                       'front': lambda p: p[0], 'back': lambda p: -p[0]}[w]
                cands = sorted(cands, key=lambda c: key(P(api, c)))
                break
        else:
            cands = sorted(cands)
    return cands[0]


def grasp_mode(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


def regions_of(names, owner):
    return [n for n in names if _is_region(n) and n.startswith(owner + '_')]


def drawer_region(names, owner, tw):
    regs = [r for r in regions_of(names, owner) if r.endswith('_region')]
    lvl = next((w for w in tw if w in LEVELS), None)
    if lvl:
        c = [r for r in regs if lvl in r[len(owner) + 1:].split('_')]
        if c:
            return c[0]
    c = [r for r in regs if any(l in r[len(owner) + 1:].split('_') for l in LEVELS)]
    return c[0] if c else None


def spatial_dir(tw):
    for i, w in enumerate(tw):
        if w in DIRS and i + 1 < len(tw) and tw[i + 1] in REL_NEXT:
            return w
    return None


def place_target(api, names, bodies, prep, tw):
    owner = resolve(api, bodies, tw)
    if owner is None:
        return None, None
    T = set(tw)
    if 'drawer' in T or 'drawers' in T:
        r = drawer_region(names, owner, tw)
        return (r or owner), owner
    d = spatial_dir(tw)
    if d:
        front_of = (prep == 'in' and tw and tw[0] == 'front')
        inside = ('compartment' in T or 'compartments' in T or prep in ('into', 'inside')
                  or (prep == 'in' and not front_of))
        rel = 'inside' if inside else 'outside'
        try:
            return api.relative_target(owner, d, rel), owner
        except Exception:
            c = [r for r in regions_of(names, owner) if d in r.split('_')
                 and (('contain' in r) == inside)]
            if c:
                return c[0], owner
    regs = regions_of(names, owner)
    if 'top' in T and prep in ('on', 'onto'):
        c = [r for r in regs if r.endswith('top_side')]
        if c:
            return c[0], owner
    for key in ('contain', 'cook', 'heating'):
        c = [r for r in regs if key in r and not any(x in r.split('_') for x in DIRS)]
        if c:
            return c[0], owner
    return owner, owner


def split_clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if w == 'then' or (w == 'and' and (nxt in VERBS or nxt == 'then')):
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return out


def split_items(ws):
    parts = [[]]
    for w in ws:
        if w == 'and':
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def build_plan(api, names, bodies, words):
    ops, last_items, last_drawer = [], [], None
    for c in split_clauses(words):
        while c and c[-1] == 'and':
            c = c[:-1]
        if not c:
            continue
        v, rest = c[0], [w for w in c[1:] if w != 'up']
        if v in ('turn', 'switch', 'push', 'pull'):
            raise Unsupported()
        if v in ('open', 'close', 'shut'):
            act = 'open' if v == 'open' else 'close'
            if not rest or rest in (['it'], ['them']):
                reg = last_drawer
            else:
                owner = resolve(api, bodies, rest)
                if owner is None:
                    raise Unsupported()
                reg = drawer_region(names, owner, rest)
            if reg is None:
                raise Unsupported()  # e.g. microwave door
            ops.append(('drawer', reg, act))
            last_drawer = reg
            continue
        idx = next((i for i, w in enumerate(rest) if w in PREPS and i > 0), None)
        if v in PICK_V and idx is None:
            it = resolve(api, bodies, rest)
            if it:
                ops.append(('pick', it))
                last_items = [it]
            continue
        if v not in PLACE_V and v not in PICK_V:
            raise Unsupported()
        if idx is None:
            raise Unsupported()
        item_w, prep, tw = rest[:idx], rest[idx], rest[idx + 1:]
        if tw and tw[0] in ('to', 'of'):  # "next to", "on top of" already handled
            tw = tw[1:]
        if tw in (['it'], ['them']) and last_drawer:
            tgt, owner = last_drawer, None
        else:
            tgt, owner = place_target(api, names, bodies, prep, tw)
        if tgt is None:
            raise Unsupported()
        items = []
        for part in split_items(item_w):
            if part in (['it'], ['them']):
                cand = list(last_items)
            else:
                r = resolve(api, bodies, part, exclude=(owner,))
                cand = [r] if r else []
            for it in cand:
                if it not in items:
                    items.append(it)
        if not items:
            raise Unsupported()
        if ops and ops[-1][0] == 'pick' and ops[-1][1] in items:
            ops.pop()  # "pick up X and place it ..." -> one placement
        for it in items:
            ops.append(('place', it, tgt))
        last_items = items
        if any(l in tgt.split('_') for l in LEVELS) and tgt.endswith('_region'):
            last_drawer = tgt
    return ops


def placed_ok(api, item, target):
    try:
        ip, tp = P(api, item), P(api, target)
    except Exception:
        return True
    tol = 0.05 if 'contain' in target and 'caddy' in target else 0.08
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.08


def do_place(api, item, target):
    mode = grasp_mode(item)
    for _ in range(2):
        try:
            api.place_with(item, target, mode)
        except Exception:
            try:
                api.arrange([(item, target)])
            except Exception:
                pass
        if placed_ok(api, item, target):
            return True
        try:
            api.grip(False)
            api.move(np.array(api.eef(), dtype=float) + np.array([0, 0, 0.10]), steps=10)
        except Exception:
            pass
    return False


def pick_only(api, item):
    p = P(api, item)
    api.grip(False)
    api.move(p + np.array([0, 0, 0.12]), steps=30)
    api.move(p, steps=25)
    api.grip(True)
    api.move(p + np.array([0, 0, 0.15]), steps=25)


def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    words = _words(api.instruction)
    try:
        ops = build_plan(api, names, bodies, words)
    except Exception:
        ops = None
    if not ops:
        return api.fallback()  # unsupported action (stove, microwave door, ...)
    # For "pick up the book and place it in the right compartment of the caddy":
    #   1. target = api.relative_target('desk_caddy_1', 'right', 'inside')
    #   2. api.place_with('black_book_1', target, 'thin_edge')
    for op in ops:
        try:
            if op[0] == 'drawer':
                api.drawer(op[1], op[2])
            elif op[0] == 'place':
                do_place(api, op[1], op[2])
            elif op[0] == 'pick':
                pick_only(api, op[1])
        except Exception:
            try:
                api.grip(False)
            except Exception:
                pass
