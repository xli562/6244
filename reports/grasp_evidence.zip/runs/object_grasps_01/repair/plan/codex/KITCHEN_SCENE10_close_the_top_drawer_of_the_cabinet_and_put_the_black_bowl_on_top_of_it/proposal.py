def run(api):
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    cabinet = next(
        (n for n in names if "cabinet" in n and n.endswith("_1")), None
    )
    bowl = next(
        (n for n in names if "black_bowl" in n and n.endswith("_1")), None
    )

    if (cabinet and bowl and "close" in text and "top drawer" in text
            and "black bowl" in text and "on top" in text
            and cabinet + "_top_region" in names
            and cabinet + "_top_side" in names):
        api.drawer(cabinet + "_top_region", "close")
        api.place_with(bowl, cabinet + "_top_side", "rim")
    else:
        api.fallback()
