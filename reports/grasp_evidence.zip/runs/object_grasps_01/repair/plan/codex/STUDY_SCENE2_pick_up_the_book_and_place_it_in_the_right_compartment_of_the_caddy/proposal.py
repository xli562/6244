def run(api):
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [
        n for n in names
        if n.rsplit("_", 1)[-1].isdigit()
        and "region" not in n and not n.endswith("_side")
    ]

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        extra = {
            "black book": ["book"],
            "desk caddy": ["caddy"],
            "akita black bowl": ["black bowl", "bowl"],
            "porcelain mug": ["white mug"],
            "white yellow mug": ["yellow and white mug", "yellow mug"],
            "red coffee mug": ["red mug"],
            "chefmate 8 frypan": ["frying pan", "pan"],
            "flat stove": ["stove"],
            "white cabinet": ["cabinet"],
        }
        return [base] + extra.get(base, [])

    def mentions(name):
        return [
            (text.find(a), len(a))
            for a in aliases(name) if a in text
        ]

    def region(body, suffix):
        return next((n for n in names if n == body + "_" + suffix), None)

    def place(item, target):
        # Pinch bowl walls; align book edges; use ordinary solid-object grasps.
        grasp = ("thin_edge" if "book" in item else
                 "rim" if "bowl" in item else "standard")
        api.place_with(item, target, grasp)

    matched = sorted(
        [n for n in bodies if mentions(n)],
        key=lambda n: min(p for p, length in mentions(n)),
    )

    if "drawer" in text:
        cabinet = next((n for n in matched if "cabinet" in n), None)
        cabinet = cabinet or next((n for n in bodies if "cabinet" in n), None)
        levels = [s for s in ("top", "middle", "bottom") if s in text]
        if not cabinet or len(levels) != 1:
            return api.fallback()
        target = region(cabinet, levels[0] + "_region")
        if not target:
            return api.fallback()
        items = [n for n in matched if n != cabinet]
        operations = []
        for verb in ("open", "close"):
            if verb in text:
                operations.append((text.find(verb), verb))
        if items:
            starts = [text.find(v) for v in ("put ", "place ", "insert ")
                      if v in text]
            if not starts:
                return api.fallback()
            operations.append((min(starts), "place"))
        for _, operation in sorted(operations):
            if operation == "place":
                for item in items:
                    place(item, target)
            else:
                api.drawer(target, operation)
        return

    if len(matched) != 2 or any(
        phrase in text for phrase in ("turn on", "turn off", "stack")
    ):
        return api.fallback()

    item, reference = matched
    directions = [d for d in ("left", "right", "front", "back") if d in text]
    if len(directions) > 1:
        return api.fallback()

    if directions:
        inside = "compartment" in text or (
            "caddy" in reference and (" in " in text or " into " in text)
        )
        target = api.relative_target(
            reference, directions[0], "inside" if inside else "outside"
        )
    elif " on top " in text:
        target = region(reference, "top_side") or reference
    elif " in " in text or " into " in text:
        target = region(reference, "contain_region") or reference
    else:
        target = region(reference, "cook_region") or reference

    if target:
        place(item, target)
    else:
        api.fallback()
