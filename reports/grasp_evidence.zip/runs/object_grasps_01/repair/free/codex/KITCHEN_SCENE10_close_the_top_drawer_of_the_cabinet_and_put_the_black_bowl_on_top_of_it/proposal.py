def run(api):
    import numpy as np

    text = " ".join(
        api.instruction.lower().replace("-", " ").replace(",", " ").split()
    )
    names = list(api.names())
    bodies = [
        n for n in names
        if n.rsplit("_", 1)[-1].isdigit()
        and "region" not in n
        and not n.endswith("_side")
    ]

    def words(s):
        return s.replace("_", " ")

    def aliases(name):
        base = words(name.rsplit("_", 1)[0])
        result = [base]
        mapping = {
            "akita black bowl": ["black bowl", "bowl"],
            "porcelain mug": ["white mug", "mug"],
            "white yellow mug": [
                "yellow and white mug", "white and yellow mug", "yellow mug"
            ],
            "red coffee mug": ["red coffee mug", "red mug"],
            "black book": ["black book", "book"],
            "cream cheese": ["cream cheese box"],
            "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
            "flat stove": ["stove"],
            "desk caddy": ["desk caddy", "caddy"],
        }
        result.extend(mapping.get(base, []))
        for kind in ("cabinet", "basket", "plate", "bowl", "book", "mug"):
            if kind in base.split():
                result.append(kind)
        return list(set(result))

    def mentions(s, pool=None):
        pool = bodies if pool is None else pool
        padded = " " + s + " "
        hits = []
        for name in pool:
            for alias in aliases(name):
                needle = " " + alias + " "
                start = padded.find(needle)
                while start >= 0:
                    hits.append((start, start + len(needle), name))
                    start = padded.find(needle, start + 1)
        # A specific phrase overrides a generic alias at the same location.
        hits = [
            h for h in hits
            if not any(
                k[0] <= h[0] and k[1] >= h[1]
                and k[1] - k[0] > h[1] - h[0]
                for k in hits
            )
        ]
        result = []
        for _, _, name in sorted(hits):
            if name not in result:
                result.append(name)
        return result

    def region(body, suffix):
        exact = body + "_" + suffix
        if exact in names:
            return exact
        return next(
            (n for n in names if n.startswith(body + "_") and n.endswith(suffix)),
            None,
        )

    def direction(s):
        return next(
            (w for w in s.split() if w in ("left", "right", "front", "back")),
            None,
        )

    def choose(s, pool=None):
        candidates = mentions(s, pool)
        if len(candidates) == 1:
            return candidates[0]
        if not candidates:
            return None
        side = direction(s)
        if side:
            markers = [
                n for n in names
                if side in n.split("_") and "region" in n
                and any(
                    c.rsplit("_", 1)[0] in n
                    or c.split("_")[0] in n
                    for c in candidates
                )
            ]
            if len(markers) == 1:
                return api.nearest(markers[0], candidates)
        return None

    def cabinet_for(s, previous=None):
        cabinets = [n for n in bodies if "cabinet" in n]
        return choose(s, cabinets) or (
            previous if previous in cabinets else
            cabinets[0] if len(cabinets) == 1 else None
        )

    def drawer_region(s, cabinet, previous=None):
        if not cabinet:
            return None
        level = next(
            (w for w in s.split() if w in ("top", "middle", "bottom")),
            None,
        )
        if level:
            return region(cabinet, level + "_region")
        if previous and previous.startswith(cabinet + "_"):
            return previous
        options = [
            region(cabinet, level + "_region")
            for level in ("top", "middle", "bottom")
        ]
        options = [n for n in options if n]
        return options[0] if len(options) == 1 else None

    # Parse the whole instruction before carrying out any physical actions.
    tokens = text.split()
    verbs = {"open", "close", "shut", "put", "place", "move", "insert"}
    unsupported = {"turn", "switch", "push", "pull", "stack", "pick"}
    starts = [i for i, word in enumerate(tokens) if word in verbs | unsupported]
    if not starts or any(tokens[i] in unsupported for i in starts):
        return api.fallback()

    clauses = []
    for j, start in enumerate(starts):
        end = starts[j + 1] if j + 1 < len(starts) else len(tokens)
        chunk = tokens[start:end]
        while chunk and chunk[-1] in ("and", "then"):
            chunk.pop()
        clauses.append((chunk[0], " ".join(chunk[1:])))

    plan = []
    last_fixture = None
    last_drawer = None
    last_items = []

    for verb, clause in clauses:
        if verb in ("open", "close", "shut"):
            cabinet = cabinet_for(clause, last_fixture)
            target = drawer_region(clause, cabinet, last_drawer)
            if not target:
                return api.fallback()
            plan.append(("drawer", target, "open" if verb == "open" else "close"))
            last_fixture, last_drawer = cabinet, target
            continue

        # Keep the complete destination wording for spatial interpretation.
        padded = " " + clause + " "
        separators = [
            " on top of ", " into ", " inside ", " onto ",
            " on ", " in ", " to ",
        ]
        splits = [
            (padded.find(sep), sep) for sep in separators
            if padded.find(sep) >= 0
        ]
        if not splits:
            return api.fallback()
        index, sep = min(splits, key=lambda pair: (pair[0], -len(pair[1])))
        source = padded[:index].strip()
        destination = padded[index + len(sep):].strip()
        items = mentions(source)
        if not items and source in ("it", "them", "the object", "the objects"):
            items = list(last_items)
        if not items:
            return api.fallback()

        # Resolve duplicate instances through a perceived location marker.
        grouped = {}
        for item in items:
            grouped.setdefault(item.rsplit("_", 1)[0], []).append(item)
        resolved = []
        for group in grouped.values():
            if len(group) > 1 and not any(
                w in source.split() for w in ("both", "all", "two")
            ):
                item = choose(source, group)
                if item is None:
                    return api.fallback()
                resolved.append(item)
            else:
                resolved.extend(group)
        items = resolved

        target_body = choose(destination)
        if target_body is None and destination in (
            "it", "of it", "there", "the top", "its top"
        ):
            target_body = last_fixture
        if target_body is None and "drawer" in destination:
            target_body = cabinet_for(destination, last_fixture)
        if target_body is None:
            return api.fallback()

        target = None
        side = direction(destination)
        outside = any(
            phrase in destination
            for phrase in ("next to", "beside", "left of", "right of",
                           "in front of", "behind")
        )
        if "behind" in destination:
            side = "back"

        if "drawer" in destination:
            target = drawer_region(destination, target_body, last_drawer)
            if target:
                last_drawer = target
        elif sep == " on top of " or destination in ("the top", "its top"):
            target = region(target_body, "top_side") or target_body
        elif side and ("caddy" in target_body or outside):
            target = api.relative_target(
                target_body, side, "outside" if outside else "inside"
            )
        elif sep in (" into ", " inside ", " in "):
            target = region(target_body, "contain_region") or target_body
        elif "stove" in target_body:
            target = region(target_body, "cook_region") or target_body
        elif "cabinet" in target_body:
            target = region(target_body, "top_side")
        else:
            target = target_body

        if not target or target_body in items:
            return api.fallback()

        for item in items:
            grasp = (
                "rim" if "bowl" in item else
                "thin_edge" if "book" in item else
                "standard"
            )
            plan.append(("place", item, target, grasp))
        last_items = items
        last_fixture = target_body

    for action in plan:
        if action[0] == "drawer":
            api.drawer(action[1], action[2])
        else:
            api.place_with(action[1], action[2], action[3])
