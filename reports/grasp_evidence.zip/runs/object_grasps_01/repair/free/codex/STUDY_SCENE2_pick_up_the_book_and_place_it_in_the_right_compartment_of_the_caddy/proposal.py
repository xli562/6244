def run(api):
    import numpy as np

    def normalize(s):
        return " ".join(
            s.lower().replace("_", " ").replace("-", " ")
            .replace(",", " ").replace(".", " ").split()
        )

    text = normalize(api.instruction)
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug", "mug"
        ],
        "red coffee mug": ["red coffee mug", "red mug", "mug"],
        "black book": ["black book", "book"],
        "desk caddy": ["desk caddy", "caddy"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["stove"],
        "white cabinet": ["cabinet"],
        "cream cheese": ["cream cheese box", "cream cheese"],
    }

    def aliases(body):
        base = normalize(body.rsplit("_", 1)[0])
        result = [base] + synonyms.get(base, [])
        for word in ("bowl", "plate", "basket", "cabinet", "caddy", "book"):
            if word in base.split():
                result.append(word)
        return sorted(set(result), key=len, reverse=True)

    def mentions(s):
        padded = " " + s + " "
        hits = []
        for body in bodies:
            for alias in aliases(body):
                needle = " " + alias + " "
                start = padded.find(needle)
                while start >= 0:
                    hits.append((start, start + len(needle) - 1, body))
                    start = padded.find(needle, start + 1)
        # Prefer specific names over generic overlapping aliases.
        hits.sort(key=lambda h: (-(h[1] - h[0]), h[0]))
        selected = []
        for hit in hits:
            if not any(hit[0] < h[1] and h[0] < hit[1] for h in selected):
                selected.append(hit)
        return sorted(selected)

    def unique_mentions(s):
        result = []
        for _, _, body in mentions(s):
            if body not in result:
                result.append(body)
        return result

    def region_for(body, fragments):
        regions = [n for n in names if n.startswith(body + "_")]
        for fragment in fragments:
            found = next((n for n in regions if fragment in n), None)
            if found:
                return found
        return None

    def drawer_region(s, previous=None):
        level = next(
            (x for x in ("top", "middle", "bottom")
             if x in s.split()), None
        )
        fixtures = [
            b for b in unique_mentions(s)
            if "cabinet" in b or "drawer" in b
        ]
        candidates = [
            n for n in names
            if "region" in n
            and ("cabinet" in n or "drawer" in n)
            and any("_" + x + "_" in n for x in ("top", "middle", "bottom"))
            and (level is None or "_" + level + "_" in n)
            and (not fixtures or n.startswith(fixtures[-1] + "_"))
        ]
        if level is None and previous in candidates:
            return previous
        return candidates[0] if len(candidates) == 1 else None

    verbs = {
        "pick", "put", "place", "move", "stack", "arrange",
        "open", "close", "shut", "turn", "push", "pull"
    }
    words = text.split()
    starts = [i for i, word in enumerate(words) if word in verbs]
    if not starts:
        return api.fallback()
    clauses = [
        " ".join(words[start:starts[i + 1] if i + 1 < len(starts) else len(words)])
        for i, start in enumerate(starts)
    ]

    pending_items = []
    previous_items = []
    previous_target = None
    previous_drawer = None
    plan = []

    def destination(s):
        nonlocal previous_drawer
        if "drawer" in s:
            target = drawer_region(s, previous_drawer)
            if target:
                previous_drawer = target
            return target

        refs = unique_mentions(s)
        if not refs:
            if any(w in s.split() for w in ("it", "there", "them")):
                return previous_target
            return None
        body = refs[-1]

        direction = next(
            (w for w in s.split() if w in ("left", "right", "front", "back")),
            None
        )
        inside = (
            "compartment" in s or "inside" in s
            or s.startswith(("in ", "into "))
        )
        outside = any(
            phrase in s for phrase in
            ("next to", "beside", "to the left", "to the right",
             "in front of", "behind")
        )
        if direction and ("caddy" in body or "cabinet" in body):
            if outside:
                return api.relative_target(body, direction, "outside")
            if inside:
                return api.relative_target(body, direction, "inside")

        if direction and "plate" in body:
            plates = [b for b in bodies if "plate" in b]
            markers = [
                n for n in names
                if "plate" in n and direction in n and "region" in n
            ]
            if len(markers) == 1:
                return api.nearest(markers[0], plates)

        if "cabinet" in body and (
            "top" in s.split() or s.startswith(("on ", "onto "))
        ):
            return region_for(body, ["top_side"])
        if inside:
            return region_for(body, ["contain_region", "inside_region"]) or body
        if "stove" in body:
            return region_for(body, ["cook_region"]) or body
        return body

    for clause in clauses:
        verb = clause.split()[0]
        if verb == "pick":
            pending_items = unique_mentions(clause)
            if not pending_items:
                return api.fallback()
            continue

        if verb in ("open", "close", "shut"):
            if "drawer" not in clause and previous_drawer is None:
                return api.fallback()
            target = drawer_region(clause, previous_drawer)
            if not target:
                return api.fallback()
            previous_drawer = target
            plan.append(("drawer", target, "open" if verb == "open" else "close"))
            continue

        if verb not in ("put", "place", "move", "stack", "arrange"):
            return api.fallback()

        # Locate the destination preposition after the movable object.
        tokens = clause.split()
        split = next(
            (i for i in range(1, len(tokens))
             if tokens[i] in ("in", "into", "inside", "on", "onto",
                              "to", "beside", "behind", "next")),
            None
        )
        if split is None:
            return api.fallback()
        source_text = " ".join(tokens[1:split])
        target_text = " ".join(tokens[split:])
        items = unique_mentions(source_text)
        if not items:
            items = pending_items or previous_items
        target = destination(target_text)
        if not items or not target or target in items:
            return api.fallback()

        for item in items:
            grasp = (
                "thin_edge" if "book" in item
                else "rim" if "bowl" in item
                else "standard"
            )
            plan.append(("place", item, target, grasp))
        previous_items = list(items)
        previous_target = target
        pending_items = []

    if not plan:
        return api.fallback()

    for action in plan:
        if action[0] == "drawer":
            result = api.drawer(action[1], action[2])
        else:
            result = api.place_with(action[1], action[2], action[3])
        if result is False:
            return
