import math
import numpy as np

ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl', 'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup', 'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup', 'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop', 'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy',
    'black_book': 'black book', 'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle', 'butter': 'butter box',
    'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'new_salad_dressing': 'salad dressing bottle', 'white_cabinet': 'white cabinet',
    'wooden_cabinet': 'wooden cabinet', 'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack',
    'microwave': 'microwave oven', 'basket': 'basket', 'plate': 'plate',
    'glazed_rim_porcelain_ramekin': 'ramekin', 'cookies': 'cookie cookies box',
    'wooden_tray': 'wooden tray', 'wooden_two_layer_shelf': 'wooden shelf',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown', 'wooden', 'pink', 'orange'}
DIRS = ('left', 'right', 'front', 'back')
LEVELS = ('top', 'middle', 'bottom')
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'top', 'left', 'right',
        'front', 'back', 'bottom', 'middle', 'compartment', 'side', 'its', 'that', 'is',
        'please', 'then', 'drawer', 'drawers', 'one', 'on', 'in', 'into', 'onto', 'inside'}
VERBS = {'put', 'place', 'turn', 'switch', 'close', 'shut', 'open', 'pick', 'push', 'pull',
         'move', 'stack', 'lift', 'grab', 'take', 'set'}
PREPS = ('into', 'onto', 'inside', 'in', 'on')
QUAL = ('next', 'between', 'from', 'near', 'beside', 'on', 'in', 'at', 'inside', 'under')


def V(*a):
    return np.array(a, dtype=float)


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def E(api):
    return np.array(api.eef(), dtype=float)


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return w


def resolve(api, names, bodies, ws, exclude=(), near=None):
    W = set(w for w in ws if w not in STOP)
    if not W:
        return None
    best, cands = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, cands = s, [b]
        elif abs(s - best) < 1e-9:
            cands.append(b)
    if not cands:
        return None
    if len(cands) == 1:
        return cands[0]
    dw = [d for d in DIRS if d in ws]
    if dw:
        head = _base(cands[0]).split('_')[-1]
        hints = [n for n in names if _is_region(n) and dw[0] in n.split('_')
                 and head in n.split('_')]
        if hints:
            try:
                r = api.nearest(hints[0], list(cands))
                if r in cands:
                    return r
            except Exception:
                pass
            hp = P(api, hints[0])
            return min(cands, key=lambda c: np.linalg.norm(P(api, c)[:2] - hp[:2]))
        keyf = {'left': lambda p: -p[1], 'right': lambda p: p[1],
                'front': lambda p: p[0], 'back': lambda p: -p[0]}[dw[0]]
        return min(cands, key=lambda c: keyf(P(api, c)))
    if near is not None:
        return min(cands, key=lambda c: np.linalg.norm(P(api, c)[:2] - near[:2]))
    return sorted(cands)[0]


def drawer_regions(names, owner):
    return [owner + '_' + l + '_region' for l in LEVELS if owner + '_' + l + '_region' in names]


def is_drawer_region(names, name, owner):
    return owner is not None and name in drawer_regions(names, owner)


def pick_region(names, owner, tw):
    regs = [n for n in names if _is_region(n) and n.startswith(owner + '_')]
    if not regs:
        return owner
    R = set(tw)
    best, bs = owner, -1e9
    for r in regs:
        suf = r[len(owner) + 1:].split('_')
        toks = set(suf) - {'region', 'contain', 'side'}
        s = 3 * len(toks & R)
        if 'side' in suf and 'top' not in R:
            s -= 4
        if not toks or toks <= {'cook', 'heating'}:
            s += 1
        if s > bs:
            bs, best = s, r
    return best


def target_of(api, names, B, tw, prep, ctx):
    tw = [w for w in tw if w not in ('the', 'a', 'an')]
    refit = any(w in ('it', 'them', 'its') for w in tw)
    if not tw or tw in (['it'], ['them']):
        lt = ctx['target']
        if lt is None:
            return None
        name, owner = lt
        if prep in ('on', 'onto') and is_drawer_region(names, name, owner):
            ts = owner + '_top_side'
            if ts in names:
                return (ts, owner)
        return lt
    for i, w in enumerate(tw[:3]):
        if w in DIRS and 'of' in tw[i + 1:i + 4]:
            j = tw.index('of', i + 1)
            rw = tw[j + 1:]
            if not rw or rw in (['it'], ['them']):
                ref = ctx['fix']
            else:
                ref = resolve(api, names, B, rw)
            rel = 'inside' if ('compartment' in tw or prep in ('in', 'into', 'inside')) else 'outside'
            if ref:
                try:
                    r = api.relative_target(ref, w, rel)
                    if r:
                        return (r, ref)
                except Exception:
                    pass
            break
    owner = None
    if refit:
        owner = ctx['fix']
    if owner is None:
        owner = resolve(api, names, B, tw)
    if owner is None:
        return None
    if 'drawer' in tw or 'drawers' in tw:
        dr = drawer_regions(names, owner)
        lv = next((l for l in LEVELS if l in tw), None)
        if lv and owner + '_' + lv + '_region' in names:
            return (owner + '_' + lv + '_region', owner)
        if dr:
            return (dr[0], owner)
    ts = owner + '_top_side'
    if ts in names and prep in ('on', 'onto'):
        return (ts, owner)
    return (pick_region(names, owner, tw), owner)


def resolve_item(api, names, B, ws, exclude, ctx):
    ws = [w for w in ws if w not in ('up',)]
    if ws in (['it'], ['them']) or not [w for w in ws if w not in STOP]:
        return ctx['item']
    q = None
    for i, w in enumerate(ws):
        if i > 0 and w in QUAL:
            q = i
            break
    near = None
    head = ws
    if q is not None:
        head, qual = ws[:q], [w for w in ws[q + 1:] if w != 'to']
        refs = [qual]
        if 'and' in qual:
            k = qual.index('and')
            refs = [qual[:k], qual[k + 1:]]
        pts = []
        for r in refs:
            t = target_of(api, names, B, r, ws[q], ctx) if r else None
            if t:
                try:
                    pts.append(P(api, t[0]))
                except Exception:
                    pass
        if pts:
            near = np.mean(pts, axis=0)
    return resolve(api, names, B, head, exclude=exclude, near=near)


def split_clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if (w == 'and' and (nxt in VERBS or nxt == 'then')) or w == 'then':
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return out


def split_items(ws):
    both = 'both' in ws
    has_the = any(ws[j] == 'and' and j + 1 < len(ws) and ws[j + 1] in ('the', 'a')
                  for j in range(len(ws)))
    parts = [[]]
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if w == 'and' and ((has_the and nxt in ('the', 'a')) or (both and not has_the)):
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def mode_for(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


def plan(api, names):
    B = [n for n in names if not _is_region(n)]
    words = _words(api.instruction)
    ctx = {'item': None, 'target': None, 'fix': None}
    ops = []
    for c in split_clauses(words):
        vi = next((i for i, w in enumerate(c) if w in VERBS), None)
        if vi is None:
            continue
        v, rest = c[vi], [w for w in c[vi + 1:]]
        while rest and rest[-1] == 'and':
            rest = rest[:-1]
        if v in ('turn', 'switch'):
            ops.append(('unsupported',))
            continue
        if v in ('close', 'shut', 'open', 'push', 'pull') and (
                v in ('close', 'shut', 'open') or 'drawer' in rest):
            act = 'open' if v in ('open', 'pull') else 'close'
            region, owner = None, None
            if not rest or rest in (['it'], ['them']):
                lt = ctx['target']
                if lt and is_drawer_region(names, lt[0], lt[1]):
                    region, owner = lt
                elif ctx['fix']:
                    owner = ctx['fix']
            else:
                owner = resolve(api, names, B, rest)
                if owner is None:
                    cabs = [b for b in B if drawer_regions(names, b)]
                    owner = cabs[0] if cabs else None
            if region is None and owner is not None:
                dr = drawer_regions(names, owner)
                lv = next((l for l in LEVELS if l in rest), None)
                if lv and owner + '_' + lv + '_region' in dr:
                    region = owner + '_' + lv + '_region'
                elif dr:
                    op_ = P(api, owner)
                    dist = lambda r: np.linalg.norm(P(api, r)[:2] - op_[:2])
                    region = max(dr, key=dist) if act == 'close' else min(dr, key=dist)
            if region is None:
                ops.append(('unsupported',))
                continue
            ops.append(('drawer', region, act, owner))
            ctx['target'], ctx['fix'] = (region, owner), owner
            continue
        rest = [w for w in rest if w != 'up']
        idx = None
        for i, w in enumerate(rest):
            if i == 0:
                continue
            if w in PREPS:
                idx = i
                break
            if w == 'to' and rest[i - 1] != 'next':
                nx = rest[i + 1:i + 3]
                if any(d in nx for d in DIRS):
                    idx = i
                    break
        if v in ('pick', 'grab', 'lift', 'take') and idx is None:
            it = resolve_item(api, names, B, rest, (), ctx)
            if it:
                ops.append(('pick', it))
                ctx['item'] = it
            continue
        if idx is None:
            item_w, tw, prep = rest, [], 'on'
        else:
            item_w, tw, prep = rest[:idx], rest[idx + 1:], rest[idx]
        if not tw and prep == 'inside':
            prep = 'in'
        tgt = target_of(api, names, B, tw, prep, ctx)
        if tgt is None:
            ops.append(('unsupported',))
            continue
        items = []
        for part in split_items(item_w):
            it = resolve_item(api, names, B, part, (tgt[1], tgt[0]), ctx)
            if it and it not in items:
                items.append(it)
        if not items:
            ops.append(('unsupported',))
            continue
        if ops and ops[-1][0] == 'pick' and ops[-1][1] in items:
            ops.pop()
        if is_drawer_region(names, tgt[0], tgt[1]):
            if not any(o[0] == 'drawer' and o[1] == tgt[0] and o[2] == 'open' for o in ops):
                ops.append(('drawer', tgt[0], 'open', tgt[1]))
        for it in items:
            ops.append(('place', it, tgt[0]))
        ctx['item'] = items[-1]
        ctx['target'], ctx['fix'] = tgt, tgt[1]
    return ops


def placed_ok(api, item, target):
    try:
        ip, tp = P(api, item), P(api, target)
    except Exception:
        return True
    tol = 0.06 if 'caddy' in target else 0.09
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.07


def recover(api):
    try:
        api.grip(False)
        api.move(E(api) + V(0, 0, 0.10), steps=12)
    except Exception:
        pass


def do_place(api, item, target):
    mode = mode_for(item)
    for attempt in range(2):
        try:
            api.place_with(item, target, mode)
        except Exception:
            try:
                api.place_with(item, target, 'standard')
            except Exception:
                try:
                    api.transfer(item, target)
                except Exception:
                    pass
        if placed_ok(api, item, target):
            return True
        recover(api)
    return False


def do_pick(api, item):
    p = P(api, item)
    api.grip(False)
    e = E(api)
    api.move(V(e[0], e[1], max(e[2], p[2] + 0.12)), steps=10)
    api.move(p + V(0, 0, 0.10), steps=25)
    api.move(p, steps=20)
    api.grip(True)
    api.move(p + V(0, 0, 0.15), steps=25)


def run(api):
    names = list(api.names())
    try:
        ops = plan(api, names)
    except Exception:
        ops = None
    if not ops or any(o[0] == 'unsupported' for o in ops):
        api.fallback()
        return
    for op in ops:
        try:
            if op[0] == 'drawer':
                api.drawer(op[1], op[2])
            elif op[0] == 'place':
                do_place(api, op[1], op[2])
            elif op[0] == 'pick':
                do_pick(api, op[1])
        except Exception:
            recover(api)
