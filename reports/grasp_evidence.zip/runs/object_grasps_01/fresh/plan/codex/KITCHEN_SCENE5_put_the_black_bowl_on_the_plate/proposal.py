def run(api):
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug"],
        "white yellow mug": ["yellow and white mug", "yellow mug"],
        "red coffee mug": ["red mug"],
        "black book": ["book"],
        "chefmate 8 frypan": ["frying pan", "pan"],
        "flat stove": ["stove"],
        "white cabinet": ["cabinet"],
        "desk caddy": ["caddy"],
    }

    def mentions(clause):
        hits = []
        for body in bodies:
            base = body.rsplit("_", 1)[0].replace("_", " ")
            matches = []
            for alias in [base] + synonyms.get(base, []):
                start = (" " + clause + " ").find(" " + alias + " ")
                if start >= 0:
                    matches.append((len(alias), start))
            if matches:
                length, start = max(matches)
                hits.append((start, -length, body))
        return [h[2] for h in sorted(hits)]

    def grasp(item):
        if "bowl" in item:
            return "rim"
        if "book" in item:
            return "thin_edge"
        return "standard"

    # Build the complete ordered plan before performing any actions.
    clauses = text
    for verb in ("put", "place", "open", "close"):
        clauses = clauses.replace(" and " + verb, "|" + verb)
        clauses = clauses.replace(" then " + verb, "|" + verb)
    clauses = clauses.replace(" and|", "|").replace(",|", "|")
    plan = []
    last_drawer = None

    for clause in clauses.split("|"):
        clause = clause.strip(" ,.")
        if clause.startswith(("open ", "close ")):
            level = next(
                (s for s in ("top", "middle", "bottom") if s in clause),
                None,
            )
            candidates = [
                n for n in names
                if "cabinet" in n and level
                and n.endswith("_" + level + "_region")
            ]
            region = candidates[0] if len(candidates) == 1 else last_drawer
            if region is None:
                return api.fallback()
            last_drawer = region
            plan.append(("drawer", region, clause.split()[0]))
            continue

        if not clause.startswith(("put ", "place ")):
            return api.fallback()

        items = mentions(clause)
        if "drawer" in clause:
            level = next(
                (s for s in ("top", "middle", "bottom") if s in clause),
                None,
            )
            regions = [
                n for n in names
                if "cabinet" in n and level
                and n.endswith("_" + level + "_region")
            ]
            target = regions[0] if len(regions) == 1 else last_drawer
            items = [n for n in items if "cabinet" not in n]
            if target is None or not items:
                return api.fallback()
        else:
            if len(items) < 2:
                return api.fallback()
            target = items.pop()
            direction = next(
                (s for s in ("left", "right", "front", "back")
                 if s in clause.split()),
                None,
            )
            if direction:
                # Let the previous policy resolve directional object identities.
                if not any(s in target for s in ("caddy", "cabinet")):
                    return api.fallback()
                relation = (
                    "outside" if any(s in clause for s in
                                     ("next to", "beside", "outside"))
                    else "inside"
                )
                target = ("relative", target, direction, relation)
            else:
                suffix = (
                    "_contain_region"
                    if " in " in clause or " into " in clause
                    else "_top_side"
                )
                if target + suffix in names:
                    target += suffix

        for item in items:
            plan.append(("place", item, target))

    if not plan:
        return api.fallback()

    for operation, subject, target in plan:
        if operation == "drawer":
            api.drawer(subject, target)
        else:
            if isinstance(target, tuple):
                _, reference, direction, relation = target
                target = api.relative_target(reference, direction, relation)
            # Black bowl → plate uses a rim grasp.
            api.place_with(subject, target, grasp(subject))
