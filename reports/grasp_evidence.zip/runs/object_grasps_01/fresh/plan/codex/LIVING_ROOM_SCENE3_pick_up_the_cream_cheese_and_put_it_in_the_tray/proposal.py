def run(api):
    instruction = api.instruction.lower()
    names = list(api.names())

    if "cream cheese" in instruction and "tray" in instruction:
        item = next((n for n in names if n.startswith("cream_cheese_")
                     and n.rsplit("_", 1)[-1].isdigit()), None)
        tray = next((n for n in names if "tray" in n
                     and n.rsplit("_", 1)[-1].isdigit()), None)
        if item and tray:
            target = tray + "_contain_region"
            if target not in names:
                target = tray
            # Pinch the solid cream cheese package with a standard grasp.
            api.place_with(item, target, grasp="standard")
            return

    api.fallback()
