def run(api):
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())

    if "stack" in text and "black bowl" in text and " on " in text:
        source_text, target_text = text.split(" on ", 1)
        bowls = [n for n in names if n.startswith("akita_black_bowl_")
                 and n.rsplit("_", 1)[-1].isdigit()]

        def resolve(description):
            location = next(
                (s for s in ("front", "middle", "back", "left", "right")
                 if s in description.split()), None
            )
            regions = [
                n for n in names
                if location and "black_bowl" in n
                and "_" + location + "_init_region" in n
            ]
            if len(regions) == 1 and bowls:
                return api.nearest(regions[0], bowls)
            return None

        # Resolve both bowls before moving either one.
        source = resolve(source_text)
        target = resolve(target_text)
        if source and target and source != target:
            # Pinch the open bowl's rim, then stack it on the target bowl.
            api.place_with(source, target, "rim")
            return

    api.fallback()
