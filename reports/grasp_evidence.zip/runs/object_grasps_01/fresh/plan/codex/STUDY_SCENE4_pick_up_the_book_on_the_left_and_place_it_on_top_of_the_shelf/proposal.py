def run(api):
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    books = [n for n in names if "book" in n and n.rsplit("_", 1)[-1].isdigit()]
    shelves = [n for n in names if "shelf" in n and n.rsplit("_", 1)[-1].isdigit()]

    if books and shelves and "book" in text and "shelf" in text:
        shelf = shelves[0]
        target = shelf + "_top_side"
        if "top" not in text or target not in names:
            return api.fallback()

        for color in ("yellow", "black", "red", "white"):
            if color + " book" in text:
                books = [n for n in books if color in n]

        side = next((s for s in ("left", "right") if s in text), None)
        if side:
            markers = [
                n for n in names
                if "book" in n and side + "_init_region" in n
            ]
            if len(markers) != 1:
                return api.fallback()
            item = api.nearest(markers[0], books)
        elif len(books) == 1:
            item = books[0]
        else:
            return api.fallback()

        # Pinch the book's thin edge, then place it on the shelf's top surface.
        return api.place_with(item, target, "thin_edge")

    return api.fallback()
