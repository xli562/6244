def run(api):
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())

    if "butter" not in text or "drawer" not in text:
        return api.fallback()

    butters = [
        n for n in names
        if n.startswith("butter_") and n.rsplit("_", 1)[-1].isdigit()
    ]
    level = next((s for s in ("top", "middle", "bottom")
                  if s + " drawer" in text), None)
    drawers = [
        n for n in names
        if "cabinet" in n and level
        and n.endswith("_" + level + "_region")
    ]
    side = next((s for s in ("front", "back", "left", "right")
                 if "at the " + s in text), None)
    markers = [
        n for n in names
        if side and "butter_" + side + "_init_region" in n
    ]

    if len(drawers) != 1 or not butters:
        return api.fallback()
    if side:
        if len(markers) != 1:
            return api.fallback()
        item = api.nearest(markers[0], butters)
    elif len(butters) == 1:
        item = butters[0]
    else:
        return api.fallback()

    drawer = drawers[0]
    api.drawer(drawer, "open")
    api.place_with(item, drawer, "standard")  # Solid butter package.
    if "close" in text or "shut" in text:
        api.drawer(drawer, "close")
