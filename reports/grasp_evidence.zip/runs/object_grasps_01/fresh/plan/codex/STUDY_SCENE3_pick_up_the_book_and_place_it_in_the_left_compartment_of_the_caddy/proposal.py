def run(api):
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [n for n in names if n.rsplit("_", 1)[-1].isdigit()
              and "region" not in n]

    # Resolve the requested movable object and fixture.
    caddy = next((n for n in bodies if "caddy" in n), None)
    direction = next((d for d in ("left", "right", "front", "back")
                      if d in text.split()), None)

    if caddy and "caddy" in text and direction:
        inside = any(w in text for w in
                     ("compartment", "inside", "into", " in "))
        outside = any(w in text for w in
                      ("next to", "beside", "to the", "in front of", "behind"))
        if inside and not outside:
            relation = "inside"
        elif outside:
            relation = "outside"
        else:
            return api.fallback()

        items = []
        for name in bodies:
            if name == caddy:
                continue
            label = name.rsplit("_", 1)[0].replace("_", " ")
            kind = next((k for k in ("book", "bowl", "mug", "cup")
                         if k in label), None)
            if label in text or (kind and kind in text):
                items.append(name)

        # Ambiguous objects are left to the general policy.
        if len(items) == 1:
            target = api.relative_target(caddy, direction, relation)
            if target is not None:
                item = items[0]
                grasp = ("thin_edge" if "book" in item else
                         "rim" if "bowl" in item else "standard")
                return api.place_with(item, target, grasp)

    return api.fallback()
