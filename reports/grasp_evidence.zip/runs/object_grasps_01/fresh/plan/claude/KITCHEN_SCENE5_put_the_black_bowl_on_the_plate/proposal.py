import math
import numpy as np

ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl', 'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup', 'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup', 'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop', 'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy',
    'black_book': 'black book', 'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle', 'butter': 'butter box',
    'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'new_salad_dressing': 'salad dressing bottle', 'cookies': 'cookie cookies box',
    'glazed_rim_porcelain_ramekin': 'ramekin', 'white_cabinet': 'white cabinet drawer drawers',
    'wooden_cabinet': 'wooden cabinet drawer drawers', 'wine_bottle': 'wine bottle',
    'wine_rack': 'wine rack', 'microwave': 'microwave oven', 'basket': 'basket', 'plate': 'plate',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown', 'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'top', 'left', 'right',
        'front', 'back', 'bottom', 'middle', 'compartment', 'side', 'its', 'that', 'is',
        'please', 'then', 'on', 'in', 'into', 'onto', 'inside', 'at'}
VERBS = {'put', 'place', 'turn', 'switch', 'close', 'shut', 'open', 'pick', 'push', 'pull',
         'move', 'stack', 'lift', 'grab', 'take', 'set'}
PLACE_PREPS = ('onto', 'into', 'inside', 'in', 'on', 'to', 'at', 'next', 'beside', 'near', 'behind')
REL_PREPS = ('on', 'in', 'from', 'next', 'near', 'beside', 'between', 'by', 'at', 'inside')
DIRS = {'left': 'left', 'right': 'right', 'front': 'front', 'back': 'back', 'behind': 'back'}
LEVELS = ('top', 'middle', 'bottom')


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    w |= set(ALIAS.get(base, '').split())
    return w


def resolve(api, bodies, ws, exclude=(), ref=None):
    W = set(w for w in ws if w not in STOP)
    if not W:
        return None
    best, cands = None, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if not m:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if best is None or s > best:
            best, cands = s, [b]
        elif s == best:
            cands.append(b)
    if not cands:
        return None
    cands.sort()
    if len(cands) > 1:
        d = next((DIRS[w] for w in ws if w in DIRS), None)
        if d:
            key = {'left': lambda p: -p[1], 'right': lambda p: p[1],
                   'front': lambda p: p[0], 'back': lambda p: -p[0]}[d]
            cands.sort(key=lambda c: key(P(api, c)))
        elif ref:
            try:
                r = api.nearest(ref, cands)
                if r in cands:
                    return r
            except Exception:
                pass
    return cands[0]


def split_clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if w == 'then' or (w == 'and' and (nxt in VERBS or nxt == 'then')):
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return out


def split_items(ws):
    parts = [[]]
    for w in ws:
        if w == 'and':
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def item_with_ref(api, bodies, names, ws, exclude=()):
    """'black bowl on the cookie box' -> nearest-resolved black bowl"""
    ref = None
    for i, w in enumerate(ws):
        if w in REL_PREPS and i > 0:
            rw = [x for x in ws[i + 1:] if x != 'to']
            ref = resolve(api, bodies, rw)
            ws = ws[:i]
            break
    return resolve(api, bodies, ws, exclude=exclude, ref=ref)


def drawer_owners(names, bodies):
    return [b for b in bodies if any('%s_%s_region' % (b, l) in names for l in LEVELS)]


def drawer_region(api, names, bodies, ws, last_drawer):
    owners = drawer_owners(names, bodies)
    if not owners:
        return None
    owner = resolve(api, owners, ws) or owners[0]
    lvl = next((l for l in LEVELS if l in ws), None)
    if lvl and '%s_%s_region' % (owner, lvl) in names:
        return '%s_%s_region' % (owner, lvl)
    if last_drawer and last_drawer.startswith(owner + '_'):
        return last_drawer
    for l in LEVELS:
        if '%s_%s_region' % (owner, l) in names:
            return '%s_%s_region' % (owner, l)
    return None


def resolve_target(api, names, bodies, prep, tw, last_drawer, last_fix):
    """returns target name, or 'UNSUPPORTED', or None"""
    if tw in (['it'], ['them']):
        if last_drawer:
            return last_drawer
        return last_fix
    d = next((DIRS[w] for w in tw if w in DIRS), None)
    if d:
        rel = 'inside' if ('compartment' in tw or prep in ('in', 'into', 'inside')) else 'outside'
        rw = tw[tw.index('of') + 1:] if 'of' in tw else tw
        ref = resolve(api, bodies, rw)
        if ref is None:
            return None
        try:
            return api.relative_target(ref, d, rel)
        except Exception:
            return 'UNSUPPORTED'
    if prep in ('next', 'beside', 'near', 'to'):
        return 'UNSUPPORTED'
    owner = resolve(api, bodies, tw)
    if owner is None:
        return None
    if owner in drawer_owners(names, bodies):
        if 'drawer' in tw or 'drawers' in tw or any(l in tw for l in ('middle', 'bottom')) \
                or ('top' in tw and prep in ('in', 'into', 'inside')):
            return drawer_region(api, names, bodies, tw, last_drawer)
        if owner + '_top_side' in names:
            return owner + '_top_side'
    regs = [n for n in names if n.startswith(owner + '_') and _is_region(n)
            and 'init' not in n]
    for key in ('contain', 'cook', 'heating'):
        for r in regs:
            if key in r:
                return r
    return owner


def build_plan(api, names, bodies, words):
    ops = []
    last_item, last_drawer, last_fix = None, None, None
    for c in split_clauses(words):
        while c and c[-1] == 'and':
            c = c[:-1]
        if not c:
            continue
        v, rest = c[0], [w for w in c[1:] if w != 'up']
        if v in ('turn', 'switch'):
            ops.append(('unsupported',))
            continue
        if v in ('open', 'close', 'shut') or (v in ('pull', 'push') and 'drawer' in rest):
            if rest in ([], ['it'], ['them']) and last_drawer:
                reg = last_drawer
            elif 'drawer' in rest or 'drawers' in rest or \
                    resolve(api, drawer_owners(names, bodies), rest):
                reg = drawer_region(api, names, bodies, rest, last_drawer)
            else:
                reg = None
            if reg is None:
                ops.append(('unsupported',))
                continue
            ops.append(('drawer', reg, 'open' if v in ('open', 'pull') else 'close'))
            last_drawer = reg
            continue
        idx = None
        for i, w in enumerate(rest):
            if w in PLACE_PREPS and i > 0:
                idx = i
                break
        if v in ('pick', 'grab', 'take', 'lift'):
            it = item_with_ref(api, bodies, names, rest)
            if it:
                ops.append(('pick', it))
                last_item = it
            continue
        if idx is None:
            ops.append(('unsupported',))
            continue
        item_w, prep, tw = rest[:idx], rest[idx], rest[idx + 1:]
        tgt = resolve_target(api, names, bodies, prep, tw, last_drawer, last_fix)
        if tgt is None or tgt == 'UNSUPPORTED':
            ops.append(('unsupported',))
            continue
        owner = next((b for b in bodies if tgt == b or tgt.startswith(b + '_')), tgt)
        items = []
        for part in split_items(item_w):
            if part in (['it'], ['them']):
                it = last_item
            else:
                it = item_with_ref(api, bodies, names, part, exclude=(owner,))
            if it and it not in items:
                items.append(it)
        if not items:
            ops.append(('unsupported',))
            continue
        if ops and ops[-1][0] == 'pick' and ops[-1][1] in items:
            ops.pop()
        for it in items:
            ops.append(('place', it, tgt))
        last_item, last_fix = items[-1], tgt
    return ops


# ---------------------------------------------------------------- skills
def grasp_for(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'           # pinch the wall of an open bowl
    if 'book' in b:
        return 'thin_edge'     # jaws across the narrow book
    return 'standard'


def placed_ok(api, item, target):
    ip, tp = P(api, item), P(api, target)
    tol = 0.045 if 'caddy' in target else (0.08 if ('basket' in target or 'contain' in target) else 0.07)
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.06


def recover(api):
    try:
        api.grip(False)
        e = np.array(api.eef(), dtype=float)
        api.move(e + np.array([0, 0, 0.12]), steps=15)
    except Exception:
        pass


def place(api, item, target):
    g = grasp_for(item)
    for _ in range(2):
        try:
            api.place_with(item, target, g)
        except Exception:
            pass
        if placed_ok(api, item, target):
            return True
        recover(api)
    gr = (0.0, 0.06, 0.025) if g == 'rim' else (0.0, 0.0, 0.0)
    try:
        api.transfer(item, target, grasp=gr, drop=(0.0, 0.0, 0.08))
    except Exception:
        pass
    ok = placed_ok(api, item, target)
    if not ok:
        recover(api)
    return ok


def pick_only(api, item):
    p = P(api, item)
    api.grip(False)
    api.move(p + np.array([0, 0, 0.12]), steps=30)
    api.move(p, steps=25)
    api.grip(True)
    api.move(p + np.array([0, 0, 0.15]), steps=25)


# ---------------------------------------------------------------- main
def run(api):
    try:
        names = list(api.names())
        bodies = [n for n in names if not _is_region(n)]
        ops = build_plan(api, names, bodies, _words(api.instruction))
    except Exception:
        ops = None
    if not ops or any(o[0] == 'unsupported' for o in ops):
        api.fallback()
        return
    for op in ops:
        try:
            if op[0] == 'drawer':
                api.drawer(op[1], op[2])
            elif op[0] == 'place':
                place(api, op[1], op[2])
            elif op[0] == 'pick':
                pick_only(api, op[1])
        except Exception:
            recover(api)
