import math
import numpy as np

ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl', 'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup', 'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup', 'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop', 'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy',
    'black_book': 'black book', 'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle', 'butter': 'butter box',
    'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet', 'wooden_cabinet': 'wooden cabinet',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack', 'microwave': 'microwave oven',
    'basket': 'basket', 'plate': 'plate', 'wooden_tray': 'wooden tray',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown', 'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'top', 'left', 'right',
        'front', 'back', 'bottom', 'middle', 'compartment', 'side', 'its', 'that', 'is',
        'please', 'then', 'next', 'beside'}
VERBS = {'put', 'place', 'turn', 'switch', 'close', 'shut', 'open', 'pick', 'push', 'pull',
         'move', 'stack', 'lift', 'grab', 'take', 'set'}
PREPS = ('into', 'onto', 'inside', 'in', 'on', 'to', 'next', 'beside')
DIRS = ('left', 'right', 'front', 'back')


def V(*a):
    return np.array(a, dtype=float)


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def E(api):
    return np.array(api.eef(), dtype=float)


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return w


def _spatial(api, names, raw, cands):
    for w in DIRS:
        if w in raw:
            head = _base(cands[0]).split('_')[-1]
            hints = [n for n in names if _is_region(n) and w in n.split('_') and head in n.split('_')]
            if hints:
                hp = P(api, hints[0])
                return sorted(cands, key=lambda c: np.linalg.norm(P(api, c)[:2] - hp[:2]))
            keyf = {'left': lambda p: -p[1], 'right': lambda p: p[1],
                    'front': lambda p: p[0], 'back': lambda p: -p[0]}[w]
            return sorted(cands, key=lambda c: keyf(P(api, c)))
    return sorted(cands)


def resolve(api, names, bodies, raw, exclude=()):
    W = set(w for w in raw if w not in STOP)
    if not W:
        return None
    best, cands = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, cands = s, [b]
        elif abs(s - best) < 1e-9:
            cands.append(b)
    if not cands:
        return None
    if len(cands) > 1:
        cands = _spatial(api, names, raw, cands)
    return cands[0]


def resolve_target(api, names, bodies, raw, prep=None):
    obj = resolve(api, names, bodies, raw)
    if obj is None:
        return None
    R = set(raw)
    # exact spatial wording -> shared relative_target skill
    d = next((w for w in raw if w in DIRS), None)
    if d is not None and ('of' in R or prep in ('next', 'beside', 'to')):
        inside = ('compartment' in R or 'drawer' in R or prep in ('in', 'into', 'inside'))
        try:
            r = api.relative_target(obj, d, 'inside' if inside else 'outside')
            if r and r in names:
                return (r, obj)
        except Exception:
            pass
    regs = [n for n in names if _is_region(n) and n.startswith(obj + '_')]
    if not regs:
        return (obj, obj)
    drawer = 'drawer' in R or 'drawers' in R
    best, bs = None, -1e9
    for r in regs:
        suf = r[len(obj) + 1:].split('_')
        toks = set(suf) - {'region', 'contain', 'side'}
        s = 3 * len(toks & R)
        if drawer and 'side' in suf:
            s -= 5
        if (not drawer) and 'top' in R and 'side' in suf:
            s += 2
        if not toks or toks <= {'cook', 'heating'}:
            s += 1
        if s > bs:
            bs, best = s, r
    return (best, obj)


def split_clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if (w == 'and' and (nxt in VERBS or nxt == 'then')) or w == 'then':
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return [c for c in out if c]


def split_items(ws):
    both = 'both' in ws
    has_the = any(ws[j] == 'and' and j + 1 < len(ws) and ws[j + 1] in ('the', 'a')
                  for j in range(len(ws)))
    parts = [[]]
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if w == 'and' and ((has_the and nxt in ('the', 'a')) or (both and not has_the)):
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def build_plan(api, names, bodies, words):
    ops = []
    last_item, last_target, last_fix = None, None, None
    for c in split_clauses(words):
        while c and c[-1] == 'and':
            c = c[:-1]
        if not c:
            continue
        v, rest = c[0], c[1:]
        if v in ('turn', 'switch'):
            ops.append(('turn',))
            continue
        if v in ('close', 'shut', 'open'):
            if not rest or rest in (['it'], ['them']):
                tgt = last_target
            else:
                tgt = resolve_target(api, names, bodies, rest)
            if tgt:
                ops.append(('open' if v == 'open' else 'close', tgt, 'drawer' in rest))
                last_target, last_fix = tgt, tgt[1]
            continue
        rest = [w for w in rest if w != 'up']
        idx = None
        for i, w in enumerate(rest):
            if w in PREPS and i > 0:
                idx = i
                break
        if v in ('pick', 'grab', 'lift', 'take') and idx is None:
            it = resolve(api, names, bodies, rest)
            if it:
                ops.append(('pick', it))
                last_item = it
            continue
        item_w, tw = (rest, []) if idx is None else (rest[:idx], rest[idx + 1:])
        prep = rest[idx] if idx is not None else None
        if tw and tw[0] == 'to' and prep == 'next':
            tw = tw[1:]
        if not tw or tw in (['it'], ['them']):
            if tw and last_fix:
                tgt = resolve_target(api, names, bodies, _base(last_fix).split('_'))
                if tgt is None or tgt[1] != last_fix:
                    tgt = (last_fix, last_fix)
            else:
                tgt = last_target
        else:
            tgt = resolve_target(api, names, bodies, tw, prep)
        if tgt is None:
            continue
        items = []
        for part in split_items(item_w):
            it = last_item if part in (['it'], ['them']) else \
                resolve(api, names, bodies, part, exclude=(tgt[1],))
            if it and it not in items:
                items.append(it)
        if ops and ops[-1][0] == 'pick' and ops[-1][1] in items:
            ops.pop()
        for k, it in enumerate(items):
            ops.append(('place', it, tgt, k, len(items)))
        if items:
            last_item = items[-1]
        last_target, last_fix = tgt, tgt[1]
    return ops


def is_drawer(op):
    name = op[1][0]
    toks = set(name.split('_'))
    return op[2] or ('drawer' in toks) or (
        bool(toks & {'top', 'middle', 'bottom'}) and not name.endswith('_side')
        and ('cabinet' in name or 'drawer' in name))


def grasp_kind(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


def drop_for(name, k, n):
    z = 0.08
    if 'basket' in name:
        z = 0.11
    elif 'caddy' in name:
        z = 0.10
    elif 'tray' in name or 'plate' in name:
        z = 0.06
    elif 'cook' in name:
        z = 0.05
    dy = 0.0
    if n > 1 and ('basket' in name or 'contain' in name) and 'caddy' not in name:
        dy = 0.03 if k % 2 == 0 else -0.03
    return (0.0, dy, z)


def placed_ok(api, item, name):
    try:
        ip, tp = P(api, item), P(api, name)
    except Exception:
        return False
    tol = 0.07
    if 'basket' in name or 'contain' in name or 'tray' in name:
        tol = 0.08
    if 'caddy' in name:
        tol = 0.045
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.06


def recover(api):
    try:
        api.grip(False)
        api.move(E(api) + V(0, 0, 0.12), steps=15)
    except Exception:
        pass


def place(api, item, name, k, n):
    g = grasp_kind(item)
    for _ in range(2):
        try:
            api.place_with(item, name, g)
        except Exception:
            pass
        if placed_ok(api, item, name):
            return True
        recover(api)
    try:
        api.transfer(item, name, grasp=(0, 0, 0), drop=drop_for(name, k, n))
    except Exception:
        pass
    ok = placed_ok(api, item, name)
    if not ok:
        recover(api)
    return ok


def pick_only(api, item):
    p = P(api, item)
    api.grip(False)
    api.move(p + V(0, 0, 0.12), steps=30)
    api.move(p, steps=25)
    api.grip(True)
    api.move(p + V(0, 0, 0.15), steps=25)


def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    words = _words(api.instruction)
    try:
        ops = build_plan(api, names, bodies, words)
    except Exception:
        ops = []
    unsupported = (not ops) or any(
        op[0] == 'turn' or (op[0] in ('open', 'close') and not is_drawer(op)) for op in ops)
    if unsupported:
        api.fallback()
        return
    for op in ops:
        try:
            if op[0] == 'place':
                place(api, op[1], op[2][0], op[3], op[4])
            elif op[0] in ('open', 'close'):
                api.drawer(op[1][0], op[0])
                recover(api)
            elif op[0] == 'pick':
                pick_only(api, op[1])
        except Exception:
            recover(api)
