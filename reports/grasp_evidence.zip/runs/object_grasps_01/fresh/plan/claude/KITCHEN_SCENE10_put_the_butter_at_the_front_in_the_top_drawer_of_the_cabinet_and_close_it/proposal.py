import numpy as np

ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl', 'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup', 'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup', 'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop', 'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy',
    'black_book': 'black book', 'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle', 'butter': 'butter box',
    'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet', 'wooden_cabinet': 'wooden cabinet',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack', 'microwave': 'microwave oven',
    'basket': 'basket', 'plate': 'plate',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown', 'wooden', 'pink', 'orange'}
DIRS = ('left', 'right', 'front', 'back')
LEVELS = ('top', 'middle', 'bottom')
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'at', 'in', 'on',
        'top', 'left', 'right', 'front', 'back', 'bottom', 'middle', 'compartment', 'side',
        'its', 'that', 'is', 'please', 'then', 'drawer', 'drawers', 'one', 'which', 'located',
        'next', 'beside', 'near', 'by', 'shelf', 'tray', 'onto', 'into', 'inside', 'over'}
VERBS = {'put', 'place', 'turn', 'switch', 'close', 'shut', 'open', 'pick', 'push', 'pull',
         'move', 'stack', 'lift', 'grab', 'take', 'set', 'drop'}
PREPS = ('into', 'onto', 'inside', 'in', 'on', 'next', 'beside', 'near', 'to')


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return w


def _P(api, n):
    return np.array(api.pos(n), dtype=float)


def grasp_for(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


def _closest(api, ref, cands):
    try:
        r = api.nearest(ref, list(cands))
        if r in cands:
            return r
    except Exception:
        pass
    rp = _P(api, ref)
    return min(cands, key=lambda c: np.linalg.norm(_P(api, c)[:2] - rp[:2]))


def resolve(api, names, bodies, phrase, exclude=()):
    W = set(w for w in phrase if w not in STOP)
    if not W:
        return None
    best, cands = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, cands = s, [b]
        elif abs(s - best) < 1e-9:
            cands.append(b)
    if not cands:
        return None
    if len(cands) == 1:
        return cands[0]
    # disambiguate with spatial wording, e.g. "the butter at the front"
    for d in DIRS:
        if d in phrase:
            key = set(_base(cands[0]).split('_'))
            hints = [n for n in names if _is_region(n) and d in n.split('_')
                     and key <= set(n.split('_'))]
            if hints:
                return _closest(api, hints[0], cands)
            f = {'left': lambda p: -p[1], 'right': lambda p: p[1],
                 'front': lambda p: p[0], 'back': lambda p: -p[0]}[d]
            return sorted(cands, key=lambda c: f(_P(api, c)))[0]
    return sorted(cands)[0]


def resolve_target(api, names, bodies, tw, prep, item=None):
    """returns (target_name, owner, is_drawer)"""
    owner = resolve(api, names, bodies, tw, exclude=(item,) if item else ())
    if owner is None:
        return None
    regs = [n for n in names if _is_region(n) and n.startswith(owner + '_')]
    T = set(tw)
    drawer = bool(T & {'drawer', 'drawers'})
    level = next((l for l in LEVELS if l in T), None)
    if drawer or (level and any(r.endswith('_%s_region' % level) for r in regs)
                  and prep in ('in', 'into', 'inside')):
        lv = level or 'top'
        r = owner + '_%s_region' % lv
        if r in names:
            return (r, owner, True)
    if 'top' in T and owner + '_top_side' in names and prep in ('on', 'onto'):
        return (owner + '_top_side', owner, False)
    d = next((x for x in DIRS if x in T), None)
    if d is not None:
        inside = ('compartment' in T) or prep in ('in', 'into', 'inside')
        try:
            r = api.relative_target(owner, d, 'inside' if inside else 'outside')
            if r:
                return (r, owner, False)
        except Exception:
            pass
    for key in ('contain', 'cook', 'heating'):
        for r in regs:
            if key in r:
                return (r, owner, False)
    return (owner, owner, False)


def split_clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if (w == 'and' and (nxt in VERBS or nxt == 'then')) or w == 'then':
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return out


def split_items(ws):
    both = 'both' in ws
    parts = [[]]
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if w == 'and' and (nxt in ('the', 'a') or both):
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def build_plan(api, names, bodies, words):
    ops = []
    last_item, last_tgt = None, None
    for c in split_clauses(words):
        while c and c[-1] == 'and':
            c = c[:-1]
        if not c:
            continue
        v, rest = c[0], [w for w in c[1:] if w != 'up']
        if v in ('turn', 'switch', 'push', 'pull'):
            return None                                   # unsupported -> fallback
        if v in ('open', 'close', 'shut'):
            if not rest or set(rest) <= {'it', 'them', 'the', 'drawer'}:
                tgt = last_tgt
            else:
                tgt = resolve_target(api, names, bodies, rest + ['drawer'], 'in')
            if tgt is None or not tgt[2]:
                return None                               # not a drawer -> fallback
            ops.append(('drawer', tgt[0], 'open' if v == 'open' else 'close'))
            last_tgt = tgt
            continue
        idx = next((i for i, w in enumerate(rest) if w in PREPS and i > 0), None)
        if idx is None:
            return None                                   # pick-only etc. -> fallback
        prep = rest[idx]
        item_w, tw = rest[:idx], rest[idx + 1:]
        if prep in ('next', 'beside', 'near'):
            tw = [w for w in tw if w not in ('to',)]
        if not tw or set(tw) <= {'it', 'them', 'of', 'the'}:
            tgt = last_tgt
        else:
            tgt = resolve_target(api, names, bodies, tw, prep)
        if tgt is None:
            return None
        items = []
        for part in split_items(item_w):
            it = last_item if part in (['it'], ['them']) else \
                resolve(api, names, bodies, part, exclude=(tgt[1],))
            if it and it not in items:
                items.append(it)
        if not items:
            return None
        for it in items:
            ops.append(('place', it, tgt[0], grasp_for(it)))
        last_item, last_tgt = items[-1], tgt
    return ops


def run(api):
    try:
        names = list(api.names())
        bodies = [n for n in names if not _is_region(n)]
        ops = build_plan(api, names, bodies, _words(api.instruction))
    except Exception:
        ops = None
    if not ops:
        return api.fallback()

    # Example ("put the butter at the front in the top drawer of the cabinet and close it"):
    #   1. place_with(<butter nearest butter_front_init_region>,
    #                 'wooden_cabinet_1_top_region', 'standard')
    #   2. drawer('wooden_cabinet_1_top_region', 'close')
    for op in ops:
        try:
            if op[0] == 'drawer':
                api.drawer(op[1], op[2])
            elif op[0] == 'place':
                _, item, target, grasp = op
                p0 = _P(api, item)
                api.place_with(item, target, grasp)
                # retry once only if the object never left its start pose
                if np.linalg.norm(_P(api, item) - p0) < 0.03:
                    api.grip(False)
                    e = np.array(api.eef(), dtype=float)
                    api.move(e + np.array([0.0, 0.0, 0.10]), steps=10)
                    api.place_with(item, target, grasp)
        except Exception:
            try:
                api.grip(False)
                e = np.array(api.eef(), dtype=float)
                api.move(e + np.array([0.0, 0.0, 0.10]), steps=10)
            except Exception:
                pass
