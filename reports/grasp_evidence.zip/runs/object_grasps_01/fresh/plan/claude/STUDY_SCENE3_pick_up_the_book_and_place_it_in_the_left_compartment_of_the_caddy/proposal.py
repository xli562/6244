import numpy as np

ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl', 'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup', 'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup', 'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop', 'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy',
    'black_book': 'black book', 'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle', 'butter': 'butter box',
    'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet drawer', 'wooden_cabinet': 'wooden cabinet drawer',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack', 'microwave': 'microwave oven',
    'basket': 'basket', 'plate': 'plate',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown', 'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'top', 'left', 'right',
        'front', 'back', 'behind', 'bottom', 'middle', 'compartment', 'side', 'its', 'that', 'is',
        'please', 'then', 'in', 'into', 'inside', 'on', 'onto', 'next', 'beside', 'at', 'region'}
VERBS = {'put', 'place', 'turn', 'switch', 'close', 'shut', 'open', 'pick', 'push', 'pull',
         'move', 'stack', 'lift', 'grab', 'take', 'set'}
PREPS = {'in', 'into', 'inside', 'on', 'onto', 'to', 'next', 'behind', 'beside', 'at'}
DIRS = {'left': 'left', 'right': 'right', 'front': 'front', 'back': 'back', 'behind': 'back'}
LEVELS = ('top', 'middle', 'bottom')


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _desc(b):
    base = _base(b)
    d = set(base.split('_'))
    if base in ALIAS:
        d |= set(ALIAS[base].split())
    return d


def resolve(api, bodies, ws, exclude=()):
    W = set(w for w in ws if w not in STOP)
    if not W:
        return None
    best, cands = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, cands = s, [b]
        elif abs(s - best) < 1e-9:
            cands.append(b)
    if not cands:
        return None
    if len(cands) > 1:
        for w in ws:
            if w in DIRS:
                key = {'left': lambda p: -p[1], 'right': lambda p: p[1],
                       'front': lambda p: p[0], 'back': lambda p: -p[0]}[DIRS[w]]
                return sorted(cands, key=lambda c: key(P(api, c)))[0]
        cands = sorted(cands)
    return cands[0]


def grasp_for(item):
    b = _base(item)
    if 'book' in b:
        return 'thin_edge'
    if 'bowl' in b:
        return 'rim'
    return 'standard'


def drawer_region(names, fixture, ws):
    regs = [n for n in names if n.startswith(fixture + '_') and n.endswith('_region')
            and not n.endswith('_side')]
    for lv in LEVELS:
        if lv in ws:
            for r in regs:
                if lv in r[len(fixture) + 1:].split('_'):
                    return r
    return regs[0] if regs else None


def resolve_target(api, names, bodies, tw, prep, exclude):
    """returns (region_or_body, fixture, is_drawer)"""
    fixture = resolve(api, bodies, tw, exclude=exclude)
    if fixture is None:
        return None
    R = set(tw)
    drawer = 'drawer' in R or 'drawers' in R
    if drawer:
        r = drawer_region(names, fixture, tw)
        return (r or fixture, fixture, True)
    direction = next((DIRS[w] for w in tw if w in DIRS), None)
    if direction is not None:
        phrase = ' '.join([prep] + tw)
        outside = (('compartment' not in R) and
                   (prep in ('to', 'next', 'behind', 'beside', 'at')
                    or phrase.startswith('in front of')
                    or prep not in ('in', 'into', 'inside')))
        rel = 'outside' if outside else 'inside'
        try:
            r = api.relative_target(fixture, direction, rel)
            if r in names:
                return (r, fixture, False)
        except Exception:
            pass
        fb = _base(fixture)
        if rel == 'inside':
            c = [n for n in names if n.startswith(fixture + '_') and direction in n.split('_')]
        else:
            c = [n for n in names if fb in n and not n.startswith(fixture + '_')
                 and direction in n.split('_') and 'contain' not in n]
        if c:
            return (c[0], fixture, False)
    regs = [n for n in names if _is_region(n) and n.startswith(fixture + '_')]
    if 'top' in R and prep in ('on', 'onto'):
        side = [r for r in regs if r.endswith('top_side')]
        if side:
            return (side[0], fixture, False)
    for key in ('contain', 'heating', 'cook'):
        c = [r for r in regs if key in r]
        if c:
            return (c[0], fixture, False)
    if 'cabinet' in fixture and prep in ('in', 'into', 'inside'):
        r = drawer_region(names, fixture, tw)
        if r:
            return (r, fixture, True)
    return (fixture, fixture, False)


def split_clauses(ws):
    out, cur = [], []
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if (w == 'and' and (nxt in VERBS or nxt == 'then')) or w == 'then':
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return out


def split_items(ws):
    parts = [[]]
    for j, w in enumerate(ws):
        if w == 'and':
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def plan(api, names, bodies, ws):
    ops, last_item, last_tgt = [], None, None
    for c in split_clauses(ws):
        while c and c[-1] == 'and':
            c = c[:-1]
        if not c:
            continue
        v, rest = c[0], [w for w in c[1:] if w != 'up']
        if v in ('turn', 'switch'):
            return [('unsupported',)]
        if v in ('open', 'close', 'shut') or (v in ('push', 'pull') and 'drawer' in rest):
            act = 'open' if v in ('open', 'pull') else 'close'
            if not rest or rest in (['it'], ['them']):
                t = last_tgt
            else:
                fx = resolve(api, bodies, rest)
                t = (drawer_region(names, fx, rest), fx, True) if fx else None
            if not t or not t[2] or t[0] is None:
                return [('unsupported',)]
            ops.append(('drawer', t[0], act))
            last_tgt = t
            continue
        idx = next((i for i, w in enumerate(rest) if w in PREPS and i > 0), None)
        if idx is None and rest and rest[-1] in PREPS:
            idx = len(rest) - 1
        if idx is None:
            if v in ('pick', 'grab', 'lift', 'take'):
                it = resolve(api, bodies, rest)
                if it is None:
                    return [('unsupported',)]
                ops.append(('pick', it))
                last_item = it
                continue
            return [('unsupported',)]
        item_w, prep, tw = rest[:idx], rest[idx], rest[idx + 1:]
        items_raw = split_items(item_w) or [['it']]
        if not tw or tw in (['it'], ['them']):
            tgt = last_tgt
        else:
            pre_items = [resolve(api, bodies, p) for p in items_raw if p not in (['it'], ['them'])]
            ex = tuple(x for x in pre_items if x) + ((last_item,) if last_item else ())
            tgt = resolve_target(api, names, bodies, tw, prep, ex)
        if tgt is None:
            return [('unsupported',)]
        items = []
        for p in items_raw:
            it = last_item if p in (['it'], ['them']) else resolve(api, bodies, p, exclude=(tgt[1],))
            if it and it not in items:
                items.append(it)
        if not items:
            return [('unsupported',)]
        if ops and ops[-1][0] == 'pick' and ops[-1][1] in items:
            ops.pop()
        for it in items:
            ops.append(('place', it, tgt))
        last_item, last_tgt = items[-1], tgt
    return ops


def placed_ok(api, item, tgt):
    name, fixture, is_drawer = tgt
    ip, tp = P(api, item), P(api, name)
    if is_drawer:
        return np.linalg.norm(ip[:2] - tp[:2]) < 0.15
    tol = 0.05 if 'caddy' in name else 0.08
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.06


def pick_only(api, item):
    p = P(api, item)
    api.grip(False)
    api.move(p + np.array([0, 0, 0.12]), steps=30)
    api.move(p, steps=25)
    api.grip(True)
    api.move(p + np.array([0, 0, 0.15]), steps=25)


def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    try:
        ops = plan(api, names, bodies, _words(api.instruction))
    except Exception:
        ops = None
    if not ops or any(o[0] == 'unsupported' for o in ops):
        api.fallback()
        return
    for op in ops:
        try:
            if op[0] == 'drawer':
                api.drawer(op[1], op[2])
            elif op[0] == 'pick':
                pick_only(api, op[1])
            elif op[0] == 'place':
                item, tgt = op[1], op[2]
                g = grasp_for(item)
                api.place_with(item, tgt[0], g)
                if not placed_ok(api, item, tgt):
                    api.grip(False)
                    api.move(np.array(api.eef(), dtype=float) + np.array([0, 0, 0.10]), steps=12)
                    api.place_with(item, tgt[0], g)
        except Exception:
            try:
                api.grip(False)
                api.move(np.array(api.eef(), dtype=float) + np.array([0, 0, 0.10]), steps=12)
            except Exception:
                pass
