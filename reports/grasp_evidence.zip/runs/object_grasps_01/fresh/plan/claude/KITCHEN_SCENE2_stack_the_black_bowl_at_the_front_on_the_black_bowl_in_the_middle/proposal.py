import math
import numpy as np

QUAL = {'front', 'back', 'middle', 'center', 'centre', 'left', 'right'}
PREPS = ['onto', 'into', 'inside', 'on', 'in', 'atop']
STOP = {'the', 'a', 'an', 'of', 'at', 'top', 'it', 'please', 'up', 'side'}
VERBS = {'put', 'place', 'stack', 'set', 'move', 'pick', 'lay'}
ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl',
    'white_bowl': 'white bowl', 'porcelain_mug': 'white porcelain mug cup',
    'white_yellow_mug': 'white yellow mug cup', 'red_coffee_mug': 'red coffee mug cup',
    'chefmate_8_frypan': 'frying pan frypan skillet', 'flat_stove': 'stove',
    'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy', 'black_book': 'black book',
    'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle',
    'butter': 'butter box', 'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'wooden_cabinet': 'wooden cabinet', 'white_cabinet': 'white cabinet',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack', 'microwave': 'microwave oven',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown', 'wooden', 'pink', 'orange'}


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def desc(b):
    bb = base(b)
    w = set(bb.split('_'))
    if bb in ALIAS:
        w |= set(ALIAS[bb].split())
    return w


def match(bodies, ws, exclude=()):
    W = set(w for w in ws if w not in STOP and w not in QUAL)
    best, cands = 0, []
    for b in bodies:
        if b in exclude:
            continue
        D = desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best:
            best, cands = s, [b]
        elif s == best:
            cands.append(b)
    return sorted(cands)


def pick_by_qualifier(api, names, cands, q):
    if len(cands) <= 1 or q is None:
        return cands[0] if cands else None
    if q in ('center', 'centre'):
        q = 'middle'
    head = set(base(cands[0]).split('_'))
    hints = [n for n in names if is_region(n) and 'init' in n
             and q in n.split('_') and head <= set(n.split('_'))]
    if not hints:
        hints = [n for n in names if is_region(n) and q in n.split('_')
                 and base(cands[0]).split('_')[-1] in n.split('_')]
    if hints:
        try:
            r = api.nearest(hints[0], list(cands))
            if r in cands:
                return r
        except Exception:
            pass
        hp = P(api, hints[0])
        return min(cands, key=lambda c: np.linalg.norm(P(api, c)[:2] - hp[:2]))
    ps = {c: P(api, c) for c in cands}
    if q == 'middle':
        cen = np.mean([p[:2] for p in ps.values()], axis=0)
        return min(cands, key=lambda c: np.linalg.norm(ps[c][:2] - cen))
    key = {'front': lambda p: p[0], 'back': lambda p: -p[0],
           'left': lambda p: -p[1], 'right': lambda p: p[1]}[q]
    return min(cands, key=lambda c: key(ps[c]))


def qualifier(ws):
    for w in ws:
        if w in QUAL:
            return w
    return None


def split_phrase(ws):
    """split 'item ... prep target ...', skipping 'in the middle'-style qualifiers"""
    for i, w in enumerate(ws):
        if w in PREPS and i > 0:
            nxt = ws[i + 1:i + 3]
            if len(nxt) == 2 and nxt[0] == 'the' and nxt[1] in QUAL:
                after = ws[i + 3] if i + 3 < len(ws) else None
                if after is None or after in PREPS:
                    continue
            if w == 'on' and ws[i + 1:i + 3] == ['top', 'of']:
                return ws[:i], ws[i + 3:]
            return ws[:i], ws[i + 1:]
    return None


def grasp_for(item):
    b = base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


def stacked_ok(api, item, target, is_body):
    ip, tp = P(api, item), P(api, target)
    tol = 0.05 if 'caddy' in target else 0.07
    ok = np.linalg.norm(ip[:2] - tp[:2]) < tol
    if is_body and 'bowl' in base(target):
        ok = ok and ip[2] > tp[2] + 0.01
    return ok


def run(api):
    names = list(api.names())
    bodies = [n for n in names if not is_region(n)]
    ws = words(api.instruction)

    # anything involving drawers, knobs, or multiple clauses -> previous policy
    if (not ws or ws[0] not in VERBS
            or any(w in ws for w in ('open', 'close', 'shut', 'turn', 'switch', 'drawer', 'then'))
            or ('and' in ws and ws[0] != 'stack')):
        return api.fallback()

    sp = split_phrase(ws[1:])
    if sp is None:
        return api.fallback()
    item_w, tgt_w = sp

    # resolve both endpoints BEFORE anything moves (init-region hints are valid now)
    tc = match(bodies, tgt_w)
    if not tc:
        return api.fallback()
    target = pick_by_qualifier(api, names, tc, qualifier(tgt_w))
    ic = match(bodies, item_w, exclude=(target,))
    if not ic:
        return api.fallback()
    item = pick_by_qualifier(api, names, ic, qualifier(item_w))
    if item is None or item == target:
        return api.fallback()

    # fixtures with sub-regions: use container / top surface region
    tname, is_body = target, True
    regs = [n for n in names if is_region(n) and n.startswith(target + '_')]
    if regs:
        cont = [r for r in regs if 'contain' in r]
        top = [r for r in regs if r.endswith('top_side')]
        if any(w in tgt_w for w in ('compartment', 'bottom', 'middle')) and not cont:
            return api.fallback()
        if cont:
            tname, is_body = cont[0], False
        elif top and 'top' in tgt_w:
            tname, is_body = top[0], False

    g = grasp_for(item)   # here: front akita bowl -> 'rim'
    for attempt in range(2):
        try:
            api.place_with(item, tname, g)
        except Exception:
            pass
        try:
            if stacked_ok(api, item, tname, is_body):
                return
        except Exception:
            pass
        try:
            api.grip(False)
            e = np.array(api.eef(), dtype=float)
            api.move(e + np.array([0, 0, 0.10]), steps=12)
        except Exception:
            pass
    try:
        api.arrange([(item, tname)])
    except Exception:
        pass
