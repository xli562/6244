import math
import numpy as np

# ---------------------------------------------------------------- vocabulary
ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl',
    'white_bowl': 'white bowl', 'porcelain_mug': 'white porcelain mug cup',
    'white_yellow_mug': 'white yellow mug cup', 'red_coffee_mug': 'red coffee mug cup',
    'chefmate_8_frypan': 'frying pan frypan skillet', 'flat_stove': 'stove burner cooktop',
    'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy', 'black_book': 'black book',
    'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle',
    'butter': 'butter box', 'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet', 'wooden_cabinet': 'wooden cabinet',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack', 'microwave': 'microwave oven',
    'basket': 'basket', 'plate': 'plate',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown',
          'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'top',
        'left', 'right', 'front', 'back', 'bottom', 'middle', 'compartment',
        'side', 'its', 'that', 'is', 'please', 'then', 'at', 'next', 'beside'}
VERBS = {'put', 'place', 'turn', 'switch', 'close', 'shut', 'open', 'pick',
         'push', 'pull', 'move', 'stack', 'lift', 'grab', 'take', 'set'}
PREPS = ('into', 'onto', 'inside', 'in', 'on')
DIRS = ('left', 'right', 'front', 'back')
DRAWER_LEVELS = ('top', 'middle', 'bottom')


def V(*a):
    return np.array(a, dtype=float)


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def E(api):
    return np.array(api.eef(), dtype=float)


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _words(s):
    s = ''.join(c if c.isalnum() else ' ' for c in s.lower())
    return s.split()


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return w


# ---------------------------------------------------------------- resolution
def _spatial(api, names, raw, cands):
    for w in DIRS:
        if w in raw:
            head = _base(cands[0]).split('_')[-1]
            hints = [n for n in names if _is_region(n)
                     and w in n.split('_') and head in n.split('_')]
            if hints:
                try:
                    r = api.nearest(hints[0], list(cands))
                    if r in cands:
                        return [r] + [c for c in cands if c != r]
                except Exception:
                    pass
                hp = P(api, hints[0])
                return sorted(cands, key=lambda c: np.linalg.norm(P(api, c)[:2] - hp[:2]))
            keyf = {'left': lambda p: -p[1], 'right': lambda p: p[1],
                    'front': lambda p: p[0], 'back': lambda p: -p[0]}[w]
            return sorted(cands, key=lambda c: keyf(P(api, c)))
    return sorted(cands)


def resolve(api, names, bodies, raw, exclude=()):
    W = set(w for w in raw if w not in STOP)
    if not W:
        return None
    best, cands = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, cands = s, [b]
        elif abs(s - best) < 1e-9:
            cands.append(b)
    if not cands:
        return None
    if len(cands) > 1:
        cands = _spatial(api, names, raw, cands)
    return cands[0]


def resolve_target(api, names, bodies, raw):
    """returns (target_name, owner_body)"""
    obj = resolve(api, names, bodies, raw)
    if obj is None:
        return None
    regs = [n for n in names if _is_region(n) and n.startswith(obj + '_')]
    if not regs:
        return (obj, obj)
    R = set(raw)
    drawer = 'drawer' in R or 'drawers' in R
    # spatial compartment / next-to wording -> shared skill
    dirs = [d for d in DIRS if d in R]
    if dirs and not drawer:
        rel = 'inside' if ('compartment' in R or R & {'in', 'into', 'inside'}) else None
        if rel is None:
            # direction word directly about this fixture -> location next to it
            rel = 'outside'
        try:
            r = api.relative_target(obj, dirs[0], rel)
            if r:
                return (r, obj)
        except Exception:
            pass
    best, bs = None, -1e9
    for r in regs:
        suf = r[len(obj) + 1:].split('_')
        toks = set(suf) - {'region', 'contain', 'side'}
        s = 3 * len(toks & R)
        if drawer and 'side' in suf:
            s -= 5
        if (not drawer) and 'top' in R and 'side' in suf:
            s += 2
        if not toks or toks <= {'cook', 'heating'}:
            s += 1
        if s > bs:
            bs, best = s, r
    return (best, obj)


# ---------------------------------------------------------------- parsing
def split_clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if (w == 'and' and (nxt in VERBS or nxt == 'then')) or w == 'then':
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return [c for c in out if c]


def split_items(ws):
    both = 'both' in ws
    has_the = any(ws[j] == 'and' and j + 1 < len(ws) and ws[j + 1] in ('the', 'a')
                  for j in range(len(ws)))
    parts = [[]]
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if w == 'and' and ((has_the and nxt in ('the', 'a')) or (both and not has_the)):
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def _outside_split(rest):
    """'X to the left of the Y' / 'X next to the Y' -> (item_words, dir, ref_words)"""
    for i, w in enumerate(rest):
        if w in DIRS and i + 1 < len(rest) and rest[i + 1] in ('of', 'side'):
            j = i + 1
            while j < len(rest) and rest[j] in ('of', 'side'):
                j += 1
            k = i
            while k > 0 and rest[k - 1] in ('to', 'the', 'at', 'on', 'next', 'a'):
                k -= 1
            if k > 0 and j < len(rest):
                return rest[:k], w, rest[j:]
    return None


def build_plan(api, names, bodies, words):
    ops = []
    last_item, last_target, last_fix = None, None, None
    for c in split_clauses(words):
        while c and c[-1] == 'and':
            c = c[:-1]
        if not c:
            continue
        v, rest = c[0], c[1:]
        if v in ('turn', 'switch'):
            on = 'off' not in rest
            ow = [w for w in rest if w not in ('on', 'off')]
            obj = last_fix if (not ow or ow == ['it']) else resolve(api, names, bodies, ow)
            if obj:
                ops.append(('turn', obj, on))
                last_fix = obj
            continue
        if v in ('close', 'shut', 'open'):
            if not rest or rest in (['it'], ['them']):
                tgt = last_target
            else:
                tgt = resolve_target(api, names, bodies, rest)
            if tgt:
                ops.append(('close' if v != 'open' else 'open', tgt))
                last_target = tgt
                last_fix = tgt[1]
            continue
        rest = [w for w in rest if w != 'up']
        idx = None
        for i, w in enumerate(rest):
            if w in PREPS and i > 0:
                idx = i
                break
        tgt = None
        item_w = None
        # 'outside' relation: next to a fixture on the table
        osp = _outside_split(rest[:idx] if idx is not None else rest) if idx is None else None
        if osp is None and idx is not None:
            sub = _outside_split(rest)
            if sub is not None and len(sub[0]) <= idx and 'drawer' not in rest:
                osp = sub
        if osp is not None:
            iw, d, rw = osp
            ref = resolve(api, names, bodies, rw)
            if ref:
                rel = 'inside' if 'compartment' in rest else 'outside'
                try:
                    r = api.relative_target(ref, d, rel)
                    if r:
                        tgt, item_w = (r, ref), iw
                except Exception:
                    tgt = None
        if tgt is None:
            if v in ('pick', 'grab', 'lift', 'take') and idx is None:
                it = resolve(api, names, bodies, rest)
                if it:
                    ops.append(('pick', it))
                    last_item = it
                continue
            if idx is None:
                item_w, tw = rest, []
            else:
                item_w, tw = rest[:idx], rest[idx + 1:]
            if not tw or tw in (['it'], ['them']):
                if tw and last_fix:
                    tgt = resolve_target(api, names, bodies, _base(last_fix).split('_'))
                    if tgt is None or tgt[1] != last_fix:
                        tgt = (last_fix, last_fix)
                else:
                    tgt = last_target
            else:
                tgt = resolve_target(api, names, bodies, tw)
        if tgt is None:
            continue
        items = []
        for part in split_items(item_w):
            if part in (['it'], ['them']):
                it = last_item
            else:
                it = resolve(api, names, bodies, part, exclude=(tgt[1],))
            if it and it not in items:
                items.append(it)
        if ops and ops[-1][0] == 'pick' and ops[-1][1] in items:
            ops.pop()
        for it in items:
            ops.append(('place', it, tgt))
        if items:
            last_item = items[-1]
        last_target = tgt
        last_fix = tgt[1]
    return ops


# ---------------------------------------------------------------- drawers
def is_drawer_region(name):
    parts = name.split('_')
    return (name.endswith('_region') and 'cabinet' in name
            and any(l in parts for l in DRAWER_LEVELS))


def drawer_open_state(api, names, region, owner):
    """True / False / None(unknown) by comparing with sibling drawers"""
    try:
        sibs = [n for n in names if n != region and n.startswith(owner + '_')
                and is_drawer_region(n)]
        if not sibs:
            return None
        op = P(api, owner)[:2]
        d = np.linalg.norm(P(api, region)[:2] - op)
        ds = [np.linalg.norm(P(api, s)[:2] - op) for s in sibs]
        return bool(d - min(ds) > 0.05)
    except Exception:
        return None


def drawer_dir(api, region, owner):
    rp = P(api, region)
    op = P(api, owner) if owner else rp
    d = op[:2] - rp[:2]
    nd = np.linalg.norm(d)
    d = d / nd if nd > 0.03 else np.array([1.0, 0.0])
    return np.array([d[0], d[1], 0.0])


def push_close(api, tgt):
    name, owner = tgt
    rp = P(api, name)
    d3 = drawer_dir(api, name, owner)
    start = rp - d3 * 0.20
    start[2] = rp[2] + 0.03
    e = E(api)
    high = max(e[2], rp[2] + 0.15)
    api.move(V(e[0], e[1], high), steps=15)
    api.move(V(start[0], start[1], high), steps=30)
    api.grip(True)
    api.move(start, steps=25)
    api.move(start + d3 * 0.32, steps=60)
    back = start + d3 * 0.20
    api.move(back, steps=10)
    api.move(back + V(0, 0, 0.12), steps=15)


def pull_open(api, tgt):
    name, owner = tgt
    rp = P(api, name)
    d3 = drawer_dir(api, name, owner)
    handle = rp - d3 * 0.13
    handle[2] = rp[2] + 0.04
    pre = handle - d3 * 0.08
    e = E(api)
    api.grip(False)
    api.move(V(e[0], e[1], max(e[2], handle[2] + 0.12)), steps=15)
    api.move(pre + V(0, 0, 0.10), steps=30)
    api.move(pre, steps=20)
    api.move(handle, steps=20)
    api.grip(True)
    api.move(handle - d3 * 0.22, steps=50)
    api.grip(False)
    e = E(api)
    api.move(e + V(0, 0, 0.10), steps=15)


def op_drawer(api, names, tgt, mode):
    name, owner = tgt
    if name.endswith('_side') and 'cabinet' in name:
        # 'close it' after placing on top makes no sense for the top surface;
        # map to the matching drawer if any
        cand = [n for n in names if n.startswith(owner + '_') and is_drawer_region(n)
                and 'top' in n.split('_')]
        if not cand:
            return
        name = cand[0]
        tgt = (name, owner)
    if is_drawer_region(name):
        api.drawer(name, mode)
        if mode == 'close' and drawer_open_state(api, names, name, owner):
            api.drawer(name, 'close')
        elif mode == 'open' and drawer_open_state(api, names, name, owner) is False:
            api.drawer(name, 'open')
    else:
        (push_close if mode == 'close' else pull_open)(api, tgt)


# ---------------------------------------------------------------- placing
def grasp_mode(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


def placed_ok(api, item, name, loose=False):
    try:
        ip, tp = P(api, item), P(api, name)
    except Exception:
        return True
    tol = 0.07
    if 'basket' in name or 'contain' in name:
        tol = 0.08
    if 'caddy' in name:
        tol = 0.05
    if is_drawer_region(name):
        tol = 0.09
    if loose:
        tol += 0.03
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.07


def retreat(api, dz=0.10):
    try:
        api.grip(False)
        e = E(api)
        api.move(e + V(0, 0, dz), steps=12)
    except Exception:
        pass


def do_place(api, item, tgt):
    name = tgt[0]
    mode = grasp_mode(item)
    for attempt in range(2):
        try:
            api.place_with(item, name, mode)
        except Exception:
            try:
                api.transfer(item, name)
            except Exception:
                pass
        retreat(api, 0.08)
        if placed_ok(api, item, name, loose=(attempt == 0)):
            return True
    return False


def pick_only(api, item):
    p = P(api, item)
    api.grip(False)
    api.move(p + V(0, 0, 0.12), steps=30)
    api.move(p, steps=25)
    api.grip(True)
    api.move(p + V(0, 0, 0.15), steps=25)


# ---------------------------------------------------------------- stove
def twist_knob(api, k, grasp_z, on):
    sgn = 1.0 if on else -1.0
    api.grip(False)
    e = E(api)
    api.move(V(e[0], e[1], max(e[2], grasp_z + 0.15)), steps=15)
    api.move(V(k[0], k[1], grasp_z + 0.10), steps=25)
    api.move(V(k[0], k[1], grasp_z), steps=20)
    api.grip(True)
    api.action([0, 0, 0, 0, 0, 0.35 * sgn, 1.0], steps=12)
    api.grip(False)
    e = E(api)
    api.move(e + V(0, 0, 0.10), steps=12)
    api.action([0, 0, 0, 0, 0, -0.35 * sgn, -1.0], steps=12)


def sweep_stove(api, sp, cp, on):
    sgn = 1.0 if on else -1.0
    e = E(api)
    api.move(V(e[0], e[1], max(e[2], cp[2] + 0.15)), steps=15)
    api.grip(True)
    lines = [(cp[0] - 0.07, cp[2] + 0.015),
             (min(sp[0], cp[0]) - 0.13, max(cp[2] - 0.015, sp[2] + 0.012))]
    for x, z in lines:
        a = V(x, cp[1] + 0.13 * sgn, z)
        b = V(x, cp[1] - 0.13 * sgn, z)
        api.move(V(a[0], a[1], cp[2] + 0.12), steps=25)
        api.move(a, steps=20)
        api.move(b, steps=45)
        api.move(V(b[0], b[1], cp[2] + 0.12), steps=15)


def turn_stove(api, stove, names, on):
    kp = None
    for n in names:
        if n.startswith(_base(stove)) and any(k in n for k in ('knob', 'button', 'switch')):
            try:
                kp = P(api, n)
                break
            except Exception:
                pass
    cook = [n for n in names if n.startswith(stove + '_') and 'cook' in n]
    sp = P(api, stove)
    cp = P(api, cook[0]) if cook else sp + V(0, 0, 0.02)
    if kp is not None:
        twist_knob(api, kp, kp[2] + 0.005, on)
        return
    d = sp[:2] - cp[:2]
    nd = np.linalg.norm(d)
    if nd >= 0.025:
        if nd > 0.15:
            d = d / nd * 0.15
        k = V(sp[0] + d[0], sp[1] + d[1], cp[2])
        twist_knob(api, k, cp[2] + 0.005, on)
        return
    sweep_stove(api, sp, cp, on)


# ---------------------------------------------------------------- main
def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    words = _words(api.instruction)
    try:
        ops = build_plan(api, names, bodies, words)
    except Exception:
        ops = []
    if not ops:
        api.fallback()
        return

    opened = set()
    for i, op in enumerate(ops):
        try:
            kind = op[0]
            if kind == 'turn':
                turn_stove(api, op[1], names, op[2])
            elif kind == 'open':
                op_drawer(api, names, op[1], 'open')
                opened.add(op[1][0])
            elif kind == 'close':
                retreat(api, 0.06)
                op_drawer(api, names, op[1], 'close')
            elif kind == 'pick':
                pick_only(api, op[1])
            elif kind == 'place':
                item, tgt = op[1], op[2]
                name, owner = tgt
                # placing inside a drawer requires it to be open first
                if is_drawer_region(name) and name not in opened:
                    if drawer_open_state(api, names, name, owner) is False:
                        api.drawer(name, 'open')
                    opened.add(name)
                do_place(api, item, tgt)
        except Exception:
            retreat(api, 0.10)
