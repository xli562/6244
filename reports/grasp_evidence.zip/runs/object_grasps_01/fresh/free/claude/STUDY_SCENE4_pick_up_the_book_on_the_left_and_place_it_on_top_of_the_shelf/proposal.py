import math
import numpy as np

COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown', 'pink', 'orange'}


def _words(s):
    s = ''.join(c if c.isalnum() else ' ' for c in s.lower())
    return s.split()


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def left_axis(api, names):
    """unit xy vector pointing 'left', derived from *_left_* / *_right_* region pairs."""
    vecs = []
    for n in names:
        toks = n.split('_')
        if 'left' in toks:
            m = '_'.join('right' if t == 'left' else t for t in toks)
            if m in names:
                try:
                    d = P(api, n)[:2] - P(api, m)[:2]
                    if np.linalg.norm(d) > 0.03:
                        vecs.append(d / np.linalg.norm(d))
                except Exception:
                    pass
    if vecs:
        v = np.mean(vecs, axis=0)
        if np.linalg.norm(v) > 1e-6:
            return v / np.linalg.norm(v)
    return np.array([0.0, 1.0])


def choose_book(api, names, bodies, W):
    books = [b for b in bodies if 'book' in b]
    if not books:
        return None
    cw = (set(W) & COLORS)
    if cw:
        f = [b for b in books if cw & set(b.split('_'))]
        if f:
            books = f
    if len(books) == 1:
        return books[0]
    L = left_axis(api, names)
    proj = {b: float(np.dot(P(api, b)[:2], L)) for b in books}
    fwd = {b: float(P(api, b)[0]) for b in books}
    s = sorted(books, key=lambda b: proj[b])   # right ... left
    if 'left' in W:
        return s[-1]
    if 'right' in W:
        return s[0]
    if 'middle' in W or 'center' in W or 'centre' in W:
        return s[len(s) // 2]
    if 'front' in W:
        return max(books, key=lambda b: fwd[b])
    if 'back' in W:
        return min(books, key=lambda b: fwd[b])
    return s[-1]


def choose_target(names, W):
    shelf_regs = [n for n in names if 'shelf' in n and _is_region(n)
                  and not n.startswith('study_table') and 'init' not in n]
    def find(*keys):
        for n in shelf_regs:
            if all(k in n for k in keys):
                return n
        return None
    if 'bottom' in W or 'lower' in W or 'under' in W:
        t = find('bottom_region')
        if t:
            return t
    if 'top' in W and any(w in W for w in ('compartment', 'layer', 'inside', 'in', 'into')) \
            and 'of' not in W:
        t = find('top_region')
        if t:
            return t
    t = find('top_side') or find('top_region')
    if t:
        return t
    sh = [n for n in names if 'shelf' in n and not _is_region(n)]
    return sh[0] if sh else None


def placed_ok(api, item, tgt):
    try:
        ip, tp = P(api, item), P(api, tgt)
    except Exception:
        return False
    return np.linalg.norm(ip[:2] - tp[:2]) < 0.10 and ip[2] > tp[2] - 0.03


def recover(api):
    try:
        api.grip(False)
        e = np.array(api.eef(), dtype=float)
        api.move(e + np.array([0, 0, 0.12]), steps=12)
    except Exception:
        pass


def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    W = _words(api.instruction)
    is_book_task = ('book' in W or 'books' in W) and any('book' in b for b in bodies)
    tgt = choose_target(names, W) if ('shelf' in W) else None
    if not is_book_task or tgt is None:
        api.fallback()
        return

    book = choose_book(api, names, bodies, W)
    if book is None:
        api.fallback()
        return

    for attempt in range(2):
        try:
            api.place_with(book, tgt, 'thin_edge')
        except Exception:
            recover(api)
        if placed_ok(api, book, tgt):
            recover(api)
            return
        recover(api)

    # last resort: generic top-down transfer
    try:
        api.transfer(book, tgt, grasp=(0, 0, 0), drop=(0, 0, 0.06))
    except Exception:
        pass
    recover(api)
