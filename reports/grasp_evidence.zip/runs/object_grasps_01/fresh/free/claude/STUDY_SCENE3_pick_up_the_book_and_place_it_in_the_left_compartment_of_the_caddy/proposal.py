import math
import numpy as np

# ------------------------------------------------------------------ vocabulary
ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl',
    'white_bowl': 'white bowl', 'porcelain_mug': 'white porcelain mug cup',
    'white_yellow_mug': 'white yellow mug cup', 'red_coffee_mug': 'red coffee mug cup',
    'chefmate_8_frypan': 'frying pan frypan skillet', 'flat_stove': 'stove burner cooktop',
    'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy', 'black_book': 'black book',
    'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle',
    'butter': 'butter box', 'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet', 'wooden_cabinet': 'wooden cabinet',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack',
    'microwave': 'microwave oven', 'basket': 'basket', 'plate': 'plate',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown',
          'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'top',
        'left', 'right', 'front', 'back', 'bottom', 'middle', 'compartment',
        'compartments', 'side', 'its', 'that', 'is', 'please', 'then', 'next',
        'behind', 'beside', 'near', 'rear', 'inside', 'in', 'on', 'into', 'onto',
        'drawer', 'drawers', 'at'}
VERBS = {'put', 'place', 'turn', 'switch', 'close', 'shut', 'open', 'pick',
         'push', 'pull', 'move', 'stack', 'lift', 'grab', 'take', 'set'}
PICKV = {'pick', 'grab', 'lift', 'take'}
PREPS = ('into', 'onto', 'inside', 'in', 'on', 'to', 'behind', 'beside', 'next', 'near', 'at')
DIRS = {'left': 'left', 'right': 'right', 'front': 'front',
        'back': 'back', 'behind': 'back', 'rear': 'back'}
LEVELS = ('top', 'middle', 'bottom')


def V(*a):
    return np.array(a, dtype=float)


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def E(api):
    return np.array(api.eef(), dtype=float)


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _words(s):
    s = ''.join(c if c.isalnum() else ' ' for c in s.lower())
    return s.split()


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return w


# ------------------------------------------------------------------ resolution
def _spatial(api, names, raw, cands):
    for w in ('left', 'right', 'front', 'back'):
        if w in raw:
            head = _base(cands[0]).split('_')[-1]
            hints = [n for n in names if _is_region(n)
                     and w in n.split('_') and head in n.split('_')]
            if hints:
                hp = P(api, hints[0])
                return sorted(cands, key=lambda c: np.linalg.norm(P(api, c)[:2] - hp[:2]))
            keyf = {'left': lambda p: -p[1], 'right': lambda p: p[1],
                    'front': lambda p: p[0], 'back': lambda p: -p[0]}[w]
            return sorted(cands, key=lambda c: keyf(P(api, c)))
    return sorted(cands)


def resolve(api, names, bodies, raw, exclude=()):
    W = set(w for w in raw if w not in STOP)
    if not W:
        return None
    best, cands = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, cands = s, [b]
        elif abs(s - best) < 1e-9:
            cands.append(b)
    if not cands:
        return None
    if len(cands) > 1:
        cands = _spatial(api, names, raw, cands)
    return cands[0]


def owner_regions(names, owner):
    return [n for n in names if _is_region(n) and n.startswith(owner + '_')]


def plain_target(names, owner, raw):
    regs = owner_regions(names, owner)
    if not regs:
        return owner
    R = set(raw)
    drawer = 'drawer' in R or 'drawers' in R
    best, bs = owner, -1e9
    for r in regs:
        suf = r[len(owner) + 1:].split('_')
        toks = set(suf) - {'region', 'contain', 'side'}
        s = 3 * len(toks & R)
        if drawer and 'side' in suf:
            s -= 5
        if (not drawer) and 'top' in R and 'side' in suf:
            s += 2
        if not toks or toks <= {'cook', 'heating'}:
            s += 1
        if s > bs:
            bs, best = s, r
    return best


def _valid(api, n):
    try:
        P(api, n)
        return True
    except Exception:
        return False


def directional_target(api, names, owner, d, rel):
    try:
        r = api.relative_target(owner, d, rel)
        if isinstance(r, str) and r and _valid(api, r):
            return r
    except Exception:
        pass
    obase = set(_base(owner).split('_'))
    if rel == 'inside':
        c = [n for n in owner_regions(names, owner) if d in n.split('_')]
        # exact-direction compartment first (avoid e.g. front_left)
        c.sort(key=lambda n: len(n.split('_')))
        if c:
            return c[0]
    else:
        alias = {'back': ('back', 'behind', 'rear')}.get(d, (d,))
        c = [n for n in names if _is_region(n) and not n.startswith(owner + '_')
             and obase <= set(n.split('_'))
             and any(a in n.split('_') for a in alias) and 'contain' not in n]
        c.sort(key=lambda n: len(n.split('_')))
        if c:
            return c[0]
    return None


def place_target(api, names, bodies, prep, tw):
    allw = [prep] + list(tw)
    owner = resolve(api, names, bodies, tw)
    if owner is None:
        return None
    dirw = None
    for w in allw:
        if w in DIRS:
            dirw = w
            break
    is_drawer = 'drawer' in allw or 'drawers' in allw
    if dirw and not is_drawer:
        inside = any(w in allw for w in ('compartment', 'compartments', 'inside'))
        r = directional_target(api, names, owner, DIRS[dirw],
                               'inside' if inside else 'outside')
        if r:
            return (r, owner)
    return (plain_target(names, owner, allw), owner)


def drawer_region(api, names, bodies, rest):
    owner = resolve(api, names, bodies, rest)
    if owner is None:
        cabs = [b for b in bodies if 'cabinet' in b]
        owner = cabs[0] if cabs else None
    if owner is None:
        return None
    regs = [r for r in owner_regions(names, owner) if 'side' not in r.split('_')]
    if not regs:
        return None
    for lv in LEVELS:
        if lv in rest:
            m = [r for r in regs if lv in r.split('_')]
            if m:
                return (m[0], owner)
    # no level named: choose the drawer sticking out furthest (likely the open one)
    try:
        op = P(api, owner)
        regs.sort(key=lambda r: -np.linalg.norm(P(api, r)[:2] - op[:2]))
    except Exception:
        pass
    return (regs[0], owner)


# ------------------------------------------------------------------ parsing
def split_clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if (w == 'and' and (nxt in VERBS or nxt == 'then')) or w == 'then':
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return [c for c in out if c]


def split_items(ws):
    both = 'both' in ws
    has_the = any(ws[j] == 'and' and j + 1 < len(ws) and ws[j + 1] in ('the', 'a')
                  for j in range(len(ws)))
    parts = [[]]
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if w == 'and' and ((has_the and nxt in ('the', 'a')) or (both and not has_the)):
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def build_plan(api, names, bodies, words):
    ops = []
    last_item, last_tgt = None, None
    for c in split_clauses(words):
        while c and c[-1] == 'and':
            c = c[:-1]
        if not c:
            continue
        v, rest = c[0], c[1:]
        if v in ('turn', 'switch'):
            return None                      # stove/appliance: use old policy
        pron = rest in ([], ['it'], ['them'])
        if v in ('open', 'close', 'shut') or (v in ('pull', 'push') and 'drawer' in rest):
            mode = 'open' if v in ('open', 'pull') else 'close'
            if pron:
                if last_tgt is None or 'cabinet' not in last_tgt[1]:
                    return None
                tgt = last_tgt
            else:
                if not ('drawer' in rest or 'drawers' in rest or 'cabinet' in rest):
                    return None              # microwave etc.
                tgt = drawer_region(api, names, bodies, rest)
            if tgt is None:
                return None
            ops.append(('drawer', tgt[0], mode))
            last_tgt = tgt
            continue
        rest = [w for w in rest if w != 'up']
        idx = None
        for i, w in enumerate(rest):
            if w in PREPS and i > 0:
                idx = i
                break
        if v in PICKV and idx is None:
            it = last_item if pron else resolve(api, names, bodies, rest)
            if it is None:
                return None
            ops.append(('pick', it))
            last_item = it
            continue
        if idx is None:
            return None
        item_w, prep, tw = rest[:idx], rest[idx], rest[idx + 1:]
        if tw in ([], ['it'], ['them']):
            tgt = last_tgt
        else:
            tgt = place_target(api, names, bodies, prep, tw)
        if tgt is None:
            return None
        items = []
        for part in split_items(item_w):
            if part in (['it'], ['them']):
                it = last_item
            else:
                it = resolve(api, names, bodies, part, exclude=(tgt[1],))
            if it and it not in items:
                items.append(it)
        if not items:
            return None
        if ops and ops[-1][0] == 'pick' and ops[-1][1] in items:
            ops.pop()
        for it in items:
            ops.append(('place', it, tgt))
        last_item = items[-1]
        last_tgt = tgt
    return ops


# ------------------------------------------------------------------ skills
def grasp_mode(item):
    b = _base(item)
    if 'book' in b:
        return 'thin_edge'
    if 'bowl' in b:
        return 'rim'
    return 'standard'


def tol_for(name):
    if 'caddy' in name:
        return 0.05
    if 'cabinet' in name and 'side' not in name:
        return 0.10
    if 'basket' in name or 'contain' in name:
        return 0.08
    return 0.07


def place_err(api, item, name):
    try:
        ip, tp = P(api, item), P(api, name)
    except Exception:
        return 0.0, True
    return float(np.linalg.norm(ip[:2] - tp[:2])), bool(ip[2] > tp[2] - 0.06)


def lift_clear(api):
    try:
        api.grip(False)
        e = E(api)
        api.move(e + V(0, 0, 0.10), steps=12)
    except Exception:
        pass


def do_place(api, item, tgt):
    name = tgt[0]
    mode = grasp_mode(item)
    tol = tol_for(name)
    for attempt in range(2):
        try:
            api.place_with(item, name, mode)
        except Exception:
            try:
                api.transfer(item, name)
            except Exception:
                pass
        d, zok = place_err(api, item, name)
        if d < tol and zok:
            return True
        # only retry when clearly not placed, to avoid dragging it back out
        if d < max(0.08, 1.5 * tol) and zok:
            return False
        lift_clear(api)
    return False


def pick_only(api, item):
    p = P(api, item)
    api.grip(False)
    e = E(api)
    api.move(V(e[0], e[1], max(e[2], p[2] + 0.12)), steps=12)
    api.move(p + V(0, 0, 0.10), steps=25)
    api.move(p, steps=20)
    api.grip(True)
    api.move(p + V(0, 0, 0.15), steps=25)


# ------------------------------------------------------------------ main
def run(api):
    try:
        names = list(api.names())
        bodies = [n for n in names if not _is_region(n)]
        ops = build_plan(api, names, bodies, _words(api.instruction))
    except Exception:
        ops = None
    if not ops:
        api.fallback()
        return
    for op in ops:
        try:
            if op[0] == 'drawer':
                api.drawer(op[1], op[2])
                lift_clear(api)
            elif op[0] == 'place':
                do_place(api, op[1], op[2])
            elif op[0] == 'pick':
                pick_only(api, op[1])
        except Exception:
            lift_clear(api)
