import math
import numpy as np

# ---------------------------------------------------------------- vocabulary
ALIAS = {
    'akita_black_bowl': 'black bowl',
    'black_bowl': 'black bowl',
    'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup',
    'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup',
    'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop',
    'moka_pot': 'moka pot',
    'desk_caddy': 'desk caddy',
    'black_book': 'black book',
    'yellow_book': 'yellow book',
    'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can',
    'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle',
    'ketchup': 'ketchup bottle',
    'butter': 'butter box',
    'milk': 'milk carton',
    'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box',
    'salad_dressing': 'salad dressing bottle',
    'new_salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet',
    'wooden_cabinet': 'wooden cabinet',
    'wooden_two_layer_shelf': 'wooden shelf',
    'wine_bottle': 'wine bottle',
    'wine_rack': 'wine rack',
    'microwave': 'microwave oven',
    'basket': 'basket',
    'plate': 'plate',
    'cookies': 'cookie cookies box',
    'glazed_rim_porcelain_ramekin': 'ramekin',
    'wooden_tray': 'wooden tray',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown',
          'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'top',
        'left', 'right', 'front', 'back', 'bottom', 'middle', 'compartment',
        'compartments', 'side', 'its', 'that', 'is', 'please', 'then', 'next',
        'beside', 'behind', 'between', 'near', 'on', 'in', 'into', 'onto',
        'inside', 'from', 'at', 'region', 'area', 'drawer', 'drawers'}
VERBS = {'put', 'place', 'turn', 'switch', 'close', 'shut', 'open', 'pick',
         'push', 'pull', 'move', 'stack', 'lift', 'grab', 'take', 'set'}
PICKV = ('pick', 'grab', 'lift', 'take')
PREPS = ('into', 'onto', 'inside', 'in', 'on', 'to', 'next', 'beside', 'behind')
QUALS = ('between', 'next', 'beside', 'near', 'on', 'in', 'from', 'at',
         'inside', 'behind')
DIRS = ('left', 'right', 'front', 'back')
DVEC = {'left': (0.0, 1.0), 'right': (0.0, -1.0),
        'front': (-1.0, 0.0), 'back': (1.0, 0.0)}


def V(*a):
    return np.array(a, dtype=float)


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def E(api):
    return np.array(api.eef(), dtype=float)


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _words(s):
    s = ''.join(c if c.isalnum() else ' ' for c in s.lower())
    return s.split()


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return w


# ---------------------------------------------------------------- resolution
def _spatial(api, names, raw, cands):
    for w in DIRS:
        if w in raw:
            head = _base(cands[0]).split('_')[-1]
            hints = [n for n in names if _is_region(n)
                     and w in n.split('_') and head in n.split('_')]
            if hints:
                hp = P(api, hints[0])
                return sorted(cands, key=lambda c: np.linalg.norm(P(api, c)[:2] - hp[:2]))
            keyf = {'left': lambda p: -p[1], 'right': lambda p: p[1],
                    'front': lambda p: p[0], 'back': lambda p: -p[0]}[w]
            return sorted(cands, key=lambda c: keyf(P(api, c)))
    return sorted(cands)


def candidates(bodies, raw, exclude=()):
    W = set(w for w in raw if w not in STOP)
    if not W:
        return []
    best, cands = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, cands = s, [b]
        elif abs(s - best) < 1e-9:
            cands.append(b)
    return sorted(cands)


def resolve(api, names, bodies, raw, exclude=()):
    c = candidates(bodies, raw, exclude)
    if not c:
        return None
    if len(c) > 1:
        c = _spatial(api, names, raw, c)
    return c[0]


def resolve_target(api, names, bodies, raw, prep=None, exclude=()):
    """returns (target_name, owner_body)"""
    obj = resolve(api, names, bodies, raw, exclude)
    if obj is None:
        return None
    regs = [n for n in names if _is_region(n) and n.startswith(obj + '_')]
    if not regs:
        return (obj, obj)
    R = set(raw)
    drawer = 'drawer' in R or 'drawers' in R
    best, bs = None, -1e9
    for r in regs:
        suf = r[len(obj) + 1:].split('_')
        toks = set(suf) - {'region', 'contain', 'side'}
        s = 3 * len(toks & R)
        if drawer and 'side' in suf:
            s -= 5
        if (not drawer) and 'top' in R and 'side' in suf:
            s += 2
        if (not drawer) and prep in ('on', 'onto') and 'side' in suf:
            s += 2
        if not toks or toks <= {'cook', 'heating'}:
            s += 1
        if s > bs:
            bs, best = s, r
    return (best, obj)


def resolve_item(api, names, bodies, ws, exclude=()):
    """object description possibly qualified by location
    ('the black bowl next to the plate', 'between the plate and the ramekin')"""
    qi = None
    for i, w in enumerate(ws):
        if i > 0 and w in QUALS:
            qi = i
            break
    head = ws if qi is None else ws[:qi]
    cands = candidates(bodies, head, exclude)
    if not cands:
        cands = candidates(bodies, ws, exclude)
        if not cands:
            return None
    if len(cands) == 1:
        return cands[0]
    if qi is None:
        return _spatial(api, names, ws, cands)[0]
    kind, q = ws[qi], ws[qi + 1:]
    others = [b for b in bodies if b not in cands]
    rp = None
    try:
        if kind == 'between':
            parts, cur = [], []
            for w in q:
                if w == 'and':
                    parts.append(cur)
                    cur = []
                else:
                    cur.append(w)
            parts.append(cur)
            ps = []
            for p in parts:
                r = resolve(api, names, others, p)
                if r:
                    ps.append(P(api, r))
            if ps:
                rp = np.mean(ps, axis=0)
        else:
            t = resolve_target(api, names, others, q, prep=kind)
            if t:
                rp = P(api, t[0])
    except Exception:
        rp = None
    if rp is None:
        return _spatial(api, names, ws, cands)[0]
    xy_only = kind in ('between', 'next', 'beside', 'near', 'at', 'behind')
    def dist(c):
        d = P(api, c) - rp
        return np.linalg.norm(d[:2]) if xy_only else np.linalg.norm(d)
    return sorted(cands, key=dist)[0]


def rel_target(api, names, bodies, tw, prep):
    """spatial placement targets: left/right/front/back compartments (inside)
    or table locations next to a fixture (outside)."""
    dirs = [w for w in tw if w in DIRS]
    if prep == 'behind' or 'behind' in tw:
        dirs = ['back']
    near = prep in ('next', 'beside', 'near') or 'next' in tw or 'beside' in tw
    if not dirs and not near:
        return None
    ref_words = [w for w in tw if w not in DIRS]
    ref = resolve(api, names, bodies, ref_words)
    if ref is None:
        return None
    if not dirs:
        return ('@near', ref)
    d = dirs[0]
    j = tw.index(d) if d in tw else -1
    after = tw[j + 1] if 0 <= j < len(tw) - 1 else ''
    ref_regs = [n for n in names if _is_region(n) and n.startswith(ref + '_')]
    if 'compartment' in tw or 'compartments' in tw:
        rel = 'inside'
    elif prep in ('in', 'into', 'inside'):
        if d == 'front' and j == 0 and after == 'of':
            rel = 'outside'               # "in front of X"
        elif any('contain' in n or d in n.split('_') for n in ref_regs):
            rel = 'inside'
        else:
            rel = 'outside'
    else:
        rel = 'outside'
    r = None
    try:
        r = api.relative_target(ref, d, rel)
    except Exception:
        r = None
    if r:
        return (str(r), ref)
    for n in ref_regs:
        if d in n.split('_'):
            return (n, ref)
    return ('@' + d, ref)


# ---------------------------------------------------------------- parsing
def split_clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if (w == 'and' and (nxt in VERBS or nxt == 'then')) or w == 'then':
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return [c for c in out if c]


def split_items(ws):
    both = 'both' in ws
    has_the = any(ws[j] == 'and' and j + 1 < len(ws) and ws[j + 1] in ('the', 'a')
                  for j in range(len(ws)))
    parts = [[]]
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if w == 'and' and ((has_the and nxt in ('the', 'a')) or (both and not has_the)):
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def build_plan(api, names, bodies, words):
    ops = []
    last_item, last_target, last_fix = None, None, None
    for c in split_clauses(words):
        while c and c[-1] == 'and':
            c = c[:-1]
        if not c:
            continue
        v, rest = c[0], c[1:]
        if v not in VERBS:
            v, rest = 'put', c
        if v in ('turn', 'switch'):
            on = 'off' not in rest
            ow = [w for w in rest if w not in ('on', 'off')]
            obj = last_fix if (not ow or ow == ['it']) else resolve(api, names, bodies, ow)
            if obj:
                ops.append(('turn', obj, on))
                last_fix = obj
            continue
        if v in ('close', 'shut', 'open'):
            if not rest or rest in (['it'], ['them']):
                tgt = last_target if last_target else (
                    (last_fix, last_fix) if last_fix else None)
            else:
                tgt = resolve_target(api, names, bodies, rest)
            if tgt:
                ops.append(('open' if v == 'open' else 'close', tgt))
                last_target = tgt
                last_fix = tgt[1]
            continue
        rest = [w for w in rest if w != 'up']
        if v in PICKV and not any(w in ('into', 'onto') for w in rest):
            it = resolve_item(api, names, bodies, rest)
            if it:
                ops.append(('pick', it))
                last_item = it
            continue
        idx = None
        for i, w in enumerate(rest):
            if w in PREPS and i > 0:
                idx = i
                break
        if idx is None:
            item_w, tw, prep = rest, [], None
        else:
            item_w, tw, prep = rest[:idx], rest[idx + 1:], rest[idx]
        if prep == 'next' and tw and tw[0] == 'to':
            tw = tw[1:]
        tgt = None
        if tw and tw not in (['it'], ['them'], ['inside'], ['in']):
            tgt = rel_target(api, names, bodies, tw, prep)
            if tgt is None:
                tgt = resolve_target(api, names, bodies, tw, prep=prep)
        elif tw:
            if last_target and last_target[1] == last_fix:
                tgt = last_target
            elif last_fix:
                tgt = resolve_target(api, names, bodies,
                                     _base(last_fix).split('_'), prep=prep)
                if tgt is None or tgt[1] != last_fix:
                    tgt = (last_fix, last_fix)
            else:
                tgt = last_target
        else:
            tgt = last_target
        if tgt is None:
            continue
        items = []
        for part in split_items(item_w):
            if part in (['it'], ['them']):
                it = last_item
            else:
                it = resolve_item(api, names, bodies, part, exclude=(tgt[1],))
            if it and it not in items:
                items.append(it)
        if ops and ops[-1][0] == 'pick' and ops[-1][1] in items:
            ops.pop()
        for k, it in enumerate(items):
            ops.append(('place', it, tgt, k, len(items)))
        if items:
            last_item = items[-1]
        last_target = tgt
        last_fix = tgt[1]
    return ops


# ---------------------------------------------------------------- legacy skills
def grasp_options(item):
    b = _base(item)
    if 'mug' in b or 'cup' in b:
        return [(0.0, 0.03, 0.02), (0.0, -0.03, 0.02)]
    if 'bowl' in b:
        return [(0.0, 0.045, 0.01), (0.0, -0.045, 0.01)]
    return [(0.0, 0.0, 0.0), (0.0, 0.0, -0.01)]


BOWL_GRASPS = [(0.0, 0.06, 0.025), (0.0, -0.06, 0.025), (0.0, 0.05, 0.035)]


def drawer_dir(api, region, owner):
    rp = P(api, region)
    op = P(api, owner) if owner else rp
    d = op[:2] - rp[:2]
    nd = np.linalg.norm(d)
    d = d / nd if nd > 0.03 else np.array([1.0, 0.0])
    return np.array([d[0], d[1], 0.0])


def drop_for(api, item, tgt, k, n):
    name, owner = tgt
    z = 0.08
    off = np.zeros(3)
    if 'basket' in name:
        z = 0.11
    elif 'caddy' in name:
        z = 0.10
    elif 'cook' in name:
        z = 0.05
    elif 'plate' in name:
        z = 0.06
    elif 'cabinet' in owner and name != owner and 'side' not in name:
        z = 0.06
        off = -drawer_dir(api, name, owner) * 0.03
    if n > 1 and ('basket' in name or 'contain' in name) and 'caddy' not in name:
        off[1] += 0.03 if k % 2 == 0 else -0.03
    return (float(off[0]), float(off[1]), float(off[2] + z))


def placed_ok(api, item, name):
    ip, tp = P(api, item), P(api, name)
    tol = 0.07
    if 'basket' in name or 'contain' in name:
        tol = 0.08
    if 'caddy' in name:
        tol = 0.06
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.06


def recover(api):
    api.grip(False)
    e = E(api)
    api.move(e + V(0, 0, 0.12), steps=15)


def try_grasp(api, item, g):
    p0 = P(api, item)
    p = p0 + V(*g)
    api.grip(False)
    e = E(api)
    api.move(V(e[0], e[1], max(e[2], p[2] + 0.12)), steps=10)
    api.move(p + V(0, 0, 0.10), steps=22)
    api.move(p, steps=18)
    api.grip(True)
    api.move(p + V(0, 0, 0.08), steps=12)
    return P(api, item)[2] - p0[2] > 0.025


def manual_place(api, item, tgt, k, n, options):
    name = tgt[0]
    drop = np.array(drop_for(api, item, tgt, k, n))
    for g in options:
        if not try_grasp(api, item, g):
            recover(api)
            continue
        ip = P(api, item)
        e = E(api)
        rel = e - ip
        dest = P(api, name) + drop
        eg = dest + rel
        hz = max(e[2], eg[2] + 0.12)
        z_before = P(api, item)[2]
        api.move(V(e[0], e[1], hz), steps=15)
        if P(api, item)[2] < z_before - 0.02:
            recover(api)
            continue
        api.move(V(eg[0], eg[1], hz), steps=35)
        api.move(eg, steps=20)
        api.grip(False)
        e = E(api)
        api.move(e + V(0, 0, 0.10), steps=12)
        if placed_ok(api, item, name):
            return True
    return False


def legacy_place(api, item, tgt, k, n):
    name = tgt[0]
    if 'bowl' in _base(item):
        if manual_place(api, item, tgt, k, n, BOWL_GRASPS):
            return True
    drop = drop_for(api, item, tgt, k, n)
    for g in grasp_options(item):
        try:
            api.transfer(item, name, grasp=g, drop=drop)
        except Exception:
            pass
        if placed_ok(api, item, name):
            return True
        recover(api)
    return False


def pick_only(api, item):
    g = np.array(grasp_options(item)[0])
    p = P(api, item) + g
    api.grip(False)
    api.move(p + V(0, 0, 0.12), steps=30)
    api.move(p, steps=25)
    api.grip(True)
    api.move(p + V(0, 0, 0.15), steps=25)


def push_close(api, tgt):
    name, owner = tgt
    rp = P(api, name)
    d3 = drawer_dir(api, name, owner)
    start = rp - d3 * 0.20
    start[2] = rp[2] + 0.03
    e = E(api)
    high = max(e[2], rp[2] + 0.15)
    api.move(V(e[0], e[1], high), steps=15)
    api.move(V(start[0], start[1], high), steps=30)
    api.grip(True)
    api.move(start, steps=25)
    api.move(start + d3 * 0.32, steps=60)
    back = start + d3 * 0.20
    api.move(back, steps=10)
    api.move(back + V(0, 0, 0.12), steps=15)


def pull_open(api, tgt):
    name, owner = tgt
    rp = P(api, name)
    d3 = drawer_dir(api, name, owner)
    handle = rp - d3 * 0.13
    handle[2] = rp[2] + 0.04
    pre = handle - d3 * 0.08
    e = E(api)
    api.grip(False)
    api.move(V(e[0], e[1], max(e[2], handle[2] + 0.12)), steps=15)
    api.move(pre + V(0, 0, 0.10), steps=30)
    api.move(pre, steps=20)
    api.move(handle, steps=20)
    api.grip(True)
    api.move(handle - d3 * 0.22, steps=50)
    api.grip(False)
    e = E(api)
    api.move(e + V(0, 0, 0.10), steps=15)


def twist_knob(api, k, grasp_z, on):
    sgn = 1.0 if on else -1.0
    api.grip(False)
    e = E(api)
    api.move(V(e[0], e[1], max(e[2], grasp_z + 0.15)), steps=15)
    api.move(V(k[0], k[1], grasp_z + 0.10), steps=25)
    api.move(V(k[0], k[1], grasp_z), steps=20)
    api.grip(True)
    api.action([0, 0, 0, 0, 0, 0.35 * sgn, 1.0], steps=12)
    api.grip(False)
    e = E(api)
    api.move(e + V(0, 0, 0.10), steps=12)
    api.action([0, 0, 0, 0, 0, -0.35 * sgn, -1.0], steps=12)


def sweep_stove(api, sp, cp, on):
    sgn = 1.0 if on else -1.0
    e = E(api)
    api.move(V(e[0], e[1], max(e[2], cp[2] + 0.15)), steps=15)
    api.grip(True)
    lines = [(cp[0] - 0.07, cp[2] + 0.015),
             (min(sp[0], cp[0]) - 0.13, max(cp[2] - 0.015, sp[2] + 0.012))]
    for x, z in lines:
        a = V(x, cp[1] + 0.13 * sgn, z)
        b = V(x, cp[1] - 0.13 * sgn, z)
        api.move(V(a[0], a[1], cp[2] + 0.12), steps=25)
        api.move(a, steps=20)
        api.move(b, steps=45)
        api.move(V(b[0], b[1], cp[2] + 0.12), steps=15)


def turn_stove(api, stove, names, on):
    kp = None
    for n in names:
        if n.startswith(_base(stove)) and any(k in n for k in ('knob', 'button', 'switch')):
            try:
                kp = P(api, n)
                break
            except Exception:
                pass
    if kp is None:
        for suf in ('_knob', '_button', '_knob_1', '_switch'):
            try:
                kp = P(api, stove + suf)
                break
            except Exception:
                kp = None
    cook = [n for n in names if n.startswith(stove + '_') and 'cook' in n]
    sp = P(api, stove)
    cp = P(api, cook[0]) if cook else sp + V(0, 0, 0.02)
    if kp is not None:
        twist_knob(api, kp, kp[2] + 0.005, on)
        return
    d = sp[:2] - cp[:2]
    nd = np.linalg.norm(d)
    if nd >= 0.025:
        if nd > 0.15:
            d = d / nd * 0.15
        k = V(sp[0] + d[0], sp[1] + d[1], cp[2])
        twist_knob(api, k, cp[2] + 0.005, on)
        return
    sweep_stove(api, sp, cp, on)


# ---------------------------------------------------------------- new skills
def grasp_types(item):
    b = _base(item)
    if 'bowl' in b:
        return ['rim', 'standard']
    if 'book' in b:
        return ['thin_edge', 'standard']
    return ['standard']


def safe_ok(api, item, name):
    try:
        return placed_ok(api, item, name)
    except Exception:
        return False


def near_region(api, ref, item):
    best, bd = None, 1e9
    try:
        ip = P(api, item)
    except Exception:
        return None
    for d in DIRS:
        try:
            r = api.relative_target(ref, d, 'outside')
            if not r:
                continue
            dist = np.linalg.norm(P(api, r)[:2] - ip[:2])
        except Exception:
            continue
        if dist < bd:
            bd, best = dist, str(r)
    return best


def offset_place(api, item, ref, d):
    v = DVEC[d]
    drop = (v[0] * 0.15, v[1] * 0.15, 0.06)
    for g in grasp_options(item):
        try:
            lift = api.transfer(item, ref, grasp=g, drop=drop)
        except Exception:
            lift = 0.0
        if lift and lift > 0.02:
            return True
        recover(api)
    return False


def do_place(api, item, tgt, k, n):
    name, owner = tgt
    if name == '@near':
        r = near_region(api, owner, item)
        if r is None:
            try:
                dv = P(api, item)[:2] - P(api, owner)[:2]
                d = max(DIRS, key=lambda w: DVEC[w][0] * dv[0] + DVEC[w][1] * dv[1])
            except Exception:
                d = 'left'
            return offset_place(api, item, owner, d)
        name = r
        tgt = (r, owner)
    elif name.startswith('@'):
        return offset_place(api, item, owner, name[1:])
    if safe_ok(api, item, name):
        return True
    for t in grasp_types(item):
        try:
            api.place_with(item, name, t)
        except Exception:
            pass
        if safe_ok(api, item, name):
            return True
        try:
            recover(api)
        except Exception:
            pass
    return legacy_place(api, item, tgt, k, n)


DRAWER_SUFS = ('top_region', 'middle_region', 'bottom_region')


def do_drawer(api, names, tgt, mode):
    name, owner = tgt
    reg = name
    if name.endswith('_side'):
        cand = name[:-len('_side')] + '_region'
        if cand in names:
            reg = cand
    if reg == owner:
        regs = [n for n in names if n.startswith(owner + '_')
                and any(n.endswith(s) for s in DRAWER_SUFS)]
        if regs:
            reg = sorted(regs, key=lambda r: [s in r for s in DRAWER_SUFS], reverse=True)[0]
    if any(reg.endswith(s) for s in DRAWER_SUFS) or 'drawer' in reg:
        try:
            api.drawer(reg, mode)
            return
        except Exception:
            pass
    if mode == 'open':
        pull_open(api, (reg, owner))
    else:
        push_close(api, (reg, owner))


# ---------------------------------------------------------------- main
def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    words = _words(api.instruction)
    try:
        ops = build_plan(api, names, bodies, words)
    except Exception:
        ops = []
    if not ops:
        api.fallback()
        return
    for op in ops:
        try:
            kind = op[0]
            if kind == 'turn':
                turn_stove(api, op[1], names, op[2])
            elif kind == 'place':
                do_place(api, op[1], op[2], op[3], op[4])
            elif kind == 'close':
                do_drawer(api, names, op[1], 'close')
            elif kind == 'open':
                do_drawer(api, names, op[1], 'open')
            elif kind == 'pick':
                pick_only(api, op[1])
        except Exception:
            try:
                recover(api)
            except Exception:
                pass
