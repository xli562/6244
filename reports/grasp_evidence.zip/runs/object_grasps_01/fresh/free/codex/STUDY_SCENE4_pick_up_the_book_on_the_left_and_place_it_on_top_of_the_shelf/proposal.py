def run(api):
    import numpy as np

    text = " ".join(
        api.instruction.lower().replace("-", " ").replace(",", " ").split()
    )
    names = list(api.names())
    bodies = [
        n for n in names
        if n.rsplit("_", 1)[-1].isdigit()
        and "region" not in n
        and not n.endswith("_side")
    ]

    def words(name):
        return name.replace("_", " ")

    def aliases(name):
        base = words(name.rsplit("_", 1)[0])
        result = [base]
        mappings = {
            "akita black bowl": ["black bowl", "bowl"],
            "porcelain mug": ["white mug", "mug"],
            "white yellow mug": [
                "yellow and white mug", "white and yellow mug",
                "yellow mug", "mug"
            ],
            "red coffee mug": ["red coffee mug", "red mug", "mug"],
            "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
            "wooden two layer shelf": ["wooden shelf", "shelf"],
            "desk caddy": ["desk caddy", "caddy"],
            "flat stove": ["stove"],
            "white cabinet": ["cabinet"],
            "cream cheese": ["cream cheese box"],
        }
        result.extend(mappings.get(base, []))
        for noun in (
            "book", "bowl", "plate", "basket", "cabinet", "shelf",
            "mug", "cup", "bottle", "pot", "caddy"
        ):
            if noun in base.split():
                result.append(noun)
        return list(set(result))

    def score(name, phrase):
        padded = " " + phrase + " "
        return max(
            [len(a) for a in aliases(name) if " " + a + " " in padded]
            or [0]
        )

    def matches(phrase, pool=None):
        pool = bodies if pool is None else pool
        ranked = [(score(n, phrase), n) for n in pool]
        best = max([s for s, n in ranked] or [0])
        return [n for s, n in ranked if best and s == best]

    def direction(phrase):
        for token in phrase.split():
            if token in ("left", "right", "front", "back"):
                return token
        return None

    def resolve(phrase, pool=None):
        candidates = matches(phrase, pool)
        if not candidates:
            return None
        if len(candidates) == 1:
            return candidates[0]

        side = direction(phrase)
        if side:
            markers = []
            for n in names:
                if "region" not in n or side not in n.split("_"):
                    continue
                marker_text = words(n)
                relevance = max(
                    [len(a) for c in candidates for a in aliases(c)
                     if a in marker_text] or [0]
                )
                if relevance:
                    markers.append((relevance, n))
            if markers:
                marker = max(markers, key=lambda x: x[0])[1]
                return api.nearest(marker, candidates)
        return None

    def owned_region(body, suffixes):
        for suffix in suffixes:
            exact = body + "_" + suffix
            if exact in names:
                return exact
        return None

    def target_for(phrase):
        body = resolve(phrase)
        if body is None:
            return None

        if "drawer" in phrase:
            level = next(
                (v for v in ("top", "middle", "bottom") if v in phrase),
                None
            )
            if level is None:
                return None
            return owned_region(body, [level + "_region"])

        side = direction(phrase)
        if side and any(v in phrase for v in (
            "next to", "beside", "to the left", "to the right",
            "in front of", "behind"
        )):
            return api.relative_target(body, side, "outside")

        if side and any(v in phrase for v in (
            "compartment", "inside", " in ", "into", "caddy"
        )):
            return api.relative_target(body, side, "inside")

        if "on top" in phrase or "top of" in phrase:
            return owned_region(body, ["top_side", "top_region"]) or body
        if "bottom" in phrase:
            return owned_region(body, ["bottom_region"]) or body
        if "stove" in body:
            return owned_region(body, ["cook_region"]) or body
        if any(v in phrase for v in ("inside", "into", " in ", "basket", "caddy")):
            return owned_region(body, ["contain_region"]) or body
        return body

    def source_items(phrase):
        # Resolve each explicitly coordinated object separately.
        parts = phrase.split(" and ")
        items = []
        for part in parts:
            if not matches(part):
                continue
            item = resolve(part)
            if item is None:
                return None
            if item not in items:
                items.append(item)
        return items or None

    def placement(clause, remembered):
        tokens = clause.split()
        verb = next(
            (i for i, t in enumerate(tokens) if t in ("put", "place", "set")),
            None
        )
        if verb is None:
            return None

        tail = " ".join(tokens[verb + 1:])
        separators = (
            " on top of ", " into ", " inside ", " onto ",
            " in ", " on ", " next to ", " beside "
        )
        hits = [(tail.find(s), s) for s in separators if s in tail]
        if not hits:
            return None
        index, separator = min(hits, key=lambda pair: pair[0])
        source = tail[:index]
        destination = tail[index:]

        if source.strip() in ("it", "them", "the object"):
            source = remembered
        items = source_items(source)
        target = target_for(destination)
        if not items or target is None or target in items:
            return None
        return [("place", item, target) for item in items]

    # Build a complete ordered plan before making physical changes.
    tokens = text.split()
    starts = [
        i for i, token in enumerate(tokens)
        if token in ("open", "close", "shut", "put", "place", "set", "turn")
    ]
    if not starts:
        return api.fallback()

    remembered = " ".join(tokens[:starts[0]])
    plan = []
    last_drawer = None

    for j, start in enumerate(starts):
        end = starts[j + 1] if j + 1 < len(starts) else len(tokens)
        clause = " ".join(tokens[start:end])
        verb = tokens[start]

        if verb == "turn":
            return api.fallback()

        if verb in ("open", "close", "shut"):
            if "drawer" not in clause and last_drawer is None:
                return api.fallback()
            level = next(
                (v for v in ("top", "middle", "bottom") if v in clause),
                None
            )
            regions = [
                n for n in names
                if "region" in n and "init" not in n
                and ("cabinet" in n or "drawer" in n)
                and (level is None or level in n.split("_"))
                and any(v in n.split("_") for v in ("top", "middle", "bottom"))
            ]
            region = (
                regions[0] if len(regions) == 1
                else last_drawer if level is None else None
            )
            if region is None:
                return api.fallback()
            last_drawer = region
            plan.append(("drawer", region, "open" if verb == "open" else "close"))
        else:
            jobs = placement(clause, remembered)
            if jobs is None:
                return api.fallback()
            plan.extend(jobs)

    for operation, item, target in plan:
        if operation == "drawer":
            result = api.drawer(item, target)
        else:
            grasp = (
                "thin_edge" if "book" in item
                else "rim" if "bowl" in item
                else "standard"
            )
            result = api.place_with(item, target, grasp)
        if result is False:
            return
