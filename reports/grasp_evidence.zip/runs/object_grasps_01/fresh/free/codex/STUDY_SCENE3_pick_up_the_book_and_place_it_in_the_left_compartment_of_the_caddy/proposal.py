def run(api):
    names = list(api.names())
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    bodies = [
        n for n in names
        if "region" not in n and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    synonyms = {
        "black book": ["book"],
        "desk caddy": ["caddy"],
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug"
        ],
        "red coffee mug": ["red mug", "coffee mug"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["stove"],
        "white cabinet": ["cabinet"],
        "cream cheese": ["cream cheese box"],
    }

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        result = [base] + synonyms.get(base, [])
        for word in ("basket", "plate", "bowl", "mug", "book", "cabinet"):
            if word in base.split() and word not in result:
                result.append(word)
        return result

    def mentions(s):
        hits = []
        padded = " " + s + " "
        for body in bodies:
            for alias in aliases(body):
                needle = " " + alias + " "
                start = padded.find(needle)
                while start >= 0:
                    hits.append((start, start + len(alias), body))
                    start = padded.find(needle, start + 1)
        # Prefer specific names over overlapping generic aliases.
        selected = []
        for hit in sorted(hits, key=lambda h: -(h[1] - h[0])):
            if not any(hit[0] <= h[1] and h[0] <= hit[1]
                       for h in selected):
                selected.append(hit)
        return sorted(selected)

    def region(body, suffix):
        return next(
            (n for n in names if n == body + "_" + suffix), None
        )

    def direction(s):
        for word in s.replace(",", " ").split():
            if word in ("left", "right", "front", "back"):
                return word
            if word == "behind":
                return "back"
        return None

    def drawer_region(s, previous=None):
        level = next(
            (v for v in ("top", "middle", "bottom") if v in s.split()),
            None,
        )
        cabinets = [
            h[2] for h in mentions(s) if "cabinet" in h[2]
        ]
        cabinet = cabinets[-1] if cabinets else next(
            (b for b in bodies if "cabinet" in b), None
        )
        if level and cabinet:
            return region(cabinet, level + "_region")
        if previous:
            return previous
        candidates = [
            n for n in names
            if "cabinet" in n
            and any(n.endswith("_" + v + "_region")
                    for v in ("top", "middle", "bottom"))
        ]
        return candidates[0] if len(candidates) == 1 else None

    # Preserve the sequence of requested operations.
    normalized = text
    for separator in (", then ", " and then ", " then ", "; ", ". "):
        normalized = normalized.replace(separator, "|")
    for verb in ("open", "close", "put", "place", "insert", "move"):
        normalized = normalized.replace(" and " + verb + " ",
                                        "|" + verb + " ")
    clauses = [c.strip(" ,.") for c in normalized.split("|") if c.strip()]
    plan = []
    held_items = []
    last_target = None
    last_drawer = None

    for clause in clauses:
        words = clause.split()
        if not words:
            continue

        if words[0] in ("open", "close"):
            target = drawer_region(clause, last_drawer)
            if target is None:
                return api.fallback()
            plan.append(("drawer", target, words[0]))
            last_drawer = target
            last_target = target
            continue

        placement = any(
            v in words for v in ("put", "place", "insert", "move")
        )
        if not placement:
            if "pick up" in clause or "take" in words:
                held_items = list(dict.fromkeys(h[2] for h in mentions(clause)))
                continue
            return api.fallback()

        # Separate source descriptions from the destination phrase.
        separators = (
            " into ", " inside ", " in ", " onto ", " on ",
            " to ", " next to ",
        )
        locations = [
            (clause.find(s), s) for s in separators if s in clause
        ]
        if not locations:
            return api.fallback()
        index, separator = min(locations)
        source = clause[:index]
        destination = clause[index + len(separator):]
        items = list(dict.fromkeys(h[2] for h in mentions(source)))
        if not items:
            items = held_items[:]
        if not items:
            return api.fallback()

        target_hits = mentions(destination)
        target_body = target_hits[-1][2] if target_hits else None
        target = None

        if "drawer" in destination:
            target = drawer_region(destination, last_drawer)
            last_drawer = target
        elif target_body:
            side = direction(destination)
            inside = (
                separator in (" into ", " inside ", " in ")
                or "compartment" in destination
            )
            outside = any(
                phrase in clause
                for phrase in ("next to", "to the left of", "to the right of",
                               "in front of", "behind", "beside")
            )
            if side and ("caddy" in target_body or outside):
                target = api.relative_target(
                    target_body, side, "outside" if outside else "inside"
                )
            elif "cabinet" in target_body and (
                "top" in destination or separator in (" on ", " onto ")
            ):
                target = region(target_body, "top_side")
            elif side and "plate" in target_body:
                markers = [
                    n for n in names if "plate_" + side + "_region" in n
                ]
                plates = [b for b in bodies if "plate" in b]
                if markers:
                    target = api.nearest(markers[0], plates)
            if target is None:
                if inside:
                    target = region(target_body, "contain_region")
                elif "stove" in target_body:
                    target = region(target_body, "cook_region")
                target = target or target_body
        elif any(w in destination.split() for w in ("it", "there", "them")):
            target = last_target

        if target is None:
            return api.fallback()
        for item in items:
            if item == target_body:
                continue
            grasp = (
                "thin_edge" if "book" in item
                else "rim" if "bowl" in item
                else "standard"
            )
            plan.append(("place", item, target, grasp))
        held_items = items
        last_target = target

    if not plan:
        return api.fallback()

    for operation in plan:
        if operation[0] == "drawer":
            api.drawer(operation[1], operation[2])
        else:
            result = api.place_with(
                operation[1], operation[2], operation[3]
            )
            if result is False:
                return
