def run(api):
    import numpy as np

    text = api.instruction.lower().replace("-", " ")
    for mark in ",.;:!?":
        text = text.replace(mark, " ")
    text = " ".join(text.split())
    names = list(api.names())
    bodies = [
        n for n in names
        if n.rsplit("_", 1)[-1].isdigit()
        and "region" not in n and not n.endswith("_side")
    ]

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug"],
        "white yellow mug": [
            "white and yellow mug", "yellow and white mug", "yellow mug", "mug"
        ],
        "red coffee mug": ["red mug", "coffee mug", "mug"],
        "black book": ["black book", "book"],
        "cream cheese": ["cream cheese box"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "desk caddy": ["caddy", "organizer"],
        "white cabinet": ["cabinet"],
        "flat stove": ["stove"],
        "wooden basket": ["basket"],
    }

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        result = [base] + synonyms.get(base, [])
        for word in ("bowl", "plate", "basket", "cabinet", "caddy", "book"):
            if word in base.split():
                result.append(word)
        return list(set(result))

    def mentions(fragment):
        padded = " " + fragment + " "
        hits = []
        for body in bodies:
            for alias in aliases(body):
                needle = " " + alias + " "
                start = 0
                while True:
                    at = padded.find(needle, start)
                    if at < 0:
                        break
                    hits.append((at, at + len(needle) - 1, body))
                    start = at + 1
        # Specific names take precedence over overlapping generic aliases.
        hits = [
            h for h in hits
            if not any(
                q[0] <= h[0] and q[1] >= h[1]
                and q[1] - q[0] > h[1] - h[0]
                for q in hits
            )
        ]
        return sorted(set(hits))

    def resolve(fragment, exclude=()):
        hits = [h for h in mentions(fragment) if h[2] not in exclude]
        if not hits:
            return None
        longest = max(b - a for a, b, n in hits)
        candidates = list(dict.fromkeys(
            n for a, b, n in hits if b - a == longest
        ))
        if len(candidates) == 1:
            return candidates[0]
        # Resolve identical objects by their named starting locations.
        words = fragment.split()
        for direction in ("left", "right", "front", "back", "middle", "center"):
            if direction not in words:
                continue
            markers = [
                n for n in names
                if "region" in n and direction in n.split("_")
                and any(
                    a.replace(" ", "_") in n
                    for c in candidates for a in aliases(c)
                )
            ]
            if markers:
                marker = min(markers, key=len)
                return api.nearest(marker, candidates)
        return None

    def named_region(body, suffixes):
        for suffix in suffixes:
            exact = body + "_" + suffix
            if exact in names:
                return exact
        return None

    def drawer_region(fragment, previous=None):
        level = next(
            (w for w in ("bottom", "middle", "top")
             if w in fragment.split()), None
        )
        cabinet = resolve(fragment)
        if cabinet is None or "cabinet" not in cabinet:
            cabinets = [b for b in bodies if "cabinet" in b]
            cabinet = cabinets[0] if len(cabinets) == 1 else None
        if level is None and previous is not None:
            return previous
        if cabinet is None:
            return None
        if level is not None:
            return named_region(cabinet, [level + "_region"])
        regions = [
            n for n in names
            if n.startswith(cabinet + "_")
            and any(n.endswith("_" + x + "_region")
                    for x in ("top", "middle", "bottom"))
        ]
        return regions[0] if len(regions) == 1 else None

    def destination(fragment, previous_drawer):
        if "drawer" in fragment:
            return drawer_region(fragment, previous_drawer)
        if fragment.strip() in ("it", "in it", "into it", "inside it"):
            return previous_drawer

        reference = resolve(fragment)
        if reference is None:
            return None
        words = fragment.split()
        direction = next(
            (d for d in ("left", "right", "front", "back") if d in words),
            None
        )
        outside = (
            "next to" in fragment or "beside" in fragment
            or "to the left of" in fragment or "to the right of" in fragment
            or "in front of" in fragment or "behind" in fragment
        )
        if "behind" in fragment:
            direction = "back"
        inside = any(w in words for w in ("in", "into", "inside", "within"))
        if direction and outside:
            return api.relative_target(reference, direction, "outside")
        if direction and (
            inside or "compartment" in words or "caddy" in reference
        ):
            return api.relative_target(reference, direction, "inside")
        if "cabinet" in reference:
            if "top" in words or "on" in words or "onto" in words:
                return named_region(reference, ["top_side"])
        if "stove" in reference:
            return named_region(reference, ["cook_region"]) or reference
        if inside or "basket" in reference:
            return named_region(reference, ["contain_region"]) or reference
        return reference

    # Parse the whole plan before performing any physical action.
    words = text.split()
    verbs = {
        "put", "place", "stack", "move", "insert", "set",
        "open", "close", "shut"
    }
    starts = [i for i, w in enumerate(words) if w in verbs]
    if not starts or any(
        phrase in text for phrase in
        ("turn on", "turn off", "switch on", "switch off", "pour ", "push ")
    ):
        return api.fallback()

    plan = []
    last_drawer = None
    last_items = []
    for index, start in enumerate(starts):
        end = starts[index + 1] if index + 1 < len(starts) else len(words)
        verb = words[start]
        fragment = " ".join(words[start + 1:end]).strip()
        while fragment.endswith((" and", " then")):
            fragment = fragment.rsplit(" ", 1)[0]

        if verb in ("open", "close", "shut"):
            region = drawer_region(fragment, last_drawer)
            if region is None:
                return api.fallback()
            plan.append(("drawer", region, "open" if verb == "open" else "close"))
            last_drawer = region
            continue

        tokens = fragment.split()
        separators = [
            i for i, w in enumerate(tokens)
            if w in ("on", "onto", "in", "into", "inside", "to", "beside")
        ]
        if not separators:
            return api.fallback()

        parsed = None
        # Trying later boundaries also supports descriptions such as
        # "the bowl on the table into the basket".
        for boundary in reversed(separators):
            source = " ".join(tokens[:boundary])
            target_text = " ".join(tokens[boundary:])
            hits = mentions(source)
            items = []
            ambiguous = False
            spans = sorted(set((a, b) for a, b, n in hits))
            for a, b in spans:
                choices = list(dict.fromkeys(
                    n for x, y, n in hits if x == a and y == b
                ))
                item = choices[0] if len(choices) == 1 else resolve(source)
                if item is None:
                    ambiguous = True
                    break
                if item not in items:
                    items.append(item)
            if not items and source.strip() in ("it", "them"):
                items = list(last_items)
            if ambiguous or not items:
                continue
            target = destination(target_text, last_drawer)
            if target is None or target in items:
                continue
            parsed = (items, target)
            break

        if parsed is None:
            return api.fallback()
        items, target = parsed
        for item in items:
            grasp = (
                "rim" if "bowl" in item
                else "thin_edge" if "book" in item
                else "standard"
            )
            plan.append(("place", item, target, grasp))
        last_items = items

    for action in plan:
        if action[0] == "drawer":
            api.drawer(action[1], action[2])
        else:
            api.place_with(action[1], action[2], action[3])
