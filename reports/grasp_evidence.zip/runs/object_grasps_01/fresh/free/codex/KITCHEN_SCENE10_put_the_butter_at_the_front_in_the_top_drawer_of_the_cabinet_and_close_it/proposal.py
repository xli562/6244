def run(api):
    import numpy as np

    text = " ".join(
        api.instruction.lower().replace("-", " ").replace(",", " ").split()
    )
    names = list(api.names())
    bodies = [
        n for n in names
        if n.rsplit("_", 1)[-1].isdigit()
        and "region" not in n
        and not n.endswith("_side")
    ]

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug"
        ],
        "red coffee mug": ["red mug", "coffee mug"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "cream cheese": ["cream cheese box"],
        "black book": ["book"],
        "desk caddy": ["caddy"],
        "flat stove": ["stove"],
        "wooden cabinet": ["cabinet"],
        "white cabinet": ["cabinet"],
    }

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        return [base] + synonyms.get(base, [])

    def score(name, phrase):
        padded = " " + phrase + " "
        return max(
            [len(a) for a in aliases(name) if " " + a + " " in padded] or [0]
        )

    def matches(phrase, pool=None):
        pool = bodies if pool is None else pool
        scored = [(score(n, phrase), n) for n in pool]
        best = max([s for s, n in scored] or [0])
        return [n for s, n in scored if s == best and s > 0]

    def region(body, suffix):
        exact = body + "_" + suffix
        return exact if exact in names else None

    def resolve(phrase, pool=None):
        candidates = matches(phrase, pool)
        if len(candidates) == 1:
            return candidates[0]
        if not candidates:
            return None

        # Resolve descriptions such as "the butter at the front" against
        # the named initial locations, rather than object instance numbers.
        directions = [
            d for d in ("left", "right", "front", "back")
            if d in phrase.split()
        ]
        stems = {n.rsplit("_", 1)[0] for n in candidates}
        markers = [
            n for n in names
            if "region" in n
            and any(d in n.split("_") for d in directions)
            and any(
                stem in n or any(
                    a.replace(" ", "_") in n for a in aliases(candidate)
                )
                for stem in stems for candidate in candidates
            )
        ]
        initial = [n for n in markers if "init" in n]
        markers = initial or markers
        if len(markers) == 1:
            return api.nearest(markers[0], candidates)
        if markers:
            marker = max(
                markers,
                key=lambda n: sum(w in n.split("_") for w in phrase.split())
            )
            return api.nearest(marker, candidates)
        return None

    def selected_items(phrase):
        selected = []
        # Longer aliases suppress generic aliases contained inside them.
        words = phrase.split()
        hits = []
        for body in bodies:
            for alias in aliases(body):
                aw = alias.split()
                for i in range(len(words) - len(aw) + 1):
                    if words[i:i + len(aw)] == aw:
                        hits.append((i, i + len(aw), body))
        hits = [
            h for h in hits
            if not any(
                other[0] <= h[0] and other[1] >= h[1]
                and other[1] - other[0] > h[1] - h[0]
                for other in hits
            )
        ]
        spans = sorted(set((a, b) for a, b, _ in hits))
        for index, (a, b) in enumerate(spans):
            pool = list(dict.fromkeys(
                n for x, y, n in hits if x == a and y == b
            ))
            end = spans[index + 1][0] if index + 1 < len(spans) else len(words)
            description = " ".join(words[a:end])
            item = resolve(description, pool)
            if item is None:
                return None
            if item not in selected:
                selected.append(item)
        return selected

    # Parse the complete plan before moving, so unsupported instructions
    # can use the previous policy without partially executing a new plan.
    verbs = {"put", "place", "move", "pick", "open", "close", "shut"}
    words = text.split()
    starts = [i for i, w in enumerate(words) if w in verbs]
    if not starts:
        return api.fallback()

    clauses = []
    for k, start in enumerate(starts):
        end = starts[k + 1] if k + 1 < len(starts) else len(words)
        clause = words[start:end]
        while clause and clause[-1] in ("and", "then"):
            clause.pop()
        clauses.append(" ".join(clause))

    plan = []
    last_drawer = None
    last_target = None
    last_items = []
    drawer_state = {}

    for clause in clauses:
        verb = clause.split()[0]
        if verb == "pick":
            # "Pick up X and place it ..." is handled by the placement skill.
            last_items = selected_items(clause)
            if not last_items:
                return api.fallback()
            continue

        drawer = None
        if "drawer" in clause:
            cabinet = resolve(
                clause, [n for n in bodies if "cabinet" in n]
            )
            if cabinet is None:
                cabinets = [n for n in bodies if "cabinet" in n]
                cabinet = cabinets[0] if len(cabinets) == 1 else None
            level = next(
                (s for s in ("top", "middle", "bottom")
                 if s in clause.split()), None
            )
            drawer = region(cabinet, level + "_region") if cabinet and level else last_drawer
            if drawer is None:
                return api.fallback()
            last_drawer = drawer

        if verb in ("open", "close", "shut"):
            drawer = drawer or (
                last_drawer if "it" in clause.split() else None
            )
            if drawer is None:
                return api.fallback()
            operation = "open" if verb == "open" else "close"
            plan.append(("drawer", drawer, operation))
            drawer_state[drawer] = operation
            continue

        if drawer:
            # Everything before the insertion preposition describes the
            # source: "butter at the front" is distinct from "top drawer".
            cuts = [
                clause.find(p) for p in (" into ", " inside ", " in ")
                if clause.find(p) >= 0
            ]
            if not cuts:
                return api.fallback()
            source = clause[:min(cuts)]
            target = drawer
        else:
            cuts = []
            for prep in (" onto ", " into ", " inside ", " on ", " in ", " to "):
                start = 0
                while True:
                    p = clause.find(prep, start)
                    if p < 0:
                        break
                    # "in front of" expresses a spatial relationship.
                    if not clause[p:].startswith(" in front of "):
                        cuts.append((p, prep))
                    start = p + len(prep)
            if not cuts:
                return api.fallback()
            p, prep = min(cuts)
            source, destination = clause[:p], clause[p + len(prep):]
            reference = resolve(destination)
            if reference is None and destination.strip() in ("it", "there"):
                target = last_target
            elif reference is None:
                return api.fallback()
            else:
                directions = [
                    d for d in ("left", "right", "front", "back")
                    if d in destination.split()
                ]
                if directions:
                    outside = any(s in destination for s in (
                        "next to", "of the", "of ", "beside"
                    ))
                    relation = (
                        "outside" if outside or prep in (" on ", " to ", " onto ")
                        else "inside"
                    )
                    target = api.relative_target(reference, directions[0], relation)
                elif "cabinet" in reference and (
                    "top" in destination.split() or prep in (" on ", " onto ")
                ):
                    target = region(reference, "top_side")
                elif "stove" in reference:
                    target = region(reference, "cook_region") or reference
                elif prep in (" in ", " into ", " inside "):
                    target = region(reference, "contain_region") or reference
                else:
                    target = reference

        if target is None:
            return api.fallback()
        items = selected_items(source)
        if not items and any(w in source.split() for w in ("it", "them")):
            items = last_items
        if not items:
            return api.fallback()

        if drawer and drawer_state.get(drawer) != "open":
            plan.append(("drawer", drawer, "open"))
            drawer_state[drawer] = "open"
        for item in items:
            if item == target:
                return api.fallback()
            plan.append(("place", item, target))
        last_items = items
        last_target = target

    for action, first, second in plan:
        if action == "drawer":
            api.drawer(first, second)
        else:
            grasp = (
                "rim" if "bowl" in first else
                "thin_edge" if "book" in first else
                "standard"
            )
            api.place_with(first, second, grasp)
