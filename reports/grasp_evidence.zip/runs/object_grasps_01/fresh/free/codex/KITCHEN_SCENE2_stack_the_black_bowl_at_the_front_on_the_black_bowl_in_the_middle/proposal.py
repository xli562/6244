def run(api):
    import numpy as np

    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    mappings = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug"],
        "white yellow mug": ["yellow and white mug", "white and yellow mug",
                             "yellow mug", "mug"],
        "red coffee mug": ["red coffee mug", "red mug", "mug"],
        "black book": ["black book", "book"],
        "cream cheese": ["cream cheese box", "cream cheese"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "desk caddy": ["desk caddy", "caddy"],
        "flat stove": ["stove"],
        "wooden cabinet": ["wooden cabinet", "cabinet"],
        "white cabinet": ["white cabinet", "cabinet"],
    }

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        return [base] + mappings.get(base, [])

    def contains(phrase, part):
        return " " + phrase + " " in " " + part + " "

    def score(name, part):
        return max(
            [len(a) for a in aliases(name) if contains(a, part)] or [0]
        )

    def position(name):
        return np.asarray(api.pos(name), dtype=float)

    def direction(part):
        return next(
            (s for s in ("left", "right", "front", "back", "middle", "center")
             if contains(s, part)), None
        )

    def resolve(part, excluded=()):
        candidates = [n for n in bodies if n not in excluded]
        best = max([score(n, part) for n in candidates] or [0])
        if not best:
            return None
        candidates = [n for n in candidates if score(n, part) == best]
        if len(candidates) == 1:
            return candidates[0]

        side = direction(part)
        if side:
            base = candidates[0].rsplit("_", 1)[0]
            markers = [
                n for n in names
                if "region" in n
                and ("_" + side + "_") in n
                and (base in n or any(
                    a.replace(" ", "_") in n
                    for a in aliases(candidates[0])
                ))
            ]
            if markers:
                markers.sort(key=lambda n: ("init_region" not in n, len(n)))
                return api.nearest(markers[0], candidates)

        # A numbered object can also be specified explicitly.
        for n in candidates:
            if contains(n.replace("_", " "), part):
                return n
        return None

    def drawer_region(part):
        cabinets = [n for n in bodies if "cabinet" in n]
        if not cabinets:
            return None
        cabinet = resolve(part)
        if cabinet not in cabinets:
            if len(cabinets) != 1:
                return None
            cabinet = cabinets[0]
        levels = [s for s in ("top", "middle", "bottom") if contains(s, part)]
        if not levels:
            levels = [s for s in ("top", "middle", "bottom") if contains(s, text)]
        if len(levels) != 1:
            return None
        region = cabinet + "_" + levels[0] + "_region"
        return region if region in names else None

    def target_for(part, relation, previous_target=None):
        if "drawer" in part:
            return drawer_region(part)
        body = resolve(part)
        if body is None:
            if part.strip(" .,") in ("it", "them", "there"):
                return previous_target
            return None

        side = direction(part)
        if side in ("left", "right", "front", "back"):
            # Object qualifiers, such as "the front bowl", are handled by
            # resolve(). Fixture-relative destinations use observed regions.
            fixture = any(w in body for w in (
                "caddy", "cabinet", "table", "desk", "shelf", "rack"
            ))
            if fixture:
                inside = relation in ("in", "into", "inside", "inside of")
                return api.relative_target(
                    body, side, "inside" if inside else "outside"
                )

        if "cabinet" in body and relation in ("on", "onto", "on top of"):
            region = body + "_top_side"
            return region if region in names else None
        if relation in ("in", "into", "inside", "inside of"):
            region = body + "_contain_region"
            return region if region in names else body
        if "stove" in body:
            region = body + "_cook_region"
            return region if region in names else body
        return body

    def grasp(item):
        if "bowl" in item:
            return "rim"
        if "book" in item:
            return "thin_edge"
        return "standard"

    # Plan every clause before taking action so an unsupported instruction can
    # be handed to the previous policy without repeating completed actions.
    verbs = ("put", "place", "stack", "move", "open", "close",
             "turn", "pick", "push", "pull")
    words = text.replace(",", " , ").replace(".", " . ").split()
    starts = [
        i for i, word in enumerate(words)
        if word in verbs and (
            i == 0 or words[i - 1] in ("and", "then", ",", ".", "please")
            or (i > 1 and words[i - 2:i] == ["and", "then"])
        )
    ]
    if not starts:
        return api.fallback()

    clauses = []
    for k, start in enumerate(starts):
        end = starts[k + 1] if k + 1 < len(starts) else len(words)
        chunk = words[start:end]
        while chunk and chunk[-1] in ("and", "then", ",", "."):
            chunk.pop()
        clauses.append(" ".join(chunk))

    plans = []
    previous_target = None
    previous_items = []
    previous_drawer = None

    for clause in clauses:
        verb = clause.split()[0]
        if verb in ("open", "close"):
            region = drawer_region(clause)
            if region is None and any(
                contains(p, clause) for p in ("it", "drawer")
            ):
                region = previous_drawer
            if region is None:
                return api.fallback()
            plans.append(("drawer", region, verb))
            previous_drawer = region
            continue

        if verb not in ("put", "place", "stack", "move"):
            return api.fallback()

        remainder = clause[len(verb):].strip()
        relations = (
            "on top of", "to the left of", "to the right of",
            "in front of", "at the back of", "next to",
            "inside of", "into", "inside", "onto", "on", "in",
        )
        splits = []
        for relation in relations:
            token = " " + relation + " "
            index = remainder.find(token)
            if index >= 0:
                splits.append((index, -len(relation), relation))
        if not splits:
            return api.fallback()
        index, _, relation = min(splits)
        source = remainder[:index]
        destination = remainder[index + len(relation) + 2:]

        if relation in (
            "to the left of", "to the right of",
            "in front of", "at the back of",
        ):
            destination = relation + " " + destination

        target = target_for(destination, relation, previous_target)
        if target is None:
            return api.fallback()

        items = []
        if source.strip() in ("it", "them", "both"):
            items = previous_items[:]
        else:
            for part in source.replace(" , ", " and ").split(" and "):
                item = resolve(part)
                if item is None:
                    return api.fallback()
                if item not in items:
                    items.append(item)

        if not items or target in items:
            return api.fallback()
        for item in items:
            plans.append(("place", item, target))
        previous_items = items
        previous_target = target
        if "drawer" in destination:
            previous_drawer = target

    for kind, first, second in plans:
        if kind == "drawer":
            api.drawer(first, second)
        else:
            api.place_with(first, second, grasp(first))
            # The skill handles grasp retries; stop if the object is still
            # clearly away from its destination rather than disturbing it.
            p, q = position(first), position(second)
            if np.linalg.norm(p[:2] - q[:2]) > 0.18:
                return
