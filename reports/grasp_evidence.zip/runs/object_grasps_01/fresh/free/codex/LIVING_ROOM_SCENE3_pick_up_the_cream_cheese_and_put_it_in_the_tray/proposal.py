def run(api):
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [
        n for n in names
        if n.rsplit("_", 1)[-1].isdigit()
        and "region" not in n
    ]

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug"
        ],
        "red coffee mug": ["red coffee mug", "red mug"],
        "cream cheese": ["cream cheese", "cream cheese box"],
        "black book": ["black book", "book"],
        "desk caddy": ["desk caddy", "caddy"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["stove"],
        "white cabinet": ["cabinet"],
        "wooden tray": ["wooden tray", "tray"],
        "woven basket": ["woven basket", "basket"],
    }

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        result = [base] + synonyms.get(base, [])
        for noun in ("bowl", "plate", "basket", "tray", "cabinet", "caddy"):
            if noun in base.split():
                result.append(noun)
        return sorted(set(result), key=len, reverse=True)

    def mentions(sentence):
        padded = " " + sentence + " "
        hits = []
        for body in bodies:
            for alias in aliases(body):
                needle = " " + alias + " "
                start = padded.find(needle)
                while start >= 0:
                    hits.append((start, start + len(needle) - 1, body, alias))
                    start = padded.find(needle, start + 1)
        # A specific name takes precedence over overlapping generic aliases.
        selected = []
        for hit in sorted(hits, key=lambda h: -(h[1] - h[0])):
            if not any(hit[0] < old[1] and old[0] < hit[1]
                       for old in selected):
                selected.append(hit)
        return sorted(selected)

    def region(body, suffix):
        exact = body + "_" + suffix
        if exact in names:
            return exact
        return next(
            (n for n in names
             if n.startswith(body + "_") and n.endswith(suffix)),
            None,
        )

    def drawer_region(sentence):
        level = next(
            (v for v in ("bottom", "middle", "top") if v in sentence),
            None,
        )
        candidates = [
            n for n in names
            if "region" in n
            and ("drawer" in n or "cabinet" in n)
            and any("_" + v + "_" in n for v in ("top", "middle", "bottom"))
        ]
        if level:
            candidates = [n for n in candidates if "_" + level + "_" in n]
        return candidates[0] if len(candidates) == 1 else None

    def target_for(body, sentence):
        direction = next(
            (d for d in ("left", "right", "front", "back")
             if d in sentence.split()),
            None,
        )
        outside = any(p in sentence for p in (
            "next to", "beside", "to the left of", "to the right of",
            "in front of", "behind",
        ))
        if "behind" in sentence:
            direction = "back"
        if direction and (
            outside or "caddy" in body or "compartment" in sentence
        ):
            return api.relative_target(
                body, direction, "outside" if outside else "inside"
            )

        if direction and ("plate" in body or "bowl" in body):
            kind = "plate" if "plate" in body else "bowl"
            markers = [
                n for n in names
                if kind + "_" + direction + "_region" in n
            ]
            candidates = [n for n in bodies if kind in n]
            if markers and candidates:
                return api.nearest(markers[0], candidates)

        if "cabinet" in body and (
            "on top" in sentence or "top of" in sentence
        ):
            return region(body, "top_side") or body
        if "stove" in body:
            return region(body, "cook_region") or body
        if any(p in sentence for p in (" in ", " into ", " inside ")):
            return region(body, "contain_region") or body
        if "tray" in body or "basket" in body:
            return region(body, "contain_region") or body
        return body

    # Leave unsupported manipulation to the existing physical policy.
    if any(p in text for p in (
        "turn on", "turn off", "switch on", "switch off", "push ",
        "rotate ", "pour ",
    )):
        return api.fallback()

    # Split actions without splitting coordinated object names.
    clauses = text
    for verb in (
        "pick up", "put", "place", "move", "open", "close", "take",
    ):
        for prefix in (" and then ", " then ", " and ", ", "):
            clauses = clauses.replace(prefix + verb + " ", "|" + verb + " ")
    clauses = clauses.replace(";", "|")
    clauses = [c.strip(" ,.").replace("then ", "", 1)
               if c.strip().startswith("then ") else c.strip(" ,.")
               for c in clauses.split("|")]

    plan = []
    pending = []
    last_drawer = None

    for clause in clauses:
        if not clause:
            continue
        hits = mentions(clause)
        objects = list(dict.fromkeys(h[2] for h in hits))

        if clause.startswith(("open ", "close ", "shut ")):
            if "drawer" not in clause and last_drawer is None:
                return api.fallback()
            drawer = drawer_region(clause) or last_drawer
            if drawer is None:
                return api.fallback()
            operation = "open" if clause.startswith("open ") else "close"
            plan.append(("drawer", drawer, operation))
            last_drawer = drawer
            continue

        placement = any(w in clause for w in (
            "put ", "place ", "move ", " into ", " onto ", " inside ",
        ))
        if not placement:
            if clause.startswith(("pick up ", "take ", "grab ")):
                pending = objects
                continue
            return api.fallback()

        if "drawer" in clause:
            target = drawer_region(clause) or last_drawer
            if target is None:
                return api.fallback()
            items = [n for n in objects if "cabinet" not in n]
            last_drawer = target
        else:
            if not objects:
                return api.fallback()
            target_body = hits[-1][2]
            target_start = max(h[0] for h in hits if h[2] == target_body)
            target_phrase = clause[max(0, target_start - 45):]
            target = target_for(target_body, target_phrase)
            items = [n for n in objects if n != target_body]

        if not items:
            items = pending
        if not items or target is None:
            return api.fallback()

        for item in items:
            grasp = (
                "rim" if "bowl" in item else
                "thin_edge" if "book" in item else
                "standard"
            )
            plan.append(("place", item, target, grasp))
        pending = []

    if not plan or pending:
        return api.fallback()

    for action in plan:
        if action[0] == "drawer":
            result = api.drawer(action[1], action[2])
        else:
            result = api.place_with(action[1], action[2], action[3])
        if result is False:
            return
