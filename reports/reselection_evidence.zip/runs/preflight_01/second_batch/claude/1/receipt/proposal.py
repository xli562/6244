import numpy as np

def run(api):
    cat = api.catalog(); N = list(cat); P = lambda n: np.asarray(api.pos(n), float)
    AL = {'porcelain': 'white', 'frypan': 'pan frying skillet', 'cabinet': 'drawer', 'microwave': 'oven',
          'stove': 'burner cooktop', 'refrigerator': 'fridge'}
    LV, THIN = {'top', 'middle', 'bottom', 'left', 'right', 'front', 'back'}, {'book', 'plate', 'board', 'tray', 'knife', 'spatula'}
    VB = {'put', 'place', 'pick', 'open', 'close', 'shut', 'turn', 'switch', 'push', 'slide', 'move', 'stack', 'set', 'grab', 'take', 'lift'}
    REL = (' between ', ' next to ', ' beside ', ' near ', ' on ', ' inside ', ' in ', ' from ', ' at ')
    DP = (' into ', ' onto ', ' inside ', ' in ', ' on ', ' to ', ' next to ', ' beside ', ' over ')
    S = {'last': None, 'pend': [], 'done': set(), 'opened': set()}
    tk = lambda n: [t for t in n.split('_') if not t.isdigit()]
    V = lambda a, z: [float(a[0]), float(a[1]), z]
    def W(s):
        o = []
        for x in s.split(): o += [x, x[:-1]] if x.endswith('s') and len(x) > 3 else [x]
        return o
    def ents(ws, kinds=('item', 'fixture')):
        sc = {}
        for n in N:
            m = [t in ws or any(a in ws for a in AL.get(t, '').split()) for t in tk(n)]
            if cat[n]['kind'] in kinds and any(m): sc[n] = sum(m) - 0.25 * (len(m) - sum(m))
        b = max(sc.values(), default=0)
        return [n for n in sc if sc[n] == b and b > 0]
    D = {'front': np.array([-1., 0]), 'back': np.array([1., 0]), 'left': np.array([0, 1.]), 'right': np.array([0, -1.])}
    for a, b in (('left', 'right'), ('front', 'back')):          # calibrate directions from paired region names
        for n in N:
            m = n.replace(a, b)
            if a in tk(n) and m in cat and m != n and np.linalg.norm((P(n) - P(m))[:2]) > 0.02:
                v = (P(n) - P(m))[:2]; D[a] = v / np.linalg.norm(v); D[b] = -D[a]
    def root(n):
        while n and cat[n]['kind'] == 'region':
            q = cat[n]['parent'] if cat[n]['parent'] in cat else next((m for m in N if cat[m]['kind'] != 'region' and n.startswith(m + '_')), None)
            if not q: break
            n = q
        return n
    def srel(s):
        s = ' ' + s + ' '; h = [(s.find(r), r) for r in REL if r in s]
        if not h: return s.strip(), '', ''
        i, r = min(h); return s[:i].strip(), r.split()[0], s[i + len(r):].strip()
    def sel(h, r, rest, cs):
        hw, rw = W(h), W(rest); ds = [d for d in D if d in hw + rw]
        if len(cs) < 2: return cs, True
        if ds: k = lambda n: -float(P(n)[:2] @ D[ds[0]])
        elif {'middle', 'center', 'centre'} & set(hw + rw):
            c = np.mean([P(n) for n in (N if 'table' in rw else cs)], 0); k = lambda n: np.linalg.norm((P(n) - c)[:2])
        elif rest:
            refs = [x for x in [tgt(y, r) for y in (rest.split(' and ') if r == 'between' else [rest])] if x]
            if not refs: return cs, False
            c = np.mean([P(x) for x in refs], 0); k = lambda n: np.linalg.norm(P(n) - c) - 9 * (cat[n]['parent'] in refs)
        else: return cs, False
        return sorted(cs, key=k), True
    def tgt(s, prep, drawer=False, excl=()):
        ws = W(s); h, r, rest = srel(s)
        if 'it' in ws or not ws:
            base = root(S['last']); ws += [t for t in tk(S['last'] or '') if t in LV]
        else:
            cs = [n for n in sel(h, r, rest, ents(W(h)))[0] if n not in excl]; base = cs[0] if cs else None
        if not base: return None
        if prep in ('to', 'next', 'beside') and LV & set(ws):
            for n in N:
                if cat[n]['kind'] == 'region' and not n.startswith(base) and set(ws) & set(tk(n)) & set(D) and set(tk(base)) & set(tk(n)) - {'region', 'side'}: return n
        w2 = ws + ['region'] * bool({'drawer', 'compartment'} & set(ws)) + ['side'] * ('top' in ws and 'drawer' not in ws)
        G = set() if drawer else {'contain', 'cook', 'heating'} | ({'top', 'side'} if prep in ('on', 'onto') else set())
        best, bs = base, 0
        for n in N:
            if cat[n]['kind'] == 'region' and (cat[n]['parent'] == base or n.startswith(base + '_')):
                sc = sum(2 if t in w2 else t in G for t in tk(n) if t not in tk(base))
                if sc > bs: best, bs = n, sc
        return best
    def items(src, t):
        ws = W(src)
        if 'it' in ws or 'them' in ws: return list(S['pend'])
        both = bool({'both', 'two'} & set(ws)); parts = [src] if 'between' in ws else src.replace('both ', '').split(' and the ')
        out = []
        for p in parts:
            h, r, rest = srel(p); cs, ok = sel(h, r, rest, ents(W(h), ('item',)))
            cs = [n for n in cs if n not in out and n != t]
            if not ok and t: cs.sort(key=lambda n: (n in S['done'], -np.linalg.norm((P(n) - P(t))[:2])))
            out += cs[:2] if both and len(parts) == 1 else cs[:1]
        return out
    def closed_drawer(t):
        b, L = root(t), {'top', 'middle', 'bottom'}
        sib = [n for n in N if cat[n]['kind'] == 'region' and root(n) == b != n and L & set(tk(n)) and 'side' not in tk(n)]
        if t not in sib or len(sib) < 2 or t in S['opened']: return False
        d = lambda n: np.linalg.norm((P(n) - P(b))[:2])
        return d(t) <= min(map(d, sib)) + 0.04
    def act(step):
        return (api.act(step) or {}) if api.remaining() > 0 else {}
    def place(it, t):
        g = ['standard', 'thin_edge', 'rim'] if THIN & set(tk(it)) else ['standard', 'rim', 'thin_edge']
        for k in range(2):
            r = act({'op': 'place', 'item': it, 'target': t, 'grasps': g[k:] + g[:k]})
            if not r or (r.get('executed') and (r.get('max_lift') is None or r['max_lift'] > 0.02)): return
    txt = ' '.join(api.instruction.lower().replace(',', ' and ').replace('.', ' ').replace(' then ', ' and ').split())
    cl = []
    for g in txt.replace(' and and ', ' and ').split(' and '):
        g = g.strip()
        if g and cl and g.split()[0] not in VB: cl[-1] += ' and ' + g
        elif g: cl.append(g)
    for c in cl:
        w = c.split(); v = w[0]; body = ' '.join(w[1:])
        body = body[3:] if body.startswith('up ') else body
        body = body[:-3] if body.endswith(' up') else body
        if v in ('open', 'close', 'shut'):
            t = tgt(body, 'in', True)
            if t: act({'op': 'open' if v == 'open' else 'close', 'target': t}); S['last'] = t; (S['opened'].add if v == 'open' else S['opened'].discard)(t)
        elif v in ('turn', 'switch'):
            b = (ents(W(body), ('fixture',)) or [None])[0]
            if b: act({'op': 'stroke', 'target': b, 'offset': V(D['front'] * 0.1, 0.02), 'delta': V(D['right' if 'off' not in w else 'left'] * 0.06, 0.0)}); S['last'] = b
        elif v in ('push', 'slide', 'shove'):
            src, _, dst = (' ' + body + ' ').partition(' to ')
            it = (items(src, None) or [None])[0]; dw = W(dst); ds = [d for d in D if d in dw]
            if not it or not ds: continue
            b = tgt(dst, 'to') if set(dw) - set(D) - {'the', 'of', 'side'} else None
            goal = P(b)[:2] if b and ds[0] in tk(b) else (P(b) if b else P(it))[:2] + D[ds[0]] * 0.15
            for _ in range(4):
                d = goal - P(it)[:2]; n = np.linalg.norm(d)
                if n < 0.03 or not act({'op': 'stroke', 'target': it, 'offset': V(-d / n * 0.1, 0.02), 'delta': V(d / n * min(n, 0.3), 0.0)}): break
            S['last'], S['pend'] = it, [it]
        else:
            s = ' ' + body + ' '; h = [(s.find(p), p) for p in DP if p in s and v not in ('pick', 'grab', 'take', 'lift')]
            if not h: S['pend'] = items(body, None); continue
            i, p = min(h); src, dst, p = s[:i], s[i + len(p):].strip(), p.split()[0]
            t = tgt(dst, p); its = items(src, t)
            if t in its: t = tgt(dst, p, excl=its); its = items(src, t)
            for it in its:
                if t and it != t:
                    if p in ('in', 'inside', 'into') and closed_drawer(t): act({'op': 'open', 'target': t}); S['opened'].add(t)
                    place(it, t); S['done'].add(it)
            S['last'], S['pend'] = t or S['last'], its
