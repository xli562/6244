import numpy as np

SYN = {'compartment': 'contain', 'inside': 'contain', 'white': 'porcelain', 'pot': 'moka', 'burner': 'cook',
       'cup': 'mug', 'pan': 'frypan', 'skillet': 'frypan', 'shelf': 'rack', 'drawer': 'region', 'stovetop': 'stove'}
SP = {'left', 'right', 'front', 'back', 'top', 'bottom', 'middle'}
AX = {'left': ('y', 'max'), 'right': ('y', 'min'), 'front': ('x', 'min'), 'back': ('x', 'max'),
      'top': ('z', 'max'), 'bottom': ('z', 'min'), 'middle': ('z', 'median')}
VERBS = {'put', 'place', 'pick', 'close', 'open', 'shut', 'turn', 'switch', 'push', 'move', 'set', 'stack',
         'then', 'take', 'grab', 'slide'}
PREPS = [' on top of ', ' into ', ' onto ', ' inside ', ' in ', ' on ', ' to ', ' at ']
DIRS = {'left': [0, .15, 0], 'right': [0, -.15, 0], 'forward': [.15, 0, 0], 'backward': [-.15, 0, 0]}
THIN, RIM = {'book', 'board', 'card'}, {'bowl', 'plate'}


def run(api):
    cat = api.catalog(); names = list(cat)
    T = lambda n: [t for t in n.lower().split('_') if t.isalpha()]
    vocab = set(t for n in names for t in T(n))
    P = lambda n: np.array(api.pos(n), dtype=float)

    def words(ph):
        out = []
        for w in ph.lower().split():
            for v in (w, w.rstrip('s'), SYN.get(w), SYN.get(w.rstrip('s'))):
                if v and v in vocab and v not in out: out.append(v)
        return out

    def root(n):
        while cat[n]['parent'] in cat and cat[cat[n]['parent']]['kind'] != 'region' and 'table' not in T(cat[n]['parent']):
            n = cat[n]['parent']
        return n

    def res(ph, role, prev):
        ws = words(ph)
        if prev and any(w in ('it', 'them', 'that') for w in ph.split()):
            if not ws: return prev
            ws += [t for t in T(root(prev[0])) if t not in ws]
        nouns = [w for w in ws if w not in SP]
        kinds = ('item',) if role == 'item' else ('item', 'fixture', 'region')
        excl = {'init', 'region', 'side'} if role == 'item' else {'init'}
        cands = [n for n in names if cat[n]['kind'] in kinds and not excl & set(T(n))]
        if not nouns or not cands: return None
        sc = lambda n: 3 * sum(w in T(n) for w in ws) - 0.1 * len(set(T(n)) - set(ws))
        top = max(sc(n) for n in cands)
        if top < 3: return None
        tied = [n for n in cands if sc(n) > top - 0.05]; pick, anc, sel = tied[0], None, {}
        objs = [n for n in cands if cat[n]['kind'] != 'region' and nouns[-1] in T(n)]
        if cat[pick]['kind'] == 'region' and objs and root(pick) not in objs:
            anc, tied = pick, objs                      # location label -> anchor the physical object near it
        left = [s for s in ws if s in SP and s not in T(tied[0])]
        if anc is None and left:
            a = [n for n in names if left[0] in T(n) and set(nouns) & set(T(n)) and cat[n]['kind'] == 'region' and n not in cands]
            if a: anc = a[0]
            elif len(tied) > 1:
                ax, rk = AX[left[0]]; tied = sorted(tied, key=lambda n: P(n)['xyz'.index(ax)])
                pick = {'min': tied[0], 'max': tied[-1], 'median': tied[len(tied) // 2]}[rk]; sel = {'axis': ax, 'rank': rk}
        if anc:
            pick = min(tied, key=lambda n: np.linalg.norm(P(n) - P(anc))); sel = {'near': anc}
        sel.update(kind=cat[pick]['kind'], terms=[w for w in ws if w in T(pick)] or T(pick)[:1])
        if cat[pick]['kind'] == 'region' and cat[pick]['parent'] in cat: sel['parent'] = cat[pick]['parent']
        return pick, sel

    def child(t):
        if cat[t[0]]['kind'] == 'region': return t
        ch = [c for c in names if cat[c]['parent'] == t[0] and 'init' not in T(c)]
        for k in ('contain', 'cook', 'side', 'top'):
            for c in ch:
                if k in T(c):
                    return c, {'kind': cat[c]['kind'], 'terms': [w for w in t[1]['terms'] if w in T(c)] + [k], 'parent': t[0]}
        return t

    def go(st, roles):
        if api.remaining() < 30: return None
        st['expect'] = roles
        p = api.preview(st)
        if isinstance(p, dict):
            for r in roles:
                q = p.get(r)
                if isinstance(q, dict) and q.get('status') == 'corrected' and q.get('resolved') in cat: st[r] = q['resolved']
        return api.act(st)

    cl = []
    for s in (' ' + api.instruction.lower().replace(',', ' and ').replace('.', ' ') + ' ').split(' and '):
        if cl and (s.split() or [''])[0] not in VERBS: cl[-1] += ' and ' + s
        else: cl.append(s)
    prev = held = None; opened = set()
    for c in cl:
        w = [x for x in c.split() if x not in ('then', 'also', 'please', 'first', 'finally')]
        if not w: continue
        v, rest = w[0], ' ' + ' '.join(w[1:]) + ' '
        if v in ('open', 'close', 'shut', 'turn', 'switch'):
            t = res(rest.replace(' on ', ' ').replace(' off ', ' '), 'target', prev)
            if not t: continue
            if v in ('turn', 'switch'): go({'op': 'stroke', 'target': t[0], 'offset': [-.08, .1, .03], 'delta': [0, -.06, 0]}, {'target': t[1]})
            else:
                go({'op': 'open' if v == 'open' else 'close', 'target': t[0]}, {'target': t[1]})
                (opened.add if v == 'open' else opened.discard)(t[0])
            prev = t; continue
        k = min([(rest.find(p), -len(p), p) for p in PREPS if p in rest] or [(-1, 0, '')])
        ip, tp = (rest[:k[0]], rest[k[0] + len(k[2]):]) if k[2] else (rest, '')
        if k[2] == ' on top of ': tp = ' top side ' + tp
        ip = (' ' + ip + ' ').replace(' up ', ' ').replace(' both ', ' ')
        ps = [p for p in ip.split(' and ') if p.strip()]
        if len(ps) > 1 and not all(p.split()[0] in ('the', 'a', 'an') for p in ps[1:]): ps = [ip]
        items = [x for x in (res(p, 'item', held) for p in ps) if x]
        tg = res(tp, 'target', prev) if tp.strip() else None
        if not tg:
            d = [DIRS[x] for x in (tp + ' ' + ip).split() if x in DIRS]
            if items and d and v in ('push', 'move', 'slide'):
                go({'op': 'stroke', 'target': items[0][0], 'offset': [-d[0][0] * .5, -d[0][1] * .5, .02], 'delta': d[0]}, {'target': items[0][1]})
            held = items[-1] if items else held; continue
        tg = child(tg)
        if 'drawer' in tp and cat[tg[0]]['kind'] == 'region' and tg[0] not in opened:
            go({'op': 'open', 'target': tg[0]}, {'target': tg[1]}); opened.add(tg[0])
        for it in items:
            tk = set(T(it[0]))
            g = ['thin_edge', 'standard', 'rim'] if tk & THIN else (['rim', 'standard', 'thin_edge'] if tk & RIM else ['standard', 'rim', 'thin_edge'])
            for i in range(2):
                r = go({'op': 'place', 'item': it[0], 'target': tg[0], 'grasps': g[i:] + g[:i]}, {'item': it[1], 'target': tg[1]})
                ml = r.get('max_lift') if isinstance(r, dict) else None
                if not r or not r.get('executed') or ml is None or ml > .02: break
            held = it
        prev = tg
