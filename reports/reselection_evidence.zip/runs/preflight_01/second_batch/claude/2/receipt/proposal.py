import numpy as np

VERBS = {'put', 'place', 'pick', 'move', 'push', 'slide', 'open', 'close', 'shut', 'turn', 'switch', 'stack', 'set', 'take', 'grab', 'drop'}
PREPS = {'in', 'into', 'inside', 'on', 'onto', 'to', 'at', 'over', 'under', 'toward', 'towards'}
IN, ON = ('in', 'into', 'inside'), ('on', 'onto', 'over')
GEN = {'region', 'contain', 'side', 'init', 'akita', 'chefmate', 'flat'}
ALIAS = {'porcelain': ['porcelain', 'white'], 'frypan': ['frypan', 'pan', 'frying', 'skillet'],
         'contain': ['contain', 'compartment'], 'cook': ['cook', 'burner'], 'region': ['drawer']}
SPACE = {'left': (1, 1), 'right': (1, -1), 'front': (0, -1), 'back': (0, 1), 'top': (2, 1), 'bottom': (2, -1)}
DIRS = {'left': [0, 1, 0], 'right': [0, -1, 0], 'front': [-1, 0, 0], 'forward': [1, 0, 0], 'back': [1, 0, 0], 'backward': [1, 0, 0]}
STOP = {'the', 'a', 'an', 'up', 'both', 'of', 'please'}


def run(api):
    cat = api.catalog()
    toks = lambda n: [t for t in n.split('_') if not t.isdigit()]
    kids = lambda e: [n for n in cat if cat[n]['parent'] == e and 'init' not in n]
    root = lambda n: cat[n]['parent'] if cat[n]['kind'] == 'region' and cat[n]['parent'] in cat else n

    def P(n):
        try:
            return np.array(api.pos(n), float)
        except Exception:
            return np.zeros(3)

    def score(ws, n):  # token overlap, penalise unexplained specific name tokens
        s = 0.0
        for t in toks(n):
            f = ALIAS.get(t, [t])
            if any(w in f or w.rstrip('s') in f for w in ws): s += 1
            elif t not in GEN: s -= 0.3
        return s

    def pick_one(cs, ws, ref):  # disambiguate same-class instances from scene layout
        sp = [w for w in ws if w in SPACE]
        if sp:
            cls = [t for t in toks(cs[0]) if all(t in toks(c) for c in cs)]
            refs = [r for r in cat if r not in cs and cls and sp[0] in toks(r) and all(t in toks(r) for t in cls)]
            if refs: return min(cs, key=lambda c: np.linalg.norm(P(c)[:2] - P(refs[0])[:2]))
            a, sg = SPACE[sp[0]]
            return max(cs, key=lambda c: sg * P(c)[a])
        return max(cs, key=lambda c: np.linalg.norm(P(c)[:2] - ref[:2])) if ref is not None else cs[0]

    def resolve(ws, kinds, ref=None):
        if not [w for w in ws if w not in SPACE and w not in DIRS and w not in ('it', 'them', 'and', ',')]: return None
        cs = [n for n in cat if cat[n]['kind'] in kinds and 'init' not in n and ('table' not in toks(n) or 'table' in ws)]
        sc = {n: score(ws, n) for n in cs}
        if not sc or max(sc.values()) <= 0: return None
        tied = [n for n in cs if sc[n] >= max(sc.values()) - 1e-6]
        roots = list(dict.fromkeys(root(n) if len(tied) > 1 else n for n in tied))
        return roots[0] if len(roots) == 1 else pick_one(roots, ws, ref)

    def refine(e, ws, prep):  # choose the functional sub-region of a fixture/item
        if e is None or cat[e]['kind'] == 'region' or not kids(e): return e
        def kb(n):
            t = toks(n)
            return (sum(w in t for w in ws if w in SPACE) + ('side' in t and 'top' in ws and prep in ON)
                    + .5 * (('contain' in t and prep in IN) or ('cook' in t and prep in ON)) + .2 * (prep in IN and 'region' in t))
        k = max(kids(e), key=kb)
        return k if kb(k) > 0 else e

    def is_drawer(t):
        sib = [toks(n) for n in kids(cat[t]['parent'])]
        return (cat[t]['kind'] == 'region' and 'side' not in toks(t) and any(x in toks(t) for x in ('top', 'middle', 'bottom'))
                and any('bottom' in s for s in sib) and any('top' in s and 'side' not in s for s in sib))

    w = (' ' + api.instruction.lower().replace(',', ' , ').replace('.', ' ').replace(';', ' , ') + ' ')
    w = w.replace(' and then ', ' and ').replace(' then ', ' and ').split()
    clauses, cur = [], []
    for i, x in enumerate(w):
        if x in ('and', ',') and i + 1 < len(w) and w[i + 1] in VERBS and cur: clauses.append(cur); cur = []
        else: cur.append(x)
    clauses.append(cur)
    last, items_last, opened, drawer_last = None, [], set(), None
    for c in clauses:
        vi = next((i for i, x in enumerate(c) if x in VERBS), None)
        if vi is None or api.remaining() < 10: continue
        v, rest = c[vi], [x for x in c[vi + 1:] if x not in STOP]
        if v in ('open', 'close', 'shut'):
            t = drawer_last if ('it' in rest and drawer_last) else refine(resolve(rest, ('fixture', 'region')), rest, 'in')
            if t:
                api.act({'op': 'open' if v == 'open' else 'close', 'target': t}); drawer_last = last = t
                opened.add(t) if v == 'open' else opened.discard(t)
            continue
        if v in ('turn', 'switch'):  # knob/switch: heuristic sweep near the front edge of the appliance
            t = last if ('it' in rest and last) else resolve([x for x in rest if x not in ('on', 'off')], ('fixture', 'item'))
            if t:
                sg = -1.0 if 'off' in rest else 1.0
                api.act({'op': 'stroke', 'target': t, 'offset': [-0.10, 0.06 * sg, 0.03], 'delta': [0.0, -0.08 * sg, 0.0]}); last = t
            continue
        k = next((i for i, x in enumerate(rest) if x in PREPS), len(rest))
        iw, dw, prep = rest[:k], rest[k + 1:], (rest[k] if k < len(rest) else '')
        tgt = None
        if dw and ('it' in dw or 'them' in dw) and last:
            tgt = last if (cat[last]['kind'] == 'region' and not ('top' in dw and prep in ON)) else refine(root(last), dw, prep)
        elif dw:
            tgt = refine(resolve(dw, ('item', 'fixture', 'region')), dw, prep)
        if not iw or 'it' in iw or 'them' in iw: its = items_last
        else:
            parts = ' '.join(iw).replace(',', ' and ').split(' and ') if (',' in iw or 'both' in c or 'all' in c) else [' '.join(iw)]
            its = [x for x in (resolve(p.split(), ('item',), P(tgt) if tgt else None) for p in parts) if x and x != tgt]
        items_last = its
        dv = next((np.array(DIRS[x], float) for x in dw if x in DIRS), None)
        if v in ('push', 'slide') or (tgt is None and dv is not None):
            for it in its:
                dv0 = dv if dv is not None else (np.zeros(3) if tgt else np.array([1.0, 0, 0]))
                goal = (P(tgt) if tgt else P(it)) + (0.12 if tgt else 0.15) * dv0
                for _ in range(3):  # re-check live position and budget before each stroke
                    d = goal - P(it); d[2] = 0.0; L = min(0.25, float(np.linalg.norm(d)))
                    if L < 0.03 or api.remaining() < 10: break
                    u = d / np.linalg.norm(d)
                    api.act({'op': 'stroke', 'target': it, 'offset': [float(x) for x in (-0.07 * u + [0, 0, 0.01])],
                             'delta': [float(x) for x in L * u]})
        elif tgt:
            if is_drawer(tgt) and tgt not in opened:
                api.act({'op': 'open', 'target': tgt}); opened.add(tgt); drawer_last = tgt
            for it in its:
                g = ['standard', 'thin_edge', 'rim'] if 'book' in toks(it) else ['standard', 'rim', 'thin_edge']
                for _ in range(2):
                    if api.remaining() < 10: break
                    r = api.act({'op': 'place', 'item': it, 'target': tgt, 'grasps': g})
                    ml, gap = r.get('max_lift'), r.get('xy_gap')
                    if r.get('executed') and (ml is None or ml > 0.02) and (gap is None or gap < 0.1): break
                    g = g[1:] + g[:1]
        last = tgt or (its[-1] if its else last)
