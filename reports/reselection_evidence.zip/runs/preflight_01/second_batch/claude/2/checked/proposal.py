import numpy as np

SYN = {'white': ['porcelain'], 'compartment': ['contain'], 'pot': ['moka'], 'pan': ['frypan'], 'skillet': ['frypan'],
       'burner': ['stove'], 'oven': ['stove'], 'cup': ['mug'], 'mug': ['cup'], 'tray': ['plate'], 'shelf': ['rack'],
       'bin': ['basket'], 'drawer': ['region'], 'cookies': ['cookie'], 'box': ['box']}
STOP = {'the', 'a', 'an', 'of', 'up', 'and', 'both', 'its', 'that', 'is', 'which', 'please'}
GEN = {'region', 'table', 'kitchen', 'living', 'room', 'study', 'side', 'contain', 'init'}
SP = {'left': (1, 'max'), 'right': (1, 'min'), 'front': (0, 'min'), 'back': (0, 'max'), 'rear': (0, 'max')}
VERBS = {'put', 'place', 'pick', 'close', 'open', 'turn', 'switch', 'shut', 'move', 'set', 'take', 'grab', 'stack'}
SRC = [' next to ', ' near ', ' beside ', ' between ', ' on ', ' in ', ' at ', ' from ']
DST = {' on top of ': ['top', 'side'], ' into ': ['contain'], ' onto ': ['cook'], ' inside ': ['contain'],
       ' in ': ['contain'], ' on ': ['cook']}


def run(api):
    cat = api.catalog()
    toks = lambda n: [x for x in n.split('_') if not x.isdigit()]
    P = lambda n: np.asarray(api.pos(n), float)
    lbl = lambda n: cat[n]['kind'] == 'region' and cat[n].get('parent') not in cat
    root = lambda n: cat[n]['parent'] if cat[n]['kind'] == 'region' and cat[n].get('parent') in cat else n

    def words(s):
        out = set()
        for x in s.split():
            if x not in STOP:
                out.update([x, x[:-1] if x.endswith('s') else x] + SYN.get(x, []))
        return out

    def score(n, w, h):
        t = toks(n)
        return (sum(x in w for x in t) + 0.5 * sum(x in h and x not in w for x in t) - 0.05 * lbl(n)
                - 0.2 * sum(x not in w and x not in h and x not in GEN for x in t))

    def pick(ph, kinds, h=(), sp_ph='', near=None, labels=False):
        w, h = words(ph), set(h)
        sc = {n: score(n, w, h) for n in cat if cat[n]['kind'] in kinds and (labels or not lbl(n))}
        b = max(sc.values(), default=0)
        if b <= 0:
            return None, None
        top = [n for n in sc if sc[n] > b - 1e-6]
        sel = {'kind': cat[top[0]]['kind'], 'terms': [x for x in toks(top[0]) if x in w or x in h] or toks(top[0])[-1:]}
        pars = {cat[n].get('parent') for n in top}
        if sel['kind'] == 'region' and len(pars) == 1 and list(pars)[0] in cat:
            sel['parent'] = list(pars)[0]
        sp = [x for x in (sp_ph + ' ' + ph).split() if x in SP]
        if len(top) > 1:
            lab = [a for a in cat if lbl(a) and sp and sp[0] in toks(a) and set(toks(a)) & set(sel['terms'])]
            if lab:
                near = lab[0]
            elif sp:
                ax, rk = SP[sp[0]]
                f = max if rk == 'max' else min
                return f(top, key=lambda n: P(n)[ax]), dict(sel, axis='xyz'[ax], rank=rk)
            if near:
                top = [min(top, key=lambda n: np.linalg.norm(P(n)[:2] - P(near)[:2]))]
                sel['near'] = near
        return top[0], sel

    def item(ph, tg):
        ph = ' ' + ph + ' '
        cut = min([(ph.find(m), m) for m in SRC if ph.find(m) > 0] or [(len(ph), '')])
        anc = ph[cut[0] + len(cut[1]):] if cut[1] else ''
        a = pick(anc, {'item', 'fixture', 'region'}, labels=True)[0] if anc.strip() else None
        return pick(ph[:cut[0]], {'item'}, sp_ph=anc, near=a or tg)

    def go(step):
        pv = api.preview(step)
        for role, r in (pv or {}).items():
            if isinstance(r, dict) and r.get('status') == 'corrected' and r.get('resolved'):
                step[role] = r['resolved']
        return api.act(step) or {}

    def place(it, isel, tg, tsel, dr):
        g = ['thin_edge', 'standard', 'rim'] if 'book' in toks(it) else ['standard', 'rim', 'thin_edge']
        opened = False
        for _ in range(3):
            if api.remaining() < 25:
                return
            st = {'op': 'place', 'item': it, 'target': tg, 'grasps': g, 'expect': {'item': isel, 'target': tsel}}
            r = go(st)
            it, tg = st['item'], st['target']
            if not r.get('executed'):
                return
            lift, gap = r.get('max_lift'), r.get('xy_gap')
            if lift is not None and lift < 0.015:
                g = g[1:] + g[:1]
            elif dr and not opened and gap is not None and gap > 0.06:
                opened = True
                go({'op': 'open', 'target': tg, 'expect': {'target': tsel}})
            else:
                return

    t = api.instruction.lower().replace(',', ' and ').replace('.', ' ').replace(' then ', ' and ').split()
    cls, cur = [], []
    for i, x in enumerate(t):
        if x == 'and' and (not cur or (i + 1 < len(t) and t[i + 1] in VERBS)):
            cls, cur = (cls + [cur] if cur else cls), []
        else:
            cur.append(x)
    cls += [cur] if cur else []
    last, drawer, held = None, None, None
    for w in cls:
        if api.remaining() < 25:
            break
        v, ph = w[0], ' '.join(x for x in w[1:] if x != 'up')
        itw = ' '.join(toks(last)) if last else ''
        if v in ('open', 'close', 'shut'):
            tg, sel = drawer if (words(ph) <= {'it', 'drawer', 'region'} and drawer) else pick(ph + ' drawer', {'region'})
            if tg:
                go({'op': 'open' if v == 'open' else 'close', 'target': tg, 'expect': {'target': sel}})
                drawer, last = (tg, sel), root(tg)
        elif v in ('turn', 'switch'):
            on = 'off' not in w
            q = ' '.join(x for x in w[1:] if x not in ('on', 'off'))
            tg, sel = pick(q.replace('it', itw) if words(q) <= {'it'} else q, {'fixture', 'item'})
            if tg:
                go({'op': 'stroke', 'target': tg, 'offset': [-0.02, 0.09, 0.03],
                    'delta': [0.0, -0.06 if on else 0.06, 0.0], 'expect': {'target': sel}})
                last = tg
        else:
            rest = ' ' + ph + ' '
            idx, ln, m = max((rest.rfind(m), len(m), m) for m in DST)
            if idx < 0:
                held = item(rest, None)
                continue
            ip, tp = rest[:idx], ' '.join(itw if x == 'it' else x for x in rest[idx + ln:].split())
            dr = 'drawer' in tp.split()
            tg, tsel = pick(tp, {'item', 'fixture', 'region'}, DST[m] + (['region'] if dr else []))
            if not tg:
                continue
            parts = ip.split(' and ') if ('both' in ip.split() or ' and the ' in ip) else [ip]
            todo = [held] if (words(ip) <= {'it', 'them'} and held) else [item(p, tg) for p in parts if words(p)]
            for it, isel in todo:
                if it:
                    place(it, isel, tg, tsel, dr)
            drawer = (tg, tsel) if dr else drawer
            last, held = root(tg), None
