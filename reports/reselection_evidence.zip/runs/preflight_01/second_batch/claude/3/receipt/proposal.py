import numpy as np
SYN = {'white': ['white', 'porcelain'], 'compartment': ['contain'], 'drawer': ['region'], 'cup': ['mug'],
       'pan': ['frypan', 'pan'], 'burner': ['stove'], 'mugs': ['mug'], 'bowls': ['bowl'], 'plates': ['plate']}
STOP = {'the', 'a', 'an', 'of', 'to', 'up', 'both', 'one', 'its', 'that', 'is', 'which', 'down'}
COL = {'red', 'white', 'yellow', 'black', 'blue', 'green', 'brown', 'pink', 'orange', 'grey', 'gray', 'silver', 'purple'}
IN = ('in', 'into', 'inside')
VERBS = {'put', 'place', 'pick', 'move', 'open', 'close', 'turn', 'push', 'set', 'take', 'stack', 'grab',
         'switch', 'shut', 'slide', 'drop', 'lift'}

def run(api):
    cat = api.catalog(); names = [n for n in cat if 'init' not in n] or list(cat)
    P = lambda n: np.array(api.pos(n), float)
    toks = lambda n: [t for t in n.split('_') if not t.isdigit()]
    def axis(a, b, dflt):
        for x in cat:
            y = x.replace('_' + a + '_', '_' + b + '_')
            if y != x and y in cat:
                d = P(x) - P(y); d[2] = 0
                if np.linalg.norm(d) > .01: return d / np.linalg.norm(d)
        return np.array(dflt, float)
    ax = {'left': axis('left', 'right', [0, 1, 0]), 'front': axis('front', 'back', [-1, 0, 0])}
    ax['right'] = -ax['left']; ax['back'] = ax['behind'] = -ax['front']
    def root(n):
        while cat[n]['parent'] in cat: n = cat[n]['parent']
        return n
    def ground(ph, kinds, prep='', near=None, avoid=()):
        ph = ' ' + ph + ' '; ref = None
        for r in (' next_to ', ' near ', ' beside ', ' closest_to ', ' on ', ' in ', ' at ', ' from ', ' by ', ' under '):
            if r in ph: ph, ref = ph.split(r, 1); break
        ws = [w for w in ph.split() if w not in STOP]
        if prep == 'on' and ws[:1] == ['top']: ws.append('side')
        if prep in IN: ws.append('contain')
        sc = {}
        for n in names:
            if cat[n]['kind'] in kinds and n not in avoid:
                t = toks(n)
                hit = [x for x in t if any(s == x or (len(s) > 3 and (s in x or x in s)) for w in ws for s in SYN.get(w, [w]))]
                if hit: sc[n] = 2 * len(hit) - .3 * (len(t) - len(hit))
        if not sc: return None
        bs = max(sc.values()); c = [n for n in sc if sc[n] > bs - .25]
        if len(c) > 1:
            d = [w for w in ws if w in ax and not any(w in toks(n) for n in c)]
            if d: return max(c, key=lambda n: P(n) @ ax[d[0]])
            rf = ground(ref, ('item', 'fixture', 'region')) if ref else None
            if rf: return min(c, key=lambda n: np.linalg.norm(P(n) - P(rf)))
            if near is not None:
                far = [n for n in c if np.linalg.norm((P(n) - near)[:2]) > .05] or c
                return min(far, key=lambda n: np.linalg.norm((P(n) - near)[:2]))
        return max(c, key=lambda n: sc[n])
    def place(it, tg):
        g = ['thin_edge', 'standard', 'rim'] if 'book' in it else (['rim', 'standard', 'thin_edge']
            if any(k in it for k in ('mug', 'cup', 'bowl')) else ['standard', 'rim', 'thin_edge'])
        for _ in range(2):
            if api.remaining() <= 0: return
            r = api.act({'op': 'place', 'item': it, 'target': tg, 'grasps': g})
            gap, lift = r.get('xy_gap'), r.get('max_lift')
            if not r.get('executed') or ((gap is None or gap < .07) and (lift is None or lift > .01)): return
            g = g[1:] + g[:1]
    s = api.instruction.lower()
    for a, b in ((',', ' '), ('.', ' '), ('next to', 'next_to'), ('closest to', 'closest_to'), (' then ', ' and ')):
        s = s.replace(a, b)
    w = s.split()
    w = [x for i, x in enumerate(w) if not (x == 'and' and 0 < i < len(w) - 1 and w[i - 1] in COL and w[i + 1] in COL)]
    cl = []
    for f in ' '.join(w).split(' and '):
        f = f.split()
        while f and f[0] in ('then', 'also', 'and'): f = f[1:]
        if not f: continue
        if f[0] in VERBS or not cl: cl.append([f[0], ' '.join(f[1:])])
        else: cl[-1][1] += ' and ' + ' '.join(f)
    pend, last, opened = [], None, set()
    for v, r in cl:
        if api.remaining() <= 0: break
        rw = r.split()
        if v in ('turn', 'switch'):
            t = ground(' '.join(x for x in rw if x not in ('on', 'off')), ('fixture', 'item')) or last
            if t:
                o = .1 * ax['front'] + .05 * ax['right']; d = .08 * (ax['right'] if 'off' in rw else ax['left'])
                api.act({'op': 'stroke', 'target': t, 'offset': [float(x) for x in o], 'delta': [float(x) for x in d]}); last = t
            continue
        if v in ('open', 'close', 'shut'):
            t = last if r.strip() in ('it', 'them', '') and last else ground(r + ' drawer', ('region',))
            if t:
                api.act({'op': 'open' if v == 'open' else 'close', 'target': t}); last = t
                (opened.add if v == 'open' else opened.discard)(t)
            continue
        if v in ('push', 'slide'):
            tt = r.split(' to ', 1); it = ground(tt[0], ('item',)) or last
            dw = [x for x in rw if x in ax]; tg = ground(tt[1], ('item', 'fixture', 'region')) if len(tt) > 1 and not dw else None
            dd = ax[dw[-1]] if dw else ((P(tg) - P(it)) * [1, 1, 0] if tg and it else None)
            if it and dd is not None:
                dd = dd / (np.linalg.norm(dd) + 1e-9)
                api.act({'op': 'stroke', 'target': it, 'offset': [float(x) for x in -.08 * dd],
                         'delta': [float(x) for x in .15 * dd]}); last = it
            continue
        rr = ' ' + r + ' '; k, p = -1, ''
        for q in (' into ', ' onto ', ' inside ', ' in ', ' on ', ' to ', ' at '):
            if rr.rfind(q) > k: k, p = rr.rfind(q), q
        src, tg = (rr[:k], rr[k + len(p):]) if k >= 0 else (rr, ''); p = p.strip()
        T = None
        if tg.strip():
            tg = ' '.join(' '.join(toks(root(last))) if x in ('it', 'them') and last else x for x in tg.split())
            T = ground(tg, ('item', 'fixture', 'region'), p)
            kids = [n for n in names if cat[n]['parent'] == T and ('cook' in n or (p in IN and 'contain' in n))] if T else []
            T = kids[0] if kids else T
        items, used = [], []
        for x in src.split(' and '):
            if x.strip() in ('it', 'them', ''): items += [i for i in pend if i not in items]; continue
            i = ground(x, ('item',), near=P(T) if T else None, avoid=used)
            if i: items.append(i); used.append(i)
        if not T: pend, last = items, (items[-1] if items else last); continue
        if p in IN and cat[T]['kind'] == 'region' and T not in opened and any(z in T for z in ('top_region', 'middle_region', 'bottom_region')):
            api.act({'op': 'open', 'target': T}); opened.add(T)
        for i in items:
            if i != T: place(i, T)
        pend, last = [], T
