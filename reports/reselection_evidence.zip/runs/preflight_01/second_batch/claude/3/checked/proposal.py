import numpy as np

STOP = set('the a an of to it its both and with up please from that this'.split())
SPATIAL = {'left', 'right', 'front', 'back', 'top', 'bottom', 'middle'}
SYN = {'rear': ['back'], 'center': ['middle'], 'drawer': ['region'], 'compartment': ['contain'],
       'white': ['porcelain'], 'cup': ['mug'], 'pan': ['frypan'], 'burner': ['stove'], 'shelf': ['rack'], 'dish': ['plate']}
GEN = {'region', 'contain', 'init', 'side', 'table', 'kitchen', 'living', 'room', 'study', 'cook'}
VERBS = {'put', 'place', 'pick', 'move', 'stack', 'open', 'close', 'shut', 'turn', 'switch', 'push', 'slide', 'take', 'set'}
AX = {'left': ('y', 'max'), 'right': ('y', 'min'), 'front': ('x', 'min'), 'back': ('x', 'max'), 'top': ('z', 'max'), 'bottom': ('z', 'min')}
PREPS = [' on top of ', ' into ', ' inside ', ' onto ', ' in ', ' on ', ' to ', ' at ']

def run(api):
    cat = api.catalog()
    P = lambda n: np.array(api.pos(n), float)
    W = lambda n: [w for w in n.lower().split('_') if w.isalpha()]
    label = lambda n: cat[n]['kind'] == 'region' and ('table' in W(n) or 'init' in W(n) or not cat[n]['parent'])
    def pw_of(s):
        out = []
        for w in s.replace('-', ' ').split():
            for v in [w] + SYN.get(w, []):
                if v not in STOP and v not in out: out.append(v)
        return out
    def score(n, pw):
        nw = W(n)
        return sum(w in pw for w in nw) - 0.3 * sum(w not in pw and w not in GEN and w not in SPATIAL for w in nw)
    def sel(n, pw, extra):
        d = {'kind': cat[n]['kind'], 'terms': [w for w in pw if w in W(n)] or [w for w in W(n) if w not in GEN][:1]}
        d.update(extra); return d
    def owner(pw, kinds, ref=None):
        c = [n for n in cat if cat[n]['kind'] in kinds] or [n for n in cat if not label(n)]
        b = max(score(n, pw) for n in c); ties = [n for n in c if score(n, pw) > b - 1e-6]
        sp = [w for w in pw if w in SPATIAL]
        if len(ties) > 1 and sp:
            noun = [w for w in pw if w not in SPATIAL]
            an = [n for n in cat if label(n) and sp[0] in W(n) and any(w in W(n) for w in noun)]
            if an:
                a = max(an, key=lambda n: score(n, pw))
                return min(ties, key=lambda n: np.linalg.norm(P(n)[:2] - P(a)[:2])), {'near': a}
            if sp[0] in AX:
                ax, rk = AX[sp[0]]; i = 'xyz'.index(ax)
                return (max if rk == 'max' else min)(ties, key=lambda n: P(n)[i]), {'axis': ax, 'rank': rk}
        if len(ties) > 1 and ref is not None:
            dist = lambda n: np.linalg.norm(P(n)[:2] - ref[:2])
            return min(ties, key=lambda n: (dist(n) < 0.05, dist(n))), {}
        return ties[0], {}
    def target(s, ontop):
        pw = pw_of(s); o, ex = owner(pw, ('item', 'fixture'))
        kids = [n for n in cat if cat[n]['kind'] == 'region' and cat[n]['parent'] == o]
        if ontop:
            k = [n for n in kids if 'top' in W(n)]
            if not k: return o, sel(o, pw, ex)
            n = max(k, key=lambda n: P(n)[2])
            return n, sel(n, pw + ['top'], {'parent': o, 'axis': 'z', 'rank': 'max'})
        for w in [w for w in pw if w in SPATIAL]:
            kids = [n for n in kids if w in W(n)] or kids
        if not kids: return o, sel(o, pw, ex)
        n = max(kids, key=lambda n: (score(n, pw), P(n)[2]))
        return n, sel(n, pw, {'parent': o})
    def act(st):
        pv = api.preview(st)
        if isinstance(pv, dict):
            for role in ('item', 'target'):
                r = pv.get(role) or {}
                if r.get('status') == 'corrected' and r.get('resolved') in cat: st[role] = r['resolved']
        return api.act(st) if api.remaining() > 10 else None
    s = ' ' + api.instruction.lower().replace(',', ' and ').replace('.', ' ').replace(' then ', ' and ') + ' '
    cl = []
    for p in s.split(' and '):
        p = p.strip()
        if p and (not cl or p.split()[0] in VERBS): cl.append(p)
        elif p: cl[-1] += ' and ' + p
    last_i, last_t = '', ''
    for c in cl:
        if api.remaining() < 25: break
        v, rest = c.split()[0], ' ' + ' '.join(c.split()[1:]) + ' '
        if v in ('turn', 'switch'):
            on = ' off ' not in rest
            ph = rest.replace(' on ', ' ').replace(' off ', ' ').strip()
            ph = last_t if ph in ('it', '') else ph; last_t = ph
            o, ex = owner(pw_of(ph), ('fixture', 'item'))
            act({'op': 'stroke', 'target': o, 'offset': [-0.12, 0.0, 0.03], 'delta': [0.0, 0.06 if on else -0.06, 0.0],
                 'expect': {'target': sel(o, pw_of(ph), ex)}}); continue
        if v in ('open', 'close', 'shut'):
            ph = rest.strip(); ph = last_t if ph == 'it' else ph; last_t = ph
            n, tsl = target(ph, False)
            act({'op': 'open' if v == 'open' else 'close', 'target': n, 'expect': {'target': tsl}}); continue
        hits = [(rest.find(p), -len(p), p) for p in PREPS if rest.find(p) >= 0]
        if not hits: last_i = rest.strip(); continue
        i, _, p = min(hits); ip, tp = rest[:i].strip(), rest[i + len(p):].strip()
        ip = last_i if ip in ('it', 'up it', '') else ip
        ontop = p == ' on top of '; tp = last_t if tp == 'it' else tp
        t, tsl = target(tp, ontop); last_t = tp
        if v in ('push', 'slide'):
            pw = pw_of(ip); o, ex = owner(pw, ('item',)); g = P(t)
            for w in pw_of(tp):
                if w in AX and AX[w][0] != 'z': g['xyz'.index(AX[w][0])] += 0.12 if AX[w][1] == 'max' else -0.12
            d = g - P(o); d[2] = 0; u = d / (np.linalg.norm(d) + 1e-9); d = d - 0.04 * u
            d = d * min(1.0, 0.3 / (np.linalg.norm(d) + 1e-9))
            act({'op': 'stroke', 'target': o, 'offset': [float(x) for x in (-0.07 * u + np.array([0, 0, 0.02]))],
                 'delta': [float(x) for x in d], 'expect': {'target': sel(o, pw, ex)}}); continue
        if 'drawer' in tp.split() and not ontop:
            act({'op': 'open', 'target': t, 'expect': {'target': tsl}})
        items = ip.replace(' and the ', ' and ').split(' and ') if ('both ' in ip or ' and the ' in ip) else [ip]
        for ph in items:
            pw = pw_of(ph); o, ex = owner(pw, ('item',), P(t)); last_i = ph
            gr = ['thin_edge', 'standard', 'rim'] if 'book' in W(o) else ['standard', 'rim', 'thin_edge']
            st = {'op': 'place', 'item': o, 'target': t, 'grasps': gr, 'expect': {'item': sel(o, pw, ex), 'target': tsl}}
            r = act(st) or {}
            ml = r.get('max_lift')
            if r.get('executed') and ml is not None and ml < 0.01 and api.remaining() > 40:
                st['grasps'] = gr[1:] + gr[:1]; act(st)
