def run(api):
    import numpy as np
    cat = api.catalog()
    colors = set("black white yellow red blue green orange brown pink gray grey".split())
    spatial = set("left right front back top bottom middle nearest closest farthest".split())
    stop = set("the a an both all of to it them and up down in on into onto inside drawer compartment".split())
    aliases = {"porcelain": "white", "contain": "inside", "cook": "stove",
               "upper": "top", "lower": "bottom", "rear": "back", "centre": "middle"}
    def words(s):
        s = s.lower().replace("_", " ").replace("-", " ")
        for c in ",.;:!?":
            s = s.replace(c, " ")
        return [aliases.get(w, w) for w in s.split() if not w.isdigit()]
    def pos(n):
        return np.asarray(api.pos(n), dtype=float)
    names = {n: set(words(n)) for n in cat}
    nouns = set().union(*names.values()) - colors - spatial - stop - {"region", "init", "side"}
    last, held, opened = None, None, set()
    def resolve(s, destination=False):
        w = set(words(s)) - stop
        if not w:
            return last if destination else held
        candidates = [n for n in cat if "init_region" not in n and
                      (destination or cat[n]["kind"] == "item")]
        scored = []
        for n in candidates:
            nw = names[n]
            parent = cat[n]["parent"]
            pw = names.get(parent, set())
            evidence = nw | pw
            hits = w & evidence
            if not hits & nouns:
                continue
            score = 5 * len(hits - spatial) - 4 * len((w & colors) - evidence)
            score += 3 * len(hits & spatial)
            score -= 0.4 * len((nw & colors) - w)
            if cat[n]["kind"] == "region":
                score += 2 if w & spatial or "drawer" in s or "compartment" in s else -2
            scored.append([score, n])
        if not scored:
            return None
        best = max(x[0] for x in scored)
        pool = [n for score, n in scored if score >= best - 0.5]
        for direction, axis, sign in [("left", 0, -1), ("right", 0, 1),
                                      ("front", 1, -1), ("back", 1, 1),
                                      ("top", 2, 1), ("bottom", 2, -1)]:
            if direction in w and not any(direction in names[n] for n in pool):
                return max(pool, key=lambda n: sign * pos(n)[axis])
        return max(pool, key=lambda n: (len(w & names[n]), -len(names[n])))
    def act(step):
        if api.remaining() <= 0:
            return {}
        for key in ("item", "target"):
            if key in step:
                pos(step[key])
        receipt = api.act(step)
        api.remaining()
        for key in ("item", "target"):
            if key in step:
                pos(step[key])
        return receipt or {}
    text = api.instruction.lower().replace("pick up", "pick").replace("place", "put")
    text = text.replace("turn on", "activate").replace("turn off", "deactivate")
    tokens = words(text)
    verbs = {"pick", "put", "open", "close", "activate", "deactivate", "push", "slide"}
    clauses = []
    for token in tokens:
        if token in verbs:
            clauses.append([token, []])
        elif clauses:
            clauses[-1][1].append(token)
    for verb, tokens in clauses:
        if api.remaining() <= 0:
            break
        phrase = " ".join(tokens).strip()
        if verb == "pick":
            held = resolve(phrase)
            continue
        if verb == "put":
            cuts = [i for i, w in enumerate(tokens) if w in {"in", "on", "into", "onto", "inside"}]
            if not cuts:
                continue
            k = cuts[0]
            source, destination = " ".join(tokens[:k]), " ".join(tokens[k + 1:])
            target = resolve(destination, True)
            if target is None:
                continue
            children = [n for n in cat if cat[n]["parent"] == target and cat[n]["kind"] == "region"]
            preferred = [n for n in children if ("contain" in n if tokens[k] in {"in", "into", "inside"} else "top_side" in n or "cook_region" in n)]
            target = preferred[0] if len(preferred) == 1 else target
            parts = source.split(" and ")
            parts = parts if all(set(words(p)) & nouns for p in parts) else [source]
            for part in parts:
                item = resolve(part)
                if item is None or item == target:
                    continue
                if "drawer" in destination and target not in opened:
                    if act({"op": "open", "target": target}).get("executed"):
                        opened.add(target)
                for grasp in ("standard", "thin_edge", "rim") if "book" in names[item] else ("standard", "rim", "thin_edge"):
                    r = act({"op": "place", "item": item, "target": target, "grasps": [grasp]})
                    if not r.get("executed") or r.get("max_lift") is None or r["max_lift"] > 0.02 or r.get("xy_gap", 1) < 0.05:
                        break
                held = item
            last = cat[target]["parent"] or target
        else:
            target = resolve(phrase, True)
            if target is None:
                continue
            if verb in {"open", "close"}:
                act({"op": verb, "target": target})
                opened.add(target) if verb == "open" else opened.discard(target)
            else:
                delta = [-0.10, 0, 0] if "left" in tokens else [0.10, 0, 0]
                if "front" in tokens or "back" in tokens:
                    delta = [0, -0.10 if "front" in tokens else 0.10, 0]
                if verb in {"activate", "deactivate"}:
                    delta = [0, 0.06 if verb == "activate" else -0.06, 0]
                act({"op": "stroke", "target": target, "offset": [0, 0, 0], "delta": delta})
            last = target
