def run(api):
    import numpy as np
    cat = api.catalog()
    words = {n: [w for w in n.lower().replace("_", " ").split() if w.isalpha()] for n in cat}
    vocab = set(w for ws in words.values() for w in ws)
    aliases = {"compartment": "contain", "inside": "contain", "interior": "contain",
               "upper": "top", "lower": "bottom", "rear": "back", "centre": "middle",
               "center": "middle", "cup": "mug", "container": "contain"}
    directions = {"left": ("x", "min"), "right": ("x", "max"),
                  "front": ("y", "min"), "back": ("y", "max"),
                  "top": ("z", "max"), "bottom": ("z", "min"), "middle": ("z", "median")}
    stop = "the a an both all it them of from at to in into on onto above below drawer compartment".split()
    last_item, last_owner, last_drawer = "", "", ""

    def resolve(text, kinds, owner=None, region=False):
        ts = [aliases.get(w, w) for w in text.split() if w not in stop]
        ds = [w for w in ts if w in directions]
        terms = list(dict.fromkeys(w for w in ts if w in vocab and w not in directions))
        pool = [n for n in cat if cat[n]["kind"] in kinds and
                (owner is None or cat[n]["parent"] == owner) and
                ("init" not in words[n] if region else True)]
        if not terms and not (owner and region):
            return None
        candidates = [n for n in pool if all(w in words[n] for w in terms)]
        if not candidates and "white" in terms and "yellow" not in terms:
            alt = ["porcelain" if w == "white" else w for w in terms]
            candidates = [n for n in pool if all(w in words[n] for w in alt)]
            if candidates:
                terms = alt
        if not candidates:
            return None
        selector = {"kind": cat[candidates[0]]["kind"], "terms": terms[:]}
        if owner:
            selector["parent"] = owner
        for d in ds:
            direct = [n for n in candidates if d in words[n]]
            anchors = [n for n in cat if cat[n]["kind"] == "region" and
                       d in words[n] and all(w in words[n] for w in terms)]
            if direct:
                candidates, selector["terms"] = direct, selector["terms"] + [d]
            elif anchors:
                if len(anchors) != 1:
                    return None
                anchor = anchors[0]
                candidates.sort(key=lambda n: float(np.linalg.norm(api.pos(n) - api.pos(anchor))))
                selector["near"] = anchor
            else:
                axis, rank = directions[d]
                selector.update(axis=axis, rank=rank)
                candidates.sort(key=lambda n: float(api.pos(n)["xyz".index(axis)]))
                if rank == "max":
                    candidates.reverse()
                elif rank == "median":
                    candidates = [candidates[len(candidates) // 2]]
        return candidates[0], selector

    def execute(op, target, item=None, **extra):
        if not target or (op == "place" and not item) or api.remaining() <= 0:
            return None
        step = dict(op=op, target=target[0], expect={"target": target[1]}, **extra)
        if item:
            step.update(item=item[0])
            step["expect"]["item"] = item[1]
        for role in step["expect"]:
            api.pos(step[role])
        preview = api.preview(step)
        if preview and any(v["status"] == "unresolved" for v in preview.values()):
            return None
        if api.remaining() <= 0:
            return None
        return api.act(step)

    text = api.instruction.lower()
    for mark in ",.;":
        text = text.replace(mark, " and ")
    text = text.replace(" and then ", " and ").replace(" then ", " and ")
    verbs = ["pick up", "place", "put", "move", "set", "open", "close", "shut", "turn on", "turn off"]
    for verb in verbs:
        text = text.replace(verb + " ", "|" + verb.replace(" ", "_") + " ")
    for clause in text.split("|"):
        ws = clause.split()
        if not ws or ws[0].replace("_", " ") not in verbs:
            continue
        op, body = ws[0], " ".join(ws[1:]).strip()
        while body.endswith(" and"):
            body = body[:-4].strip()
        if op == "pick_up":
            last_item = body
            continue
        if op in ("open", "close", "shut"):
            owner = resolve(body, ["fixture", "item"])
            if owner:
                last_owner = owner[0]
            target = last_drawer if body in ("it", "the drawer") and last_drawer else resolve(
                " ".join(w for w in body.split() if w in directions) or "top",
                ["region"], last_owner or None, True)
            execute("open" if op == "open" else "close", target)
            last_drawer = target
            continue
        if op in ("turn_on", "turn_off"):
            target = resolve(body, ["fixture", "item"])
            execute("stroke", target, offset=[0, 0, 0], delta=[0, 0.08 if op == "turn_on" else -0.08, 0])
            if target:
                last_owner = target[0]
            continue
        split = next(((body.split(" " + p + " ", 1), p)
                      for p in ("into", "onto", "in", "on", "to") if " " + p + " " in body), None)
        if not split:
            continue
        (source, dest), prep = split
        source = last_item if source.strip() in ("it", "them") else source.replace("both ", "")
        owner = resolve(dest, ["fixture", "item"])
        if not owner and dest.strip() in ("it", "top of it", "the top of it") and last_owner:
            owner = resolve(" ".join(words[last_owner]), [cat[last_owner]["kind"]])
        if not owner:
            continue
        last_owner = owner[0]
        loc = [aliases.get(w, w) for w in dest.split() if aliases.get(w, w) in directions]
        region_text = " ".join(loc + (["side"] if "top" in loc and "drawer" not in dest else []))
        if not region_text:
            region_text = "contain" if prep in ("in", "into") else "cook" if "stove" in words[owner[0]] else "top"
        target = resolve(region_text, ["region"], owner[0], True) or owner
        for phrase in source.split(" and "):
            item = resolve(phrase, ["item"])
            if not item:
                continue
            receipt = execute("place", target, item, grasps=["standard", "rim", "thin_edge"])
            if receipt and receipt["executed"]:
                last_item = phrase
            elif "drawer" in dest and target[1]["kind"] == "region":
                opened = execute("open", target)
                if opened and opened["executed"]:
                    execute("place", target, item, grasps=["standard", "rim", "thin_edge"])
            if "drawer" in dest:
                last_drawer = target
