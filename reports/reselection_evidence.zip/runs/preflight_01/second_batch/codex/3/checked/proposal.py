def run(api):
    import numpy as np
    catalog = api.catalog()
    words = lambda s: s.lower().replace("_", " ").replace("-", " ").split()
    tokens = {n: [w for w in words(n) if w.isalpha()] for n in catalog}
    verbs = "put place move transfer set pick open close shut turn switch push pull".split()
    stop = "the a an both and up down please into onto to from of it them drawer compartment box".split()
    aliases = {"cup": "mug", "cabinet": "cabinet", "tray": "tray",
               "compartment": "contain", "inside": "contain", "shut": "close"}
    directions = "left right front back rear top bottom middle".split()
    last_item, last_target = None, None

    def ground(phrase, role="item", owner=None):
        ws = words(phrase)
        if ws in (["it"], ["them"]):
            return last_item if role == "item" else last_target
        for prep in (" from ", " near ", " of "):
            if prep in " " + phrase + " ":
                head, tail = phrase.split(prep, 1)
                anchor = ground(tail, "target")
                if anchor:
                    result = ground(head, role, anchor[0] if prep == " of " else owner)
                    if result and prep != " of ":
                        result[1]["near"] = anchor[0]
                    return nominate(result)
        pool = [n for n in catalog if catalog[n]["kind"] == "item"] if role == "item" else list(catalog)
        if owner:
            pool = [n for n in pool if catalog[n]["parent"] == owner]
        meaningful = [aliases.get(w, w) for w in ws if w not in stop and w not in verbs
                      and w not in ("on", "in", "at", "off")]
        terms = [w for w in meaningful if any(w in tokens[n] for n in pool)]
        spatial = [w for w in terms if w in directions]
        anchors = [n for n in catalog if catalog[n]["kind"] == "region"
                   and all(w in tokens[n] for w in spatial)
                   and any(w in tokens[n] for w in terms if w not in directions)]
        near = None
        if role == "item" and spatial and anchors:
            near = min(anchors, key=lambda n: (len(tokens[n]), n))
            terms = [w for w in terms if w not in spatial]
        if role == "target":
            fixtures = [n for n in pool if catalog[n]["kind"] in ("fixture", "item")
                        and terms and all(w in tokens[n] for w in terms if w not in directions)]
            regions = [n for n in pool if catalog[n]["kind"] == "region" and "init" not in tokens[n]]
            owned = [n for n in regions if catalog[n]["parent"] in fixtures]
            if owned:
                pool = owned
                owner = catalog[owned[0]]["parent"] if len(fixtures) == 1 else owner
                terms = [w for w in terms if w in directions or w not in tokens[fixtures[0]]]
                preference = ("side" if "on top" in phrase else "cook" if "stove" in ws
                              else "contain" if not spatial else None)
                if preference and any(preference in tokens[n] for n in pool):
                    terms.append(preference)
        candidates = [n for n in pool if all(w in tokens[n] for w in terms)]
        if not candidates or not terms and not owner:
            return None
        pick = min(candidates, key=lambda n: (np.linalg.norm(api.pos(n) - api.pos(near)) if near else 0,
                                             len(tokens[n]), n))
        selector = {"kind": catalog[pick]["kind"], "terms": list(dict.fromkeys(terms))}
        if owner:
            selector["parent"] = owner
        if near:
            selector["near"] = near
        return pick, selector

    def nominate(result):
        if not result:
            return None
        name, sel = result
        matches = [n for n in catalog if catalog[n]["kind"] == sel["kind"]
                   and all(w in tokens[n] for w in sel["terms"])
                   and ("parent" not in sel or catalog[n]["parent"] == sel["parent"])]
        if matches and "near" in sel:
            name = min(matches, key=lambda n: np.linalg.norm(api.pos(n) - api.pos(sel["near"])))
        return name, sel

    def execute(op, target, item=None, **extra):
        if not target or op == "place" and not item or api.remaining() <= 0:
            return None
        roles = {"target": nominate(target)}
        if item:
            roles["item"] = nominate(item)
        step = dict(op=op, expect={r: v[1] for r, v in roles.items()}, **extra)
        step.update({r: v[0] for r, v in roles.items()})
        preview = api.preview(step)
        if preview and any(v["status"] == "unresolved" for v in preview.values()):
            return None
        if preview:
            for r, v in preview.items():
                if v.get("resolved") in catalog:
                    step[r] = v["resolved"]
        for r in roles:
            api.pos(step[r])
        return api.act(step) if api.remaining() > 0 else None

    text = api.instruction.lower().replace(".", " ; ").replace(",", " ").replace("then", ";")
    for verb in verbs:
        text = text.replace(" and " + verb + " ", " ; " + verb + " ")
    for clause in text.split(";"):
        clause = clause.strip()
        if not clause:
            continue
        ws = words(clause)
        verb = next((w for w in ws if w in verbs), "")
        body = clause.split(verb, 1)[1].strip() if verb else clause
        if verb == "pick":
            last_item = ground(body)
            continue
        if verb in ("open", "close", "shut"):
            target = ground(body, "target")
            execute("close" if verb == "shut" else verb, target)
            last_target = target or last_target
            continue
        if verb in ("turn", "switch", "push", "pull"):
            target = ground(body, "target")
            if target and catalog[target[0]]["parent"]:
                name = catalog[target[0]]["parent"]
                target = (name, {"kind": catalog[name]["kind"],
                                 "terms": [w for w in words(body) if w in tokens[name]]})
            execute("stroke", target, offset=[0, 0, 0.02],
                    delta=[0.08 if verb == "pull" or "off" in ws else -0.08, 0, 0])
            last_target = target or last_target
            continue
        splits = [(body.find(p), p) for p in (" into ", " onto ", " in ", " on ", " to ")]
        splits = [(i, p) for i, p in splits if i >= 0]
        if not splits:
            continue
        i, prep = min(splits)
        source, destination = body[:i], body[i + len(prep):]
        target = ground(("on top " if destination.startswith("top of ") else "") +
                        destination.replace("top of ", ""), "target")
        for part in source.replace("both ", "").split(" and the "):
            item = ground(part)
            if target and item:
                if "drawer" in destination:
                    execute("open", target)
                execute("place", target, item, grasps=["standard", "rim", "thin_edge"])
                last_item, last_target = item, target
