def run(api):
    import numpy as np
    catalog = api.catalog()
    names = list(catalog)
    verbs = "put place move transfer pick open close turn push pull slide".split()
    stop = "the a an both all of into inside onto on in to at up it them then and drawer compartment".split()
    colors = "black white yellow red blue green".split()
    aliases = {"porcelain": "white", "contain": "inside", "cook": "stove",
               "back": "rear", "bottom": "lower", "top": "upper"}
    def words(s):
        t = s.lower().replace("_", " ").replace("-", " ").split()
        return [aliases.get(w, w) for w in t if not w.isdigit() and w not in stop]
    def position(n):
        return np.asarray(api.pos(n), dtype=float)
    def parent(n):
        return catalog[n]["parent"]
    def drawer(n):
        return ("cabinet" in n or "drawer" in n) and catalog[n]["kind"] == "region" and "side" not in n and "init" not in n
    last = None
    held = None
    def resolve(phrase, source=False, relation="", fallback=None):
        q = words(phrase)
        if not q:
            return fallback
        candidates = [n for n in names if "init" not in n and
                      (catalog[n]["kind"] == "item" if source else True)]
        if "drawer" in phrase:
            candidates = [n for n in candidates if drawer(n)]
        if not candidates:
            return None
        positions = {n: position(n) for n in candidates}
        scores = {}
        for n in candidates:
            own = words(n)
            inherited = words(parent(n) or "")
            labels = []
            for r in names:
                if catalog[r]["kind"] != "region" or r == n:
                    continue
                if "init" in r or ("table" in r and "region" in r):
                    if set(own) & set(words(r)) and np.linalg.norm(position(r)[:2] - positions[n][:2]) < .07:
                        labels += words(r)
            lex = set(own + inherited + labels)
            spatial = ["left", "right", "front", "rear", "upper", "lower", "middle"]
            core = [w for w in q if w not in spatial and w not in ["box", "small", "large"]]
            hits = sum(w in lex for w in core)
            if core and not hits:
                continue
            score = 5 * hits - 4 * sum(w not in lex for w in core)
            score += sum(4 if w in lex else 0 for w in q if w in spatial)
            score -= sum(2 for w in colors if w in own and w not in q)
            score += .5 * sum(w in own for w in q)
            for w, axis, sign in [("left", 0, -1), ("right", 0, 1), ("front", 1, -1), ("rear", 1, 1)]:
                if w in q:
                    score += sign * float(positions[n][axis])
            if not source:
                score += 2 * (catalog[n]["kind"] == "region")
                score += 3 * ("contain" in n and relation in ["in", "into", "inside"])
                score += 4 * ("top_side" in n and relation in ["on", "onto", "on top of"])
            scores[n] = score
        return max(scores, key=scores.get) if scores and max(scores.values()) > 0 else None
    def destination(n, relation):
        if n is None:
            return None
        if relation == "on top of" and catalog[n]["kind"] == "region":
            n = parent(n) or n
        children = [r for r in names if parent(r) == n and catalog[r]["kind"] == "region" and "init" not in r]
        preferred = [r for r in children if ("contain" in r if relation in ["in", "into", "inside"] else "top_side" in r or "cook" in r)]
        return preferred[0] if len(preferred) == 1 else n
    text = api.instruction.lower().replace(",", " and ").replace(".", " ").replace(";", " and ")
    clauses = []
    for token in text.split():
        if token in verbs:
            clauses.append([token])
        elif clauses:
            clauses[-1].append(token)
    for tokens in clauses:
        if api.remaining() <= 0:
            break
        op, phrase = tokens[0], " ".join(tokens[1:]).strip()
        while phrase.split() and phrase.split()[-1] in ["and", "then"]:
            phrase = " ".join(phrase.split()[:-1])
        if op == "pick":
            held = resolve(phrase, True, fallback=held)
            continue
        if op in ["put", "place", "move", "transfer"]:
            split = next(((r, phrase.split(" " + r + " ", 1)) for r in ["on top of", "inside", "into", "onto", "in", "on", "to"] if " " + r + " " in phrase), None)
            if split is None:
                continue
            relation, (src, dst) = split
            target = destination(resolve(dst, relation=relation, fallback=last), relation)
            parts = src.replace("both ", "").split(" and the ")
            if len(parts) == 1 and " and " in src and not any(w in colors for w in words(src)):
                parts = src.replace("both ", "").split(" and ")
            items = [resolve(s, True, fallback=held) for s in parts]
            if target is None or any(n is None for n in items):
                continue
            if drawer(target) and api.remaining() > 0:
                position(target)
                api.act({"op": "open", "target": target})
            for item in dict.fromkeys(items):
                for grasp in (["thin_edge", "standard", "rim"] if "book" in item else ["standard", "rim", "thin_edge"]):
                    if api.remaining() <= 0 or item == target:
                        break
                    position(item), position(target)
                    receipt = api.act({"op": "place", "item": item, "target": target, "grasps": [grasp]})
                    position(item), position(target)
                    if receipt.get("executed") and (receipt.get("max_lift") is None or receipt["max_lift"] > .015):
                        break
                held = item
            last = target
        else:
            target = resolve(phrase.replace("on ", "").replace("off ", ""), fallback=last)
            if target is None or api.remaining() <= 0:
                continue
            position(target)
            if op in ["open", "close"] and drawer(target):
                api.act({"op": op, "target": target})
            elif op in ["turn", "push", "pull", "slide"]:
                direction = np.array([0., -.12 if op == "pull" else .12, 0.])
                for word, vector in [("left", [-.12, 0, 0]), ("right", [.12, 0, 0]), ("forward", [0, -.12, 0]), ("back", [0, .12, 0])]:
                    if word in phrase.split():
                        direction = np.array(vector)
                if op == "turn":
                    direction = np.array([0., -.06 if "off" in phrase.split() else .06, 0.])
                api.act({"op": "stroke", "target": target, "offset": (-direction / 2).tolist(), "delta": direction.tolist()})
            last = target
