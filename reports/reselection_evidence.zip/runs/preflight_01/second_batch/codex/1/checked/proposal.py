def run(api):
    import numpy as np
    cat = api.catalog()
    words = lambda s: [w for w in s.lower().replace("_", " ").split() if w.isalpha()]
    vocab = {w for n in cat for w in words(n)}
    aliases = {"cup": "mug", "cups": "mug", "books": "book", "bowls": "bowl",
               "compartment": "contain", "inside": "contain", "basket": "basket",
               "upper": "top", "lower": "bottom", "rear": "back", "center": "middle"}
    skip = set("the a an both all it them its into in on onto at of to from up down "
               "put place move set take pick drawer compartment box and nearest closest".split())
    directions = set("left right front back top bottom middle".split())
    memory = {"item": None, "target": None}
    def pos(n):
        return np.asarray(api.pos(n), dtype=float)
    def resolve(phrase, role, relation=""):
        raw = words(phrase)
        if not raw or all(w in skip for w in raw):
            return memory[role] if any(w in raw for w in ("it", "them")) else None
        ws = [aliases.get(w, w) for w in raw]
        spatial = [w for w in ws if w in directions]
        terms = list(dict.fromkeys(w for w in ws if w in vocab and w not in skip | directions))
        if not terms:
            return None
        region_request = role == "target" and (
            "drawer" in raw or "compartment" in raw or relation == "on top of")
        base_terms = [w for w in terms if w not in ("contain", "region")]
        base = [n for n, d in cat.items() if d["kind"] != "region"
                and all(w in words(n) for w in base_terms)]
        candidates = [n for n in base if cat[n]["kind"] == "item"] if role == "item" else base
        selector = None
        if role == "target" and len(base) == 1:
            owner = base[0]
            regions = [n for n, d in cat.items() if d["kind"] == "region" and d["parent"] == owner]
            desired = spatial[:] if region_request else []
            if relation == "on top of":
                desired = ["top", "side"]
            elif "compartment" in raw or relation in ("in", "into", "inside"):
                if "drawer" not in raw:
                    desired += ["contain"] if any("contain" in words(n) for n in regions) else ["inner"]
            elif any("cook" in words(n) for n in regions):
                desired = ["cook"]
            if desired or region_request:
                candidates = [n for n in regions if all(w in words(n) for w in desired)]
                selector = {"kind": "region", "terms": desired, "parent": owner}
        if not candidates:
            return None
        if selector is None:
            kinds = {cat[n]["kind"] for n in candidates}
            if len(kinds) != 1:
                return None
            selector = {"kind": cat[candidates[0]]["kind"], "terms": base_terms}
            if spatial:
                anchors = [n for n in cat if cat[n]["kind"] == "region"
                           and all(w in words(n) for w in base_terms + spatial)]
                if len(anchors) == 1:
                    selector["near"] = anchors[0]
                    candidates.sort(key=lambda n: float(np.linalg.norm(pos(n) - pos(anchors[0]))))
                elif len(spatial) == 1:
                    axis, rank = {"left": ("x", "min"), "right": ("x", "max"),
                                  "front": ("y", "min"), "back": ("y", "max"),
                                  "top": ("z", "max"), "bottom": ("z", "min"),
                                  "middle": ("z", "median")}[spatial[0]]
                    selector.update(axis=axis, rank=rank)
                    candidates.sort(key=lambda n: float(pos(n)["xyz".index(axis)]))
                    candidates = [candidates[len(candidates)//2] if rank == "median"
                                  else candidates[-1 if rank == "max" else 0]]
                else:
                    return None
        return candidates[0], selector
    def execute(op, roles, **extra):
        if api.remaining() <= 0 or any(v is None for v in roles.values()):
            return None
        step = dict(op=op, expect={r: v[1] for r, v in roles.items()}, **extra)
        step.update({r: v[0] for r, v in roles.items()})
        for v in roles.values():
            pos(v[0])
        checked = api.preview(step)
        if checked and any(v.get("status") == "unresolved" for v in checked.values()):
            return None
        if checked:
            for r, v in checked.items():
                if r in roles and v.get("status") in ("confirmed", "corrected") and v.get("pick") in cat:
                    step[r] = v["pick"]
        return api.act(step) if api.remaining() > 0 else None
    text = api.instruction.lower().replace(".", ";").replace(",", " and ").replace("then ", "")
    for verb in ("put", "place", "move", "set", "open", "close", "turn", "push", "pull", "pick"):
        text = text.replace(" and " + verb + " ", ";" + verb + " ")
    for clause in text.split(";"):
        clause = clause.strip()
        if not clause:
            continue
        verb, _, body = clause.partition(" ")
        if verb == "pick":
            memory["item"] = resolve(body.replace("up ", "", 1), "item")
        elif verb in ("open", "close", "turn", "push", "pull"):
            target = resolve(body.replace("on ", "", 1).replace("off ", "", 1), "target")
            if target is None and body.strip() == "it":
                target = memory["target"]
            if verb in ("open", "close"):
                execute(verb, {"target": target})
            else:
                execute("stroke", {"target": target}, offset=[0, 0, 0.02],
                        delta=[0, -0.08 if verb == "pull" or "off" in body.split() else 0.08, 0])
            memory["target"] = target
        elif verb in ("put", "place", "move", "set"):
            parts = next(((body.split(" " + r + " ", 1), r) for r in
                          ("on top of", "into", "inside", "onto", "in", "on")
                          if " " + r + " " in body), None)
            if parts is None:
                continue
            (source, destination), relation = parts
            target = resolve(destination, "target", relation)
            whole = resolve(source, "item")
            sources = [source] if whole else source.replace("both ", "", 1).split(" and ")
            for phrase in sources:
                item = resolve(phrase, "item")
                receipt = execute("place", {"item": item, "target": target},
                                  grasps=["standard", "rim", "thin_edge"])
                if receipt and receipt.get("executed") and item and target:
                    pos(item[0]), pos(target[0]), api.remaining()
                memory.update(item=item, target=target)
