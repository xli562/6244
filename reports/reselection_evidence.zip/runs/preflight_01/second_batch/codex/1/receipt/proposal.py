def run(api):
    import numpy as np
    cat = api.catalog()
    last_item, last_target, pending = None, None, ""
    noise = set("the a an both of object item box up please into onto inside compartment drawer".split())
    directions = {"left": (0, -1), "right": (0, 1), "front": (1, -1),
                  "back": (1, 1), "bottom": (2, -1), "top": (2, 1)}
    def words(s):
        s = s.lower().replace("_", " ").replace("-", " ")
        for a, b in [("saucepan", "pan"), ("frypan", "pan"), ("porcelain", "white"),
                     ("contain", "in"), ("upper", "top"), ("lower", "bottom")]:
            s = s.replace(a, b)
        return [w for w in s.split() if w not in noise and not w.isdigit()]
    def positions():
        return {n: np.asarray(api.pos(n), dtype=float) for n in cat}
    def resolve(phrase, target=False, prep=""):
        p = phrase.strip()
        if not p:
            return None
        if p in ("it", "them", "there", "that"):
            n = last_target if target else last_item
            if target and prep in ("on", "on top of") and n:
                n = cat[n]["parent"] or n
            p = n or ""
        q = set(words(p))
        if not q:
            return None
        xyz = positions()
        reference, relation = None, None
        for marker in ("to the left of", "to the right of", "in front of", "behind", "near"):
            if marker in p:
                lhs, rhs = p.split(marker, 1)
                reference, relation = resolve(rhs), marker
                q = set(words(lhs))
                break
        candidates = []
        for n, info in cat.items():
            if "init_region" in n or (not target and info["kind"] != "item"):
                continue
            parent = info["parent"]
            tags = set(words(n + " " + (parent or "")))
            core = q - set(directions) - {"middle", "in", "on", "side"}
            if not core or not (core & tags):
                continue
            score = 6 * len(core & tags) - 5 * len(core - tags)
            colors = set("white black yellow red blue green brown orange".split())
            score -= 2 * len((tags & colors) - q)
            score += 3 * len(q & tags & (set(directions) | {"middle"}))
            if target:
                region = info["kind"] == "region"
                score += 3 * region - 2 * ("region" in n and "init" in n)
                score += 5 * ("drawer" in p and region and "side" not in n)
                score += 5 * (prep in ("on", "on top of") and "top_side" in n)
                score += 3 * (prep in ("in", "inside", "into") and "contain" in n)
            for d, (axis, sign) in directions.items():
                if d in q and d not in tags:
                    score += sign * float(xyz[n][axis])
                    nearby = [r for r in cat if "region" in r and d in words(r)
                              and bool(core & set(words(r)))]
                    if nearby:
                        score += 3 * np.exp(-20 * min(np.linalg.norm(xyz[n] - xyz[r]) for r in nearby))
            if reference:
                diff = xyz[n] - xyz[reference]
                score += (-8 * np.linalg.norm(diff) if relation == "near" else
                          4 * np.tanh(10 * diff[0 if "left" in relation or "right" in relation else 1]
                                      * (-1 if "left" in relation or "front" in relation else 1)))
                score -= 20 * (n == reference)
            candidates.append((float(score), n))
        return max(candidates)[1] if candidates else None
    text = api.instruction.lower().replace(".", " ; ").replace(",", " and ").replace("then ", "")
    verbs = ("put ", "place ", "move ", "pick ", "open ", "close ", "turn ", "push ", "pull ")
    for v in verbs:
        text = text.replace(" and " + v, " ; " + v)
    for clause in text.split(";"):
        clause = clause.strip()
        if not clause or api.remaining() <= 0:
            continue
        if clause.startswith("pick "):
            pending = clause.replace("pick up ", "", 1)
            last_item = resolve(pending)
            continue
        op = clause.split()[0]
        if op in ("put", "place", "move"):
            body = clause.split(" ", 1)[1]
            choices = [(body.find(" " + p + " "), p) for p in ("on top of", "into", "onto", "inside", "in", "on")]
            choices = sorted((i, -len(p), p) for i, p in choices if i >= 0)
            if not choices:
                continue
            i, _, prep = choices[0]
            source, destination = body[:i], body[i + len(prep) + 2:]
            target = resolve(destination, True, prep)
            parts = source.replace("both ", "").split(" and ")
            if len(parts) > 1 and not any(w in set(words(parts[0])) for w in "bowl mug cup book plate soup cheese sauce butter bottle pot pan pudding milk juice".split()):
                parts = [source]
            for part in parts:
                item = resolve(pending if part.strip() == "it" and pending else part)
                if not item or not target or item == target or api.remaining() <= 0:
                    continue
                positions()
                grasps = ["thin_edge", "standard", "rim"] if "book" in item else ["standard", "rim", "thin_edge"]
                receipt = api.act({"op": "place", "item": item, "target": target, "grasps": grasps})
                positions()
                last_item, last_target, pending = item, target, ""
        elif op in ("open", "close"):
            target = resolve(clause.split(" ", 1)[1], True)
            if target and cat[target]["kind"] == "region" and api.remaining() > 0:
                positions()
                receipt = api.act({"op": op, "target": target})
                positions()
                last_target = target
        elif op in ("turn", "push", "pull"):
            phrase = clause.split(" ", 1)[1].replace("on ", "").replace("off ", "")
            target = resolve(phrase, True)
            if target and api.remaining() > 0:
                offset, delta = [0, -0.10, 0.02], [0.08, 0, 0]
                if op in ("push", "pull"):
                    offset, delta = [0, -0.04, 0], [0, 0.12 if op == "push" else -0.12, 0]
                elif "off" in clause:
                    delta[0] *= -1
                positions()
                receipt = api.act({"op": "stroke", "target": target, "offset": offset, "delta": delta})
                positions()
                last_target = target
