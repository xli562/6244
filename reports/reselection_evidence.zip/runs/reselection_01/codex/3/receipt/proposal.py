def run(api):
    import numpy as np
    cat = api.catalog()
    last, held, opened = None, [], set()
    def norm(s):
        s = s.lower()
        for a, b in [('pick up', 'pick'), ('on top of', 'on'), ('inside', 'in'),
                     ('into', 'in'), ('onto', 'on'), ('compartment', 'region'),
                     ('drawer', 'region'), ('porcelain', 'white'), ('frypan', 'pan')]:
            s = s.replace(a, b)
        for c in '_,.;:!?':
            s = s.replace(c, ' ')
        return ' '.join(s.split())
    stop = set('the a an both all of it them there and box in on to region side contain init put place move set pick open close turn switch'.split())
    directions = {'left': (0, -1), 'right': (0, 1), 'front': (1, -1),
                  'back': (1, 1), 'bottom': (2, -1), 'top': (2, 1)}
    def words(s):
        return set(norm(s).split()) - stop - set(directions)
    def positions():
        return {n: np.asarray(api.pos(n), dtype=float) for n in cat}
    def resolve(text, target=False):
        text = norm(text)
        if text in ('it', 'them', 'there'):
            return last if target else (held[0] if held else None)
        if not text:
            return None
        p, reference, relation = positions(), None, None
        for rel in ('nearest to', 'closest to', 'next to', 'near', 'left of', 'right of', 'behind'):
            if ' ' + rel + ' ' in text:
                text, tail = text.split(' ' + rel + ' ', 1)
                reference, relation = resolve(tail, True), rel
                break
        w = words(text)
        candidates = [n for n in cat if (target or cat[n]['kind'] == 'item') and n != reference]
        scored = []
        for n in candidates:
            label, parent = norm(n), cat[n]['parent']
            tokens = words(n) | (words(parent) if parent else set())
            overlap = len(w & tokens)
            if not w or not overlap:
                continue
            score = 5 * overlap - 2 * len(w - tokens)
            if target:
                score += 1.5 * (cat[n]['kind'] == 'region') - 5 * ('init' in label.split())
                score += 2 * ('contain' in label.split() and 'region' not in text.split())
                score += 3 * ('side' in label.split() and 'top' in text.split())
            for d, (axis, sign) in directions.items():
                if d in text.split():
                    score += 5 * (d in label.split())
                    score += sign * float(p[n][axis]) / (1 + abs(float(p[n][axis])))
            if reference:
                delta = p[n] - p[reference]
                score -= float(np.linalg.norm(delta))
                if relation in ('left of', 'right of', 'behind'):
                    axis, sign = {'left of': (0, -1), 'right of': (0, 1), 'behind': (1, 1)}[relation]
                    score -= 8 * (sign * delta[axis] <= 0)
            scored.append((score, n))
        return max(scored)[1] if scored else None
    def act(step):
        if api.remaining() <= 0:
            return {}
        positions()
        return api.act(step)
    text = norm(api.instruction)
    for color in ('white', 'black', 'red', 'yellow', 'blue', 'green'):
        for other in ('white', 'black', 'red', 'yellow', 'blue', 'green'):
            text = text.replace(color + ' and ' + other, color + ' ' + other)
    verbs = ('put', 'place', 'move', 'set', 'pick', 'open', 'close', 'turn', 'switch', 'push', 'slide')
    for verb in verbs:
        text = text.replace(verb + ' ', '|' + verb + ' ')
    for clause in text.split('|'):
        parts = clause.strip().split()
        if not parts or parts[0] not in verbs or api.remaining() <= 0:
            continue
        verb, body = parts[0], ' '.join(parts[1:]).removesuffix(' and').removesuffix(' then').strip()
        if verb in ('open', 'close'):
            target = resolve(body, True)
            if target:
                receipt = act({'op': verb, 'target': target})
                last = target
                if receipt.get('executed'):
                    opened.add(target) if verb == 'open' else opened.discard(target)
        elif verb in ('turn', 'switch', 'push', 'slide'):
            target = resolve(body.replace('on ', '').replace('off ', ''), True)
            if target:
                act({'op': 'stroke', 'target': target, 'offset': [0, 0, 0],
                     'delta': [0, -.08 if 'off' in body.split() else .08, 0]})
                last = target
        else:
            source, dest = body, None
            for prep in (' in ', ' on ', ' to '):
                if prep in body:
                    source, dest = body.rsplit(prep, 1)
                    break
            items = held[:] if source in ('it', 'them') else [resolve(s) for s in source.split(' and ')]
            held = [n for n in items if n]
            target = resolve(dest, True) if dest else None
            if target:
                parent = cat[target]['parent'] or ''
                if 'cabinet' in norm(parent) and 'region' in norm(target).split() and target not in opened:
                    if act({'op': 'open', 'target': target}).get('executed'):
                        opened.add(target)
                for item in held:
                    if item != target:
                        grasps = ['thin_edge', 'standard', 'rim'] if 'book' in norm(item) else ['standard', 'rim', 'thin_edge']
                        act({'op': 'place', 'item': item, 'target': target, 'grasps': grasps})
                last = target
