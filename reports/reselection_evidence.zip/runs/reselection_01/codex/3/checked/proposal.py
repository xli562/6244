import numpy as np

def run(api):
    catalog = api.catalog()
    def words(s):
        for c in "_-.,;:!?":
            s = s.replace(c, " ")
        return s.lower().split()
    labels = {n: [w for w in words(n) if w.isalpha()] for n in catalog}
    vocab = {w for ws in labels.values() for w in ws}
    aliases = {"compartment": "contain", "inside": "contain", "interior": "inner",
               "upper": "top", "lower": "bottom", "rear": "back",
               "cup": "mug", "pan": "frypan", "surface": "side"}
    spatial = {"left": ("x", "min"), "right": ("x", "max"),
               "front": ("y", "min"), "back": ("y", "max"),
               "top": ("z", "max"), "bottom": ("z", "min"),
               "middle": ("z", "median")}
    ignored = set("a an the both and of from at to on in into onto it them drawer".split())
    def position(n):
        return np.asarray(api.pos(n), dtype=float)
    def resolve(description, source=False):
        raw = words(description)
        ws = [aliases.get(w, w) for w in raw]
        terms = list(dict.fromkeys(w for w in ws if w in vocab and w not in ignored))
        owners = [n for n in catalog if catalog[n]["kind"] == "fixture"
                  and set(labels[n]) & set(terms)]
        owner = max(owners, key=lambda n: len(set(labels[n]) & set(terms)), default=None)
        region = not source and (owner is not None or "drawer" in raw or "compartment" in raw)
        kind = "item" if source else ("region" if region else "item")
        candidates = [n for n in catalog if catalog[n]["kind"] == kind
                      and "init" not in labels[n]
                      and (not region or not owner or catalog[n]["parent"] == owner)]
        if not candidates and not source and owner and not region:
            candidates, kind = [owner], "fixture"
        if not candidates or not terms:
            return None
        def score(n):
            return len(set(labels[n]) & set(terms)), -len(set(labels[n]) - set(terms))
        pick = max(candidates, key=score)
        if score(pick)[0] == 0:
            return None
        semantic = [w for w in terms if w in labels[pick]]
        direction = next((w for w in ws if w in spatial), None)
        selector = {"kind": kind, "terms": semantic}
        if region and owner:
            selector["parent"] = owner
        pool = [n for n in candidates if all(w in labels[n] for w in semantic)]
        if direction and (source or direction not in labels[pick]):
            base = [w for w in semantic if w not in spatial]
            anchors = [n for n in catalog if catalog[n]["kind"] == "region"
                       and direction in labels[n] and any(w in labels[n] for w in base)]
            if len(anchors) == 1:
                selector["near"] = anchors[0]
                pick = min(pool, key=lambda n: np.linalg.norm(position(n) - position(anchors[0])))
            else:
                axis, rank = spatial[direction]
                selector.update(axis=axis, rank=rank)
                ordered = sorted(pool, key=lambda n: position(n)["xyz".index(axis)])
                pick = ordered[0 if rank == "min" else -1 if rank == "max" else len(ordered)//2]
        return pick, selector
    def execute(op, roles, **extra):
        if api.remaining() <= 0 or any(value is None for value in roles.values()):
            return False
        step = dict(op=op, expect={r: v[1] for r, v in roles.items()}, **extra)
        step.update({r: v[0] for r, v in roles.items()})
        evidence = api.preview(step)
        if evidence is not None:
            for role in roles:
                report = evidence.get(role, {})
                if report.get("status") == "unresolved":
                    return False
                if report.get("resolved") in catalog:
                    step[role] = report["resolved"]
        for role in roles:
            position(step[role])
        if api.remaining() <= 0:
            return False
        return bool(api.act(step).get("executed", False))
    text = api.instruction.lower().replace("turn on", "activate").replace("turn off", "deactivate")
    for delimiter in (";", ".", ", then ", " then "):
        text = text.replace(delimiter, " and ")
    verbs = {"put", "place", "move", "set", "insert", "pick", "open", "close",
             "activate", "deactivate", "push", "slide"}
    clauses = []
    for fragment in text.split(" and "):
        fragment = fragment.strip()
        if fragment and (not clauses or fragment.split()[0] in verbs):
            clauses.append(fragment)
        elif fragment:
            clauses[-1] += " and " + fragment
    held, last_target, last_owner = "", "", ""
    for clause in clauses:
        bits = clause.split(maxsplit=1)
        if len(bits) != 2:
            continue
        verb, body = bits
        if verb == "pick":
            held = body.removeprefix("up ").strip()
            continue
        if verb in ("open", "close", "activate", "deactivate", "push", "slide"):
            description = last_target if body.strip() == "it" else body
            target = resolve(description)
            if verb in ("open", "close"):
                if execute(verb, {"target": target}):
                    last_target = description
                    last_owner = catalog[target[0]]["parent"] or description
            elif target:
                execute("stroke", {"target": target}, offset=[0, 0, .02],
                        delta=[0, .06 if verb != "deactivate" else -.06, 0])
            continue
        split = None
        for preposition in (" into ", " onto ", " in ", " on ", " to "):
            if preposition in body:
                left, right = body.rsplit(preposition, 1)
                if split is None or len(left) > len(split[0]):
                    split = left, right
        if split is None:
            continue
        source_text, destination = split
        source_text = held if source_text.strip() in ("it", "them") else source_text
        destination = destination.replace("it", last_owner or last_target) if "it" in destination.split() else destination
        target = resolve(destination)
        if not target:
            continue
        sources = source_text.replace("both ", "").split(" and ")
        if len(sources) > 1 and any(resolve(s, True) is None for s in sources):
            sources = [source_text]
        if "drawer" in words(destination):
            if not execute("open", {"target": target}):
                continue
        for source in sources:
            item = resolve(source, True)
            if execute("place", {"item": item, "target": target},
                       grasps=["standard", "rim", "thin_edge"]):
                held, last_target = source, destination
                last_owner = catalog[target[0]]["parent"] or destination


def reread(instruction, step, role):
    lower = instruction.lower()
    verbs = ("put ", "place ", "move ", "set ", "insert ", "open ", "close ",
             "push ", "slide ", "turn on ", "turn off ")
    starts = [i for i in range(len(lower)) if (i == 0 or lower[i-1] in " ,;.")
              and any(lower.startswith(v, i) for v in verbs)]
    quotes = []
    terms = step.get("expect", {}).get(role, {}).get("terms", [])
    for j, start in enumerate(starts):
        end = starts[j+1] if j+1 < len(starts) else len(instruction)
        verb = next(v for v in verbs if lower.startswith(v, start))
        a, b = start + len(verb), end
        while b > a and instruction[b-1] in " ,;.":
            b -= 1
        for tail in (" and then", " and", " then"):
            if lower[a:b].endswith(tail):
                b -= len(tail)
        separators = [(lower.rfind(p, a, b), len(p)) for p in
                      (" into ", " onto ", " in ", " on ", " to ")]
        cut, width = max(separators)
        if cut >= a:
            a, b = (a, cut) if role == "item" else (cut + width, b)
        elif role == "item" or step.get("op") == "place":
            continue
        quote = instruction[a:b].strip()
        tokens = quote.lower().replace("-", " ").split()
        score = sum(t in tokens for t in terms)
        if quote and score:
            quotes.append((score, quote))
    best = max((s for s, q in quotes), default=0)
    winners = list(dict.fromkeys(q for s, q in quotes if s == best))
    return winners[0] if len(winners) == 1 else ""
