import numpy as np

def _clauses(text):
    verbs = {'put', 'place', 'move', 'transfer', 'insert', 'open', 'close', 'turn', 'push', 'slide', 'pick'}
    words, spans, cursor = text.split(), [], 0
    for word in words:
        start = text.find(word, cursor); spans.append((start, start + len(word))); cursor = start + len(word)
    starts = [i for i, w in enumerate(words) if w.lower().strip('.,;') in verbs]
    for j, i in enumerate(starts):
        end = spans[starts[j + 1]][0] if j + 1 < len(starts) else len(text)
        body = text[spans[i][1]:end].strip(' ,.;')
        while body.lower().endswith((' and', ' then')):
            body = body.rsplit(' ', 1)[0].rstrip(' ,;')
        yield words[i].lower(), body

def _roles(body):
    low = body.lower(); found = []
    for prep in (' on top of ', ' into ', ' inside ', ' onto ', ' in ', ' on '):
        at = low.rfind(prep)
        if at >= 0:
            found.append((at, len(prep)))
    if not found:
        return body, ''
    at, size = max(found)
    return body[:at].strip(), body[at:].strip()

def reread(instruction, step, role):
    quotes = []
    operation = step.get('op', '')
    for verb, body in _clauses(instruction):
        if operation == 'place' and verb not in ('put', 'place', 'move', 'transfer', 'insert'):
            continue
        if operation in ('open', 'close') and verb != operation:
            continue
        if operation == 'stroke' and verb not in ('turn', 'push', 'slide'):
            continue
        source, target = _roles(body) if operation == 'place' else ('', body)
        quote = source if role == 'item' else target
        meaningful = quote.lower().replace('.', '').split()
        if quote and not any(w in ('it', 'them', 'this', 'that') for w in meaningful):
            quotes.append(quote)
    if len(quotes) == 1:
        return quotes[0]
    terms = step.get('expect', {}).get(role, {}).get('terms', [])
    scored = [(sum(t in q.lower().replace('_', ' ').split() for t in terms), q) for q in quotes]
    scored.sort(reverse=True)
    return scored[0][1] if scored and scored[0][0] > 0 and (len(scored) == 1 or scored[0][0] > scored[1][0]) else ''

def run(api):
    catalog = api.catalog()
    tokens = {n: [w for w in n.lower().split('_') if w.isalpha()] for n in catalog}
    vocabulary = {w for ws in tokens.values() for w in ws}
    aliases = {'cup': 'mug', 'compartment': 'contain', 'inside': 'contain', 'interior': 'contain',
               'upper': 'top', 'lower': 'bottom', 'rear': 'back', 'frontmost': 'front',
               'leftmost': 'left', 'rightmost': 'right', 'centre': 'middle', 'center': 'middle'}
    spatial = {'left': ('x', 'min'), 'right': ('x', 'max'), 'front': ('y', 'min'),
               'back': ('y', 'max'), 'top': ('z', 'max'), 'bottom': ('z', 'min'),
               'middle': ('z', 'median')}
    ignored = {'the', 'a', 'an', 'both', 'of', 'to', 'on', 'in', 'up', 'and', 'it', 'them', 'box'}
    last_source, last_target = '', ''

    def resolve(phrase, role, surface=False):
        raw = phrase.lower().replace('-', ' ').replace(',', ' ').replace('.', ' ').split()
        words = [aliases.get(w, w) if w not in vocabulary else w for w in raw]
        direction = next((w for w in words if w in spatial), None)
        terms = list(dict.fromkeys(w for w in words if w in vocabulary and w not in ignored and w not in spatial and w not in ('region', 'contain', 'side')))
        if not terms:
            return None
        candidates = [n for n in catalog if catalog[n]['kind'] != 'region' and (role != 'item' or catalog[n]['kind'] == 'item') and all(t in tokens[n] for t in terms)]
        if not candidates:
            return None
        anchors = [n for n in catalog if catalog[n]['kind'] == 'region' and direction in tokens[n] and all(t in tokens[n] for t in terms)] if direction else []
        selector = {'terms': terms}
        if len(anchors) == 1:
            selector['near'] = anchors[0]
            candidates.sort(key=lambda n: float(np.linalg.norm(api.pos(n) - api.pos(anchors[0]))))
        elif direction:
            axis, rank = spatial[direction]; selector.update(axis=axis, rank=rank)
            candidates.sort(key=lambda n: float(api.pos(n)['xyz'.index(axis)]))
            candidates = [candidates[-1] if rank == 'max' else candidates[len(candidates)//2] if rank == 'median' else candidates[0]]
        chosen = candidates[0]; selector['kind'] = catalog[chosen]['kind']
        if role == 'target':
            regions = [n for n in catalog if catalog[n]['kind'] == 'region' and catalog[n]['parent'] == chosen and 'init' not in tokens[n]]
            wanted = ['top', 'side'] if surface else [direction] if direction and any(w in raw for w in ('drawer', 'compartment')) else ['contain'] if any(w in raw for w in ('in', 'into', 'inside', 'compartment', 'basket')) else ['cook'] if 'stove' in words else []
            matching = [n for n in regions if all(w in tokens[n] for w in wanted)] if wanted else regions
            if len(matching) == 1:
                chosen = matching[0]
                selector = {'kind': 'region', 'terms': wanted or ['region'], 'parent': catalog[chosen]['parent']}
        return chosen, selector

    def execute(step):
        if api.remaining() <= 0:
            return False
        for role in step['expect']:
            api.pos(step[role])
        evidence = api.preview(step)
        if evidence is not None and any(v.get('status') == 'unresolved' for v in evidence.values()):
            return False
        if api.remaining() <= 0:
            return False
        receipt = api.act(step)
        for role in step['expect']:
            api.pos(step[role])
        api.remaining()
        return bool(receipt.get('executed'))

    for verb, body in _clauses(api.instruction):
        low = body.lower()
        if verb == 'pick':
            last_source = body[3:] if low.startswith('up ') else body
            continue
        placing = verb in ('put', 'place', 'move', 'transfer', 'insert')
        source, target = _roles(body) if placing else ('', body)
        if placing and not target:
            return
        if source.lower().strip() in ('it', 'them'):
            source = last_source
        surface = 'on top of' in target.lower()
        if 'it' in target.lower().split():
            target = ' '.join(last_target if w.lower() == 'it' else w for w in target.split())
        if surface:
            target = target.replace('drawer', '').replace('compartment', '')
        destination = resolve(target, 'target', surface)
        if destination is None:
            return
        name, constraint = destination
        if not placing:
            step = {'op': verb if verb in ('open', 'close') else 'stroke', 'target': name, 'expect': {'target': constraint}}
            if step['op'] == 'stroke':
                step.update(offset=[0., 0., .03], delta=[0., -.08 if 'off' in low else .08, 0.])
            if not execute(step):
                return
            last_target = target
            continue
        pieces = source.replace('both ', '').split(' and ')
        if len(pieces) > 1 and not all(resolve(p, 'item') for p in pieces):
            pieces = [source]
        for phrase in pieces:
            item = resolve(phrase, 'item')
            if item is None:
                return
            parent = catalog[name]['parent']
            if 'drawer' in target.lower().split() and parent and np.linalg.norm((api.pos(name) - api.pos(parent))[:2]) < .12:
                if not execute({'op': 'open', 'target': name, 'expect': {'target': constraint}}):
                    return
            grasps = ['thin_edge', 'standard', 'rim'] if 'book' in tokens[item[0]] else ['standard', 'rim', 'thin_edge']
            if not execute({'op': 'place', 'item': item[0], 'target': name, 'grasps': grasps, 'expect': {'item': item[1], 'target': constraint}}):
                return
        last_source, last_target = source, target
