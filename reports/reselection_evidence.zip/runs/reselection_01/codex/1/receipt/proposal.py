import numpy as np

def run(api):
    catalog = api.catalog()
    def words(s):
        for a, b in [("_", " "), ("-", " "), (",", " "), (".", " "),
                     ("onto", "on"), ("into", "in"), ("cup", "mug"),
                     ("compartment", "region"), ("drawer", "region")]:
            s = s.lower().replace(a, b)
        return [w for w in s.split() if not w.isdigit()]
    stop = "the a an both and of to up it them this that please box object".split()
    spatial = "left right front back top bottom middle nearest farthest".split()
    def tokens(s):
        return [w for w in words(s) if w not in stop]
    def position(n):
        return np.asarray(api.pos(n), dtype=float)
    def resolve(text, destination=False, fallback=None):
        q = tokens(text)
        if not q:
            return fallback
        relation, reference = None, None
        for marker in [" near ", " next to ", " left of ", " right of ",
                       " in front of ", " behind "]:
            if marker in " " + text:
                base, ref = (" " + text).split(marker, 1)
                reference = resolve(ref)
                q, relation = tokens(base), marker.strip()
                break
        candidates = []
        for n, meta in catalog.items():
            if "init_region" in n or (not destination and meta["kind"] != "item"):
                continue
            t = tokens(n)
            if "porcelain" in t:
                t += ["white", "mug"]
            if meta["parent"] in catalog:
                t += tokens(meta["parent"])
            identity = [w for w in q if w not in spatial + ["in", "on", "region"]]
            hits = sum(w in t for w in identity)
            if identity and not hits:
                continue
            if not identity and not any(w in t for w in q):
                continue
            score = 5 * hits - 3 * sum(w not in t for w in identity)
            score += 3 * sum(w in t for w in q if w in spatial)
            score -= 2 * sum(w in t and w not in q for w in ["red", "black", "yellow", "white"])
            if destination:
                score += (2 if meta["kind"] == "region" else 0)
                score += 4 * ("on" in q and "top_side" in n)
                score += 3 * ("in" in q and "contain" in t)
                score -= 4 * ("on" in q and "contain" in t)
            p = position(n)
            if reference is not None:
                d = p - position(reference)
                score -= float(np.linalg.norm(d))
                if relation in ["left of", "right of", "in front of", "behind"]:
                    axis, sign = (0, -1) if relation == "left of" else (
                        (0, 1) if relation == "right of" else (1, -1 if relation == "in front of" else 1))
                    score += 4 if sign * d[axis] > 0 else -8
            for w, axis, sign in [("left", 0, -1), ("right", 0, 1),
                                  ("front", 1, -1), ("back", 1, 1),
                                  ("top", 2, 1), ("bottom", 2, -1)]:
                if w in q and w not in t:
                    score += sign * float(p[axis])
            candidates.append((score, n))
        return max(candidates)[1] if candidates else None
    def act(step):
        if api.remaining() <= 0:
            return None
        for key in ["item", "target"]:
            if key in step:
                position(step[key])
        receipt = api.act(step)
        for key in ["item", "target"]:
            if key in step:
                position(step[key])
        api.remaining()
        return receipt
    text = " " + api.instruction.lower()
    for a, b in [("pick up", "pick"), ("place", "put"), ("set ", "put "),
                 ("then", "and"), (";", " and "), ("turn on", "activate"),
                 ("turn off", "deactivate"), ("switch on", "activate"),
                 ("switch off", "deactivate")]:
        text = text.replace(a, b)
    for verb in ["pick", "put", "open", "close", "activate", "deactivate", "push"]:
        text = text.replace(" " + verb + " ", "|" + verb + " ")
    held, last_target, opened = None, None, {}
    for clause in text.split("|"):
        parts = clause.strip(" ,.;").split()
        if not parts or api.remaining() <= 0:
            continue
        verb, body = parts[0], " ".join(parts[1:]).strip(" ,.;")
        while body.endswith(" and"):
            body = body[:-4]
        if verb == "pick":
            held = resolve(body, fallback=held)
        elif verb == "put":
            body = body.replace(" onto ", " on ").replace(" into ", " in ")
            cuts = [(body.rfind(" " + p + " "), p) for p in ["in", "on", "inside"]]
            index, prep = max(cuts)
            if index < 0:
                continue
            source, destination = body[:index], body[index + len(prep) + 2:]
            target = resolve(prep + " " + destination, True, last_target)
            if target is None:
                continue
            items = [resolve(source, fallback=held)]
            if " and " in source and not items[0]:
                items = [resolve(s) for s in source.replace("both ", "").split(" and ")]
            elif " and " in source:
                separate = [resolve(s) for s in source.replace("both ", "").split(" and ")]
                if all(separate) and len(set(separate)) > 1:
                    items = separate
            if not any(items):
                continue
            if "drawer" in destination and prep != "on" and not opened.get(target):
                receipt = act({"op": "open", "target": target})
                opened[target] = bool(receipt and receipt.get("executed"))
            for item in dict.fromkeys(items):
                if item and item != target:
                    grasps = ["thin_edge", "standard", "rim"] if "book" in item else (
                        ["rim", "standard", "thin_edge"] if "bowl" in item else ["standard", "rim", "thin_edge"])
                    act({"op": "place", "item": item, "target": target, "grasps": grasps})
                    held = item
            last_target = target
        elif verb in ["open", "close"]:
            target = resolve(body, True, last_target)
            if target:
                receipt = act({"op": verb, "target": target})
                if receipt and receipt.get("executed"):
                    opened[target] = verb == "open"
                last_target = target
        elif verb in ["activate", "deactivate", "push"]:
            target = resolve(body, True, last_target)
            if target:
                direction = [-0.10 if "left" in body else 0.10, 0, 0]
                if verb != "push":
                    direction = [0, 0.08 if verb == "activate" else -0.08, 0]
                act({"op": "stroke", "target": target,
                     "offset": [0, 0, 0], "delta": direction})
                last_target = target
