import numpy as np

def run(api):
    catalog = api.catalog()
    colors = set("black white yellow red blue green orange brown".split())
    directions = "left right front back top bottom middle".split()
    aliases = {"cup": "mug", "porcelain": "white", "cupboard": "cabinet",
               "compartment": "contain", "inside": "in", "onto": "on"}
    ignored = set("the a an both all of it them and to up object region init side".split())
    def words(text):
        for c in "_,.;:!?-":
            text = text.lower().replace(c, " ")
        return [aliases.get(w, w) for w in text.split() if not w.isdigit()]
    def position(name):
        return np.asarray(api.pos(name), dtype=float)
    def resolve(text, source=False, previous=None):
        tokens = words(text)
        if tokens and all(w in ("it", "them", "the") for w in tokens):
            return previous
        query = set(tokens) - ignored - set("in on into drawer".split())
        meaningful = query - set(directions)
        if not meaningful:
            return None
        candidates = []
        for name, meta in catalog.items():
            if source and meta["kind"] != "item":
                continue
            if "init_region" in name:
                continue
            nt = set(words(name))
            overlap = meaningful & nt
            if not overlap:
                continue
            score = 5 * len(overlap) - 2 * len(meaningful - nt)
            score -= 5 * len((nt & colors) - (query & colors))
            score += 4 * len(query & nt & set(directions))
            region = meta["kind"] == "region"
            if not source:
                wanted = ("contain" if "in" in tokens or "into" in tokens else
                          "cook" if "stove" in nt else "side")
                score += 3 * (region and wanted in nt)
                score += 5 * ("drawer" in tokens and region and "side" not in nt)
                score += 5 * ("top" in query and "side" in nt)
            score += 0.2 * (meta["kind"] == "item")
            candidates.append([name, score])
        if not candidates:
            return None
        best = max(s for _, s in candidates)
        pool = [n for n, s in candidates if s >= best - 1]
        for direction in directions:
            if direction not in query or len(pool) < 2:
                continue
            anchors = [n for n in catalog if catalog[n]["kind"] == "region"
                       and direction in words(n) and meaningful & set(words(n))]
            if anchors:
                return min(pool, key=lambda n: min(
                    np.linalg.norm(position(n) - position(a)) for a in anchors))
            axis = 0 if direction in ("left", "right") else 1 if direction in ("front", "back") else 2
            sign = -1 if direction in ("right", "back", "top") else 1
            return min(pool, key=lambda n: sign * position(n)[axis])
        return max(candidates, key=lambda pair: pair[1])[0]
    def act(step):
        if api.remaining() <= 0:
            return {}
        for key in ("item", "target"):
            if key in step:
                position(step[key])
        receipt = api.act(step)
        for key in ("item", "target"):
            if key in step:
                position(step[key])
        api.remaining()
        return receipt
    text = api.instruction.lower().replace("pick up", "pick").replace("on top of", "on top")
    verbs = set("pick put place move transfer insert set stack open close turn switch push slide press".split())
    clauses = []
    for token in text.replace(",", " ").replace(".", " ").replace("then", " ").split():
        if token in verbs:
            clauses.append([token, []])
        elif clauses:
            clauses[-1][1].append(token)
    last_item = last_target = None
    for verb, tokens in clauses:
        while tokens and tokens[-1] == "and":
            tokens.pop()
        phrase = " ".join(tokens)
        if verb == "pick":
            last_item = resolve(phrase, True, last_item)
        elif verb in ("open", "close"):
            target = resolve(phrase + (" drawer" if "it" not in tokens else ""), False, last_target)
            if target and catalog[target]["kind"] == "region":
                act({"op": verb, "target": target})
                last_target = target
        elif verb in ("turn", "switch", "push", "slide", "press"):
            target = resolve(" ".join(w for w in tokens if w not in ("on", "off")), False, last_target)
            if target:
                delta = [-0.10 if "off" in tokens else 0.10, 0, 0]
                act({"op": "stroke", "target": target, "offset": [0, -0.10, 0.02], "delta": delta})
                last_target = target
        else:
            splits = [i for i, w in enumerate(tokens) if w in ("in", "into", "on", "onto", "to")]
            if not splits:
                continue
            i = splits[-1]
            source_text, target_text = " ".join(tokens[:i]), " ".join(tokens[i:])
            target = resolve(target_text, False, last_target)
            if not target:
                continue
            parts = source_text.replace("both ", "").split(" and ")
            sources = [resolve(p, True, last_item) for p in parts]
            if None in sources:
                sources = [resolve(source_text, True, last_item)]
            for item in dict.fromkeys(sources):
                if not item or item == target:
                    continue
                grasps = ["thin_edge", "standard", "rim"] if "book" in words(item) else ["standard", "rim", "thin_edge"]
                for grasp in grasps:
                    receipt = act({"op": "place", "item": item, "target": target, "grasps": [grasp]})
                    lift = receipt.get("max_lift")
                    if not receipt.get("executed") or lift is None or lift > 0.01:
                        break
                last_item = item
            last_target = target
