import numpy as np

def run(api):
    catalog = api.catalog()
    def words(s):
        for c in "_-.,;:!?":
            s = s.replace(c, " ")
        return [w for w in s.lower().split() if w.isalpha()]
    tokens = {n: words(n) for n in catalog}
    vocabulary = {w for ts in tokens.values() for w in ts}
    aliases = {"compartment": "contain", "inside": "contain", "bottommost": "bottom",
               "upper": "top", "lower": "bottom", "rear": "back", "centre": "middle",
               "center": "middle", "stovetop": "stove", "cup": "mug"}
    spatial = {"left", "right", "front", "back", "top", "bottom", "middle"}
    stop = set("the a an both of at from on in into to onto it them drawer compartment box".split())
    last_item, last_owner, last_drawer = "", "", ""
    def resolve(phrase, source=False, mode=""):
        ws = [aliases.get(w, w) for w in words(phrase)]
        owner = None
        fixtures = [n for n in catalog if catalog[n]["kind"] == "fixture"]
        owners = [(sum(w in tokens[n] for w in ws if w not in stop | spatial), n)
                  for n in fixtures]
        if owners:
            best = max(s for s, n in owners)
            matches = [n for s, n in owners if s == best and s]
            if len(matches) == 1:
                owner = matches[0]
        kinds = ["item"] if source else ["region", "fixture", "item"]
        if mode in ("open", "close"):
            kinds = ["region"]
        if mode == "stroke":
            kinds = ["fixture", "item", "region"]
        for kind in kinds:
            pool = [n for n in catalog if catalog[n]["kind"] == kind
                    and "init" not in tokens[n]]
            if owner and kind == "region":
                pool = [n for n in pool if catalog[n]["parent"] == owner]
            available = {w for n in pool for w in tokens[n]}
            terms = list(dict.fromkeys(w for w in ws if w in available
                                       and w not in stop and (kind == "region" or w not in spatial)))
            if "white" in ws and "yellow" not in ws and "porcelain" in available:
                if not any("white" in tokens[n] and "yellow" not in tokens[n] for n in pool):
                    terms = [w for w in terms if w != "white"] + ["porcelain"]
            if kind == "region":
                desired = (["top", "side"] if "on top" in phrase else
                           ["cook"] if owner and "stove" in tokens[owner] else
                           ["contain"] if mode in ("in", "into", "inside") else [])
                terms += [w for w in desired if w in available and w not in terms]
            if not terms:
                continue
            pool = [n for n in pool if all(w in tokens[n] for w in terms)]
            if not pool:
                continue
            selector = {"kind": kind, "terms": terms}
            if owner and kind == "region":
                selector["parent"] = owner
            locations = [w for w in ws if w in spatial and w not in terms]
            anchors = [n for n in catalog if catalog[n]["kind"] == "region"
                       and all(w in tokens[n] for w in locations)
                       and any(w in tokens[n] for w in terms)]
            if locations and len(anchors) == 1:
                selector["near"] = anchors[0]
                distances = [(float(np.linalg.norm(api.pos(n) - api.pos(anchors[0]))), n) for n in pool]
                pool = [n for d, n in sorted(distances)]
                if len(distances) > 1 and abs(sorted(distances)[0][0] - sorted(distances)[1][0]) < .001:
                    return None
            elif locations:
                direction = locations[0]
                axis = "z" if direction in ("top", "bottom") else "x" if direction in ("left", "right") else "y"
                rank = "median" if direction == "middle" else "min" if direction in ("left", "front", "bottom") else "max"
                selector.update(axis=axis, rank=rank)
                pool.sort(key=lambda n: float(api.pos(n)["xyz".index(axis)]))
                pool = [pool[len(pool)//2] if rank == "median" else pool[-1] if rank == "max" else pool[0]]
            elif len(pool) != 1:
                return None
            return pool[0], selector
        return None
    def execute(step):
        if api.remaining() <= 0:
            return False
        for role in step["expect"]:
            api.pos(step[role])
        evidence = api.preview(step)
        if evidence is not None and any(v["status"] == "unresolved" for v in evidence.values()):
            return False
        if api.remaining() <= 0:
            return False
        receipt = api.act(step)
        for role in step["expect"]:
            api.pos(step[role])
        api.remaining()
        return bool(receipt["executed"])
    text = api.instruction.lower().replace(";", " and ").replace(".", " and ")
    verbs = ["put", "place", "move", "pick up", "open", "close", "turn on", "turn off", "push"]
    for verb in verbs:
        text = text.replace(" and then " + verb, "|" + verb).replace(" then " + verb, "|" + verb)
        text = text.replace(" and " + verb, "|" + verb)
    for clause in text.split("|"):
        clause = clause.strip()
        verb = next((v for v in verbs if clause.startswith(v + " ")), "")
        if not verb:
            return
        body = clause[len(verb):].strip()
        if verb == "pick up":
            last_item = body
            continue
        if verb in ("open", "close", "turn on", "turn off", "push"):
            body = last_drawer if body in ("it", "the drawer") and last_drawer else body
            op = verb if verb in ("open", "close") else "stroke"
            target = resolve(body, mode=op)
            if not target:
                return
            step = {"op": op, "target": target[0], "expect": {"target": target[1]}}
            if op == "stroke":
                step.update(offset=[0, 0, .02], delta=[0, .08 if verb != "turn off" else -.08, 0])
            if not execute(step):
                return
            if op != "stroke":
                last_drawer = body
                last_owner = catalog[target[0]]["parent"] or target[0]
            else:
                last_owner = target[0]
            continue
        separators = [" on top of ", " into ", " inside ", " onto ", " in ", " on "]
        sep = next((s for s in separators if s in body), None)
        if sep is None:
            return
        source, destination = body.split(sep, 1)
        if source.strip() in ("it", "them"):
            source = last_item
        destination = destination.replace("it", last_owner) if destination.strip() == "it" else destination
        if destination.endswith(" of it"):
            destination = destination[:-2] + last_owner
        target = resolve(("on top of " if sep == " on top of " else "") + destination, mode=sep.strip())
        if not target:
            return
        for phrase in source.replace("both ", "").split(" and "):
            item = resolve(phrase, source=True)
            if not item:
                return
            step = {"op": "place", "item": item[0], "target": target[0],
                    "grasps": ["standard", "thin_edge", "rim"] if "book" in words(phrase)
                    else ["standard", "rim", "thin_edge"],
                    "expect": {"item": item[1], "target": target[1]}}
            if not execute(step):
                return
            last_item = phrase
        last_owner = catalog[target[0]]["parent"] or target[0]
        if "drawer" in destination:
            last_drawer = destination


def reread(instruction, step, role):
    text = instruction
    lower = text.lower()
    verbs = ["put ", "place ", "move ", "pick up ", "open ", "close ",
             "turn on ", "turn off ", "push "]
    starts = [i for i in range(len(text)) if (i == 0 or lower[i-1] in " ;,.")
              and any(lower.startswith(v, i) for v in verbs)]
    quotes = []
    terms = step.get("expect", {}).get(role, {}).get("terms", [])
    for j, start in enumerate(starts):
        end = starts[j+1] if j+1 < len(starts) else len(text)
        chunk = text[start:end].strip(" ,;.")
        for tail in (" and then", " and", " then"):
            if chunk.lower().endswith(tail):
                chunk = chunk[:-len(tail)].rstrip()
        verb = next(v for v in verbs if chunk.lower().startswith(v))
        body = chunk[len(verb):]
        cuts = [(body.lower().find(s), s) for s in
                [" on top of ", " into ", " inside ", " onto ", " in ", " on "]
                if s in body.lower()]
        if step["op"] == "place" and cuts:
            i, sep = min(cuts)
            candidates = body[:i].split(" and ") if role == "item" else [body[i+len(sep):]]
        elif role == "target" and step["op"] != "place" and verb.strip() == step["op"]:
            candidates = [body]
        else:
            continue
        for candidate in candidates:
            quote = candidate.strip()
            ws = quote.lower().replace("-", " ").split()
            if terms and any(t in ws for t in terms) and quote not in quotes:
                quotes.append(quote)
    return quotes[0] if len(quotes) == 1 else ""
