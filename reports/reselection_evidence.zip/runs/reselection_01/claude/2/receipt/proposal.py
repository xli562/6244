import numpy as np

def run(api):
    cat, ALL = api.catalog(), {'item', 'fixture', 'region'}
    STOP = {'region', 'table', 'init', 'kitchen', 'living', 'room', 'study', 'floor'}
    SYN = {'white': ['porcelain'], 'compartment': ['contain'], 'pan': ['frypan'], 'skillet': ['frypan'], 'cup': ['mug'], 'burner': ['stove']}
    VERBS = {'put', 'place', 'pick', 'move', 'close', 'open', 'turn', 'push', 'slide', 'set', 'take', 'grab', 'switch', 'press', 'rotate', 'drop', 'stack'}
    MODS = {'next', 'between', 'near', 'beside', 'from', 'on', 'in', 'at', 'by', 'behind', 'under', 'inside'}
    PREPS = {'in', 'into', 'on', 'onto', 'inside'}
    DIRS = {'left': np.array([0, 1., 0]), 'right': np.array([0, -1., 0]), 'front': np.array([-1., 0, 0]), 'back': np.array([1., 0, 0])}
    P = lambda n: np.array(api.pos(n), dtype=float)
    wset = lambda ws: set(ws) | {w[:-1] for w in ws if w.endswith('s')} | {s for w in ws for s in SYN.get(w, [])}
    act = lambda step: (api.act(step) or {}) if api.remaining() > 10 else {}
    opened = set()

    def score(n, W):
        t = [x for x in n.split('_') if x not in STOP and not x.isdigit()]
        m = sum(x in W for x in t)
        return m - 0.3 * (len(t) - m) if m else -9.0

    def resolve(ws, kinds, ref=None):
        W = wset(ws)
        c = sorted((score(n, W), n) for n in cat if cat[n]['kind'] in kinds and 'init' not in n)
        if not c or c[-1][0] <= 0: return None
        ties = sorted(n for s, n in c if s > c[-1][0] - 0.05)
        if len(ties) > 1 and ref is not None: return min(ties, key=lambda n: np.linalg.norm(P(n)[:2] - ref[:2]))
        for w in ws:
            if len(ties) > 1 and w in DIRS: return max(ties, key=lambda n: float(P(n) @ DIRS[w]))
        return ties[0]

    def split(ws):
        out, cur = [], []
        for w in ws + ['and']:
            if w != 'and': cur.append(w)
            elif cur: out, cur = out + [cur], []
        return out

    def items_of(src):
        src = [w for w in src if w != 'both']
        i = next((i for i, w in enumerate(src) if w in MODS and i > 0), len(src))
        refs = [r for r in (resolve(s, ALL) for s in split([w for w in src[i + 1:] if w != 'to'])) if r]
        ref = np.mean([P(r) for r in refs], axis=0) if refs else None
        segs = split(src[:i]); got = [resolve(s, {'item'}, ref) for s in segs]
        if len(segs) > 1 and None not in got and len(set(got)) == len(got) and min(score(g, wset(s)) for g, s in zip(got, segs)) >= 0.65:
            return got
        one = resolve(src[:i], {'item'}, ref)
        return [one] if one else []

    def target(ws, last, prep):
        top = any(ws[i] == 'top' and ws[i + 1:i + 2] == ['of'] for i in range(len(ws)))
        if top: ws = [w for w in ws if w not in ('top', 'of')]
        if ('it' in ws or not ws) and last:
            t = last
            if top and cat[last]['kind'] == 'region':
                t = cat[last]['parent'] or max([m for m in cat if last.startswith(m + '_')], key=len, default=last)
        else: t = resolve(ws, {'fixture', 'item'} if top else ALL)
        if t and cat[t]['kind'] == 'region' and 'table' in t.split('_'): t = resolve(ws, {'fixture', 'item'}, P(t)) or t
        if t and cat[t]['kind'] != 'region':
            kids = [n for n in cat if cat[n]['kind'] == 'region' and 'init' not in n and (cat[n]['parent'] == t or n.startswith(t + '_'))]
            prefs = ['top_side', 'top'] if top else (['contain'] if prep in ('in', 'into', 'inside') else ['cook', 'top_side', 'contain'])
            t = next((k for p in prefs for k in kids if p in k), t)
        return t

    def drawer(t):
        p = t.split('_')
        return cat[t]['kind'] == 'region' and len(p) > 2 and p[-1] == 'region' and p[-2] in ('top', 'middle', 'bottom') and any(k in t for k in ('cabinet', 'drawer', 'dresser'))

    def place(it, t):
        g = ['standard', 'thin_edge', 'rim'] if 'book' in it else ['standard', 'rim', 'thin_edge']
        for _ in range(3):
            r = act({'op': 'place', 'item': it, 'target': t, 'grasps': g})
            if not r.get('executed'): return
            lift, gap = r.get('max_lift'), r.get('xy_gap')
            if lift is not None and lift < 0.01: g = g[1:] + g[:1]; continue
            if gap is None: gap = float(np.linalg.norm(P(it)[:2] - P(t)[:2]))
            if gap < 0.1 or api.remaining() < 60: return

    def stroke(v, ws):
        j = next((i for i, w in enumerate(ws) if w in ('to', 'toward', 'towards')), len(ws))
        t = resolve([w for w in ws[:j] if w not in DIRS], ALL)
        if not t: return None
        e = resolve([w for w in ws[j + 1:] if w not in DIRS], ALL) if j < len(ws) else None
        d, m = sum([DIRS[w] for w in ws if w in DIRS], np.zeros(3)), 0.15
        if not d.any() and e and e != t:
            d = P(e) - P(t); d[2] = 0; m = min(0.28, max(0.05, float(np.linalg.norm(d)) - 0.05))
        if not d.any(): d = np.array([0, -1., 0]) if v in ('turn', 'switch', 'rotate', 'press') else np.array([1., 0, 0])
        u = d / np.linalg.norm(d)
        act({'op': 'stroke', 'target': t, 'offset': [float(x) for x in -u * 0.08 + np.array([0, 0, 0.02])], 'delta': [float(x) for x in u * m]})
        return t

    words = api.instruction.lower().replace(',', ' ').replace('.', ' ').split()
    cls, cur = [], []
    for i, w in enumerate(words):
        if w == 'then' or (w == 'and' and words[i + 1:i + 2] and words[i + 1] in VERBS):
            if cur: cls.append(cur)
            cur = []; continue
        cur.append(w)
    cls.append(cur)
    li = lt = None
    for c in cls:
        iv = next((i for i, w in enumerate(c) if w in VERBS), -1)
        v, ws = (c[iv] if iv >= 0 else 'put'), [w for w in c[iv + 1:] if w not in ('the', 'a', 'an', 'up', 'down', 'please')]
        if v in ('open', 'close'):
            t = lt if 'it' in ws and lt else resolve(ws, {'region', 'fixture'})
            if t: act({'op': v, 'target': t}); lt = t; (opened.add(t) if v == 'open' else opened.discard(t))
        elif v in ('turn', 'switch', 'push', 'slide', 'press', 'rotate'):
            lt = stroke(v, ws) or lt
        else:
            k = max([i for i, w in enumerate(ws) if w in PREPS] + [-1]) if v not in ('pick', 'take', 'grab') else -1
            src = ws[:k] if k >= 0 else ws
            its = ([li] if li else []) if ('it' in src or 'them' in src) else items_of(src)
            if k < 0: li = its[0] if its else li; continue
            t = target(ws[k + 1:], lt, ws[k])
            if not t or not its: continue
            if drawer(t) and t not in opened: act({'op': 'open', 'target': t}); opened.add(t)
            for it in its: place(it, t)
            li, lt = its[-1], t
