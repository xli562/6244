import numpy as np

VERBS = {'put', 'place', 'pick', 'close', 'open', 'turn', 'switch', 'move', 'set', 'take', 'grab', 'lift', 'shut', 'stack', 'drop'}
HOLD = {'pick', 'take', 'grab', 'lift'}
PREPS = [' on top of ', ' into ', ' inside ', ' onto ', ' in ', ' on ']
RELS = [' between ', ' next to ', ' near ', ' beside ', ' behind ', ' from ', ' on ', ' in ', ' at ']
STOP = {'the', 'a', 'an', 'of', 'both', 'up', 'and', 'in', 'into', 'on', 'onto', 'inside', 'it', 'to', 'at', 'its'}
SYN = {'white': ['white', 'porcelain'], 'compartment': ['contain'], 'drawer': ['drawer', 'region'], 'cup': ['mug', 'cup'],
       'pan': ['frypan', 'pan'], 'burner': ['stove', 'cook'], 'shelf': ['rack', 'shelf']}
AX = {'left': ('y', 'max'), 'right': ('y', 'min'), 'front': ('x', 'min'), 'back': ('x', 'max'), 'rear': ('x', 'max'),
      'top': ('z', 'max'), 'bottom': ('z', 'min'), 'middle': ('y', 'median'), 'center': ('y', 'median')}
GEN = {'region', 'init', 'table', 'kitchen', 'living', 'room', 'study', 'side', 'contain'}
PRON = {'it', 'them', 'that', 'there'}
BONUS = {'in': ['contain'], 'into': ['contain'], 'inside': ['contain'], 'on': ['cook', 'side', 'top'], 'onto': ['cook', 'side', 'top']}

def toks(ph):
    return [t for t in ph.lower().split() if t.isalpha() and t not in STOP]

def hits(ws, ts):
    return [w for w in ws if any(w in SYN.get(t, [t, t[:-1]]) for t in ts)]

def parse(text):
    segs, out = [], []
    for s in text.lower().replace('.', ' ').replace(',', ' ').replace(' then ', ' and ').split(' and '):
        s = ' '.join(s.split())
        if segs and (not s or s.split()[0] not in VERBS): segs[-1] += ' and ' + s
        elif s: segs.append(s)
    for s in segs:
        w = s.split(); v = w[0]; d = {'op': 'place', 'items': [], 'prep': '', 'tgt': ''}
        if v in ('turn', 'switch'):
            d.update(op='stroke', on='off' not in w, tgt=' '.join(x for x in w[1:] if x not in ('on', 'off')))
        elif v in ('open', 'close', 'shut'):
            d.update(op='open' if v == 'open' else 'close', tgt=' '.join(w[1:]))
        else:
            body = ' ' + ' '.join(w[2:] if len(w) > 1 and w[1] == 'up' else w[1:]) + ' '
            hs = sorted((body.find(p), -len(p), p) for p in PREPS if p in body)
            if v in HOLD or not hs:
                d.update(op='hold', items=[body.strip()]); out.append(d); continue
            i, _, p = hs[0]; ip = body[:i].strip()
            parts = [ip] if ' between ' in ip else ip.replace(' and the ', ' | the ').split(' | ')
            d.update(prep=p.strip(), tgt=body[i + len(p):].strip(), items=[x[5:] if x.startswith('both ') else x for x in parts])
            if d['items'] == ['it'] and out and out[-1]['op'] == 'hold': d['items'] = out.pop()['items']
        out.append(d)
    return out

def run(api):
    cat, last, opened, drawers = api.catalog(), {}, set(), set()
    P = lambda n: np.array(api.pos(n), dtype=float)
    D = lambda a, b: float(np.linalg.norm(P(a) - P(b)))
    def best(ph, kinds, excl=()):
        ts, sc = toks(ph), {}
        for n in cat:
            if cat[n]['kind'] in kinds and n not in excl and 'init' not in n.split('_'):
                ws = [w for w in n.split('_') if w.isalpha()]; h = hits(ws, ts)
                sc[n] = (len(set(h)) - .3 * len([w for w in ws if w not in h and w not in GEN]), sorted(set(h)))
        top = max([v[0] for v in sc.values()] + [0.])
        return [n for n in sc if top > 0 and sc[n][0] > top - 1e-6], ts, sc
    def choose(tied, ts, refs=()):
        if len(tied) < 2: return tied[0], {}
        com = {w for w in set.intersection(*[set(n.split('_')) for n in tied]) if w.isalpha()}
        mods = [t for t in ts if t not in com]
        labs = sorted((len(hits(n.split('_'), mods)), n) for n in cat if cat[n]['kind'] == 'region' and n not in tied
                      and cat[n]['parent'] not in tied and com & set(n.split('_')))
        if labs and labs[-1][0] > 0 and (len(labs) < 2 or labs[-2][0] < labs[-1][0]):
            a = labs[-1][1]; return min(tied, key=lambda n: D(n, a)), {'near': a}
        if refs:
            c = np.mean([P(r) for r in refs], axis=0); pk = min(tied, key=lambda n: np.linalg.norm(P(n) - c))
            a = [r for r in refs if min(tied, key=lambda n: D(n, r)) == pk]
            return pk, ({'near': a[0]} if a else {})
        for m in mods:
            if m in AX:
                ax, rk = AX[m]; v = sorted(tied, key=lambda n: P(n)['xyz'.index(ax)])
                return v[-1] if rk == 'max' else v[0] if rk == 'min' else v[len(v) // 2], {'axis': ax, 'rank': rk}
        return tied[0], {}
    def item(ph):
        if ph in PRON and last.get('it'): return last['it']
        pp, refs, head = ' ' + ph + ' ', [], ph
        for r in RELS:
            if r in pp:
                head, ref = pp.split(r, 1)
                refs = [t[0] for t in (best(x, ('item', 'fixture'))[0] for x in ref.split(' and ')) if len(t) == 1]
                break
        tied, _, sc = best(head, ('item',))
        if not tied: tied, _, sc = best(ph, ('item',))
        if not tied: return None, None
        n, sel = choose(tied, toks(ph), refs)
        return n, dict(kind=cat[n]['kind'], terms=sc[n][1], **sel)
    def target(ph, prep, it):
        if ph in PRON and last.get('own'): own, oe = last['own']
        else:
            tied, ts, sc = best(ph, ('item', 'fixture'), (it,))
            if not tied: tied, ts, sc = best(ph, ('region',))
            if not tied: return None, None, None, None
            own, sel = choose(tied, ts); oe = dict(kind=cat[own]['kind'], terms=sc[own][1], **sel)
            if cat[own]['kind'] == 'region': return own, oe, own, oe
        pr, tw, ch = (prep.split() or [''])[0], toks(prep + ' ' + ph), []
        for c in cat:
            if cat[c]['parent'] == own and cat[c]['kind'] == 'region':
                ws = [w for w in c.split('_') if w.isalpha() and w not in own.split('_')]
                h = sorted(set(hits(ws, tw) + [w for w in ws if w in BONUS.get(pr, [])])); ch.append((len(h), c, h))
        ch.sort()
        if ch and ch[-1][0] > 0: return ch[-1][1], {'kind': 'region', 'terms': ch[-1][2], 'parent': own}, own, oe
        return own, oe, own, oe
    def do(st):
        pv = api.preview(st) or {}
        for r in ('item', 'target'):
            v = pv.get(r) or {}
            if v.get('status') == 'corrected' and v.get('resolved'): st[r] = v['resolved']
        return api.act(st) or {}
    for d in parse(api.instruction):
        if d['op'] == 'hold' or api.remaining() < 15: continue
        if d['op'] != 'place':
            if d['tgt'] in PRON and last.get('tgt'): (tg, te), (own, oe) = last['tgt'], last['own']
            else: tg, te, own, oe = target(d['tgt'], '', None)
            if not tg: continue
            st = {'op': d['op'], 'target': tg, 'expect': {'target': te}}
            if d['op'] == 'stroke':  # switch/knob guess: front edge of fixture, sideways push; reversed for "off"
                st.update(offset=[-0.10, 0.0, 0.03], delta=[0.0, 0.08 if d.get('on', True) else -0.08, 0.0])
            do(st); tg = st['target']
            if d['op'] != 'stroke': drawers.add(tg); (opened.add if d['op'] == 'open' else opened.discard)(tg)
            last.update(tgt=(tg, te), own=(own, oe)); continue
        for ip in d['items']:
            if api.remaining() < 15: break
            it, ie = item(ip); tg, te, own, oe = target(d['tgt'], d['prep'], it)
            if not it or not tg: continue
            if ('drawer' in d['tgt'] or tg in drawers) and tg not in opened:
                do({'op': 'open', 'target': tg, 'expect': {'target': te}}); opened.add(tg)
            thin = set(it.split('_')) & {'book', 'plate', 'card', 'board', 'folder', 'tray'}
            st = {'op': 'place', 'item': it, 'target': tg, 'expect': {'item': ie, 'target': te},
                  'grasps': ['standard', 'thin_edge', 'rim'] if thin else ['standard', 'rim', 'thin_edge']}
            for _ in range(3):
                rc = do(st); lift = rc.get('max_lift')
                if not rc.get('executed') or lift is None or lift > .02 or api.remaining() < 15: break
                st['grasps'] = st['grasps'][1:] + st['grasps'][:1]
            last.update(it=(st['item'], ie), tgt=(st['target'], te), own=(own, oe))

def reread(instruction, step, role):
    low, cl = instruction.lower(), parse(instruction)
    ov = lambda ph, nm: sum(1 if hits(nm.split('_'), [t]) else -.3 for t in toks(ph))
    if step.get('op') == 'place':
        c = [(ov(p, step.get('item') or ''), d, p) for d in cl if d['op'] == 'place' for p in d['items']]
        if not c: return ''
        _, d, p = max(c, key=lambda x: x[0])
        q = p if role == 'item' else ('' if d['tgt'] in PRON else (d['prep'] + ' ' + d['tgt']).strip())
    elif role == 'item': return ''
    else:
        c = [(ov(d['tgt'], step.get('target') or ''), i, d) for i, d in enumerate(cl) if d['op'] == step.get('op')]
        if not c: return ''
        _, i, d = max(c, key=lambda x: x[0]); q = d['tgt']
        if q in PRON: q = next((e['tgt'] for e in cl[:i][::-1] if e['tgt'] and e['tgt'] not in PRON), '')
    k = low.find(q) if q else -1
    return instruction[k:k + len(q)] if k >= 0 else ''
