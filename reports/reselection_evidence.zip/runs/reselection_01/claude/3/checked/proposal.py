import numpy as np

VERBS = {'put', 'place', 'pick', 'close', 'open', 'turn', 'push', 'move', 'slide', 'set', 'take', 'stack', 'drop', 'grab', 'shut', 'switch', 'insert'}
PREPS = {'in', 'into', 'on', 'onto', 'inside', 'atop'}
SPAT = {'left', 'right', 'front', 'back', 'top', 'bottom', 'middle', 'rear', 'center'}
STOP = {'the', 'a', 'an', 'of', 'it', 'both', 'up', 'and', 'to', 'its', 'that', 'is', 'which', 'then', 'them', 'please', 'one'}
REL = {'near', 'next', 'beside', 'by', 'from', 'behind', 'closest', 'nearest', 'on', 'in', 'at', 'under', 'inside', 'between'}
SYN = {'white': ['white', 'porcelain'], 'compartment': ['contain'], 'drawer': ['drawer', 'cabinet'], 'cup': ['cup', 'mug'],
       'mug': ['mug', 'cup'], 'pan': ['pan', 'frypan'], 'skillet': ['frypan'], 'stove': ['stove', 'burner'],
       'shelf': ['shelf', 'rack'], 'rear': ['back'], 'center': ['middle']}
AX = {'left': ('y', 'max'), 'right': ('y', 'min'), 'front': ('x', 'min'), 'back': ('x', 'max'),
      'top': ('z', 'max'), 'bottom': ('z', 'min'), 'middle': ('y', 'median')}
DIRV = {'left': (0, 1, 0), 'right': (0, -1, 0), 'front': (-1, 0, 0), 'forward': (1, 0, 0), 'back': (1, 0, 0), 'backward': (-1, 0, 0)}
KNOB = {'knob', 'button', 'switch', 'dial'}


def _words(text):
    t = text.lower()
    for c in ',.;:!?()':
        t = t.replace(c, ' ')
    out, i = [], 0
    for w in t.split(' '):
        if w:
            out.append((w, i, i + len(w)))
        i += len(w) + 1
    return out


def _clauses(text):
    ws, out = _words(text), []
    for k, x in enumerate(ws):
        if not out or (x[0] in VERBS and (ws[k - 1][0] in ('and', 'then') or ',' in text[ws[k - 1][2]:x[1]])):
            while out and out[-1] and out[-1][-1][0] in ('and', 'then'):
                out[-1].pop()
            out.append([])
        out[-1].append(x)
    return [c for c in out if c]


def _parse(cw):
    v, b, part = cw[0][0], cw[1:], ''
    if v not in VERBS:
        v, b = 'put', cw
    if b and b[0][0] in ('up', 'on', 'off', 'down') and v in ('pick', 'turn', 'switch'):
        part, b = b[0][0], b[1:]
    sp = lambda seg: (seg[0][1], seg[-1][2]) if seg else None
    if v in ('open', 'close', 'shut', 'turn', 'switch'):
        return {'v': v, 'part': part or ('off' if 'off' in [x[0] for x in b] else 'on'), 'items': [], 'tgt': sp(b), 'prep': ''}
    k = next((i for i, x in enumerate(b) if x[0] in PREPS), None)
    if k is None:
        k = next((i for i, x in enumerate(b) if x[0] in ('to', 'toward', 'towards')), len(b))
    ct = lambda seg: [x for x in seg if x[0] not in STOP and x[0] not in SPAT]
    for j in range(k + 1, len(b)):
        if b[j][0] in PREPS and ct(b[k + 1:j]) and ct(b[j + 1:]):
            k = j
    items, cur, both = [], [], 'both' in [x[0] for x in b[:k]]
    for i, x in enumerate(b[:k]):
        if x[0] == 'both':
            continue
        if x[0] == 'and' and (both or (i + 1 < k and b[i + 1][0] in ('the', 'a', 'an'))):
            items.append(cur); cur = []
        else:
            cur.append(x)
    items.append(cur)
    return {'v': v, 'part': part, 'items': [sp(s) for s in items if s], 'tgt': sp(b[k:]), 'prep': b[k][0] if k < len(b) else ''}


def run(api):
    cat, text = api.catalog(), api.instruction
    W = lambda n: [w for w in str(n).lower().split('_') if w.isalpha()]
    P = lambda n: np.array(api.pos(n), dtype=float)
    objs = [n for n in cat if cat[n]['kind'] != 'region']
    onames = set(w for o in objs for w in W(o))
    lab, kids, mem, opened = [], {}, {'item': None, 'obj': None, 'reg': None}, set()
    for r in cat:
        if cat[r]['kind'] != 'region':
            continue
        p = cat[r].get('parent')
        o = p if p in cat and cat[p]['kind'] != 'region' else max([x for x in objs if r.startswith(x + '_')] or [''], key=len)
        rest = [w for w in W(r) if w not in W(o)]
        if not o or 'init' in rest or set(rest) & (onames - set(W(o))):
            lab.append(r)          # location label: a physical anchor, never a destination
        else:
            kids.setdefault(o, []).append(r)

    def sc(tk, n):
        nw = W(n)
        hit = [w for w in nw if any(w in SYN.get(t, [t]) for t in tk)]
        return len(set(hit)) - .15 * len([w for w in nw if w not in hit]), hit

    def res(tk, role, prep='', drawer=False):
        i = next((k for k in range(1, len(tk)) if tk[k] in REL), len(tk))
        head, rel = tk[:i], tk[i + 1:]
        core = [t for t in head if t not in STOP and t not in SPAT]
        relc = [t for t in rel if t not in STOP and t not in SPAT]
        mods = [SYN.get(t, [t])[0] for t in head + ([] if relc else rel) if t in SPAT]
        if not core:
            key = 'item' if role == 'item' else 'obj'
            if not ('it' in tk or 'them' in tk) or not mem[key]:
                return None, None
            o, osel = mem[key][0], dict(mem[key][1])
        else:
            cands = [(sc(core, x)[0], x) for x in objs if role != 'item' or cat[x]['kind'] == 'item']
            if role == 'item' and max([s for s, _ in cands] + [0]) <= 0:
                cands = [(sc(core, x)[0], x) for x in objs]
            top = max([s for s, _ in cands] + [0])
            if top <= 0:
                return None, None
            tied = sorted(x for s, x in cands if s > top - 1e-6)
            o, extra = tied[0], {}
            if len(tied) > 1:
                anc = res(rel, 'anchor')[0] if relc else None
                if not anc and mods:
                    tw = set(sc(core, o)[1])
                    anc = max([r for r in lab if all(m in W(r) for m in mods) and tw & set(W(r))],
                              key=lambda r: len(tw & set(W(r))), default=None)
                if anc:
                    o = min(tied, key=lambda x: np.linalg.norm(P(x)[:2] - P(anc)[:2])); extra = {'near': anc}
                elif mods and mods[0] in AX:
                    ax, rk = AX[mods[0]]
                    srt = sorted(tied, key=lambda x: P(x)['xyz'.index(ax)])
                    o = srt[-1] if rk == 'max' else srt[0] if rk == 'min' else srt[len(srt) // 2]
                    extra = {'axis': ax, 'rank': rk}
            osel = dict({'kind': cat[o]['kind'], 'terms': sc(core, o)[1]}, **extra)
        if role in ('target', 'fix'):
            mem['obj'] = (o, osel)
        if role != 'target' or o not in kids:
            return o, osel
        fn = ['region'] if drawer else (['contain', 'inside', 'interior'] if prep in ('in', 'into', 'inside') else ['side', 'cook', 'surface'])
        cs = lambda r: (2 * sum(m in [w for w in W(r) if w not in W(o)] for m in mods)
                        + any(w in fn for w in W(r) if w not in W(o)))
        r = max(sorted(kids[o]), key=cs)
        if cs(r) <= 0 and len(kids[o]) > 1:
            return o, osel
        rw = [w for w in W(r) if w not in W(o)]
        rs = {'kind': 'region', 'terms': [m for m in mods if m in rw] + [w for w in rw if w in fn][:1] or rw}
        if cat[r].get('parent'):
            rs['parent'] = cat[r]['parent']
        return r, rs

    def do(step):
        if api.remaining() < 12:
            return None
        pv = api.preview(step)
        for r in ('item', 'target'):
            q = pv.get(r) if isinstance(pv, dict) else None
            if r in step and isinstance(q, dict) and q.get('status') == 'corrected' and q.get('resolved'):
                step[r] = q['resolved']
        return api.act(step)

    toks = lambda sp: [w for w, s, e in _words(text[sp[0]:sp[1]])] if sp else []
    for c in [_parse(x) for x in _clauses(text)]:
        v, tt = c['v'], toks(c['tgt'])
        if v in ('open', 'close', 'shut'):
            t, sel = res(tt, 'target', 'in', True) if [w for w in tt if w not in STOP] else (mem['reg'] or (None, None))
            if t:
                do({'op': 'open' if v == 'open' else 'close', 'target': t, 'expect': {'target': sel}})
                mem['reg'] = (t, sel)
                (opened.add if v == 'open' else opened.discard)(t)
        elif v in ('turn', 'switch'):
            t, sel = res(tt, 'fix')
            kn = [r for r in cat if t and set(W(r)) & KNOB and r.startswith(t)]
            if kn:
                t, sel = kn[0], {'kind': cat[kn[0]]['kind'], 'terms': [w for w in W(kn[0]) if w in KNOB]}
            g = -1 if c['part'] == 'off' else 1
            if t:
                do({'op': 'stroke', 'target': t, 'offset': [-.06, .06 * g, .02], 'delta': [0., -.1 * g, 0.], 'expect': {'target': sel}})
        elif v in ('push', 'slide') and c['items']:
            i, isel = res(toks(c['items'][0]), 'item')
            u = np.array(sum((np.array(DIRV[w], float) for w in tt if w in DIRV), np.zeros(3)))
            a = res(tt[1:], 'anchor')[0] if i and not u.any() else None
            if a:
                u = P(a) - P(i); u[2] = 0
            if i and np.linalg.norm(u) > 1e-6:
                u = u / np.linalg.norm(u)
                do({'op': 'stroke', 'target': i, 'offset': [float(z) for z in -.07 * u + np.array([0, 0, .02])],
                    'delta': [float(z) for z in .15 * u], 'expect': {'target': isel}})
        else:
            its = [res(toks(s), 'item') for s in c['items']]
            if not tt:
                if its and its[0][0]:
                    mem['item'] = its[0]
                continue
            pr, dr = tt[0], 'drawer' in tt
            t, tsel = res(tt[1:] if pr in PREPS else tt, 'target', pr, dr)
            if not t:
                continue
            ow = next((o for o in kids if t in kids[o]), None)
            if (ow and pr in ('in', 'into', 'inside') and 'side' not in W(t) and t not in opened and
                    (dr or (sum(bool(set(W(r)) & {'top', 'middle', 'bottom'}) for r in kids[ow]) > 1 and 'contain' not in W(t)))):
                do({'op': 'open', 'target': t, 'expect': {'target': tsel}}); opened.add(t)
            for i, isel in its:
                if not i or api.remaining() < 12:
                    continue
                gr = ['standard', 'thin_edge', 'rim'] if set(W(i)) & {'book', 'plate', 'board', 'card'} else ['standard', 'rim', 'thin_edge']
                st = {'op': 'place', 'item': i, 'target': t, 'grasps': gr, 'expect': {'item': isel, 'target': tsel}}
                rc = do(st)
                if rc and rc.get('executed') and rc.get('max_lift') is not None and rc['max_lift'] < .015:
                    st['grasps'] = gr[1:] + gr[:1]
                    do(st)
                mem['item'] = (st['item'], isel)
            if cat[t]['kind'] == 'region':
                mem['reg'] = (t, tsel)


def reread(instruction, step, role):
    t = instruction
    nm = lambda k: [w for w in str(step.get(k) or '').lower().split('_') if w.isalpha()]
    iw, tw = nm('item'), nm('target')
    ws = lambda sp: _words(t[sp[0]:sp[1]]) if sp else []
    ov = lambda sp, n: sum(1 for x in ws(sp) for a in SYN.get(x[0], [x[0]]) if a in n)
    pron = lambda sp: not [x for x in ws(sp) if x[0] not in STOP and x[0] not in SPAT and x[0] not in PREPS]
    txt = lambda sp: '' if pron(sp) else t[sp[0]:sp[1]]
    strip = lambda sp: (sp[0] + ws(sp)[1][1], sp[1]) if len(ws(sp)) > 1 and ws(sp)[0][0] in PREPS else sp
    op, best, out, held, prev = step.get('op'), -1, '', None, None
    want_item = role in ('item', 'source')
    for p in [_parse(c) for c in _clauses(t)]:
        if p['v'] in ('pick', 'take', 'grab') and p['items'] and not p['tgt']:
            held = p['items'][0]
        if op == 'place' and p['tgt'] and p['v'] not in ('open', 'close', 'shut', 'turn', 'switch', 'push', 'slide'):
            for sp in p['items']:
                isp = held if pron(sp) and held else sp
                s = ov(isp, iw) + ov(p['tgt'], tw)
                if s > best:
                    best, out = s, txt(isp) if want_item else txt(p['tgt'])
        elif op in ('open', 'close') and p['v'] in (('open',) if op == 'open' else ('close', 'shut')) and not want_item:
            tsp = prev if pron(p['tgt']) else p['tgt']
            if tsp and ov(tsp, tw) > best:
                best, out = ov(tsp, tw), txt(tsp)
        elif op == 'stroke' and p['v'] in ('turn', 'switch', 'push', 'slide'):
            sp = p['tgt'] if p['v'] in ('turn', 'switch') else (p['items'] or [None])[0]
            if ov(sp, tw) > best:
                best, out = ov(sp, tw), txt(sp)
        if p['tgt'] and not pron(p['tgt']) and p['v'] not in ('turn', 'switch', 'push', 'slide'):
            prev = strip(p['tgt'])
    return out.strip()
