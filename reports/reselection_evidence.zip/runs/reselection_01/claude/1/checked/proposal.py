import numpy as np

SP = {'left', 'right', 'front', 'back', 'top', 'bottom', 'middle'}
SYN = {'compartment': ['contain'], 'drawer': ['region'], 'cup': ['mug'], 'pan': ['frypan', 'pan'], 'rear': ['back'],
       'white': ['white', 'porcelain'], 'center': ['middle'], 'burner': ['stove'], 'box': [], 'it': [], 'them': []}
STOP = {'the', 'a', 'an', 'of', 'both', 'up', 'down', 'its', 'that', 'this', 'and', 'there'}
VERBS = {'put', 'place', 'move', 'pick', 'close', 'open', 'turn', 'push', 'slide', 'set', 'grab', 'take', 'shut',
         'switch', 'drop', 'stack'}
PREPS = [' on top of ', ' into ', ' inside ', ' onto ', ' in ', ' on ', ' at ', ' over ', ' to ']
AX = {'left': ('y', 'max'), 'right': ('y', 'min'), 'front': ('x', 'min'), 'back': ('x', 'max'),
      'top': ('z', 'max'), 'bottom': ('z', 'min'), 'middle': ('y', 'median')}
DIR = {'left': (0, 1, 0), 'right': (0, -1, 0), 'front': (-1, 0, 0), 'back': (1, 0, 0)}
PRON = ('it', 'them', 'there')


def parse(instr):
    t = instr.lower().replace(',', ' ').replace('.', ' ').replace(' then ', ' and ')
    parts, out = [], []
    for p in t.split(' and '):
        w = p.split()
        if not w: continue
        if parts and w[0] not in VERBS: parts[-1] += ' and ' + ' '.join(w)
        else: parts.append(' '.join(w))
    for c in parts:
        w = c.split(); v = w[0]; w = w[1:]
        if v in ('turn', 'switch'):
            out.append({'op': 'off' if 'off' in w else 'on', 'items': [], 'prep': '',
                        'target': ' '.join(x for x in w if x not in ('on', 'off'))})
        elif v in ('open', 'close', 'shut'):
            out.append({'op': 'open' if v == 'open' else 'close', 'items': [], 'prep': '', 'target': ' '.join(w)})
        else:
            r = ' ' + ' '.join(x for x in w if x not in ('up', 'down')) + ' '
            hits = [(r.find(p), -len(p), p) for p in PREPS if r.find(p) >= 0]
            if not hits:
                out.append({'op': 'pick', 'items': [r.strip()], 'prep': '', 'target': ''}); continue
            i, _, p = min(hits)
            item, tgt = r[:i].strip(), r[i + len(p):].strip()
            its = [x.strip() for x in item.replace('both ', '').split(' and ')] \
                if ('both ' in item or ' and the ' in item) else [item]
            out.append({'op': 'push' if v in ('push', 'slide') else 'place', 'items': its, 'prep': p.strip(), 'target': tgt})
    return out


def match(ph, nm):
    s = 0
    for w in ph.split():
        if w in STOP or w in PRON: continue
        s += 1 if any(a in nm for a in SYN.get(w, []) + [w, w[:-1]]) else -0.5
    return s


def reread(instruction, step, role):
    nm = lambda r: set(x for x in str(step.get(r, '')).lower().split('_') if x.isalpha())
    ok = {'place': ('place',), 'open': ('open',), 'close': ('close',), 'stroke': ('on', 'off', 'push')}.get(step.get('op'), ())
    best, bs, li, lt = '', 0, '', ''
    for c in parse(instruction):
        tg = c['target']
        if not tg.split() or tg.split()[-1] in PRON: tg = '' if 'top' in c['prep'] else lt
        for it in c['items'] or ['']:
            if not it.split() or it.split()[-1] in PRON: it = li
            if c['op'] in ok:
                ph = it if (role == 'item' or c['op'] == 'push') else tg
                s = match(ph, nm(role)) if ph else 0.01
                if c['op'] == 'place': s += 0.5 * (match(it, nm('item')) if role != 'item' else match(tg, nm('target')))
                if s > bs: best, bs = ph, s
            if it: li = it
        if c['op'] not in ('pick', 'push') and tg: lt = tg
    i = instruction.lower().find(best) if best else -1
    return instruction[i:i + len(best)] if i >= 0 else ''


def run(api):
    cat = api.catalog()
    W = {n: [x for x in n.lower().split('_') if x.isalpha()] for n in cat}
    voc = set(x for v in W.values() for x in v)
    P = lambda n: np.array(api.pos(n), float)
    kids = lambda h: [n for n in cat if cat[n]['parent'] == h and cat[n]['kind'] == 'region']
    own = lambda n: [x for x in W[n] if cat[n]['parent'] not in W or x not in W[cat[n]['parent']]]

    def words(ph):
        out = []
        for w in ph.split():
            if w not in STOP: out += SYN.get(w, [w[:-1]] if w not in voc and w[-1:] == 's' else [w])
        return out

    def rsel(h, ws):
        s = {'kind': cat[h]['kind'], 'terms': [x for x in own(h) if x in ws] or own(h)}
        if cat[h]['kind'] == 'region' and cat[h]['parent'] in cat: s['parent'] = cat[h]['parent']
        return s

    def ground(ph, role, prep='', last=None):
        ws = words(ph); sp = [w for w in ws if w in SP]; nn = [w for w in ws if w not in SP]
        if not ph.split() or ph.split()[-1] in PRON:
            if not last: return None
            h = cat[last]['parent'] if 'top' in prep and cat[last]['kind'] == 'region' and cat[last]['parent'] in cat else last
            sel = rsel(h, ws)
        else:
            pools = [[n for n in cat if cat[n]['kind'] == 'item']] if role == 'item' else [
                [n for n in cat if cat[n]['kind'] != 'region'],
                [n for n in cat if cat[n]['kind'] == 'region' and 'init' not in W[n]]]
            for pool in pools:
                sc = {n: sum(x in ws for x in W[n]) - .3 * sum(x not in ws for x in W[n]) for n in pool if set(nn) & set(W[n])}
                if sc: break
            if not sc: return None
            best = sorted(n for n in sc if sc[n] > max(sc.values()) - 1e-6); h = best[0]; sel = rsel(h, ws)
            if len(best) > 1:
                anc = [r for r in cat if cat[r]['kind'] == 'region' and sp and sp[0] in W[r] and set(sel['terms']) & set(W[r])]
                if anc:
                    a = max(anc, key=lambda r: sum(x in ws for x in W[r])); sel['near'] = a
                    h = min(best, key=lambda n: float(np.linalg.norm(P(n) - P(a))))
                else:
                    ax, rk = AX.get(sp[0] if sp else '', ('x', 'min'))
                    o = sorted(best, key=lambda n: P(n)['xyz'.index(ax)])
                    h = o[-1] if rk == 'max' else o[len(o) // 2] if rk == 'median' else o[0]; sel.update(axis=ax, rank=rk)
                sp = sp[1:]
        if role in ('target', 'drawer') and cat[h]['kind'] != 'region' and kids(h):
            want = {w: 1 for w in nn}; want.update({w: 2 for w in sp})
            if 'top' in prep: want.update(top=2, side=2)
            elif role == 'target' and not sp: want.update(contain=1, cook=1)
            s2 = lambda r: sum(want.get(x, 0) for x in own(r))
            b = max(kids(h), key=s2)
            if s2(b) > 0 or (role == 'target' and len(kids(h)) == 1 and not sp): return b, rsel(b, list(want))
        return h, sel

    def drawer(r):
        f = lambda k: bool(set(own(k)) & {'top', 'middle', 'bottom'}) and 'side' not in W[k]
        p = cat[r]['parent']
        return cat[r]['kind'] == 'region' and p in cat and f(r) and sum(1 for k in kids(p) if f(k)) >= 2

    def grasps(n):
        if set(W[n]) & {'bowl', 'mug', 'cup', 'basket'}: return ['rim', 'standard', 'thin_edge']
        if set(W[n]) & {'book', 'plate', 'board', 'card', 'folder'}: return ['standard', 'thin_edge', 'rim']
        return ['standard', 'rim', 'thin_edge']

    def go(step):
        pv = api.preview(step)
        for r in ('item', 'target'):
            v = pv.get(r) if isinstance(pv, dict) else None
            if isinstance(v, dict) and v.get('status') == 'corrected' and v.get('resolved') in cat: step[r] = v['resolved']
        return api.act(step) or {}

    li = lt = None; opened = set()
    for c in parse(api.instruction):
        op = c['op']
        if api.remaining() < 10: break
        if op == 'pick':
            li = ground(c['items'][0], 'item', '', li and li[0]) or li; continue
        if op in ('open', 'close', 'on', 'off'):
            g = ground(c['target'], 'drawer' if op in ('open', 'close') else 'fixture', '', lt)
            if not g: continue
            if op in ('open', 'close'):
                go({'op': op, 'target': g[0], 'expect': {'target': g[1]}})
                (opened.add if op == 'open' else opened.discard)(g[0])
            else:
                go({'op': 'stroke', 'target': g[0], 'offset': [-0.08, 0.0, 0.0],
                    'delta': [0.0, 0.08 if op == 'on' else -0.08, 0.0], 'expect': {'target': g[1]}})
            lt = g[0]; continue
        gt = ground(c['target'], 'target', c['prep'], lt) if op == 'place' else None
        for ph in c['items']:
            gi = ground(ph, 'item', '', li and li[0])
            if not gi or api.remaining() < 10: continue
            if op == 'push':
                d = sum((np.array(DIR[w], float) for w in words(c['target']) if w in DIR), np.zeros(3))
                if not d.any():
                    g2 = ground(c['target'], 'fixture', '', None)
                    d = P(g2[0]) - P(gi[0]) if g2 else d; d[2] = 0
                if np.linalg.norm(d) > 1e-6:
                    u = d / np.linalg.norm(d)
                    go({'op': 'stroke', 'target': gi[0], 'offset': [float(x) for x in -0.1 * u],
                        'delta': [float(x) for x in 0.15 * u], 'expect': {'target': gi[1]}})
                li = gi; continue
            if not gt: break
            if drawer(gt[0]) and gt[0] not in opened:
                go({'op': 'open', 'target': gt[0], 'expect': {'target': gt[1]}}); opened.add(gt[0])
            gr = grasps(gi[0])
            for _ in range(3):
                rec = go({'op': 'place', 'item': gi[0], 'target': gt[0], 'grasps': gr,
                          'expect': {'item': gi[1], 'target': gt[1]}})
                ml = rec.get('max_lift')
                if not rec.get('executed') or ml is None or ml > 0.02 or api.remaining() < 10: break
                gr = gr[1:] + gr[:1]
            li = gi
        if gt: lt = gt[0]
