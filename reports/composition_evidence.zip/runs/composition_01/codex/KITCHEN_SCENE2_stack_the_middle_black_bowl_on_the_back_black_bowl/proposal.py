def run(api):
    bowls = ["akita_black_bowl_1", "akita_black_bowl_2", "akita_black_bowl_3"]
    middle = api.nearest("kitchen_table_akita_black_bowl_middle_init_region", bowls)
    front = api.nearest("kitchen_table_akita_black_bowl_front_init_region", bowls)
    api.arrange([(middle, front)])
