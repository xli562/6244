import math
import numpy as np

# ---------------------------------------------------------------- vocabulary
ALIAS = {
    'akita_black_bowl': 'black bowl',
    'black_bowl': 'black bowl',
    'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup',
    'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup',
    'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop',
    'moka_pot': 'moka pot',
    'desk_caddy': 'desk caddy',
    'black_book': 'black book',
    'yellow_book': 'yellow book',
    'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can',
    'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle',
    'ketchup': 'ketchup bottle',
    'butter': 'butter box',
    'milk': 'milk carton',
    'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box',
    'salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet',
    'wooden_cabinet': 'wooden cabinet',
    'wine_bottle': 'wine bottle',
    'wine_rack': 'wine rack',
    'microwave': 'microwave oven',
    'basket': 'basket',
    'plate': 'plate',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown',
          'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'top',
        'left', 'right', 'front', 'back', 'bottom', 'middle', 'compartment',
        'side', 'its', 'that', 'is', 'please', 'then'}
VERBS = {'put', 'place', 'turn', 'switch', 'close', 'shut', 'open', 'pick',
         'push', 'pull', 'move', 'stack', 'lift', 'grab', 'take', 'set'}
PREPS = ('into', 'onto', 'inside', 'in', 'on')
FIXTURE_WORDS = ('cabinet', 'microwave', 'drawer')


def V(*a):
    return np.array(a, dtype=float)


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def E(api):
    return np.array(api.eef(), dtype=float)


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _words(s):
    s = ''.join(c if c.isalnum() else ' ' for c in s.lower())
    return s.split()


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return w


# ---------------------------------------------------------------- resolution
def _spatial(api, names, raw, cands):
    for w in ('left', 'right', 'front', 'back'):
        if w in raw:
            head = _base(cands[0]).split('_')[-1]
            hints = [n for n in names if _is_region(n)
                     and w in n.split('_') and head in n.split('_')]
            if hints:
                hp = P(api, hints[0])
                return sorted(cands, key=lambda c: np.linalg.norm(P(api, c)[:2] - hp[:2]))
            keyf = {'left': lambda p: -p[1], 'right': lambda p: p[1],
                    'front': lambda p: p[0], 'back': lambda p: -p[0]}[w]
            return sorted(cands, key=lambda c: keyf(P(api, c)))
    return sorted(cands)


def resolve(api, names, bodies, raw, exclude=()):
    W = set(w for w in raw if w not in STOP)
    if not W:
        return None
    best, cands = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, cands = s, [b]
        elif abs(s - best) < 1e-9:
            cands.append(b)
    if not cands:
        return None
    if len(cands) > 1:
        cands = _spatial(api, names, raw, cands)
    return cands[0]


def default_fixture(names, bodies):
    """a body that owns drawer-like regions (cabinet etc.)"""
    best = None
    for b in sorted(bodies):
        regs = [n for n in names if _is_region(n) and n.startswith(b + '_')]
        if not regs:
            continue
        if any(w in b for w in FIXTURE_WORDS):
            return b
        if best is None:
            best = b
    return best


def resolve_target(api, names, bodies, raw, fallback=None):
    """returns (target_name, owner_body)"""
    obj = resolve(api, names, bodies, raw)
    if obj is None:
        obj = fallback
    if obj is None:
        return None
    regs = [n for n in names if _is_region(n) and n.startswith(obj + '_')]
    if not regs:
        return (obj, obj)
    R = set(raw)
    drawer = 'drawer' in R or 'drawers' in R
    best, bs = None, -1e9
    for r in regs:
        suf = r[len(obj) + 1:].split('_')
        toks = set(suf) - {'region', 'contain', 'side'}
        s = 3 * len(toks & R)
        if drawer and 'side' in suf:
            s -= 5
        if (not drawer) and 'top' in R and 'side' in suf:
            s += 2
        if not toks or toks <= {'cook', 'heating'}:
            s += 1
        if s > bs:
            bs, best = s, r
    return (best, obj)


# ---------------------------------------------------------------- parsing
def split_clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if (w == 'and' and (nxt in VERBS or nxt == 'then')) or w == 'then':
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return [[w for w in c] for c in out if c]


def split_items(ws):
    both = 'both' in ws
    has_the = any(ws[j] == 'and' and j + 1 < len(ws) and ws[j + 1] in ('the', 'a')
                  for j in range(len(ws)))
    parts = [[]]
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if w == 'and' and ((has_the and nxt in ('the', 'a')) or (both and not has_the)):
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def build_plan(api, names, bodies, words):
    ops = []
    last_item, last_target, last_fix = None, None, None
    for c in split_clauses(words):
        while c and c[-1] == 'and':
            c = c[:-1]
        if not c:
            continue
        v, rest = c[0], c[1:]
        if v in ('turn', 'switch'):
            on = 'off' not in rest
            ow = [w for w in rest if w not in ('on', 'off')]
            obj = last_fix if (not ow or ow == ['it']) else resolve(api, names, bodies, ow)
            if obj:
                ops.append(('turn', obj, on))
                last_fix = obj
            continue
        if v in ('close', 'shut', 'open'):
            if not rest or rest == ['it'] or rest == ['them']:
                tgt = last_target
            else:
                fb = last_fix if last_fix else default_fixture(names, bodies)
                tgt = resolve_target(api, names, bodies, rest, fallback=fb)
            if tgt:
                ops.append(('close' if v != 'open' else 'open', tgt))
                last_target = tgt
                last_fix = tgt[1]
            continue
        rest = [w for w in rest if w != 'up']
        idx = None
        for i, w in enumerate(rest):
            if w in PREPS and i > 0:
                idx = i
                break
        if v in ('pick', 'grab', 'lift', 'take') and idx is None:
            it = resolve(api, names, bodies, rest)
            if it:
                ops.append(('pick', it))
                last_item = it
            continue
        if idx is None:
            item_w, tw = rest, []
        else:
            item_w, tw = rest[:idx], rest[idx + 1:]
        if not tw or tw in (['it'], ['them']):
            if tw and last_fix:
                tgt = resolve_target(api, names, bodies, _base(last_fix).split('_'))
                if tgt is None or tgt[1] != last_fix:
                    tgt = (last_fix, last_fix)
            else:
                tgt = last_target
        else:
            tgt = resolve_target(api, names, bodies, tw)
        if tgt is None:
            continue
        items = []
        for part in split_items(item_w):
            if part in (['it'], ['them']):
                it = last_item
            else:
                it = resolve(api, names, bodies, part, exclude=(tgt[1],))
            if it and it not in items:
                items.append(it)
        if ops and ops[-1][0] == 'pick' and ops[-1][1] in items:
            ops.pop()
        for k, it in enumerate(items):
            ops.append(('place', it, tgt, k, len(items)))
        if items:
            last_item = items[-1]
        last_target = tgt
        last_fix = tgt[1]
    return ops


# ---------------------------------------------------------------- skills
def grasp_options(item):
    b = _base(item)
    if 'mug' in b or 'cup' in b:
        return [(0.0, 0.03, 0.02), (0.0, -0.03, 0.02)]
    if 'bowl' in b:
        return [(0.0, 0.045, 0.01), (0.0, -0.045, 0.01)]
    return [(0.0, 0.0, 0.0), (0.0, 0.0, -0.01)]


# verified rim grasps for bowls: finger midpoint on the wall, above the floor
BOWL_GRASPS = [(0.0, 0.06, 0.025), (0.0, -0.06, 0.025), (0.0, 0.05, 0.035)]


def drawer_dir(api, region, owner):
    rp = P(api, region)
    op = P(api, owner) if owner else rp
    d = op[:2] - rp[:2]
    nd = np.linalg.norm(d)
    d = d / nd if nd > 0.03 else np.array([1.0, 0.0])
    return np.array([d[0], d[1], 0.0])


def drop_for(api, item, tgt, k, n):
    name, owner = tgt
    z = 0.08
    off = np.zeros(3)
    if 'basket' in name:
        z = 0.11
    elif 'caddy' in name:
        z = 0.10
    elif 'cook' in name:
        z = 0.05
    elif 'plate' in name:
        z = 0.06
    elif 'cabinet' in owner and name != owner and 'side' not in name:
        z = 0.06
        off = -drawer_dir(api, name, owner) * 0.03
    if n > 1 and ('basket' in name or 'contain' in name) and 'caddy' not in name:
        off[1] += 0.03 if k % 2 == 0 else -0.03
    return (float(off[0]), float(off[1]), float(off[2] + z))


def placed_ok(api, item, name):
    ip, tp = P(api, item), P(api, name)
    tol = 0.07
    if 'basket' in name or 'contain' in name:
        tol = 0.08
    if 'caddy' in name:
        tol = 0.045
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.06


def recover(api):
    api.grip(False)
    e = E(api)
    api.move(e + V(0, 0, 0.12), steps=15)


def try_grasp(api, item, g):
    """top-down grasp with lift verification; returns True if item rose"""
    p0 = P(api, item)
    p = p0 + V(*g)
    api.grip(False)
    e = E(api)
    api.move(V(e[0], e[1], max(e[2], p[2] + 0.12)), steps=10)
    api.move(p + V(0, 0, 0.10), steps=22)
    api.move(p, steps=18)
    api.grip(True)
    api.move(p + V(0, 0, 0.08), steps=12)
    return P(api, item)[2] - p0[2] > 0.025


def manual_place(api, item, tgt, k, n, options):
    name = tgt[0]
    drop = np.array(drop_for(api, item, tgt, k, n))
    for g in options:
        if not try_grasp(api, item, g):
            recover(api)
            continue
        ip = P(api, item)
        e = E(api)
        rel = e - ip
        dest = P(api, name) + drop
        eg = dest + rel
        hz = max(e[2], eg[2] + 0.12)
        z_before = P(api, item)[2]
        api.move(V(e[0], e[1], hz), steps=15)
        if P(api, item)[2] < z_before - 0.02:   # slipped while lifting
            recover(api)
            continue
        api.move(V(eg[0], eg[1], hz), steps=35)
        api.move(eg, steps=20)
        api.grip(False)
        e = E(api)
        api.move(e + V(0, 0, 0.10), steps=12)
        if placed_ok(api, item, name):
            return True
    return False


def do_place(api, item, tgt, k, n):
    name = tgt[0]
    if 'bowl' in _base(item):
        if manual_place(api, item, tgt, k, n, BOWL_GRASPS):
            return True
    drop = drop_for(api, item, tgt, k, n)
    for g in grasp_options(item):
        try:
            lift = api.transfer(item, name, grasp=g, drop=drop)
        except Exception:
            lift = 0.0
        if placed_ok(api, item, name):
            return True
        recover(api)
    return False


def pick_only(api, item):
    g = np.array(grasp_options(item)[0])
    p = P(api, item) + g
    api.grip(False)
    api.move(p + V(0, 0, 0.12), steps=30)
    api.move(p, steps=25)
    api.grip(True)
    api.move(p + V(0, 0, 0.15), steps=25)


def push_close(api, tgt):
    name, owner = tgt
    rp = P(api, name)
    d3 = drawer_dir(api, name, owner)
    start = rp - d3 * 0.20
    start[2] = rp[2] + 0.03
    e = E(api)
    high = max(e[2], rp[2] + 0.15)
    api.move(V(e[0], e[1], high), steps=15)
    api.move(V(start[0], start[1], high), steps=30)
    api.grip(True)
    api.move(start, steps=25)
    api.move(start + d3 * 0.32, steps=60)
    back = start + d3 * 0.20
    api.move(back, steps=10)
    api.move(back + V(0, 0, 0.12), steps=15)


def pull_open(api, tgt):
    name, owner = tgt
    rp = P(api, name)
    d3 = drawer_dir(api, name, owner)
    handle = rp - d3 * 0.13
    handle[2] = rp[2] + 0.04
    pre = handle - d3 * 0.08
    e = E(api)
    api.grip(False)
    api.move(V(e[0], e[1], max(e[2], handle[2] + 0.12)), steps=15)
    api.move(pre + V(0, 0, 0.10), steps=30)
    api.move(pre, steps=20)
    api.move(handle, steps=20)
    api.grip(True)
    api.move(handle - d3 * 0.22, steps=50)
    api.grip(False)
    e = E(api)
    api.move(e + V(0, 0, 0.10), steps=15)


def twist_knob(api, k, grasp_z, on):
    """straddle the knob with open fingers, close, rotate about z, release,
    then restore wrist orientation"""
    sgn = 1.0 if on else -1.0
    api.grip(False)
    e = E(api)
    api.move(V(e[0], e[1], max(e[2], grasp_z + 0.15)), steps=15)
    api.move(V(k[0], k[1], grasp_z + 0.10), steps=25)
    api.move(V(k[0], k[1], grasp_z), steps=20)
    api.grip(True)
    api.action([0, 0, 0, 0, 0, 0.35 * sgn, 1.0], steps=12)
    api.grip(False)
    e = E(api)
    api.move(e + V(0, 0, 0.10), steps=12)
    api.action([0, 0, 0, 0, 0, -0.35 * sgn, -1.0], steps=12)


def sweep_stove(api, sp, cp, on):
    sgn = 1.0 if on else -1.0
    e = E(api)
    api.move(V(e[0], e[1], max(e[2], cp[2] + 0.15)), steps=15)
    api.grip(True)
    lines = [(cp[0] - 0.07, cp[2] + 0.015),
             (min(sp[0], cp[0]) - 0.13, max(cp[2] - 0.015, sp[2] + 0.012))]
    for x, z in lines:
        a = V(x, cp[1] + 0.13 * sgn, z)
        b = V(x, cp[1] - 0.13 * sgn, z)
        api.move(V(a[0], a[1], cp[2] + 0.12), steps=25)
        api.move(a, steps=20)
        api.move(b, steps=45)
        api.move(V(b[0], b[1], cp[2] + 0.12), steps=15)


def turn_stove(api, stove, names, on):
    kp = None
    for n in names:
        if n.startswith(_base(stove)) and any(k in n for k in ('knob', 'button', 'switch')):
            try:
                kp = P(api, n)
                break
            except Exception:
                pass
    if kp is None:
        for suf in ('_knob', '_button', '_knob_1', '_switch'):
            try:
                kp = P(api, stove + suf)
                break
            except Exception:
                kp = None
    cook = [n for n in names if n.startswith(stove + '_') and 'cook' in n]
    sp = P(api, stove)
    cp = P(api, cook[0]) if cook else sp + V(0, 0, 0.02)
    if kp is not None:
        twist_knob(api, kp, kp[2] + 0.005, on)
        return
    # knob shares the stove top with the burner, on the far side of the body centre
    d = sp[:2] - cp[:2]
    nd = np.linalg.norm(d)
    if nd >= 0.025:
        if nd > 0.15:
            d = d / nd * 0.15
        k = V(sp[0] + d[0], sp[1] + d[1], cp[2])
        twist_knob(api, k, cp[2] + 0.005, on)
        return
    sweep_stove(api, sp, cp, on)


# ---------------------------------------------------------------- main
def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    words = _words(api.instruction)
    ops = build_plan(api, names, bodies, words)
    for op in ops:
        try:
            kind = op[0]
            if kind == 'turn':
                turn_stove(api, op[1], names, op[2])
            elif kind == 'place':
                do_place(api, op[1], op[2], op[3], op[4])
            elif kind == 'close':
                push_close(api, op[1])
            elif kind == 'open':
                pull_open(api, op[1])
            elif kind == 'pick':
                pick_only(api, op[1])
        except Exception:
            try:
                recover(api)
            except Exception:
                pass
