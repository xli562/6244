def run(api):
    # Closing and opening drawers are not placement actions; delegate to the fallback program.
    api.fallback()
