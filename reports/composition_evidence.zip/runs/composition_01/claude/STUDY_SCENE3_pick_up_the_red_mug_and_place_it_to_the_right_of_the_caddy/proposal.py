def run(api):
    api.arrange([("red_coffee_mug_1", "desk_caddy_1_right_contain_region")])
