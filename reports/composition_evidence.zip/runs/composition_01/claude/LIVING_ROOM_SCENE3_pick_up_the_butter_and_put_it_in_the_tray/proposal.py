def run(api):
    api.arrange([("butter_1", "wooden_tray_1_contain_region")])
