def run(api):
    api.arrange([("white_bowl_1", "kitchen_table_plate_right_region")])
