def run(api):
    api.arrange([
        ("porcelain_mug_1", "plate_1"),
        ("chocolate_pudding_1", "living_room_table_plate_right_region"),
    ])
