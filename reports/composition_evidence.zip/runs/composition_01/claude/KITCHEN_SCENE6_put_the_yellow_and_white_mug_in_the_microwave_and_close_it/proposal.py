def run(api):
    api.fallback()
