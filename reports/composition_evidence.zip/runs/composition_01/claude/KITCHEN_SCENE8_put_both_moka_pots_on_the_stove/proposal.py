def run(api):
    api.arrange([
        ("moka_pot_1", "flat_stove_1_cook_region"),
        ("moka_pot_2", "flat_stove_1_cook_region"),
    ])
