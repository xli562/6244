def run(api):
    bowls = ["akita_black_bowl_1", "akita_black_bowl_2", "akita_black_bowl_3"]
    middle_bowl = api.nearest("kitchen_table_akita_black_bowl_middle_init_region", bowls)
    remaining = [b for b in bowls if b != middle_bowl]
    front_bowl = api.nearest("kitchen_table_akita_black_bowl_front_init_region", remaining)
    api.arrange([(middle_bowl, front_bowl)])
