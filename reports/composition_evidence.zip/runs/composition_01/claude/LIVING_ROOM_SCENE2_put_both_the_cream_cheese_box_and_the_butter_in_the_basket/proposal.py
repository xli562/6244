def run(api):
    api.arrange([
        ("cream_cheese_1", "basket_1_contain_region"),
        ("butter_1", "basket_1_contain_region"),
    ])
