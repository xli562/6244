import math
import numpy as np

ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl',
    'white_bowl': 'white bowl', 'porcelain_mug': 'white porcelain mug cup',
    'white_yellow_mug': 'white yellow mug cup', 'red_coffee_mug': 'red coffee mug cup',
    'chefmate_8_frypan': 'frying pan frypan skillet', 'flat_stove': 'stove burner cooktop',
    'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy', 'black_book': 'black book',
    'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle',
    'butter': 'butter box', 'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet drawer', 'wooden_cabinet': 'wooden wood cabinet drawer',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack', 'microwave': 'microwave oven',
    'basket': 'basket', 'plate': 'plate', 'glazed_rim_porcelain_ramekin': 'ramekin',
    'cookies': 'cookie cookies box',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown',
          'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'top',
        'left', 'right', 'front', 'back', 'bottom', 'middle', 'compartment',
        'side', 'its', 'that', 'is', 'please', 'then', 'on', 'in', 'into', 'onto'}
DIRS = ('left', 'right', 'front', 'back')
PUT_VERBS = {'put', 'place', 'set', 'move', 'stack', 'drop', 'pick', 'grab', 'take', 'lift'}
PICK_VERBS = {'pick', 'grab', 'take', 'lift'}
ALL_VERBS = PUT_VERBS | {'open', 'close', 'shut', 'pull', 'turn', 'switch', 'push', 'press'}
PLACE_PREPS = ('into', 'onto', 'inside', 'in', 'on', 'to', 'next', 'beside',
               'under', 'at', 'over', 'near', 'by')
DESC_PREPS = ('on', 'in', 'inside', 'next', 'near', 'from', 'at', 'between',
              'beside', 'by', 'under')


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def E(api):
    return np.array(api.eef(), dtype=float)


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _isreg(n):
    return n.endswith('_region') or n.endswith('_side')


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return w


def _norm(ws):
    out = set()
    for w in ws:
        if w in STOP:
            continue
        out.add(w)
        if len(w) > 3 and w.endswith('s'):
            out.add(w[:-1])
    return out


def _cands(bodies, ws, exclude=()):
    W = _norm(ws)
    if not W:
        return []
    best, out = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if not m:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D) - 0.1 * len(D - W)
        if s > best + 1e-9:
            best, out = s, [b]
        elif abs(s - best) < 1e-9:
            out.append(b)
    return out


def resolve(api, bodies, ws, exclude=()):
    ws = list(ws)
    head, ref = ws, []
    for i, w in enumerate(ws):
        if i > 0 and w in DESC_PREPS:
            head, ref = ws[:i], ws[i + 1:]
            break
    c = _cands(bodies, head, exclude)
    if not c:
        c, ref = _cands(bodies, ws, exclude), []
    if not c:
        return None
    if len(c) == 1:
        return c[0]
    if ref:
        r = _cands(bodies, ref, exclude=tuple(c))
        if r:
            try:
                n = api.nearest(r[0], list(c))
                if n in c:
                    return n
            except Exception:
                pass
            rp = P(api, r[0])
            return min(c, key=lambda x: np.linalg.norm(P(api, x)[:2] - rp[:2]))
    keys = {'left': lambda p: -p[1], 'right': lambda p: p[1],
            'front': lambda p: p[0], 'back': lambda p: -p[0]}
    for d in DIRS:
        if d in head:
            return sorted(c, key=lambda x: keys[d](P(api, x)))[0]
    return sorted(c)[0]


def _is_cab(names, owner):
    return any(owner + s in names for s in
               ('_top_side', '_top_region', '_middle_region', '_bottom_region'))


def _drawer_reg(names, owner, ws):
    for lvl in ('top', 'middle', 'bottom'):
        if lvl in ws and owner + '_' + lvl + '_region' in names:
            return owner + '_' + lvl + '_region'
    for lvl in ('top', 'middle', 'bottom'):
        if owner + '_' + lvl + '_region' in names:
            return owner + '_' + lvl + '_region'
    return None


def target_for(api, names, bodies, prep, tw, st):
    inside = prep in ('in', 'into', 'inside')
    # explicit spatial relation: "<dir> [side|compartment] of <ref>"
    for j, w in enumerate(tw):
        if w in DIRS:
            k = j + 1
            while k < len(tw) and tw[k] in ('side', 'compartment', 'part', 'corner', 'area'):
                k += 1
            if k < len(tw) and tw[k] == 'of':
                ref = resolve(api, bodies, tw[k + 1:])
                if ref:
                    rel = 'inside' if (inside and not (j == 0 and w == 'front')) else 'outside'
                    if prep in ('to', 'next', 'beside', 'by', 'near'):
                        rel = 'outside'
                    try:
                        return api.relative_target(ref, w, rel)
                    except Exception:
                        pass
            break
    if not tw or tw in (['it'], ['them']):
        return st['drawer'] if (inside and st['drawer']) else st['target']
    owner = resolve(api, bodies, tw)
    if owner is None:
        return None
    if _is_cab(names, owner):
        if inside:
            return _drawer_reg(names, owner, tw)
        if owner + '_top_side' in names:          # "on top of the drawer/cabinet"
            return owner + '_top_side'
        return _drawer_reg(names, owner, tw)
    regs = [n for n in names if _isreg(n) and n.startswith(owner + '_')]
    if not regs:
        return owner
    if len(regs) == 1:
        return regs[0]
    T = set(tw)
    best, bs = regs[0], -1e9
    for r in regs:
        toks = set(r[len(owner) + 1:].split('_')) - {'region', 'side'}
        s = 3 * len(toks & T)
        if toks & {'contain', 'cook', 'heating', 'top'}:
            s += 1
        if s > bs:
            bs, best = s, r
    return best


def grasp_for(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'          # pinch the wall of an open bowl
    if 'book' in b:
        return 'thin_edge'    # jaws across a narrow book-like object
    return 'standard'         # bottles, boxes, cans, mugs, ...


def split_clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if (w == 'and' and (nxt in ALL_VERBS or nxt == 'then')) or w == 'then':
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return out


def split_items(ws):
    both = 'both' in ws
    has_the = any(ws[j] == 'and' and j + 1 < len(ws) and ws[j + 1] in ('the', 'a')
                  for j in range(len(ws)))
    parts = [[]]
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if w == 'and' and ((has_the and nxt in ('the', 'a')) or (both and not has_the)):
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def build(api, names, bodies, words):
    ops = []
    st = {'item': [], 'target': None, 'drawer': None}
    for c in split_clauses(words):
        while c and c[-1] in ('and', 'then'):
            c = c[:-1]
        if not c:
            continue
        v, rest = c[0], [w for w in c[1:] if w != 'up']
        if v in ('open', 'close', 'shut', 'pull'):
            act = 'open' if v in ('open', 'pull') else 'close'
            if not rest or rest in (['it'], ['them']):
                reg = st['drawer']
            else:
                owner = resolve(api, bodies, rest)
                if owner is None or not _is_cab(names, owner):
                    return None
                reg = _drawer_reg(names, owner, rest)
            if reg is None:
                return None
            ops.append(('drawer', reg, act))
            st['drawer'] = reg
            continue
        if v not in PUT_VERBS:
            return None                            # turn on/off, push ... -> old policy
        idx = None
        if v not in PICK_VERBS:
            for i, w in enumerate(rest):
                if i > 0 and w in PLACE_PREPS:
                    idx = i
                    break
        if idx is None:
            if v not in PICK_VERBS:
                return None
            it = st['item'][-1] if rest in (['it'], ['them']) and st['item'] \
                else resolve(api, bodies, rest)
            if it is None:
                return None
            ops.append(('pick', it))
            st['item'] = [it]
            continue
        prep, item_w, tw = rest[idx], rest[:idx], rest[idx + 1:]
        tgt = target_for(api, names, bodies, prep, tw, st)
        if tgt is None:
            return None
        owner = tgt
        for b in bodies:
            if tgt.startswith(b + '_') or tgt == b:
                owner = b
        items = []
        for part in split_items(item_w):
            if part in (['it'], ['them']):
                its = list(st['item'])
            else:
                r = resolve(api, bodies, part, exclude=(owner,))
                its = [r] if r else []
            for it in its:
                if it not in items:
                    items.append(it)
        if not items:
            return None
        if ops and ops[-1][0] == 'pick' and ops[-1][1] in items:
            ops.pop()
        for it in items:
            ops.append(('place', it, tgt, grasp_for(it)))
        st['item'], st['target'] = items, tgt
        if tgt.endswith(('_top_region', '_middle_region', '_bottom_region')) and \
                _is_cab(names, owner):
            st['drawer'] = tgt
    return ops


def _near(api, item, tgt):
    try:
        ip, tp = P(api, item), P(api, tgt)
    except Exception:
        return True
    tol = 0.06 if ('caddy' in tgt or 'compartment' in tgt) else 0.10
    ok = np.linalg.norm(ip[:2] - tp[:2]) < tol
    if tgt.endswith('_side') or 'drawer' not in tgt:
        ok = ok and ip[2] > tp[2] - 0.05
    return ok


def _recover(api):
    try:
        api.grip(False)
        e = E(api)
        api.move(e + np.array([0, 0, 0.12]), steps=15)
    except Exception:
        pass


def _pick(api, item):
    p = P(api, item)
    api.grip(False)
    e = E(api)
    api.move(np.array([e[0], e[1], max(e[2], p[2] + 0.15)]), steps=15)
    api.move(p + np.array([0, 0, 0.10]), steps=25)
    api.move(p, steps=20)
    api.grip(True)
    api.move(p + np.array([0, 0, 0.15]), steps=20)


def run(api):
    try:
        names = list(api.names())
        bodies = [n for n in names if not _isreg(n)]
        ops = build(api, names, bodies, _words(api.instruction))
    except Exception:
        ops = None
    if not ops:
        return api.fallback()
    # e.g. "put the wine bottle on the top of the drawer" ->
    #   [('place', 'wine_bottle_1', 'wooden_cabinet_1_top_side', 'standard')]
    for op in ops:
        try:
            if op[0] == 'drawer':
                api.drawer(op[1], op[2])
            elif op[0] == 'place':
                _, item, tgt, g = op
                api.place_with(item, tgt, g)
                if not _near(api, item, tgt):
                    _recover(api)
                    api.place_with(item, tgt, g)
            elif op[0] == 'pick':
                _pick(api, op[1])
        except Exception:
            _recover(api)
