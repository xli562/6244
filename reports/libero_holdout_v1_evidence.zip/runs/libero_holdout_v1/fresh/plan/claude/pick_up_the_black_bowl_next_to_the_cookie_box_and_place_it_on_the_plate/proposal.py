import math
import numpy as np

ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl', 'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup', 'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup', 'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop', 'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy',
    'black_book': 'black book', 'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle', 'butter': 'butter box',
    'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'cookies': 'cookies cookie box', 'glazed_rim_porcelain_ramekin': 'ramekin porcelain',
    'wooden_cabinet': 'wooden cabinet', 'white_cabinet': 'white cabinet',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack', 'microwave': 'microwave oven',
    'plate': 'plate', 'basket': 'basket',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown', 'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'please', 'then',
        'its', 'that', 'is', 'which', 'one', 'object'}
DIRS = ('left', 'right', 'front', 'back')
VERBS = {'put', 'place', 'turn', 'switch', 'close', 'shut', 'open', 'pick', 'push', 'pull',
         'move', 'stack', 'lift', 'grab', 'take', 'set'}
PREPS = ('into', 'onto', 'inside', 'in', 'on')
LOCS = ('next', 'between', 'on', 'in', 'inside', 'from', 'at', 'near', 'beside', 'by', 'closest')


def _n(w):
    return w[:-1] if len(w) > 3 and w.endswith('s') and not w.endswith('ss') else w


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side') or n.startswith('main_table')


def _desc(b):
    base = _base(b)
    w = set(_n(x) for x in base.split('_'))
    w |= set(_n(x) for x in ALIAS.get(base, '').split())
    return w


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def _content(ws):
    return set(_n(w) for w in ws if w not in STOP and w not in DIRS
               and w not in ('top', 'bottom', 'middle', 'drawer', 'compartment', 'side'))


def _cands(bodies, ws, exclude=()):
    W = _content(ws)
    if not W:
        return []
    best, out = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, out = s, [b]
        elif abs(s - best) < 1e-9:
            out.append(b)
    return sorted(out)


def _loc_point(api, names, bodies, loc, exclude):
    """xy reference point described by a locator phrase."""
    if not loc:
        return None
    ws = [w for w in loc if w not in ('to', 'the', 'a')]
    if 'center' in ws or 'centre' in ws:
        for n in names:
            if 'table_center' in n:
                return P(api, n)[:2]
    if 'and' in ws:
        i = ws.index('and')
        pts = [_loc_point(api, names, bodies, part, exclude) for part in (ws[:i], ws[i + 1:])]
        pts = [p for p in pts if p is not None]
        if pts:
            return np.mean(pts, axis=0)
    c = _cands(bodies, ws, exclude)
    if c:
        return np.mean([P(api, x)[:2] for x in c], axis=0) if len(c) == 1 else P(api, c[0])[:2]
    return None


def resolve_item(api, names, bodies, ws, exclude=()):
    if ws in (['it'], ['them']):
        return None
    li = None
    for i, w in enumerate(ws):
        if w in LOCS and i > 0:
            li = i
            break
    noun, loc = (ws, []) if li is None else (ws[:li], ws[li + 1:])
    c = _cands(bodies, noun, exclude)
    if not c:
        return None
    if len(c) > 1:
        pt = _loc_point(api, names, bodies, loc, exclude=set(c) | set(exclude))
        if pt is not None:
            c.sort(key=lambda b: np.linalg.norm(P(api, b)[:2] - pt))
        else:
            for d in DIRS:
                if d in ws:
                    key = {'left': lambda p: p[1], 'right': lambda p: -p[1],
                           'front': lambda p: -p[0], 'back': lambda p: p[0]}[d]
                    c.sort(key=lambda b: key(P(api, b)))
                    break
    return c[0]


def resolve_target(api, names, bodies, ws, for_drawer=False):
    owner = resolve_item(api, names, bodies, ws)
    if owner is None:
        W = _content(ws)
        regs = [n for n in names if _is_region(n) and W & set(_n(x) for x in n.split('_'))]
        return (regs[0], regs[0]) if regs else None
    regs = [n for n in names if _is_region(n) and n.startswith(owner + '_')]
    R = set(ws)
    drawer = for_drawer or 'drawer' in R or 'drawers' in R
    d = [x for x in DIRS if x in R]
    if d and not any(d[0] in r.split('_') for r in regs):
        rel = 'inside' if (R & {'in', 'inside', 'into', 'compartment'}) else 'outside'
        try:
            r = api.relative_target(owner, d[0], rel)
            if r:
                return (r, owner)
        except Exception:
            pass
    if not regs:
        return (owner, owner)
    best, bs = None, -1e9
    for r in regs:
        suf = r[len(owner) + 1:].split('_')
        toks = set(suf) - {'region', 'contain', 'side'}
        s = 3 * len(toks & R)
        if drawer and 'side' in suf:
            s -= 5
        if not drawer and 'top' in R and 'side' in suf:
            s += 2
        if not toks or toks <= {'cook', 'heating'}:
            s += 1
        if s > bs:
            bs, best = s, r
    if bs <= 0 and not drawer and 'cabinet' not in owner and 'stove' not in owner:
        return (owner, owner)
    return (best, owner)


def split_clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if (w == 'and' and (nxt in VERBS or nxt == 'then')) or w == 'then':
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return out


def split_items(ws):
    ws = [w for w in ws if w != 'both']
    parts, cur = [], []
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if w == 'and' and (nxt in ('the', 'a') or not any(x in LOCS for x in cur)):
            parts.append(cur)
            cur = []
        else:
            cur.append(w)
    parts.append(cur)
    parts = [p for p in parts if p]
    # "between the plate and the ramekin" must not be split
    if len(parts) > 1 and any('between' in p for p in parts[:-1]):
        return [ws]
    return parts


def grasp_for(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


def placed_ok(api, item, target):
    ip, tp = P(api, item), P(api, target)
    tol = 0.045 if 'caddy' in target else (0.08 if ('basket' in target or 'contain' in target) else 0.07)
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.06


def recover(api):
    api.grip(False)
    e = np.array(api.eef(), dtype=float)
    api.move(e + np.array([0, 0, 0.12]), steps=15)


def place(api, item, target):
    g = grasp_for(item)
    for _ in range(2):
        try:
            api.place_with(item, target, g)
        except Exception:
            pass
        if placed_ok(api, item, target):
            return True
        recover(api)
    offs = [(0.0, 0.06, 0.025), (0.0, -0.06, 0.025)] if g == 'rim' else [(0, 0, 0)]
    for o in offs:
        try:
            api.transfer(item, target, grasp=o, drop=(0, 0, 0.08))
        except Exception:
            pass
        if placed_ok(api, item, target):
            return True
        recover(api)
    return False


def build_plan(api, names, bodies, words):
    ops, last_item, last_tgt = [], None, None
    pending_pick = None
    for c in split_clauses(words):
        while c and c[-1] == 'and':
            c = c[:-1]
        if not c:
            continue
        v, rest = c[0], [w for w in c[1:] if w != 'up']
        if v in ('turn', 'switch', 'push', 'pull'):
            return None                                   # unsupported -> fallback
        if v in ('open', 'close', 'shut'):
            t = last_tgt if rest in ([], ['it'], ['them']) else \
                resolve_target(api, names, bodies, rest, for_drawer=True)
            if t is None:
                return None
            reg = t[0]
            if reg.endswith('_top_side'):
                reg = reg[:-len('_top_side')] + '_top_region'
            ops.append(('drawer', reg, 'open' if v == 'open' else 'close'))
            last_tgt = (reg, t[1])
            continue
        if v in ('pick', 'grab', 'lift', 'take'):
            idx = None
            for i, w in enumerate(rest):
                if w in ('onto', 'into') and i > 0:
                    idx = i
            if idx is None:
                pending_pick = resolve_item(api, names, bodies, rest)
                if pending_pick is None:
                    return None
                last_item = pending_pick
                continue
        idx = None
        for i, w in enumerate(rest):
            if w in PREPS and i > 0:
                idx = i                                   # last preposition = destination
        if idx is None:
            return None
        item_w, tw = rest[:idx], rest[idx + 1:]
        tgt = last_tgt if tw in ([], ['it'], ['them']) else resolve_target(api, names, bodies, tw)
        if tgt is None:
            return None
        items = []
        for part in split_items(item_w):
            it = last_item if part in (['it'], ['them']) or not part else \
                resolve_item(api, names, bodies, part, exclude=(tgt[1],))
            if it and it not in items:
                items.append(it)
        if not items:
            return None
        for it in items:
            ops.append(('place', it, tgt[0]))
        pending_pick = None
        last_item, last_tgt = items[-1], tgt
    if pending_pick is not None:
        ops.append(('pick', pending_pick))
    return ops


def pick_only(api, item):
    p = P(api, item)
    api.grip(False)
    api.move(p + np.array([0, 0, 0.12]), steps=30)
    api.move(p, steps=25)
    api.grip(True)
    api.move(p + np.array([0, 0, 0.15]), steps=25)


def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    try:
        ops = build_plan(api, names, bodies, _words(api.instruction))
    except Exception:
        ops = None
    if not ops:
        return api.fallback()
    for op in ops:
        try:
            if op[0] == 'drawer':
                api.drawer(op[1], op[2])
            elif op[0] == 'place':
                place(api, op[1], op[2])
            elif op[0] == 'pick':
                pick_only(api, op[1])
        except Exception:
            try:
                recover(api)
            except Exception:
                pass
