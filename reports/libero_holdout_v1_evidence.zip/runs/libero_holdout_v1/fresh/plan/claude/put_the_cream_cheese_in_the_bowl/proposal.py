import numpy as np

ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl', 'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup', 'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup', 'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop', 'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy',
    'black_book': 'black book', 'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle', 'butter': 'butter box',
    'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet', 'wooden_cabinet': 'wooden cabinet',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack', 'microwave': 'microwave oven',
    'basket': 'basket', 'plate': 'plate',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown', 'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'top', 'left', 'right',
        'front', 'back', 'bottom', 'middle', 'compartment', 'side', 'its', 'that', 'is',
        'please', 'then', 'table', 'next', 'beside', 'near', 'drawer', 'drawers', 'region'}
PLACE_V = {'put', 'place', 'move', 'stack', 'set'}
DRAWER_V = {'open', 'close', 'shut'}
OTHER_V = {'turn', 'switch', 'pick', 'push', 'pull', 'lift', 'grab', 'take'}
VERBS = PLACE_V | DRAWER_V | OTHER_V
PREPS = ('into', 'onto', 'inside', 'in', 'on')
DIRS = ('left', 'right', 'front', 'back')


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return w


def resolve(api, bodies, raw, exclude=()):
    W = set(w for w in raw if w not in STOP)
    if not W:
        return None
    best, cands = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, cands = s, [b]
        elif abs(s - best) < 1e-9:
            cands.append(b)
    if not cands:
        return None
    if len(cands) > 1:
        for w in DIRS:
            if w in raw:
                key = {'left': lambda p: -p[1], 'right': lambda p: p[1],
                       'front': lambda p: p[0], 'back': lambda p: -p[0]}[w]
                cands = sorted(cands, key=lambda c: key(P(api, c)))
                break
        else:
            cands = sorted(cands)
    return cands[0]


def resolve_target(api, names, bodies, tw, prep):
    R = set(tw)
    drawer = bool(R & {'drawer', 'drawers'})
    dirs = [d for d in DIRS if d in R]
    if dirs and not drawer:
        rel = 'outside' if R & {'table', 'next', 'beside', 'near', 'outside'} else 'inside'
        ref = resolve(api, bodies, tw)
        if ref:
            try:
                r = api.relative_target(ref, dirs[0], rel)
                if r:
                    return (r, ref)
            except Exception:
                pass
    obj = resolve(api, bodies, tw)
    if obj is None and drawer:
        for b in bodies:
            if any(n.startswith(b + '_') and n.endswith(('top_region', 'bottom_region'))
                   for n in names):
                obj = b
                break
    if obj is None:
        return None
    regs = [n for n in names if _is_region(n) and n.startswith(obj + '_')]
    if not regs:
        return (obj, obj)
    if drawer:
        for w in ('top', 'middle', 'bottom'):
            if w in R and obj + '_' + w + '_region' in names:
                return (obj + '_' + w + '_region', obj)
        c = [r for r in regs if r.endswith('_region')
             and any(w in r for w in ('top', 'middle', 'bottom'))]
        return (c[0], obj) if c else None
    side = [r for r in regs if r.endswith('_side')]
    if side and ('top' in R or prep in ('on', 'onto')):
        return (side[0], obj)
    for key in ('contain', 'cook', 'heating'):
        for r in regs:
            if key in r:
                return (r, obj)
    if 'top' in R:
        for r in regs:
            if 'top' in r:
                return (r, obj)
    if len(regs) == 1:
        return (regs[0], obj)
    return (obj, obj)


def split_clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if (w == 'and' and (nxt in VERBS or nxt == 'then')) or w == 'then':
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return out


def split_items(ws):
    both = 'both' in ws
    has_the = any(ws[j] == 'and' and j + 1 < len(ws) and ws[j + 1] in ('the', 'a')
                  for j in range(len(ws)))
    parts = [[]]
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if w == 'and' and ((has_the and nxt in ('the', 'a')) or (both and not has_the)):
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def build_plan(api, names, bodies, words):
    ops, last_item, last_tgt = [], None, None
    for c in split_clauses(words):
        while c and c[-1] == 'and':
            c = c[:-1]
        if not c:
            continue
        v, rest = c[0], [w for w in c[1:] if w != 'up']
        if v in DRAWER_V:
            if not rest or rest in (['it'], ['them']):
                tgt = last_tgt
            else:
                tgt = resolve_target(api, names, bodies, rest + ['drawer'], None)
            if tgt is None:
                return None
            ops.append(('drawer', tgt, 'open' if v == 'open' else 'close'))
            last_tgt = tgt
            continue
        if v not in PLACE_V:
            return None                      # unsupported -> previous policy
        idx = next((i for i, w in enumerate(rest) if w in PREPS and i > 0), None)
        if idx is None:
            return None
        item_w, tw, prep = rest[:idx], rest[idx + 1:], rest[idx]
        if not tw or tw in (['it'], ['them']):
            tgt = last_tgt
        else:
            tgt = resolve_target(api, names, bodies, tw, prep)
        if tgt is None:
            return None
        items = []
        for part in split_items(item_w):
            it = last_item if part in (['it'], ['them']) else \
                resolve(api, bodies, part, exclude=(tgt[1],))
            if it and it not in items:
                items.append(it)
        if not items:
            return None
        for it in items:
            ops.append(('place', it, tgt))
        last_item, last_tgt = items[-1], tgt
    return ops


def grasp_for(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'          # pinch the wall of an open bowl
    if 'book' in b:
        return 'thin_edge'    # jaws across the narrow book
    return 'standard'         # boxes, cans, bottles, mugs, cheese


def placed(api, item, tname):
    try:
        ip, tp = P(api, item), P(api, tname)
    except Exception:
        return False
    tol = 0.045 if 'caddy' in tname else 0.08
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.06


def lift_clear(api):
    try:
        api.grip(False)
        e = np.array(api.eef(), dtype=float)
        api.move(e + np.array([0.0, 0.0, 0.10]), steps=10)
    except Exception:
        pass


def do_place(api, item, tgt):
    g = grasp_for(item)
    for attempt in range(2):
        try:
            api.place_with(item, tgt[0], g)
        except Exception:
            try:
                api.arrange([(item, tgt[0])])
            except Exception:
                pass
        if placed(api, item, tgt[0]):
            return True
        lift_clear(api)
    return False


def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    words = _words(api.instruction)
    try:
        ops = build_plan(api, names, bodies, words)
    except Exception:
        ops = None
    if not ops:
        api.fallback()
        return
    # e.g. "put the cream cheese on the bowl" ->
    #   [('place', 'cream_cheese_1', ('akita_black_bowl_1', 'akita_black_bowl_1'))]
    #   grasp = 'standard'
    for op in ops:
        try:
            if op[0] == 'drawer':
                api.drawer(op[1][0], op[2])
            elif op[0] == 'place':
                do_place(api, op[1], op[2])
        except Exception:
            lift_clear(api)
