import math
import numpy as np

ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl',
    'white_bowl': 'white bowl', 'cookies': 'cookie cookies box',
    'glazed_rim_porcelain_ramekin': 'ramekin', 'flat_stove': 'stove burner cooktop',
    'wooden_cabinet': 'wooden cabinet', 'white_cabinet': 'white cabinet',
    'porcelain_mug': 'white porcelain mug cup', 'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup', 'chefmate_8_frypan': 'frying pan frypan skillet',
    'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy', 'black_book': 'black book',
    'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle',
    'butter': 'butter box', 'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack', 'microwave': 'microwave oven',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown',
          'wooden', 'pink', 'orange'}
STOPW = {'the', 'a', 'an', 'of', 'it', 'them', 'up', 'to', 'please'}
QUAL = {'between', 'next', 'near', 'beside', 'by', 'on', 'in', 'inside',
        'from', 'at', 'atop'}
REL = ('between', 'next', 'near', 'beside', 'by')
PICKV = {'pick', 'grab', 'take', 'lift'}
PLACEV = {'place', 'put', 'set', 'move'}
TPREP = {'on', 'onto', 'in', 'into', 'inside', 'next', 'between', 'to',
         'atop', 'near', 'beside'}
COMPLEX = {'then', 'open', 'close', 'shut', 'turn', 'switch', 'both'}


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return (n.endswith('_region') or n.endswith('_side') or n.startswith('main_table')
            or n.endswith('_center') or n.endswith('_front'))


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return w


def _has(D, w):
    return w in D or (w.endswith('s') and w[:-1] in D) or (w + 's') in D


def _P(api, n):
    return np.array(api.pos(n), dtype=float)


def _cands(bodies, phrase, exclude=()):
    toks = [w for w in phrase if w not in STOPW]
    if not toks:
        return []
    pool = [b for b in bodies if b not in exclude]
    head = toks[-1]
    c = [b for b in pool if _has(_desc(b), head)]
    if not c:
        c = [b for b in pool if any(_has(_desc(b), w) for w in toks)]
    if not c:
        return []
    cols = [w for w in toks if w in COLORS]
    if cols:
        c2 = [b for b in c if all(_has(_desc(b), w) for w in cols)]
        if c2:
            c = c2
    sc = {b: sum(_has(_desc(b), w) for w in toks)
          - len((_desc(b) & COLORS) - set(toks)) for b in c}
    m = max(sc.values())
    return sorted(b for b in c if sc[b] == m)


def _parts(words):
    parts = [[]]
    for w in words:
        if w == 'and':
            parts.append([])
        elif w not in STOPW and w not in REL:
            parts[-1].append(w)
    return [p for p in parts if p]


def _rel_region(names, bodies, kw, words, exclude):
    key = 'between' if kw == 'between' else 'next'
    sets = []
    for p in _parts(words):
        s = set(p)
        c = _cands(bodies, p, exclude)
        if c:
            s |= _desc(c[0])
        sets.append(s)
    if not sets:
        return None
    best, bs = None, 0
    for r in names:
        if not _is_region(r):
            continue
        rt = set(r.split('_'))
        if key not in rt or not all(rt & s for s in sets):
            continue
        sc = sum(len(rt & s) for s in sets)
        if sc > bs:
            best, bs = r, sc
    return best


def _target(names, bodies, words, exclude, prep_on):
    W = [w for w in words if w not in STOPW]
    for kw in REL:
        if kw in W:
            r = _rel_region(names, bodies, kw, W[W.index(kw):], exclude)
            if r:
                return r
    regs = [n for n in names if _is_region(n)]
    if 'table' in W and ('center' in W or 'front' in W):
        for r in regs:
            if 'table' in r and (('center' in W and 'center' in r)
                                 or ('front' in W and 'front' in r)):
                return r
    drawer = 'drawer' in W or 'drawers' in W
    noun = [w for w in W if w not in ('on', 'onto', 'in', 'into', 'inside', 'top',
                                      'middle', 'bottom', 'drawer', 'drawers', 'side',
                                      'compartment', 'surface', 'at', 'from', 'atop')]
    c = _cands(bodies, noun, exclude)
    if not c:
        return None
    o = c[0]
    sub = [n for n in regs if n.startswith(o + '_')]
    if not sub:
        return o
    lv = [w for w in ('top', 'middle', 'bottom') if w in W]
    best, bs = None, -1e9
    for r in sub:
        suf = set(r[len(o) + 1:].split('_'))
        s = 0
        if drawer:
            if 'side' in suf:
                s -= 10
            if lv and lv[0] in suf:
                s += 5
        else:
            if 'side' in suf and (prep_on or 'top' in W):
                s += 6
            if suf & {'cook', 'heating', 'contain'}:
                s += 3
            s += 2 * len((suf & set(W)) - {'region'})
        if s > bs:
            bs, best = s, r
    if drawer or bs > 0:
        return best
    return o


def _pick_item(api, names, bodies, cands, qual):
    if len(cands) == 1 or not qual:
        return cands[0]
    kw = qual[0]
    ref = None
    if kw in REL:
        ref = _rel_region(names, bodies, kw, qual, cands)
    if ref is None:
        ref = _target(names, bodies, qual, cands, kw in ('on', 'atop'))
    pt = None
    if ref is not None:
        pt = _P(api, ref)
    elif kw == 'between':
        pts = []
        for p in _parts(qual):
            c = _cands(bodies, p, cands)
            if c:
                pts.append(_P(api, c[0]))
        if pts:
            pt = np.mean(pts, axis=0)
    if pt is None:
        return cands[0]
    ds = sorted((np.linalg.norm(_P(api, c) - pt), c) for c in cands)
    if ref is not None and len(ds) > 1 and ds[0][0] > 0.7 * ds[1][0]:
        try:   # ambiguous: let the shared resolver decide
            r = api.nearest(ref, list(cands))
            if r in cands:
                return r
        except Exception:
            pass
    return ds[0][1]


def _grasp(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


def _plan(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    words = _words(api.instruction)
    if not words or any(w in COMPLEX for w in words):
        return None
    v = words[0]
    if v in PICKV:
        js = [i for i, w in enumerate(words) if i > 1 and w in PLACEV and words[i - 1] == 'and']
        if len(js) != 1:
            return None
        j = js[0]
        left = [w for w in words[1:j - 1] if w != 'up']
        right = words[j + 1:]
        qi = next((i for i, w in enumerate(left) if i > 0 and w in QUAL), None)
        item_w = left[:qi] if qi is not None else left
        qual = left[qi:] if qi is not None else []
    elif v in PLACEV:
        rest = words[1:]
        qi = next((i for i, w in enumerate(rest) if i > 0 and w in TPREP), None)
        if qi is None:
            return None
        item_w, qual, right = rest[:qi], [], rest[qi:]
        if 'and' in item_w or ('and' in right and 'between' not in right):
            return None
    else:
        return None
    cands = _cands(bodies, item_w)
    if not cands:
        return None
    item = _pick_item(api, names, bodies, cands, qual)
    R = [w for w in right if w not in STOPW]
    tgt = _target(names, bodies, R, (item,),
                  ('on' in R or 'onto' in R) and 'drawer' not in R)
    if tgt is None:
        return None
    return item, tgt, _grasp(item)


def _placed(api, item, tgt):
    ip, tp = _P(api, item), _P(api, tgt)
    tol = 0.10 if ('contain' in tgt or 'cabinet' in tgt or 'basket' in tgt) else 0.08
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.05


def _recover(api):
    try:
        api.grip(False)
        e = np.array(api.eef(), dtype=float)
        api.move(e + np.array([0.0, 0.0, 0.10]), steps=12)
    except Exception:
        pass


def run(api):
    try:
        plan = _plan(api)
    except Exception:
        plan = None
    if plan is None:
        return api.fallback()
    item, tgt, grasp = plan
    # e.g. ('akita_black_bowl_k' nearest between-region, 'plate_1', 'rim')
    for _ in range(2):
        try:
            api.place_with(item, tgt, grasp)
        except Exception:
            pass
        try:
            if _placed(api, item, tgt):
                return
        except Exception:
            return
        _recover(api)
