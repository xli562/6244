import math
import numpy as np

ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl', 'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup', 'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup', 'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop', 'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy',
    'black_book': 'black book', 'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle', 'butter': 'butter box',
    'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet', 'wooden_cabinet': 'wooden cabinet',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack', 'microwave': 'microwave oven',
    'basket': 'basket', 'plate': 'plate',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown', 'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'top', 'left', 'right',
        'front', 'back', 'bottom', 'middle', 'compartment', 'side', 'its', 'that', 'is',
        'please', 'then', 'drawer', 'next', 'region', 'area', 'inside', 'in', 'on', 'onto', 'into'}
VERBS = {'put', 'place', 'turn', 'switch', 'close', 'shut', 'open', 'pick', 'push', 'pull',
         'move', 'stack', 'lift', 'grab', 'take', 'set'}
PREPS = ('into', 'onto', 'inside', 'in', 'on', 'to', 'next', 'beside', 'at')
DIRS = ('left', 'right', 'front', 'back')
LEVELS = ('top', 'middle', 'bottom')


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return w


def _resolve(api, bodies, ws, exclude=()):
    W = set(w for w in ws if w not in STOP)
    if not W:
        return None
    best, cands = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, cands = s, [b]
        elif abs(s - best) < 1e-9:
            cands.append(b)
    if not cands:
        return None
    if len(cands) > 1:
        for d in DIRS:
            if d in ws:
                key = {'left': lambda p: -p[1], 'right': lambda p: p[1],
                       'front': lambda p: p[0], 'back': lambda p: -p[0]}[d]
                cands.sort(key=lambda c: key(np.array(api.pos(c), dtype=float)))
                break
        else:
            cands.sort()
    return cands[0]


def _grasp_for(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


def _target(api, names, bodies, tw, prep):
    """Return a placement/operation name for target words, or None."""
    obj = _resolve(api, bodies, tw)
    if obj is None:
        # maybe a bare region name like the floor/table
        W = set(tw) - STOP
        regs = [n for n in names if _is_region(n) and W & set(n.split('_'))]
        return regs[0] if regs else None
    regs = [n for n in names if _is_region(n) and n.startswith(obj + '_')]
    T = set(tw)
    d = next((x for x in DIRS if x in T), None)
    lvl = next((x for x in LEVELS if x in T), None)
    drawer = 'drawer' in T or 'drawers' in T
    # cabinet: drawer level vs top surface
    if lvl and regs:
        if drawer or prep in ('in', 'into', 'inside'):
            c = [r for r in regs if lvl in r.split('_') and 'side' not in r.split('_')]
        else:
            c = [r for r in regs if 'top' in r.split('_') and 'side' in r.split('_')]
        if c:
            return c[0]
    if d:
        c = [r for r in regs if d in r.split('_')]
        if c:
            return c[0]
        rel = 'inside' if prep in ('in', 'into', 'inside') and 'of' not in T else 'outside'
        try:
            r = api.relative_target(obj, d, rel)
            if r:
                return r
        except Exception:
            pass
    c = [r for r in regs if 'contain' in r]
    if c:
        return c[0]
    c = [r for r in regs if 'side' not in r.split('_')]
    if c:
        return sorted(c, key=len)[0]
    return regs[0] if regs else obj


def _clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if (w == 'and' and (nxt in VERBS or nxt == 'then')) or w == 'then':
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return out


def _items(api, bodies, ws, last_item, exclude):
    parts, cur = [], []
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if w == 'and' and nxt in ('the', 'a'):
            parts.append(cur)
            cur = []
        elif w != 'both':
            cur.append(w)
    parts.append(cur)
    out = []
    for p in parts:
        if not p or p in (['it'], ['them']):
            it = last_item
        else:
            it = _resolve(api, bodies, p, exclude=exclude)
        if it and it not in out:
            out.append(it)
    return out


def _plan(api, names, bodies, words):
    ops, last_item, last_tgt = [], None, None
    for c in _clauses(words):
        v, rest = c[0], [w for w in c[1:] if w != 'up']
        if v in ('turn', 'switch'):
            return None                     # unsupported -> fallback
        if v in ('open', 'close', 'shut'):
            if not rest or rest in (['it'], ['them']):
                tgt = last_tgt
            else:
                tgt = _target(api, names, bodies, rest + ['drawer'], 'in')
            if not tgt:
                return None
            ops.append(('drawer', tgt, 'open' if v == 'open' else 'close'))
            last_tgt = tgt
            continue
        idx = next((i for i, w in enumerate(rest) if w in PREPS and i > 0), None)
        if idx is None:
            if v in ('pick', 'grab', 'lift', 'take'):
                it = _resolve(api, bodies, rest)
                if it:
                    last_item = it          # merged into the following placement
                continue
            item_w, tw, prep = rest, [], 'in'
        else:
            item_w, tw, prep = rest[:idx], rest[idx + 1:], rest[idx]
        if not tw or tw in (['it'], ['them']):
            tgt = last_tgt
        else:
            tgt = _target(api, names, bodies, tw, prep)
        if not tgt:
            return None
        owner = _resolve(api, bodies, tw) if tw else None
        items = _items(api, bodies, item_w, last_item, exclude=(owner,) if owner else ())
        if not items:
            return None
        for it in items:
            ops.append(('place', it, tgt))
        last_item, last_tgt = items[-1], tgt
    return ops


def _placed(api, item, tgt):
    try:
        ip = np.array(api.pos(item), dtype=float)
        tp = np.array(api.pos(tgt), dtype=float)
        return np.linalg.norm(ip[:2] - tp[:2]) < 0.08 and ip[2] > tp[2] - 0.06
    except Exception:
        return True


def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    try:
        ops = _plan(api, names, bodies, _words(api.instruction))
    except Exception:
        ops = None
    if not ops:
        api.fallback()
        return
    for op in ops:
        try:
            if op[0] == 'drawer':
                api.drawer(op[1], op[2])
            else:
                _, item, tgt = op
                grasp = _grasp_for(item)    # e.g. chocolate_pudding_1 -> 'standard'
                api.place_with(item, tgt, grasp)
                if not _placed(api, item, tgt):
                    api.place_with(item, tgt, grasp)
        except Exception:
            try:
                api.arrange([(op[1], op[2])]) if op[0] == 'place' else None
            except Exception:
                pass
