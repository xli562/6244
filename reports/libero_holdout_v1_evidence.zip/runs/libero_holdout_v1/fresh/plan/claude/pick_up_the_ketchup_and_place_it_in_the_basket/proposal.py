import math
import numpy as np

ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl', 'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup', 'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup', 'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop', 'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy',
    'black_book': 'black book', 'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle', 'butter': 'butter box',
    'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet', 'wooden_cabinet': 'wooden cabinet',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack', 'microwave': 'microwave oven',
    'basket': 'basket', 'plate': 'plate',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown', 'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'top', 'left', 'right',
        'front', 'back', 'bottom', 'middle', 'compartment', 'side', 'its', 'that', 'is',
        'please', 'then', 'next'}
VERBS = {'put', 'place', 'turn', 'switch', 'close', 'shut', 'open', 'pick', 'push', 'pull',
         'move', 'stack', 'lift', 'grab', 'take', 'set'}
PREPS = ('into', 'onto', 'inside', 'in', 'on', 'to', 'next', 'beside')
DIRS = ('left', 'right', 'front', 'back')


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return w


def resolve(api, bodies, raw, exclude=()):
    W = set(w for w in raw if w not in STOP)
    if not W:
        return None
    best, cands = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, cands = s, [b]
        elif abs(s - best) < 1e-9:
            cands.append(b)
    if not cands:
        return None
    if len(cands) > 1:
        for w in DIRS:
            if w in raw:
                keyf = {'left': lambda p: -p[1], 'right': lambda p: p[1],
                        'front': lambda p: p[0], 'back': lambda p: -p[0]}[w]
                try:
                    return sorted(cands, key=lambda c: keyf(P(api, c)))[0]
                except Exception:
                    break
        cands = sorted(cands)
    return cands[0]


def resolve_target(api, names, bodies, raw):
    """returns (target_name, owner_body)"""
    obj = resolve(api, bodies, raw)
    if obj is None:
        return None
    regs = [n for n in names if _is_region(n) and n.startswith(obj + '_')]
    if not regs:
        return (obj, obj)
    R = set(raw)
    drawer = 'drawer' in R or 'drawers' in R
    best, bs = None, -1e9
    for r in regs:
        suf = r[len(obj) + 1:].split('_')
        toks = set(suf) - {'region', 'contain', 'side'}
        s = 3 * len(toks & R)
        if drawer and 'side' in suf:
            s -= 5
        if (not drawer) and 'top' in R and 'side' in suf:
            s += 2
        if not toks or toks <= {'cook', 'heating', 'contain'}:
            s += 1
        if s > bs:
            bs, best = s, r
    return (best, obj)


def spatial_target(api, names, bodies, tw):
    """'left compartment of the caddy' / 'right of the plate' -> relative_target"""
    if 'of' not in tw:
        return None
    i = tw.index('of')
    d = next((w for w in tw[:i] if w in DIRS), None)
    if d is None:
        return None
    ref = resolve(api, bodies, tw[i + 1:])
    if ref is None:
        return None
    rel = 'inside' if any(w in tw for w in ('compartment', 'drawer', 'drawers')) else 'outside'
    try:
        r = api.relative_target(ref, d, rel)
        if r:
            return (r, ref)
    except Exception:
        pass
    return None


def split_clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if (w == 'and' and (nxt in VERBS or nxt == 'then')) or w == 'then':
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return [c for c in out if c]


def split_items(ws):
    both = 'both' in ws
    has_the = any(ws[j] == 'and' and j + 1 < len(ws) and ws[j + 1] in ('the', 'a')
                  for j in range(len(ws)))
    parts = [[]]
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if w == 'and' and ((has_the and nxt in ('the', 'a')) or (both and not has_the)):
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def is_drawer(tgt):
    name, owner = tgt
    return name != owner and 'cabinet' in owner and 'side' not in name and \
        any(k in name for k in ('top', 'middle', 'bottom'))


def build_plan(api, names, bodies, words):
    ops = []
    last_item, last_target = None, None
    for c in split_clauses(words):
        while c and c[-1] == 'and':
            c = c[:-1]
        if not c:
            continue
        v, rest = c[0], c[1:]
        if v in ('turn', 'switch'):
            ops.append(('unsupported',))
            continue
        if v in ('close', 'shut', 'open'):
            if not rest or rest in (['it'], ['them']):
                tgt = last_target
            else:
                tgt = resolve_target(api, names, bodies, rest)
            if tgt and is_drawer(tgt):
                ops.append(('drawer', tgt[0], 'open' if v == 'open' else 'close'))
                last_target = tgt
            else:
                ops.append(('unsupported',))
            continue
        rest = [w for w in rest if w != 'up']
        idx = None
        for i, w in enumerate(rest):
            if w in PREPS and i > 0:
                idx = i
                break
        if v in ('pick', 'grab', 'lift', 'take') and idx is None:
            it = resolve(api, bodies, rest)
            if it:
                ops.append(('pick', it))
                last_item = it
            continue
        item_w, tw = (rest, []) if idx is None else (rest[:idx], rest[idx + 1:])
        tw = [w for w in tw if w not in ('to',)] if rest[idx] == 'next' else tw
        if not tw or tw in (['it'], ['them']):
            tgt = last_target
        else:
            tgt = spatial_target(api, names, bodies, tw) or resolve_target(api, names, bodies, tw)
        if tgt is None:
            ops.append(('unsupported',))
            continue
        items = []
        for part in split_items(item_w):
            it = last_item if part in (['it'], ['them']) else \
                resolve(api, bodies, part, exclude=(tgt[1],))
            if it and it not in items:
                items.append(it)
        if not items:
            ops.append(('unsupported',))
            continue
        if ops and ops[-1][0] == 'pick' and ops[-1][1] in items:
            ops.pop()
        for it in items:
            ops.append(('place', it, tgt))
        last_item, last_target = items[-1], tgt
    return ops


def grasp_for(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


def placed_ok(api, item, tgt):
    name, owner = tgt
    try:
        ip, tp = P(api, item), P(api, name)
    except Exception:
        return True
    tol = 0.07
    if 'basket' in name or 'contain' in name:
        tol = 0.08
    if 'caddy' in name:
        tol = 0.05
    if is_drawer(tgt):
        return np.linalg.norm(ip[:2] - tp[:2]) < 0.12
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.06


def do_place(api, item, tgt):
    name = tgt[0]
    if name not in api.names():
        try:
            name = api.nearest(name, list(api.names())) or name
            tgt = (name, tgt[1])
        except Exception:
            pass
    g = grasp_for(item)
    for attempt in range(2):
        try:
            api.place_with(item, name, g)
        except Exception:
            pass
        if placed_ok(api, item, tgt):
            return True
        try:
            api.grip(False)
            e = np.array(api.eef(), dtype=float)
            api.move(e + np.array([0, 0, 0.10]), steps=10)
        except Exception:
            pass
    if g == 'standard':
        try:
            api.transfer(item, name, grasp=(0, 0, 0), drop=(0, 0, 0.10))
        except Exception:
            pass
    return placed_ok(api, item, tgt)


def pick_only(api, item):
    p = P(api, item)
    api.grip(False)
    api.move(p + np.array([0, 0, 0.12]), steps=30)
    api.move(p, steps=25)
    api.grip(True)
    api.move(p + np.array([0, 0, 0.15]), steps=25)


def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    words = _words(api.instruction)
    try:
        ops = build_plan(api, names, bodies, words)
    except Exception:
        ops = None
    # unsupported action anywhere: hand the whole task to the previous policy before moving
    if not ops or any(o[0] == 'unsupported' for o in ops):
        api.fallback()
        return
    # e.g. "pick the ketchup and place it in the basket" ->
    #   [('place', 'ketchup_1', ('basket_1_contain_region', 'basket_1'))], grasp 'standard'
    for op in ops:
        try:
            if op[0] == 'drawer':
                api.drawer(op[1], op[2])
            elif op[0] == 'place':
                do_place(api, op[1], op[2])
            elif op[0] == 'pick':
                pick_only(api, op[1])
        except Exception:
            try:
                api.grip(False)
            except Exception:
                pass
