import math
import numpy as np

ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl', 'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup', 'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup', 'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop', 'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy',
    'black_book': 'black book', 'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle', 'butter': 'butter box',
    'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet', 'wooden_cabinet': 'wooden cabinet',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack', 'microwave': 'microwave oven',
    'basket': 'basket', 'plate': 'plate',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown', 'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'top', 'left', 'right',
        'front', 'back', 'bottom', 'middle', 'compartment', 'side', 'its', 'that', 'is',
        'please', 'then', 'drawer', 'next'}
PLACE_VERBS = {'put', 'place', 'move', 'set'}
PICK_VERBS = {'pick', 'grab', 'take', 'lift'}
DRAWER_VERBS = {'open', 'close', 'shut'}
UNSUPPORTED = {'turn', 'switch', 'push', 'pull', 'stack'}
VERBS = PLACE_VERBS | PICK_VERBS | DRAWER_VERBS | UNSUPPORTED
PREPS = ('into', 'onto', 'inside', 'in', 'on', 'to', 'at')
DIRS = ('left', 'right', 'front', 'back')


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return w


def resolve(bodies, ws, exclude=()):
    W = set(w for w in ws if w not in STOP)
    best, pick = -1e9, None
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best:
            best, pick = s, b
    return pick


def grasp_for(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


def resolve_target(api, names, bodies, ws, prep):
    """returns (region_or_body_name, owner) ; handles drawers and spatial relations"""
    owner = resolve(bodies, ws)
    if owner is None:
        return None
    R = set(ws)
    for d in DIRS:
        if d in R:
            rel = 'inside' if ('compartment' in R or prep in ('in', 'into', 'inside')) else 'outside'
            try:
                return (api.relative_target(owner, d, rel), owner)
            except Exception:
                break
    regs = [n for n in names if _is_region(n) and n.startswith(owner + '_')]
    if not regs:
        return (owner, owner)
    drawer = 'drawer' in R or 'drawers' in R
    best, bs = owner, -1e9
    for r in regs:
        suf = r[len(owner) + 1:].split('_')
        toks = set(suf) - {'region', 'side'}
        s = 3 * len(toks & R)
        if drawer and 'side' in suf:
            s -= 5
        if not drawer and 'top' in R and 'side' in suf:
            s += 2
        if 'contain' in toks and prep in ('in', 'into', 'inside'):
            s += 2
        if not toks or toks <= {'cook', 'heating', 'contain'}:
            s += 1
        if s > bs:
            bs, best = s, r
    return (best, owner)


def split_clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if (w == 'and' and (nxt in VERBS or nxt == 'then')) or w == 'then':
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return out


def split_items(ws):
    parts = [[]]
    for w in ws:
        if w == 'and':
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def build_plan(api, names, bodies, words):
    ops, pending, last_item, last_tgt = [], None, None, None
    for c in split_clauses(words):
        v, rest = c[0], [w for w in c[1:] if w != 'up']
        if v in UNSUPPORTED:
            return None
        if v in DRAWER_VERBS:
            tgt = last_tgt if rest in ([], ['it']) else resolve_target(api, names, bodies, rest, 'in')
            if tgt is None:
                return None
            ops.append(('drawer', tgt[0], 'open' if v == 'open' else 'close'))
            last_tgt = tgt
            continue
        idx = next((i for i, w in enumerate(rest) if w in PREPS and i > 0), None)
        if v in PICK_VERBS and idx is None:
            pending = resolve(bodies, rest)
            if pending is None:
                return None
            last_item = pending
            continue
        if v not in PLACE_VERBS and v not in PICK_VERBS:
            return None
        item_w = rest if idx is None else rest[:idx]
        prep = rest[idx] if idx is not None else 'in'
        tw = [] if idx is None else rest[idx + 1:]
        tgt = last_tgt if tw in ([], ['it'], ['them']) else resolve_target(api, names, bodies, tw, prep)
        if tgt is None:
            return None
        items = []
        for part in split_items(item_w):
            it = last_item if part in (['it'], ['them']) else resolve(bodies, part, exclude=(tgt[1],))
            if it and it not in items:
                items.append(it)
        if not items:
            return None
        for it in items:
            ops.append(('place', it, tgt[0], grasp_for(it)))
        pending, last_item, last_tgt = None, items[-1], tgt
    if pending is not None:
        ops.append(('pick', pending))
    return ops


def placed_ok(api, item, target):
    ip, tp = np.array(api.pos(item), float), np.array(api.pos(target), float)
    tol = 0.08 if ('basket' in target or 'contain' in target) else 0.07
    if 'caddy' in target:
        tol = 0.05
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.06


def lift_only(api, item):
    p = np.array(api.pos(item), float)
    api.grip(False)
    api.move(p + np.array([0, 0, 0.12]), steps=30)
    api.move(p, steps=25)
    api.grip(True)
    api.move(p + np.array([0, 0, 0.15]), steps=25)


def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    words = _words(api.instruction)
    try:
        ops = build_plan(api, names, bodies, words)
    except Exception:
        ops = None
    if not ops:
        api.fallback()
        return
    # e.g. "pick the cream cheese and place it in the basket" ->
    #   [('place', 'cream_cheese_1', 'basket_1_contain_region', 'standard')]
    for op in ops:
        try:
            if op[0] == 'drawer':
                api.drawer(op[1], op[2])
            elif op[0] == 'place':
                _, item, target, grasp = op
                for _attempt in range(2):
                    api.place_with(item, target, grasp)
                    if placed_ok(api, item, target):
                        break
                    api.grip(False)
                    e = np.array(api.eef(), float)
                    api.move(e + np.array([0, 0, 0.12]), steps=15)
            elif op[0] == 'pick':
                lift_only(api, op[1])
        except Exception:
            try:
                api.grip(False)
                e = np.array(api.eef(), float)
                api.move(e + np.array([0, 0, 0.12]), steps=15)
            except Exception:
                pass
