import numpy as np

ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl', 'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup', 'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup', 'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop', 'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy',
    'black_book': 'black book', 'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle', 'butter': 'butter box',
    'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet', 'wooden_cabinet': 'wooden cabinet',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack', 'microwave': 'microwave oven',
    'basket': 'basket', 'plate': 'plate',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown', 'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'top', 'left', 'right',
        'front', 'back', 'bottom', 'middle', 'compartment', 'side', 'its', 'that', 'is',
        'please', 'then', 'drawer', 'table', 'next', 'beside'}
VERBS = {'put', 'place', 'turn', 'switch', 'close', 'shut', 'open', 'pick', 'push', 'pull',
         'move', 'stack', 'lift', 'grab', 'take', 'set'}
PREPS = ('into', 'onto', 'inside', 'in', 'on', 'to', 'next', 'beside', 'at')
DIRS = ('left', 'right', 'front', 'back')
LEVELS = ('top', 'middle', 'bottom')


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _isreg(n):
    return n.endswith('_region') or n.endswith('_side')


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return w


def _cands(bodies, ws, exclude=()):
    W = set(w for w in ws if w not in STOP)
    if not W:
        return []
    best, out = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best:
            best, out = s, [b]
        elif s == best:
            out.append(b)
    return out


def _resolve(api, bodies, ws, hint=(), exclude=()):
    c = _cands(bodies, ws, exclude)
    if not c:
        return None
    if len(c) == 1:
        return c[0]
    hint = list(hint)
    # disambiguate by a referenced object ("the bowl on the plate", "between X and Y")
    if hint:
        others = [b for b in bodies if b not in c]
        if 'between' in hint:
            parts = ' '.join(hint[hint.index('between') + 1:]).split(' and ')
            refs = [_resolve(api, others, p.split()) for p in parts]
            refs = [r for r in refs if r]
            if refs:
                hp = np.mean([P(api, r) for r in refs], axis=0)
                return min(c, key=lambda b: np.linalg.norm(P(api, b)[:2] - hp[:2]))
        r = _resolve(api, others, hint)
        if r:
            hp = P(api, r)
            return min(c, key=lambda b: np.linalg.norm(P(api, b)[:2] - hp[:2]))
    ws = list(ws) + hint
    for d in DIRS:
        if d in ws:
            key = {'left': lambda p: -p[1], 'right': lambda p: p[1],
                   'front': lambda p: p[0], 'back': lambda p: -p[0]}[d]
            return min(c, key=lambda b: key(P(api, b)))
    return sorted(c)[0]


def _clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if (w == 'and' and (nxt in VERBS or nxt == 'then')) or w == 'then':
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return out


def _split_items(ws):
    parts, cur = [], []
    for w in ws:
        if w == 'and':
            if cur:
                parts.append(cur)
            cur = []
        elif w != 'both':
            cur.append(w)
    if cur:
        parts.append(cur)
    return parts


def _grasp(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


def _drawer_region(names, owner, ws):
    regs = [n for n in names if _isreg(n) and n.startswith(owner + '_') and not n.endswith('_side')]
    for lv in LEVELS:
        if lv in ws:
            m = [r for r in regs if lv in r[len(owner) + 1:].split('_')]
            if m:
                return m[0]
    m = [r for r in regs if any(lv in r for lv in LEVELS)]
    return m[0] if m else None


def _target(api, names, bodies, tw, prep, last_drawer, last_target):
    if not tw or tw in (['it'], ['them']):
        return last_drawer or last_target
    for d in DIRS:
        if d in tw:
            i = tw.index(d)
            inside = 'compartment' in tw or prep in ('in', 'into', 'inside')
            if 'compartment' in tw or (i + 1 < len(tw) and tw[i + 1] == 'of'):
                ref = _resolve(api, bodies, [w for w in tw if w not in DIRS])
                if ref is None:
                    return None
                return api.relative_target(ref, d, 'inside' if inside else 'outside')
    owner = _resolve(api, bodies, tw)
    if owner is None:
        return None
    regs = [n for n in names if _isreg(n) and n.startswith(owner + '_')]
    if 'drawer' in tw or 'drawers' in tw:
        return _drawer_region(names, owner, tw) or owner
    if 'top' in tw:
        m = [r for r in regs if r.endswith('top_side')] or [r for r in regs if r.endswith('_side')]
        if m:
            return m[0]
    m = [r for r in regs if any(k in r for k in ('contain', 'cook', 'heating'))]
    return m[0] if m else owner


def _plan(api, names, bodies, words):
    ops, pending, last_drawer, last_target = [], [], None, None
    for c in _clauses(words):
        while c and c[-1] == 'and':
            c = c[:-1]
        if not c:
            continue
        v, rest = c[0], [w for w in c[1:] if w != 'up']
        if v in ('open', 'close', 'shut'):
            if not rest or rest in (['it'], ['them']):
                reg = last_drawer
            else:
                owner = _resolve(api, bodies, rest)
                reg = _drawer_region(names, owner, rest) if owner else None
            if reg is None:
                return None          # microwave doors etc.: not a sliding drawer
            ops.append(('drawer', reg, 'open' if v == 'open' else 'close'))
            last_drawer = reg
            continue
        if v not in ('put', 'place', 'move', 'set', 'stack', 'pick', 'grab', 'take', 'lift'):
            return None              # turn/switch/push etc. -> old policy
        pidx = [i for i, w in enumerate(rest) if w in PREPS and i > 0]
        if v in ('pick', 'grab', 'take', 'lift') and not pidx:
            it = _resolve(api, bodies, rest)
            if it is None:
                return None
            pending = [it]
            continue
        if v in ('pick', 'grab', 'take', 'lift'):
            # "pick up X on Y": the whole phrase describes the item
            core, hint = rest[:pidx[0]], rest[pidx[0] + 1:]
            it = _resolve(api, bodies, core, hint)
            if it is None:
                return None
            pending = [it]
            continue
        if pidx:
            k = pidx[-1]
            item_w, prep, tw = rest[:k], rest[k], rest[k + 1:]
            if prep == 'to' and tw and tw[0] in ('the',) and len(tw) > 1 and tw[1] in DIRS:
                pass
        else:
            item_w, prep, tw = rest, '', []
        tgt = _target(api, names, bodies, tw, prep, last_drawer if not tw or tw in (['it'], ['them']) else None, last_target)
        if tgt is None:
            return None
        towner = _base(tgt)
        ip = [i for i, w in enumerate(item_w) if w in PREPS and i > 0]
        core, hint = (item_w[:ip[0]], item_w[ip[0] + 1:]) if ip else (item_w, [])
        items = []
        if core in (['it'], ['them']) or not core:
            items = list(pending)
        else:
            for part in _split_items(core):
                if part in (['it'], ['them']):
                    items += pending
                    continue
                excl = tuple(b for b in bodies if tgt.startswith(b + '_') or b == tgt) + tuple(items)
                it = _resolve(api, bodies, part, hint, exclude=excl)
                if it is None:
                    return None
                items.append(it)
        if not items:
            return None
        for it in items:
            ops.append(('place', it, tgt))
        pending, last_target = items, tgt
    return ops


def _near(api, item, tgt):
    try:
        ip, tp = P(api, item), P(api, tgt)
    except Exception:
        return True
    tol = 0.06 if 'caddy' in tgt else 0.09
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.08


def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _isreg(n)]
    try:
        ops = _plan(api, names, bodies, _words(api.instruction))
    except Exception:
        ops = None
    if not ops:
        api.fallback()
        return
    # e.g. "pick the orange juice and place it in the basket" ->
    #   [('place', 'orange_juice_1', 'basket_1_contain_region')]  grasp='standard'
    for op in ops:
        try:
            if op[0] == 'drawer':
                api.drawer(op[1], op[2])
            elif op[0] == 'place':
                item, tgt = op[1], op[2]
                g = _grasp(item)
                api.place_with(item, tgt, g)
                if not _near(api, item, tgt):
                    api.grip(False)
                    e = np.array(api.eef(), dtype=float)
                    api.move(e + np.array([0, 0, 0.10]), steps=12)
                    api.place_with(item, tgt, g)
        except Exception:
            try:
                api.grip(False)
                e = np.array(api.eef(), dtype=float)
                api.move(e + np.array([0, 0, 0.10]), steps=12)
            except Exception:
                pass
