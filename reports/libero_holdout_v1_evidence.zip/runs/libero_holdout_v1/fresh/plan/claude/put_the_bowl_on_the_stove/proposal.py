import numpy as np

ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl', 'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup', 'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup', 'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop', 'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy',
    'cream_cheese': 'cream cheese box', 'alphabet_soup': 'alphabet soup can',
    'tomato_sauce': 'tomato sauce can', 'bbq_sauce': 'bbq barbecue sauce bottle',
    'ketchup': 'ketchup bottle', 'butter': 'butter box', 'milk': 'milk carton',
    'orange_juice': 'orange juice carton', 'chocolate_pudding': 'chocolate pudding box',
    'salad_dressing': 'salad dressing bottle', 'microwave': 'microwave oven',
    'wooden_cabinet': 'wooden cabinet drawer', 'white_cabinet': 'white cabinet drawer',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown', 'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'top', 'left', 'right',
        'front', 'back', 'bottom', 'middle', 'compartment', 'side', 'its', 'that', 'is',
        'please', 'then', 'drawer', 'next'}
VERBS = {'put', 'place', 'open', 'close', 'shut', 'pick', 'move', 'set', 'stack', 'turn', 'switch'}
PREPS = ('into', 'onto', 'inside', 'in', 'on', 'next', 'to', 'at')
DIRS = ('left', 'right', 'front', 'back')


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _desc(b):
    base = _base(b)
    d = set(base.split('_'))
    if base in ALIAS:
        d |= set(ALIAS[base].split())
    return d


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def resolve(api, bodies, ws, exclude=()):
    W = set(ws) - STOP
    if not W:
        return None
    best, cands = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best:
            best, cands = s, [b]
        elif s == best:
            cands.append(b)
    if not cands:
        return None
    if len(cands) > 1:
        key = {'left': lambda p: -p[1], 'right': lambda p: p[1],
               'front': lambda p: p[0], 'back': lambda p: -p[0]}
        for d in DIRS:
            if d in ws:
                return sorted(cands, key=lambda c: key[d](P(api, c)))[0]
    return sorted(cands)[0]


def grasp_for(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'          # open bowl: pinch the wall
    if 'book' in b:
        return 'thin_edge'    # narrow book-like object
    return 'standard'


def drawer_region(names, body, ws):
    for lvl in ('top', 'middle', 'bottom'):
        if lvl in ws:
            r = body + '_' + lvl + '_region'
            if r in names:
                return r
    regs = [n for n in names if n.startswith(body + '_') and n.endswith('_region')]
    return regs[0] if regs else None


def target_for(api, names, body, ws, prep):
    regs = [n for n in names if n.startswith(body + '_') and _is_region(n)]
    has_drawer = 'drawer' in ws or 'drawers' in ws
    # relative spatial wording -> shared skill, exact wording preserved
    for d in DIRS:
        if d in ws and not ('cabinet' in body and has_drawer):
            rel = 'inside' if ('compartment' in ws or prep in ('in', 'into', 'inside')) else 'outside'
            try:
                r = api.relative_target(body, d, rel)
                if r:
                    return r
            except Exception:
                pass
    if not regs:
        return body
    if 'stove' in body:
        cook = [r for r in regs if 'cook' in r]
        if cook:
            return cook[0]
    if 'cabinet' in body:
        if has_drawer or prep in ('in', 'into', 'inside'):
            r = drawer_region(names, body, ws)
            if r:
                return r
        side = [r for r in regs if r.endswith('top_side')]
        if side:
            return side[0]
    cont = [r for r in regs if 'contain' in r]
    if cont:
        return cont[0]
    best, bs = regs[0], -1e9
    for r in regs:
        toks = set(r[len(body) + 1:].split('_')) - {'region', 'side'}
        s = 3 * len(toks & set(ws)) + (1 if toks <= {'cook', 'heating', 'contain'} else 0)
        if s > bs:
            best, bs = r, s
    return best


def placed_ok(api, item, target):
    try:
        ip, tp = P(api, item), P(api, target)
    except Exception:
        return True
    tol = 0.08 if ('contain' in target or 'basket' in target) else 0.07
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.06


def clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if w == 'then' or (w == 'and' and (nxt in VERBS or nxt == 'then')):
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return out


def split_items(ws):
    parts = [[]]
    for w in ws:
        if w == 'and':
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def build(api, names, bodies, words):
    ops, last_t = [], None
    for c in clauses(words):
        v, rest = c[0], [w for w in c[1:] if w != 'up']
        if v in ('turn', 'switch'):
            return None                       # knobs: let the old policy do it
        if v in ('open', 'close', 'shut'):
            body = resolve(api, bodies, rest) if rest and rest not in (['it'], ['them']) else \
                (last_t[1] if last_t else None)
            if not body:
                return None
            reg = drawer_region(names, body, rest) if 'cabinet' in body else None
            if not reg:
                return None
            ops.append(('drawer', reg, 'open' if v == 'open' else 'close'))
            last_t = (reg, body)
            continue
        if v not in ('put', 'place', 'move', 'set', 'stack'):
            return None
        idx = next((i for i, w in enumerate(rest) if w in PREPS and i > 0), None)
        if idx is None:
            return None
        item_w, tw, prep = rest[:idx], rest[idx + 1:], rest[idx]
        if tw in (['it'], ['them'], []) and last_t:
            target, tbody = last_t
        else:
            tbody = resolve(api, bodies, tw)
            if not tbody:
                return None
            target = target_for(api, names, tbody, tw, prep)
        for part in split_items(item_w):
            it = resolve(api, bodies, part, exclude=(tbody,))
            if not it:
                return None
            ops.append(('place', it, target))
        last_t = (target, tbody)
    return ops or None


def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    words = _words(api.instruction)
    try:
        ops = build(api, names, bodies, words)
    except Exception:
        ops = None
    if not ops:
        api.fallback()
        return
    failed = False
    for op in ops:                       # execute in the requested order
        try:
            if op[0] == 'drawer':
                api.drawer(op[1], op[2])
                continue
            _, item, target = op
            g = grasp_for(item)          # e.g. akita_black_bowl_1 -> 'rim'
            ok = False
            for _ in range(2):
                api.place_with(item, target, g)
                if placed_ok(api, item, target):
                    ok = True
                    break
                api.grip(False)
                e = np.array(api.eef(), dtype=float)
                api.move(e + np.array([0, 0, 0.10]), steps=12)
            failed = failed or not ok
        except Exception:
            failed = True
    if failed and all(o[0] == 'place' for o in ops):
        try:
            api.fallback()
        except Exception:
            pass
