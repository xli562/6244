import math
import numpy as np

ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl', 'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup', 'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup', 'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop', 'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy',
    'black_book': 'black book', 'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle', 'butter': 'butter box',
    'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet', 'wooden_cabinet': 'wooden cabinet drawer',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack', 'microwave': 'microwave oven',
    'basket': 'basket', 'plate': 'plate',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown', 'wooden', 'pink', 'orange'}
LEVELS = ('top', 'middle', 'bottom')
DIRS = ('left', 'right', 'front', 'back')
VERBS = {'put', 'place', 'turn', 'switch', 'close', 'shut', 'open', 'pick', 'push', 'pull',
         'move', 'stack', 'lift', 'grab', 'take', 'set', 'drop', 'store'}
PICKV = {'pick', 'grab', 'lift', 'take'}
PREPS = ('into', 'onto', 'inside', 'in', 'on', 'to', 'at', 'next', 'beside', 'near', 'under')
FILL = {'the', 'a', 'an', 'of', 'please', 'up', 'both', 'and', 'it', 'them', 'that', 'its',
        'is', 'layer', 'table', 'compartment', 'drawer', 'drawers', 'side', 'then', 'there'}
DRAWERW = {'drawer', 'drawers', 'layer', 'shelf'}


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return w


def _pos(api, n):
    try:
        return np.array(api.pos(n), dtype=float)
    except Exception:
        return None


def _cands(bodies, ws, exclude=()):
    W = set(w for w in ws if w not in FILL and w not in DIRS and w not in LEVELS)
    if not W:
        return []
    best, out = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, out = s, [b]
        elif abs(s - best) < 1e-9:
            out.append(b)
    return sorted(out)


def _disambig(api, names, bodies, cands, ws, qual):
    if len(cands) <= 1:
        return cands[0] if cands else None
    if qual:
        ref = _cands([b for b in bodies if b not in cands], qual)
        if ref:
            try:
                r = api.nearest(ref[0], cands)
                if r in cands:
                    return r
            except Exception:
                rp = _pos(api, ref[0])
                if rp is not None:
                    return min(cands, key=lambda c: np.linalg.norm((_pos(api, c) - rp)[:2]))
    for w in DIRS:
        if w in ws or w in (qual or []):
            key = {'left': lambda p: -p[1], 'right': lambda p: p[1],
                   'front': lambda p: -p[0], 'back': lambda p: p[0]}[w]
            return min(cands, key=lambda c: key(_pos(api, c)))
    return cands[0]


def resolve_item(api, names, bodies, ws, exclude=()):
    q = None
    for i, w in enumerate(ws):
        if w in PREPS + ('between', 'from') and i > 0:
            ws, q = ws[:i], ws[i + 1:]
            break
    return _disambig(api, names, bodies, _cands(bodies, ws, exclude), ws, q)


def grasp_for(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


def _cabinet(bodies, T):
    cabs = [b for b in bodies if 'cabinet' in b]
    if not cabs:
        return None
    m = _cands(cabs, list(T))
    return m[0] if m else cabs[0]


def resolve_target(api, names, bodies, prep, tw, ctx):
    """returns (target_name, owner_body, is_drawer_region)"""
    T = set(tw)
    if not (T - {'it', 'them', 'there', 'the', 'drawer'}) and ctx.get('drawer') and (
            not T or T & {'it', 'drawer', 'there'} or prep in ('inside', 'in', 'into')):
        return ctx['drawer']
    if not T or T <= {'it', 'them', 'there'}:
        return ctx.get('target')
    lvl = next((l for l in LEVELS if l in T), None)
    cab = _cabinet(bodies, T) if (T & DRAWERW or 'cabinet' in T) else None
    if cab:
        if T & DRAWERW or (lvl in ('middle', 'bottom')):
            r = '%s_%s_region' % (cab, lvl or 'top')
            if r in names:
                return (r, cab, True)
        if 'top' in T and cab + '_top_side' in names:
            return (cab + '_top_side', cab, False)
    dirw = next((d for d in DIRS if d in tw), None)
    if dirw:
        ref = _cands(bodies, tw)
        if ref:
            rel = 'inside' if ('compartment' in T or prep in ('in', 'into', 'inside')) else 'outside'
            try:
                r = api.relative_target(ref[0], dirw, rel)
                if r:
                    return (r, ref[0], False)
            except Exception:
                pass
    c = _cands(bodies, tw)
    if not c:
        return None
    obj = c[0]
    regs = [n for n in names if _is_region(n) and n.startswith(obj + '_')]
    best, bs = obj, 0
    for r in regs:
        toks = set(r[len(obj) + 1:].split('_')) - {'region', 'side'}
        s = 3 * len(toks & T) + (2 if toks & {'contain', 'cook', 'heating'} else 0)
        if s > bs:
            bs, best = s, r
    return (best, obj, False)


def split_clauses(ws):
    out, cur = [], []
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if (w == 'and' and (nxt in VERBS or nxt == 'then')) or w == 'then':
            if cur:
                out.append(cur)
            cur = []
            continue
        if w == 'please' and not cur:
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return out


def split_items(ws):
    parts = [[]]
    for w in ws:
        if w == 'and':
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def build_plan(api, names, bodies, ws):
    ops, ctx = [], {}
    for c in split_clauses(ws):
        v, rest = c[0], [w for w in c[1:] if w != 'up']
        if v in ('open', 'close', 'shut', 'pull', 'push') and (set(rest) & (DRAWERW | {'cabinet', 'it', 'them'}) or not rest):
            if not rest or set(rest) <= {'it', 'them'}:
                t = ctx.get('drawer')
            else:
                t = resolve_target(api, names, bodies, 'in', rest + ['drawer'], ctx)
            if not t or not t[2]:
                return None
            ops.append(('drawer', t[0], 'open' if v in ('open', 'pull') else 'close'))
            ctx['drawer'] = t
            ctx['target'] = t
            continue
        if v not in ('put', 'place', 'move', 'stack', 'set', 'drop', 'store') and v not in PICKV:
            return None                       # turn/switch etc -> old policy
        if v in PICKV and not any(w in ('into', 'onto', 'inside', 'in', 'on') for w in rest):
            it = resolve_item(api, names, bodies, rest)
            if not it:
                return None
            ctx['item'] = it
            ops.append(('pick', it))
            continue
        idx = next((i for i, w in enumerate(rest) if w in PREPS and i > 0), None)
        if idx is None and rest and rest[-1] in ('inside', 'in', 'there'):
            idx = len(rest) - 1
        item_w = rest if idx is None else rest[:idx]
        prep = rest[idx] if idx is not None else 'in'
        tw = [] if idx is None else rest[idx + 1:]
        if prep == 'next' and tw and tw[0] == 'to':
            tw = tw[1:]
        tgt = resolve_target(api, names, bodies, prep, tw, ctx)
        if not tgt:
            return None
        items = []
        for part in split_items(item_w) or [['it']]:
            if set(part) <= {'it', 'them', 'the'}:
                it = ctx.get('item')
            else:
                it = resolve_item(api, names, bodies, part, exclude=(tgt[1],))
            if it and it not in items:
                items.append(it)
        if not items:
            return None
        if ops and ops[-1][0] == 'pick' and ops[-1][1] in items:
            ops.pop()
        for it in items:
            ops.append(('place', it, tgt))
        ctx['item'], ctx['target'] = items[-1], tgt
        if tgt[2]:
            ctx['drawer'] = tgt
    # a drawer placement needs that drawer open first
    out, opened = [], set()
    for op in ops:
        if op[0] == 'drawer':
            if op[2] == 'open':
                opened.add(op[1])
            else:
                opened.discard(op[1])
        if op[0] == 'place' and op[2][2] and op[2][0] not in opened:
            out.append(('drawer', op[2][0], 'open'))
            opened.add(op[2][0])
        out.append(op)
    return out if any(o[0] != 'pick' for o in out) and all(o[0] != 'pick' for o in out) else None


def placed_ok(api, item, target):
    ip, tp = _pos(api, item), _pos(api, target)
    if ip is None or tp is None:
        return True
    tol = 0.05 if 'caddy' in target else (0.10 if 'main_table' in target else 0.08)
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.07


def lift_clear(api):
    try:
        api.grip(False)
        e = np.array(api.eef(), dtype=float)
        api.move(e + np.array([0, 0, 0.10]), steps=12)
    except Exception:
        pass


def do_place(api, item, target):
    g = grasp_for(item)
    for attempt in range(2):
        try:
            api.place_with(item, target, g)
        except Exception:
            try:
                api.transfer(item, target)
            except Exception:
                pass
        if placed_ok(api, item, target):
            return True
        lift_clear(api)
    return False


def do_drawer(api, region, mode):
    for attempt in range(2):
        try:
            api.drawer(region, mode)
            return True
        except Exception:
            lift_clear(api)
    return False


def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    try:
        ops = build_plan(api, names, bodies, _words(api.instruction))
    except Exception:
        ops = None
    if not ops:
        api.fallback()
        return
    # e.g. "open the top layer of the drawer and put the bowl inside":
    #   drawer(wooden_cabinet_1_top_region, open); place_with(akita_black_bowl_1, ..., 'rim')
    for op in ops:
        if op[0] == 'drawer':
            do_drawer(api, op[1], op[2])
        elif op[0] == 'place':
            do_place(api, op[1], op[2][0])
