import numpy as np

STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'to', 'up', 'please',
        'then', 'and', 'on', 'onto', 'in', 'into', 'inside', 'from', 'at',
        'near', 'beside', 'is', 'that', 'its', 'compartment'}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown',
          'wooden', 'pink', 'orange'}
DIRS = {'left', 'right', 'front', 'back'}
GENERIC = {'main', 'table', 'region', 'side'}
LEVELS = {'top', 'middle', 'bottom'}
PICK_V = {'pick', 'grab', 'take', 'lift'}
PLACE_V = {'put', 'place', 'move', 'set', 'stack', 'drop'}
DRAWER_V = {'open', 'close', 'shut'}
VERBS = PICK_V | PLACE_V | DRAWER_V | {'turn', 'switch', 'push', 'pull'}
LOC = ('on', 'onto', 'in', 'into', 'inside', 'from', 'next', 'between', 'at',
       'near', 'beside')
PLACE_PREPS = ('onto', 'into', 'inside', 'on', 'in')
ON = ('on', 'onto')
IN = ('in', 'into', 'inside')
ALIAS = {
    'porcelain_mug': 'white mug cup', 'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup', 'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop', 'moka_pot': 'moka pot',
    'cream_cheese': 'box', 'butter': 'box', 'chocolate_pudding': 'box',
    'alphabet_soup': 'can', 'tomato_sauce': 'can', 'bbq_sauce': 'barbecue bottle',
    'ketchup': 'bottle', 'salad_dressing': 'bottle', 'milk': 'carton',
    'orange_juice': 'carton', 'microwave': 'oven', 'cookies': 'cookie box',
    'glazed_rim_porcelain_ramekin': 'white ramekin bowl',
}


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side') or n.startswith('main_table')


def _raw(n):
    return set(t for t in n.split('_') if not t.isdigit())


def _full(n):
    s = _raw(n)
    for k, v in ALIAS.items():
        if k in n:
            s |= set(v.split())
    return s


def P(api, n):
    return np.array(api.pos(n), dtype=float)


# ---------------------------------------------------------------- resolution
def resolve_item(api, names, ws, exclude=()):
    W = set(w for w in ws if w not in STOP and w not in DIRS and w not in LOC)
    best, cands = -1e9, []
    for b in names:
        if _is_region(b) or b in exclude:
            continue
        F = _full(b)
        m = len(W & F)
        if m == 0:
            continue
        s = 3 * m - 2 * len((W & COLORS) - F) - 1 * len((F & COLORS) - W)
        if s > best + 1e-9:
            best, cands = s, [b]
        elif abs(s - best) < 1e-9:
            cands.append(b)
    if len(cands) > 1:
        for d in ('left', 'right', 'front', 'back'):
            if d in ws:
                key = {'left': lambda p: -p[1], 'right': lambda p: p[1],
                       'front': lambda p: p[0], 'back': lambda p: -p[0]}[d]
                cands.sort(key=lambda c: key(P(api, c)))
                break
    return cands


def best_name(api, names, ws, rel, exclude=(), drawer_only=False):
    W = set(w for w in ws if w not in STOP)
    drawer = drawer_only or 'drawer' in W or 'drawers' in W
    best, bn = -1e9, None
    for n in sorted(names):
        if n in exclude:
            continue
        raw, full = _raw(n), _full(n)
        m = len(W & full)
        if m == 0:
            continue
        s = 3 * m - 0.5 * len((raw - GENERIC) - W) - 2 * len((W & COLORS) - full)
        if drawer:
            if 'side' in raw:
                s -= 5
            if raw & LEVELS and n.endswith('_region'):
                s += 2 + (0.05 if 'top' in raw else 0)
        elif rel in ON:
            if n.endswith('top_side') or 'cook' in raw:
                s += 2
        elif rel in IN:
            if raw & {'contain', 'heating'}:
                s += 2
        if not _is_region(n):
            s += 0.1
        if drawer_only and not (raw & LEVELS and n.endswith('_region')):
            continue
        if s > best:
            best, bn = s, n
    return bn


def pick_with_qualifier(api, names, cands, rel, qw):
    if len(cands) <= 1 or not qw:
        return cands[0] if cands else None
    loc = best_name(api, names, qw, rel, exclude=set(cands))
    if loc is None:
        return cands[0]
    lp = P(api, loc)
    return min(cands, key=lambda c: np.linalg.norm(P(api, c) - lp))


def parse_item_phrase(api, names, ws, exclude=()):
    """'the akita black bowl on the wooden cabinet' -> body name"""
    idx = None
    for i, w in enumerate(ws):
        if w in LOC and i > 0:
            idx = i
            break
    if idx is None:
        c = resolve_item(api, names, ws, exclude)
        return c[0] if c else None
    c = resolve_item(api, names, ws[:idx], exclude)
    return pick_with_qualifier(api, names, c, ws[idx], ws[idx + 1:])


# ---------------------------------------------------------------- planning
def split_clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if (w == 'and' and (nxt in VERBS or nxt == 'then')) or w == 'then':
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return out


def split_items(ws):
    parts = [[]]
    for w in ws:
        if w == 'and':
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def plan(api, names, words):
    ops, pending, last_item, last_tgt, last_drawer = [], None, None, None, None
    for c in split_clauses(words):
        while c and c[-1] == 'and':
            c = c[:-1]
        if not c:
            continue
        v, rest = c[0], [w for w in c[1:] if w != 'up']
        if v in DRAWER_V:
            if rest in ([], ['it'], ['them']):
                r = last_drawer or last_tgt
            else:
                r = best_name(api, names, rest, 'in', drawer_only=True)
            if r is None or not (_raw(r) & LEVELS and r.endswith('_region')):
                return ops, False
            ops.append(('drawer', r, 'open' if v == 'open' else 'close'))
            last_drawer = r
            continue
        if v in PICK_V or v in PLACE_V:
            idx = None
            for i, w in enumerate(rest):
                if w in PLACE_PREPS and i > 0:
                    idx = i
                    break
            if v in PICK_V:
                # "pick X <qualifier>" with no destination: remember the item
                it = parse_item_phrase(api, names, rest)
                if it is None:
                    return ops, False
                pending = it
                continue
            if idx is None:
                return ops, False
            item_w, rel, tw = rest[:idx], rest[idx], rest[idx + 1:]
            if not tw or tw in (['it'], ['them']):
                tgt = last_tgt
            else:
                tgt = None
            items = []
            if item_w in (['it'], ['them']) or not item_w:
                if pending or last_item:
                    items = [pending or last_item]
            else:
                for part in split_items(item_w):
                    it = parse_item_phrase(api, names, part)
                    if it and it not in items:
                        items.append(it)
            if tgt is None:
                tgt = best_name(api, names, tw, rel, exclude=set(items))
            if tgt is None or not items:
                return ops, False
            for it in items:
                ops.append(('place', it, tgt))
            last_item, last_tgt, pending = items[-1], tgt, None
            if _raw(tgt) & LEVELS and tgt.endswith('_region'):
                last_drawer = tgt
            continue
        return ops, False          # turn/switch/push/etc. unsupported here
    if pending is not None:
        return ops, False          # pick without destination
    return ops, True


# ---------------------------------------------------------------- execution
def grasp_for(item):
    t = _full(item)
    if 'bowl' in t and 'ramekin' not in t:
        return 'rim'
    if 'book' in t:
        return 'thin_edge'
    return 'standard'


def placed_ok(api, item, tgt):
    ip, tp = P(api, item), P(api, tgt)
    tol = 0.09 if ('contain' in tgt or 'basket' in tgt) else 0.07
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.06


def recover(api):
    try:
        api.grip(False)
        e = np.array(api.eef(), dtype=float)
        api.move(e + np.array([0.0, 0.0, 0.10]), steps=12)
    except Exception:
        pass


def place(api, item, tgt):
    g = grasp_for(item)
    for _ in range(2):
        try:
            api.place_with(item, tgt, g)
        except Exception:
            pass
        try:
            if placed_ok(api, item, tgt):
                return True
        except Exception:
            return False
        recover(api)
    return False


def run(api):
    try:
        names = list(api.names())
        ops, ok = plan(api, names, _words(api.instruction))
    except Exception:
        ops, ok = [], False
    if not ok or not ops:
        api.fallback()
        return
    for op in ops:
        try:
            if op[0] == 'drawer':
                api.drawer(op[1], op[2])
            else:
                place(api, op[1], op[2])
        except Exception:
            recover(api)
