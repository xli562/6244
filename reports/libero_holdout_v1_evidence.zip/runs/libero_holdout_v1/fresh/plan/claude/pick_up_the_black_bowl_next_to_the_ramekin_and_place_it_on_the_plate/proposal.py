import math
import numpy as np

ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl', 'white_bowl': 'white bowl',
    'glazed_rim_porcelain_ramekin': 'ramekin', 'cookies': 'cookie cookies box',
    'porcelain_mug': 'white porcelain mug cup', 'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup', 'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop', 'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy',
    'black_book': 'black book', 'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle', 'butter': 'butter box',
    'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet', 'wooden_cabinet': 'wooden cabinet',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack', 'microwave': 'microwave oven',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown', 'wooden', 'pink', 'orange'}
DIRS = {'left', 'right', 'front', 'back'}
POSW = {'top', 'middle', 'bottom'}
FILL = {'the', 'a', 'an', 'of', 'it', 'them', 'to', 'up', 'please', 'that', 'is', 'its',
        'both', 'and', 'then'}
PICKV = {'pick', 'grab', 'take', 'lift'}
PLACEV = {'put', 'place', 'set', 'move', 'stack'}
DRAWV = {'open', 'close', 'shut'}
ALLV = PICKV | PLACEV | DRAWV | {'turn', 'switch', 'push', 'pull'}
PREPS = ('on', 'onto', 'in', 'into', 'inside')
QUAL = {'next', 'between', 'from', 'on', 'in', 'inside', 'at', 'near', 'beside', 'by'}
NOUN_SKIP = FILL | DIRS | POSW | QUAL | {'onto', 'into', 'drawer', 'drawers', 'compartment',
                                         'side', 'region', 'center'} | ALLV


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side') or n.startswith('main_table')


def _toks(ws):
    S = set()
    for w in ws:
        if w in NOUN_SKIP:
            continue
        S.add(w)
        if w.endswith('s') and len(w) > 3:
            S.add(w[:-1])
    return S


def _desc(b):
    base = _base(b)
    D = set(base.split('_'))
    if base in ALIAS:
        D |= set(ALIAS[base].split())
    D |= {d[:-1] for d in D if d.endswith('s') and len(d) > 3}
    return D


def match(bodies, ws, exclude=()):
    W = _toks(ws)
    if not W:
        return []
    best, out = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, out = s, [b]
        elif abs(s - best) < 1e-9:
            out.append(b)
    return out


def dir_sort(api, names, cands, ws):
    for w in ws:
        if w in DIRS:
            head = _base(cands[0]).split('_')[-1]
            hints = [n for n in names if _is_region(n) and w in n.split('_') and head in n.split('_')]
            if hints:
                hp = P(api, hints[0])
                return sorted(cands, key=lambda c: np.linalg.norm(P(api, c)[:2] - hp[:2]))
            key = {'left': lambda p: -p[1], 'right': lambda p: p[1],
                   'front': lambda p: -p[0], 'back': lambda p: p[0]}[w]
            return sorted(cands, key=lambda c: key(P(api, c)))
    return sorted(cands)


def region_toks(n):
    return set(t for t in n.split('_') if not t.isdigit()) - {'main', 'region', 'to'}


def best_region(regs, qs, require=None):
    Q = set(qs) | {w[:-1] for w in qs if w.endswith('s') and len(w) > 3}
    best, bs = None, -1e9
    for r in regs:
        rt = region_toks(r)
        if 'table' not in Q:
            rt.discard('table')
        if require and require not in rt:
            continue
        ov = len(rt & Q)
        if ov - (1 if require else 0) < 1:
            continue
        s = 2 * ov - len(rt - Q)
        if s > bs:
            bs, best = s, r
    return best


def locate(api, names, bodies, cands, q):
    """pick the candidate described by the qualifier phrase q"""
    qs = [w for w in q if w not in FILL]
    regs = [n for n in names if _is_region(n)]
    others = [b for b in bodies if b not in cands]

    def nearest(pt, three=False):
        k = 3 if three else 2
        return min(cands, key=lambda c: np.linalg.norm(P(api, c)[:k] - pt[:k]))

    if 'between' in qs:
        r = best_region(regs, qs, 'between')
        if r:
            return nearest(P(api, r))
        i = qs.index('between')
        rest = q[q.index('between') + 1:]
        if 'and' in rest:
            j = rest.index('and')
            a, b = match(others, rest[:j]), match(others, rest[j + 1:])
            if a and b:
                return nearest((P(api, a[0]) + P(api, b[0])) / 2)
    if any(w in qs for w in ('next', 'beside', 'near', 'by')):
        r = best_region(regs, qs, 'next')
        if r:
            return nearest(P(api, r))
        ref = match(others, qs)
        if ref:
            return nearest(P(api, ref[0]))
    if 'center' in qs:
        r = best_region(regs, qs + ['center'], 'center')
        if r:
            return nearest(P(api, r))
    pw = [w for w in qs if w in POSW]
    if 'drawer' in qs or ('top' not in qs and pw):
        cabs = match(others, qs) or [b for b in others if any(
            n.startswith(b + '_') and n.endswith('_top_region') for n in names)]
        if cabs and pw:
            r = cabs[0] + '_' + pw[0] + '_region'
            if r in names:
                return nearest(P(api, r), three=True)
    ref = match(others, qs)
    if ref:
        ts = ref[0] + '_top_side'
        if ts in names and 'drawer' not in qs:
            return nearest(P(api, ts), three=True)
        rp = P(api, ref[0])
        return min(cands, key=lambda c: np.linalg.norm(P(api, c)[:2] - rp[:2])
                   - 0.3 * max(0.0, P(api, c)[2] - rp[2]))
    r = best_region(regs, qs)
    if r:
        return nearest(P(api, r))
    return dir_sort(api, names, cands, q)[0]


def resolve_item(api, names, bodies, ws, exclude=()):
    cut = None
    for i, w in enumerate(ws):
        if i > 0 and w in QUAL:
            cut = i
            break
    noun, q = (ws, []) if cut is None else (ws[:cut], ws[cut:])
    cands = match(bodies, noun, exclude)
    if not cands:
        cands = match(bodies, ws, exclude)
        q = []
    if not cands:
        return None
    if len(cands) == 1:
        return cands[0]
    if q:
        return locate(api, names, bodies, cands, q)
    return dir_sort(api, names, cands, noun)[0]


def split_items(ws):
    both = 'both' in ws
    has_the = any(ws[j] == 'and' and j + 1 < len(ws) and ws[j + 1] in ('the', 'a')
                  for j in range(len(ws)))
    parts = [[]]
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if w == 'and' and ((has_the and nxt in ('the', 'a')) or (both and not has_the)):
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def drawer_cabs(names, bodies):
    return [b for b in bodies if any(n.startswith(b + '_') and
            n.endswith(('_top_region', '_middle_region', '_bottom_region')) for n in names)]


def target_of(api, names, bodies, tw, prep, items, last_target):
    if not tw or tw in (['it'], ['them']):
        return last_target
    # relative placement: "<dir> ... of <fixture>"
    for i, w in enumerate(tw):
        if w in DIRS and 'of' in tw[i + 1:i + 4]:
            j = tw.index('of', i + 1)
            ref = match(bodies, tw[j + 1:], exclude=items)
            if not ref:
                return None
            inside = ('compartment' in tw or 'compartments' in tw or
                      (prep in ('in', 'into', 'inside') and tw[0] not in DIRS and 'side' not in tw))
            return api.relative_target(ref[0], w, 'inside' if inside else 'outside')
    cands = match(bodies, tw, exclude=items)
    if not cands:
        r = best_region([n for n in names if _is_region(n)], [w for w in tw if w not in FILL])
        return r
    ref = dir_sort(api, names, cands, tw)[0]
    regs = [n for n in names if _is_region(n) and n.startswith(ref + '_')]
    pw = [w for w in tw if w in POSW]
    if ('drawer' in tw or 'drawers' in tw) and pw and ref + '_' + pw[0] + '_region' in names:
        return ref + '_' + pw[0] + '_region'
    if ref + '_top_side' in names and ('top' in tw or prep in ('on', 'onto')):
        return ref + '_top_side'
    if prep in ('in', 'into', 'inside'):
        c = [r for r in regs if 'contain' in r or 'heating' in r]
        if c:
            c = dir_sort(api, names, c, tw) if any(w in DIRS for w in tw) else c
            return c[0]
    c = [r for r in regs if 'cook' in r]
    if c:
        return c[0]
    return ref


def drawer_region(names, bodies, ws, last_drawer):
    if ws in ([], ['it'], ['them']):
        return last_drawer
    cabs = drawer_cabs(names, bodies)
    m = match(cabs, ws)
    if not m and _toks(ws) - {'drawer', 'cabinet'} and match(bodies, ws):
        return None                      # e.g. microwave door: not a sliding drawer
    cab = m[0] if m else (last_drawer.rsplit('_', 2)[0] if last_drawer else
                          (cabs[0] if cabs else None))
    if cab is None:
        return None
    pw = [w for w in ws if w in POSW]
    if pw and cab + '_' + pw[0] + '_region' in names:
        return cab + '_' + pw[0] + '_region'
    return last_drawer


def clauses(ws):
    out, cur = [], []
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if w == 'then' or (w == 'and' and (nxt in ALLV or nxt == 'then')):
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return out


def grasp_for(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


def build(api, names, bodies, ws):
    ops, pending, last_item, last_target, last_drawer = [], None, None, None, None
    for c in clauses(ws):
        while c and c[-1] == 'and':
            c = c[:-1]
        if not c:
            continue
        v, rest = c[0], [w for w in c[1:] if w != 'up']
        if v in DRAWV:
            r = drawer_region(names, bodies, rest, last_drawer if last_drawer else
                              (last_target if last_target and last_target.endswith(
                                  ('_top_region', '_middle_region', '_bottom_region')) else None))
            if r is None:
                return None
            ops.append(('drawer', r, 'open' if v == 'open' else 'close'))
            last_drawer = last_target = r
            continue
        if v in PICKV:
            it = resolve_item(api, names, bodies, rest)
            if it is None:
                return None
            pending = last_item = it
            continue
        if v not in PLACEV:
            return None                  # turn / push / unknown -> previous policy
        idx = None
        for i in range(len(rest) - 1, 0, -1):
            if rest[i] in PREPS:
                idx = i
                break
        if idx is None and 'to' in rest[1:]:
            idx = rest.index('to', 1)
        if idx is None:
            return None
        item_w, prep, tw = rest[:idx], rest[idx], rest[idx + 1:]
        items = []
        if item_w in ([], ['it'], ['them']):
            if pending or last_item:
                items = [pending or last_item]
        else:
            parts = split_items(item_w)
            for part in parts:
                it = resolve_item(api, names, bodies, part, exclude=tuple(items))
                if it and it not in items:
                    items.append(it)
            if 'both' in item_w and len(items) == 1:
                more = match(bodies, item_w, exclude=tuple(items))
                if more:
                    items.append(more[0])
        if not items:
            return None
        tgt = target_of(api, names, bodies, tw, prep, tuple(items),
                        last_drawer or last_target)
        if tgt is None:
            return None
        for it in items:
            ops.append(('place', it, tgt))
        pending, last_item, last_target = None, items[-1], tgt
    if pending is not None or not ops:
        return None
    return ops


def placed(api, item, tgt):
    ip, tp = P(api, item), P(api, tgt)
    tol = 0.12 if tgt.endswith(('_top_region', '_middle_region', '_bottom_region')) else 0.08
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.06


def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    try:
        ops = build(api, names, bodies, _words(api.instruction))
    except Exception:
        ops = None
    if not ops:
        api.fallback()
        return
    for k, op in enumerate(ops):
        try:
            if op[0] == 'drawer':
                api.drawer(op[1], op[2])
            else:
                _, item, tgt = op
                g = grasp_for(item)
                api.place_with(item, tgt, g)
                if not placed(api, item, tgt):
                    api.grip(False)
                    e = np.array(api.eef(), dtype=float)
                    api.move(e + np.array([0.0, 0.0, 0.10]), steps=12)
                    api.place_with(item, tgt, g)
        except Exception:
            if k == 0:
                api.fallback()
                return
            try:
                api.grip(False)
            except Exception:
                pass
