import numpy as np

ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl', 'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup', 'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup', 'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop', 'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy',
    'black_book': 'black book', 'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle', 'butter': 'butter box',
    'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet', 'wooden_cabinet': 'wooden cabinet',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack', 'microwave': 'microwave oven',
    'basket': 'basket', 'plate': 'plate',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown', 'wooden', 'pink', 'orange'}
DIRS = ('left', 'right', 'front', 'back')
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'top', 'left', 'right',
        'front', 'back', 'bottom', 'middle', 'compartment', 'side', 'its', 'that', 'is', 'please',
        'then', 'drawer', 'drawers', 'next', 'on', 'in', 'into', 'inside', 'onto', 'region'}
VERBS = {'put', 'place', 'turn', 'switch', 'close', 'shut', 'open', 'pick', 'push', 'pull',
         'move', 'stack', 'lift', 'grab', 'take', 'set'}
PREPS = ('into', 'onto', 'inside', 'in', 'on', 'to')


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return w


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def resolve(api, bodies, ws, exclude=()):
    W = set(w for w in ws if w not in STOP)
    if not W:
        return None
    best, cands = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, cands = s, [b]
        elif abs(s - best) < 1e-9:
            cands.append(b)
    if not cands:
        return None
    cands.sort()
    for d in DIRS:
        if d in ws and len(cands) > 1:
            key = {'left': lambda p: -p[1], 'right': lambda p: p[1],
                   'front': lambda p: -p[0], 'back': lambda p: p[0]}[d]
            cands.sort(key=lambda c: key(P(api, c)))
            break
    return cands[0]


def target_of(api, names, bodies, tw, prep, last, exclude=()):
    if not tw or tw in (['it'], ['them']):
        return last
    T = set(tw)
    ref = resolve(api, bodies, [w for w in tw if w not in DIRS], exclude)
    if ref is None:
        return last
    dirs = [w for w in tw if w in DIRS]
    if dirs and 'drawer' not in T:
        rel = 'inside' if ('compartment' in T or prep in ('in', 'into', 'inside')) else 'outside'
        try:
            r = api.relative_target(ref, dirs[0], rel)
            if r:
                return (r, ref)
        except Exception:
            pass
    regs = [n for n in names if _is_region(n) and n.startswith(ref + '_')]
    if not regs:
        return (ref, ref)

    def sc(r):
        toks = set(r[len(ref) + 1:].split('_')) - {'region', 'side'}
        s = 3 * len(toks & T)
        if 'drawer' in T and r.endswith('_side'):
            s -= 5
        if 'drawer' not in T and 'top' in T and r.endswith('_side'):
            s += 2
        if toks & {'contain', 'cook', 'heating'}:
            s += 1
        return s
    return (max(regs, key=sc), ref)


def split_clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if (w == 'and' and (nxt in VERBS or nxt == 'then')) or w == 'then':
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return out


def split_items(ws):
    parts = [[]]
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if w == 'and' and nxt in ('the', 'a') or (w == 'and' and 'both' in ws):
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def grasp_for(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


def placed_ok(api, item, name):
    try:
        ip, tp = P(api, item), P(api, name)
    except Exception:
        return False
    tol = 0.07
    if 'basket' in name or 'contain' in name:
        tol = 0.08
    if 'caddy' in name:
        tol = 0.05
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.06


def lift_clear(api):
    try:
        api.grip(False)
        e = np.array(api.eef(), dtype=float)
        api.move(e + np.array([0, 0, 0.10]), steps=12)
    except Exception:
        pass


def place(api, item, target):
    g = grasp_for(item)
    try:
        api.place_with(item, target, g)
    except Exception:
        pass
    if placed_ok(api, item, target):
        return True
    lift_clear(api)
    try:
        api.arrange([(item, target)])
    except Exception:
        pass
    if placed_ok(api, item, target):
        return True
    lift_clear(api)
    try:
        drop = (0, 0, 0.11) if 'basket' in target else (0, 0, 0.08)
        api.transfer(item, target, grasp=(0, 0, 0), drop=drop)
    except Exception:
        pass
    return placed_ok(api, item, target)


def build_plan(api, names, bodies, words):
    ops, last_item, last_tgt = [], None, None
    for c in split_clauses(words):
        while c and c[-1] == 'and':
            c = c[:-1]
        if not c:
            continue
        v, rest = c[0], [w for w in c[1:] if w != 'up']
        if v in ('turn', 'switch', 'push'):
            return None                      # unsupported here -> old policy
        if v in ('open', 'close', 'shut', 'pull'):
            tw = rest if 'drawer' in rest or not rest or rest in (['it'], ['them']) \
                else rest + ['drawer']
            tgt = target_of(api, names, bodies, tw, None, last_tgt)
            if tgt is None:
                return None
            ops.append(('drawer', tgt[0], 'open' if v in ('open', 'pull') else 'close'))
            last_tgt = tgt
            continue
        idx = next((i for i, w in enumerate(rest) if w in PREPS and i > 0), None)
        if idx is None:
            if v in ('pick', 'grab', 'lift', 'take'):
                last_item = resolve(api, bodies, rest) or last_item
                continue
            return None
        item_w, prep, tw = rest[:idx], rest[idx], rest[idx + 1:]
        if tw and tw[0] in ('the', 'a') is False:
            pass
        items, owner = [], None
        tgt = target_of(api, names, bodies, tw, prep, last_tgt)
        if tgt is None:
            return None
        for part in split_items(item_w):
            it = last_item if part in (['it'], ['them']) else \
                resolve(api, bodies, part, exclude=(tgt[1],))
            if it and it not in items:
                items.append(it)
        if not items and last_item:
            items = [last_item]
        for it in items:
            ops.append(('place', it, tgt[0]))
        if items:
            last_item = items[-1]
        last_tgt = tgt
    return ops or None


def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    words = _words(api.instruction)
    try:
        ops = build_plan(api, names, bodies, words)
    except Exception:
        ops = None
    if not ops:
        api.fallback()
        return
    # e.g. "pick the milk and place it in the basket" ->
    #   [('place', 'milk_1', 'basket_1_contain_region')]  grasp='standard'
    for op in ops:
        try:
            if op[0] == 'drawer':
                api.drawer(op[1], op[2])
            elif op[0] == 'place':
                place(api, op[1], op[2])
        except Exception:
            lift_clear(api)
