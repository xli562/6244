import math
import numpy as np

ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl', 'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup', 'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup', 'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop', 'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy',
    'black_book': 'black book', 'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle', 'butter': 'butter box',
    'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet', 'wooden_cabinet': 'wooden wood cabinet',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack', 'microwave': 'microwave oven',
    'basket': 'basket', 'plate': 'plate', 'glazed_rim_porcelain_ramekin': 'ramekin',
    'cookies': 'cookie cookies box',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown', 'wooden', 'pink', 'orange'}
DIRS = ('left', 'right', 'front', 'back')
LEVELS = ('top', 'middle', 'bottom')
DRAWERW = {'drawer', 'drawers', 'layer', 'layers'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'top', 'left', 'right',
        'front', 'back', 'bottom', 'middle', 'compartment', 'side', 'its', 'that', 'is',
        'please', 'then', 'next', 'between', 'from', 'near'}
VERBS = {'put', 'place', 'turn', 'switch', 'close', 'shut', 'open', 'pick', 'push', 'pull',
         'move', 'stack', 'lift', 'grab', 'take', 'set'}
SEGP = {'into', 'onto', 'inside', 'in', 'on', 'to', 'next', 'at', 'between', 'from',
        'near', 'beside', 'atop'}
RELW = ('of', 'compartment', 'side', 'region', 'part')


def V(*a):
    return np.array(a, dtype=float)


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def E(api):
    return np.array(api.eef(), dtype=float)


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    if 'cabinet' in w:
        w |= DRAWERW
    return w


# ------------------------------------------------------------ resolution
def best_bodies(bodies, ws, exclude=()):
    W = {w for w in ws if w not in STOP}
    if not W:
        return []
    best, out = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, out = s, [b]
        elif abs(s - best) < 1e-9:
            out.append(b)
    return out


def spatial(api, ws, cands):
    keys = {'left': lambda p: -p[1], 'right': lambda p: p[1],
            'front': lambda p: p[0], 'back': lambda p: -p[0]}
    for w in DIRS:
        if w in ws:
            return sorted(cands, key=lambda c: keys[w](P(api, c)))
    return sorted(cands)


def pick_body(api, bodies, ws, exclude=()):
    c = best_bodies(bodies, ws, exclude)
    if not c:
        return None
    return spatial(api, ws, c)[0] if len(c) > 1 else c[0]


def region_by_words(names, ws):
    W = {w for w in ws if w not in ('the', 'a', 'an', 'of', 'to')}
    best, bs = None, 0
    for n in names:
        if _is_region(n):
            s = len(W & set(n.split('_')))
            if s > bs:
                best, bs = n, s
    return best


def resolve_target(api, names, bodies, ws, prep='', drawer=False, use_rel=True):
    ws = list(ws)
    R = set(ws)
    if use_rel:
        for i, w in enumerate(ws):
            nxt = ws[i + 1] if i + 1 < len(ws) else ''
            if w in DIRS and nxt in RELW:
                rest = [x for x in ws if x not in DIRS and x not in RELW]
                ref = pick_body(api, bodies, rest)
                if ref:
                    inside = bool(R & {'compartment', 'inside'}) or prep in ('into', 'inside') \
                        or (prep == 'in' and nxt != 'of')
                    try:
                        r = api.relative_target(ref, w, 'inside' if inside else 'outside')
                    except Exception:
                        r = None
                    if r:
                        return (str(r), ref)
                break
    obj = pick_body(api, bodies, ws)
    if obj is None:
        r = region_by_words(names, ws)
        return (r, r) if r else None
    regs = [n for n in names if _is_region(n) and n.startswith(obj + '_')]
    if not regs:
        return (obj, obj)
    D = bool(R & DRAWERW) or drawer
    lvl = next((l for l in LEVELS if l in R), None)
    lregs = {l: obj + '_' + l + '_region' for l in LEVELS if obj + '_' + l + '_region' in regs}
    if lregs and ('cabinet' in _base(obj) or len(lregs) >= 2):
        side = obj + '_top_side' if obj + '_top_side' in regs else None
        if side and not D and prep in ('on', 'onto', 'atop'):
            return (side, obj)
        if lvl in lregs:
            return (lregs[lvl], obj)
        if D or prep in ('in', 'into', 'inside'):
            return (lregs.get('top') or list(lregs.values())[0], obj)
        return (side or lregs.get('top') or list(lregs.values())[0], obj)
    best, bs = None, -1e9
    for r in regs:
        suf = r[len(obj) + 1:].split('_')
        toks = set(suf) - {'region', 'contain', 'side'}
        s = 3 * len(toks & R)
        if D and 'side' in suf:
            s -= 5
        if not D and 'top' in R and 'side' in suf:
            s += 2
        if not toks or toks <= {'cook', 'heating'}:
            s += 1
        if s > bs:
            bs, best = s, r
    return (best, obj)


def is_drawer(name, owner):
    b = _base(owner)
    return ('cabinet' in b or 'drawer' in b) and \
        any(name == owner + '_' + l + '_region' for l in LEVELS)


def next_to(api, names, bodies, ref):
    rp = P(api, ref)
    best, bd = None, 1e9
    for n in names:
        if not (_is_region(n) and n.startswith('main_table_')):
            continue
        q = P(api, n)
        d = np.linalg.norm(q[:2] - rp[:2])
        if d < 0.06 or d > 0.35:
            continue
        if any(np.linalg.norm(P(api, b)[:2] - q[:2]) < 0.05 for b in bodies):
            continue
        if d < bd:
            best, bd = n, d
    return best


def by_qual(api, names, bodies, qual, cands):
    prep, ws = qual
    try:
        if prep.startswith('between') and 'and' in ws:
            i = ws.index('and')
            a, b = pick_body(api, bodies, ws[:i]), pick_body(api, bodies, ws[i + 1:])
            if a and b:
                m = (P(api, a) + P(api, b)) / 2
                return min(cands, key=lambda c: np.linalg.norm(P(api, c)[:2] - m[:2]))
            return None
        pw = prep.split()[-1] if prep else ''
        t = resolve_target(api, names, bodies, ws, pw, use_rel=False)
        if t:
            loc = t[0]
            try:
                r = api.nearest(loc, list(cands))
                if r in cands:
                    return r
            except Exception:
                pass
            lp = P(api, loc)
            return min(cands, key=lambda c: np.linalg.norm(P(api, c)[:2] - lp[:2]))
    except Exception:
        pass
    return None


def resolve_item(api, names, bodies, part, quals, exclude=()):
    cands = best_bodies(bodies, part, exclude)
    if not cands:
        return None
    if len(cands) > 1:
        for q in quals:
            r = by_qual(api, names, bodies, q, cands)
            if r:
                return r
        return spatial(api, part, cands)[0]
    return cands[0]


# ------------------------------------------------------------ parsing
def split_clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if (w == 'and' and (nxt in VERBS or nxt == 'then')) or w == 'then':
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return out


def split_items(ws):
    both = 'both' in ws
    has_the = any(ws[j] == 'and' and j + 1 < len(ws) and ws[j + 1] in ('the', 'a')
                  for j in range(len(ws)))
    parts = [[]]
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if w == 'and' and ((has_the and nxt in ('the', 'a')) or (both and not has_the)):
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def segments(ws):
    segs = [['', []]]
    for w in ws:
        if w in SEGP:
            if segs[-1][1]:
                segs.append([w, []])
            else:
                segs[-1][0] = (segs[-1][0] + ' ' + w).strip()
        else:
            segs[-1][1].append(w)
    return segs


def grasp_for(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


def build_plan(api, names, bodies, words):
    ops, last_items, last_target = [], [], None
    clauses = split_clauses(words)
    for ci, c in enumerate(clauses):
        while c and c[-1] == 'and':
            c = c[:-1]
        if not c:
            continue
        v, rest = c[0], [w for w in c[1:] if w != 'up']
        if v not in VERBS or v in ('turn', 'switch', 'push', 'pull'):
            ops.append(('unsupported',))
            continue
        if v in ('open', 'close', 'shut'):
            lvl = next((l for l in LEVELS if l in rest), None)
            tgt = None
            if last_target and is_drawer(*last_target) and lvl is None and \
                    (not best_bodies(bodies, rest) or
                     last_target[1] in best_bodies(bodies, rest)):
                tgt = last_target
            elif rest and rest not in (['it'], ['them']):
                tgt = resolve_target(api, names, bodies, rest, 'in', drawer=True, use_rel=False)
            else:
                tgt = last_target
            if tgt and is_drawer(*tgt):
                ops.append(('drawer', tgt[0], 'open' if v == 'open' else 'close'))
                last_target = tgt
            else:
                ops.append(('unsupported',))
            continue
        segs = segments(rest)
        item_w = segs[0][1]
        last_prep = segs[-1][0].split()[-1] if len(segs) > 1 and segs[-1][0] else ''
        if v in ('pick', 'grab', 'lift', 'take') and not (
                ci == len(clauses) - 1 and last_prep in ('into', 'onto', 'to', 'inside')):
            it = None
            for part in split_items(item_w):
                it = resolve_item(api, names, bodies, part, segs[1:])
                break
            if it:
                ops.append(('pick', it))
                last_items = [it]
            else:
                ops.append(('unsupported',))
            continue
        if len(segs) < 2:
            ops.append(('unsupported',))
            continue
        tprep, tw = segs[-1]
        quals = segs[1:-1]
        if not tw or tw in (['it'], ['them']):
            tgt = last_target
        else:
            tgt = resolve_target(api, names, bodies, tw, tprep.split()[-1] if tprep else '')
            if tgt and tprep.startswith('next') and tgt[0] == tgt[1]:
                n2 = next_to(api, names, bodies, tgt[1])
                if n2:
                    tgt = (n2, tgt[1])
        if tgt is None:
            ops.append(('unsupported',))
            continue
        items = []
        for part in split_items(item_w):
            if part in (['it'], ['them']):
                its = list(last_items)
            else:
                its = [resolve_item(api, names, bodies, part, quals, exclude=(tgt[1],))]
            for it in its:
                if it and it not in items:
                    items.append(it)
        if not items:
            ops.append(('unsupported',))
            continue
        if ops and ops[-1][0] == 'pick' and ops[-1][1] in items:
            ops.pop()
        for it in items:
            ops.append(('place', it, tgt[0], grasp_for(it)))
        last_items, last_target = items, tgt
    return ops


# ------------------------------------------------------------ execution
def recover(api):
    try:
        api.grip(False)
        api.move(E(api) + V(0, 0, 0.12), steps=15)
    except Exception:
        pass


def pick_only(api, item):
    p = P(api, item)
    api.grip(False)
    e = E(api)
    api.move(V(e[0], e[1], max(e[2], p[2] + 0.12)), steps=15)
    api.move(p + V(0, 0, 0.10), steps=25)
    api.move(p, steps=20)
    api.grip(True)
    api.move(p + V(0, 0, 0.15), steps=25)


def place(api, item, target, grasp):
    for attempt in range(2):
        p0 = P(api, item)
        try:
            api.place_with(item, target, grasp)
        except Exception:
            recover(api)
        if np.linalg.norm(P(api, item) - p0) > 0.02:
            return
        recover(api)


def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    try:
        ops = build_plan(api, names, bodies, _words(api.instruction))
    except Exception:
        ops = None
    if not ops or any(op[0] == 'unsupported' for op in ops):
        api.fallback()
        return
    for op in ops:
        try:
            if op[0] == 'drawer':
                api.drawer(op[1], op[2])
            elif op[0] == 'place':
                place(api, op[1], op[2], op[3])
            elif op[0] == 'pick':
                pick_only(api, op[1])
        except Exception:
            recover(api)
