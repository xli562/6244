import math
import numpy as np

ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl', 'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup', 'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup', 'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop', 'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy',
    'black_book': 'black book', 'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle', 'butter': 'butter box',
    'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet drawer drawers',
    'wooden_cabinet': 'wooden cabinet drawer drawers',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack', 'microwave': 'microwave oven',
    'basket': 'basket', 'plate': 'plate', 'glazed_rim_porcelain_ramekin': 'ramekin',
    'cookies': 'cookie cookies box',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown',
          'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'top', 'left',
        'right', 'front', 'back', 'bottom', 'middle', 'compartment', 'side', 'its', 'that',
        'is', 'please', 'then', 'on', 'in', 'into', 'onto', 'inside', 'next', 'behind', 'at',
        'near', 'beside', 'by', 'from', 'between', 'there', 'over', 'under', 'atop'}
DIRS = {'left': 'left', 'right': 'right', 'front': 'front', 'back': 'back', 'behind': 'back'}
VERBS = {'put', 'place', 'turn', 'switch', 'close', 'shut', 'open', 'pick', 'push', 'pull',
         'move', 'stack', 'lift', 'grab', 'take', 'set', 'drop', 'insert'}
PICKV = {'pick', 'grab', 'lift', 'take'}
PLACEV = {'put', 'place', 'move', 'set', 'stack', 'drop', 'insert'}
TPREP = ('into', 'onto', 'inside', 'in', 'on', 'to', 'next', 'beside', 'behind', 'atop',
         'at', 'near', 'under')
LOC = ('on', 'next', 'between', 'in', 'from', 'at', 'near', 'beside', 'inside', 'by', 'behind')


def V(*a):
    return np.array(a, dtype=float)


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return w


def grasp_for(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


# ------------------------------------------------------------ resolution
def _cands(bodies, ws, exclude=()):
    W = {w for w in ws if w not in STOP}
    best, out = None, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if not m:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if best is None or s > best:
            best, out = s, [b]
        elif s == best:
            out.append(b)
    return sorted(out)


def _spatial_sort(api, ws, cands):
    keys = {'left': lambda p: -p[1], 'right': lambda p: p[1],
            'front': lambda p: p[0], 'back': lambda p: -p[0]}
    for w in ws:
        if w in keys:
            return sorted(cands, key=lambda c: keys[w](np.asarray(api.pos(c), float)))
    return cands


def _refpoint(api, bodies, ws, exclude):
    ws = list(ws)
    if 'between' in ws:
        rest = ws[ws.index('between') + 1:]
        if 'and' in rest:
            j = rest.index('and')
            a = _cands(bodies, rest[:j], exclude)
            b = _cands(bodies, rest[j + 1:], exclude)
            if a and b:
                return (np.asarray(api.pos(a[0]), float) + np.asarray(api.pos(b[0]), float)) / 2
    c = _cands(bodies, ws, exclude)
    return np.asarray(api.pos(c[0]), float) if c else None


def resolve_item(api, bodies, ws, exclude=()):
    ws = [w for w in ws if w not in ('up', 'both')]
    k = next((i for i, w in enumerate(ws) if w in LOC and i > 0), None)
    head, ref = (ws, []) if k is None else (ws[:k], ws[k:])
    c = _cands(bodies, head, exclude) or _cands(bodies, ws, exclude)
    if len(c) > 1 and ref:
        rp = _refpoint(api, bodies, ref, exclude=tuple(c))
        if rp is not None:
            c = sorted(c, key=lambda b: np.linalg.norm(np.asarray(api.pos(b), float)[:2] - rp[:2]))
    elif len(c) > 1:
        c = _spatial_sort(api, head, c)
    return c[0] if c else None


def resolve_target(api, names, bodies, prep, tw, item, last_region):
    T = list(tw)
    Ts = set(T)
    content = Ts - STOP - {'it', 'them', 'there'}
    if not content and not (Ts & set(DIRS)):
        return last_region
    c = _cands(bodies, T, exclude=(item,))
    if not c:
        return last_region
    fix = _spatial_sort(api, T, c)[0] if len(c) > 1 else c[0]
    regs = [n for n in names if _is_region(n) and n.startswith(fix + '_')]
    inner = bool(Ts & {'compartment', 'drawer', 'drawers'})

    # spatial wording: outside (next to a fixture) vs inside (compartment)
    dword = next((w for w in T if w in DIRS), None)
    d = DIRS[dword] if dword else None
    outside = False
    if prep == 'behind':
        d, outside = 'back', True
    elif d:
        i = T.index(dword)
        nxt = T[i + 1] if i + 1 < len(T) else ''
        outside = (not inner) and (prep in ('to', 'next', 'beside', 'near') or
                                   nxt in ('of', 'side', 'to'))
    if d and outside:
        try:
            r = api.relative_target(fix, d, 'outside')
            if r:
                return r
        except Exception:
            pass
    elif d and not any(d in n[len(fix) + 1:].split('_') for n in regs) and \
            d not in ('top', 'middle', 'bottom'):
        try:
            r = api.relative_target(fix, d, 'inside')
            if r:
                return r
        except Exception:
            pass

    if not regs:
        return fix

    # "on (the) top of X" -> the top surface, not the top drawer
    if 'top' in Ts:
        it = T.index('top')
        after = T[it + 1] if it + 1 < len(T) else ''
        on_top = after not in ('drawer', 'drawers', 'compartment', 'shelf') and \
            (prep in ('on', 'onto', 'atop') or after == 'of')
        if on_top:
            sides = [r for r in regs if r.endswith('top_side')]
            if sides:
                return sides[0]

    best, bs = None, -1e9
    for r in regs:
        suf = r[len(fix) + 1:].split('_')
        toks = set(suf) - {'region', 'contain', 'side'}
        s = 3 * len(toks & Ts)
        if 'side' in suf:
            s -= 4
        if not toks or toks <= {'cook', 'heating'}:
            s += 1
        if r == last_region:
            s += 2
        if inner and 'top' in toks:
            s += 0.5
        if s > bs:
            bs, best = s, r
    return best


def drawer_region(names, bodies, ws, last_region):
    c = [b for b in _cands(bodies, ws) if 'cabinet' in _base(b)]
    if not c:
        if last_region and 'cabinet' in last_region:
            fix = last_region.rsplit('_', 2)[0]
        else:
            if not ('drawer' in ws or 'drawers' in ws):
                return None
            cab = [b for b in bodies if 'cabinet' in _base(b)]
            if not cab:
                return None
            fix = cab[0]
    else:
        fix = c[0]
    regs = [n for n in names if n.startswith(fix + '_') and n.endswith('_region')]
    for lvl in ('top', 'middle', 'bottom'):
        if lvl in ws:
            r = fix + '_' + lvl + '_region'
            if r in regs:
                return r
    if last_region in regs:
        return last_region
    r = fix + '_top_region'
    return r if r in regs else (regs[0] if regs else None)


# ------------------------------------------------------------ planning
def clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if w == 'then' or (w == 'and' and (nxt in VERBS or nxt == 'then')):
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return out


def build(api, names, bodies, words):
    plan, last_items, last_region, pending = [], [], None, None
    for c in clauses(words):
        while c and c[-1] == 'and':
            c = c[:-1]
        if not c:
            continue
        v, rest = c[0], [w for w in c[1:] if w != 'up']
        if v in ('open', 'close', 'shut'):
            r = drawer_region(names, bodies, rest, last_region)
            if r is None:
                return None                      # e.g. microwave door: old policy
            plan.append(('drawer', r, 'open' if v == 'open' else 'close'))
            last_region = r
            continue
        if v in PICKV:
            it = resolve_item(api, bodies, rest)
            if it is None:
                return None
            pending, last_items = it, [it]
            continue
        if v not in PLACEV:
            return None                          # turn/switch/push...: old policy
        k = next((i for i, w in enumerate(rest) if w in TPREP and i > 0), None)
        if k is None and rest and rest[0] in ('it', 'them'):
            k = next((i for i, w in enumerate(rest) if w in TPREP), None)
        if k is None:
            return None
        iw, prep, tw = rest[:k], rest[k], rest[k + 1:]
        if prep == 'next' and tw[:1] == ['to']:
            tw = tw[1:]
        items = []
        if not iw or iw in (['it'], ['them']):
            items = list(last_items)
        else:
            part = []
            for w in iw + ['and']:
                if w == 'and':
                    if part:
                        if part in (['it'], ['them']):
                            items += last_items
                        else:
                            it = resolve_item(api, bodies, part, exclude=tuple(items))
                            if it:
                                items.append(it)
                    part = []
                elif w != 'both':
                    part.append(w)
        if not items:
            return None
        tgt = resolve_target(api, names, bodies, prep, tw, items[0], last_region)
        if tgt is None:
            return None
        for it in items:
            plan.append(('place', it, tgt, grasp_for(it)))
        pending, last_items, last_region = None, items, tgt
    if pending is not None:
        return None                              # standalone pick: old policy
    return plan or None


# ------------------------------------------------------------ execution
def placed(api, item, tgt):
    try:
        ip = np.asarray(api.pos(item), float)
        tp = np.asarray(api.pos(tgt), float)
    except Exception:
        return True
    return np.linalg.norm(ip[:2] - tp[:2]) < 0.09 and ip[2] > tp[2] - 0.08


def do_place(api, item, tgt, grasp):
    for _ in range(2):
        try:
            api.place_with(item, tgt, grasp)
        except Exception:
            try:
                api.transfer(item, tgt)
            except Exception:
                pass
        if placed(api, item, tgt):
            return True
        try:
            api.grip(False)
            e = np.asarray(api.eef(), float)
            api.move(e + V(0, 0, 0.10), steps=10)
        except Exception:
            pass
    return False


def run(api):
    try:
        names = list(api.names())
        bodies = [n for n in names if not _is_region(n)]
        plan = build(api, names, bodies, _words(api.instruction))
    except Exception:
        plan = None
    if not plan:
        api.fallback()
        return
    for step in plan:
        try:
            if step[0] == 'drawer':
                api.drawer(step[1], step[2])
            elif step[0] == 'place':
                do_place(api, step[1], step[2], step[3])
        except Exception:
            try:
                api.grip(False)
            except Exception:
                pass
