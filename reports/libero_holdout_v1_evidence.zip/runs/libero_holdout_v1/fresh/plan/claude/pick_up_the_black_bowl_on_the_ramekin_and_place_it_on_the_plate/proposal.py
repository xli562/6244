import numpy as np


def _w(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _reg(n):
    return n.endswith('_region') or n.endswith('_side') or 'table_' in n


def _P(api, n):
    return np.array(api.pos(n), dtype=float)


def _stem(t):
    return t[:-1] if t.endswith('s') and len(t) > 3 else t


def _toks(n):
    return set(_stem(t) for t in n.split('_') if not t.isdigit())


def _body(names, ws, exclude=()):
    W = set(_stem(w) for w in ws) - {'the', 'a', 'of', 'and', 'on', 'to', 'next', 'top'}
    if 'box' in W:
        W.add('cookie')
    best, bs = None, 0
    for n in names:
        if _reg(n) or n in exclude:
            continue
        s = len(W & _toks(n))
        if s > bs:
            best, bs = n, s
    return best


def _src_point(api, names, src, bowls):
    nonb = [n for n in names if n not in bowls]
    if 'between' in src:
        r = [n for n in names if 'between' in n]
        if r:
            return _P(api, r[0])
        i = src.index('between')
        a = _body(nonb, src[i + 1:src.index('and')] if 'and' in src else src[i + 1:])
        b = _body(nonb, src[src.index('and') + 1:], exclude=(a,)) if 'and' in src else None
        if a and b:
            return (_P(api, a) + _P(api, b)) / 2
    if 'next' in src:
        ref = _body(nonb, src[src.index('next') + 1:])
        if ref:
            key = [t for t in _toks(ref) if t in ('plate', 'ramekin', 'cookie', 'box', 'stove', 'cabinet')]
            for n in names:
                if 'next_to' in n and any(k in n for k in key + (['box'] if 'cookie' in key else [])):
                    return _P(api, n)
            return _P(api, ref)
    if 'drawer' in src:
        for lvl in ('top', 'middle', 'bottom'):
            if lvl in src:
                r = [n for n in names if 'cabinet' in n and n.endswith(lvl + '_region')]
                if r:
                    return _P(api, r[0])
    if 'center' in src:
        r = [n for n in names if n.endswith('table_center')]
        if r:
            return _P(api, r[0])
    ref = _body(nonb, src)
    if ref:
        if 'stove' in ref:
            c = [n for n in names if n.startswith(ref) and 'cook' in n]
            if c:
                return _P(api, c[0])
        if 'cabinet' in ref:
            c = [n for n in names if n.startswith(ref) and n.endswith('top_side')]
            if c:
                return _P(api, c[0])
        return _P(api, ref)
    return None


def _target(names, tw):
    T = set(tw)
    if 'plate' in T:
        p = [n for n in names if n.startswith('plate') and not _reg(n)]
        if p:
            return p[0]
    if 'stove' in T:
        c = [n for n in names if 'stove' in n and 'cook' in n]
        if c:
            return c[0]
    if 'cabinet' in T:
        if 'drawer' in T:
            for lvl in ('top', 'middle', 'bottom'):
                if lvl in T:
                    r = [n for n in names if 'cabinet' in n and n.endswith(lvl + '_region')]
                    if r:
                        return r[0]
        r = [n for n in names if 'cabinet' in n and n.endswith('top_side')]
        if r:
            return r[0]
    return _body(names, tw)


def _ok(api, bowl, tgt):
    b, t = _P(api, bowl), _P(api, tgt)
    return np.linalg.norm(b[:2] - t[:2]) < 0.07 and b[2] > t[2] - 0.03


def _recover(api):
    api.grip(False)
    e = np.array(api.eef(), dtype=float)
    api.move(e + np.array([0, 0, 0.12]), steps=12)


def run(api):
    names = list(api.names())
    ws = _w(api.instruction)
    bowls = [n for n in names if 'bowl' in n and not _reg(n)]
    split = None
    for j in range(len(ws) - 1):
        if ws[j] == 'and' and ws[j + 1] in ('place', 'put'):
            split = j
            break
    if not bowls or 'bowl' not in ws or split is None or ws.index('bowl') > split:
        return api.fallback()

    src = ws[ws.index('bowl') + 1:split]
    tw = [w for w in ws[split + 2:] if w not in ('it', 'on', 'onto', 'in', 'into', 'inside', 'the')]
    tgt = _target(names, tw)
    if tgt is None:
        return api.fallback()

    # 1) choose the bowl described by the source phrase (here: the one on the ramekin)
    pt = _src_point(api, names, src, bowls) if src else None
    if pt is not None:
        bowl = min(bowls, key=lambda b: np.linalg.norm(_P(api, b)[:2] - pt[:2]))
    else:
        bowl = sorted(bowls)[0]

    # 2) rim grasp: pinch the open bowl's wall and place it on the target
    for _ in range(2):
        try:
            api.place_with(bowl, tgt, 'rim')
        except Exception:
            pass
        if _ok(api, bowl, tgt):
            return
        _recover(api)

    # 3) last resort: direct top-down transfer at rim offsets
    for g in ((0.0, 0.06, 0.025), (0.0, -0.06, 0.025)):
        try:
            api.transfer(bowl, tgt, grasp=g, drop=(0, 0, 0.07))
        except Exception:
            pass
        if _ok(api, bowl, tgt):
            return
        _recover(api)
