import math
import numpy as np

ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl',
    'white_bowl': 'white bowl', 'porcelain_mug': 'white porcelain mug cup',
    'white_yellow_mug': 'white yellow mug cup', 'red_coffee_mug': 'red coffee mug cup',
    'chefmate_8_frypan': 'frying pan frypan skillet', 'flat_stove': 'stove burner cooktop',
    'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy', 'black_book': 'black book',
    'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle',
    'butter': 'butter box', 'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet', 'wooden_cabinet': 'wooden cabinet',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack', 'microwave': 'microwave oven',
    'basket': 'basket', 'plate': 'plate',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown',
          'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'top',
        'left', 'right', 'front', 'back', 'bottom', 'middle', 'compartment',
        'side', 'its', 'that', 'is', 'please', 'then', 'drawer', 'drawers',
        'region', 'part', 'in', 'on', 'into', 'onto', 'inside', 'at', 'next',
        'behind', 'with', 'from', 'near', 'between', 'beside'}
VERBS = {'put', 'place', 'turn', 'switch', 'close', 'shut', 'open', 'pick',
         'push', 'pull', 'move', 'stack', 'lift', 'grab', 'take', 'set'}
PREPS = ('into', 'onto', 'inside', 'in', 'on', 'to', 'at')
QUAL = ('on', 'in', 'at', 'near', 'from', 'next', 'between', 'beside', 'inside')
DIRS = ('left', 'right', 'front', 'back')
LEVELS = ('top', 'middle', 'bottom')


class Unsupported(Exception):
    pass


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return w


def _pos(api, n):
    try:
        return np.array(api.pos(n), dtype=float)
    except Exception:
        return None


def _match(bodies, ws, exclude=()):
    W = set(w for w in ws if w not in STOP)
    if not W:
        return []
    best, cands = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, cands = s, [b]
        elif abs(s - best) < 1e-9:
            cands.append(b)
    return sorted(cands)


def _dir_sort(api, cands, ws):
    for w in DIRS:
        if w in ws:
            keyf = {'left': lambda p: -p[1], 'right': lambda p: p[1],
                    'front': lambda p: p[0], 'back': lambda p: -p[0]}[w]
            return sorted(cands, key=lambda c: keyf(_pos(api, c)))
    return cands


def resolve_item(api, names, bodies, ws, exclude, last_item):
    ws = [w for w in ws if w not in ('both',)]
    if not ws or ws in (['it'], ['them']):
        return last_item
    q = None
    for i, w in enumerate(ws):
        if w in QUAL and i > 0:
            q, ws = ws[i + 1:], ws[:i]
            break
    cands = _match(bodies, ws, exclude)
    if not cands:
        return None
    if len(cands) > 1 and q:
        refs = _match(bodies, q, exclude=tuple(cands))
        rregs = [n for n in names if _is_region(n)
                 and set(w for w in q if w not in STOP) <= set(n.split('_'))]
        ref = refs[0] if refs else (rregs[0] if rregs else None)
        if ref:
            try:
                r = api.nearest(ref, cands)
                if r in cands:
                    return r
            except Exception:
                pass
            rp = _pos(api, ref)
            if rp is not None:
                return min(cands, key=lambda c: np.linalg.norm(_pos(api, c)[:2] - rp[:2]))
    if len(cands) > 1:
        cands = _dir_sort(api, cands, ws)
    return cands[0]


def resolve_target(api, names, bodies, tw, prep, last):
    if not tw or tw in (['it'], ['them']):
        return last
    R = set(tw)
    drawer = 'drawer' in R or 'drawers' in R
    d, rel = None, None
    if 'behind' in R:
        d, rel = 'back', 'outside'
    elif not drawer:
        for i, w in enumerate(tw):
            if w in DIRS:
                nxt = tw[i + 1] if i + 1 < len(tw) else ''
                d = w
                rel = 'outside' if (nxt in ('of', 'side', '') or prep == 'to') else 'inside'
                break
    owners = _match(bodies, tw)
    owner = owners[0] if owners else None
    if owner is None:
        toks = set(w for w in tw if w not in STOP)
        regs = [n for n in names if _is_region(n) and toks and toks <= set(n.split('_'))]
        if not regs and drawer:
            regs = [n for n in names if _is_region(n) and 'side' not in n
                    and any(l in R and l in n.split('_') for l in LEVELS)]
        return (regs[0], regs[0]) if regs else None
    if d:
        try:
            r = api.relative_target(owner, d, rel)
            if r:
                return (r, owner)
        except Exception:
            pass
    regs = [n for n in names if _is_region(n) and n.startswith(owner + '_')]
    if not regs:
        return (owner, owner)
    best, bs = None, -1e9
    for r in regs:
        suf = r[len(owner) + 1:].split('_')
        toks = set(suf) - {'region', 'contain', 'side'}
        s = 3 * len(toks & R)
        if drawer and 'side' in suf:
            s -= 5
        if not drawer and 'top' in R and 'side' in suf:
            s += 2
        if d and d in suf:
            s += 2
        if not toks or toks <= {'cook', 'heating'}:
            s += 1
        if s > bs:
            bs, best = s, r
    if bs < 1 and not drawer:
        return (owner, owner)
    return (best, owner)


def split_clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if (w == 'and' and (nxt in VERBS or nxt == 'then')) or w == 'then':
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return out


def split_items(ws):
    has_the = any(ws[j] == 'and' and j + 1 < len(ws) and ws[j + 1] in ('the', 'a')
                  for j in range(len(ws)))
    both = 'both' in ws
    parts = [[]]
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if w == 'and' and ((has_the and nxt in ('the', 'a')) or (both and not has_the)):
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def is_drawer_region(name, owner):
    t = name.split('_')
    return 'side' not in t and ('cabinet' in owner or 'drawer' in t
                                or any(l in t for l in LEVELS))


def build_plan(api, names, bodies, words):
    ops = []
    last_item, last_target, pending_pick = None, None, None
    for c in split_clauses(words):
        while c and c[-1] == 'and':
            c = c[:-1]
        if not c:
            continue
        v, rest = c[0], [w for w in c[1:] if w != 'up']
        if v in ('turn', 'switch', 'push', 'pull'):
            raise Unsupported()
        if v in ('open', 'close', 'shut'):
            tgt = resolve_target(api, names, bodies, rest, None, last_target)
            if tgt is None or not is_drawer_region(tgt[0], tgt[1]):
                raise Unsupported()
            ops.append(('drawer', tgt[0], 'open' if v == 'open' else 'close'))
            last_target = tgt
            continue
        idx = None
        for i in range(len(rest) - 1, 0, -1):
            if rest[i] in PREPS:
                idx = i
                break
        if v in ('pick', 'grab', 'lift', 'take') and idx is None:
            it = resolve_item(api, names, bodies, rest, (), last_item)
            if it is None:
                raise Unsupported()
            pending_pick, last_item = it, it
            continue
        if idx is None:
            item_w, tw, prep = rest, [], None
        else:
            item_w, tw, prep = rest[:idx], rest[idx + 1:], rest[idx]
            if item_w and item_w[-1] == 'next':
                item_w = item_w[:-1]
        tgt = resolve_target(api, names, bodies, tw, prep, last_target)
        if tgt is None:
            raise Unsupported()
        items = []
        for part in split_items(item_w) or [['it']]:
            it = resolve_item(api, names, bodies, part, (tgt[1],), last_item)
            if it and it not in items:
                items.append(it)
        if not items:
            raise Unsupported()
        for it in items:
            ops.append(('place', it, tgt[0]))
            if it == pending_pick:
                pending_pick = None
        last_item, last_target = items[-1], tgt
    if pending_pick is not None or not ops:
        raise Unsupported()
    return ops


def grasp_for(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


def placed_ok(api, item, target):
    ip, tp = _pos(api, item), _pos(api, target)
    if ip is None or tp is None:
        return True
    tol = 0.08 if ('basket' in target or 'contain' in target or _is_region(target)) else 0.07
    if 'caddy' in target:
        tol = 0.05
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.06


def recover(api):
    try:
        api.grip(False)
        e = np.array(api.eef(), dtype=float)
        api.move(e + np.array([0, 0, 0.12]), steps=15)
    except Exception:
        pass


def do_place(api, item, target):
    g = grasp_for(item)
    for _ in range(2):
        try:
            api.place_with(item, target, g)
        except Exception:
            recover(api)
        if placed_ok(api, item, target):
            return True
        recover(api)
    try:
        api.transfer(item, target, grasp=(0, 0, 0), drop=(0, 0, 0.08))
    except Exception:
        recover(api)
    return placed_ok(api, item, target)


def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    try:
        ops = build_plan(api, names, bodies, _words(api.instruction))
    except Exception:
        api.fallback()
        return
    for op in ops:
        try:
            if op[0] == 'drawer':
                api.drawer(op[1], op[2])
            else:
                do_place(api, op[1], op[2])
        except Exception:
            recover(api)
