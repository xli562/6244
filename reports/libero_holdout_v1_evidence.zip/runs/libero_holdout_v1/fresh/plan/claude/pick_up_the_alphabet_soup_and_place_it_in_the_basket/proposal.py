import numpy as np

ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl', 'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup', 'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup', 'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop', 'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy',
    'black_book': 'black book', 'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle', 'butter': 'butter box',
    'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet', 'wooden_cabinet': 'wooden cabinet',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack', 'microwave': 'microwave oven',
    'basket': 'basket', 'plate': 'plate',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown', 'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'top', 'left', 'right',
        'front', 'back', 'bottom', 'middle', 'compartment', 'side', 'its', 'that', 'is',
        'please', 'then', 'next', 'drawer', 'region'}
VERBS = {'put', 'place', 'pick', 'move', 'set', 'open', 'close', 'shut', 'grab', 'take',
         'lift', 'stack', 'turn', 'switch', 'push', 'pull'}
PLACE_V = {'put', 'place', 'move', 'set', 'stack'}
PICK_V = {'pick', 'grab', 'take', 'lift'}
PREPS = ('into', 'onto', 'inside', 'in', 'on', 'next', 'at')
DIRS = ('left', 'right', 'front', 'back')


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _desc(b):
    base = _base(b)
    d = set(base.split('_'))
    if base in ALIAS:
        d |= set(ALIAS[base].split())
    return d


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def resolve(api, bodies, ws, exclude=()):
    W = set(w for w in ws if w not in STOP)
    if not W:
        return None
    best, cands = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, cands = s, [b]
        elif abs(s - best) < 1e-9:
            cands.append(b)
    if not cands:
        return None
    if len(cands) > 1:
        for w in DIRS:
            if w in ws:
                key = {'left': lambda p: -p[1], 'right': lambda p: p[1],
                       'front': lambda p: p[0], 'back': lambda p: -p[0]}[w]
                return sorted(cands, key=lambda c: key(P(api, c)))[0]
        cands.sort()
    return cands[0]


def region_for(names, body, ws):
    regs = [n for n in names if _is_region(n) and n.startswith(body + '_')]
    if not regs:
        return body
    R = set(ws)
    drawer = 'drawer' in R or 'drawers' in R
    best, bs = regs[0], -1e9
    for r in regs:
        suf = r[len(body) + 1:].split('_')
        toks = set(suf) - {'region', 'side'}
        s = 3 * len(toks & R)
        if drawer and 'side' in suf:
            s -= 5
        if not drawer and 'top' in R and 'side' in suf and ('on' in R or 'onto' in R):
            s += 4
        if 'contain' in suf:
            s += 1
        if s > bs:
            bs, best = s, r
    return best


def resolve_target(api, names, bodies, ws, exclude=()):
    """Return the target region name, honouring spatial wording."""
    body = resolve(api, bodies, ws, exclude)
    if body is None:
        return None
    drawer = 'drawer' in ws or 'drawers' in ws
    dirs = [d for d in DIRS if d in ws]
    if dirs and not drawer:
        rel = 'inside' if ('compartment' in ws or 'inside' in ws or 'in' in ws) else 'outside'
        if rel == 'outside' or 'compartment' in ws:
            try:
                r = api.relative_target(body, dirs[0], rel)
                if r:
                    return r
            except Exception:
                pass
    return region_for(names, body, ws)


def grasp_for(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


def placed_ok(api, item, tgt):
    try:
        ip, tp = P(api, item), P(api, tgt)
    except Exception:
        return True
    tol = 0.045 if 'caddy' in tgt else 0.08
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.06


def split_clauses(ws):
    out, cur = [], []
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if w == 'then' or (w == 'and' and (nxt in VERBS or nxt == 'then')):
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return out


def split_items(ws):
    parts = [[]]
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if w == 'and' and nxt in ('the', 'a'):
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def build_plan(api, names, bodies, ws):
    ops, last_item, last_drawer, pending = [], None, None, None
    for c in split_clauses(ws):
        v, rest = c[0], [w for w in c[1:] if w != 'up']
        if v in ('turn', 'switch', 'push', 'pull'):
            return None                       # unsupported -> old policy
        if v in ('open', 'close', 'shut'):
            if not rest or rest in (['it'], ['them']):
                reg = last_drawer
            else:
                body = resolve(api, bodies, rest)
                reg = region_for(names, body, rest + ['drawer']) if body else None
            if reg is None:
                return None
            ops.append(('drawer', reg, 'open' if v == 'open' else 'close'))
            last_drawer = reg
            continue
        idx = next((i for i, w in enumerate(rest) if w in PREPS and i > 0), None)
        if v in PICK_V and idx is None:
            it = resolve(api, bodies, rest)
            if it is None:
                return None
            pending = it
            last_item = it
            continue
        if v not in PLACE_V and v not in PICK_V:
            return None
        item_w = rest if idx is None else rest[:idx]
        tw = [] if idx is None else rest[idx:]
        if not tw:
            return None
        if tw[0] == 'next':
            tw = tw[1:]
        if tw and tw[0] in PREPS:
            tw = tw[1:]
        if tw in (['it'], ['them']) and last_drawer:
            tgt = last_drawer
        else:
            ex_items = [resolve(api, bodies, p) for p in split_items(item_w)
                        if p not in (['it'], ['them'])]
            tgt = resolve_target(api, names, bodies, tw,
                                 exclude=tuple(x for x in ex_items if x))
        if tgt is None:
            return None
        if any(w in tw for w in ('drawer', 'drawers')):
            last_drawer = tgt
        items = []
        for p in split_items(item_w):
            it = (last_item or pending) if p in (['it'], ['them']) else \
                resolve(api, bodies, p, exclude=(tgt, _base(tgt)))
            if it and it not in items:
                items.append(it)
        if not items:
            return None
        for it in items:
            ops.append(('place', it, tgt))
        last_item, pending = items[-1], None
    if pending:
        ops.append(('pick', pending))
    return ops or None


def do_place(api, item, tgt):
    g = grasp_for(item)
    for _ in range(2):
        try:
            api.place_with(item, tgt, g)
        except Exception:
            pass
        if placed_ok(api, item, tgt):
            return True
        try:
            api.grip(False)
            api.move(np.array(api.eef(), dtype=float) + np.array([0, 0, 0.10]), steps=12)
        except Exception:
            pass
    try:
        api.transfer(item, tgt, grasp=(0, 0, 0), drop=(0, 0, 0.10))
    except Exception:
        pass
    return placed_ok(api, item, tgt)


def do_pick(api, item):
    p = P(api, item)
    api.grip(False)
    api.move(p + np.array([0, 0, 0.12]), steps=30)
    api.move(p, steps=25)
    api.grip(True)
    api.move(p + np.array([0, 0, 0.15]), steps=25)


def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    ws = _words(api.instruction)
    try:
        ops = build_plan(api, names, bodies, ws)
    except Exception:
        ops = None
    if not ops:
        return api.fallback()
    # e.g. "pick the alphabet soup and place it in the basket" ->
    #   [('place', 'alphabet_soup_1', 'basket_1_contain_region')]  grasp='standard'
    for op in ops:
        try:
            if op[0] == 'drawer':
                api.drawer(op[1], op[2])
            elif op[0] == 'place':
                do_place(api, op[1], op[2])
            elif op[0] == 'pick':
                do_pick(api, op[1])
        except Exception:
            try:
                api.grip(False)
            except Exception:
                pass
