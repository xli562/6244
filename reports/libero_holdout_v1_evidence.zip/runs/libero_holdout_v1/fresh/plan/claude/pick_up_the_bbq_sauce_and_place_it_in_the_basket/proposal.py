import numpy as np

ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl', 'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup', 'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup', 'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop', 'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy',
    'black_book': 'black book', 'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle', 'butter': 'butter box',
    'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet', 'wooden_cabinet': 'wooden cabinet',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack', 'microwave': 'microwave oven',
    'basket': 'basket', 'plate': 'plate',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown', 'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'top', 'left', 'right',
        'front', 'back', 'bottom', 'middle', 'compartment', 'side', 'its', 'that', 'is',
        'please', 'then', 'next'}
VERBS = {'put', 'place', 'turn', 'switch', 'close', 'shut', 'open', 'pick', 'push', 'pull',
         'move', 'stack', 'lift', 'grab', 'take', 'set'}
PREPS = ('into', 'onto', 'inside', 'in', 'on', 'to')
DIRS = ('left', 'right', 'front', 'back')


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return w


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def resolve(api, bodies, raw, exclude=()):
    W = set(w for w in raw if w not in STOP)
    if not W:
        return None
    best, cands = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, cands = s, [b]
        elif abs(s - best) < 1e-9:
            cands.append(b)
    if not cands:
        return None
    if len(cands) > 1:
        for w in DIRS:
            if w in raw:
                key = {'left': lambda p: -p[1], 'right': lambda p: p[1],
                       'front': lambda p: p[0], 'back': lambda p: -p[0]}[w]
                return sorted(cands, key=lambda c: key(P(api, c)))[0]
    return sorted(cands)[0]


def resolve_target(api, names, bodies, raw):
    obj = resolve(api, bodies, raw)
    if obj is None:
        return None
    R = set(raw)
    # spatial wording: compartment IN a fixture vs table location NEXT TO it
    for d in DIRS:
        if d in R and not ({'drawer', 'drawers'} & R) and not ('top' in R and d == 'top'):
            rel = 'inside' if ({'compartment', 'in', 'inside', 'into'} & R) else 'outside'
            try:
                r = api.relative_target(obj, d, rel)
                if r:
                    return (r, obj)
            except Exception:
                pass
    regs = [n for n in names if _is_region(n) and n.startswith(obj + '_')]
    if not regs:
        return (obj, obj)
    drawer = bool({'drawer', 'drawers'} & R)
    best, bs = None, -1e9
    for r in regs:
        suf = r[len(obj) + 1:].split('_')
        toks = set(suf) - {'region', 'contain', 'side'}
        s = 3 * len(toks & R)
        if drawer and 'side' in suf:
            s -= 5
        if (not drawer) and 'top' in R and 'side' in suf:
            s += 2
        if not toks or toks <= {'cook', 'heating'}:
            s += 1
        if s > bs:
            bs, best = s, r
    return (best, obj)


def split_clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if (w == 'and' and (nxt in VERBS or nxt == 'then')) or w == 'then':
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return out


def split_items(ws):
    both = 'both' in ws
    has_the = any(ws[j] == 'and' and j + 1 < len(ws) and ws[j + 1] in ('the', 'a')
                  for j in range(len(ws)))
    parts = [[]]
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if w == 'and' and ((has_the and nxt in ('the', 'a')) or (both and not has_the)):
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def build_plan(api, names, bodies, words):
    """returns list of ops, or None if an unsupported action appears"""
    ops, last_item, last_target = [], None, None
    pending_pick = None
    for c in split_clauses(words):
        while c and c[-1] == 'and':
            c = c[:-1]
        if not c:
            continue
        v, rest = c[0], [w for w in c[1:] if w != 'up']
        if v in ('turn', 'switch'):
            return None
        if v in ('open', 'close', 'shut'):
            tgt = last_target if (not rest or rest in (['it'], ['them'])) \
                else resolve_target(api, names, bodies, rest)
            if tgt is None:
                return None
            ops.append(('drawer', tgt[0], 'open' if v == 'open' else 'close'))
            last_target = tgt
            continue
        idx = next((i for i, w in enumerate(rest) if w in PREPS and i > 0), None)
        if idx is None:
            if v in ('pick', 'grab', 'lift', 'take'):
                it = resolve(api, bodies, rest)
                if it is None:
                    return None
                pending_pick = it          # may be completed by a later "place it ..."
                last_item = it
                continue
            return None
        item_w, tw = rest[:idx], rest[idx + 1:]
        if tw and tw[0] == 'of':           # "to the left of X" handled by resolve_target
            tw = tw[1:]
        tgt = last_target if (not tw or tw in (['it'], ['them'])) \
            else resolve_target(api, names, bodies, rest[idx:])
        if tgt is None:
            return None
        items = []
        for part in split_items(item_w) or [['it']]:
            it = last_item if part in (['it'], ['them']) \
                else resolve(api, bodies, part, exclude=(tgt[1],))
            if it and it not in items:
                items.append(it)
        if not items:
            return None
        for it in items:
            ops.append(('place', it, tgt[0]))
        if pending_pick in items:
            pending_pick = None
        last_item, last_target = items[-1], tgt
    if pending_pick is not None:
        return None                        # bare pick: unsupported by shared skills
    return ops


def grasp_for(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'          # pinch the wall of an open bowl
    if 'book' in b:
        return 'thin_edge'    # jaws across a narrow book-like object
    return 'standard'         # bottles, boxes, cans, mugs, pans


def placed_ok(api, item, target):
    try:
        ip, tp = P(api, item), P(api, target)
    except Exception:
        return True
    tol = 0.045 if 'caddy' in target else (0.09 if ('basket' in target or 'contain' in target) else 0.08)
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.06


def place(api, item, target):
    g = grasp_for(item)
    for _ in range(2):
        try:
            api.place_with(item, target, g)
        except Exception:
            pass
        if placed_ok(api, item, target):
            return True
    try:
        z = 0.11 if 'basket' in target else 0.08
        api.transfer(item, target, grasp=(0, 0, 0), drop=(0, 0, z))
    except Exception:
        pass
    return placed_ok(api, item, target)


def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    try:
        ops = build_plan(api, names, bodies, _words(api.instruction))
    except Exception:
        ops = None
    if not ops:
        api.fallback()        # unsupported action (e.g. stove) or unparsed: previous policy
        return
    # Example: "pick the bbq sauce and place it in the basket"
    #   -> [('place', 'bbq_sauce_1', 'basket_1_contain_region')]  grasp='standard'
    for op in ops:
        try:
            if op[0] == 'drawer':
                api.drawer(op[1], op[2])
            elif op[0] == 'place':
                place(api, op[1], op[2])
        except Exception:
            try:
                api.grip(False)
                e = np.array(api.eef(), dtype=float)
                api.move(e + np.array([0, 0, 0.1]), steps=12)
            except Exception:
                pass
