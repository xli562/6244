import math
import numpy as np

STOP = {'the', 'a', 'an', 'of', 'it', 'up', 'please', 'and', 'them'}
QUAL_START = ('on', 'in', 'inside', 'from', 'next', 'between', 'at', 'near', 'onto')
SYN = {'cookie': 'cookies', 'cookies': 'cookies', 'box': 'cookies',
       'ramekin': 'ramekin', 'plate': 'plate', 'stove': 'stove',
       'cabinet': 'cabinet', 'bowl': 'bowl', 'book': 'book', 'mug': 'mug',
       'cup': 'mug', 'caddy': 'caddy', 'basket': 'basket'}


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _toks(name):
    t = [x for x in name.split('_') if not x.isdigit()]
    out = set(t)
    for x in t:
        if x in SYN:
            out.add(SYN[x])
    return out


def _P(api, n):
    return np.array(api.pos(n), dtype=float)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side') or n.startswith('main_table')


def _match_bodies(bodies, ws):
    W = set(SYN.get(w, w) for w in ws if w not in STOP) | set(w for w in ws if w not in STOP)
    best, out = 0, []
    for b in bodies:
        s = len(W & _toks(b))
        if s > best:
            best, out = s, [b]
        elif s == best and s > 0:
            out.append(b)
    return out


def _reference(api, names, bodies, qual):
    """position named by a qualifier like 'on the cookies box'."""
    W = set(qual)
    regs = [n for n in names if n.startswith('main_table')]
    if 'between' in W:
        r = [n for n in regs if 'between' in n]
        if r:
            return _P(api, r[0])
    if 'next' in W or 'beside' in W:
        keys = set(SYN.get(w, w) for w in W)
        for n in regs:
            if 'next_to' in n:
                tail = n.split('next_to_')[-1].split('_')[0]
                if SYN.get(tail, tail) in keys or tail in W:
                    return _P(api, n)
    if 'center' in W:
        r = [n for n in regs if 'center' in n]
        if r:
            return _P(api, r[0])
    if 'drawer' in W:
        for lvl in ('top', 'middle', 'bottom'):
            if lvl in W:
                r = [n for n in names if n.endswith(lvl + '_region') and 'cabinet' in n]
                if r:
                    return _P(api, r[0])
    m = _match_bodies(bodies, [w for w in qual if w not in QUAL_START])
    if m:
        return _P(api, m[0])
    return None


def _target(api, names, bodies, ws):
    W = set(ws)
    if 'drawer' in W:
        for lvl in ('top', 'middle', 'bottom'):
            if lvl in W:
                r = [n for n in names if n.endswith('_' + lvl + '_region') and 'cabinet' in n]
                if r:
                    return r[0]
    m = _match_bodies(bodies, ws)
    if not m:
        return None
    t = m[0]
    if 'stove' in t:
        r = [n for n in names if n.startswith(t + '_') and 'cook' in n]
        return r[0] if r else t
    if 'cabinet' in t and 'top' in W:
        r = [n for n in names if n.startswith(t + '_') and n.endswith('top_side')]
        return r[0] if r else t
    return t


def _mode(item):
    if 'bowl' in item:
        return 'rim'
    if 'book' in item:
        return 'thin_edge'
    return 'standard'


def _placed(api, item, target):
    try:
        ip, tp = _P(api, item), _P(api, target)
        return np.linalg.norm(ip[:2] - tp[:2]) < 0.07 and ip[2] > tp[2] - 0.05
    except Exception:
        return False


def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    w = _words(api.instruction)

    # parse "pick/take <item> [qualifier] and place/put it <prep> <target>"
    split = None
    for i in range(len(w) - 1):
        if w[i] == 'and' and w[i + 1] in ('place', 'put', 'set'):
            split = i
            break
    if split is None or not w or w[0] not in ('pick', 'take', 'grab', 'lift'):
        return api.fallback()

    pick = [x for x in w[1:split] if x != 'up']
    place = w[split + 2:]
    q = next((j for j, x in enumerate(pick) if x in QUAL_START), len(pick))
    item_ws, qual = pick[:q], pick[q:]
    pj = next((j for j, x in enumerate(place) if x in ('on', 'onto', 'in', 'into', 'inside')), None)
    if pj is None:
        return api.fallback()
    tgt_ws = place[pj + 1:]

    cands = _match_bodies(bodies, item_ws)
    target = _target(api, names, bodies, tgt_ws)
    if not cands or target is None:
        return api.fallback()
    cands = [c for c in cands if c != target] or cands

    # disambiguate identical objects with the spatial qualifier
    item = cands[0]
    if len(cands) > 1:
        ref = _reference(api, names, bodies, qual) if qual else None
        if ref is not None:
            def score(c):
                p = _P(api, c)
                s = np.linalg.norm(p[:2] - ref[:2])
                if qual and qual[0] in ('on', 'onto'):
                    s -= 0.5 * max(0.0, p[2] - ref[2])   # sits on top of it
                return s
            item = min(cands, key=score)
        else:
            item = sorted(cands)[0]

    # place with the grasp suited to the item: 'rim' for the black bowl
    mode = _mode(item)
    for _ in range(2):
        try:
            api.place_with(item, target, mode)
        except Exception:
            pass
        if _placed(api, item, target):
            return
        try:
            api.grip(False)
            e = np.array(api.eef(), dtype=float)
            api.move(e + np.array([0, 0, 0.10]), steps=12)
        except Exception:
            pass
    try:
        api.arrange([(item, target)])
    except Exception:
        pass
