import math
import numpy as np

ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl', 'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup', 'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup', 'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop', 'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy',
    'black_book': 'black book', 'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle', 'butter': 'butter box',
    'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet', 'wooden_cabinet': 'wooden cabinet',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack', 'microwave': 'microwave oven',
    'basket': 'basket', 'plate': 'plate',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown', 'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'to', 'up', 'please', 'and', 'then', 'towards', 'toward'}
DIRS = ('front', 'back', 'left', 'right')


def V(*a):
    return np.array(a, dtype=float)


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def E(api):
    return np.array(api.eef(), dtype=float)


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return w


def match_body(bodies, ws, exclude=()):
    W = set(ws) - STOP - set(DIRS)
    best, bs = None, -1e9
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > bs:
            bs, best = s, b
    return best


def spatial_region(api, names, ref, direction, relation):
    try:
        r = api.relative_target(ref, direction, relation)
        if r in names:
            return r
    except Exception:
        pass
    toks = set(_base(ref).split('_'))
    for n in names:
        if _is_region(n):
            parts = n.split('_')
            if direction in parts and toks & set(parts):
                return n
    return None


def grasp_kind(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


# ------------------------------------------------------------ pushing
def push_to(api, item, target, tol=0.025):
    """Non-prehensile push of item's centre onto target's xy using closed fingers."""
    R = 0.12          # standoff behind item centre before contact
    r_est = 0.08      # estimated contact offset (item half-width + finger)
    dz = 0.0
    for _ in range(4):
        p, t = P(api, item), P(api, target)
        d = t[:2] - p[:2]
        dist = float(np.linalg.norm(d))
        if dist < tol:
            return True
        u = d / dist
        z = p[2] + 0.012 + dz
        s = p[:2] - u * R
        e = E(api)
        api.grip(True)
        api.move(V(e[0], e[1], max(e[2], z + 0.12)), steps=12)
        api.move(V(s[0], s[1], z + 0.12), steps=25)
        api.move(V(s[0], s[1], z), steps=18)
        travel = (R - r_est) + dist
        g = s + u * travel
        steps = int(np.clip(40 + 300 * travel, 35, 90))
        rem = api.move(V(g[0], g[1], z), steps=steps)
        # back off along the push line before lifting so the item is not dragged
        e = E(api)
        api.move(V(e[0] - u[0] * 0.03, e[1] - u[1] * 0.03, z), steps=6)
        api.move(V(e[0] - u[0] * 0.03, e[1] - u[1] * 0.03, z + 0.12), steps=12)
        p2 = P(api, item)
        moved = float(np.dot(p2[:2] - p[:2], u))
        if moved > 0.01:
            r_est = float(np.clip(moved - travel + R, 0.03, 0.11))
        elif rem is not None and rem > 0.03:
            dz += 0.01   # likely scraping the table; push a little higher
    p, t = P(api, item), P(api, target)
    return float(np.linalg.norm(t[:2] - p[:2])) < 0.06


# ------------------------------------------------------------ main
def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    ws = _words(api.instruction)
    if not ws:
        return api.fallback()
    verb = ws[0]

    # find "<dir> of <reference>" phrase
    di = None
    for i, w in enumerate(ws):
        if w in DIRS and i + 1 < len(ws) and ws[i + 1] == 'of':
            di = i
            break
    relation = 'inside' if any(w in ws for w in ('inside', 'compartment')) else 'outside'

    # item words: after verb, up to the first preposition
    cut = len(ws)
    for i, w in enumerate(ws[1:], 1):
        if w in ('to', 'towards', 'toward', 'into', 'onto', 'on', 'in', 'inside', 'next'):
            cut = i
            break
    item = match_body(bodies, ws[1:cut])

    target = None
    if di is not None:
        ref = match_body(bodies, ws[di + 2:], exclude=(item,))
        if ref is not None:
            target = spatial_region(api, names, ref, ws[di], relation)

    try:
        if verb in ('push', 'slide', 'shove', 'nudge') and item is not None:
            if target is None:
                ref = match_body(bodies, ws[cut + 1:], exclude=(item,))
                if ref is not None:
                    regs = [n for n in names if _is_region(n) and _base(ref).split('_')[-1] in n
                            and n.startswith('main_table')]
                    target = regs[0] if regs else ref
            if target is not None:
                # placement 1: item -> target, grasp: none (closed-finger push)
                if push_to(api, item, target):
                    return
                # last resort: physical pick-and-place with standard grasp
                api.place_with(item, target, 'standard')
                return
        elif verb in ('put', 'place', 'move', 'set') and item is not None and target is not None:
            # placement 1: item -> spatial target, grasp chosen by object shape
            api.place_with(item, target, grasp_kind(item))
            return
    except Exception:
        try:
            api.grip(False)
            e = E(api)
            api.move(e + V(0, 0, 0.10), steps=10)
        except Exception:
            pass
        return
    return api.fallback()
