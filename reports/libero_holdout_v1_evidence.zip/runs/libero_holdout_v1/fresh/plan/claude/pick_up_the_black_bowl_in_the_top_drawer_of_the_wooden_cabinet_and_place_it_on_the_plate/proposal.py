import math
import numpy as np

ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl', 'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup', 'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup', 'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop', 'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy',
    'black_book': 'black book', 'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle', 'butter': 'butter box',
    'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet', 'wooden_cabinet': 'wooden cabinet',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack', 'microwave': 'microwave oven',
    'glazed_rim_porcelain_ramekin': 'ramekin', 'cookies': 'cookie cookies box',
    'basket': 'basket', 'plate': 'plate',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown',
          'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'top',
        'left', 'right', 'front', 'back', 'bottom', 'middle', 'compartment',
        'side', 'its', 'that', 'is', 'please', 'then'}
QSTOP = {'the', 'a', 'an', 'of', 'it', 'in', 'on', 'at', 'from', 'inside', 'into',
         'onto', 'layer', 'drawer', 'shelf', 'that', 'is', 'which', 'located',
         'sitting', 'placed', 'and', 'its', 'level', 'table'}
VERBS = {'put', 'place', 'turn', 'switch', 'close', 'shut', 'open', 'pick',
         'push', 'pull', 'move', 'stack', 'lift', 'grab', 'take', 'set'}
PREPS = {'into', 'onto', 'inside', 'in', 'on', 'at'}
DIRS = ('left', 'right', 'front', 'back')


def V(*a):
    return np.array(a, dtype=float)


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def E(api):
    return np.array(api.eef(), dtype=float)


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _words(s):
    s = ''.join(c if c.isalnum() else ' ' for c in s.lower())
    return s.split()


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return w


def owner_of(name, bodies):
    best = None
    for b in bodies:
        if name == b or name.startswith(b + '_'):
            if best is None or len(b) > len(best):
                best = b
    return best


# ------------------------------------------------------------ resolution
def resolve_cands(bodies, raw, exclude=()):
    W = set(w for w in raw if w not in STOP)
    if not W:
        return []
    best, cands = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, cands = s, [b]
        elif abs(s - best) < 1e-9:
            cands.append(b)
    return cands


def spatial(api, names, raw, cands):
    for w in DIRS:
        if w in raw:
            keyf = {'left': lambda p: -p[1], 'right': lambda p: p[1],
                    'front': lambda p: p[0], 'back': lambda p: -p[0]}[w]
            return sorted(cands, key=lambda c: keyf(P(api, c)))
    return sorted(cands)


def match_region(names, bodies, raw, exclude=()):
    """best-matching body or region for a location phrase"""
    q = set(w for w in raw if w not in QSTOP)
    if not q:
        return None
    R = set(raw)
    inside_words = bool(R & {'drawer', 'layer', 'shelf', 'in', 'inside', 'into', 'compartment'})
    best, bs = None, -1e9
    for n in names:
        if n in exclude:
            continue
        own = owner_of(n, bodies)
        rawt = [t for t in n.split('_') if not t.isdigit()]
        toks = set(rawt) - {'main', 'table', 'region'}
        if own:
            toks |= _desc(own)
        m = len(q & toks)
        if m == 0:
            continue
        unmatched = len((set(rawt) - {'main', 'table', 'region'}) - q)
        s = 2 * m - 0.3 * unmatched
        if 'side' in rawt:
            if inside_words:
                s -= 1.5
            elif 'on' in R and 'top' in R:
                s += 1.0
        if not _is_region(n):
            s += 0.01
        if s > bs:
            bs, best = s, n
    return best


def nearest(api, reg, cands):
    try:
        r = api.nearest(reg, list(cands))
        if r in cands:
            return r
    except Exception:
        pass
    rp = P(api, reg)
    return min(cands, key=lambda c: float(np.linalg.norm(P(api, c) - rp)))


def choose_item(api, names, bodies, item_w, qual_w, exclude=()):
    cands = resolve_cands(bodies, item_w, exclude)
    if not cands:
        return None
    if len(cands) == 1:
        return cands[0]
    if qual_w:
        reg = match_region(names, bodies, qual_w, exclude=tuple(cands))
        if reg:
            return nearest(api, reg, cands)
    return spatial(api, names, item_w, cands)[0]


def resolve_target(api, names, bodies, tw, exclude=()):
    prep = tw[0] if tw else ''
    raw = tw
    best = match_region(names, bodies, raw, exclude)
    dirs = [d for d in DIRS if d in raw]
    if dirs and (best is None or dirs[0] not in best.split('_')):
        ref_w = [w for w in raw if w not in DIRS]
        ref = None
        c = resolve_cands(bodies, ref_w, exclude)
        if c:
            ref = c[0]
        if ref:
            inside = ('compartment' in raw or
                      (prep in ('in', 'into', 'inside') and 'front' not in raw
                       and 'of' not in raw[:3]))
            try:
                r = api.relative_target(ref, dirs[0], 'inside' if inside else 'outside')
                if r in names:
                    return r
            except Exception:
                pass
    if best is None:
        return None
    if not _is_region(best):
        kids = [n for n in names if n.startswith(best + '_') and _is_region(n)]
        if kids:
            if prep in ('in', 'into', 'inside'):
                k = [n for n in kids if 'contain' in n or 'heating' in n]
            else:
                k = [n for n in kids if 'cook' in n or n.endswith('top_side')]
            if k:
                return k[0]
    return best


# ------------------------------------------------------------ parsing
def split_clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if (w == 'and' and (nxt in VERBS or nxt == 'then')) or w == 'then':
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return [c for c in out if c]


def split_items(ws):
    both = 'both' in ws
    has_the = any(ws[j] == 'and' and j + 1 < len(ws) and ws[j + 1] in ('the', 'a')
                  for j in range(len(ws)))
    parts = [[]]
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if w == 'and' and ((has_the and nxt in ('the', 'a')) or (both and not has_the)):
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def starts_of(rest):
    st = []
    for i, w in enumerate(rest):
        if i == 0:
            continue
        prev = rest[i - 1]
        if w in PREPS or w in ('next', 'between', 'from'):
            st.append(i)
        elif w == 'to' and prev != 'next' and any(d in rest[i + 1:i + 3] for d in DIRS):
            st.append(i)
    return st


def build_plan(api, names, bodies, words):
    ops = []
    last_item, last_tgt = None, None
    for c in split_clauses(words):
        while c and c[-1] == 'and':
            c = c[:-1]
        if not c:
            continue
        v, rest = c[0], [w for w in c[1:] if w != 'up']
        if v in ('open', 'close', 'shut', 'pull', 'push') and (
                v in ('open', 'close', 'shut') or 'drawer' in rest):
            mode = 'open' if v in ('open', 'pull') else 'close'
            if not rest or rest in (['it'], ['them']):
                reg = last_tgt
            else:
                reg = match_region(names, bodies, rest)
            if reg:
                ops.append(('drawer', reg, mode))
                last_tgt = reg
            continue
        st = starts_of(rest)
        if v in ('pick', 'grab', 'lift', 'take'):
            item_w = rest[:st[0]] if st else rest
            qual = rest[st[0]:] if st else []
            if item_w in (['it'], ['them']):
                it = last_item
            else:
                it = choose_item(api, names, bodies, item_w, qual)
            if it:
                ops.append(('pick', it))
                last_item = it
            continue
        if not st:
            continue
        item_w = rest[:st[0]]
        qual = rest[st[0]:st[-1]] if len(st) > 1 else []
        tw = rest[st[-1]:]
        if tw[1:] in (['it'], ['them']) and last_tgt:
            tgt = last_tgt
        else:
            tgt = resolve_target(api, names, bodies, tw)
        if tgt is None:
            continue
        town = owner_of(tgt, bodies)
        items = []
        for part in split_items(item_w):
            if part in (['it'], ['them']):
                it = last_item
            else:
                it = choose_item(api, names, bodies, part, qual,
                                 exclude=(town,) if town else ())
            if it and it not in items:
                items.append(it)
        if ops and ops[-1][0] == 'pick' and ops[-1][1] in items:
            ops.pop()
        for it in items:
            ops.append(('place', it, tgt))
        if items:
            last_item = items[-1]
        last_tgt = tgt
    return ops


# ------------------------------------------------------------ skills
def grasp_kind(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


def grasp_offset(item):
    b = _base(item)
    if 'bowl' in b:
        return (0.0, 0.06, 0.025)
    if 'mug' in b or 'cup' in b:
        return (0.0, 0.03, 0.02)
    return (0.0, 0.0, 0.0)


def placed_ok(api, item, tgt):
    try:
        ip, tp = P(api, item), P(api, tgt)
    except Exception:
        return False
    tol = 0.07
    if 'basket' in tgt or 'contain' in tgt:
        tol = 0.08
    if 'caddy' in tgt:
        tol = 0.045
    if 'cabinet' in tgt:
        tol = 0.09
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.06


def recover(api):
    try:
        api.grip(False)
        api.move(E(api) + V(0, 0, 0.12), steps=15)
    except Exception:
        pass


def do_place(api, item, tgt):
    kind = grasp_kind(item)
    for _ in range(2):
        try:
            api.place_with(item, tgt, kind)
        except Exception:
            pass
        if placed_ok(api, item, tgt):
            return True
        recover(api)
    try:
        api.transfer(item, tgt, grasp=grasp_offset(item), drop=(0, 0, 0.08))
    except Exception:
        pass
    if not placed_ok(api, item, tgt):
        recover(api)
        return False
    return True


def pick_only(api, item):
    p = P(api, item) + V(*grasp_offset(item))
    api.grip(False)
    e = E(api)
    api.move(V(e[0], e[1], max(e[2], p[2] + 0.12)), steps=12)
    api.move(p + V(0, 0, 0.10), steps=25)
    api.move(p, steps=20)
    api.grip(True)
    api.move(p + V(0, 0, 0.15), steps=25)


# ------------------------------------------------------------ main
def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    words = _words(api.instruction)
    if any(w in ('turn', 'switch') for w in words):
        api.fallback()
        return
    try:
        ops = build_plan(api, names, bodies, words)
    except Exception:
        ops = []
    if not ops:
        api.fallback()
        return
    for op in ops:
        try:
            if op[0] == 'drawer':
                api.drawer(op[1], op[2])
            elif op[0] == 'place':
                do_place(api, op[1], op[2])
            elif op[0] == 'pick':
                pick_only(api, op[1])
        except Exception:
            recover(api)
