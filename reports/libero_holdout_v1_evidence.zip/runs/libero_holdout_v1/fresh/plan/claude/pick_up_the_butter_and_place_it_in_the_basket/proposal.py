import numpy as np

ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl', 'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup', 'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup', 'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop', 'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy',
    'black_book': 'black book', 'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle', 'butter': 'butter box',
    'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet', 'wooden_cabinet': 'wooden cabinet',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack', 'microwave': 'microwave oven',
    'basket': 'basket', 'plate': 'plate',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown', 'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'its', 'that',
        'is', 'please', 'then', 'top', 'side', 'compartment', 'drawer', 'left', 'right',
        'front', 'back', 'bottom', 'middle'}
VERBS = {'put', 'place', 'turn', 'switch', 'close', 'shut', 'open', 'pick', 'push', 'pull',
         'move', 'stack', 'lift', 'grab', 'take', 'set'}
PREPS = ('into', 'onto', 'inside', 'in', 'on')
DIRS = ('left', 'right', 'front', 'back')


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return w


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def resolve(api, bodies, ws, exclude=()):
    W = set(w for w in ws if w not in STOP)
    if not W:
        return None
    best, cands = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best:
            best, cands = s, [b]
        elif s == best:
            cands.append(b)
    if not cands:
        return None
    if len(cands) > 1:
        for d in DIRS:
            if d in ws:
                key = {'left': lambda p: -p[1], 'right': lambda p: p[1],
                       'front': lambda p: p[0], 'back': lambda p: -p[0]}[d]
                cands.sort(key=lambda c: key(P(api, c)))
                break
        else:
            cands.sort()
    return cands[0]


def target_region(api, names, bodies, ws):
    owner = resolve(api, bodies, ws)
    if owner is None:
        return None, None
    regs = [n for n in names if _is_region(n) and n.startswith(owner + '_')]
    if not regs:
        return owner, owner
    R = set(ws)
    drawer = 'drawer' in R or 'drawers' in R
    # spatial compartment / table location next to a fixture
    for d in DIRS:
        if d in R and not drawer:
            rel = 'outside' if ('next' in R or 'beside' in R) else 'inside'
            try:
                r = api.relative_target(owner, d, rel)
                if r:
                    return r, owner
            except Exception:
                pass
    best, bs = regs[0], -1e9
    for r in regs:
        suf = r[len(owner) + 1:].split('_')
        toks = set(suf) - {'region', 'side'}
        s = 3 * len(toks & R)
        if 'contain' in suf and R & {'in', 'into', 'inside'}:
            s += 2
        if drawer and 'side' in suf:
            s -= 5
        if not drawer and 'top' in R and 'side' in suf:
            s += 3
        if s > bs:
            bs, best = s, r
    return best, owner


def grasp_type(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


def placed_ok(api, item, region):
    ip, tp = P(api, item), P(api, region)
    tol = 0.045 if 'caddy' in region else (0.08 if ('basket' in region or 'contain' in region) else 0.07)
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.06


def place(api, item, region):
    g = grasp_type(item)
    for _ in range(2):
        try:
            api.place_with(item, region, g)
        except Exception:
            pass
        if placed_ok(api, item, region):
            return True
    z = 0.11 if 'basket' in region else 0.08
    try:
        api.transfer(item, region, grasp=(0, 0, 0), drop=(0, 0, z))
    except Exception:
        pass
    return placed_ok(api, item, region)


def clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if w == 'then' or (w == 'and' and (nxt in VERBS or nxt == 'then')):
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return out


def split_items(ws):
    parts = [[]]
    for w in ws:
        if w == 'and':
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def build(api, names, bodies, words):
    ops, last_item, last_drawer = [], None, None
    for c in clauses(words):
        v, rest = c[0], [w for w in c[1:] if w != 'up']
        if v in ('turn', 'switch'):
            return None                      # stove etc: old policy
        if v in ('open', 'close', 'shut'):
            if rest in ([], ['it']):
                reg = last_drawer
            else:
                reg, _ = target_region(api, names, bodies, rest)
            if reg is None:
                return None
            ops.append(('drawer', reg, 'open' if v == 'open' else 'close'))
            last_drawer = reg
            continue
        idx = next((i for i, w in enumerate(rest) if w in PREPS and i > 0), None)
        if idx is None:
            if v in ('pick', 'grab', 'lift', 'take'):
                last_item = resolve(api, bodies, rest)
                continue
            return None
        iw, tw = rest[:idx], rest[idx:]
        if tw[1:] in ([], ['it']) and last_drawer:
            reg, owner = last_drawer, None
        else:
            reg, owner = target_region(api, names, bodies, tw)
        if reg is None:
            return None
        for part in split_items(iw):
            it = last_item if part in (['it'], ['them']) else \
                resolve(api, bodies, part, exclude=(owner,))
            if it is None:
                return None
            ops.append(('place', it, reg))
            last_item = it
    return ops or None


def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    try:
        ops = build(api, names, bodies, _words(api.instruction))
    except Exception:
        ops = None
    if not ops:
        return api.fallback()
    # e.g. "pick the butter and place it in the basket":
    #   [('place', 'butter_1', 'basket_1_contain_region')]  grasp = 'standard'
    for op in ops:
        try:
            if op[0] == 'drawer':
                api.drawer(op[1], op[2])
            else:
                place(api, op[1], op[2])
        except Exception:
            try:
                api.grip(False)
                api.move(np.array(api.eef(), dtype=float) + np.array([0, 0, 0.12]), steps=15)
            except Exception:
                pass
