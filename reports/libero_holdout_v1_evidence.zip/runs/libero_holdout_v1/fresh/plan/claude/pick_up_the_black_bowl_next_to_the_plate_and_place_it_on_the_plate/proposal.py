import numpy as np

VERBS = {'put', 'place', 'pick', 'open', 'close', 'shut', 'turn', 'switch', 'move',
         'stack', 'grab', 'take', 'set', 'push', 'pull', 'lift'}
PLACEV = {'put', 'place', 'move', 'stack', 'set'}
PICKV = {'pick', 'grab', 'take', 'lift'}
LOCW = {'next', 'beside', 'near', 'between', 'on', 'in', 'inside', 'from', 'at', 'by', 'onto', 'into'}
PREPS = ('onto', 'into', 'inside', 'on', 'in')
FILL = {'the', 'a', 'an', 'up', 'of', 'to', 'its', 'please', 'both'}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown', 'pink', 'orange', 'wooden'}
SYN = {'cookie': 'box', 'cookies': 'box', 'skillet': 'frypan', 'pan': 'frypan',
       'frying': 'frypan', 'oven': 'microwave', 'cup': 'mug', 'centre': 'center',
       'barbecue': 'bbq', 'beside': 'next', 'near': 'next'}
ALIAS = {'porcelain_mug': 'white cup', 'white_yellow_mug': 'cup', 'red_coffee_mug': 'cup',
         'chefmate_8_frypan': 'frying pan', 'flat_stove': 'burner cooktop',
         'cream_cheese': 'box', 'butter': 'box', 'chocolate_pudding': 'box',
         'milk': 'carton', 'orange_juice': 'carton', 'bbq_sauce': 'bottle',
         'ketchup': 'bottle', 'salad_dressing': 'bottle', 'alphabet_soup': 'can',
         'tomato_sauce': 'can', 'microwave': 'oven'}


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _isreg(n):
    return n.endswith('_region') or n.endswith('_side') or n.startswith('main_table')


def _tok(w):
    out = {w}
    if len(w) > 3 and w.endswith('s') and not w.endswith('ss'):
        out.add(w[:-1])
    for x in list(out):
        if x in SYN:
            out.add(SYN[x])
    return out


def _btoks(b):
    base = _base(b)
    D = set()
    for t in base.split('_') + ALIAS.get(base, '').split():
        if t and not t.isdigit():
            D |= _tok(t)
    return D


def _P(api, n):
    return np.array(api.pos(n), dtype=float)


def resolve_bodies(bodies, ws, exclude=()):
    W = set()
    for w in ws:
        if w not in FILL and w not in LOCW:
            W |= _tok(w)
    best, out = 0, []
    for b in bodies:
        if b in exclude:
            continue
        D = _btoks(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - 2 * len((W & COLORS) - D) - len((D & COLORS) - W)
        if s <= 0:
            continue
        if s > best:
            best, out = s, [b]
        elif s == best:
            out.append(b)
    return out


def find_region(names, ws):
    W = set()
    for w in ws:
        W |= _tok(w)
    if not W:
        return None
    nxt = 'next' in W
    btw = 'between' in W
    drw = 'drawer' in W
    content = W - {'next', 'to', 'between', 'the', 'and', 'of', 'on', 'in', 'inside',
                   'into', 'onto', 'from', 'at', 'by', 'a', 'drawer'}
    best, bs = None, 0
    for r in names:
        if not _isreg(r):
            continue
        T = set()
        for t in r.split('_'):
            if t.isdigit() or t in ('main', 'region'):
                continue
            T |= _tok(t)
        if btw != ('between' in T) or nxt != ('next' in T):
            continue
        if drw and 'side' in T:
            continue
        s = 2 * len(content & T)
        if s == 0:
            continue
        if 'side' in T:
            s += 1 if ('on' in W and not drw) else -2
        if s > bs:
            bs, best = s, r
    return best


def choose(api, names, bodies, cands, locws):
    if not cands:
        return None
    if len(cands) == 1:
        return cands[0]
    if locws:
        r = find_region(names, locws)
        if r is not None:
            try:
                res = api.nearest(r, list(cands))
                if res in cands:
                    return res
            except Exception:
                pass
            try:
                rp = _P(api, r)
                return min(cands, key=lambda c: np.linalg.norm(_P(api, c)[:2] - rp[:2]))
            except Exception:
                pass
        refs = resolve_bodies(bodies, locws, exclude=tuple(cands))
        if refs:
            try:
                rp = _P(api, refs[0])
                return min(cands, key=lambda c: np.linalg.norm(_P(api, c)[:2] - rp[:2]))
            except Exception:
                pass
        for w in ('left', 'right', 'front', 'back'):
            if w in locws:
                keyf = {'left': lambda p: -p[1], 'right': lambda p: p[1],
                        'front': lambda p: p[0], 'back': lambda p: -p[0]}[w]
                try:
                    return sorted(cands, key=lambda c: keyf(_P(api, c)))[0]
                except Exception:
                    pass
    return sorted(cands)[0]


def parse_np(ws):
    ws = [w for w in ws if w not in ('both', 'up')]
    for i, w in enumerate(ws):
        if w in LOCW and i > 0:
            return ws[:i], ws[i:]
    return ws, []


def resolve_item(api, names, bodies, ws, exclude=()):
    noun, loc = parse_np(ws)
    return choose(api, names, bodies, resolve_bodies(bodies, noun, exclude), loc)


def resolve_target(api, names, bodies, ws, item):
    if 'drawer' in ws or 'drawers' in ws:
        level = next((l for l in ('top', 'middle', 'bottom') if l in ws), 'top')
        ow = [w for w in ws if w not in ('drawer', 'drawers', 'top', 'middle', 'bottom')]
        owners = resolve_bodies(bodies, ow, exclude=(item,) if item else ())
        owners = [o for o in owners if any(n.startswith(o + '_') and _isreg(n) for n in names)] or \
                 [b for b in bodies if 'cabinet' in b]
        for o in owners:
            reg = o + '_' + level + '_region'
            if reg in names:
                return reg
        return find_region(names, ws)
    noun, loc = parse_np(ws)
    cands = resolve_bodies(bodies, noun, exclude=(item,) if item else ())
    if not cands:
        return find_region(names, ws)
    b = choose(api, names, bodies, cands, loc)
    sub = [n for n in names if n.startswith(b + '_') and _isreg(n)]
    inside = any(w in ('in', 'into', 'inside') for w in ws)
    for n in sub:
        if 'cook' in n:
            return n
    if inside:
        for n in sub:
            if 'contain' in n or 'heating' in n:
                return n
    else:
        for n in sub:
            if n.endswith('top_side'):
                return n
    return b


def grasp_for(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


def placed(api, item, tgt):
    try:
        ip, tp = _P(api, item), _P(api, tgt)
    except Exception:
        return True
    tol = 0.08
    if 'caddy' in tgt:
        tol = 0.05
    elif 'basket' in tgt:
        tol = 0.09
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.05


def recover(api):
    try:
        api.grip(False)
        e = np.array(api.eef(), dtype=float)
        api.move(e + np.array([0, 0, 0.12]), steps=15)
    except Exception:
        pass


def do_place(api, item, tgt):
    g = grasp_for(item)
    for attempt in range(2):
        try:
            api.place_with(item, tgt, g)
        except Exception:
            try:
                api.arrange([(item, tgt)])
            except Exception:
                pass
        if placed(api, item, tgt):
            return True
        recover(api)
    return False


def pick_only(api, item):
    p = _P(api, item)
    api.grip(False)
    api.move(p + np.array([0, 0, 0.12]), steps=30)
    api.move(p, steps=25)
    api.grip(True)
    api.move(p + np.array([0, 0, 0.15]), steps=25)


def split_clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if (w == 'and' and (nxt in VERBS or nxt == 'then')) or w == 'then':
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return out


def build(api, names, bodies, words):
    plan, pending = [], []
    for c in split_clauses(words):
        v, rest = c[0], [w for w in c[1:] if w != 'up']
        if v in ('turn', 'switch', 'push', 'pull'):
            return None
        if v in ('open', 'close', 'shut'):
            if 'drawer' not in rest and 'drawers' not in rest:
                return None
            reg = resolve_target(api, names, bodies, rest, None)
            if reg is None:
                return None
            plan.append(('drawer', reg, 'open' if v == 'open' else 'close'))
            continue
        if v in PICKV:
            it = resolve_item(api, names, bodies, rest)
            if it is None:
                return None
            pending = [it]
            plan.append(('pick', it))
            continue
        if v in PLACEV:
            idx = None
            for i in range(len(rest) - 1, 0, -1):
                if rest[i] in PREPS:
                    idx = i
                    break
            if idx is None:
                return None
            item_ws, tws = rest[:idx], rest[idx + 1:]
            core = [w for w in item_ws if w not in FILL]
            if not core or core in (['it'], ['them']):
                items = list(pending)
            else:
                parts = [item_ws] if 'between' in item_ws else \
                    [p for p in ' '.join(item_ws).split(' and ') if p]
                items = []
                for p in parts:
                    pw = p.split() if isinstance(p, str) else p
                    it = resolve_item(api, names, bodies, pw)
                    if it and it not in items:
                        items.append(it)
            if not items:
                return None
            tgt = resolve_target(api, names, bodies, tws, items[0])
            if tgt is None:
                return None
            if plan and plan[-1][0] == 'pick' and plan[-1][1] in items:
                plan.pop()
            for it in items:
                plan.append(('place', it, tgt))
            pending = items
            continue
        return None
    return plan or None


def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _isreg(n)]
    words = _words(api.instruction)
    try:
        plan = build(api, names, bodies, words)
    except Exception:
        plan = None
    if not plan:
        api.fallback()
        return
    for op in plan:
        try:
            if op[0] == 'drawer':
                api.drawer(op[1], op[2])
            elif op[0] == 'place':
                # e.g. place_with(<bowl nearest next_to_plate_region>, 'plate_1', 'rim')
                do_place(api, op[1], op[2])
            elif op[0] == 'pick':
                pick_only(api, op[1])
        except Exception:
            recover(api)
