import math
import numpy as np

ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl', 'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup', 'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup', 'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop', 'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy',
    'black_book': 'black book', 'yellow_book': 'yellow book',
    'cream_cheese': 'cream cheese box', 'alphabet_soup': 'alphabet soup can',
    'tomato_sauce': 'tomato sauce can', 'bbq_sauce': 'bbq barbecue sauce bottle',
    'ketchup': 'ketchup bottle', 'butter': 'butter box', 'milk': 'milk carton',
    'orange_juice': 'orange juice carton', 'chocolate_pudding': 'chocolate pudding box',
    'salad_dressing': 'salad dressing bottle', 'microwave': 'microwave oven',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack',
    'cookies': 'cookie box', 'glazed_rim_porcelain_ramekin': 'ramekin glazed porcelain dish',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown',
          'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'top',
        'left', 'right', 'front', 'back', 'bottom', 'middle', 'compartment',
        'side', 'its', 'that', 'is', 'please', 'then', 'on', 'in', 'into', 'onto',
        'inside', 'from', 'at', 'next', 'between', 'near', 'beside', 'by'}
VERBS = {'put', 'place', 'turn', 'switch', 'close', 'shut', 'open', 'pick',
         'push', 'pull', 'move', 'stack', 'lift', 'grab', 'take', 'set'}
PICKV = {'pick', 'grab', 'lift', 'take'}
PLACEV = {'put', 'place', 'move', 'set'}
QUAL = ('on', 'in', 'inside', 'from', 'near', 'next', 'between', 'at', 'beside', 'by')
TPREP = ('onto', 'into', 'on', 'in', 'inside')
DIRS = ('left', 'right', 'front', 'back')
LEVELS = ('top', 'middle', 'bottom')


def V(*a):
    return np.array(a, dtype=float)


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def _stem(w):
    if len(w) > 3 and w.endswith('s') and not w.endswith('ss'):
        return w[:-1]
    return w


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side') or n.startswith('main_table')


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return set(_stem(x) for x in w)


def _cands(bodies, ws):
    W = set(_stem(w) for w in ws if w not in STOP)
    if not W:
        return []
    best, out = -1e9, []
    for b in bodies:
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, out = s, [b]
        elif abs(s - best) < 1e-9:
            out.append(b)
    return sorted(out)


def _sort_dir(api, cands, d):
    key = {'left': lambda p: -p[1], 'right': lambda p: p[1],
           'front': lambda p: -p[0], 'back': lambda p: p[0]}[d]
    return sorted(cands, key=lambda c: key(P(api, c)))


def _subregion(names, obj, R):
    regs = [n for n in names if (n.endswith('_region') or n.endswith('_side'))
            and n.startswith(obj + '_')]
    if not regs:
        return obj
    Rs = set(R)
    drawer = bool(Rs & {'drawer', 'drawers'})
    best = obj
    if not drawer and (obj + '_top_side') in regs:
        best = obj + '_top_side'
    bs = 0
    for r in regs:
        suf = r[len(obj) + 1:].split('_')
        toks = set(suf) - {'region', 'contain', 'side'}
        s = 3 * len(toks & Rs)
        if drawer and 'side' in suf:
            s -= 5
        if (not drawer) and 'top' in Rs and 'side' in suf:
            s += 2
        if not toks or toks <= {'cook', 'heating'}:
            s += 1
        if s > bs:
            bs, best = s, r
    return best


def _loc(api, names, bodies, ws):
    """resolve a location phrase to a body or region name"""
    R = list(ws)
    S = set(_stem(w) for w in R if w not in STOP)
    for key in ('between', 'next'):
        if key in R:
            best, bs = None, 0
            for n in names:
                if _is_region(n) and key in n.split('_'):
                    toks = set(_stem(t) for t in n.split('_')) - {
                        'main', 'table', 'region', 'next', 'to', 'between'}
                    s = len(toks & S)
                    if s > bs:
                        best, bs = n, s
            if best:
                return best
    cands = _cands(bodies, [w for w in R if w not in DIRS])
    if not cands:
        best, bs = None, 0
        for n in names:
            if _is_region(n):
                s = len(set(_stem(t) for t in n.split('_')) & S)
                if s > bs:
                    best, bs = n, s
        return best
    di = [i for i, w in enumerate(R) if w in DIRS]
    if di:
        d = R[di[0]]
        after = R[di[0] + 1:]
        if 'compartment' in after or 'of' in after[:2]:
            rel = 'inside' if ('compartment' in after or 'drawer' in after) else 'outside'
            try:
                r = api.relative_target(cands[0], d, rel)
                if r:
                    return r
            except Exception:
                pass
        elif len(cands) > 1:
            cands = _sort_dir(api, cands, d)
    return _subregion(names, cands[0], R)


def _item(api, names, bodies, ws, exclude=()):
    qi = None
    for i, w in enumerate(ws):
        if i > 0 and w in QUAL and any(x not in STOP for x in ws[:i]):
            qi = i
            break
    iw = ws if qi is None else ws[:qi]
    qw = [] if qi is None else ws[qi:]
    cands = [c for c in _cands(bodies, [w for w in iw if w not in DIRS])
             if not any(e == c or e.startswith(c + '_') for e in exclude)]
    if not cands:
        return None
    if len(cands) > 1:
        ref = _loc(api, names, bodies, qw) if qw else None
        if ref and ref not in cands:
            pick = None
            try:
                r = api.nearest(ref, list(cands))
                if r in cands:
                    pick = r
            except Exception:
                pick = None
            rp = P(api, ref)
            mine = min(cands, key=lambda c: np.linalg.norm(P(api, c)[:2] - rp[:2]))
            if pick is None:
                pick = mine
            return pick
        for d in DIRS:
            if d in iw:
                return _sort_dir(api, cands, d)[0]
    return cands[0]


def _clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if (w == 'and' and (nxt in VERBS or nxt == 'then')) or w == 'then':
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return out


def _split_items(ws):
    both = 'both' in ws
    has_the = any(ws[j] == 'and' and j + 1 < len(ws) and ws[j + 1] in ('the', 'a')
                  for j in range(len(ws)))
    parts = [[]]
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if w == 'and' and ((has_the and nxt in ('the', 'a')) or (both and not has_the)):
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def _is_drawer(r):
    return isinstance(r, str) and not r.endswith('_side') and \
        ('cabinet' in r or 'drawer' in r) and \
        any(r.endswith('_%s_region' % l) for l in LEVELS)


def _plan(api, names, bodies, words):
    ops, last_items, last_tgt = [], [], None
    for c in _clauses(words):
        while c and c[-1] == 'and':
            c = c[:-1]
        if not c:
            continue
        v, rest = c[0], [w for w in c[1:] if w != 'up']
        if v in ('open', 'close', 'shut'):
            content = [w for w in rest if w not in STOP and w not in ('drawer', 'drawers')]
            reg = _loc(api, names, bodies, rest) if content or \
                any(l in rest for l in LEVELS) else last_tgt
            if not _is_drawer(reg):
                return None
            ops.append(('drawer', reg, 'open' if v == 'open' else 'close'))
            last_tgt = reg
            continue
        if v in PICKV:
            it = _item(api, names, bodies, rest)
            if it is None:
                return None
            ops.append(('pick', it))
            last_items = [it]
            continue
        if v not in PLACEV:
            return None
        ti, tw = None, []
        for i in range(len(rest) - 1, 0, -1):
            if rest[i] in TPREP:
                ti, tw = i, rest[i + 1:]
                break
        if ti is None:
            for i in range(1, len(rest)):
                if rest[i] in ('to', 'next', 'beside'):
                    ti, tw = i, rest[i:]
                    break
        iw = rest if ti is None else rest[:ti]
        if not tw or tw in (['it'], ['them']):
            tgt = last_tgt
        else:
            tgt = _loc(api, names, bodies, tw)
        if tgt is None:
            return None
        items = []
        for part in _split_items(iw):
            if part in (['it'], ['them']):
                new = list(last_items)
            else:
                it = _item(api, names, bodies, part, exclude=(tgt,))
                new = [it] if it else []
            for it in new:
                if it not in items:
                    items.append(it)
        if not items:
            return None
        if ops and ops[-1][0] == 'pick' and ops[-1][1] in items:
            ops.pop()
        for it in items:
            ops.append(('place', it, tgt))
        last_items, last_tgt = items, tgt
    return ops


# ---------------------------------------------------------------- skills
def _grasp(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'          # pinch the wall of the open bowl
    if 'book' in b:
        return 'thin_edge'    # jaws across the narrow book
    return 'standard'


def _ok(api, item, tgt):
    ip, tp = P(api, item), P(api, tgt)
    tol, dz = 0.08, 0.06
    if _is_drawer(tgt) or 'contain' in tgt or 'basket' in tgt:
        tol, dz = 0.11, 0.10
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - dz


def _recover(api):
    try:
        api.grip(False)
        api.move(np.array(api.eef(), dtype=float) + V(0, 0, 0.10), steps=10)
    except Exception:
        pass


def _place(api, item, tgt):
    g = _grasp(item)
    for _ in range(2):
        try:
            api.place_with(item, tgt, g)
        except Exception:
            pass
        if _ok(api, item, tgt):
            return True
        _recover(api)
    return False


def _pick(api, item):
    off = V(0, 0.06, 0.025) if 'bowl' in _base(item) else V(0, 0, 0)
    p = P(api, item) + off
    api.grip(False)
    api.move(p + V(0, 0, 0.12), steps=30)
    api.move(p, steps=25)
    api.grip(True)
    api.move(p + V(0, 0, 0.15), steps=25)


def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    try:
        ops = _plan(api, names, bodies, _words(api.instruction))
    except Exception:
        ops = None
    if not ops:
        api.fallback()   # unsupported action (e.g. stove knob) -> previous policy
        return
    # e.g. "pick the akita black bowl on the stove and place it on the plate"
    #  -> [('place', <bowl nearest flat_stove_1_cook_region>, 'plate_1')], grasp 'rim'
    for op in ops:
        try:
            if op[0] == 'drawer':
                api.drawer(op[1], op[2])
            elif op[0] == 'place':
                _place(api, op[1], op[2])
            elif op[0] == 'pick':
                _pick(api, op[1])
        except Exception:
            _recover(api)
