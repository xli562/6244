import math
import numpy as np

ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl', 'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup', 'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup', 'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop', 'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy',
    'black_book': 'black book', 'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle', 'butter': 'butter box',
    'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet', 'wooden_cabinet': 'wooden cabinet',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack', 'microwave': 'microwave oven',
    'basket': 'basket', 'plate': 'plate', 'cookie_box': 'cookie box',
    'glazed_rim_porcelain_ramekin': 'ramekin', 'wooden_tray': 'wooden tray',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown', 'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'top', 'bottom',
        'middle', 'compartment', 'compartments', 'side', 'its', 'that', 'is', 'please',
        'then', 'table', 'from', 'with', 'which', 'part'}
DIRW = {'left': 'left', 'right': 'right', 'front': 'front', 'back': 'back',
        'behind': 'back', 'rear': 'back'}
LEVELS = ('top', 'middle', 'bottom')
VERBS = {'put', 'place', 'pick', 'move', 'set', 'stack', 'grab', 'take', 'lift',
         'open', 'close', 'shut', 'drop', 'insert'}
PICKV = {'pick', 'grab', 'take', 'lift'}
PREPS = ('into', 'onto', 'inside', 'in', 'on', 'to', 'at', 'behind', 'beside', 'next', 'near')
QUAL = ('between', 'next', 'from', 'near', 'beside', 'on', 'in', 'inside', 'at', 'under', 'by')


def V(*a):
    return np.array(a, dtype=float)


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return w


def _hit(w, D):
    return (w in D or (len(w) > 3 and w.endswith('s') and w[:-1] in D)
            or (len(w) > 4 and w.endswith('es') and w[:-2] in D))


# ------------------------------------------------------------ resolution
def resolve(api, words, pool, exclude=()):
    W = set(w for w in words if w not in STOP and w not in DIRW)
    if not W:
        return []
    best, cands = -1e9, []
    for b in pool:
        if b in exclude:
            continue
        D = _desc(b)
        m = sum(1 for w in W if _hit(w, D))
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, cands = s, [b]
        elif abs(s - best) < 1e-9:
            cands.append(b)
    d = next((DIRW[w] for w in words if w in DIRW), None)
    if len(cands) > 1 and d:
        key = {'left': lambda p: -p[1], 'right': lambda p: p[1],
               'front': lambda p: p[0], 'back': lambda p: -p[0]}[d]
        cands.sort(key=lambda c: key(P(api, c)))
    else:
        cands.sort()
    return cands


def drawer_region(api, names, bodies, words):
    level = next((w for w in words if w in LEVELS), None)

    def regs_of(o):
        out = []
        for n in names:
            if _is_region(n) and n.startswith(o + '_') and not n.endswith('_side'):
                suf = n[len(o) + 1:].split('_')
                if any(l in suf for l in LEVELS):
                    out.append((n, suf))
        return out

    owners = [o for o in resolve(api, words, bodies) if regs_of(o)]
    if not owners:
        owners = [b for b in bodies if regs_of(b)]
    for o in owners:
        rs = regs_of(o)
        if level:
            m = [n for n, suf in rs if level in suf]
            if m:
                return (m[0], o)
        else:
            rs.sort(key=lambda t: min(LEVELS.index(l) for l in LEVELS if l in t[1]))
            return (rs[0][0], o)
    return None


def anchor_sort(api, names, bodies, cands, qual):
    pts = []
    if 'drawer' in qual:
        r = drawer_region(api, names, bodies, qual)
        if r:
            pts.append(P(api, r[0]))
    else:
        part = []
        for w in qual + ['and']:
            if w == 'and':
                rs = resolve(api, part, bodies, exclude=cands)
                if rs:
                    pts.append(P(api, rs[0]))
                part = []
            else:
                part.append(w)
    if not pts:
        return cands
    a = np.mean(pts, axis=0)
    return sorted(cands, key=lambda c: np.linalg.norm(P(api, c)[:2] - a[:2]))


def choose(api, names, bodies, words, exclude=()):
    i = next((j for j in range(1, len(words)) if words[j] in QUAL), None)
    noun, qual = (words, []) if i is None else (words[:i], words[i + 1:])
    cands = resolve(api, noun, bodies, exclude) or resolve(api, words, bodies, exclude)
    if len(cands) > 1 and qual:
        cands = anchor_sort(api, names, bodies, cands, qual)
    return cands


def target_for(api, names, bodies, prep, tw, last_target):
    if not tw or tw in (['it'], ['them']):
        return last_target
    if prep in ('next', 'beside', 'near'):
        return None
    d, di = None, None
    if prep == 'behind':
        d = 'back'
    else:
        for i, w in enumerate(tw):
            if w in DIRW:
                d, di = DIRW[w], i
                break
    if d:
        after = tw[di + 1:di + 3] if di is not None else []
        comp = 'compartment' in tw or 'compartments' in tw
        structural = (prep in ('behind', 'to') or comp or after[:1] == ['of']
                      or after[:2] in (['side', 'of'], ['part', 'of']))
        if structural:
            if comp:
                rel = 'inside'
            elif (prep in ('in', 'into', 'inside') and 'side' not in after
                  and not (d == 'front' and after[:1] == ['of'])):
                rel = 'inside'
            else:
                rel = 'outside'
            refw = [w for w in tw if w not in DIRW and
                    w not in ('compartment', 'compartments', 'side', 'part', 'of')]
            rc = resolve(api, refw, bodies)
            if not rc:
                return None
            reg = api.relative_target(rc[0], d, rel)
            return (reg, rc[0]) if reg else None
    if 'drawer' in tw or 'drawers' in tw:
        return drawer_region(api, names, bodies, tw)
    oc = choose(api, names, bodies, tw)
    if not oc:
        return None
    owner = oc[0]
    regs = [n for n in names if _is_region(n) and n.startswith(owner + '_')]
    if not regs:
        return (owner, owner)
    sides = [r for r in regs if r.endswith('top_side')]
    if sides and ('top' in tw or prep in ('on', 'onto')):
        return (sides[0], owner)
    for key in ('contain', 'cook', 'heating', 'inside'):
        m = [r for r in regs if key in r[len(owner) + 1:].split('_')]
        if m:
            return (m[0], owner)
    T = set(tw)
    best, bs = owner, 0
    for r in regs:
        s = len(set(r[len(owner) + 1:].split('_')) & T)
        if s > bs:
            best, bs = r, s
    return (best, owner)


# ------------------------------------------------------------ parsing
def split_clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if (w == 'and' and (nxt in VERBS or nxt == 'then')) or w == 'then':
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return out


def split_items(ws):
    both = 'both' in ws
    has_the = any(ws[j] == 'and' and j + 1 < len(ws) and ws[j + 1] in ('the', 'a')
                  for j in range(len(ws)))
    parts = [[]]
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if w == 'and' and ((has_the and nxt in ('the', 'a')) or (both and not has_the)):
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def grasp_for(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


def plan(api, names, bodies, words):
    ops = []
    last_item, last_target, last_drawer = None, None, None
    clauses = split_clauses(words)
    for ci, c in enumerate(clauses):
        while c and c[-1] == 'and':
            c = c[:-1]
        if not c:
            continue
        v, rest = c[0], [w for w in c[1:] if w != 'up']
        if v not in VERBS:
            return None
        if v in ('open', 'close', 'shut'):
            act = 'open' if v == 'open' else 'close'
            if not rest or rest in (['it'], ['them']):
                tgt = last_drawer
            elif 'drawer' in rest or 'drawers' in rest:
                tgt = drawer_region(api, names, bodies, rest)
            else:
                return None          # microwave/other doors: old policy
            if tgt is None:
                return None
            ops.append(('drawer', tgt[0], act))
            last_target = last_drawer = tgt
            continue
        idx = next((i for i in range(1, len(rest)) if rest[i] in PREPS), None)
        is_last = ci == len(clauses) - 1
        if v in PICKV and not (is_last and idx is not None and rest[idx] in ('into', 'onto')):
            cands = choose(api, names, bodies, rest)
            if not cands:
                return None
            ops.append(('pick', cands[0]))
            last_item = cands[0]
            continue
        if idx is None:
            item_w, prep, tw = rest, None, []
        else:
            item_w, prep, tw = rest[:idx], rest[idx], rest[idx + 1:]
        tgt = target_for(api, names, bodies, prep, tw, last_target)
        if tgt is None:
            return None
        items = []
        parts = split_items(item_w)
        for part in parts:
            if part in (['it'], ['them']):
                got = [last_item] if last_item else []
            else:
                cands = choose(api, names, bodies, part, exclude=(tgt[1],))
                got = cands[:2] if ('both' in item_w and len(parts) == 1) else cands[:1]
            for it in got:
                if it and it not in items:
                    items.append(it)
        if not items:
            return None
        if ops and ops[-1][0] == 'pick' and ops[-1][1] in items:
            ops.pop()
        for it in items:
            ops.append(('place', it, tgt[0], grasp_for(it)))
        last_item, last_target = items[-1], tgt
    return ops


# ------------------------------------------------------------ execution
def placed_ok(api, item, region):
    ip, tp = P(api, item), P(api, region)
    tol = 0.08 if ('contain' in region or 'basket' in region or 'region' in region) else 0.07
    if 'caddy' in region:
        tol = 0.05
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.08


def recover(api):
    try:
        api.grip(False)
        e = np.array(api.eef(), dtype=float)
        api.move(e + V(0, 0, 0.12), steps=15)
    except Exception:
        pass


def pick_only(api, item):
    p = P(api, item)
    api.grip(False)
    e = np.array(api.eef(), dtype=float)
    api.move(V(e[0], e[1], max(e[2], p[2] + 0.12)), steps=12)
    api.move(p + V(0, 0, 0.12), steps=25)
    api.move(p, steps=20)
    api.grip(True)
    api.move(p + V(0, 0, 0.15), steps=25)


def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    words = _words(api.instruction)
    try:
        ops = plan(api, names, bodies, words)
    except Exception:
        ops = None
    if not ops:
        api.fallback()
        return
    for op in ops:
        try:
            if op[0] == 'drawer':
                api.drawer(op[1], op[2])
            elif op[0] == 'pick':
                pick_only(api, op[1])
            elif op[0] == 'place':
                _, item, region, grasp = op
                for _attempt in range(2):
                    try:
                        api.place_with(item, region, grasp)
                    except Exception:
                        recover(api)
                    if placed_ok(api, item, region):
                        break
                    recover(api)
        except Exception:
            recover(api)
