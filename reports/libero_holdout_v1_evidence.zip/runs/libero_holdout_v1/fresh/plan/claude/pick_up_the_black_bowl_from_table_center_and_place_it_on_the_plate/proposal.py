import math
import numpy as np

ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl', 'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup', 'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup', 'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop', 'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy',
    'black_book': 'black book', 'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle', 'butter': 'butter box',
    'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet', 'wooden_cabinet': 'wooden cabinet',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack', 'microwave': 'microwave oven',
    'basket': 'basket', 'plate': 'plate', 'cookies': 'cookie box',
    'glazed_rim_porcelain_ramekin': 'ramekin',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown',
          'wooden', 'pink', 'orange'}
DIRS = ('left', 'right', 'front', 'back')
VERBS = {'put', 'place', 'turn', 'switch', 'close', 'shut', 'open', 'pick',
         'push', 'pull', 'move', 'stack', 'lift', 'grab', 'take', 'set'}
PICKV = {'pick', 'grab', 'lift', 'take'}
PLACEV = {'put', 'place', 'move', 'stack', 'set'}
DRAWV = {'open', 'close', 'shut'}
SPLITW = {'into', 'onto', 'inside', 'in', 'on', 'next', 'between', 'behind'}
LSTOP = {'the', 'a', 'an', 'of', 'from', 'at', 'on', 'in', 'into', 'onto', 'inside',
         'it', 'is', 'up', 'located', 'placed', 'sitting', 'and', 'its', 'that',
         'which', 'please', 'both', 'them'}
ISTOP = LSTOP | {'next', 'to', 'between', 'behind', 'left', 'right', 'front', 'back',
                 'top', 'bottom', 'middle', 'compartment', 'side', 'table', 'center'}
GEN = {'main', 'table', 'region', 'side', 'contain', 'kitchen', 'living', 'room',
       'study', 'floor'}


def V(*a):
    return np.array(a, dtype=float)


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def E(api):
    return np.array(api.eef(), dtype=float)


def stem(w):
    if len(w) > 3 and w.endswith('s') and not w.endswith('ss'):
        return w[:-1]
    return w


def words_of(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def is_region(n):
    return (n.endswith('_region') or n.endswith('_side')
            or not any(t.isdigit() for t in n.split('_')))


def base(n):
    out = []
    for t in n.split('_'):
        if t.isdigit():
            break
        out.append(t)
    return '_'.join(out)


def toks(n):
    return {stem(t) for t in n.lower().split('_') if t and not t.isdigit()}


def desc(n):
    D = toks(n)
    if not is_region(n):
        b = base(n)
        if b in ALIAS:
            D |= {stem(w) for w in ALIAS[b].split()}
    return D


def dir_sort(api, cands, d):
    key = {'left': lambda p: -p[1], 'right': lambda p: p[1],
           'front': lambda p: p[0], 'back': lambda p: -p[0]}[d]
    return sorted(cands, key=lambda c: key(P(api, c)))


def loc_rank(api, W, pool, drawer=False):
    scored = []
    for n in pool:
        T, D = toks(n), desc(n)
        m = len(D & W)
        if not m:
            continue
        s = 3 * m - len(T - W - GEN) - len((D & COLORS) - W)
        if 'side' in T:
            s += -5 if drawer else (1 if 'top' in W else -1)
        if drawer and n.endswith('_region') and T & {'top', 'middle', 'bottom'}:
            s += 1
        if not is_region(n):
            s += 0.5
        scored.append((s, n))
    if not scored:
        return None
    top = max(s for s, _ in scored)
    ties = sorted(n for s, n in scored if abs(s - top) < 1e-9)
    if len(ties) > 1:
        for d in DIRS:
            if d in W:
                ties = dir_sort(api, ties, d)
                break
    return ties[0]


def nearest_to(api, loc, cands):
    try:
        r = api.nearest(loc, list(cands))
        if r in cands:
            return r
    except Exception:
        pass
    lp = P(api, loc)
    return min(cands, key=lambda c: np.linalg.norm(P(api, c) - lp))


def resolve_item(api, names, bodies, phrase, exclude=()):
    ws = [stem(w) for w in phrase]
    W = {w for w in ws if w not in ISTOP}
    best, cands = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = desc(b)
        m = len(W & D)
        if not m:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, cands = s, [b]
        elif abs(s - best) < 1e-9:
            cands.append(b)
    if not cands:
        return None
    if len(cands) == 1:
        return cands[0]
    U = set()
    for c in cands:
        U |= desc(c)
    extra = [w for w in ws if w not in LSTOP and w not in U and w not in COLORS]
    dirs = [w for w in extra if w in DIRS or w == 'behind']
    rest = [w for w in extra if w not in DIRS and w != 'behind']
    if rest:
        pool = [n for n in names if n not in cands and n not in exclude]
        loc = loc_rank(api, set(extra), pool)
        if loc:
            return nearest_to(api, loc, cands)
    if dirs:
        d = 'back' if dirs[0] == 'behind' else dirs[0]
        return dir_sort(api, cands, d)[0]
    return sorted(cands)[0]


def drawer_pool(names):
    return [n for n in names if n.endswith('_region') and toks(n) & {'top', 'middle', 'bottom'}]


def resolve_drawer(api, names, rest):
    ws = [stem(w) for w in rest]
    W = {w for w in ws if w not in LSTOP}
    pool = drawer_pool(names)
    if not pool:
        return None
    r = loc_rank(api, W, pool, drawer=True)
    if r is None and 'drawer' in W:
        tops = [n for n in pool if 'top' in toks(n)]
        r = sorted(tops or pool)[0]
    return r


def resolve_target(api, names, bodies, tw, items, last_t):
    ws = [stem(w) for w in tw]
    if not ws or ws in (['it'], ['them']):
        return last_t
    for j, w in enumerate(ws):
        if w in DIRS or w == 'behind':
            d = 'back' if w == 'behind' else w
            nxt = ws[j + 1] if j + 1 < len(ws) else ''
            rel, ref_w = None, None
            if nxt == 'compartment':
                rel = 'inside'
                ref_w = ws[ws.index('of', j) + 1:] if 'of' in ws[j:] else ws[j + 2:]
            elif nxt == 'of' or w == 'behind':
                rel = 'outside'
                ref_w = ws[j + 2:] if nxt == 'of' else ws[j + 1:]
            if rel and ref_w:
                ref = resolve_item(api, names, bodies, ref_w, exclude=items)
                if ref:
                    try:
                        r = api.relative_target(ref, d, rel)
                        if r:
                            return r
                    except Exception:
                        pass
            break
    W = {w for w in ws if w not in LSTOP}
    pool = [n for n in names if n not in items
            and not any(n.startswith(i + '_') for i in items)]
    return loc_rank(api, W, pool, drawer='drawer' in ws)


def split_clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if (w == 'and' and (nxt in VERBS or nxt == 'then')) or w == 'then':
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return out


def split_items(ws):
    both = 'both' in ws
    has_the = any(ws[j] == 'and' and j + 1 < len(ws) and ws[j + 1] in ('the', 'a')
                  for j in range(len(ws)))
    parts = [[]]
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if w == 'and' and ((has_the and nxt in ('the', 'a')) or (both and not has_the)):
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def make_plan(api):
    names = list(api.names())
    bodies = [n for n in names if not is_region(n)]
    words = words_of(api.instruction)
    dpool = set(drawer_pool(names))
    ops, pending, last_t, last_drawer = [], None, None, None
    for c in split_clauses(words):
        while c and c[-1] in ('and', 'then'):
            c = c[:-1]
        if not c:
            continue
        v = c[0]
        rest = [w for w in c[1:] if w not in ('up', 'please')]
        if v in DRAWV:
            mode = 'open' if v == 'open' else 'close'
            if not rest or rest in (['it'], ['them']):
                r = last_drawer
            else:
                r = resolve_drawer(api, names, rest)
            if r is None:
                return None
            ops.append(('drawer', r, mode))
            last_drawer, last_t = r, r
            continue
        if v in PICKV:
            it = resolve_item(api, names, bodies, rest)
            if it is None:
                return None
            ops.append(('pick', it))
            pending = it
            continue
        if v in PLACEV:
            idx = None
            for i in range(len(rest) - 1, 0, -1):
                if rest[i] in SPLITW:
                    idx = i
                    break
            if idx is None:
                return None
            if rest[idx] in ('next', 'between', 'behind'):
                item_w, tw = rest[:idx], rest[idx:]
            else:
                item_w, tw = rest[:idx], rest[idx + 1:]
            items = []
            for part in (split_items(item_w) or [['it']]):
                if part in (['it'], ['them']):
                    it = pending
                else:
                    it = resolve_item(api, names, bodies, part)
                if it and it not in items:
                    items.append(it)
            if not items:
                return None
            tgt = resolve_target(api, names, bodies, tw, items, last_t)
            if tgt is None:
                return None
            if ops and ops[-1][0] == 'pick' and ops[-1][1] in items:
                ops.pop()
            for it in items:
                ops.append(('place', it, tgt))
            pending, last_t = items[-1], tgt
            if tgt in dpool:
                last_drawer = tgt
            continue
        return None          # turn/switch/push/... -> previous policy
    return ops


def grasp_for(item):
    b = base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


def placed_ok(api, item, tgt):
    ip, tp = P(api, item), P(api, tgt)
    tol = 0.05 if 'caddy' in tgt else (0.10 if is_region(tgt) else 0.09)
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.08


def recover(api):
    try:
        api.grip(False)
        api.move(E(api) + V(0, 0, 0.10), steps=12)
    except Exception:
        pass


def do_place(api, item, tgt):
    g = grasp_for(item)
    for _ in range(2):
        try:
            api.place_with(item, tgt, g)
        except Exception:
            try:
                api.arrange([(item, tgt)])
            except Exception:
                pass
        if placed_ok(api, item, tgt):
            return True
        recover(api)
    return False


def pick_only(api, item):
    p = P(api, item)
    api.grip(False)
    e = E(api)
    api.move(V(e[0], e[1], max(e[2], p[2] + 0.12)), steps=12)
    api.move(p + V(0, 0, 0.10), steps=25)
    api.move(p, steps=20)
    api.grip(True)
    api.move(p + V(0, 0, 0.15), steps=25)


def run(api):
    try:
        plan = make_plan(api)
    except Exception:
        plan = None
    if not plan:
        api.fallback()
        return
    for op in plan:
        try:
            if op[0] == 'drawer':
                api.drawer(op[1], op[2])
            elif op[0] == 'place':
                do_place(api, op[1], op[2])
            elif op[0] == 'pick':
                pick_only(api, op[1])
        except Exception:
            recover(api)
