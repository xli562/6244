def run(api):
    names = list(api.names())
    instruction = api.instruction.lower()
    if "orange juice" in instruction and "basket" in instruction:
        item = next((n for n in names if n.startswith("orange_juice_")
                     and n.rsplit("_", 1)[-1].isdigit()), None)
        target = next((n for n in names if n.startswith("basket_")
                       and n.endswith("_contain_region")), None)
        if item and target:
            api.place_with(item, target, "standard")
            return
    api.fallback()
