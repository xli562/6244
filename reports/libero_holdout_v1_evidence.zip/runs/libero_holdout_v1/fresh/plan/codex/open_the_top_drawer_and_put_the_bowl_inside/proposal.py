def run(api):
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())

    if "drawer" not in text:
        return api.fallback()

    level = next((s for s in ("top", "middle", "bottom") if s in text), None)
    regions = [
        n for n in names
        if ("cabinet" in n or "drawer" in n)
        and level is not None
        and n.endswith("_" + level + "_region")
    ]
    if len(regions) != 1:
        return api.fallback()
    drawer = regions[0]

    items = []
    for name in names:
        if not name.rsplit("_", 1)[-1].isdigit():
            continue
        base = name.rsplit("_", 1)[0].replace("_", " ")
        if "cabinet" in base or "drawer" in base:
            continue
        if base in text or base.split()[-1] in text.split():
            items.append(name)

    placing = any(word in text.split() for word in ("put", "place", "insert"))
    if placing and not items:
        return api.fallback()

    # Opening precedes insertion; closing follows it when requested.
    if "open" in text.split():
        api.drawer(drawer, "open")

    if placing:
        for item in items:
            grasp = (
                "rim" if "bowl" in item else
                "thin_edge" if "book" in item else
                "standard"
            )
            api.place_with(item, drawer, grasp)

    if "close" in text.split() or "shut" in text.split():
        api.drawer(drawer, "close")
