def run(api):
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())

    if "wine bottle" in text and "rack" in text:
        bottle = next(
            (n for n in names
             if n.startswith("wine_bottle_") and n.rsplit("_", 1)[-1].isdigit()),
            None,
        )
        rack = next(
            (n for n in names
             if n.startswith("wine_rack_") and n.rsplit("_", 1)[-1].isdigit()),
            None,
        )
        if bottle and rack and rack + "_top_region" in names:
            # Standard grasp for the solid bottle; place on the rack's top.
            api.place_with(bottle, rack + "_top_region", "standard")
            return

    api.fallback()
