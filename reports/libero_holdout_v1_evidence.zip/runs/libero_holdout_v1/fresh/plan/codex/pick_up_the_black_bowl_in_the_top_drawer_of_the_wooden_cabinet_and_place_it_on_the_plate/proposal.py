def run(api):
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())

    cabinets = [
        n for n in names
        if "cabinet" in n and n.rsplit("_", 1)[-1].isdigit()
    ]
    bowls = [n for n in names if n.startswith("akita_black_bowl_")
             and n.rsplit("_", 1)[-1].isdigit()]
    plates = [n for n in names if n.startswith("plate_")
              and n.rsplit("_", 1)[-1].isdigit()]
    level = next((s for s in ("top", "middle", "bottom")
                  if s + " layer" in text), None)

    if level and "bowl" in text and "plate" in text:
        cabinets = [n for n in cabinets
                    if "wooden" not in text or "wooden" in n]
        regions = [c + "_" + level + "_region" for c in cabinets
                   if c + "_" + level + "_region" in names]
        if len(regions) == 1 and bowls and len(plates) == 1:
            # Resolve the source by its observed cabinet layer.
            bowl = api.nearest(regions[0], bowls)
            # Pinch the open bowl's wall, then place it on the plate.
            api.place_with(bowl, plates[0], "rim")
            return

    api.fallback()
