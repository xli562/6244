def run(api):
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [n for n in names
              if n.rsplit("_", 1)[-1].isdigit() and "region" not in n]

    synonyms = {
        "akita_black_bowl": ["black bowl", "bowl"],
        "porcelain_mug": ["white mug"],
        "white_yellow_mug": ["yellow and white mug", "yellow mug"],
        "chefmate_8_frypan": ["frying pan", "pan"],
        "red_coffee_mug": ["red mug"],
    }

    def mentions(name):
        base = name.rsplit("_", 1)[0]
        aliases = [base.replace("_", " ")] + synonyms.get(base, [])
        hits = [(text.find(a), -len(a)) for a in aliases if a in text]
        return min(hits) if hits else None

    selected = [(mentions(n), n) for n in bodies if mentions(n) is not None]
    selected.sort()
    ordered = [n for _, n in selected]

    def place(item, target):
        grasp = ("rim" if "bowl" in item else
                 "thin_edge" if "book" in item else "standard")
        api.place_with(item, target, grasp)

    if "drawer" in text:
        levels = [s for s in ("top", "middle", "bottom") if s in text]
        regions = [n for n in names
                   if levels and levels[0] + "_region" in n
                   and ("cabinet" in n or "drawer" in n)]
        if len(levels) != 1 or len(regions) != 1:
            return api.fallback()
        region = regions[0]
        items = [n for n in ordered if "cabinet" not in n and "drawer" not in n]
        opening = text.find("open")
        closing = text.find("close")
        if closing >= 0 and (opening < 0 or closing < opening) and items:
            return api.fallback()
        if opening >= 0:
            api.drawer(region, "open")
        for item in items:
            place(item, region)
        if closing >= 0:
            api.drawer(region, "close")
        return

    # Leave switches and complex action sequences to the existing policy.
    if "turn " in text or len(ordered) < 2:
        return api.fallback()
    if any(word in text for word in (" then ", " and place ", " and put ")):
        return api.fallback()

    target_body = ordered[-1]
    target = target_body
    directions = [d for d in ("left", "right", "front", "back")
                  if d in text.split()]
    outside = any(p in text for p in
                  ("next to", "to the left of", "to the right of",
                   "in front of", "behind"))
    if "behind" in text and not directions:
        directions = ["back"]

    if directions and ("caddy" in target_body or outside):
        if len(directions) != 1:
            return api.fallback()
        target = api.relative_target(
            target_body, directions[0], "outside" if outside else "inside"
        )
    elif directions:
        return api.fallback()
    elif "cabinet" in target_body and ("on top" in text or "on the" in text):
        target = target_body + "_top_side"
    elif " in " in text or " into " in text:
        region = target_body + "_contain_region"
        if region in names:
            target = region

    if target not in names:
        return api.fallback()
    for item in ordered[:-1]:
        # Tomato sauce uses the standard grasp; the basket's containment
        # region is the placement target.
        place(item, target)
