def run(api):
    import numpy as np

    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [n for n in names
              if n.rsplit("_", 1)[-1].isdigit() and "region" not in n]

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "cookies": ["cookies box", "cookie box"],
        "porcelain mug": ["white mug"],
        "white yellow mug": ["yellow and white mug", "yellow mug"],
        "red coffee mug": ["red mug"],
        "chefmate 8 frypan": ["frying pan", "pan"],
        "black book": ["book"],
        "desk caddy": ["caddy"],
        "flat stove": ["stove"],
        "wooden cabinet": ["cabinet"],
        "white cabinet": ["cabinet"],
    }

    def candidates(phrase):
        scored = []
        for name in bodies:
            base = name.rsplit("_", 1)[0].replace("_", " ")
            aliases = [base] + synonyms.get(base, [])
            score = max([len(a) for a in aliases
                         if " " + a + " " in " " + phrase + " "] or [0])
            if score:
                scored.append((score, name))
        best = max([s for s, n in scored] or [0])
        return [n for s, n in scored if s == best]

    def resolve(phrase):
        # Source qualifiers identify which instance to pick.
        for prep in (" on top of ", " on ", " in ", " inside "):
            if prep in phrase:
                subject, reference = phrase.split(prep, 1)
                choices = candidates(subject)
                anchors = candidates(reference)
                if choices and len(anchors) == 1:
                    return api.nearest(anchors[0], choices)
        choices = candidates(phrase)
        if len(choices) == 1:
            return choices[0]
        if choices:
            for side in ("left", "right", "front", "back"):
                if side in phrase.split():
                    markers = [n for n in names
                               if side in n.split("_")
                               and any(c.rsplit("_", 1)[0] in n
                                       for c in choices)]
                    if len(markers) == 1:
                        return api.nearest(markers[0], choices)
        return None

    def destination(phrase):
        if "drawer" in phrase:
            level = next((s for s in ("top", "middle", "bottom")
                          if s in phrase.split()), None)
            regions = [n for n in names if level
                       and n.endswith("_" + level + "_region")
                       and "cabinet" in n]
            return regions[0] if len(regions) == 1 else None

        reference = resolve(phrase)
        if reference is None:
            return None
        for side in ("left", "right", "front", "back"):
            if side in phrase.split() and (
                "caddy" in reference or "cabinet" in reference
                or "next to" in phrase or "side of" in phrase
            ):
                relation = "inside" if (
                    phrase.startswith(("in ", "into ", "inside "))
                    and "next to" not in phrase
                ) else "outside"
                return api.relative_target(reference, side, relation)

        suffix = "_contain_region" if phrase.startswith(
            ("in ", "into ", "inside ")
        ) else "_top_side"
        if "stove" in reference:
            suffix = "_cook_region"
        return reference + suffix if reference + suffix in names else reference

    # Build the complete ordered plan before moving anything.
    clauses = text.replace(", then ", " then ").replace(
        " and then ", " then "
    ).split(" then ")
    plan = []
    for clause in clauses:
        clause = clause.strip(" ,.")
        if clause.startswith(("open ", "close ", "shut ")):
            target = destination(clause)
            if target is None or " and " in clause:
                return api.fallback()
            plan.append(("drawer", target,
                         "open" if clause.startswith("open ") else "close"))
            continue

        clause = clause.replace(" and place ", " ").replace(" and put ", " ")
        placement = None
        for prep in (" on top of ", " into ", " inside ", " on ", " in "):
            if prep in clause:
                source, target_text = clause.rsplit(prep, 1)
                item = resolve(source)
                target = destination(prep.strip() + " " + target_text)
                if item and target and item != target:
                    placement = (item, target)
                    break
        if placement is None:
            return api.fallback()
        item, target = placement
        grasp = ("rim" if "bowl" in item else
                 "thin_edge" if "book" in item else "standard")
        plan.append(("place", (item, target), grasp))

    for action, target, mode in plan:
        if action == "drawer":
            api.drawer(target, mode)
        else:
            item, region = target
            api.place_with(item, region, mode)
