def run(api):
    api.place_with("cream_cheese_1", "basket_1_contain_region", "standard")
