def run(api):
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())

    if ("bowl" in text and "stove" in text
            and text.rfind("plate") > text.rfind("stove")):
        bowls = [n for n in names if n.startswith("akita_black_bowl_")
                 and n.rsplit("_", 1)[-1].isdigit()]
        plates = [n for n in names if n.startswith("plate_")
                  and n.rsplit("_", 1)[-1].isdigit()]
        stove = next((n for n in names if n.endswith("_cook_region")), None)
        if bowls and plates and stove:
            # Resolve the source bowl by its observed location on the stove.
            bowl = api.nearest(stove, bowls)
            marker = next((n for n in names
                           if n.endswith("_plate_region")), None)
            plate = api.nearest(marker or bowl, plates)
            # Pinch the open bowl's wall, then place it on the plate.
            api.place_with(bowl, plate, "rim")
            return

    api.fallback()
