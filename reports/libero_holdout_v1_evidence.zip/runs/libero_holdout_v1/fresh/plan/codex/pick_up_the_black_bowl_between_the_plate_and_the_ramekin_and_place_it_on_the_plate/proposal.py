def run(api):
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bowls = [n for n in names if n.startswith("akita_black_bowl_")
             and n.rsplit("_", 1)[-1].isdigit()]
    plates = [n for n in names if n.startswith("plate_")
              and n.rsplit("_", 1)[-1].isdigit()]
    between = next(
        (n for n in names if "between_plate_ramekin" in n), None
    )

    if (bowls and plates and between
            and "bowl" in text and "between" in text
            and "ramekin" in text
            and ("on the plate" in text or "onto the plate" in text)):
        # 1. Resolve the bowl using the perceived between region.
        bowl = api.nearest(between, bowls)
        plate_region = next(
            (n for n in names if n.endswith("_plate_region")), between
        )
        plate = api.nearest(plate_region, plates)

        # 2. Pinch the open bowl's rim, then place it on the plate.
        api.place_with(bowl, plate, "rim")
        return

    api.fallback()
