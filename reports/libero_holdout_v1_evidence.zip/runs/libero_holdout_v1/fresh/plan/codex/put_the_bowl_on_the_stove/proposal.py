def run(api):
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [n for n in names if n.rsplit("_", 1)[-1].isdigit()
              and "region" not in n]

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "flat stove": ["stove"],
        "chefmate 8 frypan": ["frying pan", "pan"],
        "porcelain mug": ["white mug", "mug"],
        "white yellow mug": ["yellow and white mug", "yellow mug"],
        "red coffee mug": ["red mug"],
        "wooden cabinet": ["cabinet"],
        "white cabinet": ["cabinet"],
        "desk caddy": ["caddy"],
    }

    def mentions(s):
        hits = []
        for body in bodies:
            base = body.rsplit("_", 1)[0].replace("_", " ")
            aliases = [base] + synonyms.get(base, [])
            aliases += [base.split()[-1]]
            for alias in aliases:
                start = 0
                while True:
                    i = s.find(alias, start)
                    if i < 0:
                        break
                    end = i + len(alias)
                    if (i == 0 or not s[i - 1].isalnum()) and (
                        end == len(s) or not s[end].isalnum()
                    ):
                        hits.append((i, end, body))
                    start = end
        # Prefer specific names over overlapping generic descriptions.
        hits.sort(key=lambda h: (-(h[1] - h[0]), h[0]))
        selected = []
        for hit in hits:
            if not any(hit[0] < h[1] and h[0] < hit[1] for h in selected):
                selected.append(hit)
        return sorted(selected)

    def region(body, suffix):
        return next((n for n in names if n == body + "_" + suffix), None)

    def grasp(item):
        if "bowl" in item:
            return "rim"
        if "book" in item:
            return "thin_edge"
        return "standard"

    # Build the complete ordered plan before moving.
    clauses = text
    for separator in (", then ", " and then ", "; ", " then "):
        clauses = clauses.replace(separator, "|")
    for verb in ("put", "place", "open", "close", "turn"):
        clauses = clauses.replace(" and " + verb + " ", "|" + verb + " ")

    plan = []
    previous_target = None
    previous_item = None
    for clause in clauses.split("|"):
        hits = mentions(clause)
        drawer = None
        if "drawer" in clause:
            level = next((x for x in ("bottom", "middle", "top")
                          if x in clause), None)
            cabinet = next((h[2] for h in hits if "cabinet" in h[2]), None)
            cabinet = cabinet or next((b for b in bodies if "cabinet" in b), None)
            if cabinet and level:
                drawer = region(cabinet, level + "_region")
            elif previous_target and "region" in previous_target:
                drawer = previous_target
            if drawer is None:
                return api.fallback()

        if clause.startswith(("open ", "close ")):
            if drawer is None:
                return api.fallback()
            plan.append(("drawer", drawer,
                         "open" if clause.startswith("open ") else "close"))
            previous_target = drawer
            continue

        if not clause.startswith(("put ", "place ", "pick ")):
            return api.fallback()

        target_body = hits[-1][2] if hits else None
        target = drawer
        if target is None and ("on it" in clause or "into it" in clause
                               or "in it" in clause):
            target = previous_target
            target_body = None
        if target is None and target_body:
            direction = next((d for d in ("left", "right", "front", "back")
                              if d in clause.split()), None)
            if direction and any(w in target_body for w in ("caddy", "cabinet")):
                outside = any(w in clause for w in
                              ("next to", "beside", "in front of", "behind",
                               "to the left of", "to the right of"))
                target = api.relative_target(
                    target_body, direction, "outside" if outside else "inside"
                )
            elif "stove" in target_body:
                target = region(target_body, "cook_region") or target_body
            elif "cabinet" in target_body and "top" in clause:
                target = region(target_body, "top_side")
            elif " in " in clause or " into " in clause:
                target = region(target_body, "contain_region") or target_body
            else:
                target = target_body

        items = []
        for _, _, body in hits:
            if body != target_body and "cabinet" not in body and body not in items:
                items.append(body)
        if not items and previous_item and ("put it" in clause or "place it" in clause):
            items = [previous_item]
        if not target or not items:
            return api.fallback()
        for item in items:
            plan.append(("place", item, target))
            previous_item = item
        previous_target = target

    for action, first, second in plan:
        if action == "drawer":
            api.drawer(first, second)
        else:
            # Bowl → stove: pinch the bowl wall using the rim grasp.
            api.place_with(first, second, grasp(first))
