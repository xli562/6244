def run(api):
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [
        n for n in names
        if n.rsplit("_", 1)[-1].isdigit() and "region" not in n
    ]

    aliases = {
        "akita_black_bowl": ["black bowl", "bowl"],
        "porcelain_mug": ["white mug"],
        "white_yellow_mug": ["yellow and white mug", "white and yellow mug"],
        "red_coffee_mug": ["red mug"],
        "chefmate_8_frypan": ["frying pan", "pan"],
        "desk_caddy": ["caddy"],
        "white_cabinet": ["cabinet"],
        "flat_stove": ["stove"],
    }

    def mentions(name):
        base = name.rsplit("_", 1)[0]
        phrases = [base.replace("_", " ")] + aliases.get(base, [])
        return [
            (text.find(p), len(p))
            for p in phrases if p in text
        ]

    matched = [n for n in bodies if mentions(n)]
    matched.sort(key=lambda n: min(p for p, _ in mentions(n)))

    # Delegate compound or unsupported manipulations to the previous policy.
    if any(p in text for p in ("turn on", "turn off", "stack")):
        return api.fallback()

    if len(matched) != 2:
        return api.fallback()

    item, reference = matched
    target = reference

    if "drawer" in text:
        level = next(
            (s for s in ("top", "middle", "bottom") if s in text), None
        )
        target = next(
            (n for n in names
             if level and n.startswith(reference + "_")
             and level in n and "region" in n),
            None,
        )
        if target is None:
            return api.fallback()

        # Open before insertion only when requested.
        if "open" in text:
            api.drawer(target, "open")
    else:
        direction = next(
            (s for s in ("left", "right", "front", "back")
             if s in text.split()), None
        )
        inside = any(p in text for p in (" in ", " into ", " inside "))
        outside = any(
            p in text for p in ("next to", "beside", "to the left of",
                               "to the right of", "in front of", "behind")
        )
        if direction and (inside or outside):
            target = api.relative_target(
                reference, direction, "outside" if outside else "inside"
            )
        elif inside:
            target = next(
                (n for n in names
                 if n == reference + "_contain_region"), reference
            )
        elif reference + "_top_side" in names:
            target = reference + "_top_side"

    # Chocolate pudding uses standard; bowls use rim; books use thin_edge.
    grasp = (
        "rim" if "bowl" in item else
        "thin_edge" if "book" in item else
        "standard"
    )
    api.place_with(item, target, grasp)

    if "drawer" in text and "close" in text:
        api.drawer(target, "close")
