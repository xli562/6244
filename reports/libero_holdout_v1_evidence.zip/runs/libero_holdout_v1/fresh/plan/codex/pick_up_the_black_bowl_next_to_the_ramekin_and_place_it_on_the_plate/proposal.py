def run(api):
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())

    if all(word in text for word in ("bowl", "next to", "ramekin", "plate")):
        bowls = [
            n for n in names
            if n.startswith("akita_black_bowl_")
            and n.rsplit("_", 1)[-1].isdigit()
        ]
        plates = [
            n for n in names
            if n.startswith("plate_") and n.rsplit("_", 1)[-1].isdigit()
        ]
        marker = next(
            (n for n in names if n.endswith("_next_to_ramekin_region")),
            None,
        )
        if bowls and len(plates) == 1 and marker:
            # 1. Resolve the bowl using the requested source location.
            bowl = api.nearest(marker, bowls)
            # 2. Pinch the open bowl's rim and place it on the plate.
            api.place_with(bowl, plates[0], "rim")
            return

    # Preserve the previous policy for other runtime tasks.
    api.fallback()
