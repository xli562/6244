def run(api):
    text = " " + " ".join(api.instruction.lower().replace("-", " ").split()) + " "
    names = list(api.names())
    bodies = [n for n in names
              if n.rsplit("_", 1)[-1].isdigit() and "region" not in n]

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        extra = {
            "akita black bowl": ["black bowl", "bowl"],
            "porcelain mug": ["white mug"],
            "white yellow mug": ["yellow and white mug", "yellow mug"],
            "red coffee mug": ["red mug"],
            "chefmate 8 frypan": ["frying pan", "pan"],
            "flat stove": ["stove"],
            "white cabinet": ["cabinet"],
            "desk caddy": ["caddy"],
        }
        return [base] + extra.get(base, [])

    mentions = []
    for name in bodies:
        hits = [(text.find(" " + a + " "), len(a))
                for a in aliases(name) if " " + a + " " in text]
        if hits:
            index, length = max(hits, key=lambda h: h[1])
            mentions.append((index, name))
    mentions.sort()

    # Leave unsupported actions and complex sequences to the previous policy.
    if any(s in text for s in ("turn on", "turn off", "stack", " then put",
                                " then place", " and put", " and place")):
        return api.fallback()

    if not mentions:
        return api.fallback()

    target_body = mentions[-1][1]
    items = [name for _, name in mentions[:-1]]
    target = target_body
    drawer = "drawer" in text and "cabinet" in target_body

    if drawer:
        level = next((s for s in ("top", "middle", "bottom")
                      if " " + s + " " in text), None)
        target = target_body + "_" + level + "_region" if level else None
        if target not in names:
            return api.fallback()
    else:
        direction = next((s for s in ("left", "right", "front", "back")
                          if " " + s + " " in text), None)
        inside = any(s in text for s in (" in ", " into ", " inside "))
        if direction:
            target = api.relative_target(
                target_body, direction, "inside" if inside else "outside"
            )
            if not target:
                return api.fallback()
        else:
            suffix = ("_contain_region" if inside else
                      "_cook_region" if "stove" in target_body else "_top_side")
            if target_body + suffix in names:
                target = target_body + suffix

    if not items and not drawer:
        return api.fallback()

    # Open before insertion; close only after the requested placements.
    if drawer and (" open " in text or items):
        api.drawer(target, "open")

    for item in items:
        # Butter and other solid objects: standard.
        # Open bowls: rim. Books: thin_edge.
        grasp = ("rim" if "bowl" in item else
                 "thin_edge" if "book" in item else "standard")
        if api.place_with(item, target, grasp) is False:
            return

    if drawer and (" close " in text or " shut " in text):
        api.drawer(target, "close")
