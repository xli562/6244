def run(api):
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())

    bowls = [n for n in names if n.startswith("akita_black_bowl_")
             and n.rsplit("_", 1)[-1].isdigit()]
    plates = [n for n in names if n.startswith("plate_")
              and n.rsplit("_", 1)[-1].isdigit()]
    marker = "main_table_next_to_plate_region"

    if (bowls and plates and marker in names
            and "bowl next to the plate" in text
            and ("on the plate" in text or "onto the plate" in text)):
        bowl = api.nearest(marker, bowls)
        plate_marker = "main_table_plate_region"
        plate = api.nearest(
            plate_marker if plate_marker in names else marker, plates
        )
        api.place_with(bowl, plate, "rim")
        return

    api.fallback()
