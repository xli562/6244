def run(api):
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [
        n for n in names
        if n.rsplit("_", 1)[-1].isdigit() and "region" not in n
    ]

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        extra = {
            "akita black bowl": ["black bowl", "bowl"],
            "porcelain mug": ["white mug"],
            "white yellow mug": ["yellow and white mug", "yellow mug"],
            "red coffee mug": ["red mug"],
            "chefmate 8 frypan": ["frying pan", "pan"],
            "flat stove": ["stove"],
            "wooden cabinet": ["cabinet"],
            "white cabinet": ["cabinet"],
            "desk caddy": ["caddy"],
        }
        return [base] + extra.get(base, [])

    def matches(words):
        padded = " " + words + " "
        scored = [
            (max([len(a) for a in aliases(n)
                  if " " + a + " " in padded] or [0]), n)
            for n in bodies
        ]
        best = max([s for s, _ in scored] or [0])
        return [n for s, n in scored if s == best and s > 0]

    def region(body, suffix):
        return next((n for n in names if n == body + "_" + suffix), None)

    def destination(words):
        candidates = matches(words)
        if len(candidates) != 1:
            return None
        body = candidates[0]
        if "drawer" in words:
            level = next((s for s in ("top", "middle", "bottom")
                          if s in words), None)
            return region(body, level + "_region") if level else None

        direction = next((s for s in ("left", "right", "front", "back")
                          if s in words.split()), None)
        if direction:
            inside = any(s in words for s in ("inside", " into ", " in "))
            return api.relative_target(
                body, direction, "inside" if inside else "outside"
            )
        if "cabinet" in body and " on " in " " + words:
            return region(body, "top_side")
        if any(s in " " + words for s in (" in ", " into ", "inside")):
            return region(body, "contain_region") or body
        return region(body, "cook_region") or body

    # Plan first, so unsupported instructions can use the previous policy.
    tokens = text.split()
    verbs = {"open", "close", "put", "place", "pick", "take"}
    starts = [i for i, word in enumerate(tokens) if word in verbs]
    if not starts or any(s in text for s in ("turn ", "push ", "stack ")):
        return api.fallback()

    plan = []
    held = []
    for k, start in enumerate(starts):
        end = starts[k + 1] if k + 1 < len(starts) else len(tokens)
        verb = tokens[start]
        clause = " ".join(tokens[start + 1:end]).rstrip(" .,")
        if verb in ("open", "close"):
            target = destination(clause)
            if not target or "drawer" not in clause:
                return api.fallback()
            plan.append(("drawer", target, verb))
            continue

        separators = (" onto ", " into ", " on ", " inside ", " in ")
        cuts = [(clause.rfind(s), s) for s in separators if s in clause]
        cut, separator = max(cuts) if cuts else (-1, "")
        source_words = clause[:cut] if cut >= 0 else clause
        candidates = matches(source_words)

        if verb in ("pick", "take"):
            if len(candidates) > 1 and cut >= 0:
                source = destination(clause[cut:])
                if source:
                    candidates = [api.nearest(source, candidates)]
            held = candidates
            if len(held) != 1:
                return api.fallback()
            continue

        target = destination(clause[cut:]) if cut >= 0 else None
        items = held if (" it " in " " + source_words + " ") else candidates
        if len(items) > 1:
            # Resolve a source qualifier, e.g. the bowl on the cabinet.
            source_cuts = [(source_words.rfind(s), s)
                           for s in separators if s in source_words]
            if source_cuts:
                source_cut, _ = max(source_cuts)
                source = destination(source_words[source_cut:])
                items = matches(source_words[:source_cut])
                if source and items:
                    items = [api.nearest(source, items)]
        if not target or len(items) != 1:
            return api.fallback()
        item = items[0]
        grasp = "rim" if "bowl" in item else (
            "thin_edge" if "book" in item else "standard"
        )
        plan.append(("place", (item, target), grasp))
        held = []

    if not plan:
        return api.fallback()

    # For the supplied task: nearest bowl to cabinet top_side, then rim placement.
    for action, subject, mode in plan:
        if action == "drawer":
            api.drawer(subject, mode)
        else:
            item, target = subject
            api.place_with(item, target, mode)
