def run(api):
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [n for n in names if n.rsplit("_", 1)[-1].isdigit()]

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        words = [base]
        for noun in ("bowl", "book", "plate", "basket", "caddy",
                     "cabinet", "mug", "bottle", "stove"):
            if noun in base:
                words.append(noun)
        if "cabinet" in base:
            words.append("drawer")
        return words

    def matches(name, phrase):
        return max((len(a) for a in aliases(name)
                    if " " + a + " " in " " + phrase + " "), default=0)

    def resolve(phrase, candidates):
        ranked = sorted(candidates, key=lambda n: matches(n, phrase),
                        reverse=True)
        if not ranked or not matches(ranked[0], phrase):
            return None
        best = matches(ranked[0], phrase)
        tied = [n for n in ranked if matches(n, phrase) == best]
        return tied[0] if len(tied) == 1 else None

    def place(item, target):
        grasp = ("rim" if "bowl" in item else
                 "thin_edge" if "book" in item else "standard")
        api.place_with(item, target, grasp)

    # Resolve the entire plan before executing any actions.
    clauses = text.replace(", then ", ";").replace(" and then ", ";")
    clauses = clauses.replace(" then ", ";")
    for verb in ("open", "close", "put", "place"):
        clauses = clauses.replace(" and " + verb + " ", ";" + verb + " ")

    plan = []
    last_drawer = None
    for clause in clauses.split(";"):
        clause = clause.strip(" ,.")
        if not clause:
            continue

        if clause.startswith(("open ", "close ")):
            cabinet = resolve(clause, [n for n in bodies if "cabinet" in n])
            level = next((s for s in ("bottom", "middle", "top")
                          if s in clause.split()), None)
            region = (cabinet + "_" + level + "_region"
                      if cabinet and level else last_drawer)
            if region not in names:
                return api.fallback()
            last_drawer = region
            plan.append(("drawer", region, clause.split()[0]))
            continue

        if not clause.startswith(("put ", "place ")):
            return api.fallback()

        separators = (" on top of ", " on ", " into ", " inside ", " in ")
        found = [(clause.find(s), s) for s in separators if s in clause]
        if not found:
            return api.fallback()
        index, separator = min(found, key=lambda pair: pair[0])
        source, destination = clause[:index], clause[index + len(separator):]
        item = resolve(source, bodies)
        target = resolve(destination, [n for n in bodies if n != item])
        if item is None or target is None:
            return api.fallback()

        surface = ("on top of" in separator or
                   "top of" in destination or "on the top" in clause)
        direction = next((s for s in ("left", "right", "front", "back")
                          if s in destination.split()), None)

        if "cabinet" in target:
            if surface:
                target += "_top_side"
            else:
                level = next((s for s in ("bottom", "middle", "top")
                              if s in destination.split()), None)
                if level is None:
                    return api.fallback()
                target += "_" + level + "_region"
                last_drawer = target
        elif direction:
            relation = ("outside" if any(s in destination for s in
                        ("next to", "beside", "side of")) else "inside")
            plan.append(("relative", item, (target, direction, relation)))
            continue
        elif separator.strip() in ("in", "into", "inside"):
            region = target + "_contain_region"
            if region in names:
                target = region
        elif "stove" in target and target + "_cook_region" in names:
            target += "_cook_region"

        if target not in names:
            return api.fallback()
        plan.append(("place", item, target))

    for action, first, second in plan:
        if action == "drawer":
            api.drawer(first, second)
        elif action == "relative":
            place(first, api.relative_target(*second))
        else:
            # Given task: bowl -> wooden_cabinet_1_top_side, rim grasp.
            place(first, second)
