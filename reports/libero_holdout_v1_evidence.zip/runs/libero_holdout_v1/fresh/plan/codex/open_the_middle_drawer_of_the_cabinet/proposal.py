def run(api):
    text = api.instruction.lower()
    names = list(api.names())
    level = next((x for x in ("middle", "bottom", "top") if x in text), None)
    regions = [
        n for n in names
        if level and n.endswith("_" + level + "_region")
        and ("cabinet" in n or "drawer" in n)
    ]
    placement = any(word in text for word in ("put", "place", "insert"))
    if "drawer" in text and len(regions) == 1 and not placement:
        actions = [
            (text.find(verb), verb)
            for verb in ("open", "close") if verb in text
        ]
        if actions:
            for _, action in sorted(actions):
                api.drawer(regions[0], action)
            return
    api.fallback()
