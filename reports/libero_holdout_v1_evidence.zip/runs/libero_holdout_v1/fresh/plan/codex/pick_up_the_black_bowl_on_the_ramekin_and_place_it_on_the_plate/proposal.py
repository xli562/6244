import numpy as np

def run(api):
    task = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bowls = [n for n in names
             if n.startswith("akita_black_bowl_") and n.split("_")[-1].isdigit()]
    ramekins = [n for n in names
                if "ramekin" in n and n.split("_")[-1].isdigit()]
    plates = [n for n in names
              if n.startswith("plate_") and n.split("_")[-1].isdigit()]

    if not (bowls and len(ramekins) == 1 and len(plates) == 1
            and "bowl on the ramekin" in task
            and "on the plate" in task):
        return api.fallback()

    # 1. Resolve the bowl by its observed position on the ramekin.
    support = np.asarray(api.pos(ramekins[0]), dtype=float)
    bowl = min(
        bowls,
        key=lambda n: np.linalg.norm(
            np.asarray(api.pos(n), dtype=float) - support
        ),
    )

    # 2. Pinch the open bowl's rim and place it on the plate.
    api.place_with(bowl, plates[0], "rim")
