def run(api):
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [n for n in names if n.rsplit("_", 1)[-1].isdigit()
              and "region" not in n]

    def words(name):
        return name.replace("_", " ")

    def aliases(name):
        base = words(name.rsplit("_", 1)[0])
        extra = {
            "akita black bowl": ["black bowl", "bowl"],
            "porcelain mug": ["white mug"],
            "white yellow mug": ["yellow and white mug", "yellow mug"],
            "red coffee mug": ["red mug"],
            "chefmate 8 frypan": ["frying pan", "pan"],
            "desk caddy": ["caddy"],
            "wooden cabinet": ["cabinet"],
            "white cabinet": ["cabinet"],
            "flat stove": ["stove"],
        }
        return [base] + extra.get(base, [])

    def matches(fragment):
        hits = []
        for name in bodies:
            score = max([len(a) for a in aliases(name)
                         if a in fragment] or [0])
            if score:
                hits.append((score, name))
        if not hits:
            return []
        best = max(score for score, name in hits)
        return [name for score, name in hits if score == best]

    def resolve(fragment):
        candidates = matches(fragment)
        if len(candidates) == 1:
            return candidates[0]
        if candidates:
            regions = [n for n in names if n not in bodies
                       and words(n).replace("main table ", "") in fragment]
            if regions:
                region = max(regions, key=len)
                return api.nearest(region, candidates)
        return None

    # Unsupported manipulations and compound placement plans use the old policy.
    if any(s in text for s in ("turn on", "turn off", "stack")):
        return api.fallback()

    separators = ("place it ", "put it ", "place them ", "put them ")
    split = next((s for s in separators if s in text), None)
    if split:
        source, destination = text.split(split, 1)
    else:
        cuts = [(text.find(s), s) for s in
                (" onto ", " into ", " inside ", " on ", " in ")
                if s in text]
        if not cuts:
            source, destination = "", text
        else:
            index, separator = min(cuts)
            source, destination = text[:index], text[index:]

    item = resolve(source)
    target = resolve(destination)

    if "drawer" in text:
        level = next((s for s in ("top", "middle", "bottom")
                      if s in destination), None)
        regions = [n for n in names
                   if level and n.endswith("_" + level + "_region")
                   and "cabinet" in n]
        if len(regions) != 1 or (source and item is None):
            return api.fallback()
        target = regions[0]
        if "open" in text:
            api.drawer(target, "open")
        if item:
            grasp = ("rim" if "bowl" in item else
                     "thin_edge" if "book" in item else "standard")
            api.place_with(item, target, grasp)
        if "close" in text:
            api.drawer(target, "close")
        return

    if item is None or target is None or item == target:
        return api.fallback()

    direction = next((s for s in ("left", "right", "front", "back")
                      if s in destination.split()), None)
    if direction and any(s in target for s in ("caddy", "cabinet")):
        outside = any(s in destination for s in
                      ("next to", "beside", "outside", "to the"))
        target = api.relative_target(
            target, direction, "outside" if outside else "inside"
        )
    elif "cabinet" in target and "top" in destination:
        target = next((n for n in names
                       if n == target + "_top_side"), target)
    elif any(s in destination for s in (" in ", "into", "inside")):
        target = next((n for n in names
                       if n == target + "_contain_region"), target)

    # Open bowls: rim pinch. Books: thin edge. Other objects: standard.
    grasp = ("rim" if "bowl" in item else
             "thin_edge" if "book" in item else "standard")
    api.place_with(item, target, grasp)
