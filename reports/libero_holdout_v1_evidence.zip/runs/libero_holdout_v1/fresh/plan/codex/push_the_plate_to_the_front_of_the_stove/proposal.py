def run(api):
    import numpy as np

    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [n for n in names
              if n.rsplit("_", 1)[-1].isdigit() and "region" not in n]

    def find(word):
        return next((n for n in bodies if word in n), None)

    def grasp(item):
        if "bowl" in item:
            return "rim"
        if "book" in item:
            return "thin_edge"
        return "standard"

    # Push with closed fingertips; do not pick up the plate.
    if "push" in text and "plate" in text and "stove" in text:
        plate, stove = find("plate"), find("stove")
        direction = next((d for d in ("front", "back", "left", "right")
                          if d in text), None)
        if plate is None or stove is None or direction is None:
            return api.fallback()
        target = api.relative_target(stove, direction, "outside")
        if target is None:
            return api.fallback()

        for _ in range(3):
            p = np.asarray(api.pos(plate), dtype=float)
            q = np.asarray(api.pos(target), dtype=float)
            delta = q[:2] - p[:2]
            distance = float(np.linalg.norm(delta))
            if distance < 0.035:
                return
            unit = np.array([delta[0], delta[1], 0.]) / distance
            contact = p - 0.105 * unit + np.array([0., 0., 0.008])
            api.grip(True)
            api.move(contact + [0., 0., 0.13], steps=15)
            api.move(contact, steps=12)
            api.move(contact + unit * (min(distance, 0.18) + 0.015),
                     steps=28)
            hand = np.asarray(api.eef(), dtype=float)
            api.move(hand + [0., 0., 0.13], steps=12)
        return

    # Resolve explicit fixture compartments and adjacent table locations.
    fixture = find("caddy") if "caddy" in text else None
    direction = next((d for d in ("front", "back", "left", "right")
                      if d in text), None)
    if fixture and direction and any(v in text for v in ("put", "place")):
        relation = "outside" if any(
            s in text for s in ("next to", "outside", "in front of")
        ) else "inside"
        target = api.relative_target(fixture, direction, relation)
        items = [n for n in bodies if n != fixture and
                 n.rsplit("_", 1)[0].replace("_", " ") in text]
        if target and items:
            for item in items:
                api.place_with(item, target, grasp(item))
            return

    # Other tasks retain the existing policy's object resolution and skills.
    return api.fallback()
