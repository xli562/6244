def run(api):
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [
        n for n in names
        if n.rsplit("_", 1)[-1].isdigit()
        and "region" not in n
    ]

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug"],
        "white yellow mug": ["yellow and white mug", "white and yellow mug"],
        "red coffee mug": ["red mug"],
        "chefmate 8 frypan": ["frying pan", "pan"],
        "flat stove": ["stove"],
        "white cabinet": ["cabinet"],
        "desk caddy": ["caddy"],
    }

    def mentions(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        aliases = [base] + synonyms.get(base, [])
        return [
            (text.find(a), len(a))
            for a in aliases if a in text
        ]

    def grasp(item):
        if "bowl" in item:
            return "rim"
        if "book" in item:
            return "thin_edge"
        return "standard"

    # The requested soup placement uses an ordinary solid-object grasp.
    if "alphabet soup" in text and "basket" in text and "drawer" not in text:
        soups = [n for n in bodies if n.startswith("alphabet_soup_")]
        baskets = [n for n in bodies if n.startswith("basket_")]
        if len(soups) == len(baskets) == 1:
            target = baskets[0] + "_contain_region"
            if target in names:
                api.place_with(soups[0], target, "standard")
                return

    # Preserve complex action sequences through the previous policy.
    if any(s in text for s in ("turn on", "turn off", "then put", "then place")):
        return api.fallback()

    matched = [n for n in bodies if mentions(n)]
    matched.sort(key=lambda n: min(p for p, _ in mentions(n)))

    if "drawer" in text:
        levels = [s for s in ("top", "middle", "bottom") if s in text]
        if len(levels) != 1:
            return api.fallback()
        regions = [
            n for n in names
            if "cabinet" in n and n.endswith("_" + levels[0] + "_region")
        ]
        if len(regions) != 1:
            return api.fallback()
        region = regions[0]
        items = [n for n in matched if "cabinet" not in n]
        if "close" in text and "open" in text:
            if text.find("close") < text.find("open"):
                return api.fallback()
        if "open" in text:
            api.drawer(region, "open")
        for item in items:
            api.place_with(item, region, grasp(item))
        if "close" in text:
            api.drawer(region, "close")
        return

    if len(matched) < 2:
        return api.fallback()

    reference = matched[-1]
    items = matched[:-1]
    target = reference
    directions = [d for d in ("left", "right", "front", "back") if d in text]

    if directions:
        if len(directions) != 1:
            return api.fallback()
        outside = any(s in text for s in (
            "next to", "beside", "to the left of", "to the right of",
            "in front of", "behind",
        ))
        target = api.relative_target(
            reference, directions[0], "outside" if outside else "inside"
        )
    elif "on top" in text and reference + "_top_side" in names:
        target = reference + "_top_side"
    elif " in " in text or " into " in text:
        candidate = reference + "_contain_region"
        if candidate in names:
            target = candidate
    elif reference + "_cook_region" in names:
        target = reference + "_cook_region"

    for item in items:
        api.place_with(item, target, grasp(item))
