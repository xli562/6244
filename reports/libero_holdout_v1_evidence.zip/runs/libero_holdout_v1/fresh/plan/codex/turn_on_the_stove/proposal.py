def run(api):
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [n for n in names if n.rsplit("_", 1)[-1].isdigit()]

    # Stove switches and other unsupported actions use the physical old policy.
    if any(s in text for s in ("turn on", "turn off", "switch on", "switch off")):
        return api.fallback()

    aliases = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug"],
        "white yellow mug": ["yellow and white mug", "white and yellow mug"],
        "red coffee mug": ["red mug"],
        "chefmate 8 frypan": ["frying pan", "pan"],
        "wooden cabinet": ["cabinet"],
        "white cabinet": ["cabinet"],
        "desk caddy": ["caddy"],
    }

    def mentions(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        labels = [base] + aliases.get(base, [])
        hits = [(text.find(a), len(a)) for a in labels if a in text]
        return min(hits, key=lambda h: (-h[1], h[0])) if hits else None

    selected = [(n, mentions(n)) for n in bodies]
    selected = sorted(
        [(n, hit) for n, hit in selected if hit is not None],
        key=lambda pair: pair[1][0],
    )

    def place(item, target):
        grasp = ("rim" if "bowl" in item else
                 "thin_edge" if "book" in item else "standard")
        api.place_with(item, target, grasp)

    if "drawer" in text:
        levels = [s for s in ("top", "middle", "bottom") if s in text]
        regions = [
            n for n in names
            if "cabinet" in n and levels
            and n.endswith("_" + levels[0] + "_region")
        ]
        if len(levels) != 1 or len(regions) != 1:
            return api.fallback()
        region = regions[0]
        items = [n for n, _ in selected if "cabinet" not in n]
        opening, closing = text.find("open"), text.find("close")
        if opening >= 0 and closing >= 0 and closing < opening:
            return api.fallback()
        if opening >= 0:
            api.drawer(region, "open")
        for item in items:
            place(item, region)
        if closing >= 0:
            api.drawer(region, "close")
        if opening < 0 and closing < 0 and not items:
            return api.fallback()
        return

    # Resolve a single destination before issuing any placement commands.
    if len(selected) < 2 or any(s in text for s in (" then ", " and put ", " and place ")):
        return api.fallback()
    target = selected[-1][0]
    items = [n for n, _ in selected[:-1]]
    destination_text = text[selected[-1][1][0]:]
    directions = [s for s in ("left", "right", "front", "back")
                  if s in text.split()]
    if directions:
        outside = any(s in text for s in
                      ("next to", "beside", "to the left of", "to the right of",
                       "in front of", "behind"))
        target = api.relative_target(
            target, directions[0], "outside" if outside else "inside"
        )
    elif "on top" in text and target + "_top_side" in names:
        target += "_top_side"
    elif any(s in text for s in (" in ", " into ", "inside")):
        region = target + "_contain_region"
        if region in names:
            target = region
    elif target + "_cook_region" in names:
        target += "_cook_region"

    for item in items:
        place(item, target)
