def run(api):
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [
        n for n in names
        if n.rsplit("_", 1)[-1].isdigit() and "region" not in n
    ]

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        extra = {
            "akita black bowl": ["black bowl", "bowl"],
            "porcelain mug": ["white mug"],
            "white yellow mug": ["yellow and white mug", "yellow mug"],
            "red coffee mug": ["red mug"],
            "chefmate 8 frypan": ["frying pan", "pan"],
            "flat stove": ["stove"],
            "white cabinet": ["cabinet"],
            "desk caddy": ["caddy"],
        }
        return [base] + extra.get(base, [])

    def mentions(clause):
        hits = []
        for body in bodies:
            matches = [
                (clause.find(a), len(a))
                for a in aliases(body)
                if " " + a + " " in " " + clause + " "
            ]
            if matches:
                start, length = max(matches, key=lambda x: x[1])
                hits.append((start, -length, body))
        hits.sort()
        return [h[2] for h in hits]

    def region(body, suffix):
        return next(
            (n for n in names if n == body + "_" + suffix), None
        )

    # Build the ordered actions before executing any physical skill.
    clauses = text
    for marker in ("then ", "and place ", "and put ", "and close ", "and open "):
        replacement = "|" + marker.replace("then ", "").replace("and ", "")
        clauses = clauses.replace(marker, replacement)

    actions = []
    held_reference = None
    drawer_reference = None

    for clause in clauses.split("|"):
        objects = mentions(clause)
        drawer = None
        if "drawer" in clause:
            level = next(
                (s for s in ("top", "middle", "bottom") if s in clause), None
            )
            candidates = [
                n for n in names
                if "cabinet" in n
                and any(n.endswith("_" + s + "_region")
                        for s in ([level] if level else
                                  ["top", "middle", "bottom"]))
            ]
            drawer = candidates[0] if len(candidates) == 1 else drawer_reference
            if drawer is None:
                return api.fallback()
            drawer_reference = drawer

        if drawer and ("open" in clause or "close" in clause):
            actions.append(("drawer", drawer,
                            "close" if "close" in clause else "open"))
            if not any(v in clause for v in ("put ", "place ", "insert ")):
                continue

        if clause.startswith("pick ") and len(objects) == 1:
            held_reference = objects[0]
            continue

        if drawer:
            target = drawer
            items = [n for n in objects if "cabinet" not in n]
        elif objects:
            target = objects[-1]
            items = objects[:-1]
            if not items and held_reference and target != held_reference:
                items = [held_reference]

            direction = next(
                (d for d in ("left", "right", "front", "back")
                 if d in clause.split()), None
            )
            if direction and ("caddy" in target or "cabinet" in target):
                outside = any(s in clause for s in
                              ("next to", "outside", "to the left of",
                               "to the right of", "in front of", "behind"))
                target = api.relative_target(
                    target, direction, "outside" if outside else "inside"
                )
            elif "cabinet" in target and "top" in clause:
                target = region(target, "top_side") or target
            elif any(s in clause for s in (" in ", " into ", "inside")):
                target = region(target, "contain_region") or target
            elif "stove" in target:
                target = region(target, "cook_region") or target
        else:
            return api.fallback()

        if not items:
            return api.fallback()
        for item in items:
            grasp = ("rim" if "bowl" in item else
                     "thin_edge" if "book" in item else "standard")
            actions.append(("place", item, (target, grasp)))
            held_reference = item

    if not actions:
        return api.fallback()

    for kind, item, argument in actions:
        if kind == "drawer":
            api.drawer(item, argument)
        else:
            target, grasp = argument
            # Milk uses the standard grasp and basket's contain region.
            api.place_with(item, target, grasp)
