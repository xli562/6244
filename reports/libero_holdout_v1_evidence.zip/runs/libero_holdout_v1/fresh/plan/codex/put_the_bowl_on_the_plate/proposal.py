def run(api):
    names = list(api.names())
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    bowls = [n for n in names if "bowl" in n and n.rsplit("_", 1)[-1].isdigit()]
    plates = [n for n in names if n.startswith("plate_") and n.rsplit("_", 1)[-1].isdigit()]

    if text == "put the bowl on the plate" and len(bowls) == len(plates) == 1:
        api.place_with(bowls[0], plates[0], "rim")
    else:
        api.fallback()
