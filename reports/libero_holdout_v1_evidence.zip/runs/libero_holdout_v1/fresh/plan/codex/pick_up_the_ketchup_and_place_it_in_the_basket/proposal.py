def run(api):
    text = api.instruction.lower()
    names = list(api.names())

    if "ketchup" in text and "basket" in text:
        items = [n for n in names if n.startswith("ketchup_")
                 and n.rsplit("_", 1)[-1].isdigit()]
        targets = [n for n in names
                   if n.startswith("basket_") and n.endswith("_contain_region")]
        if len(items) == 1 and len(targets) == 1:
            api.place_with(items[0], targets[0], grasp="standard")
            return

    api.fallback()
