def run(api):
    api.place_with("bbq_sauce_1", "basket_1_contain_region", "standard")
