def run(api):
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())

    if "cream cheese" in text and ("on the bowl" in text or
                                  "on the black bowl" in text):
        cheese = next((n for n in names
                       if n.startswith("cream_cheese_")
                       and n.rsplit("_", 1)[-1].isdigit()), None)
        bowl = next((n for n in names
                     if "bowl" in n
                     and n.rsplit("_", 1)[-1].isdigit()), None)
        if cheese and bowl:
            # Grasp the solid cheese box with the standard grasp.
            api.place_with(cheese, bowl, "standard")
            return

    api.fallback()
