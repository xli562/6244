def run(api):
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())

    # A placement on top of a drawer uses the cabinet's top_side.
    on_top = any(p in text for p in (
        "on the top of", "on top of", "on top", "on the drawer"
    ))
    if on_top and ("drawer" in text or "cabinet" in text):
        surfaces = [n for n in names if n.endswith("_top_side")]
        surfaces = [n for n in surfaces if "cabinet" in n or "drawer" in n]
        items = []
        for name in names:
            base, _, suffix = name.rpartition("_")
            if not suffix.isdigit():
                continue
            phrase = base.replace("_", " ")
            if phrase in text and "cabinet" not in name and "drawer" not in name:
                items.append(name)

        if len(surfaces) == 1 and items:
            items.sort(key=lambda n: text.find(n.rsplit("_", 1)[0].replace("_", " ")))
            for item in items:
                grasp = (
                    "rim" if "bowl" in item else
                    "thin_edge" if "book" in item else
                    "standard"
                )
                # Wine bottle: standard grasp; place on the exterior top.
                api.place_with(item, surfaces[0], grasp)
            return

    api.fallback()
