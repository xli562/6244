def run(api):
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [n for n in names if n.rsplit("_", 1)[-1].isdigit()]

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "cookies": ["cookies box", "cookies"],
        "porcelain mug": ["white mug"],
        "white yellow mug": ["white and yellow mug", "yellow and white mug"],
        "red coffee mug": ["red mug"],
        "black book": ["book"],
        "desk caddy": ["caddy"],
        "wooden cabinet": ["cabinet"],
        "white cabinet": ["cabinet"],
        "chefmate 8 frypan": ["frying pan", "pan"],
        "flat stove": ["stove"],
    }

    def matches(phrase):
        scored = []
        for name in bodies:
            base = name.rsplit("_", 1)[0].replace("_", " ")
            aliases = [base] + synonyms.get(base, [])
            score = max(
                [len(a) for a in aliases if " " + a + " " in
                 " " + phrase + " "] or [0]
            )
            if score:
                scored.append((score, name))
        best = max([s for s, _ in scored] or [0])
        return [n for s, n in scored if s == best]

    def region(body, suffix):
        return next((n for n in names if n == body + "_" + suffix), None)

    # Resolve the source separately from its destination and location qualifier.
    split = None
    for marker in (" and place ", " and put ", " and then place ",
                   " and then put "):
        if marker in text:
            split = text.split(marker, 1)
            break
    if split is None:
        for marker in (" into ", " inside ", " onto ", " on ", " in "):
            if marker in text:
                split = text.rsplit(marker, 1)
                split[1] = marker.strip() + " " + split[1]
                break

    if split is None:
        if "drawer" in text:
            fixtures = [n for n in bodies if "cabinet" in n]
            level = next((s for s in ("top", "middle", "bottom")
                          if s in text), None)
            if len(fixtures) == 1 and level:
                target = region(fixtures[0], level + "_region")
                operations = [(text.find(v), v) for v in ("open", "close")
                              if v in text]
                if target and operations:
                    for _, operation in sorted(operations):
                        api.drawer(target, operation)
                    return
        return api.fallback()

    source, destination = split
    source_parts = source.split(" next to ", 1)
    candidates = matches(source_parts[0])
    if len(candidates) > 1 and len(source_parts) == 2:
        references = matches(source_parts[1])
        if len(references) == 1:
            candidates = [api.nearest(references[0], candidates)]
    if len(candidates) != 1:
        return api.fallback()
    item = candidates[0]

    targets = matches(destination)
    if "drawer" in destination and not targets:
        targets = [n for n in bodies if "cabinet" in n]
    if len(targets) != 1:
        return api.fallback()
    target = targets[0]

    if "drawer" in destination:
        level = next((s for s in ("top", "middle", "bottom")
                      if s in destination), None)
        target = region(target, level + "_region") if level else None
        if target is None:
            return api.fallback()
    else:
        direction = next((s for s in ("left", "right", "front", "back")
                          if s in destination.split()), None)
        inside = any(s in destination.split() for s in ("in", "inside", "into"))
        if direction:
            target = api.relative_target(
                target, direction, "inside" if inside else "outside"
            )
        elif inside:
            target = region(target, "contain_region") or target
        elif "cabinet" in target:
            target = region(target, "top_side") or target
        elif "stove" in target:
            target = region(target, "cook_region") or target

    # Physical grasp: bowl wall, narrow book edge, or ordinary solid object.
    grasp = "rim" if "bowl" in item else (
        "thin_edge" if "book" in item else "standard"
    )
    if "drawer" in destination and "open" in text:
        api.drawer(target, "open")
    api.place_with(item, target, grasp)
    if "drawer" in destination and "close" in destination:
        api.drawer(target, "close")
