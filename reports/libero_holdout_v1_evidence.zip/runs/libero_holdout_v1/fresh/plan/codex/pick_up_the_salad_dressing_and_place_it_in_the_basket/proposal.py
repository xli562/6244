def run(api):
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [n for n in names if n.rsplit("_", 1)[-1].isdigit()
              and "region" not in n]

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug"],
        "white yellow mug": ["yellow and white mug", "white and yellow mug"],
        "red coffee mug": ["red mug"],
        "chefmate 8 frypan": ["frying pan", "pan"],
        "flat stove": ["stove"],
        "white cabinet": ["cabinet"],
        "desk caddy": ["caddy"],
    }

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        return [base] + synonyms.get(base, [])

    def matches(fragment):
        found = []
        for name in bodies:
            for alias in aliases(name):
                start = (" " + fragment + " ").find(" " + alias + " ")
                if start >= 0:
                    found.append((start, -len(alias), name))
        found.sort()
        result, end = [], -1
        for start, negative_length, name in found:
            if start >= end and name not in result:
                result.append(name)
                end = start - negative_length
        return result

    def region(body, suffix):
        return next((n for n in names if n == body + "_" + suffix), None)

    def grasp(item):
        if "bowl" in item:
            return "rim"
        if "book" in item:
            return "thin_edge"
        return "standard"

    # Compile the full ordered plan before executing any physical actions.
    clauses = text
    verbs = ("open", "close", "put", "place", "move", "turn")
    for verb in verbs:
        for separator in (", then ", " and then ", " then ", " and ", ", "):
            clauses = clauses.replace(separator + verb + " ",
                                      "|" + verb + " ")
    plan = []
    previous_target = None

    for clause in clauses.split("|"):
        objects = matches(clause)
        if clause.startswith(("open ", "close ")):
            cabinets = [n for n in objects if "cabinet" in n]
            if not cabinets:
                cabinets = [n for n in bodies if "cabinet" in n]
            level = next((s for s in ("top", "middle", "bottom")
                          if s in clause), None)
            target = (region(cabinets[0], level + "_region")
                      if len(cabinets) == 1 and level else previous_target)
            if not target or "region" not in target:
                return api.fallback()
            plan.append(("drawer", target, clause.split()[0]))
            previous_target = target
            continue

        if "turn " in clause or len(objects) < 2:
            return api.fallback()

        reference = objects[-1]
        items = objects[:-1]
        target = reference
        direction = next((s for s in ("left", "right", "front", "back")
                          if s in clause.split()), None)
        inside = any(s in clause for s in (" in ", " into ", " inside "))
        outside = any(s in clause for s in
                      ("next to", "to the left of", "to the right of",
                       "in front of", "behind"))

        if "drawer" in clause:
            level = next((s for s in ("top", "middle", "bottom")
                          if s in clause), None)
            target = region(reference, level + "_region") if level else None
        elif direction and ("caddy" in reference or outside):
            target = api.relative_target(
                reference, direction, "outside" if outside else "inside")
        elif direction and "plate" in reference:
            markers = [n for n in names
                       if "plate_" + direction + "_region" in n]
            plates = [n for n in bodies if "plate" in n]
            target = api.nearest(markers[0], plates) if markers else None
        elif inside:
            target = region(reference, "contain_region") or reference
        elif "cabinet" in reference:
            target = region(reference, "top_side")
        elif "stove" in reference:
            target = region(reference, "cook_region") or reference

        if not target:
            return api.fallback()
        for item in items:
            plan.append(("place", item, target))
        previous_target = target

    for operation, first, second in plan:
        if operation == "drawer":
            api.drawer(first, second)
        else:
            # Salad dressing → basket: standard grasp.
            # Open bowls: rim; books: thin_edge; other objects: standard.
            api.place_with(first, second, grasp(first))
