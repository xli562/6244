import math
import numpy as np

ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl', 'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup', 'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup', 'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop', 'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy',
    'black_book': 'black book', 'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle', 'butter': 'butter box',
    'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet drawer drawers', 'wooden_cabinet': 'wooden cabinet drawer drawers',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack', 'microwave': 'microwave oven',
    'basket': 'basket', 'plate': 'plate',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown', 'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'top', 'left', 'right',
        'front', 'back', 'bottom', 'middle', 'compartment', 'side', 'its', 'that', 'is',
        'please', 'then', 'next', 'onto', 'into', 'on', 'in', 'inside'}
VERBS = {'put', 'place', 'turn', 'switch', 'close', 'shut', 'open', 'pick', 'push', 'pull',
         'move', 'stack', 'lift', 'grab', 'take', 'set'}
PREPS = ('into', 'onto', 'inside', 'in', 'on')
DIRS = ('left', 'right', 'front', 'back')
LEVELS = ('top', 'middle', 'bottom')


def V(*a):
    return np.array(a, dtype=float)


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def E(api):
    return np.array(api.eef(), dtype=float)


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    if 'cabinet' in base:
        w |= {'drawer', 'drawers', 'cabinet'}
    if 'mug' in base:
        w |= {'mug', 'cup'}
    return w


# ---------------------------------------------------------------- resolution
def _spatial(api, names, raw, cands):
    for w in DIRS:
        if w in raw:
            keyf = {'left': lambda p: -p[1], 'right': lambda p: p[1],
                    'front': lambda p: p[0], 'back': lambda p: -p[0]}[w]
            try:
                return sorted(cands, key=lambda c: keyf(P(api, c)))
            except Exception:
                return sorted(cands)
    return sorted(cands)


def resolve(api, names, bodies, raw, exclude=()):
    W = set(w for w in raw if w not in STOP)
    if not W:
        return None
    best, cands = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, cands = s, [b]
        elif abs(s - best) < 1e-9:
            cands.append(b)
    if not cands:
        return None
    if len(cands) > 1:
        cands = _spatial(api, names, raw, cands)
    return cands[0]


def _top_of(tw):
    for i, w in enumerate(tw):
        if w == 'top' and i + 1 < len(tw) and tw[i + 1] == 'of':
            return True
    return False


def resolve_target(api, names, bodies, tw, prep):
    """returns (target_name, owner_body)"""
    obj = resolve(api, names, bodies, tw)
    if obj is None:
        return None
    R = set(tw)
    regs = [n for n in names if _is_region(n) and n.startswith(obj + '_')]
    inside_prep = prep in ('in', 'into', 'inside')

    # cabinets / drawers
    if 'cabinet' in _base(obj) and regs:
        side = [r for r in regs if r.endswith('top_side')]
        lvl = next((l for l in LEVELS if l in R), None)
        want_top = (prep in ('on', 'onto') and (_top_of(tw) or lvl is None or
                    ('drawer' not in R and 'compartment' not in R))) or \
                   (_top_of(tw) and not inside_prep)
        if want_top and side:
            return (side[0], obj)
        lvl = lvl or 'top'
        cand = [r for r in regs if r.endswith('_' + lvl + '_region')]
        if cand:
            return (cand[0], obj)
        if side and prep in ('on', 'onto'):
            return (side[0], obj)

    # spatial relation (left/right/front/back)
    d = next((w for w in DIRS if w in R), None)
    if d:
        hit = [r for r in regs if d in r[len(obj) + 1:].split('_')]
        if hit:
            return (hit[0], obj)
        rel = 'inside' if (inside_prep or 'compartment' in R) else 'outside'
        try:
            r = api.relative_target(obj, d, rel)
            if r:
                return (r, obj)
        except Exception:
            pass

    if not regs:
        return (obj, obj)
    drawer = 'drawer' in R or 'drawers' in R
    best, bs = None, -1e9
    for r in regs:
        suf = r[len(obj) + 1:].split('_')
        toks = set(suf) - {'region', 'contain', 'side'}
        s = 3 * len(toks & R)
        if drawer and 'side' in suf:
            s -= 5
        if (not drawer) and 'top' in R and 'side' in suf:
            s += 2
        if not toks or toks <= {'cook', 'heating'}:
            s += 1
        if s > bs:
            bs, best = s, r
    return (best, obj)


def drawer_region(names, tgt, words):
    name, owner = tgt
    if name.endswith('_region') and any(('_' + l + '_') in name for l in LEVELS):
        return name
    lvl = next((l for l in LEVELS if l in words), 'top')
    c = [n for n in names if n.startswith(owner + '_') and n.endswith('_' + lvl + '_region')]
    if c:
        return c[0]
    c = [n for n in names if n.startswith(owner + '_') and n.endswith('_region')]
    return c[0] if c else name


# ---------------------------------------------------------------- parsing
def split_clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if (w == 'and' and (nxt in VERBS or nxt == 'then')) or w == 'then':
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return [c for c in out if c]


def split_items(ws):
    both = 'both' in ws
    has_the = any(ws[j] == 'and' and j + 1 < len(ws) and ws[j + 1] in ('the', 'a')
                  for j in range(len(ws)))
    parts = [[]]
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if w == 'and' and ((has_the and nxt in ('the', 'a')) or (both and not has_the)):
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def build_plan(api, names, bodies, words):
    ops = []
    last_item, last_target, last_fix = None, None, None
    for c in split_clauses(words):
        while c and c[-1] == 'and':
            c = c[:-1]
        if not c:
            continue
        v, rest = c[0], c[1:]
        if v in ('turn', 'switch'):
            on = 'off' not in rest
            ow = [w for w in rest if w not in ('on', 'off')]
            obj = last_fix if (not ow or ow == ['it']) else resolve(api, names, bodies, ow)
            if obj:
                ops.append(('turn', obj, on))
                last_fix = obj
            continue
        if v in ('close', 'shut', 'open'):
            if not rest or rest in (['it'], ['them']):
                tgt = last_target
            else:
                tgt = resolve_target(api, names, bodies, rest, 'in')
            if tgt:
                ops.append(('open' if v == 'open' else 'close', tgt, rest))
                last_target = tgt
                last_fix = tgt[1]
            continue
        rest = [w for w in rest if w != 'up']
        idx = None
        for i, w in enumerate(rest):
            if w in PREPS and i > 0:
                idx = i
                break
        if v in ('pick', 'grab', 'lift', 'take') and idx is None:
            it = resolve(api, names, bodies, rest)
            if it:
                ops.append(('pick', it))
                last_item = it
            continue
        if idx is None:
            item_w, tw, prep = rest, [], 'on'
        else:
            item_w, tw, prep = rest[:idx], rest[idx + 1:], rest[idx]
        if prep == 'on' and tw[:1] == ['top'] and 'of' not in tw:
            pass
        if not tw or tw in (['it'], ['them']):
            if tw and last_fix:
                tgt = resolve_target(api, names, bodies, _base(last_fix).split('_'), prep)
                if last_target and last_target[1] == last_fix:
                    tgt = last_target
                if tgt is None:
                    tgt = (last_fix, last_fix)
            else:
                tgt = last_target
        else:
            tgt = resolve_target(api, names, bodies, tw, prep)
        if tgt is None:
            continue
        items = []
        for part in split_items(item_w):
            if part in (['it'], ['them']):
                it = last_item
            else:
                it = resolve(api, names, bodies, part, exclude=(tgt[1],))
            if it and it not in items:
                items.append(it)
        if ops and ops[-1][0] == 'pick' and ops[-1][1] in items:
            ops.pop()
        for it in items:
            ops.append(('place', it, tgt))
        if items:
            last_item = items[-1]
        last_target = tgt
        last_fix = tgt[1]
    return ops


# ---------------------------------------------------------------- skills
def grasp_kind(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


def placed_ok(api, item, name):
    try:
        ip, tp = P(api, item), P(api, name)
    except Exception:
        return False
    tol = 0.07
    if 'basket' in name or 'contain' in name:
        tol = 0.08
    if 'caddy' in name:
        tol = 0.045
    if name.endswith('_side'):
        tol = 0.10
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.05


def recover(api):
    try:
        api.grip(False)
        e = E(api)
        api.move(e + V(0, 0, 0.12), steps=15)
    except Exception:
        pass


def do_place(api, item, tgt):
    name = tgt[0]
    kind = grasp_kind(item)
    for attempt in range(2):
        try:
            api.place_with(item, name, kind)
        except Exception:
            pass
        if placed_ok(api, item, name):
            return True
        recover(api)
    # last resort: generic transfer
    g = (0.0, 0.06, 0.025) if kind == 'rim' else (0.0, 0.0, 0.0)
    z = 0.10 if name.endswith('_side') else 0.08
    try:
        api.transfer(item, name, grasp=g, drop=(0.0, 0.0, z))
    except Exception:
        pass
    if placed_ok(api, item, name):
        return True
    recover(api)
    return False


def pick_only(api, item):
    p = P(api, item)
    if 'bowl' in _base(item):
        p = p + V(0, 0.06, 0.025)
    api.grip(False)
    api.move(p + V(0, 0, 0.12), steps=30)
    api.move(p, steps=25)
    api.grip(True)
    api.move(p + V(0, 0, 0.15), steps=25)


def twist_knob(api, k, grasp_z, on):
    sgn = 1.0 if on else -1.0
    api.grip(False)
    e = E(api)
    api.move(V(e[0], e[1], max(e[2], grasp_z + 0.15)), steps=15)
    api.move(V(k[0], k[1], grasp_z + 0.10), steps=25)
    api.move(V(k[0], k[1], grasp_z), steps=20)
    api.grip(True)
    api.action([0, 0, 0, 0, 0, 0.35 * sgn, 1.0], steps=12)
    api.grip(False)
    e = E(api)
    api.move(e + V(0, 0, 0.10), steps=12)
    api.action([0, 0, 0, 0, 0, -0.35 * sgn, -1.0], steps=12)


def sweep_stove(api, sp, cp, on):
    sgn = 1.0 if on else -1.0
    e = E(api)
    api.move(V(e[0], e[1], max(e[2], cp[2] + 0.15)), steps=15)
    api.grip(True)
    lines = [(cp[0] - 0.07, cp[2] + 0.015),
             (min(sp[0], cp[0]) - 0.13, max(cp[2] - 0.015, sp[2] + 0.012))]
    for x, z in lines:
        a = V(x, cp[1] + 0.13 * sgn, z)
        b = V(x, cp[1] - 0.13 * sgn, z)
        api.move(V(a[0], a[1], cp[2] + 0.12), steps=25)
        api.move(a, steps=20)
        api.move(b, steps=45)
        api.move(V(b[0], b[1], cp[2] + 0.12), steps=15)


def turn_stove(api, stove, names, on):
    kp = None
    for n in names:
        if n.startswith(_base(stove)) and any(k in n for k in ('knob', 'button', 'switch')):
            try:
                kp = P(api, n)
                break
            except Exception:
                pass
    cook = [n for n in names if n.startswith(stove + '_') and 'cook' in n]
    sp = P(api, stove)
    cp = P(api, cook[0]) if cook else sp + V(0, 0, 0.02)
    if kp is not None:
        twist_knob(api, kp, kp[2] + 0.005, on)
        return
    d = sp[:2] - cp[:2]
    nd = np.linalg.norm(d)
    if nd >= 0.025:
        if nd > 0.15:
            d = d / nd * 0.15
        k = V(sp[0] + d[0], sp[1] + d[1], cp[2])
        twist_knob(api, k, cp[2] + 0.005, on)
        return
    sweep_stove(api, sp, cp, on)


# ---------------------------------------------------------------- main
def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    words = _words(api.instruction)
    try:
        ops = build_plan(api, names, bodies, words)
    except Exception:
        ops = []
    if not ops:
        api.fallback()
        return
    for op in ops:
        try:
            kind = op[0]
            if kind == 'turn':
                turn_stove(api, op[1], names, op[2])
            elif kind == 'place':
                do_place(api, op[1], op[2])
            elif kind in ('open', 'close'):
                reg = drawer_region(names, op[1], op[2] if len(op) > 2 else words)
                api.drawer(reg, kind)
                recover(api)
            elif kind == 'pick':
                pick_only(api, op[1])
        except Exception:
            recover(api)
