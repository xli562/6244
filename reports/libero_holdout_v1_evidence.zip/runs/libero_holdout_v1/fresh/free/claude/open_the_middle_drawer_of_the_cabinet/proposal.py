import math
import numpy as np

# ================================================================ vocabulary
ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl',
    'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup',
    'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup',
    'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop',
    'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy',
    'black_book': 'black book', 'yellow_book': 'yellow book',
    'cream_cheese': 'cream cheese box', 'alphabet_soup': 'alphabet soup can',
    'tomato_sauce': 'tomato sauce can', 'bbq_sauce': 'bbq barbecue sauce bottle',
    'ketchup': 'ketchup bottle', 'butter': 'butter box', 'milk': 'milk carton',
    'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box',
    'salad_dressing': 'salad dressing bottle',
    'new_salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet drawer drawers',
    'wooden_cabinet': 'wooden cabinet drawer drawers',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack',
    'microwave': 'microwave oven', 'basket': 'basket', 'plate': 'plate',
    'glazed_rim_porcelain_ramekin': 'ramekin',
    'cookies': 'cookie cookies box', 'wooden_tray': 'wooden tray',
    'wooden_two_layer_shelf': 'wooden shelf',
    'white_storage_box': 'white storage box',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown',
          'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'top',
        'left', 'right', 'front', 'back', 'bottom', 'middle', 'compartment',
        'side', 'its', 'that', 'is', 'please', 'then', 'layer', 'level', 'tier',
        'upper', 'lower', 'second', 'third', 'lowest', 'highest', 'uppermost',
        'next', 'near', 'beside', 'between', 'from', 'on', 'in', 'at', 'by',
        'inside', 'into', 'onto', 'with', 'behind', 'rear', 'center', 'centre',
        'section', 'part', 'slot', 'one', 'which', 'located', 'placed', 'sitting'}
VERBS = {'put', 'place', 'turn', 'switch', 'close', 'shut', 'open', 'pick',
         'push', 'pull', 'move', 'stack', 'lift', 'grab', 'take', 'set', 'get',
         'bring', 'slide', 'drop', 'insert'}
PICKV = {'pick', 'grab', 'lift', 'take', 'get'}
PREPS = ('into', 'onto', 'inside', 'in', 'on', 'to', 'next', 'beside', 'near',
         'behind', 'at', 'over', 'above')
QUAL = {'on', 'in', 'inside', 'next', 'near', 'beside', 'between', 'from', 'at',
        'by', 'under', 'closest', 'nearest', 'behind', 'which', 'that'}
DIRS = {'left': 'left', 'right': 'right', 'front': 'front', 'back': 'back',
        'behind': 'back', 'rear': 'back'}
LEVELS = {'top': 'top', 'upper': 'top', 'uppermost': 'top', 'topmost': 'top',
          'highest': 'top', 'middle': 'middle', 'center': 'middle',
          'centre': 'middle', 'central': 'middle', 'second': 'middle',
          'bottom': 'bottom', 'lower': 'bottom', 'lowest': 'bottom',
          'bottommost': 'bottom', 'third': 'bottom'}
DRAWER_ONLY = {'drawer', 'drawers', 'layer', 'level', 'tier'}
PARTS = {'compartment', 'compartments', 'section', 'slot', 'part', 'side',
         'corner', 'half', 'area', 'portion', 'spot'}
INSIDE_PARTS = {'compartment', 'compartments', 'section', 'slot', 'inside',
                'interior'}


def V(*a):
    return np.array(a, dtype=float)


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def E(api):
    return np.array(api.eef(), dtype=float)


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _words(s):
    s = ''.join(c if c.isalnum() else ' ' for c in s.lower())
    return s.split()


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return w


# ================================================================ resolution
def resolve_list(api, names, bodies, raw, exclude=()):
    W = set(w for w in raw if w not in STOP)
    W |= set(w[:-1] for w in list(W) if w.endswith('s') and len(w) > 3)
    if not W:
        return []
    best, cands = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, cands = s, [b]
        elif abs(s - best) < 1e-9:
            cands.append(b)
    return cands


def _spatial(api, names, raw, cands):
    for w in ('left', 'right', 'front', 'back'):
        if w in raw:
            head = _base(cands[0]).split('_')[-1]
            hints = [n for n in names if _is_region(n)
                     and w in n.split('_') and head in n.split('_')]
            if hints:
                hp = P(api, hints[0])
                return sorted(cands, key=lambda c: np.linalg.norm(P(api, c)[:2] - hp[:2]))
            keyf = {'left': lambda p: -p[1], 'right': lambda p: p[1],
                    'front': lambda p: p[0], 'back': lambda p: -p[0]}[w]
            return sorted(cands, key=lambda c: keyf(P(api, c)))
    return sorted(cands)


def resolve(api, names, bodies, raw, exclude=()):
    c = resolve_list(api, names, bodies, raw, exclude)
    if not c:
        return None
    if len(c) > 1:
        c = _spatial(api, names, raw, c)
    return c[0]


def resolve_target(api, names, bodies, raw):
    obj = resolve(api, names, bodies, raw)
    if obj is None:
        return None
    regs = [n for n in names if _is_region(n) and n.startswith(obj + '_')]
    if not regs:
        return (obj, obj)
    R = set(raw)
    drawer = 'drawer' in R or 'drawers' in R
    best, bs = None, -1e9
    for r in regs:
        suf = r[len(obj) + 1:].split('_')
        toks = set(suf) - {'region', 'contain', 'side'}
        s = 3 * len(toks & R)
        if drawer and 'side' in suf:
            s -= 5
        if (not drawer) and 'top' in R and 'side' in suf:
            s += 2
        if not toks or toks <= {'cook', 'heating'}:
            s += 1
        if s > bs:
            bs, best = s, r
    return (best, obj)


def drawer_owners(names, bodies):
    out = []
    for b in bodies:
        k = sum(1 for l in ('top', 'middle', 'bottom') if b + '_' + l + '_region' in names)
        if k >= 2 or (k >= 1 and ('cabinet' in b or 'drawer' in b)):
            out.append(b)
    return out


def drawer_target(api, names, bodies, ws, prep=None, mode=None):
    owners = drawer_owners(names, bodies)
    if not owners:
        return None
    T = set(ws)
    hasdrawer = bool(T & DRAWER_ONLY)
    if not (hasdrawer or T & {'cabinet', 'dresser', 'cupboard'}):
        return None
    r0 = resolve(api, names, bodies, ws)
    if r0 is not None and r0 not in owners:
        return None            # e.g. "top layer of the wine rack"
    owner = r0 if r0 in owners else owners[0]
    side = owner + '_top_side'
    if mode is None and not hasdrawer and side in names and prep not in ('in', 'into', 'inside'):
        return (side, owner)
    lvl = None
    for w in ws:
        if w in LEVELS:
            lvl = LEVELS[w]
            break
    regs = [owner + '_' + l + '_region' for l in ('top', 'middle', 'bottom')
            if owner + '_' + l + '_region' in names]
    if not regs:
        return None
    r = owner + '_' + lvl + '_region' if lvl else None
    if r not in regs:
        if mode == 'close' and len(regs) > 1:
            op = P(api, owner)
            r = max(regs, key=lambda g: np.linalg.norm(P(api, g)[:2] - op[:2]))
        else:
            r = regs[0]
    return (r, owner)


def spatial_target(api, names, bodies, tw, prep):
    d, i = None, None
    if prep == 'behind':
        d = 'back'
    for j, w in enumerate(tw):
        if w in DIRS:
            d, i = DIRS[w], j
            break
    if d is None:
        return None
    nxt = tw[i + 1] if (i is not None and i + 1 < len(tw)) else ''
    if i is not None and prep not in ('behind', 'to', 'next', 'beside', 'near') \
            and nxt not in PARTS and nxt != 'of':
        return None            # direction used as adjective ("the right bowl")
    if set(tw) & INSIDE_PARTS:
        rel = 'inside'
    elif nxt == 'of' or prep in ('to', 'next', 'beside', 'near', 'behind'):
        rel = 'outside'
    elif prep in ('in', 'into', 'inside'):
        rel = 'inside'
    else:
        rel = 'outside'
    refw = [w for w in tw if w not in DIRS and w not in PARTS and w != 'of']
    ref = resolve(api, names, bodies, refw)
    if ref is None:
        return None
    try:
        r = api.relative_target(ref, d, rel)
        if r:
            P(api, r)
            return (r, ref)
    except Exception:
        pass
    toks = _base(ref).split('_')
    hints = [n for n in names if _is_region(n) and d in n.split('_')
             and any(t in n.split('_') for t in toks)]
    if hints:
        rp = P(api, ref)
        h = min(hints, key=lambda n: np.linalg.norm(P(api, n)[:2] - rp[:2]))
        return (h, ref)
    return None


def place_target(api, names, bodies, tw, prep):
    tw = list(tw)
    while tw and tw[0] in ('to', 'of'):
        tw = tw[1:]
    for f in (spatial_target, drawer_target):
        try:
            r = f(api, names, bodies, tw, prep)
        except Exception:
            r = None
        if r:
            return r
    return resolve_target(api, names, bodies, tw)


def disambiguate(api, names, bodies, cands, qual):
    q = qual[0]
    rest = list(qual[1:])
    while rest and rest[0] in ('to', 'of', 'is', 'the'):
        rest = rest[1:]
    others = [b for b in bodies if b not in cands]
    if q == 'between':
        parts = [[]]
        for w in rest:
            if w == 'and':
                parts.append([])
            else:
                parts[-1].append(w)
        pts = []
        for p in parts:
            r = resolve(api, names, others, p)
            if r:
                pts.append(P(api, r))
        if not pts:
            return None
        c = np.mean(pts, axis=0)
        return min(cands, key=lambda b: np.linalg.norm(P(api, b)[:2] - c[:2]))
    if q in ('which', 'that') and rest and rest[0] in QUAL:
        q, rest = rest[0], rest[1:]
    t = place_target(api, names, others, rest, q)
    if not t:
        return None
    try:
        r = api.nearest(t[0], list(cands))
        if r in cands:
            return r
    except Exception:
        pass
    c = P(api, t[0])
    return min(cands, key=lambda b: np.linalg.norm(P(api, b) - c))


def resolve_item(api, names, bodies, ws, exclude=()):
    ws = [w for w in ws if w != 'up']
    qi = None
    for i, w in enumerate(ws):
        if i > 0 and w in QUAL and any(x not in STOP for x in ws[:i]):
            qi = i
            break
    head = ws if qi is None else ws[:qi]
    qual = [] if qi is None else ws[qi:]
    cands = resolve_list(api, names, bodies, head, exclude) or \
        resolve_list(api, names, bodies, ws, exclude)
    if not cands:
        return None
    if len(cands) == 1:
        return cands[0]
    if qual:
        try:
            r = disambiguate(api, names, bodies, cands, qual)
            if r:
                return r
        except Exception:
            pass
    return _spatial(api, names, ws, cands)[0]


# ================================================================ parsing
def split_clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if (w == 'and' and (nxt in VERBS or nxt == 'then')) or w == 'then':
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return [c for c in out if c]


def split_items(ws):
    both = 'both' in ws
    has_the = any(ws[j] == 'and' and j + 1 < len(ws) and ws[j + 1] in ('the', 'a')
                  for j in range(len(ws)))
    parts = [[]]
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if w == 'and' and ((has_the and nxt in ('the', 'a')) or (both and not has_the)):
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def build_plan(api, names, bodies, words):
    ops = []
    last_items, last_target, last_fix, last_stack = [], None, None, None
    owners = drawer_owners(names, bodies)
    for c in split_clauses(words):
        while c and c[-1] == 'and':
            c = c[:-1]
        vi = next((i for i, w in enumerate(c) if w in VERBS), None)
        if vi is None:
            continue
        v, rest = c[vi], c[vi + 1:]
        if v in ('turn', 'switch'):
            on = 'off' not in rest
            ow = [w for w in rest if w not in ('on', 'off')]
            obj = last_fix if (not ow or ow == ['it']) else resolve(api, names, bodies, ow)
            if obj:
                ops.append(('turn', obj, on))
                last_fix = obj
            continue
        if v in ('close', 'shut', 'open'):
            mode = 'open' if v == 'open' else 'close'
            if not rest or rest in (['it'], ['them']):
                tgt = last_target
            else:
                tgt = drawer_target(api, names, bodies, rest, None, mode) or \
                    resolve_target(api, names, bodies, rest)
            if tgt:
                is_dr = tgt[1] in owners and tgt[0] != tgt[1] and not tgt[0].endswith('_side')
                ops.append((mode, tgt, is_dr))
                last_target, last_fix = tgt, tgt[1]
            continue
        rest = [w for w in rest if w != 'up']
        has_dest = any(w in ('into', 'onto') or
                       (w == 'to' and (i == 0 or rest[i - 1] != 'next'))
                       for i, w in enumerate(rest))
        if v in PICKV and not has_dest:
            it = resolve_item(api, names, bodies, rest)
            if it:
                ops.append(('pick', it))
                last_items = [it]
            continue
        idx = None
        for i, w in enumerate(rest):
            if w in PREPS and i > 0:
                if v in PICKV and w not in ('into', 'onto', 'to'):
                    continue
                idx = i
                break
        if idx is None:
            item_w, tw, prep = rest, [], None
        else:
            item_w, tw, prep = rest[:idx], rest[idx + 1:], rest[idx]
        if not tw or tw in (['it'], ['them']):
            tgt = last_target or ((last_fix, last_fix) if last_fix else None)
        else:
            tgt = place_target(api, names, bodies, tw, prep)
        if tgt is None:
            continue
        items, stack_top = [], None
        for part in split_items(item_w):
            if part == ['it']:
                cand = last_items[-1:]
            elif part == ['them']:
                if last_stack:
                    cand, stack_top = [last_stack[1]], last_stack[0]
                else:
                    cand = list(last_items)
            else:
                r = resolve_item(api, names, bodies, part, exclude=(tgt[1],))
                cand = [r] if r else []
            for it in cand:
                if it and it not in items and it != tgt[1]:
                    items.append(it)
        if not items:
            continue
        while ops and ops[-1][0] == 'pick' and ops[-1][1] in items:
            ops.pop()
        for k, it in enumerate(items):
            ops.append(('place', it, tgt, k, len(items), v == 'push',
                        stack_top if k == 0 else None))
        last_items, last_target, last_fix = items, tgt, tgt[1]
        last_stack = (items[-1], tgt[1]) if (tgt[0] == tgt[1] and len(items) == 1) else None
    return ops


# ================================================================ skills
def grasp_kind(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


def grasp_options(item):
    b = _base(item)
    if 'mug' in b or 'cup' in b:
        return [(0.0, 0.03, 0.02), (0.0, -0.03, 0.02)]
    if 'bowl' in b:
        return [(0.0, 0.06, 0.025), (0.0, -0.06, 0.025)]
    return [(0.0, 0.0, 0.0), (0.0, 0.0, -0.01)]


def placed_ok(api, item, name):
    try:
        ip, tp = P(api, item), P(api, name)
    except Exception:
        return False
    tol = 0.07
    if 'basket' in name or 'contain' in name or 'drawer' in name or \
            name.endswith(('_top_region', '_middle_region', '_bottom_region')):
        tol = 0.08
    if 'caddy' in name:
        tol = 0.05
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.06


def recover(api):
    try:
        api.grip(False)
        e = E(api)
        api.move(e + V(0, 0, 0.12), steps=15)
    except Exception:
        pass


def place_item(api, item, name):
    kind = grasp_kind(item)
    for attempt in range(2):
        try:
            api.place_with(item, name, kind)
        except Exception:
            try:
                api.arrange([(item, name)])
            except Exception:
                try:
                    api.transfer(item, name, grasp=grasp_options(item)[0])
                except Exception:
                    pass
        if placed_ok(api, item, name):
            return True
        recover(api)
    return False


def push_obj(api, item, name):
    for _ in range(2):
        ip, tp = P(api, item), P(api, name)
        d = tp[:2] - ip[:2]
        dist = np.linalg.norm(d)
        if dist < 0.035:
            return True
        u = d / dist
        r = 0.09 if 'plate' in item else 0.06
        z = ip[2] + 0.012
        s = ip[:2] - u * (r + 0.04)
        g = tp[:2] - u * r
        e = E(api)
        high = max(e[2], ip[2] + 0.15)
        api.grip(True)
        api.move(V(e[0], e[1], high), steps=12)
        api.move(V(s[0], s[1], high), steps=25)
        api.move(V(s[0], s[1], z), steps=20)
        api.move(V(g[0], g[1], z), steps=50)
        e = E(api)
        api.move(V(e[0], e[1], high), steps=12)
    return placed_ok(api, item, name)


def pick_only(api, item):
    p = P(api, item) + V(*grasp_options(item)[0])
    api.grip(False)
    api.move(p + V(0, 0, 0.12), steps=30)
    api.move(p, steps=25)
    api.grip(True)
    api.move(p + V(0, 0, 0.15), steps=25)


def drawer_dir(api, region, owner):
    rp = P(api, region)
    op = P(api, owner) if owner else rp
    d = op[:2] - rp[:2]
    nd = np.linalg.norm(d)
    d = d / nd if nd > 0.03 else np.array([1.0, 0.0])
    return np.array([d[0], d[1], 0.0])


def push_close(api, tgt):
    name, owner = tgt
    rp = P(api, name)
    d3 = drawer_dir(api, name, owner)
    start = rp - d3 * 0.20
    start[2] = rp[2] + 0.03
    e = E(api)
    high = max(e[2], rp[2] + 0.15)
    api.move(V(e[0], e[1], high), steps=15)
    api.move(V(start[0], start[1], high), steps=30)
    api.grip(True)
    api.move(start, steps=25)
    api.move(start + d3 * 0.32, steps=60)
    back = start + d3 * 0.20
    api.move(back, steps=10)
    api.move(back + V(0, 0, 0.12), steps=15)


def pull_open(api, tgt):
    name, owner = tgt
    rp = P(api, name)
    d3 = drawer_dir(api, name, owner)
    handle = rp - d3 * 0.13
    handle[2] = rp[2] + 0.04
    pre = handle - d3 * 0.08
    e = E(api)
    api.grip(False)
    api.move(V(e[0], e[1], max(e[2], handle[2] + 0.12)), steps=15)
    api.move(pre + V(0, 0, 0.10), steps=30)
    api.move(pre, steps=20)
    api.move(handle, steps=20)
    api.grip(True)
    api.move(handle - d3 * 0.22, steps=50)
    api.grip(False)
    e = E(api)
    api.move(e + V(0, 0, 0.10), steps=15)


def operate(api, kind, tgt, is_drawer):
    if is_drawer:
        try:
            api.drawer(tgt[0], kind)
            return
        except Exception:
            recover(api)
    if kind == 'open':
        pull_open(api, tgt)
    else:
        push_close(api, tgt)


def twist_knob(api, k, grasp_z, on):
    sgn = 1.0 if on else -1.0
    api.grip(False)
    e = E(api)
    api.move(V(e[0], e[1], max(e[2], grasp_z + 0.15)), steps=15)
    api.move(V(k[0], k[1], grasp_z + 0.10), steps=25)
    api.move(V(k[0], k[1], grasp_z), steps=20)
    api.grip(True)
    api.action([0, 0, 0, 0, 0, 0.35 * sgn, 1.0], steps=12)
    api.grip(False)
    e = E(api)
    api.move(e + V(0, 0, 0.10), steps=12)
    api.action([0, 0, 0, 0, 0, -0.35 * sgn, -1.0], steps=12)


def sweep_stove(api, sp, cp, on):
    sgn = 1.0 if on else -1.0
    e = E(api)
    api.move(V(e[0], e[1], max(e[2], cp[2] + 0.15)), steps=15)
    api.grip(True)
    lines = [(cp[0] - 0.07, cp[2] + 0.015),
             (min(sp[0], cp[0]) - 0.13, max(cp[2] - 0.015, sp[2] + 0.012))]
    for x, z in lines:
        a = V(x, cp[1] + 0.13 * sgn, z)
        b = V(x, cp[1] - 0.13 * sgn, z)
        api.move(V(a[0], a[1], cp[2] + 0.12), steps=25)
        api.move(a, steps=20)
        api.move(b, steps=45)
        api.move(V(b[0], b[1], cp[2] + 0.12), steps=15)


def turn_stove(api, stove, names, on):
    kp = None
    for n in names:
        if n.startswith(_base(stove)) and any(k in n for k in ('knob', 'button', 'switch')):
            try:
                kp = P(api, n)
                break
            except Exception:
                pass
    cook = [n for n in names if n.startswith(stove + '_') and 'cook' in n]
    sp = P(api, stove)
    cp = P(api, cook[0]) if cook else sp + V(0, 0, 0.02)
    if kp is not None:
        twist_knob(api, kp, kp[2] + 0.005, on)
        return
    d = sp[:2] - cp[:2]
    nd = np.linalg.norm(d)
    if nd >= 0.025:
        if nd > 0.15:
            d = d / nd * 0.15
        k = V(sp[0] + d[0], sp[1] + d[1], cp[2])
        twist_knob(api, k, cp[2] + 0.005, on)
        return
    sweep_stove(api, sp, cp, on)


def exec_op(api, op, names):
    kind = op[0]
    if kind == 'turn':
        turn_stove(api, op[1], names, op[2])
    elif kind in ('open', 'close'):
        operate(api, kind, op[1], op[2])
    elif kind == 'pick':
        pick_only(api, op[1])
    elif kind == 'place':
        _, item, tgt, k, n, push, stack_top = op
        name = tgt[0]
        done = False
        if push:
            try:
                done = push_obj(api, item, name)
            except Exception:
                recover(api)
        if not done:
            place_item(api, item, name)
        if stack_top and not placed_ok(api, stack_top, name):
            # top of the stack fell off: put it back on the moved base
            place_item(api, stack_top, item)


# ================================================================ main
def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    words = _words(api.instruction)
    try:
        ops = build_plan(api, names, bodies, words)
    except Exception:
        ops = []
    if not ops:
        try:
            api.fallback()
        except Exception:
            pass
        return

    for op in ops:
        try:
            exec_op(api, op, names)
        except Exception:
            recover(api)

    # episode still running => something failed; one corrective pass
    places = [op for op in ops if op[0] == 'place']
    if places:
        for op in places:
            try:
                if not placed_ok(api, op[1], op[2][0]):
                    exec_op(api, op, names)
            except Exception:
                recover(api)
    else:
        for op in ops:
            try:
                exec_op(api, op, names)
            except Exception:
                recover(api)
