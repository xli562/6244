import math
import numpy as np

# ------------------------------------------------------------------ vocabulary
ALIAS = {
    'akita_black_bowl': 'black bowl',
    'black_bowl': 'black bowl',
    'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup',
    'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup',
    'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop',
    'moka_pot': 'moka pot',
    'desk_caddy': 'desk caddy',
    'black_book': 'black book',
    'yellow_book': 'yellow book',
    'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can',
    'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle',
    'ketchup': 'ketchup bottle',
    'butter': 'butter box',
    'milk': 'milk carton',
    'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box',
    'salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet drawer drawers layer',
    'wooden_cabinet': 'wooden cabinet drawer drawers layer',
    'wine_bottle': 'wine bottle',
    'wine_rack': 'wine rack',
    'microwave': 'microwave oven',
    'basket': 'basket',
    'plate': 'plate',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown',
          'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'top',
        'left', 'right', 'front', 'back', 'bottom', 'middle', 'compartment',
        'side', 'its', 'that', 'is', 'please', 'then', 'behind', 'next'}
VERBS = {'put', 'place', 'turn', 'switch', 'close', 'shut', 'open', 'pick',
         'push', 'pull', 'move', 'stack', 'lift', 'grab', 'take', 'set'}
PREPS = ('into', 'onto', 'inside', 'in', 'on', 'to', 'behind', 'under')
DIRS = ('left', 'right', 'front', 'back', 'behind')


def V(*a):
    return np.array(a, dtype=float)


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def E(api):
    return np.array(api.eef(), dtype=float)


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _words(s):
    s = ''.join(c if c.isalnum() else ' ' for c in s.lower())
    return s.split()


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return w


# ------------------------------------------------------------------ resolution
def _spatial(api, names, raw, cands):
    for w in ('left', 'right', 'front', 'back'):
        if w in raw:
            head = _base(cands[0]).split('_')[-1]
            hints = [n for n in names if _is_region(n)
                     and w in n.split('_') and head in n.split('_')]
            if hints:
                hp = P(api, hints[0])
                return sorted(cands, key=lambda c: np.linalg.norm(P(api, c)[:2] - hp[:2]))
            keyf = {'left': lambda p: -p[1], 'right': lambda p: p[1],
                    'front': lambda p: p[0], 'back': lambda p: -p[0]}[w]
            return sorted(cands, key=lambda c: keyf(P(api, c)))
    return sorted(cands)


def resolve(api, names, bodies, raw, exclude=()):
    W = set(w for w in raw if w not in STOP)
    if not W:
        return None
    best, cands = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, cands = s, [b]
        elif abs(s - best) < 1e-9:
            cands.append(b)
    if not cands:
        return None
    if len(cands) > 1:
        try:
            cands = _spatial(api, names, raw, cands)
        except Exception:
            cands = sorted(cands)
    return cands[0]


def resolve_target(api, names, bodies, raw):
    """returns (target_name, owner_body)"""
    obj = resolve(api, names, bodies, raw)
    if obj is None:
        return None
    regs = [n for n in names if _is_region(n) and n.startswith(obj + '_')]
    if not regs:
        return (obj, obj)
    R = set(raw)
    drawer = bool(R & {'drawer', 'drawers', 'layer', 'compartment', 'inside', 'into', 'in'}) \
        and 'cabinet' in obj or bool(R & {'drawer', 'drawers', 'layer'})
    level_given = bool(R & {'top', 'middle', 'bottom'})
    best, bs = None, -1e9
    for r in regs:
        suf = r[len(obj) + 1:].split('_')
        toks = set(suf) - {'region', 'contain', 'side'}
        s = 3 * len(toks & R)
        if drawer and 'side' in suf:
            s -= 5
        if (not drawer) and 'top' in R and 'side' in suf:
            s += 2
        if not toks or toks <= {'cook', 'heating'}:
            s += 1
        if drawer and not level_given and 'top' in toks and 'side' not in suf:
            s += 0.5
        if s > bs:
            bs, best = s, r
    return (best, obj)


def relative_or_resolve(api, names, bodies, tw):
    """handle 'left compartment of X' (inside) and 'to the left of X' (outside)"""
    d = None
    for j, w in enumerate(tw):
        if w in DIRS:
            d = (j, 'back' if w == 'behind' else w)
            break
    if d is not None:
        j, direction = d
        nxt = tw[j + 1] if j + 1 < len(tw) else ''
        relation = None
        if 'compartment' in tw or 'compartments' in tw:
            relation = 'inside'
        elif nxt == 'of' or tw[j] == 'behind' or (nxt == 'side' and 'of' in tw[j:]):
            relation = 'outside'
        if relation:
            rest = [w for w in tw if w not in DIRS]
            ref = resolve(api, names, bodies, rest)
            if ref is not None:
                try:
                    reg = api.relative_target(ref, direction, relation)
                    if reg:
                        return (reg, ref)
                except Exception:
                    pass
    return resolve_target(api, names, bodies, tw)


# ------------------------------------------------------------------ parsing
def split_clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if (w == 'and' and (nxt in VERBS or nxt == 'then')) or w == 'then':
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return [c for c in out if c]


def split_items(ws):
    both = 'both' in ws
    has_the = any(ws[j] == 'and' and j + 1 < len(ws) and ws[j + 1] in ('the', 'a')
                  for j in range(len(ws)))
    parts = [[]]
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if w == 'and' and ((has_the and nxt in ('the', 'a')) or (both and not has_the)):
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def build_plan(api, names, bodies, words):
    ops = []
    last_item, last_target, last_fix = None, None, None
    for c in split_clauses(words):
        while c and c[-1] == 'and':
            c = c[:-1]
        if not c:
            continue
        v, rest = c[0], c[1:]
        if v in ('turn', 'switch'):
            on = 'off' not in rest
            ow = [w for w in rest if w not in ('on', 'off')]
            obj = last_fix if (not ow or ow == ['it']) else resolve(api, names, bodies, ow)
            ops.append(('turn', obj, on))
            last_fix = obj
            continue
        if v in ('close', 'shut', 'open'):
            if not rest or rest == ['it'] or rest == ['them']:
                tgt = last_target
            else:
                tgt = resolve_target(api, names, bodies, rest)
            if tgt:
                ops.append(('open' if v == 'open' else 'close', tgt))
                last_target = tgt
                last_fix = tgt[1]
            continue
        rest = [w for w in rest if w != 'up']
        idx = None
        for i, w in enumerate(rest):
            if w in PREPS and i > 0:
                idx = i
                break
        # 'in front of' / 'to the left of': keep the preposition word with target
        if v in ('pick', 'grab', 'lift', 'take') and idx is None:
            it = resolve(api, names, bodies, rest)
            if it:
                ops.append(('pick', it))
                last_item = it
            continue
        if idx is None:
            item_w, tw = rest, []
        else:
            item_w, tw = rest[:idx], rest[idx + 1:]
            if rest[idx] == 'behind':
                tw = ['behind'] + tw
        if not tw or tw in (['it'], ['them']):
            if tw and last_fix:
                tgt = resolve_target(api, names, bodies, _base(last_fix).split('_'))
                if tgt is None or tgt[1] != last_fix:
                    tgt = (last_fix, last_fix)
            else:
                tgt = last_target
        else:
            tgt = relative_or_resolve(api, names, bodies, tw)
        if tgt is None:
            continue
        items = []
        for part in split_items(item_w):
            if part in (['it'], ['them']):
                it = last_item
            else:
                it = resolve(api, names, bodies, part, exclude=(tgt[1],))
            if it and it not in items:
                items.append(it)
        if not items and last_item:
            items = [last_item]
        if ops and ops[-1][0] == 'pick' and ops[-1][1] in items:
            ops.pop()
        for it in items:
            ops.append(('place', it, tgt))
        if items:
            last_item = items[-1]
        last_target = tgt
        last_fix = tgt[1]
    return ops


# ------------------------------------------------------------------ skills
def grasp_kind(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


def placed_ok(api, item, name):
    try:
        ip, tp = P(api, item), P(api, name)
    except Exception:
        return True
    tol = 0.08
    if 'caddy' in name:
        tol = 0.05
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.07


def recover(api):
    try:
        api.grip(False)
        e = E(api)
        api.move(e + V(0, 0, 0.10), steps=12)
    except Exception:
        pass


def do_place(api, item, tgt):
    name = tgt[0]
    kind = grasp_kind(item)
    tries = [kind] + (['standard'] if kind == 'rim' else [kind])
    for g in tries:
        try:
            api.place_with(item, name, g)
        except Exception:
            recover(api)
        if placed_ok(api, item, name):
            return True
        recover(api)
    return False


def pick_only(api, item):
    p = P(api, item)
    api.grip(False)
    api.move(p + V(0, 0, 0.12), steps=30)
    api.move(p, steps=25)
    api.grip(True)
    api.move(p + V(0, 0, 0.15), steps=25)


def drawer_region(names, tgt):
    """make sure a drawer action uses the named compartment, not top_side"""
    name, owner = tgt
    if name.endswith('_side') or name == owner:
        for lvl in ('top', 'middle', 'bottom'):
            cand = owner + '_' + lvl + '_region'
            if cand in names:
                return cand
    return name


# ------------------------------------------------------------------ main
def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    words = _words(api.instruction)
    try:
        ops = build_plan(api, names, bodies, words)
    except Exception:
        ops = []
    # unsupported actions (knobs / stoves etc.) or nothing parsed -> old policy
    if not ops or any(op[0] == 'turn' for op in ops):
        api.fallback()
        return
    for op in ops:
        try:
            kind = op[0]
            if kind in ('open', 'close'):
                api.drawer(drawer_region(names, op[1]), kind)
            elif kind == 'place':
                do_place(api, op[1], op[2])
            elif kind == 'pick':
                pick_only(api, op[1])
        except Exception:
            recover(api)
