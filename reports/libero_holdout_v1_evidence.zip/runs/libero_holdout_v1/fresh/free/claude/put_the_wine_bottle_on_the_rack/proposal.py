import math
import numpy as np


def V(*a):
    return np.array(a, dtype=float)


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def E(api):
    return np.array(api.eef(), dtype=float)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _safe_pos(api, n):
    try:
        return P(api, n)
    except Exception:
        return None


# ------------------------------------------------------------ task detection
def bottle_task(api, names, words):
    """Single-clause 'put/place the wine bottle on <rack|cabinet top>'."""
    W = set(words)
    if not ({'put', 'place', 'set', 'move'} & W):
        return None
    if 'then' in W or ({'open', 'close', 'shut', 'turn', 'switch'} & W):
        return None
    if 'bottle' not in W:
        return None
    # exactly one movable item mentioned before the preposition
    prep = None
    for i, w in enumerate(words):
        if w in ('on', 'onto', 'in', 'into', 'inside') and i > 0:
            prep = i
            break
    if prep is None:
        return None
    item_w, tgt_w = set(words[:prep]), set(words[prep + 1:])
    if 'and' in item_w or 'bottle' not in item_w:
        return None
    bottles = [n for n in names if not _is_region(n) and 'wine_bottle' in n]
    if not bottles:
        return None
    bottle = sorted(bottles)[0]
    target = None
    if 'rack' in tgt_w:
        regs = sorted(n for n in names if 'wine_rack' in n and _is_region(n)
                      and not n.startswith('main_table'))
        tops = [r for r in regs if 'top' in r]
        target = (tops or regs or [None])[0]
        if target is None:
            racks = [n for n in names if not _is_region(n) and 'wine_rack' in n]
            target = racks[0] if racks else None
    elif 'cabinet' in tgt_w and ('top' in tgt_w or 'on' in words[prep:prep + 1]):
        sides = sorted(n for n in names if 'cabinet' in n and n.endswith('_top_side'))
        if 'white' in tgt_w:
            sides = [s for s in sides if 'white' in s] or sides
        if 'wooden' in tgt_w:
            sides = [s for s in sides if 'wooden' in s] or sides
        target = sides[0] if sides else None
    if target is None:
        return None
    return bottle, target


# ------------------------------------------------------------ bottle skill
def recover(api):
    api.grip(False)
    e = E(api)
    api.move(e + V(0, 0, 0.10), steps=10)


def bottle_height_offset(api, names, bottle):
    """Height of the body origin above the surface it stands on."""
    p = P(api, bottle)
    for n in names:
        if n.startswith('main_table') and 'wine_bottle' in n:
            r = _safe_pos(api, n)
            if r is not None and abs(r[0] - p[0]) < 0.25 and abs(r[1] - p[1]) < 0.25:
                return float(np.clip(p[2] - r[2], 0.0, 0.15))
    return 0.0


def placed_ok(api, bottle, target):
    bp, tp = P(api, bottle), P(api, target)
    return np.linalg.norm(bp[:2] - tp[:2]) < 0.07 and bp[2] > tp[2] - 0.05


def grasp_bottle(api, bottle, dz):
    p0 = P(api, bottle)
    g = p0 + V(0, 0, dz)
    api.grip(False)
    e = E(api)
    safe = max(e[2], g[2] + 0.12)
    api.move(V(e[0], e[1], safe), steps=10)
    api.move(V(g[0], g[1], safe), steps=22)
    api.move(g + V(0, 0, 0.03), steps=12)
    api.move(g, steps=10)
    api.grip(True)
    api.move(g + V(0, 0, 0.08), steps=12)
    return P(api, bottle)[2] - p0[2] > 0.03


def carry_and_place(api, bottle, target, h0):
    tp = P(api, target)
    ip = P(api, bottle)
    e = E(api)
    rel = e - ip                              # eef relative to bottle origin
    # bottle bottom must clear the target surface by ~9 cm during transit
    carry_item_z = max(ip[2], tp[2] + h0 + 0.09)
    hz = carry_item_z + rel[2]
    api.move(V(e[0], e[1], hz), steps=15)
    if P(api, bottle)[2] < ip[2] - 0.02:      # slipped while lifting
        return False
    api.move(V(tp[0] + rel[0], tp[1] + rel[1], hz), steps=35)
    # correct for drift during transport
    ip = P(api, bottle)
    e = E(api)
    rel = e - ip
    above = V(tp[0], tp[1], tp[2] + h0 + 0.04) + rel
    api.move(above, steps=15)
    rest = V(tp[0], tp[1], tp[2] + h0 + 0.012) + rel
    api.move(rest, steps=15)
    api.grip(False)
    e = E(api)
    api.move(e + V(0, 0, 0.10), steps=12)
    return placed_ok(api, bottle, target)


def place_bottle(api, names, bottle, target):
    h0 = bottle_height_offset(api, names, bottle)
    for dz in (0.07, 0.10, 0.04):
        if placed_ok(api, bottle, target):
            return True
        try:
            if not grasp_bottle(api, bottle, dz):
                recover(api)
                continue
            if carry_and_place(api, bottle, target, h0):
                return True
            recover(api)
        except Exception:
            try:
                recover(api)
            except Exception:
                pass
    if placed_ok(api, bottle, target):
        return True
    try:
        api.place_with(bottle, target, 'standard')
    except Exception:
        pass
    return placed_ok(api, bottle, target)


# ------------------------------------------------------------ main
def run(api):
    names = list(api.names())
    words = _words(api.instruction)
    task = None
    try:
        task = bottle_task(api, names, words)
    except Exception:
        task = None
    if task is not None:
        place_bottle(api, names, task[0], task[1])
        return
    api.fallback()
