import math
import numpy as np

ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl',
    'white_bowl': 'white bowl', 'plate': 'plate dish',
    'flat_stove': 'stove burner cooktop', 'cream_cheese': 'cream cheese box',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack',
    'wooden_cabinet': 'wooden cabinet', 'white_cabinet': 'white cabinet',
    'microwave': 'microwave oven', 'moka_pot': 'moka pot',
    'chefmate_8_frypan': 'frying pan frypan skillet', 'basket': 'basket',
    'porcelain_mug': 'white porcelain mug cup', 'red_coffee_mug': 'red coffee mug cup',
    'white_yellow_mug': 'white yellow mug cup', 'desk_caddy': 'desk caddy',
    'black_book': 'black book', 'yellow_book': 'yellow book',
    'ketchup': 'ketchup bottle', 'butter': 'butter box', 'milk': 'milk carton',
    'tomato_sauce': 'tomato sauce can', 'alphabet_soup': 'alphabet soup can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'orange_juice': 'orange juice carton',
}
STOP = {'the', 'a', 'an', 'of', 'it', 'to', 'towards', 'toward', 'and', 'please',
        'side', 'its', 'that', 'then', 'area', 'location', 'place', 'spot', 'table'}
DIRS = ('front', 'back', 'left', 'right', 'behind')
PUSH_VERBS = ('push', 'slide', 'shove', 'nudge')

R_START = 0.14     # pusher start distance behind item centre
R_CONTACT = 0.105  # assumed contact offset (item radius + finger)
BUDGET = 470


def V(*a):
    return np.array(a, dtype=float)


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return w


def match_body(bodies, ws, exclude=()):
    W = set(w for w in ws if w not in STOP and w not in DIRS)
    best, bs = None, 0
    for b in bodies:
        if b in exclude:
            continue
        s = len(W & _desc(b))
        if s > bs:
            bs, best = s, b
    return best


class Ctl:
    def __init__(self, api):
        self.api = api
        self.used = 0

    def pos(self, n):
        return np.array(self.api.pos(n), dtype=float)

    def eef(self):
        return np.array(self.api.eef(), dtype=float)

    def move(self, x, steps):
        steps = int(max(3, min(steps, BUDGET - self.used)))
        self.used += steps
        return self.api.move(np.array(x, dtype=float), steps=steps)

    def grip(self, c):
        self.used += 10
        self.api.grip(c)

    def left(self):
        return BUDGET - self.used


def find_target(api, names, bodies, ws):
    """ws: words after 'to'. returns (target_name, ref_body)"""
    direction = None
    for w in ws:
        if w in DIRS:
            direction = 'back' if w == 'behind' else w
            break
    if 'of' in ws:
        ref_ws = ws[ws.index('of') + 1:]
    else:
        ref_ws = ws
    ref = match_body(bodies, ref_ws)
    inside = any(w in ws for w in ('inside', 'into', 'in'))
    regs = [n for n in names if _is_region(n)]
    if ref is not None and direction is not None:
        try:
            r = api.relative_target(ref, direction, 'inside' if inside else 'outside')
            if isinstance(r, str) and r in names:
                return r, ref
        except Exception:
            pass
        head = set(_base(ref).split('_')) | (_desc(ref) - {'box', 'bottle'})
        cands = []
        for n in regs:
            t = set(n.split('_'))
            if direction in t and (t & head):
                s = len(t & head) + (2 if (n.startswith('main_table') != inside) else 0)
                cands.append((s, n))
        if cands:
            cands.sort(key=lambda x: -x[0])
            return cands[0][1], ref
        return None, ref
    if ref is not None:
        rb = _base(ref).split('_')[-1]
        for n in regs:
            if n.startswith('main_table') and rb in n.split('_') and len(n.split('_')) <= 5:
                return n, ref
        return ref, ref
    return None, None


def seg_dist(a, b, c):
    ab = b - a
    L2 = float(ab @ ab)
    if L2 < 1e-9:
        return float(np.linalg.norm(c - a))
    t = float(np.clip((c - a) @ ab / L2, 0.0, 1.0))
    return float(np.linalg.norm(a + t * ab - c))


def push_once(ctl, item, goal, zpush, zsafe):
    p = ctl.pos(item)
    v = goal[:2] - p[:2]
    L = float(np.linalg.norm(v))
    if L < 1e-4:
        return
    d = v / L
    start = V(p[0] - d[0] * R_START, p[1] - d[1] * R_START, zpush)
    end = V(goal[0] - d[0] * R_CONTACT, goal[1] - d[1] * R_CONTACT, zpush)
    e = ctl.eef()
    hz = max(e[2], zsafe)
    ctl.move(V(e[0], e[1], hz), 10)
    ctl.move(V(start[0], start[1], hz), 25)
    ctl.move(start, 15)
    # if lowering disturbed the item (landed on its rim), back off further
    p2 = ctl.pos(item)
    if np.linalg.norm(p2 - p) > 0.015 and p2[2] < p[2] - 0.004:
        ctl.move(V(start[0], start[1], hz), 8)
        start = start - V(d[0], d[1], 0) * 0.04
        ctl.move(V(start[0], start[1], hz), 8)
        ctl.move(start, 12)
    stroke = float(np.linalg.norm(end[:2] - start[:2]))
    ctl.move(end, int(20 + stroke * 160))
    back = end - V(d[0], d[1], 0) * 0.03
    ctl.move(back, 6)
    ctl.move(V(back[0], back[1], hz), 10)


def push_task(api, ctl, names, bodies, item, target, ref):
    tp = ctl.pos(target)
    table_z = [ctl.pos(n)[2] for n in names if n.startswith('main_table_') and _is_region(n)]
    p0 = ctl.pos(item)
    tz = float(np.median(table_z)) if table_z else p0[2]
    if abs(tz - p0[2]) > 0.06:
        tz = p0[2]
    zpush = max(tz, min(p0[2], tz + 0.02)) + 0.015
    zsafe = max(tz + 0.18, p0[2] + 0.15)

    # detour if the straight path crosses the reference fixture
    legs = [tp]
    if ref is not None and ref != item and target != ref:
        rp = ctl.pos(ref)
        if seg_dist(p0[:2], tp[:2], rp[:2]) < 0.14 and np.linalg.norm(tp[:2] - rp[:2]) > 0.05:
            out = tp[:2] - rp[:2]
            out = out / np.linalg.norm(out)
            w = V(tp[0] + out[0] * 0.13, tp[1] + out[1] * 0.13, tp[2])
            legs = [w, tp]

    ctl.grip(True)
    for li, goal in enumerate(legs):
        final = li == len(legs) - 1
        tol = 0.02 if final else 0.05
        for _ in range(4):
            if ctl.left() < 110:
                break
            p = ctl.pos(item)
            if np.linalg.norm(goal[:2] - p[:2]) < tol:
                break
            push_once(ctl, item, goal, zpush, zsafe)
    p = ctl.pos(item)
    err = float(np.linalg.norm(tp[:2] - p[:2]))
    if err > 0.07 and ctl.left() > 200:
        try:
            ctl.grip(False)
            api.arrange([(item, target)])
        except Exception:
            pass
    e = ctl.eef()
    try:
        api.grip(False)
        api.move(V(e[0], e[1], max(e[2], zsafe)), steps=8)
    except Exception:
        pass


def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    ws = _words(api.instruction)
    vi = next((i for i, w in enumerate(ws) if w in PUSH_VERBS), None)
    plan = None
    if vi is not None and 'drawer' not in ws and 'drawers' not in ws:
        rest = ws[vi + 1:]
        ti = next((i for i, w in enumerate(rest) if w in ('to', 'towards', 'toward')), None)
        if ti is not None and ti > 0:
            item = match_body(bodies, rest[:ti])
            if item is not None:
                target, ref = find_target(api, names, [b for b in bodies if b != item],
                                          rest[ti + 1:])
                if target is not None and target != item:
                    plan = (item, target, ref)
    if plan is None:
        api.fallback()
        return
    ctl = Ctl(api)
    try:
        push_task(api, ctl, names, bodies, *plan)
    except Exception:
        try:
            api.grip(False)
            e = np.array(api.eef(), dtype=float)
            api.move(e + V(0, 0, 0.1), steps=10)
        except Exception:
            pass
