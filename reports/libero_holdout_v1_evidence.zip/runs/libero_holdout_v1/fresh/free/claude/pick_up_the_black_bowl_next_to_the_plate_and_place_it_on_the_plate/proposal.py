import math
import numpy as np

# ------------------------------------------------------------------ vocabulary
ALIAS = {
    'akita_black_bowl': 'black bowl',
    'black_bowl': 'black bowl',
    'white_bowl': 'white bowl',
    'glazed_rim_porcelain_ramekin': 'ramekin porcelain',
    'cookies': 'cookie cookies box',
    'flat_stove': 'stove burner cooktop',
    'wooden_cabinet': 'wooden cabinet',
    'white_cabinet': 'white cabinet',
    'plate': 'plate',
    'porcelain_mug': 'white porcelain mug cup',
    'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup',
    'chefmate_8_frypan': 'frying pan frypan skillet',
    'moka_pot': 'moka pot',
    'desk_caddy': 'desk caddy',
    'black_book': 'black book',
    'yellow_book': 'yellow book',
    'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can',
    'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle',
    'ketchup': 'ketchup bottle',
    'butter': 'butter box',
    'milk': 'milk carton',
    'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box',
    'salad_dressing': 'salad dressing bottle',
    'wine_bottle': 'wine bottle',
    'wine_rack': 'wine rack',
    'microwave': 'microwave oven',
    'basket': 'basket',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown',
          'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'and', 'to', 'up', 'please',
        'then', 'its', 'that', 'is'}
QUAL = ('next', 'between', 'on', 'from', 'in', 'inside', 'at', 'near',
        'beside', 'by')
PICKV = ('pick', 'grab', 'take', 'lift')
PLACEV = ('place', 'put', 'set', 'move')
PREPS = ('into', 'onto', 'inside', 'in', 'on', 'to')


def V(*a):
    return np.array(a, dtype=float)


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def E(api):
    return np.array(api.eef(), dtype=float)


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side') or 'table_' in n


def _words(s):
    s = ''.join(c if c.isalnum() else ' ' for c in s.lower())
    return s.split()


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return w


# ------------------------------------------------------------------ resolution
def candidates(bodies, words, exclude=()):
    W = set(w for w in words if w not in STOP)
    if not W:
        return []
    best, cands = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, cands = s, [b]
        elif abs(s - best) < 1e-9:
            cands.append(b)
    return sorted(cands)


def resolve_target(api, names, bodies, raw, exclude=()):
    c = candidates(bodies, raw, exclude)
    if not c:
        return None
    obj = c[0]
    regs = [n for n in names if n.startswith(obj + '_')
            and (n.endswith('_region') or n.endswith('_side'))]
    if not regs:
        return (obj, obj)
    R = set(raw)
    drawer = 'drawer' in R or 'drawers' in R
    best, bs = obj, 0.5
    for r in regs:
        suf = r[len(obj) + 1:].split('_')
        toks = set(suf) - {'region', 'contain', 'side'}
        s = 3 * len(toks & R)
        if drawer and 'side' in suf:
            s -= 5
        if (not drawer) and 'top' in R and 'side' in suf:
            s += 2
        if not toks or toks <= {'cook', 'heating'}:
            s += 1
        if s > bs:
            bs, best = s, r
    return (best, obj)


def qualifier_ref(api, names, bodies, qual, exclude):
    """returns (reference xyz, mode) for phrases like 'next to the plate'."""
    content = [w for w in qual if w not in STOP and w not in QUAL]
    regions = [n for n in names if n.endswith('_region') or 'table_' in n]
    kind = qual[0]

    if 'center' in content or 'centre' in content:
        for n in names:
            if 'center' in n or 'centre' in n:
                return P(api, n), 'xy'

    if kind == 'between':
        rest = [w for w in qual[1:]]
        for r in regions:
            t = set(r.split('_'))
            if 'between' in t and len(t & set(content)) >= 2:
                return P(api, r), 'xy'
        # midpoint of the two references
        if 'and' in rest:
            j = rest.index('and')
            a = candidates(bodies, rest[:j], exclude)
            b = candidates(bodies, rest[j + 1:], exclude)
            if a and b:
                return 0.5 * (P(api, a[0]) + P(api, b[0])), 'xy'

    if kind in ('next', 'near', 'beside', 'by'):
        best, bs = None, 0
        for r in regions:
            t = set(r.split('_'))
            if 'next' not in t:
                continue
            s = len((t - {'main', 'table', 'next', 'to', 'region'}) & set(content))
            if s > bs:
                bs, best = s, r
        if best:
            return P(api, best), 'xy'
        c = candidates(bodies, content, exclude)
        if c:
            return P(api, c[0]), 'near'

    if kind in ('in', 'inside') or 'drawer' in content:
        t = resolve_target(api, names, bodies, content, exclude)
        if t:
            return P(api, t[0]), '3d'

    # on / from / at <object>
    c = candidates(bodies, content, exclude)
    if c:
        obj = c[0]
        top = obj + '_top_side'
        if 'cabinet' in obj and top in names:
            return P(api, top), '3d'
        return P(api, obj), 'on'
    for r in regions:
        if set(r.split('_')) & set(content):
            return P(api, r), 'xy'
    return None, None


def choose_item(api, names, bodies, item_w, qual, exclude):
    cands = candidates(bodies, item_w, exclude)
    if not cands:
        return None
    if len(cands) == 1 or not qual:
        if len(cands) > 1:
            for w, f in (('left', lambda p: -p[1]), ('right', lambda p: p[1]),
                         ('front', lambda p: p[0]), ('back', lambda p: -p[0])):
                if w in item_w:
                    return sorted(cands, key=lambda c: f(P(api, c)))[0]
        return cands[0]
    ref, mode = qualifier_ref(api, names, bodies, qual, set(cands) | set(exclude))
    if ref is None:
        return cands[0]

    def score(c):
        p = P(api, c)
        dxy = np.linalg.norm(p[:2] - ref[:2])
        if mode == '3d':
            return np.linalg.norm(p - ref)
        if mode == 'on':
            return dxy + 0.8 * max(0.0, ref[2] - p[2])
        if mode == 'near':
            # next to an object but not on top of it
            return dxy + (0.2 if dxy < 0.03 else 0.0)
        return dxy
    return sorted(cands, key=score)[0]


# ------------------------------------------------------------------ parsing
def parse(api, names, bodies, words):
    """pick (up) <item> [qualifier] and place/put it on/in <target>"""
    if not words or words[0] not in PICKV:
        return None
    split = None
    for j in range(1, len(words) - 1):
        if words[j] == 'and' and words[j + 1] in PLACEV:
            split = j
    if split is None:
        return None
    first = [w for w in words[1:split] if w not in ('up',)]
    second = words[split + 2:]
    if any(w in ('and', 'then') for w in second) and any(
            w in PICKV + PLACEV + ('turn', 'open', 'close') for w in second):
        return None  # more than one action: leave it to the old policy
    second = [w for w in second if w not in ('it', 'them')]
    idx = None
    for i, w in enumerate(second):
        if w in PREPS:
            idx = i
            break
    tw = second[idx + 1:] if idx is not None else second
    tw = [w for w in tw if w != 'top' or 'drawer' in tw or 'cabinet' in tw]
    tgt = resolve_target(api, names, bodies, tw)
    if tgt is None:
        return None
    first = [w for w in first if w not in ('the', 'a', 'an')]
    q = None
    for i, w in enumerate(first):
        if w in QUAL and i > 0:
            q = i
            break
    item_w = first[:q] if q is not None else first
    qual = first[q:] if q is not None else []
    item = choose_item(api, names, bodies, item_w, qual, exclude=(tgt[1],))
    if item is None:
        return None
    return item, tgt


# ------------------------------------------------------------------ skills
def grasp_mode(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


def placed_ok(api, item, name):
    try:
        ip, tp = P(api, item), P(api, name)
    except Exception:
        return False
    tol = 0.07
    if 'basket' in name or 'contain' in name:
        tol = 0.08
    if 'caddy' in name:
        tol = 0.045
    return (np.linalg.norm(ip[:2] - tp[:2]) < tol
            and ip[2] > tp[2] - 0.05 and ip[2] < tp[2] + 0.12)


def recover(api):
    try:
        api.grip(False)
        e = E(api)
        api.move(e + V(0, 0, 0.12), steps=12)
    except Exception:
        pass


def drop_z(name):
    if 'basket' in name:
        return 0.11
    if 'caddy' in name:
        return 0.10
    if 'cook' in name:
        return 0.05
    if 'plate' in name:
        return 0.06
    return 0.08


BOWL_GRASPS = [(0.0, 0.06, 0.025), (0.0, -0.06, 0.025)]


def manual_place(api, item, name, options):
    for g in options:
        p0 = P(api, item)
        p = p0 + V(*g)
        api.grip(False)
        e = E(api)
        api.move(V(e[0], e[1], max(e[2], p[2] + 0.12)), steps=10)
        api.move(p + V(0, 0, 0.10), steps=20)
        api.move(p, steps=16)
        api.grip(True)
        api.move(p + V(0, 0, 0.08), steps=12)
        if P(api, item)[2] - p0[2] < 0.025:
            recover(api)
            continue
        ip, e = P(api, item), E(api)
        dest = P(api, name) + V(0, 0, drop_z(name))
        eg = dest + (e - ip)
        hz = max(e[2], eg[2] + 0.10)
        api.move(V(e[0], e[1], hz), steps=12)
        api.move(V(eg[0], eg[1], hz), steps=30)
        api.move(eg, steps=18)
        api.grip(False)
        e = E(api)
        api.move(e + V(0, 0, 0.10), steps=10)
        if placed_ok(api, item, name):
            return True
    return False


def execute(api, item, tgt):
    name = tgt[0]
    mode = grasp_mode(item)
    for _ in range(2):
        try:
            api.place_with(item, name, mode)
        except Exception:
            try:
                api.transfer(item, name, grasp=(0, 0, 0), drop=(0, 0, drop_z(name)))
            except Exception:
                pass
        if placed_ok(api, item, name):
            recover(api)
            return True
        recover(api)
    if 'bowl' in _base(item):
        try:
            if manual_place(api, item, name, BOWL_GRASPS):
                return True
        except Exception:
            recover(api)
    try:
        api.place_with(item, name, 'standard')
    except Exception:
        pass
    return placed_ok(api, item, name)


# ------------------------------------------------------------------ main
def run(api):
    names = list(api.names())
    bodies = [n for n in names
              if not (n.endswith('_region') or n.endswith('_side')
                      or n.startswith('main_table'))]
    words = _words(api.instruction)
    plan = None
    try:
        plan = parse(api, names, bodies, words)
    except Exception:
        plan = None
    if plan is None:
        api.fallback()
        return
    item, tgt = plan
    try:
        execute(api, item, tgt)
    except Exception:
        recover(api)
