import math
import numpy as np

ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl', 'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup', 'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup', 'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop', 'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy',
    'black_book': 'black book', 'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle', 'butter': 'butter box',
    'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet', 'wooden_cabinet': 'wooden cabinet',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack', 'microwave': 'microwave oven',
    'basket': 'basket', 'plate': 'plate', 'cookies': 'cookie box',
    'glazed_rim_porcelain_ramekin': 'ramekin',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown', 'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'top', 'left', 'right',
        'front', 'back', 'bottom', 'middle', 'compartment', 'side', 'its', 'that', 'is', 'please',
        'then', 'which', 'located', 'sitting', 'lying', 'placed'}
VERBS = {'put', 'place', 'turn', 'switch', 'close', 'shut', 'open', 'pick', 'push', 'pull',
         'move', 'stack', 'lift', 'grab', 'take', 'set'}
PICKV = ('pick', 'grab', 'lift', 'take')
PREPS = ('into', 'onto', 'inside', 'in', 'on')
QUAL = ('on', 'in', 'inside', 'next', 'between', 'from', 'at', 'near', 'beside', 'by', 'under',
        'atop', 'beneath')
NEXT = ('next', 'near', 'beside', 'by')
DIRS = ('left', 'right', 'front', 'back')
DIRV = {'left': (0.0, 1.0), 'right': (0.0, -1.0), 'front': (-1.0, 0.0), 'back': (1.0, 0.0)}
IRREG = {'caddies': 'caddy', 'shelves': 'shelf', 'centre': 'center', 'cookies': 'cookie'}


def V(*a):
    return np.array(a, dtype=float)


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def E(api):
    return np.array(api.eef(), dtype=float)


def sg(w):
    if w in IRREG:
        return IRREG[w]
    if len(w) > 3 and w.endswith('xes'):
        return w[:-2]
    if len(w) > 3 and w.endswith('s') and not w.endswith(('ss', 'us', 'is')):
        return w[:-1]
    return w


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side') or n.endswith('_center') \
        or n.endswith('_front')


def _words(s):
    s = ''.join(c if c.isalnum() else ' ' for c in s.lower())
    return [sg(w) for w in s.split()]


def _desc(b):
    base = _base(b)
    w = set(sg(t) for t in base.split('_'))
    if base in ALIAS:
        w |= set(sg(t) for t in ALIAS[base].split())
    return w


def is_drawer(name):
    t = name.split('_')
    return name.endswith('_region') and 'side' not in t and \
        any(k in t for k in ('top', 'middle', 'bottom'))


# ---------------------------------------------------------------- resolution
def _spatial(api, names, raw, cands):
    for w in DIRS:
        if w in raw:
            head = _base(cands[0]).split('_')[-1]
            hints = [n for n in names if _is_region(n) and w in n.split('_')
                     and head in n.split('_')]
            if hints:
                hp = P(api, hints[0])
                return sorted(cands, key=lambda c: np.linalg.norm(P(api, c)[:2] - hp[:2]))
            keyf = {'left': lambda p: -p[1], 'right': lambda p: p[1],
                    'front': lambda p: p[0], 'back': lambda p: -p[0]}[w]
            return sorted(cands, key=lambda c: keyf(P(api, c)))
    return sorted(cands)


def resolve_all(bodies, raw, exclude=()):
    W = set(w for w in raw if w not in STOP and w not in QUAL)
    if not W:
        return []
    best, cands = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, cands = s, [b]
        elif abs(s - best) < 1e-9:
            cands.append(b)
    return cands


def split_qual(ws):
    for i in range(1, len(ws)):
        if ws[i] in QUAL and any(w not in STOP and w not in VERBS for w in ws[:i]):
            head, rel, ref = ws[:i], ws[i], ws[i + 1:]
            if rel == 'next' and ref[:1] == ['to']:
                ref = ref[1:]
            r2 = [w for w in ref if w not in ('the', 'a', 'an')]
            if r2 and r2[0] in DIRS and 'of' in ref:
                j = len(ref) - 1 - ref[::-1].index('of')
                rel, ref = 'dir:' + r2[0], ref[j + 1:]
            return head, rel, ref
    return ws, None, []


def _region_hint(api, names, key, toks):
    T = set(toks) - {'main', 'table', 'region', 'the', 'a', 'to', 'and'}
    best, bs = None, 0
    for r in names:
        if not _is_region(r):
            continue
        rt = set(sg(t) for t in r.split('_'))
        if key not in rt:
            continue
        s = len(T & rt)
        if s > bs:
            bs, best = s, r
    return best


def ref_point(api, names, bodies, rel, ref):
    """returns (point, owner_body, use3d)"""
    toks = [w for w in ref if w not in STOP and w not in QUAL]
    if 'center' in ref:
        cs = [n for n in names if 'center' in n.split('_')]
        if cs:
            return P(api, cs[0]), None, False
    if rel in NEXT:
        owner = resolve_np(api, names, bodies, ref)
        h = _region_hint(api, names, 'next', toks)
        if h is not None:
            return P(api, h), owner, False
        if owner:
            return P(api, owner), owner, False
        return None, None, False
    if rel == 'between':
        h = _region_hint(api, names, 'between', toks)
        if h is not None:
            return P(api, h), None, False
        parts, cur = [], []
        for w in ref:
            if w == 'and':
                parts.append(cur)
                cur = []
            else:
                cur.append(w)
        parts.append(cur)
        pts = []
        for p in parts:
            o = resolve_np(api, names, bodies, p)
            if o:
                pts.append(P(api, o))
        if pts:
            return np.mean(pts, axis=0), None, False
        return None, None, False
    if rel and rel.startswith('dir:'):
        d = rel[4:]
        owner = resolve_np(api, names, bodies, ref)
        if not owner:
            return None, None, False
        op = P(api, owner)
        v = DIRV[d]
        return op + V(v[0] * 0.12, v[1] * 0.12, 0), owner, False
    tgt = resolve_target(api, names, bodies, ref, on_top=(rel in ('on', 'atop')))
    if tgt is None:
        return None, None, False
    return P(api, tgt[0]), tgt[1], is_drawer(tgt[0])


def resolve_np(api, names, bodies, ws, exclude=()):
    head, rel, ref = split_qual(ws)
    cands = resolve_all(bodies, head, exclude)
    if not cands:
        cands = resolve_all(bodies, ws, exclude)
        rel = None
    if not cands:
        return None
    if len(cands) == 1:
        return cands[0]
    if rel is None:
        return _spatial(api, names, head, cands)[0]
    try:
        pt, owner, use3d = ref_point(api, names, bodies, rel, ref)
    except Exception:
        pt, owner, use3d = None, None, False
    if pt is None:
        return _spatial(api, names, head, cands)[0]
    cs = [c for c in cands if c != owner] or cands
    op = P(api, owner) if owner else None
    best, bs = cs[0], 1e9
    for c in cs:
        cp = P(api, c)
        d = np.linalg.norm(cp - pt) if use3d else np.linalg.norm(cp[:2] - pt[:2])
        if rel in ('on', 'atop') and cp[2] < pt[2] - 0.02:
            d += 0.15
        if rel in ('under', 'beneath') and cp[2] > pt[2] + 0.02:
            d += 0.15
        if (rel in NEXT or rel.startswith('dir:')) and op is not None:
            if np.linalg.norm(cp[:2] - op[:2]) < 0.05 and cp[2] > op[2] + 0.02:
                d += 0.5
        if d < bs:
            bs, best = d, c
    return best


def resolve_target(api, names, bodies, raw, on_top=False):
    obj = resolve_np(api, names, bodies, raw)
    if obj is None:
        return None
    regs = [n for n in names if _is_region(n) and n.startswith(obj + '_')]
    if not regs:
        return (obj, obj)
    R = set(raw)
    drawer = 'drawer' in R
    best, bs = None, -1e9
    for r in regs:
        suf = r[len(obj) + 1:].split('_')
        toks = set(sg(t) for t in suf) - {'region', 'contain', 'side'}
        s = 3 * len(toks & R)
        if drawer and 'side' in suf:
            s -= 5
        if (not drawer) and 'top' in R and 'side' in suf:
            s += 2
        if on_top and not drawer and 'side' in suf:
            s += 4
        if not toks or toks <= {'cook', 'heating'}:
            s += 1
        if s > bs:
            bs, best = s, r
    return (best, obj)


# ---------------------------------------------------------------- parsing
def split_clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if (w == 'and' and (nxt in VERBS or nxt == 'then')) or w == 'then':
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return [c for c in out if c]


def split_items(ws):
    if 'between' in ws:
        return [ws]
    both = 'both' in ws
    has_the = any(ws[j] == 'and' and j + 1 < len(ws) and ws[j + 1] in ('the', 'a')
                  for j in range(len(ws)))
    parts = [[]]
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if w == 'and' and ((has_the and nxt in ('the', 'a')) or (both and not has_the)):
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def target_split(rest):
    idxs = []
    for i, w in enumerate(rest):
        if i == 0:
            continue
        if w in PREPS or w == 'next':
            idxs.append(i)
        elif w == 'to' and rest[i - 1] != 'next' and any(x in DIRS for x in rest[i + 1:i + 3]):
            idxs.append(i)
    for i in reversed(idxs):
        tail = rest[i + 1:]
        if tail in (['it'], ['them']) or any(w not in STOP and w not in DIRS and w != 'to'
                                             for w in tail):
            return i
    return idxs[0] if idxs else None


def target_from(api, names, bodies, tw, prepw):
    if prepw == 'next' and tw[:1] == ['to']:
        tw = tw[1:]
    d = None
    if 'of' in tw:
        j = tw.index('of')
        for w in tw[:j]:
            if w in DIRS:
                d = w
                break
    if d:
        k = len(tw) - 1 - tw[::-1].index('of')
        refb = resolve_np(api, names, bodies, tw[k + 1:])
        if refb:
            inside = ('compartment' in tw or prepw in ('inside', 'into')
                      or (prepw == 'in' and d != 'front'))
            try:
                r = api.relative_target(refb, d, 'inside' if inside else 'outside')
                if r:
                    return (r, refb)
            except Exception:
                pass
            hs = [n for n in names if _is_region(n) and n.startswith(refb + '_')
                  and d in n.split('_')]
            if hs:
                return (hs[0], refb)
    if prepw == 'next':
        toks = [w for w in tw if w not in STOP]
        h = _region_hint(api, names, 'next', toks)
        if h:
            return (h, resolve_np(api, names, bodies, tw) or h)
    return resolve_target(api, names, bodies, tw, on_top=(prepw in ('on', 'onto')))


def build_plan(api, names, bodies, words):
    ops = []
    last_item, last_target, last_fix = None, None, None
    for c in split_clauses(words):
        while c and c[-1] == 'and':
            c = c[:-1]
        if not c:
            continue
        v, rest = c[0], c[1:]
        if v in ('turn', 'switch'):
            on = 'off' not in rest
            ow = [w for w in rest if w not in ('on', 'off')]
            obj = last_fix if (not ow or ow == ['it']) else resolve_np(api, names, bodies, ow)
            if obj:
                ops.append(('turn', obj, on))
                last_fix = obj
            continue
        if v in ('close', 'shut', 'open'):
            if not rest or rest in (['it'], ['them']):
                tgt = last_target
            else:
                tgt = resolve_target(api, names, bodies, rest)
            if tgt:
                ops.append(('close' if v != 'open' else 'open', tgt))
                last_target = tgt
                last_fix = tgt[1]
            continue
        rest = [w for w in rest if w != 'up']
        if v in PICKV:
            it = resolve_np(api, names, bodies, rest)
            if it:
                ops.append(('pick', it))
                last_item = it
            continue
        idx = target_split(rest)
        if idx is None:
            item_w, tw, prepw = rest, [], None
        else:
            item_w, tw, prepw = rest[:idx], rest[idx + 1:], rest[idx]
        if not tw or tw in (['it'], ['them']):
            if tw and last_fix:
                tgt = resolve_target(api, names, bodies, _base(last_fix).split('_'),
                                     on_top=(prepw in ('on', 'onto')))
                if tgt is None or tgt[1] != last_fix:
                    tgt = (last_fix, last_fix)
            else:
                tgt = last_target
        else:
            tgt = target_from(api, names, bodies, tw, prepw)
        if tgt is None:
            continue
        items = []
        for part in split_items(item_w):
            if part in (['it'], ['them']):
                it = last_item
            else:
                it = resolve_np(api, names, bodies, part, exclude=(tgt[1],))
            if it and it not in items:
                items.append(it)
        if not items and last_item:
            items = [last_item]
        if ops and ops[-1][0] == 'pick' and ops[-1][1] in items:
            ops.pop()
        for k, it in enumerate(items):
            ops.append(('place', it, tgt, k, len(items)))
        if items:
            last_item = items[-1]
        last_target = tgt
        last_fix = tgt[1]
    return ops


# ---------------------------------------------------------------- skills
def grasp_options(item):
    b = _base(item)
    if 'mug' in b or 'cup' in b:
        return [(0.0, 0.03, 0.02), (0.0, -0.03, 0.02)]
    if 'bowl' in b:
        return [(0.0, 0.045, 0.01), (0.0, -0.045, 0.01)]
    return [(0.0, 0.0, 0.0), (0.0, 0.0, -0.01)]


BOWL_GRASPS = [(0.0, 0.06, 0.025), (0.0, -0.06, 0.025), (0.0, 0.05, 0.035)]


def grasp_mode(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


def drawer_dir(api, region, owner):
    rp = P(api, region)
    op = P(api, owner) if owner else rp
    d = op[:2] - rp[:2]
    nd = np.linalg.norm(d)
    d = d / nd if nd > 0.03 else np.array([1.0, 0.0])
    return np.array([d[0], d[1], 0.0])


def drop_for(api, item, tgt, k, n):
    name, owner = tgt
    z = 0.08
    off = np.zeros(3)
    if 'basket' in name:
        z = 0.11
    elif 'caddy' in name:
        z = 0.10
    elif 'cook' in name:
        z = 0.05
    elif 'plate' in name:
        z = 0.06
    elif 'cabinet' in owner and name != owner and 'side' not in name:
        z = 0.06
        off = -drawer_dir(api, name, owner) * 0.03
    if n > 1 and ('basket' in name or 'contain' in name) and 'caddy' not in name:
        off[1] += 0.03 if k % 2 == 0 else -0.03
    return (float(off[0]), float(off[1]), float(off[2] + z))


def placed_ok(api, item, name):
    try:
        ip, tp = P(api, item), P(api, name)
    except Exception:
        return False
    tol = 0.07
    if 'basket' in name or 'contain' in name:
        tol = 0.08
    if 'caddy' in name:
        tol = 0.045
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.06


def recover(api):
    api.grip(False)
    e = E(api)
    api.move(e + V(0, 0, 0.12), steps=15)


def try_grasp(api, item, g):
    p0 = P(api, item)
    p = p0 + V(*g)
    api.grip(False)
    e = E(api)
    api.move(V(e[0], e[1], max(e[2], p[2] + 0.12)), steps=10)
    api.move(p + V(0, 0, 0.10), steps=22)
    api.move(p, steps=18)
    api.grip(True)
    api.move(p + V(0, 0, 0.08), steps=12)
    return P(api, item)[2] - p0[2] > 0.025


def manual_place(api, item, tgt, k, n, options):
    name = tgt[0]
    drop = np.array(drop_for(api, item, tgt, k, n))
    for g in options:
        if not try_grasp(api, item, g):
            recover(api)
            continue
        ip = P(api, item)
        e = E(api)
        rel = e - ip
        dest = P(api, name) + drop
        eg = dest + rel
        hz = max(e[2], eg[2] + 0.12)
        z_before = P(api, item)[2]
        api.move(V(e[0], e[1], hz), steps=15)
        if P(api, item)[2] < z_before - 0.02:
            recover(api)
            continue
        api.move(V(eg[0], eg[1], hz), steps=35)
        api.move(eg, steps=20)
        api.grip(False)
        e = E(api)
        api.move(e + V(0, 0, 0.10), steps=12)
        if placed_ok(api, item, name):
            return True
    return False


def place_item(api, item, tgt, k, n):
    name = tgt[0]
    mode = grasp_mode(item)
    for _ in range(2):
        try:
            api.place_with(item, name, mode)
        except Exception:
            break
        if placed_ok(api, item, name):
            return True
        recover(api)
    if 'bowl' in _base(item):
        if manual_place(api, item, tgt, k, n, BOWL_GRASPS):
            return True
    drop = drop_for(api, item, tgt, k, n)
    for g in grasp_options(item):
        try:
            api.transfer(item, name, grasp=g, drop=drop)
        except Exception:
            pass
        if placed_ok(api, item, name):
            return True
        recover(api)
    return False


def pick_only(api, item):
    g = np.array(grasp_options(item)[0])
    p = P(api, item) + g
    api.grip(False)
    api.move(p + V(0, 0, 0.12), steps=30)
    api.move(p, steps=25)
    api.grip(True)
    api.move(p + V(0, 0, 0.15), steps=25)


def push_close(api, tgt):
    name, owner = tgt
    rp = P(api, name)
    d3 = drawer_dir(api, name, owner)
    start = rp - d3 * 0.20
    start[2] = rp[2] + 0.03
    e = E(api)
    high = max(e[2], rp[2] + 0.15)
    api.move(V(e[0], e[1], high), steps=15)
    api.move(V(start[0], start[1], high), steps=30)
    api.grip(True)
    api.move(start, steps=25)
    api.move(start + d3 * 0.32, steps=60)
    back = start + d3 * 0.20
    api.move(back, steps=10)
    api.move(back + V(0, 0, 0.12), steps=15)


def pull_open(api, tgt):
    name, owner = tgt
    rp = P(api, name)
    d3 = drawer_dir(api, name, owner)
    handle = rp - d3 * 0.13
    handle[2] = rp[2] + 0.04
    pre = handle - d3 * 0.08
    e = E(api)
    api.grip(False)
    api.move(V(e[0], e[1], max(e[2], handle[2] + 0.12)), steps=15)
    api.move(pre + V(0, 0, 0.10), steps=30)
    api.move(pre, steps=20)
    api.move(handle, steps=20)
    api.grip(True)
    api.move(handle - d3 * 0.22, steps=50)
    api.grip(False)
    e = E(api)
    api.move(e + V(0, 0, 0.10), steps=15)


def operate(api, tgt, mode, names):
    name, owner = tgt
    reg = name
    if not is_drawer(reg):
        ds = [n for n in names if n.startswith(owner + '_') and is_drawer(n)]
        if 'cabinet' in owner and ds:
            ds.sort(key=lambda n: 0 if 'top' in n.split('_') else 1)
            reg = ds[0]
    if is_drawer(reg):
        try:
            api.drawer(reg, mode)
            return
        except Exception:
            pass
    if mode == 'open':
        pull_open(api, (reg, owner))
    else:
        push_close(api, (reg, owner))


def twist_knob(api, k, grasp_z, on):
    sgn = 1.0 if on else -1.0
    api.grip(False)
    e = E(api)
    api.move(V(e[0], e[1], max(e[2], grasp_z + 0.15)), steps=15)
    api.move(V(k[0], k[1], grasp_z + 0.10), steps=25)
    api.move(V(k[0], k[1], grasp_z), steps=20)
    api.grip(True)
    api.action([0, 0, 0, 0, 0, 0.35 * sgn, 1.0], steps=12)
    api.grip(False)
    e = E(api)
    api.move(e + V(0, 0, 0.10), steps=12)
    api.action([0, 0, 0, 0, 0, -0.35 * sgn, -1.0], steps=12)


def sweep_stove(api, sp, cp, on):
    sgn = 1.0 if on else -1.0
    e = E(api)
    api.move(V(e[0], e[1], max(e[2], cp[2] + 0.15)), steps=15)
    api.grip(True)
    lines = [(cp[0] - 0.07, cp[2] + 0.015),
             (min(sp[0], cp[0]) - 0.13, max(cp[2] - 0.015, sp[2] + 0.012))]
    for x, z in lines:
        a = V(x, cp[1] + 0.13 * sgn, z)
        b = V(x, cp[1] - 0.13 * sgn, z)
        api.move(V(a[0], a[1], cp[2] + 0.12), steps=25)
        api.move(a, steps=20)
        api.move(b, steps=45)
        api.move(V(b[0], b[1], cp[2] + 0.12), steps=15)


def turn_stove(api, stove, names, on):
    kp = None
    for n in names:
        if n.startswith(_base(stove)) and any(k in n for k in ('knob', 'button', 'switch')):
            try:
                kp = P(api, n)
                break
            except Exception:
                pass
    cook = [n for n in names if n.startswith(stove + '_') and 'cook' in n]
    sp = P(api, stove)
    cp = P(api, cook[0]) if cook else sp + V(0, 0, 0.02)
    if kp is not None:
        twist_knob(api, kp, kp[2] + 0.005, on)
        return
    d = sp[:2] - cp[:2]
    nd = np.linalg.norm(d)
    if nd >= 0.025:
        if nd > 0.15:
            d = d / nd * 0.15
        k = V(sp[0] + d[0], sp[1] + d[1], cp[2])
        twist_knob(api, k, cp[2] + 0.005, on)
        return
    sweep_stove(api, sp, cp, on)


# ---------------------------------------------------------------- main
def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    words = _words(api.instruction)
    try:
        ops = build_plan(api, names, bodies, words)
    except Exception:
        ops = []
    if not ops:
        api.fallback()
        return
    for op in ops:
        try:
            kind = op[0]
            if kind == 'turn':
                turn_stove(api, op[1], names, op[2])
            elif kind == 'place':
                place_item(api, op[1], op[2], op[3], op[4])
            elif kind in ('open', 'close'):
                operate(api, op[1], kind, names)
            elif kind == 'pick':
                pick_only(api, op[1])
        except Exception:
            try:
                recover(api)
            except Exception:
                pass
