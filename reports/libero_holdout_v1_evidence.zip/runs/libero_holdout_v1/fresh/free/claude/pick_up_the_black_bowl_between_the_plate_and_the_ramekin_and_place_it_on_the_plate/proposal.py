import math
import numpy as np

# ---------------------------------------------------------------- vocabulary
ALIAS = {
    'akita_black_bowl': 'black bowl',
    'black_bowl': 'black bowl',
    'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup',
    'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup',
    'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop',
    'moka_pot': 'moka pot',
    'desk_caddy': 'desk caddy',
    'black_book': 'black book',
    'yellow_book': 'yellow book',
    'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can',
    'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle',
    'ketchup': 'ketchup bottle',
    'butter': 'butter box',
    'milk': 'milk carton',
    'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box',
    'salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet',
    'wooden_cabinet': 'wooden cabinet',
    'wine_bottle': 'wine bottle',
    'wine_rack': 'wine rack',
    'microwave': 'microwave oven',
    'basket': 'basket',
    'plate': 'plate',
    'cookies': 'cookie cookies box',
    'glazed_rim_porcelain_ramekin': 'ramekin porcelain',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown',
          'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'top',
        'left', 'right', 'front', 'back', 'bottom', 'middle', 'compartment',
        'side', 'its', 'that', 'is', 'please', 'then', 'which', 'located',
        'sitting', 'lying', 'one'}
LOC = {'between', 'next', 'near', 'beside', 'from', 'on', 'in', 'inside',
       'at', 'by', 'onto', 'into', 'behind', 'under', 'closest', 'nearest'}
PLACE_VERBS = ('place', 'put', 'set', 'move', 'drop')
PICK_VERBS = ('pick', 'grab', 'take', 'lift', 'get')
PREPS = ('into', 'onto', 'inside', 'in', 'on', 'at', 'to')
CLAUSE_VERBS = {'put', 'place', 'turn', 'switch', 'close', 'shut', 'open',
                'pick', 'push', 'pull', 'move', 'stack', 'lift', 'grab',
                'take', 'set'}


def V(*a):
    return np.array(a, dtype=float)


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def E(api):
    return np.array(api.eef(), dtype=float)


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side') or \
        n.endswith('_center') or n.endswith('_front')


def _words(s):
    s = ''.join(c if c.isalnum() else ' ' for c in s.lower())
    return s.split()


def _stem(w):
    return w[:-1] if len(w) > 3 and w.endswith('s') and not w.endswith('ss') else w


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return {_stem(x) for x in w} | w


# ---------------------------------------------------------------- resolution
def candidates(bodies, words, exclude=()):
    W = {_stem(w) for w in words if w not in STOP and w not in LOC}
    if not W:
        return []
    best, out = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, out = s, [b]
        elif abs(s - best) < 1e-9:
            out.append(b)
    return out


def resolve_target(api, names, bodies, raw):
    """returns (target_name, owner_body)"""
    c = candidates(bodies, raw)
    if not c:
        return None
    obj = sorted(c)[0]
    regs = [n for n in names if _is_region(n) and n.startswith(obj + '_')]
    if not regs:
        return (obj, obj)
    R = set(raw)
    drawer = 'drawer' in R or 'drawers' in R
    best, bs = None, -1e9
    for r in regs:
        suf = r[len(obj) + 1:].split('_')
        toks = set(suf) - {'region', 'contain', 'side'}
        s = 3 * len(toks & R)
        if drawer and 'side' in suf:
            s -= 5
        if (not drawer) and 'top' in R and 'side' in suf:
            s += 2
        if (not drawer) and 'top' not in R and ('on' in R or 'onto' in R) and 'side' in suf:
            s += 1
        if not toks or toks <= {'cook', 'heating'}:
            s += 1
        if s > bs:
            bs, best = s, r
    return (best, obj)


def ref_position(api, names, bodies, words, exclude):
    """position of an object / region referred to by a short phrase"""
    W = [w for w in words if w not in LOC]
    Ws = {_stem(w) for w in W}
    # table locations such as 'table center'
    if 'table' in Ws and ('center' in Ws or 'centre' in Ws):
        for n in names:
            if n.endswith('table_center'):
                return P(api, n)
    c = candidates(bodies, W, exclude=exclude)
    if not c:
        return None
    b = sorted(c)[0]
    if ('drawer' in Ws or Ws & {'top', 'middle', 'bottom'}):
        t = resolve_target(api, names, [b], W)
        if t is not None:
            try:
                return P(api, t[0])
            except Exception:
                pass
    try:
        return P(api, b)
    except Exception:
        return None


def region_anchor(api, names, loc):
    """best table region whose descriptive tokens are all in the locator phrase"""
    L = {_stem(w) for w in loc}
    if 'cookie' in L:
        L |= {'box'}
    best, bs = None, 0
    for r in names:
        if not _is_region(r) or 'table' not in r:
            continue
        toks = {_stem(t) for t in r.split('_')} - {'main', 'table', 'region', 'side'}
        toks = {t for t in toks if not t.isdigit()}
        if not toks:
            continue
        if toks <= L and len(toks) > bs:
            bs, best = len(toks), r
    if best is None:
        return None
    try:
        return P(api, best)
    except Exception:
        return None


def pick_candidate(api, names, bodies, cands, loc):
    if len(cands) == 1:
        return cands[0]
    if not loc:
        return sorted(cands)[0]
    anchor = None
    if 'between' in loc:
        after = loc[loc.index('between') + 1:]
        parts, cur = [], []
        for w in after:
            if w == 'and':
                parts.append(cur)
                cur = []
            else:
                cur.append(w)
        parts.append(cur)
        ps = [ref_position(api, names, bodies, p, cands) for p in parts if p]
        ps = [p for p in ps if p is not None]
        if ps:
            anchor = np.mean(ps, axis=0)
    else:
        anchor = ref_position(api, names, bodies, loc, cands)
    region = region_anchor(api, names, loc)
    if anchor is None and region is None:
        for w in ('left', 'right', 'front', 'back'):
            if w in loc:
                keyf = {'left': lambda p: -p[1], 'right': lambda p: p[1],
                        'front': lambda p: p[0], 'back': lambda p: -p[0]}[w]
                return sorted(cands, key=lambda c: keyf(P(api, c)))[0]
        return sorted(cands)[0]
    onish = any(w in loc for w in ('on', 'onto')) and 'next' not in loc and 'between' not in loc

    def score(c):
        cp = P(api, c)
        s = 0.0
        if anchor is not None:
            s += np.linalg.norm(cp[:2] - anchor[:2])
        if region is not None:
            s += 0.7 * np.linalg.norm(cp[:2] - region[:2])
        if onish and anchor is not None:
            s -= 0.3 * max(0.0, cp[2] - anchor[2])
        return s
    return sorted(cands, key=score)[0]


# ---------------------------------------------------------------- parsing
def parse(words):
    if not words or words[0] not in PICK_VERBS + PLACE_VERBS:
        return None
    idx = None
    for i in range(1, len(words) - 1):
        if words[i] == 'and' and words[i + 1] in PLACE_VERBS:
            idx = i
            break
    if idx is None:
        return None
    pre = [w for w in words[1:idx] if w != 'up']
    post = words[idx + 2:]
    if post and post[0] in ('it', 'them'):
        post = post[1:]
    if not post or post[0] not in PREPS:
        return None
    tw = post[1:]
    # reject multi-clause instructions
    for j, w in enumerate(tw):
        if w == 'then' or (w == 'and' and j + 1 < len(tw) and tw[j + 1] in CLAUSE_VERBS):
            return None
    if 'and' in pre and 'between' not in pre:
        return None
    k = len(pre)
    for j, w in enumerate(pre):
        if w in LOC and j > 0:
            k = j
            break
    noun, loc = pre[:k], pre[k:]
    if not tw or not noun:
        return None
    return noun, loc, tw


# ---------------------------------------------------------------- placement skills
BOWL_GRASPS = [(0.0, 0.06, 0.025), (0.0, -0.06, 0.025), (0.0, 0.05, 0.035)]


def drawer_dir(api, region, owner):
    rp = P(api, region)
    op = P(api, owner) if owner else rp
    d = op[:2] - rp[:2]
    nd = np.linalg.norm(d)
    d = d / nd if nd > 0.03 else np.array([1.0, 0.0])
    return np.array([d[0], d[1], 0.0])


def drop_for(api, tgt):
    name, owner = tgt
    z = 0.08
    off = np.zeros(3)
    if 'basket' in name:
        z = 0.11
    elif 'caddy' in name:
        z = 0.10
    elif 'cook' in name:
        z = 0.05
    elif 'plate' in name:
        z = 0.06
    elif 'cabinet' in owner and name != owner and 'side' not in name:
        z = 0.06
        off = -drawer_dir(api, name, owner) * 0.03
    return (float(off[0]), float(off[1]), float(off[2] + z))


def placed_ok(api, item, name):
    ip, tp = P(api, item), P(api, name)
    tol = 0.07
    if 'basket' in name or 'contain' in name:
        tol = 0.08
    if 'caddy' in name:
        tol = 0.045
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.06


def recover(api):
    try:
        api.grip(False)
        e = E(api)
        api.move(e + V(0, 0, 0.12), steps=12)
    except Exception:
        pass


def try_grasp(api, item, g):
    p0 = P(api, item)
    p = p0 + V(*g)
    api.grip(False)
    e = E(api)
    api.move(V(e[0], e[1], max(e[2], p[2] + 0.12)), steps=10)
    api.move(p + V(0, 0, 0.10), steps=22)
    api.move(p, steps=18)
    api.grip(True)
    api.move(p + V(0, 0, 0.08), steps=12)
    return P(api, item)[2] - p0[2] > 0.025


def manual_place(api, item, tgt, options):
    name = tgt[0]
    drop = np.array(drop_for(api, tgt))
    for g in options:
        if not try_grasp(api, item, g):
            recover(api)
            continue
        ip = P(api, item)
        e = E(api)
        rel = e - ip
        dest = P(api, name) + drop
        eg = dest + rel
        hz = max(e[2], eg[2] + 0.12)
        z_before = P(api, item)[2]
        api.move(V(e[0], e[1], hz), steps=15)
        if P(api, item)[2] < z_before - 0.02:
            recover(api)
            continue
        api.move(V(eg[0], eg[1], hz), steps=35)
        api.move(eg, steps=20)
        api.grip(False)
        e = E(api)
        api.move(e + V(0, 0, 0.10), steps=12)
        if placed_ok(api, item, name):
            return True
    return False


def grasp_mode(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


def place_item(api, item, tgt):
    name = tgt[0]
    mode = grasp_mode(item)
    # 1) shared skill (has internal grasp retries)
    try:
        api.place_with(item, name, mode)
    except Exception:
        recover(api)
    if placed_ok(api, item, name):
        return True
    recover(api)
    # 2) manual rim grasp for bowls, transfer for others
    if mode == 'rim':
        try:
            if manual_place(api, item, tgt, BOWL_GRASPS[:2]):
                return True
        except Exception:
            recover(api)
    else:
        for g in [(0.0, 0.0, 0.0), (0.0, 0.0, -0.01)]:
            try:
                api.transfer(item, name, grasp=g, drop=drop_for(api, tgt))
            except Exception:
                pass
            if placed_ok(api, item, name):
                return True
            recover(api)
    return placed_ok(api, item, name)


# ---------------------------------------------------------------- main
def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    words = _words(api.instruction)
    parsed = parse(words)
    if parsed is None:
        api.fallback()
        return
    noun, loc, tw = parsed
    tgt = resolve_target(api, names, bodies, tw)
    if tgt is None:
        api.fallback()
        return
    cands = candidates(bodies, noun, exclude=(tgt[1],))
    if not cands:
        api.fallback()
        return
    try:
        item = pick_candidate(api, names, bodies, cands, loc)
    except Exception:
        item = sorted(cands)[0]
    place_item(api, item, tgt)
