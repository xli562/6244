import math
import numpy as np

COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown',
          'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'to', 'up', 'please', 'that',
        'is', 'which', 'located', 'sitting', 'placed', 'lying'}
REL_WORDS = ('between', 'next', 'beside', 'near', 'on', 'in', 'inside',
             'from', 'at', 'under')
PLACE_VERBS = ('place', 'put', 'set', 'move', 'drop')


def V(*a):
    return np.array(a, dtype=float)


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def E(api):
    return np.array(api.eef(), dtype=float)


def _words(s):
    s = ''.join(c if c.isalnum() else ' ' for c in s.lower())
    return s.split()


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side') or 'table_' in n


def _stem(w):
    if len(w) > 3 and w.endswith('ies'):
        return w[:-3] + 'y'
    if len(w) > 3 and w.endswith('s') and not w.endswith('ss'):
        return w[:-1]
    return w


def _desc(b):
    w = set(_base(b).split('_'))
    w |= {_stem(x) for x in w}
    if 'cookie' in w:
        w |= {'box'}
    if 'stove' in w:
        w |= {'burner', 'cooktop'}
    if 'frypan' in w:
        w |= {'pan', 'frying', 'skillet'}
    if 'mug' in w:
        w |= {'cup'}
    return w


def _match(bodies, ws, exclude=()):
    W = {_stem(w) for w in ws if w not in STOP} | {w for w in ws if w not in STOP}
    best, out = 0, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best:
            best, out = s, [b]
        elif s == best:
            out.append(b)
    return out


# ------------------------------------------------------------ parsing
def parse(words):
    """pick <item phrase> and place it <prep> <target phrase>"""
    if not words or words[0] not in ('pick', 'grab', 'take', 'lift'):
        return None
    j = None
    for i in range(1, len(words) - 1):
        if words[i] == 'and' and words[i + 1] in PLACE_VERBS:
            j = i
            break
    if j is None:
        return None
    first = [w for w in words[1:j] if w != 'up']
    second = words[j + 2:]
    if second and second[0] in ('it', 'them'):
        second = second[1:]
    while second and second[0] in ('on', 'onto', 'into', 'in', 'inside',
                                   'top', 'of', 'the', 'to'):
        second = second[1:] if second[0] != 'top' else second[1:]
    raw_second = words[j + 2:]
    rel, ref = None, []
    item = first
    for i, w in enumerate(first):
        if i > 0 and w in REL_WORDS:
            rel, item, ref = w, first[:i], first[i + 1:]
            break
    return item, rel, ref, second, raw_second


# ------------------------------------------------------------ resolution
def ref_point(api, names, bodies, rel, ref, exclude):
    refs = [w for w in ref if w not in STOP and w not in ('to', 'top', 'of')]
    regions = [n for n in names if _is_region(n)]
    if rel == 'between':
        parts = [[]]
        for w in refs:
            if w == 'and':
                parts.append([])
            else:
                parts[-1].append(w)
        toks = [_stem(w) for p in parts for w in p]
        for r in regions:
            if 'between' in r and all(t in r for t in toks if len(t) > 2):
                return P(api, r), None
        pts = []
        for p in parts:
            m = _match(bodies, p, exclude)
            if m:
                pts.append(P(api, m[0]))
        if pts:
            return np.mean(pts, axis=0), None
        return None, None
    if 'center' in refs or 'centre' in refs:
        for r in regions:
            if 'center' in r:
                return P(api, r), None
    if 'drawer' in refs or 'drawers' in refs:
        m = _match(bodies, refs, exclude)
        lvl = [w for w in ('top', 'middle', 'bottom') if w in ref]
        if m:
            for r in regions:
                if r.startswith(m[0] + '_') and lvl and lvl[0] in r and 'side' not in r:
                    return P(api, r), m[0]
    m = _match(bodies, refs, exclude)
    if not m:
        return None, None
    rb = m[0]
    if rel in ('next', 'beside', 'near'):
        key = _base(rb).split('_')[-1]
        for r in regions:
            if 'next_to' in r and key in r:
                return P(api, r), rb
    if 'stove' in rb:
        for r in regions:
            if r.startswith(rb + '_') and 'cook' in r:
                return P(api, r), rb
    return P(api, rb), rb


def pick_candidate(api, cands, rel, rp, rbody):
    if len(cands) == 1 or rp is None:
        return cands[0]

    def score(c):
        cp = P(api, c)
        d = np.linalg.norm(cp[:2] - rp[:2])
        if rel in ('on',) and rbody is not None:
            # must sit above the reference body
            if cp[2] < rp[2] + 0.01:
                d += 0.3
        if rel in ('next', 'beside', 'near') and rbody is not None:
            # exclude one stacked on the reference
            try:
                bp = P(api, rbody)
                if np.linalg.norm(cp[:2] - bp[:2]) < 0.03 and cp[2] > bp[2] + 0.01:
                    d += 0.3
            except Exception:
                pass
        return d
    return sorted(cands, key=score)[0]


def resolve_target(api, names, bodies, tw, raw, exclude):
    m = _match(bodies, tw, exclude)
    if not m:
        return None
    t = m[0]
    regs = [n for n in names if n.startswith(t + '_') and _is_region(n)]
    if not regs:
        return t
    R = set(raw)
    if 'drawer' in R or 'drawers' in R:
        for lvl in ('top', 'middle', 'bottom'):
            if lvl in R:
                for r in regs:
                    if lvl in r and 'side' not in r:
                        return r
    if 'top' in R:
        for r in regs:
            if r.endswith('top_side'):
                return r
    for r in regs:
        if 'cook' in r or 'heating' in r or 'contain' in r:
            return r
    return t


# ------------------------------------------------------------ skills
BOWL_GRASPS = [(0.0, 0.06, 0.025), (0.0, -0.06, 0.025), (0.0, 0.05, 0.035)]


def drop_z(name):
    if 'basket' in name:
        return 0.11
    if 'caddy' in name:
        return 0.10
    if 'cook' in name:
        return 0.05
    if 'plate' in name:
        return 0.06
    return 0.08


def placed_ok(api, item, name):
    ip, tp = P(api, item), P(api, name)
    tol = 0.08 if ('basket' in name or 'contain' in name) else 0.07
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.06


def recover(api):
    api.grip(False)
    e = E(api)
    api.move(e + V(0, 0, 0.12), steps=15)


def try_grasp(api, item, g):
    p0 = P(api, item)
    p = p0 + V(*g)
    api.grip(False)
    e = E(api)
    api.move(V(e[0], e[1], max(e[2], p[2] + 0.12)), steps=10)
    api.move(p + V(0, 0, 0.10), steps=22)
    api.move(p, steps=18)
    api.grip(True)
    api.move(p + V(0, 0, 0.08), steps=12)
    return P(api, item)[2] - p0[2] > 0.025


def manual_place(api, item, name, options):
    for g in options:
        if not try_grasp(api, item, g):
            recover(api)
            continue
        ip, e = P(api, item), E(api)
        rel = e - ip
        dest = P(api, name) + V(0, 0, drop_z(name))
        eg = dest + rel
        hz = max(e[2], eg[2] + 0.12)
        z0 = P(api, item)[2]
        api.move(V(e[0], e[1], hz), steps=15)
        if P(api, item)[2] < z0 - 0.02:
            recover(api)
            continue
        api.move(V(eg[0], eg[1], hz), steps=35)
        api.move(eg, steps=20)
        api.grip(False)
        e = E(api)
        api.move(e + V(0, 0, 0.10), steps=12)
        if placed_ok(api, item, name):
            return True
    return False


def place_item(api, item, target):
    b = _base(item)
    if 'bowl' in b:
        mode = 'rim'
    elif 'book' in b:
        mode = 'thin_edge'
    else:
        mode = 'standard'
    try:
        api.place_with(item, target, mode)
    except Exception:
        pass
    try:
        if placed_ok(api, item, target):
            return True
    except Exception:
        return False
    try:
        recover(api)
    except Exception:
        pass
    if mode == 'rim':
        opts = BOWL_GRASPS
    else:
        opts = [(0.0, 0.0, 0.0), (0.0, 0.0, -0.01)]
    try:
        return manual_place(api, item, target, opts)
    except Exception:
        return False


# ------------------------------------------------------------ main
def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    words = _words(api.instruction)
    parsed = parse(words)
    if parsed is None or parsed[1] is None:
        api.fallback()
        return
    item_w, rel, ref_w, tgt_w, raw_second = parsed

    target = resolve_target(api, names, bodies, tgt_w, raw_second, ())
    if target is None:
        api.fallback()
        return
    tbody = target if target in bodies else None
    excl = tuple(x for x in (tbody,) if x) + tuple(
        n for n in bodies if target.startswith(n + '_'))

    cands = _match(bodies, item_w, excl)
    if not cands:
        api.fallback()
        return
    rp, rbody = ref_point(api, names, bodies, rel, ref_w, tuple(cands))
    item = pick_candidate(api, cands, rel, rp, rbody)

    ok = place_item(api, item, target)
    if not ok:
        try:
            if not placed_ok(api, item, target):
                manual_place(api, item, target,
                             BOWL_GRASPS[:1] if 'bowl' in _base(item)
                             else [(0.0, 0.0, 0.0)])
        except Exception:
            try:
                recover(api)
            except Exception:
                pass
