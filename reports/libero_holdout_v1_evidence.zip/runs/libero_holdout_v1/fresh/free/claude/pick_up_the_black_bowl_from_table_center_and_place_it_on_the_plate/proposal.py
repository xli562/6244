import math
import numpy as np

# ---------------------------------------------------------------- vocabulary
ALIAS = {
    'akita_black_bowl': 'akita black bowl',
    'black_bowl': 'black bowl',
    'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup',
    'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup',
    'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop',
    'moka_pot': 'moka pot',
    'desk_caddy': 'desk caddy',
    'black_book': 'black book',
    'yellow_book': 'yellow book',
    'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can',
    'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle',
    'ketchup': 'ketchup bottle',
    'butter': 'butter box',
    'milk': 'milk carton',
    'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box',
    'salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet',
    'wooden_cabinet': 'wooden cabinet',
    'wine_bottle': 'wine bottle',
    'wine_rack': 'wine rack',
    'microwave': 'microwave oven',
    'basket': 'basket',
    'plate': 'plate',
    'cookies': 'cookie cookies box',
    'glazed_rim_porcelain_ramekin': 'ramekin glazed porcelain',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown',
          'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'top',
        'left', 'right', 'front', 'back', 'bottom', 'middle', 'compartment',
        'side', 'its', 'that', 'is', 'please', 'then'}
VERBS = {'put', 'place', 'turn', 'switch', 'close', 'shut', 'open', 'pick',
         'push', 'pull', 'move', 'stack', 'lift', 'grab', 'take', 'set'}
PREPS = ('into', 'onto', 'inside', 'in', 'on')
LOCKEYS = ('from', 'on', 'in', 'inside', 'next', 'between', 'at', 'near',
           'beside', 'by', 'under', 'located', 'sitting', 'which')
GENERIC = {'main', 'table', 'next', 'to', 'region', 'contain', 'side',
           'the', 'a', 'an', 'of', 'from', 'on', 'in', 'at'}


def V(*a):
    return np.array(a, dtype=float)


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def E(api):
    return np.array(api.eef(), dtype=float)


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side') or 'table_center' in n \
        or n.startswith('main_table_')


def _words(s):
    s = ''.join(c if c.isalnum() else ' ' for c in s.lower())
    return s.split()


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return w


# ---------------------------------------------------------------- resolution
def cands_for(bodies, raw, exclude=()):
    W = set(w for w in raw if w not in STOP)
    if 'cookie' in W:
        W.add('cookies')
    if not W:
        return []
    best, cands = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, cands = s, [b]
        elif abs(s - best) < 1e-9:
            cands.append(b)
    return cands


def _spatial(api, names, raw, cands):
    for w in ('left', 'right', 'front', 'back'):
        if w in raw:
            head = _base(cands[0]).split('_')[-1]
            hints = [n for n in names if _is_region(n)
                     and w in n.split('_') and head in n.split('_')]
            if hints:
                hp = P(api, hints[0])
                return sorted(cands, key=lambda c: np.linalg.norm(P(api, c)[:2] - hp[:2]))
            keyf = {'left': lambda p: -p[1], 'right': lambda p: p[1],
                    'front': lambda p: p[0], 'back': lambda p: -p[0]}[w]
            return sorted(cands, key=lambda c: keyf(P(api, c)))
    return sorted(cands)


def resolve(api, names, bodies, raw, exclude=()):
    c = cands_for(bodies, raw, exclude)
    if not c:
        return None
    if len(c) > 1:
        c = _spatial(api, names, raw, c)
    return c[0]


def resolve_target(api, names, bodies, raw):
    obj = resolve(api, names, bodies, raw)
    if obj is None:
        return None
    regs = [n for n in names if n.startswith(obj + '_') and
            (n.endswith('_region') or n.endswith('_side'))]
    if not regs:
        return (obj, obj)
    R = set(raw)
    drawer = 'drawer' in R or 'drawers' in R
    best, bs = None, -1e9
    for r in regs:
        suf = r[len(obj) + 1:].split('_')
        toks = set(suf) - {'region', 'contain', 'side'}
        s = 3 * len(toks & R)
        if drawer and 'side' in suf:
            s -= 5
        if (not drawer) and 'top' in R and 'side' in suf:
            s += 2
        if not toks or toks <= {'cook', 'heating'}:
            s += 1
        if s > bs:
            bs, best = s, r
    return (best, obj)


def best_region(names, words, require=None):
    W = set(words)
    if 'cookie' in W or 'cookies' in W:
        W.add('box')
    if 'centre' in W:
        W.add('center')
    best, bs = None, 0.0
    for r in names:
        if not _is_region(r):
            continue
        t = r[len('main_table_'):] if r.startswith('main_table_') else r
        T = set(t.split('_')) - {'region', 'contain'}
        if require and require not in T:
            continue
        m = W & T
        if not (m - GENERIC):
            continue
        s = len(m) - 0.1 * len(T - W)
        if s > bs:
            bs, best = s, r
    return best


def split_phrase(ws):
    for i, w in enumerate(ws):
        if i > 0 and w in LOCKEYS:
            return ws[:i], ws[i:]
    return ws, []


def locator_ref(api, names, bodies, loc, exclude):
    """returns (point, mode) for a phrase like 'from table center'"""
    rest = [w for w in loc[1:] if w not in ('to', 'of', 'the', 'a', 'an', 'top')]
    if 'between' in loc:
        r = best_region(names, loc, require='between')
        if r:
            return P(api, r), 'at'
        parts, cur = [], []
        for w in rest:
            if w == 'and':
                parts.append(cur)
                cur = []
            elif w != 'between':
                cur.append(w)
        parts.append(cur)
        pts = []
        for p in parts:
            b = resolve(api, names, bodies, p, exclude)
            if b:
                pts.append(P(api, b))
        if len(pts) == 2:
            return (pts[0] + pts[1]) / 2.0, 'at'
    if any(w in loc for w in ('next', 'beside', 'near', 'by')):
        ref = resolve(api, names, bodies, rest, exclude)
        if ref:
            r = best_region(names, list(loc) + list(_desc(ref)), require='next')
            if r:
                return P(api, r), 'at'
            return P(api, ref), 'next'
        r = best_region(names, loc, require='next')
        if r:
            return P(api, r), 'at'
    if 'drawer' in loc or 'drawers' in loc:
        tgt = resolve_target(api, names, bodies, loc[1:])
        if tgt and tgt[0] != tgt[1]:
            return P(api, tgt[0]), 'at'
    ref = resolve(api, names, bodies, rest, exclude)
    if ref:
        side = [n for n in names if n.startswith(ref + '_') and n.endswith('_side')]
        cook = [n for n in names if n.startswith(ref + '_') and 'cook' in n]
        if side and ('cabinet' in ref or 'top' in loc):
            return P(api, side[0]), 'at'
        if cook:
            return P(api, cook[0]), 'on'
        return P(api, ref), 'on'
    r = best_region(names, loc)
    if r:
        return P(api, r), 'at'
    return None


def choose(api, cands, ref, mode):
    def xy(c):
        return float(np.linalg.norm(P(api, c)[:2] - ref[:2]))
    if mode == 'next':
        cc = [c for c in cands if xy(c) > 0.04] or cands
        return min(cc, key=xy)
    if mode == 'on':
        return min(cands, key=xy)
    return min(cands, key=lambda c: float(np.linalg.norm(P(api, c) - ref)))


def resolve_item(api, names, bodies, part, exclude=()):
    head, loc = split_phrase(part)
    cands = cands_for(bodies, head, exclude)
    if not cands:
        cands = cands_for(bodies, part, exclude)
    if not cands:
        return None
    if len(cands) == 1:
        return cands[0]
    if loc:
        try:
            r = locator_ref(api, names, bodies, loc, tuple(cands) + tuple(exclude))
        except Exception:
            r = None
        if r is not None:
            return choose(api, cands, r[0], r[1])
    return _spatial(api, names, part, cands)[0]


# ---------------------------------------------------------------- parsing
def split_clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if (w == 'and' and (nxt in VERBS or nxt == 'then')) or w == 'then':
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return [c for c in out if c]


def split_items(ws):
    both = 'both' in ws
    has_the = any(ws[j] == 'and' and j + 1 < len(ws) and ws[j + 1] in ('the', 'a')
                  for j in range(len(ws)))
    parts = [[]]
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if w == 'and' and ((has_the and nxt in ('the', 'a')) or (both and not has_the)):
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def plan(api, names, bodies, words):
    ops = []
    last_items, last_target = [], None
    for c in split_clauses(words):
        while c and c[-1] == 'and':
            c = c[:-1]
        if not c:
            continue
        v, rest = c[0], c[1:]
        if v in ('turn', 'switch', 'push', 'pull'):
            return None
        if v in ('open', 'close', 'shut'):
            if not rest or rest in (['it'], ['them']):
                tgt = last_target
            else:
                tgt = resolve_target(api, names, bodies, rest)
            if (not tgt or tgt[0] == tgt[1] or tgt[0].endswith('_side') or
                    not any(k in tgt[0].split('_') for k in ('top', 'middle', 'bottom'))):
                return None
            ops.append(('drawer', tgt[0], 'open' if v == 'open' else 'close'))
            last_target = tgt
            continue
        if v not in VERBS:
            rest = c
        rest = [w for w in rest if w != 'up']
        if v in ('pick', 'grab', 'lift', 'take'):
            it = resolve_item(api, names, bodies, rest)
            if it:
                ops.append(('pick', it))
                last_items = [it]
            continue
        idx = None
        for i, w in enumerate(rest):
            if w in PREPS and i > 0:
                idx = i
        if idx is None:
            item_w, tw = rest, []
        else:
            item_w, tw = rest[:idx], rest[idx + 1:]
        if not tw or tw in (['it'], ['them']):
            tgt = last_target
        else:
            tgt = resolve_target(api, names, bodies, tw)
        if tgt is None:
            return None
        items = []
        for part in split_items(item_w):
            if part in (['it'], ['them']):
                its = last_items
            else:
                it = resolve_item(api, names, bodies, part, exclude=(tgt[1],))
                its = [it] if it else []
            for it in its:
                if it and it not in items:
                    items.append(it)
        if not items:
            return None
        if ops and ops[-1][0] == 'pick' and ops[-1][1] in items:
            ops.pop()
        for k, it in enumerate(items):
            ops.append(('place', it, tgt, k, len(items)))
        last_items = items
        last_target = tgt
    return ops


# ---------------------------------------------------------------- skills
def grasp_type(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


def grasp_options(item):
    b = _base(item)
    if 'mug' in b or 'cup' in b:
        return [(0.0, 0.03, 0.02), (0.0, -0.03, 0.02)]
    if 'bowl' in b:
        return [(0.0, 0.045, 0.01), (0.0, -0.045, 0.01)]
    return [(0.0, 0.0, 0.0), (0.0, 0.0, -0.01)]


BOWL_GRASPS = [(0.0, 0.06, 0.025), (0.0, -0.06, 0.025)]


def drawer_dir(api, region, owner):
    rp = P(api, region)
    op = P(api, owner) if owner else rp
    d = op[:2] - rp[:2]
    nd = np.linalg.norm(d)
    d = d / nd if nd > 0.03 else np.array([1.0, 0.0])
    return np.array([d[0], d[1], 0.0])


def drop_for(api, item, tgt, k, n):
    name, owner = tgt
    z = 0.08
    off = np.zeros(3)
    if 'basket' in name:
        z = 0.11
    elif 'caddy' in name:
        z = 0.10
    elif 'cook' in name:
        z = 0.05
    elif 'plate' in name:
        z = 0.06
    elif 'cabinet' in owner and name != owner and 'side' not in name:
        z = 0.06
        off = -drawer_dir(api, name, owner) * 0.03
    if n > 1 and ('basket' in name or 'contain' in name) and 'caddy' not in name:
        off[1] += 0.03 if k % 2 == 0 else -0.03
    return (float(off[0]), float(off[1]), float(off[2] + z))


def placed_ok(api, item, name):
    ip, tp = P(api, item), P(api, name)
    tol = 0.07
    if 'basket' in name or 'contain' in name:
        tol = 0.08
    if 'caddy' in name:
        tol = 0.045
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.06


def recover(api):
    api.grip(False)
    e = E(api)
    api.move(e + V(0, 0, 0.12), steps=15)


def try_grasp(api, item, g):
    p0 = P(api, item)
    p = p0 + V(*g)
    api.grip(False)
    e = E(api)
    api.move(V(e[0], e[1], max(e[2], p[2] + 0.12)), steps=10)
    api.move(p + V(0, 0, 0.10), steps=22)
    api.move(p, steps=18)
    api.grip(True)
    api.move(p + V(0, 0, 0.08), steps=12)
    return P(api, item)[2] - p0[2] > 0.025


def manual_place(api, item, tgt, k, n, options):
    name = tgt[0]
    drop = np.array(drop_for(api, item, tgt, k, n))
    for g in options:
        if not try_grasp(api, item, g):
            recover(api)
            continue
        ip = P(api, item)
        e = E(api)
        eg = P(api, name) + drop + (e - ip)
        hz = max(e[2], eg[2] + 0.12)
        z0 = P(api, item)[2]
        api.move(V(e[0], e[1], hz), steps=15)
        if P(api, item)[2] < z0 - 0.02:
            recover(api)
            continue
        api.move(V(eg[0], eg[1], hz), steps=35)
        api.move(eg, steps=20)
        api.grip(False)
        e = E(api)
        api.move(e + V(0, 0, 0.10), steps=12)
        if placed_ok(api, item, name):
            return True
    return False


def do_place(api, item, tgt, k, n):
    name = tgt[0]
    gt = grasp_type(item)
    for _ in range(2):
        try:
            api.place_with(item, name, gt)
        except Exception:
            try:
                api.transfer(item, name, grasp=grasp_options(item)[0],
                             drop=drop_for(api, item, tgt, k, n))
            except Exception:
                pass
        if placed_ok(api, item, name):
            return True
        recover(api)
    if 'bowl' in _base(item):
        return manual_place(api, item, tgt, k, n, BOWL_GRASPS)
    return False


def pick_only(api, item):
    p = P(api, item) + V(*grasp_options(item)[0])
    api.grip(False)
    api.move(p + V(0, 0, 0.12), steps=30)
    api.move(p, steps=25)
    api.grip(True)
    api.move(p + V(0, 0, 0.15), steps=25)


# ---------------------------------------------------------------- main
def run(api):
    try:
        names = list(api.names())
        bodies = [n for n in names if not _is_region(n)]
        ops = plan(api, names, bodies, _words(api.instruction))
    except Exception:
        ops = None
    if not ops:
        api.fallback()
        return
    for op in ops:
        try:
            if op[0] == 'drawer':
                api.drawer(op[1], op[2])
            elif op[0] == 'place':
                do_place(api, op[1], op[2], op[3], op[4])
            elif op[0] == 'pick':
                pick_only(api, op[1])
        except Exception:
            try:
                recover(api)
            except Exception:
                pass
