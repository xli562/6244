def run(api):
    import numpy as np

    text = " ".join(
        api.instruction.lower().replace("-", " ").replace(",", " ").split()
    )
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n
        and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug", "cup"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug",
            "mug", "cup"
        ],
        "red coffee mug": ["red mug", "coffee mug", "mug", "cup"],
        "cream cheese": ["cream cheese box"],
        "black book": ["book"],
        "desk caddy": ["caddy", "organizer"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["stove"],
        "white cabinet": ["cabinet"],
        "wooden cabinet": ["cabinet"],
        "wooden basket": ["basket"],
    }

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        result = [base] + synonyms.get(base, [])
        for word in ("basket", "plate", "bowl", "book", "cabinet", "caddy"):
            if word in base.split():
                result.append(word)
        return sorted(set(result), key=len, reverse=True)

    def mentions(sentence):
        words = sentence.split()
        found = []
        i = 0
        while i < len(words):
            matches = []
            for body in bodies:
                for alias in aliases(body):
                    aw = alias.split()
                    if words[i:i + len(aw)] == aw:
                        matches.append((len(aw), len(alias), body))
            if not matches:
                i += 1
                continue
            best = max((m[0], m[1]) for m in matches)
            candidates = list(dict.fromkeys(
                m[2] for m in matches if (m[0], m[1]) == best
            ))
            selected = candidates[0]
            if len(candidates) > 1:
                nearby = words[max(0, i - 4):i]
                direction = next(
                    (w for w in reversed(nearby)
                     if w in ("left", "right", "front", "back")), None
                )
                if direction:
                    markers = [
                        n for n in names
                        if direction in n.split("_") and "region" in n
                        and any(
                            part in n.split("_")
                            for part in selected.rsplit("_", 1)[0].split("_")
                        )
                    ]
                    if markers:
                        selected = api.nearest(markers[0], candidates)
            found.append((i, i + best[0], selected))
            i += best[0]
        return found

    def region(body, suffix):
        exact = body + "_" + suffix
        return exact if exact in names else None

    cabinet = next((n for n in bodies if "cabinet" in n), None)
    default_level = next(
        (w for w in text.split() if w in ("top", "middle", "bottom")),
        "bottom"
    )

    def drawer_region(sentence):
        level = next(
            (w for w in sentence.split() if w in ("top", "middle", "bottom")),
            default_level
        )
        if cabinet:
            candidate = region(cabinet, level + "_region")
            if candidate:
                return candidate
        return next((
            n for n in names
            if level in n.split("_") and "region" in n
            and ("drawer" in n or "cabinet" in n)
        ), None)

    def destination(sentence, target_body):
        if "drawer" in sentence:
            return drawer_region(sentence)

        if target_body is None:
            return None

        words = sentence.split()
        direction = next(
            (w for w in words if w in ("left", "right", "front", "back")),
            None
        )
        outside = any(phrase in sentence for phrase in (
            "next to", "beside", "to the left of", "to the right of",
            "in front of", "behind"
        ))
        if direction is None and "behind" in words:
            direction = "back"

        compartment = any(w in words for w in (
            "compartment", "section", "slot"
        ))
        fixture = "caddy" in target_body or "cabinet" in target_body

        if direction and (outside or compartment or fixture):
            return api.relative_target(
                target_body, direction, "outside" if outside else "inside"
            )

        if "cabinet" in target_body and any(
            phrase in sentence for phrase in ("on top", "on the top", "on the cabinet")
        ):
            return region(target_body, "top_side") or target_body

        if "stove" in target_body:
            return region(target_body, "cook_region") or target_body

        if any(w in words for w in ("in", "into", "inside")):
            return region(target_body, "contain_region") or target_body
        return target_body

    # Keep action clauses in their original order. "Pick ... and place it"
    # records the object and lets the placement skill perform the grasp.
    verbs = {
        "pick", "grab", "take", "put", "place", "move", "stack",
        "open", "close", "shut", "turn", "switch"
    }
    words = text.split()
    starts = [i for i, word in enumerate(words) if word in verbs]
    if not starts:
        return api.fallback()

    clauses = [
        " ".join(words[start:starts[k + 1] if k + 1 < len(starts) else len(words)])
        for k, start in enumerate(starts)
    ]
    plan = []
    pending = []
    previous_target = None

    for clause in clauses:
        verb = clause.split()[0]
        found = mentions(clause)

        if verb in ("turn", "switch"):
            return api.fallback()

        if verb in ("open", "close", "shut"):
            target = drawer_region(clause)
            if target is None or (
                "drawer" not in text and "cabinet" not in clause
            ):
                return api.fallback()
            plan.append(("drawer", target, "open" if verb == "open" else "close"))
            continue

        if verb in ("pick", "grab", "take"):
            pending = list(dict.fromkeys(m[2] for m in found))
            continue

        clause_words = clause.split()
        separators = [
            i for i, w in enumerate(clause_words)
            if w in ("in", "into", "inside", "on", "onto", "to", "beside", "behind")
        ]
        boundary = separators[0] if separators else len(clause_words)
        sources = list(dict.fromkeys(
            body for start, end, body in found if start < boundary
        ))
        targets = [
            body for start, end, body in found if start >= boundary
        ]

        if not sources:
            sources = pending[:]
        target_body = targets[-1] if targets else None

        if not sources and len(found) >= 2:
            sources = [m[2] for m in found[:-1]]
            target_body = found[-1][2]

        target = destination(clause, target_body)
        if target is None and any(
            w in clause_words for w in ("there", "it", "them")
        ):
            target = previous_target

        if not sources or target is None:
            return api.fallback()

        for item in sources:
            if item != target and item != target_body:
                plan.append(("place", item, target))
        pending = sources
        previous_target = target

    if not plan:
        return api.fallback()

    for operation, first, second in plan:
        if operation == "drawer":
            result = api.drawer(first, second)
        else:
            grasp = (
                "rim" if "bowl" in first
                else "thin_edge" if "book" in first
                else "standard"
            )
            result = api.place_with(first, second, grasp)
        if result is False:
            return
