def run(api):
    import numpy as np

    text = " ".join(
        api.instruction.lower().replace("-", " ").replace(",", " , ")
        .replace(".", " ").replace(";", " ; ").split()
    )
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    def words(name):
        return name.replace("_", " ")

    def base(name):
        return words(name.rsplit("_", 1)[0])

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["porcelain mug", "white mug", "mug"],
        "white yellow mug": [
            "white and yellow mug", "yellow and white mug", "yellow mug", "mug"
        ],
        "red coffee mug": ["red coffee mug", "red mug", "mug"],
        "cream cheese": ["cream cheese box", "cream cheese"],
        "black book": ["black book", "book"],
        "desk caddy": ["desk caddy", "caddy"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["flat stove", "stove"],
        "white cabinet": ["white cabinet", "cabinet"],
    }

    def aliases(name):
        b = base(name)
        result = [b]
        result.extend(synonyms.get(b, []))
        for noun in ("basket", "plate", "bowl", "mug", "book", "cabinet"):
            if noun in b.split():
                result.append(noun)
        return sorted(set(result), key=len, reverse=True)

    def occurrences(fragment):
        padded = " " + fragment + " "
        hits = []
        for n in bodies:
            for alias in aliases(n):
                start = 0
                needle = " " + alias + " "
                while True:
                    i = padded.find(needle, start)
                    if i < 0:
                        break
                    hits.append((i, i + len(needle) - 1, n))
                    start = i + 1
        # A generic noun must not override a more specific object phrase.
        hits = [
            h for h in hits
            if not any(
                q[0] <= h[0] and q[1] >= h[1]
                and q[1] - q[0] > h[1] - h[0]
                for q in hits
            )
        ]
        groups = {}
        for start, end, n in hits:
            groups.setdefault((start, end), []).append(n)

        result = []
        for (start, end), candidates in sorted(groups.items()):
            if len(candidates) == 1:
                chosen = candidates[0]
            else:
                prefix = padded[max(0, start - 35):start].split()
                side = next(
                    (w for w in reversed(prefix)
                     if w in ("left", "right", "front", "back")), None
                )
                marker = None
                if side:
                    noun = padded[start:end].strip().split()[-1]
                    marker = next(
                        (n for n in names
                         if "region" in n and side in n.split("_")
                         and noun in n.split("_")), None
                    )
                if marker:
                    chosen = api.nearest(marker, candidates)
                else:
                    chosen = candidates[0]
            if chosen not in result:
                result.append(chosen)
        return result

    def region(body, suffixes):
        for suffix in suffixes:
            exact = body + "_" + suffix
            if exact in names:
                return exact
        return body

    def drawer_region(fragment, previous=None):
        level = next(
            (w for w in ("top", "middle", "bottom")
             if w in fragment.split()), None
        )
        if level is None and previous:
            return previous
        if level is None:
            levels = [
                w for w in ("top", "middle", "bottom")
                if w in text.split()
            ]
            level = levels[0] if len(levels) == 1 else "bottom"
        fixtures = [
            n for n in occurrences(fragment)
            if "cabinet" in n or "drawer" in n
        ]
        candidates = [
            n for n in names
            if level in n.split("_") and "region" in n
            and ("cabinet" in n or "drawer" in n)
        ]
        if fixtures:
            preferred = [
                n for n in candidates if n.startswith(fixtures[0] + "_")
            ]
            if preferred:
                candidates = preferred
        return candidates[0] if candidates else None

    def target_for(fragment, previous=None, last_drawer=None):
        if "drawer" in fragment:
            return drawer_region(fragment, last_drawer)

        refs = occurrences(fragment)
        if not refs:
            if any(w in fragment.split() for w in ("it", "there", "them")):
                return previous
            return None
        reference = refs[-1]
        tokens = fragment.split()
        direction = next(
            (w for w in tokens if w in ("left", "right", "front", "back")),
            None
        )
        if direction:
            # "Left plate" selects a plate; "left of the plate" is a location.
            positional = (
                "caddy" in reference or "cabinet" in reference
                or "basket" in reference
                or " of " in " " + fragment + " "
                or "next to" in fragment or "beside" in fragment
            )
            if positional:
                outside = (
                    "next to" in fragment or "beside" in fragment
                    or "outside" in fragment
                    or " to the " + direction + " of " in " " + fragment + " "
                    or " on the " + direction + " of " in " " + fragment + " "
                    or "in front of" in fragment or "behind" in fragment
                )
                relation = "outside" if outside else "inside"
                return api.relative_target(reference, direction, relation)

        if "cabinet" in reference and (
            "top" in tokens or "on" in tokens or "onto" in tokens
        ):
            return region(reference, ["top_side", "top_region"])
        if "stove" in reference:
            return region(reference, ["cook_region", "top_side"])
        if any(w in tokens for w in ("in", "into", "inside", "within")):
            return region(reference, ["contain_region", "inside_region"])
        if "basket" in reference:
            return region(reference, ["contain_region"])
        return reference

    # Unsupported articulated actions retain the earlier physical policy.
    if any(phrase in text for phrase in (
        "turn on", "turn off", "switch on", "switch off"
    )):
        return api.fallback()

    tokens = text.split()
    verbs = {
        "pick", "take", "grab", "put", "place", "move", "insert",
        "deposit", "set", "open", "close", "shut"
    }
    starts = [i for i, token in enumerate(tokens) if token in verbs]
    if not starts:
        return api.fallback()

    segments = []
    for k, start in enumerate(starts):
        end = starts[k + 1] if k + 1 < len(starts) else len(tokens)
        segments.append((tokens[start], " ".join(tokens[start + 1:end])))

    plan = []
    pending = []
    previous_target = None
    last_drawer = None

    for verb, fragment in segments:
        if verb in ("open", "close", "shut"):
            d = drawer_region(fragment, last_drawer)
            if not d:
                return api.fallback()
            plan.append(("drawer", d, "open" if verb == "open" else "close"))
            previous_target = d
            last_drawer = d
            continue

        if verb in ("pick", "take", "grab"):
            pending = occurrences(fragment)
            continue

        parts = fragment.split()
        # "From" belongs to the source description. Find the destination
        # preposition after it when one is present.
        prepositions = {"in", "into", "inside", "on", "onto", "to", "within"}
        split_at = next(
            (i for i, token in enumerate(parts) if token in prepositions), None
        )
        if split_at is None:
            return api.fallback()
        source_text = " ".join(parts[:split_at])
        destination_text = " ".join(parts[split_at:])
        if " from " in " " + source_text + " ":
            source_text = source_text.split(" from ", 1)[0]

        items = occurrences(source_text) or list(pending)
        target = target_for(destination_text, previous_target, last_drawer)
        if not target or not items:
            return api.fallback()

        for item in items:
            if target == item or target.startswith(item + "_"):
                continue
            grasp = (
                "rim" if "bowl" in item
                else "thin_edge" if "book" in item
                else "standard"
            )
            plan.append(("place", item, target, grasp))
        pending = items
        previous_target = target

    if not plan:
        return api.fallback()

    for job in plan:
        if job[0] == "drawer":
            api.drawer(job[1], job[2])
        else:
            result = api.place_with(job[1], job[2], job[3])
            if result is False:
                return
