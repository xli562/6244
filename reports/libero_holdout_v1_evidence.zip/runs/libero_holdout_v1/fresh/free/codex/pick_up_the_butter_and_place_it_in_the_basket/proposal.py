def run(api):
    import numpy as np

    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug"
        ],
        "red coffee mug": ["red mug", "coffee mug"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "cream cheese": ["cream cheese box"],
        "black book": ["book"],
        "desk caddy": ["caddy"],
        "flat stove": ["stove"],
        "white cabinet": ["cabinet"],
        "wooden cabinet": ["cabinet"],
    }

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        result = [base] + synonyms.get(base, [])
        if base.endswith(" basket"):
            result.append("basket")
        if base.endswith(" plate"):
            result.append("plate")
        return result

    def mentions(s):
        padded = " " + s + " "
        hits = []
        for body in bodies:
            for alias in aliases(body):
                needle = " " + alias + " "
                start = 0
                while True:
                    i = padded.find(needle, start)
                    if i < 0:
                        break
                    hits.append((i, i + len(needle) - 1, body))
                    start = i + 1
        # A specific name wins over a generic name at the same location.
        hits = [
            h for h in hits
            if not any(
                q[0] <= h[0] and q[1] >= h[1]
                and q[1] - q[0] > h[1] - h[0]
                for q in hits
            )
        ]
        return sorted(set(hits))

    def objects(s):
        result = []
        for _, _, body in mentions(s):
            if body not in result:
                result.append(body)
        return result

    def region(body, suffix):
        exact = body + "_" + suffix
        return exact if exact in names else None

    def direction(s):
        padded = " " + s + " "
        return next(
            (d for d in ("left", "right", "front", "back")
             if " " + d + " " in padded),
            None,
        )

    def drawer_region(s):
        level = next(
            (v for v in ("top", "middle", "bottom") if v in s), None
        )
        candidates = [
            n for n in names
            if "region" in n and
            ("cabinet" in n or "drawer" in n)
            and any("_" + v + "_" in n
                    for v in ("top", "middle", "bottom"))
            and (level is None or "_" + level + "_" in n)
        ]
        fixtures = objects(s)
        narrowed = [
            n for n in candidates
            if any(n.startswith(b + "_") for b in fixtures)
        ]
        candidates = narrowed or candidates
        return candidates[0] if len(candidates) == 1 else None

    def target(s, preposition):
        if "drawer" in s:
            return drawer_region(s)

        candidates = objects(s)
        side = direction(s)
        outside = any(
            phrase in s for phrase in
            ("next to", "beside", "to the left of", "to the right of",
             "in front of", "behind")
        )
        if "behind" in s:
            side = "back"
        if "in front of" in s:
            side = "front"

        if len(candidates) > 1 and side:
            markers = [
                n for n in names
                if side in n and "region" in n
                and any(
                    b.rsplit("_", 1)[0] in n for b in candidates
                )
            ]
            if len(markers) == 1:
                candidates = [api.nearest(markers[0], candidates)]

        if len(candidates) != 1:
            return None
        body = candidates[0]
        if side and (outside or "caddy" in body):
            return api.relative_target(
                body, side, "outside" if outside else "inside"
            )
        if "cabinet" in body and (
            preposition in ("on", "onto") or "top" in s
        ):
            return region(body, "top_side")
        if "stove" in body:
            return region(body, "cook_region") or body
        if preposition in ("in", "into", "inside") or "basket" in body:
            return region(body, "contain_region") or body
        return body

    # Parse before acting so an unsupported instruction can use the old policy.
    words = text.replace(",", " ").replace(".", " ").split()
    verbs = {
        "pick", "grab", "take", "put", "place", "move", "transfer",
        "open", "close", "shut", "turn", "switch", "push", "pull",
    }
    starts = [i for i, w in enumerate(words) if w in verbs]
    if not starts:
        return api.fallback()

    clauses = [
        words[a:(starts[k + 1] if k + 1 < len(starts) else len(words))]
        for k, a in enumerate(starts)
    ]
    pending = []
    plan = []
    last_drawer = None

    for clause in clauses:
        verb = clause[0]
        s = " ".join(clause)
        if verb in ("turn", "switch", "push", "pull"):
            return api.fallback()

        if verb in ("open", "close", "shut"):
            drawer = drawer_region(s)
            if drawer is None and ("it" in clause or "drawer" in clause):
                drawer = last_drawer
            if drawer is None:
                return api.fallback()
            plan.append(("drawer", drawer,
                         "open" if verb == "open" else "close"))
            last_drawer = drawer
            continue

        if verb in ("pick", "grab", "take"):
            source_end = next(
                (i for i, w in enumerate(clause) if w == "from"),
                len(clause),
            )
            pending = objects(" ".join(clause[:source_end]))
            if not pending:
                return api.fallback()
            continue

        separators = [
            i for i, w in enumerate(clause)
            if w in ("in", "into", "inside", "on", "onto", "to")
        ]
        resolved = None
        for i in separators:
            item_text = " ".join(clause[1:i])
            destination_text = " ".join(clause[i + 1:])
            items = objects(item_text) or pending
            destination = target(destination_text, clause[i])
            if destination is not None and items:
                resolved = (items, destination)
                break

        if resolved is None:
            return api.fallback()
        items, destination = resolved
        for item in items:
            if item == destination:
                return api.fallback()
            plan.append(("place", item, destination))
        pending = []
        if "drawer" in s:
            last_drawer = destination

    if pending or not plan:
        return api.fallback()

    for operation, first, second in plan:
        if operation == "drawer":
            api.drawer(first, second)
        else:
            grasp = (
                "rim" if "bowl" in first else
                "thin_edge" if "book" in first else
                "standard"
            )
            api.place_with(first, second, grasp)
