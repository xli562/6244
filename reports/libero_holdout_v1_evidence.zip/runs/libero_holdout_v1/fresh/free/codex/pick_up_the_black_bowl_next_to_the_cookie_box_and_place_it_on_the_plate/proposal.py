def run(api):
    import numpy as np

    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [
        n for n in names
        if n.rsplit("_", 1)[-1].isdigit()
        and "region" not in n and not n.endswith("_side")
    ]

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "cookies": ["cookies box", "cookie box", "cookies"],
        "porcelain mug": ["white mug", "mug"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug", "mug"
        ],
        "red coffee mug": ["red mug", "coffee mug", "mug"],
        "cream cheese": ["cream cheese box"],
        "black book": ["book"],
        "desk caddy": ["caddy"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["stove"],
        "wooden cabinet": ["cabinet"],
        "white cabinet": ["cabinet"],
        "glazed rim porcelain ramekin": ["ramekin"],
    }

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        result = [base] + synonyms.get(base, [])
        if base.endswith(" basket"):
            result.append("basket")
        return result

    def mentions(sentence):
        padded = " " + sentence + " "
        hits = []
        for name in bodies:
            for alias in aliases(name):
                start = padded.find(" " + alias + " ")
                if start >= 0:
                    hits.append((start, start + len(alias), name))
        # Suppress generic aliases contained in more specific mentions.
        return [
            h for h in hits
            if not any(
                k[0] <= h[0] and k[1] >= h[1]
                and k[1] - k[0] > h[1] - h[0]
                for k in hits
            )
        ]

    def unique(sequence):
        return list(dict.fromkeys(sequence))

    def first_group(sentence):
        hits = mentions(sentence)
        if not hits:
            return []
        start = min(h[0] for h in hits)
        return unique(h[2] for h in hits if h[0] == start)

    def nearby(reference, candidates):
        if len(candidates) == 1:
            return candidates[0]
        return api.nearest(reference, candidates)

    def resolve(sentence):
        candidates = first_group(sentence)
        if not candidates:
            return None
        if len(candidates) == 1:
            return candidates[0]

        hits = mentions(sentence)
        references = unique(h[2] for h in hits if h[2] not in candidates)
        if references:
            reference = references[-1]
            direction = next(
                (d for d in ("left", "right", "front", "back")
                 if d in sentence.split()), None
            )
            if direction:
                region = api.relative_target(reference, direction, "outside")
                return nearby(region, candidates)
            return nearby(reference, candidates)

        # Named table regions often distinguish identical objects.
        markers = [
            n for n in names
            if "region" in n and any(
                d in sentence.split() and d in n.split("_")
                for d in ("left", "right", "front", "back", "center")
            )
        ]
        compatible = [
            n for n in markers
            if any(
                word in n.split("_")
                for word in aliases(candidates[0])[0].split()
            )
        ]
        if len(compatible) == 1:
            return nearby(compatible[0], candidates)
        if len(markers) == 1:
            return nearby(markers[0], candidates)
        return None

    def region_for(body, suffix):
        exact = body + "_" + suffix
        return exact if exact in names else None

    def drawer_region(sentence, previous=None):
        level = next(
            (d for d in ("bottom", "middle", "top")
             if d in sentence.split()), None
        )
        fixtures = [
            n for n in bodies
            if "cabinet" in n or "drawer" in n
        ]
        explicit = [n for n in fixtures if n in first_group(sentence)]
        if explicit:
            fixtures = explicit
        if level:
            choices = [
                region_for(n, level + "_region") for n in fixtures
            ]
            choices = [n for n in choices if n]
            if len(choices) == 1:
                return choices[0]
        if previous:
            return previous
        return None

    def target_for(sentence, previous_drawer):
        if "drawer" in sentence:
            return drawer_region(sentence, previous_drawer)

        body = resolve(sentence)
        if body is None:
            return None

        direction = next(
            (d for d in ("left", "right", "front", "back")
             if d in sentence.split()), None
        )
        if direction:
            outside = (
                "next to" in sentence or "side of" in sentence
                or "to the left of" in sentence
                or "to the right of" in sentence
                or "in front of" in sentence
                or "behind" in sentence
            )
            compartment = (
                "compartment" in sentence or "caddy" in body
                or "inside" in sentence
            )
            if outside or compartment:
                return api.relative_target(
                    body, direction, "outside" if outside else "inside"
                )

        if "cabinet" in body and (
            "on" in sentence.split() or "top" in sentence.split()
        ):
            return region_for(body, "top_side")
        if "stove" in body:
            return region_for(body, "cook_region") or body
        if any(w in sentence.split() for w in ("in", "into", "inside")):
            return region_for(body, "contain_region") or body
        return body

    # Separate action clauses while retaining source descriptions such as
    # "the bowl next to the cookies box".
    verbs = {
        "pick", "grab", "take", "put", "place", "move", "stack",
        "open", "close", "shut", "turn"
    }
    words = text.replace(",", " , ").replace(".", " ").split()
    starts = [i for i, w in enumerate(words) if w in verbs]
    if not starts:
        return api.fallback()
    clauses = []
    for index, start in enumerate(starts):
        end = starts[index + 1] if index + 1 < len(starts) else len(words)
        chunk = words[start:end]
        while chunk and chunk[-1] in ("and", "then", ","):
            chunk.pop()
        clauses.append(" ".join(chunk))

    plan = []
    selected = None
    last_drawer = None

    for clause in clauses:
        verb = clause.split()[0]
        if verb == "turn":
            return api.fallback()

        if verb in ("open", "close", "shut"):
            region = drawer_region(clause, last_drawer)
            if region is None:
                return api.fallback()
            last_drawer = region
            plan.append(("drawer", region, "open" if verb == "open" else "close"))
            continue

        if verb in ("pick", "grab", "take"):
            selected = resolve(clause)
            if selected is None:
                return api.fallback()
            continue

        # Test separators from left to right: source-location phrases are
        # rejected unless their left side contains a movable object.
        separators = (
            " on top of ", " onto ", " into ", " inside ",
            " on ", " in ", " to "
        )
        options = []
        for separator in separators:
            offset = 0
            while True:
                at = clause.find(separator, offset)
                if at < 0:
                    break
                options.append((at, separator))
                offset = at + len(separator)

        chosen = None
        for at, separator in sorted(options, reverse=True):
            source_text = clause[:at]
            destination_text = separator.strip() + " " + clause[at + len(separator):]
            item = resolve(source_text)
            if item is None and any(
                p in source_text.split() for p in ("it", "them", "that")
            ):
                item = selected
            if item is None:
                continue
            target = target_for(destination_text, last_drawer)
            if target is None or target == item:
                continue

            # More than one explicitly requested source is handled in order.
            source_hits = mentions(source_text)
            sources = [item]
            if " and " in source_text and "next to" not in source_text:
                groups = source_text.split(" and ")
                resolved = [resolve(group) for group in groups]
                if all(resolved):
                    sources = unique(resolved)
            chosen = (sources, target)
            break

        if chosen is None:
            return api.fallback()
        for item in chosen[0]:
            plan.append(("place", item, chosen[1]))
        selected = chosen[0][-1]

    if not plan:
        return api.fallback()

    for action, item, target in plan:
        if action == "drawer":
            api.drawer(item, target)
        else:
            grasp = (
                "rim" if "bowl" in item
                else "thin_edge" if "book" in item
                else "standard"
            )
            api.place_with(item, target, grasp)
