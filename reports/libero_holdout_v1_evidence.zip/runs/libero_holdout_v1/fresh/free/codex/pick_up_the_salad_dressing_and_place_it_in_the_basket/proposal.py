def run(api):
    import numpy as np

    text = " ".join(
        api.instruction.lower().replace("-", " ").replace(",", " ").split()
    )
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug"
        ],
        "red coffee mug": ["red mug", "coffee mug"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "black book": ["book"],
        "desk caddy": ["caddy"],
        "flat stove": ["stove"],
        "white cabinet": ["cabinet"],
        "cream cheese": ["cream cheese box"],
        "salad dressing": ["salad dressing bottle"],
    }

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        result = [base] + synonyms.get(base, [])
        if base.endswith(" basket"):
            result.append("basket")
        return result

    def mentions(sentence, pool=None):
        """Keep specific mentions in preference to overlapping generic names."""
        padded = " " + sentence + " "
        hits = []
        for body in bodies if pool is None else pool:
            for alias in aliases(body):
                needle = " " + alias + " "
                start = padded.find(needle)
                while start >= 0:
                    hits.append((start, start + len(needle) - 1, body))
                    start = padded.find(needle, start + 1)
        selected = []
        for hit in sorted(hits, key=lambda h: -(h[1] - h[0])):
            if not any(hit[0] < h[1] and h[0] < hit[1] for h in selected):
                selected.append(hit)
        return sorted(selected)

    def region(body, suffixes):
        for suffix in suffixes:
            exact = body + "_" + suffix
            if exact in names:
                return exact
        return None

    def direction(sentence):
        words = sentence.split()
        return next((w for w in words if w in (
            "left", "right", "front", "back"
        )), None)

    def resolve_body(sentence):
        hits = mentions(sentence)
        if not hits:
            return None
        body = hits[-1][2]
        side = direction(sentence)
        if side:
            base = body.rsplit("_", 1)[0]
            candidates = [
                n for n in bodies if n.rsplit("_", 1)[0] == base
            ]
            if len(candidates) > 1:
                markers = [
                    n for n in names
                    if base in n and side in n and "region" in n
                ]
                if markers:
                    body = api.nearest(markers[0], candidates)
        return body

    last_drawer = None

    def drawer_target(sentence):
        nonlocal last_drawer
        cabinets = [n for n in bodies if "cabinet" in n]
        cabinet = resolve_body(sentence)
        if cabinet not in cabinets:
            cabinet = cabinets[0] if len(cabinets) == 1 else None
        level = next(
            (w for w in ("top", "middle", "bottom")
             if w in sentence.split()),
            None,
        )
        if last_drawer and level is None:
            return last_drawer
        candidates = [
            n for n in names
            if "region" in n
            and any(s + "_region" in n for s in ("top", "middle", "bottom"))
            and (cabinet is None or n.startswith(cabinet + "_"))
            and (level is None or level + "_region" in n)
        ]
        if len(candidates) == 1:
            last_drawer = candidates[0]
        elif cabinet and level:
            last_drawer = region(cabinet, [level + "_region"])
        else:
            return None
        return last_drawer

    def destination(sentence):
        if "drawer" in sentence:
            return drawer_target(sentence)

        body = resolve_body(sentence)
        if body is None:
            readable = " " + sentence + " "
            matches = [
                n for n in names
                if " " + n.replace("_", " ") + " " in readable
            ]
            return max(matches, key=len) if matches else None

        side = direction(sentence)
        if side and any(w in sentence for w in (
            "caddy", "cabinet", "basket", "shelf"
        )):
            outside = any(w in sentence for w in (
                "next to", "beside", "outside", "to the left of",
                "to the right of", "in front of", "behind"
            ))
            return api.relative_target(
                body, side, "outside" if outside else "inside"
            )

        if "cabinet" in body and (
            "on" in sentence.split() or "top" in sentence.split()
        ):
            return region(body, ["top_side", "top_region"])

        if "stove" in body:
            return region(body, ["cook_region"]) or body

        inside = any(w in sentence.split() for w in ("in", "into", "inside"))
        if inside or "basket" in body:
            return region(body, ["contain_region"]) or body
        return body

    # Parse before executing so an unsupported instruction can use the old policy.
    words = text.split()
    verbs = {
        "pick", "take", "put", "place", "move", "insert", "stack",
        "open", "close", "shut", "turn"
    }
    starts = [i for i, w in enumerate(words) if w in verbs]
    if not starts:
        return api.fallback()

    clauses = [
        (words[i], " ".join(words[i + 1:j]))
        for i, j in zip(starts, starts[1:] + [len(words)])
    ]
    pending = []
    plan = []

    for verb, clause in clauses:
        if verb == "turn":
            return api.fallback()

        if verb in ("open", "close", "shut"):
            target = drawer_target(clause)
            if target is None:
                return api.fallback()
            plan.append(("drawer", target, "open" if verb == "open" else "close"))
            continue

        if verb in ("pick", "take"):
            pending = list(dict.fromkeys(h[2] for h in mentions(clause)))
            if not pending:
                return api.fallback()
            continue

        tokens = clause.split()
        boundaries = [
            i for i, w in enumerate(tokens)
            if w in ("in", "into", "inside", "on", "onto", "to")
        ]
        resolved = None
        for boundary in boundaries:
            source_text = " ".join(tokens[:boundary])
            target_text = " ".join(tokens[boundary:])
            items = list(dict.fromkeys(h[2] for h in mentions(source_text)))
            if not items:
                items = pending[:]
            if not items:
                continue
            target = destination(target_text)
            if target and all(
                target != item and not target.startswith(item + "_")
                for item in items
            ):
                resolved = (items, target)
                break

        if resolved is None:
            return api.fallback()
        items, target = resolved
        for item in items:
            grasp = (
                "rim" if "bowl" in item else
                "thin_edge" if "book" in item else
                "standard"
            )
            plan.append(("place", item, target, grasp))
        pending = items

    if not plan:
        return api.fallback()

    for action in plan:
        if action[0] == "drawer":
            result = api.drawer(action[1], action[2])
        else:
            result = api.place_with(action[1], action[2], action[3])
        if result is False:
            return
