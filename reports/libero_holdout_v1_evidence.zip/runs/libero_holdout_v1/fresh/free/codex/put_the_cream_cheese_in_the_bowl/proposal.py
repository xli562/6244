def run(api):
    import numpy as np

    text = " ".join(
        api.instruction.lower().replace("-", " ").replace(",", " ").split()
    )
    names = list(api.names())
    bodies = [
        n for n in names
        if n.rsplit("_", 1)[-1].isdigit()
        and "region" not in n and not n.endswith("_side")
    ]

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug", "cup"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug", "mug"
        ],
        "red coffee mug": ["red coffee mug", "red mug", "mug"],
        "cream cheese": ["cream cheese box", "cream cheese"],
        "black book": ["black book", "book"],
        "desk caddy": ["desk caddy", "caddy", "organizer"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["stove"],
        "wooden cabinet": ["wooden cabinet", "cabinet"],
        "white cabinet": ["white cabinet", "cabinet"],
    }

    def words(s):
        return s.replace("_", " ").split()

    def aliases(n):
        base = n.rsplit("_", 1)[0].replace("_", " ")
        result = [base] + synonyms.get(base, [])
        for noun in ("bowl", "plate", "basket", "book", "mug",
                     "cabinet", "bottle", "rack", "caddy"):
            if noun in base.split():
                result.append(noun)
        return list(set(result))

    def mentions(s):
        tokens = s.split()
        hits = []
        for n in bodies:
            for alias in aliases(n):
                a = alias.split()
                for i in range(len(tokens) - len(a) + 1):
                    if tokens[i:i + len(a)] == a:
                        hits.append((i, i + len(a), n))
        # A specific name suppresses overlapping generic names.
        hits.sort(key=lambda h: (-(h[1] - h[0]), h[0]))
        selected = []
        for h in hits:
            overlaps = [
                x for x in selected if h[0] < x[1] and x[0] < h[1]
            ]
            if not overlaps or all(h[:2] == x[:2] for x in overlaps):
                if h not in selected:
                    selected.append(h)
        return sorted(selected)

    def resolve(s):
        hits = mentions(s)
        if not hits:
            return []
        result = []
        spans = sorted(set((h[0], h[1]) for h in hits))
        tokens = s.split()
        for start, end in spans:
            candidates = list(dict.fromkeys(
                h[2] for h in hits if h[:2] == (start, end)
            ))
            prefix = tokens[max(0, start - 4):start]
            side = next(
                (w for w in reversed(prefix)
                 if w in ("left", "right", "front", "back")), None
            )
            if len(candidates) > 1 and side:
                noun = tokens[end - 1]
                markers = [
                    n for n in names
                    if "region" in n and side in words(n)
                    and noun in words(n)
                ]
                if markers:
                    candidates = [api.nearest(markers[0], candidates)]
            if len(candidates) > 1:
                # Never invent a world-coordinate meaning for left/right.
                return []
            if candidates[0] not in result:
                result.append(candidates[0])
        return result

    def region(body, suffix):
        exact = body + "_" + suffix
        return exact if exact in names else None

    def drawer_region(s, previous=None):
        fixtures = [n for n in resolve(s) if "cabinet" in n]
        if not fixtures:
            fixtures = [n for n in bodies if "cabinet" in n]
        level = next(
            (v for v in ("top", "middle", "bottom") if v in s.split()), None
        )
        if level is None and previous:
            return previous
        if len(fixtures) != 1 or level is None:
            return None
        return region(fixtures[0], level + "_region")

    def destination(s, previous_drawer):
        if "drawer" in s:
            return drawer_region(s, previous_drawer)

        targets = resolve(s)
        if len(targets) != 1:
            return None
        body = targets[0]
        tokens = s.split()
        direction = next(
            (v for v in tokens if v in ("left", "right", "front", "back")),
            None,
        )
        outside = any(p in s for p in (
            "next to", "beside", "to the left of", "to the right of",
            "on the left of", "on the right of", "in front of",
            "in back of", "behind",
        ))
        if "behind" in tokens:
            direction = "back"
        inside = any(v in tokens for v in ("in", "into", "inside"))
        # "Left plate" identifies a plate; "left of the plate" is a region.
        compartment = "caddy" in body or "compartment" in s
        if direction and (outside or compartment):
            return api.relative_target(
                body, direction, "outside" if outside else "inside"
            )
        if "cabinet" in body and ("on" in tokens or "top" in tokens):
            return region(body, "top_side")
        if "stove" in body:
            return region(body, "cook_region") or body
        if "rack" in body and ("on" in tokens or "top" in tokens):
            return region(body, "top_region") or body
        if inside or "basket" in body:
            return region(body, "contain_region") or body
        return body

    # Construct the complete ordered plan before moving anything.
    tokens = text.replace(".", " ").replace(";", " ").split()
    verbs = {
        "put", "place", "move", "transfer", "insert", "stack",
        "open", "close", "shut", "pick", "take", "turn",
    }
    starts = [i for i, w in enumerate(tokens) if w in verbs]
    if not starts:
        return api.fallback()
    starts.append(len(tokens))
    plan = []
    pending = []
    last_drawer = None
    last_target = None

    for a, b in zip(starts[:-1], starts[1:]):
        verb = tokens[a]
        clause = tokens[a + 1:b]
        while clause and clause[-1] in ("and", "then"):
            clause.pop()
        s = " ".join(clause)

        if verb == "turn":
            return api.fallback()

        if verb in ("open", "close", "shut"):
            target = drawer_region(s, last_drawer)
            if target is None:
                return api.fallback()
            plan.append(("drawer", target, "open" if verb == "open" else "close"))
            last_drawer = target
            continue

        if verb in ("pick", "take"):
            pending = resolve(s.split(" from ")[0])
            if not pending:
                return api.fallback()
            continue

        separators = [
            i for i, w in enumerate(clause)
            if w in ("on", "onto", "in", "into", "inside", "to",
                     "beside", "behind", "under", "above", "next")
        ]
        if not separators:
            return api.fallback()
        split = separators[0]
        source_text = " ".join(clause[:split])
        target_text = " ".join(clause[split:])
        if "under" in target_text.split() or "above" in target_text.split():
            return api.fallback()

        items = resolve(source_text)
        if not items and any(w in source_text.split() for w in ("it", "them")):
            items = pending
        target = destination(target_text, last_drawer)
        if target is None and target_text in ("in it", "into it", "inside it"):
            target = last_drawer or last_target
        if target is None and target_text in ("on it", "onto it", "there"):
            target = last_target
        if not items or target is None or target in items:
            return api.fallback()

        for item in items:
            grasp = (
                "rim" if "bowl" in item else
                "thin_edge" if "book" in item else
                "standard"
            )
            plan.append(("place", item, target, grasp))
        pending = items
        last_target = target
        if "drawer" in target_text:
            last_drawer = target

    if not plan or plan[-1][0] not in ("place", "drawer"):
        return api.fallback()

    for job in plan:
        if job[0] == "drawer":
            result = api.drawer(job[1], job[2])
        else:
            result = api.place_with(job[1], job[2], job[3])
        if isinstance(result, (bool, np.bool_)) and not result:
            return
