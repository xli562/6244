import numpy as np


def run(api):
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [
        n for n in names
        if n.rsplit("_", 1)[-1].isdigit() and "region" not in n
    ]

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug", "mug"
        ],
        "red coffee mug": ["red mug", "coffee mug", "mug"],
        "cookies": ["cookies box", "cookie box", "cookies"],
        "cream cheese": ["cream cheese box", "cream cheese"],
        "black book": ["black book", "book"],
        "desk caddy": ["desk caddy", "caddy"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["stove"],
        "wooden cabinet": ["wooden cabinet", "cabinet"],
        "white cabinet": ["white cabinet", "cabinet"],
        "glazed rim porcelain ramekin": ["ramekin"],
    }

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        return [base] + synonyms.get(base, [])

    def contains(phrase, passage):
        return (" " + phrase + " ") in (" " + passage + " ")

    def matches(passage, pool=None):
        pool = bodies if pool is None else pool
        scores = {
            n: max(
                [len(a) for a in aliases(n) if contains(a, passage)] or [0]
            )
            for n in pool
        }
        best = max(scores.values(), default=0)
        return [n for n in pool if scores[n] == best and best > 0]

    def position(name):
        return np.asarray(api.pos(name), dtype=float)

    def nearest(reference, candidates):
        if len(candidates) == 1:
            return candidates[0]
        return api.nearest(reference, candidates)

    def region(body, suffix):
        return next(
            (n for n in names if n == body + "_" + suffix), None
        )

    def resolve(passage, pool=None):
        candidates = matches(passage, pool)
        if not candidates:
            return None
        if len(candidates) == 1:
            return candidates[0]

        # A source relation identifies an instance, not another object to move.
        relations = [
            " on top of ", " on ", " inside ", " in ",
            " next to ", " near ", " above ",
        ]
        for relation in relations:
            if relation not in passage:
                continue
            left, right = passage.split(relation, 1)
            subjects = matches(left, candidates)
            references = matches(right, [n for n in bodies if n not in candidates])
            if subjects and references:
                reference = references[0]
                if relation in (" on ", " on top of ", " above "):
                    q = position(reference)
                    return min(
                        subjects,
                        key=lambda n: (
                            np.linalg.norm(position(n)[:2] - q[:2])
                            + 2.0 * max(0.0, q[2] - position(n)[2])
                        ),
                    )
                return nearest(reference, subjects)

        # Use observed location markers to distinguish identical instances.
        words = passage.split()
        for direction in ("left", "right", "front", "back"):
            if direction not in words:
                continue
            markers = [
                n for n in names
                if direction in n.split("_")
                and any(
                    a.replace(" ", "_") in n
                    for candidate in candidates for a in aliases(candidate)
                )
            ]
            if markers:
                return nearest(markers[0], candidates)
        return candidates[0]

    def drawer_region(passage):
        level = next(
            (w for w in ("top", "middle", "bottom") if contains(w, passage)),
            None,
        )
        cabinets = [n for n in bodies if "cabinet" in n]
        cabinet = resolve(passage, cabinets)
        if cabinet is None and len(cabinets) == 1:
            cabinet = cabinets[0]
        if cabinet is None or level is None:
            return None
        return region(cabinet, level + "_region")

    def destination(passage):
        if "drawer" in passage:
            return drawer_region(passage)

        target = resolve(passage)
        if target is None:
            return None

        direction = next(
            (w for w in ("left", "right", "front", "back")
             if contains(w, passage)),
            None,
        )
        outside = any(
            phrase in passage
            for phrase in (
                "next to", "to the left of", "to the right of",
                "in front of", "behind", "at the back of",
            )
        )
        if "behind" in passage:
            direction = "back"
        if direction and outside:
            return api.relative_target(target, direction, "outside")
        if direction and (
            "caddy" in target or "compartment" in passage
            or "inside" in passage or passage.startswith(("in ", "into "))
        ):
            return api.relative_target(target, direction, "inside")

        if "cabinet" in target and (
            "on" in passage or "top" in passage
        ):
            return region(target, "top_side")

        # Named table locations are useful even when no direction is specified.
        if outside:
            markers = [
                n for n in names
                if "next_to" in n
                and any(a.replace(" ", "_") in n for a in aliases(target))
            ]
            if markers:
                return markers[0]

        if "stove" in target:
            return region(target, "cook_region") or target
        if passage.startswith(("in ", "into ", "inside ")) or "basket" in target:
            return region(target, "contain_region") or target
        return target

    def item_list(passage):
        result = []
        for part in passage.replace(",", " and ").split(" and "):
            item = resolve(part)
            if item and item not in result:
                result.append(item)
        # Color aliases can themselves contain "and".
        whole = resolve(passage)
        if whole and not result:
            result.append(whole)
        return result

    # Build the complete ordered plan before executing physical actions.
    normalized = text.replace(",", " , ").replace(".", " ")
    words = normalized.split()
    verbs = {"pick", "put", "place", "move", "stack", "open", "close"}
    starts = [i for i, word in enumerate(words) if word in verbs]
    if not starts or any(
        phrase in text
        for phrase in ("turn on", "turn off", "switch on", "switch off")
    ):
        return api.fallback()

    plan = []
    selected = []
    last_drawer = None
    for index, start in enumerate(starts):
        end = starts[index + 1] if index + 1 < len(starts) else len(words)
        verb = words[start]
        clause = " ".join(words[start + 1:end])
        while clause.endswith((" and", " then", " ,")):
            clause = clause.rsplit(" ", 1)[0]

        if verb in ("open", "close"):
            target = drawer_region(clause)
            if target is None and ("it" in clause or "drawer" in clause):
                target = last_drawer
            if target is None:
                return api.fallback()
            last_drawer = target
            plan.append(("drawer", target, verb))
            continue

        if verb == "pick":
            selected = item_list(clause)
            if not selected:
                return api.fallback()
            continue

        # The final placement preposition separates source descriptions from
        # the destination: "bowl on the cookies box ... on the plate".
        separators = [
            " on top of ", " into ", " inside ", " onto ",
            " on ", " in ", " to ",
        ]
        boundaries = [
            (clause.rfind(separator), separator)
            for separator in separators if separator in clause
        ]
        if not boundaries:
            return api.fallback()
        split, separator = max(boundaries, key=lambda pair: pair[0])
        source = clause[:split]
        target_text = clause[split + 1:]

        # Keep spatial destination phrases intact.
        for phrase in (
            " to the left of ", " to the right of ", " in front of ",
            " next to ", " at the back of ",
        ):
            boundary = clause.find(phrase)
            if boundary >= 0:
                source = clause[:boundary]
                target_text = clause[boundary + 1:]
                break

        items = item_list(source) or selected
        target = destination(target_text)
        if not items or target is None:
            return api.fallback()
        for item in items:
            if item == target:
                return api.fallback()
            grasp = (
                "rim" if "bowl" in item else
                "thin_edge" if "book" in item else
                "standard"
            )
            plan.append(("place", item, target, grasp))
        selected = items

    if not plan:
        return api.fallback()

    for operation in plan:
        if operation[0] == "drawer":
            api.drawer(operation[1], operation[2])
        else:
            api.place_with(operation[1], operation[2], operation[3])
