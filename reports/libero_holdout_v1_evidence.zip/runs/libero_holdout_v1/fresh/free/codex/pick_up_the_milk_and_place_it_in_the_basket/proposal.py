def run(api):
    import numpy as np

    text = " ".join(
        api.instruction.lower().replace("-", " ").replace(",", " and ")
        .replace(".", " ").split()
    )
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]
    mappings = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug", "mug"
        ],
        "red coffee mug": ["red mug", "coffee mug", "mug"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "cream cheese": ["cream cheese box"],
        "black book": ["book"],
        "desk caddy": ["caddy"],
        "flat stove": ["stove"],
        "white cabinet": ["cabinet"],
        "wooden cabinet": ["cabinet"],
    }

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        result = [base] + mappings.get(base, [])
        if "bowl" in base:
            result.append("bowl")
        if "plate" in base:
            result.append("plate")
        return sorted(set(result), key=len, reverse=True)

    def mentions(sentence):
        padded = " " + sentence + " "
        hits = {}
        for body in bodies:
            for alias in aliases(body):
                start = 0
                needle = " " + alias + " "
                while True:
                    i = padded.find(needle, start)
                    if i < 0:
                        break
                    key = (i, i + len(alias))
                    hits.setdefault(key, []).append(body)
                    start = i + 1
        selected = []
        for span in sorted(hits, key=lambda s: (-(s[1] - s[0]), s[0])):
            if not any(span[0] < b and a < span[1] for a, b, _ in selected):
                selected.append((span[0], span[1], list(dict.fromkeys(hits[span]))))
        return sorted(selected)

    def resolve(hit, sentence):
        start, end, candidates = hit
        if len(candidates) == 1:
            return candidates[0]
        prefix = sentence[max(0, start - 35):start]
        direction = next(
            (d for d in ("left", "right", "front", "back")
             if d in prefix.split()), None
        )
        if direction:
            markers = [
                n for n in names
                if "region" in n and direction in n.split("_")
                and any(
                    c.rsplit("_", 1)[0] in n for c in candidates
                )
            ]
            if len(markers) == 1:
                return api.nearest(markers[0], candidates)
        return None

    def region(body, suffixes):
        for suffix in suffixes:
            candidate = body + "_" + suffix
            if candidate in names:
                return candidate
        return body

    def drawer_region(sentence):
        level = next(
            (s for s in ("bottom", "middle", "top")
             if s in sentence.split()), None
        )
        candidates = [
            n for n in names
            if "region" in n and ("cabinet" in n or "drawer" in n)
            and (level is None or level in n.split("_"))
            and any(s in n.split("_") for s in ("bottom", "middle", "top"))
        ]
        return candidates[0] if len(candidates) == 1 else None

    # Segment at action verbs while retaining noun conjunctions.
    verbs = {
        "pick", "take", "grab", "put", "place", "move", "insert",
        "drop", "open", "close", "shut", "turn", "switch", "push",
        "pull", "stack",
    }
    words = text.split()
    starts = [i for i, word in enumerate(words) if word in verbs]
    if not starts:
        return api.fallback()
    clauses = [
        " ".join(words[start:(starts[j + 1] if j + 1 < len(starts)
                               else len(words))])
        for j, start in enumerate(starts)
    ]

    plan = []
    held_items = []
    last_target = None
    last_drawer = None

    for clause in clauses:
        verb = clause.split()[0]
        hits = mentions(clause)
        resolved = [resolve(hit, clause) for hit in hits]
        if any(n is None for n in resolved):
            return api.fallback()

        if verb in ("turn", "switch", "push", "pull"):
            return api.fallback()

        if verb in ("open", "close", "shut"):
            target = drawer_region(clause)
            if target is None and ("it" in clause.split() or
                                   "drawer" in clause.split()):
                target = last_drawer
            if target is None:
                return api.fallback()
            plan.append(("drawer", target, "open" if verb == "open" else "close"))
            last_drawer = target
            last_target = target
            continue

        # A pick clause can describe an object's source location.
        if verb in ("pick", "take", "grab"):
            if not resolved:
                return api.fallback()
            first = resolved[0]
            held_items = [first]
            for index in range(1, len(hits)):
                between = clause[hits[index - 1][1]:hits[index][0]]
                if any(w in between.split()
                       for w in ("from", "in", "inside", "on", "near", "of")):
                    break
                held_items.append(resolved[index])
            continue

        target = None
        target_body = None
        if "drawer" in clause.split():
            target = drawer_region(clause) or last_drawer
            last_drawer = target
        elif len(resolved) >= 2 or (held_items and resolved):
            target_body = resolved[-1]
            target = target_body
        elif last_target and any(
            word in clause.split() for word in ("it", "there", "inside")
        ):
            target = last_target

        if target is None:
            return api.fallback()

        if target_body:
            target_start = hits[-1][0]
            # Only destination wording determines the spatial relationship.
            source_end = hits[0][1] if len(hits) >= 2 else 0
            destination_words = clause[source_end:target_start].split()
            directions = [
                word for word in destination_words
                if word in ("left", "right", "front", "back")
            ]
            if directions and ("caddy" in target_body or "cabinet" in target_body):
                outside = (
                    "next to" in clause or "beside" in destination_words
                    or "outside" in destination_words
                )
                inside = any(
                    word in destination_words for word in ("in", "into", "inside")
                )
                if outside or inside:
                    target = api.relative_target(
                        target_body, directions[-1],
                        "outside" if outside else "inside"
                    )
                else:
                    return api.fallback()
            elif "cabinet" in target_body or "caddy" in target_body:
                if "top" in destination_words or "on" in destination_words:
                    target = region(target_body, ["top_side", "top_region"])
                else:
                    target = region(target_body, ["contain_region"])
            elif "stove" in target_body:
                target = region(target_body, ["cook_region"])
            elif any(word in destination_words for word in ("in", "into", "inside")):
                target = region(target_body, ["contain_region"])

        items = [n for n in resolved if n != target_body
                 and "cabinet" not in n and "caddy" not in n]
        if not items:
            items = held_items[:]
        if not items or target is None:
            return api.fallback()

        for item in dict.fromkeys(items):
            if item == target:
                return api.fallback()
            grasp = (
                "rim" if "bowl" in item else
                "thin_edge" if "book" in item else
                "standard"
            )
            plan.append(("place", item, target, grasp))
        held_items = []
        last_target = target

    if not plan:
        return api.fallback()

    for operation in plan:
        if operation[0] == "drawer":
            api.drawer(operation[1], operation[2])
        else:
            api.place_with(operation[1], operation[2], operation[3])
