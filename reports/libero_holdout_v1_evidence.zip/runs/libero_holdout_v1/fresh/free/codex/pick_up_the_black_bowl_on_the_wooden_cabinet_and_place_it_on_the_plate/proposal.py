def run(api):
    import numpy as np

    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [
        n for n in names
        if n.rsplit("_", 1)[-1].isdigit()
        and "region" not in n
        and not n.endswith("_side")
    ]

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug", "cup"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug",
            "mug", "cup"
        ],
        "red coffee mug": ["red mug", "mug", "cup"],
        "black book": ["book"],
        "cream cheese": ["cream cheese box"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["stove"],
        "wooden cabinet": ["cabinet"],
        "white cabinet": ["cabinet"],
        "desk caddy": ["caddy"],
        "glazed rim porcelain ramekin": ["ramekin"],
    }

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        return [base] + synonyms.get(base, [])

    def score(name, phrase):
        padded = " " + phrase.strip(" ,.;") + " "
        return max(
            [len(a) for a in aliases(name) if " " + a + " " in padded]
            or [0]
        )

    def matches(phrase, pool=None):
        pool = bodies if pool is None else pool
        ranked = [(score(n, phrase), n) for n in pool]
        best = max([s for s, n in ranked] or [0])
        return [n for s, n in ranked if s == best and s > 0]

    def region(body, suffix):
        exact = body + "_" + suffix
        if exact in names:
            return exact
        return next(
            (n for n in names if n.startswith(body + "_") and n.endswith(suffix)),
            None
        )

    def nearest(marker, candidates):
        if len(candidates) == 1:
            return candidates[0]
        return api.nearest(marker, candidates)

    def resolve(phrase, pool=None):
        candidates = matches(phrase, pool)
        if not candidates:
            return None
        if len(candidates) == 1:
            return candidates[0]

        # Use the named support to distinguish otherwise identical objects.
        for connector in (" on top of ", " on ", " inside ", " in ", " near "):
            if connector in phrase:
                support_text = phrase.split(connector, 1)[1]
                supports = matches(
                    support_text, [b for b in bodies if b not in candidates]
                )
                if len(supports) == 1:
                    support = supports[0]
                    marker = (
                        region(support, "top_side")
                        or region(support, "contain_region")
                        or support
                    )
                    return nearest(marker, candidates)

        for direction in ("left", "right", "front", "back"):
            if direction not in phrase.split():
                continue
            bases = [a.replace(" ", "_") for a in aliases(candidates[0])]
            markers = [
                n for n in names
                if "region" in n and direction in n.split("_")
                and any(base in n for base in bases)
            ]
            if len(markers) == 1:
                return nearest(markers[0], candidates)
        return None

    def drawer_region(phrase):
        cabinets = matches(phrase, [n for n in bodies if "cabinet" in n])
        if not cabinets:
            cabinets = [n for n in bodies if "cabinet" in n]
        if len(cabinets) != 1:
            return None
        levels = [s for s in ("top", "middle", "bottom") if s in phrase.split()]
        if not levels:
            levels = [s for s in ("top", "middle", "bottom") if s in text.split()]
        if len(levels) != 1:
            return None
        return region(cabinets[0], levels[0] + "_region")

    def destination(phrase, relation):
        if "drawer" in phrase:
            return drawer_region(phrase)

        body = resolve(phrase)
        if body is None:
            return None

        direction = next(
            (s for s in ("left", "right", "front", "back")
             if s in phrase.split()), None
        )
        spatial = any(
            s in phrase for s in
            ("side", "compartment", "next to", "left of", "right of",
             "front of", "back of", "behind")
        )
        if direction and spatial:
            outside = any(
                s in phrase for s in
                ("next to", "left of", "right of", "front of", "back of")
            )
            return api.relative_target(
                body, direction,
                "outside" if outside or relation == "beside" else "inside"
            )

        if "cabinet" in body and relation == "on":
            return region(body, "top_side")
        if relation == "inside":
            return region(body, "contain_region") or body
        if "stove" in body:
            return region(body, "cook_region") or body
        return body

    # Parse a complete plan before executing physical actions.
    words = text.replace(",", " ").replace(".", " ").split()
    verbs = {"pick", "take", "put", "place", "move", "open", "close"}
    starts = [i for i, word in enumerate(words) if word in verbs]
    unsupported = (
        "turn on", "turn off", "switch", "push", "pull",
        "stack", "pour", "rotate"
    )
    if not starts or any(s in text for s in unsupported):
        return api.fallback()

    segments = [
        " ".join(words[start:(starts[j + 1] if j + 1 < len(starts) else len(words))])
        for j, start in enumerate(starts)
    ]
    pending = None
    previous_item = None
    plan = []

    connectors = [
        (" on top of ", "on"),
        (" into ", "inside"),
        (" inside ", "inside"),
        (" onto ", "on"),
        (" on ", "on"),
        (" in ", "inside"),
        (" beside ", "beside"),
        (" next to ", "beside"),
    ]

    for segment in segments:
        verb, _, phrase = segment.partition(" ")
        phrase = phrase.rstrip(" .;")
        while phrase.endswith((" and", " then")):
            phrase = phrase.rsplit(" ", 1)[0]

        if verb in ("pick", "take"):
            pending = phrase
            continue

        if verb in ("open", "close"):
            if "drawer" not in phrase:
                return api.fallback()
            target = drawer_region(phrase)
            if target is None:
                return api.fallback()
            plan.append(("drawer", target, verb))
            continue

        splits = []
        padded = " " + phrase
        for connector, relation in connectors:
            index = padded.rfind(connector)
            if index >= 0:
                splits.append((index, len(connector), connector, relation))
        if not splits:
            return api.fallback()

        index, _, connector, relation = max(splits, key=lambda x: (x[0], x[1]))
        item_text = padded[:index].strip()
        target_text = padded[index + len(connector):].strip()

        if item_text in ("it", "this", "that", "them", "the object"):
            item_text = pending or ""
            item = resolve(item_text) if item_text else previous_item
        else:
            item = resolve(item_text)

        # In "pick X on support and place X ..." retain its source qualifier.
        if pending:
            source_item = resolve(pending)
            if source_item and (
                item is None or source_item in matches(item_text)
            ):
                item = source_item

        target = destination(target_text, relation)
        if item is None or target is None or item == target:
            return api.fallback()

        plan.append(("place", item, target))
        previous_item = item
        pending = None

    if not plan or pending is not None:
        return api.fallback()

    for operation, first, second in plan:
        if operation == "drawer":
            api.drawer(first, second)
        else:
            grasp = (
                "rim" if "bowl" in first
                else "thin_edge" if "book" in first
                else "standard"
            )
            result = api.place_with(first, second, grasp)
            if result is False:
                return
