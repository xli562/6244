def run(api):
    import numpy as np

    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [
        n for n in names
        if n.rsplit("_", 1)[-1].isdigit()
        and "region" not in n and not n.endswith("_side")
    ]

    # The previous policy includes physical stove-switch operation.
    if any(s in text for s in (
        "turn on", "turn off", "switch on", "switch off",
        "push", "press", "rotate",
    )):
        return api.fallback()

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug", "cup"],
        "white yellow mug": [
            "white and yellow mug", "yellow and white mug", "yellow mug",
            "mug", "cup",
        ],
        "red coffee mug": ["red mug", "red coffee mug", "mug", "cup"],
        "cream cheese": ["cream cheese box", "cream cheese"],
        "black book": ["black book", "book"],
        "desk caddy": ["desk caddy", "caddy"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["stove"],
        "wooden cabinet": ["wooden cabinet", "cabinet"],
        "white cabinet": ["white cabinet", "cabinet"],
    }

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        result = [base] + synonyms.get(base, [])
        if base.split():
            result.append(base.split()[-1])
        return sorted(set(result), key=len, reverse=True)

    def mentions(fragment):
        padded = " " + fragment + " "
        hits = []
        for body in bodies:
            for alias in aliases(body):
                needle = " " + alias + " "
                start = padded.find(needle)
                while start >= 0:
                    hits.append((start, start + len(needle) - 2, body, alias))
                    start = padded.find(needle, start + 1)
        # Prefer specific names over generic names at the same location.
        hits.sort(key=lambda h: (-(h[1] - h[0]), h[0]))
        accepted = []
        for hit in hits:
            if not any(
                hit[0] < old[1] and old[0] < hit[1]
                for old in accepted
            ):
                accepted.append(hit)
        return sorted(accepted)

    def region(body, endings):
        for ending in endings:
            exact = body + "_" + ending
            if exact in names:
                return exact
        return None

    def resolve_body(hit, fragment):
        start, end, body, alias = hit
        candidates = [
            n for n in bodies if alias in aliases(n)
        ]
        if len(candidates) <= 1:
            return body
        prefix = fragment[max(0, start - 35):start]
        for direction in ("left", "right", "front", "back"):
            if direction not in prefix.split()[-5:]:
                continue
            markers = [
                n for n in names
                if "region" in n and direction in n.split("_")
                and any(word in n for word in alias.split())
            ]
            if len(markers) == 1:
                return api.nearest(markers[0], candidates)
        return None

    # Split at action verbs, retaining noun conjunctions within placements.
    words = text.replace(",", " ").replace(".", " ").split()
    verbs = {
        "put", "place", "move", "pick", "take", "open", "close",
        "stack", "insert",
    }
    starts = [i for i, word in enumerate(words) if word in verbs]
    if not starts:
        return api.fallback()
    clauses = [
        " ".join(words[start:starts[k + 1] if k + 1 < len(starts) else len(words)])
        for k, start in enumerate(starts)
    ]

    plan = []
    previous_items = []
    previous_target = None
    previous_drawer = None

    for clause in clauses:
        verb = clause.split()[0]
        if verb in ("pick", "take"):
            # A following placement clause supplies the destination.
            hits = mentions(clause)
            selected = [resolve_body(h, clause) for h in hits]
            if not selected or any(n is None for n in selected):
                return api.fallback()
            previous_items = list(dict.fromkeys(selected))
            continue

        if verb in ("open", "close"):
            cabinet_hits = [
                h for h in mentions(clause) if "cabinet" in h[2]
            ]
            cabinets = [n for n in bodies if "cabinet" in n]
            cabinet = (
                resolve_body(cabinet_hits[0], clause) if cabinet_hits
                else cabinets[0] if len(cabinets) == 1 else None
            )
            levels = [
                level for level in ("top", "middle", "bottom")
                if level in clause.split()
            ]
            drawer = None
            if cabinet and levels:
                drawer = region(cabinet, [levels[0] + "_region"])
            elif previous_drawer:
                drawer = previous_drawer
            else:
                candidates = [
                    n for n in names
                    if "drawer" in n and "region" in n
                ]
                if len(candidates) == 1:
                    drawer = candidates[0]
            if drawer is None:
                return api.fallback()
            plan.append(("drawer", drawer, verb))
            previous_drawer = drawer
            continue

        hits = mentions(clause)
        resolved = [(h, resolve_body(h, clause)) for h in hits]
        if any(body is None for _, body in resolved):
            return api.fallback()

        target = None
        target_body = None
        target_start = len(clause)
        if resolved:
            target_hit, target_body = resolved[-1]
            target_start = target_hit[0]

        if "drawer" in clause:
            cabinets = [n for n in bodies if "cabinet" in n]
            cabinet = (
                target_body if target_body and "cabinet" in target_body
                else cabinets[0] if len(cabinets) == 1 else None
            )
            level = next(
                (v for v in ("top", "middle", "bottom")
                 if v in clause.split()), None
            )
            target = (
                region(cabinet, [level + "_region"])
                if cabinet and level else previous_drawer
            )
            target_body = cabinet
            previous_drawer = target
        elif target_body and (
            len(resolved) >= 2 or previous_items
        ):
            target_phrase = clause[max(0, target_start - 65):]
            direction = next(
                (d for d in ("left", "right", "front", "back")
                 if d in target_phrase.split()), None
            )
            fixture = any(
                k in target_body for k in ("caddy", "cabinet", "rack")
            )
            outside = any(s in target_phrase for s in (
                "next to", "to the left of", "to the right of",
                "in front of", "behind", "at the back of",
            ))
            if fixture and (direction or "behind" in target_phrase):
                direction = direction or "back"
                target = api.relative_target(
                    target_body, direction,
                    "outside" if outside else "inside",
                )
            elif "cabinet" in target_body:
                target = region(target_body, ["top_side"])
            elif "stove" in target_body:
                target = region(target_body, ["cook_region"]) or target_body
            elif any(w in clause.split() for w in ("in", "into", "inside")):
                target = region(target_body, ["contain_region"]) or target_body
            else:
                target = target_body
        elif any(s in clause for s in ("on it", "in it", "into it", "there")):
            target = previous_target

        if target is None:
            return api.fallback()

        items = list(dict.fromkeys(
            body for _, body in resolved if body != target_body
        ))
        if not items:
            items = previous_items
        if not items or target in items:
            return api.fallback()

        for item in items:
            style = (
                "rim" if "bowl" in item
                else "thin_edge" if "book" in item
                else "standard"
            )
            plan.append(("place", item, target, style))
        previous_items = items
        previous_target = target

    if not plan:
        return api.fallback()

    for action in plan:
        if action[0] == "drawer":
            result = api.drawer(action[1], action[2])
        else:
            result = api.place_with(action[1], action[2], action[3])
        if result is False:
            return
