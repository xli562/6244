import numpy as np


def run(api):
    def clean(text):
        return " ".join(
            str(text).lower().replace("_", " ").replace("-", " ")
            .replace(",", " ").replace(".", " ").split()
        )

    text = clean(api.instruction)
    names = list(api.names())
    bodies = [
        n for n in names
        if n.rsplit("_", 1)[-1].isdigit()
        and "region" not in n and not n.endswith("_side")
    ]

    mappings = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug", "cup"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug",
            "mug", "cup"
        ],
        "red coffee mug": ["red mug", "coffee mug", "mug", "cup"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["stove"],
        "black book": ["book"],
        "desk caddy": ["caddy"],
        "wooden cabinet": ["cabinet"],
        "white cabinet": ["cabinet"],
        "glazed rim porcelain ramekin": ["porcelain ramekin", "ramekin"],
        "cream cheese": ["cream cheese box"],
        "moka pot": ["moka"],
    }

    def aliases(name):
        base = clean(name.rsplit("_", 1)[0])
        result = [base] + mappings.get(base, [])
        if base.endswith("basket"):
            result.append("basket")
        return result

    def contains(phrase, fragment):
        return " " + fragment + " " in " " + phrase + " "

    def matches(phrase, pool):
        scored = []
        for name in pool:
            score = max(
                (len(a) for a in aliases(name) if contains(phrase, a)),
                default=0,
            )
            if score:
                scored.append((name, score))
        if not scored:
            return []
        best = max(score for _, score in scored)
        return [name for name, score in scored if score == best]

    def region(owner, fragments):
        for fragment in fragments:
            exact = owner + "_" + fragment
            if exact in names:
                return exact
        return None

    def level_of(phrase):
        for level in ("top", "middle", "bottom"):
            if contains(phrase, level):
                return level
        if contains(phrase, "upper"):
            return "top"
        if contains(phrase, "lower"):
            return "bottom"
        return None

    def direction_of(phrase):
        for direction in ("left", "right", "front", "back"):
            if contains(phrase, direction):
                return direction
        return None

    def source_region(phrase, candidates):
        fixtures = [
            n for n in bodies
            if n not in candidates
            and any(k in n for k in ("cabinet", "caddy", "basket"))
        ]
        owners = matches(phrase, fixtures)
        if owners:
            owner = owners[0]
            level = level_of(phrase)
            if level:
                return region(owner, [level + "_region"])
            direction = direction_of(phrase)
            if direction:
                return api.relative_target(owner, direction, "inside")
            return region(owner, ["contain_region"])

        direction = direction_of(phrase)
        if direction:
            bases = set(n.rsplit("_", 1)[0] for n in candidates)
            markers = [
                n for n in names
                if "region" in n and direction in n
                and any(base in n for base in bases)
            ]
            if len(markers) == 1:
                return markers[0]
        return None

    def choose(phrase, pool):
        candidates = matches(phrase, pool)
        if len(candidates) == 1:
            return candidates[0]
        if not candidates:
            return None
        marker = source_region(phrase, candidates)
        if marker:
            return api.nearest(marker, candidates)
        return None

    def drawer_region(phrase):
        cabinets = [n for n in bodies if "cabinet" in n]
        owners = matches(phrase, cabinets)
        if not owners and len(cabinets) == 1:
            owners = cabinets
        level = level_of(phrase)
        if len(owners) == 1 and level:
            return region(owners[0], [level + "_region"])
        return None

    def destination(phrase, items):
        if "drawer" in phrase:
            return drawer_region(phrase)

        pool = [n for n in bodies if n not in items]
        target = choose(phrase, pool)
        if target is None:
            # Some destinations are table regions without a numbered body.
            scored = []
            for name in names:
                if "region" not in name and "table_center" not in name:
                    continue
                label = clean(name)
                for prefix in ("main table ", "living room table ", "study table "):
                    if label.startswith(prefix):
                        label = label[len(prefix):]
                label = label.replace(" region", "")
                if label and contains(phrase, label):
                    scored.append((len(label), name))
            if scored:
                return max(scored)[1]
            return None

        direction = direction_of(phrase)
        outside = any(
            s in phrase for s in (
                "next to", "beside", "to the left of", "to the right of",
                "in front of", "behind", "at the back of"
            )
        )
        if "behind" in phrase:
            direction = "back"
        if direction and (outside or "caddy" in target or "cabinet" in target):
            return api.relative_target(
                target, direction, "outside" if outside else "inside"
            )

        if "cabinet" in target:
            if "on top" in phrase or "top of" in phrase:
                return region(target, ["top_side"])
            level = level_of(phrase)
            if level:
                return region(target, [level + "_region"])
            if contains(phrase, "on"):
                return region(target, ["top_side"])

        if "stove" in target:
            return region(target, ["cook_region"]) or target

        if any(contains(phrase, word) for word in ("in", "into", "inside")):
            return region(target, ["contain_region"]) or target
        return target

    # Plan before moving so an unsupported instruction can use the old policy.
    words = text.split()
    verbs = {"pick", "take", "put", "place", "move", "open", "close"}
    if any(
        contains(text, phrase)
        for phrase in ("turn on", "turn off", "push", "pull", "stack", "pour")
    ):
        return api.fallback()

    starts = [i for i, word in enumerate(words) if word in verbs]
    if not starts:
        return api.fallback()

    plan = []
    pending = []
    last_drawer = None

    for index, start in enumerate(starts):
        end = starts[index + 1] if index + 1 < len(starts) else len(words)
        verb = words[start]
        clause = " ".join(words[start + 1:end]).strip()

        if verb in ("open", "close"):
            target = drawer_region(clause)
            if target is None and any(
                contains(clause, p) for p in ("it", "drawer")
            ):
                target = last_drawer
            if target is None:
                return api.fallback()
            last_drawer = target
            plan.append(("drawer", target, verb))
            continue

        if verb in ("pick", "take"):
            # Acquisition is performed by the placement skill once its target
            # is known. The source description disambiguates identical objects.
            item = choose(clause, bodies)
            if item is None:
                return api.fallback()
            pending = [item]
            continue

        # Prefer the final destination preposition over source qualifiers.
        tokens = clause.split()
        separators = [
            i for i, token in enumerate(tokens)
            if token in ("on", "onto", "in", "into", "inside", "to")
        ]
        splits = []
        for split in reversed(separators):
            # Keep compound spatial phrases intact.
            begin = split
            if tokens[split] == "to" and split and tokens[split - 1] == "next":
                begin = split - 1
            splits.append((
                " ".join(tokens[:begin]),
                " ".join(tokens[begin:])
            ))

        resolved = None
        for source, target_phrase in splits:
            item = choose(source, bodies)
            items = [item] if item else list(pending)
            if not items:
                continue

            # Explicitly named distinct objects may share one destination.
            if " and " in source:
                groups = source.split(" and ")
                multiple = [choose(group, bodies) for group in groups]
                if all(multiple):
                    items = list(dict.fromkeys(multiple))

            target = destination(target_phrase, items)
            if target is None and (
                contains(target_phrase, "it")
                or contains(target_phrase, "drawer")
            ):
                target = last_drawer
            if target:
                resolved = (items, target)
                break

        if resolved is None:
            return api.fallback()
        items, target = resolved
        for item in items:
            grasp = (
                "rim" if "bowl" in item
                else "thin_edge" if "book" in item
                else "standard"
            )
            plan.append(("place", item, target, grasp))
        pending = []

    if pending or not plan:
        return api.fallback()

    for operation in plan:
        if operation[0] == "drawer":
            api.drawer(operation[1], operation[2])
        else:
            api.place_with(operation[1], operation[2], operation[3])
