def run(api):
    import numpy as np

    text = " ".join(
        api.instruction.lower().replace("-", " ").split()
    )
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n
        and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    mapping = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug", "mug"
        ],
        "red coffee mug": ["red coffee mug", "red mug", "mug"],
        "cream cheese": ["cream cheese box"],
        "black book": ["book"],
        "desk caddy": ["caddy"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["stove"],
        "white cabinet": ["cabinet"],
        "wooden cabinet": ["cabinet"],
    }

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        result = [base] + mapping.get(base, [])
        for noun in ("bowl", "plate", "basket", "book", "cabinet"):
            if noun in base.split():
                result.append(noun)
        return list(set(result))

    def mentions(phrase, pool=None):
        pool = bodies if pool is None else pool
        padded = " " + phrase + " "
        hits = []
        for name in pool:
            for alias in aliases(name):
                needle = " " + alias + " "
                start = 0
                while True:
                    index = padded.find(needle, start)
                    if index < 0:
                        break
                    hits.append((index, index + len(needle) - 1, name))
                    start = index + 1

        # Specific names suppress generic matches at the same location.
        hits = [
            h for h in hits
            if not any(
                other[0] <= h[0] and other[1] >= h[1]
                and other[1] - other[0] > h[1] - h[0]
                for other in hits
            )
        ]
        return sorted(set(hits))

    def resolve(phrase, last=False):
        hits = mentions(phrase)
        if not hits:
            return None
        index = hits[-1][0] if last else hits[0][0]
        candidates = list(dict.fromkeys(
            h[2] for h in hits if h[0] == index
        ))
        if len(candidates) == 1:
            return candidates[0]

        for direction in ("left", "right", "front", "back"):
            if direction in phrase.split():
                markers = [
                    n for n in names
                    if direction in n.split("_")
                    and ("region" in n or n.endswith("_side"))
                    and any(
                        c.rsplit("_", 1)[0] in n for c in candidates
                    )
                ]
                if markers:
                    return api.nearest(markers[0], candidates)
        return None

    def region(body, suffixes):
        for suffix in suffixes:
            candidate = body + "_" + suffix
            if candidate in names:
                return candidate
        return None

    def drawer_region(phrase, previous=None):
        level = next(
            (s for s in ("top", "middle", "bottom")
             if s in phrase.split()), None
        )
        cabinet = resolve(
            phrase, last=True
        )
        if cabinet is not None and "cabinet" not in cabinet:
            cabinet = None
        choices = [
            n for n in names
            if "region" in n
            and any(s in n.split("_") for s in ("top", "middle", "bottom"))
            and ("cabinet" in n or "drawer" in n)
            and (level is None or level in n.split("_"))
            and (cabinet is None or n.startswith(cabinet + "_"))
        ]
        if len(choices) == 1:
            return choices[0]
        if previous in choices:
            return previous
        return None

    def destination(phrase, previous_drawer=None, previous_target=None):
        if "drawer" in phrase:
            return drawer_region(phrase, previous_drawer)

        body = resolve(phrase, last=True)
        if body is None:
            if any(w in phrase.split() for w in ("it", "there", "them")):
                return previous_drawer or previous_target
            return None

        words = phrase.split()
        direction = next(
            (d for d in ("left", "right", "front", "back") if d in words),
            None
        )
        fixture = any(k in body for k in ("caddy", "cabinet", "rack", "shelf"))
        if direction and fixture:
            outside = any(
                p in phrase for p in (
                    "next to", "beside", "to the left of", "to the right of",
                    "in front of", "behind", "at the left of", "at the right of"
                )
            )
            relation = "outside" if outside else "inside"
            return api.relative_target(body, direction, relation)

        if "cabinet" in body and any(
            p in phrase for p in ("on ", "on top", "top of")
        ):
            return region(body, ["top_side", "top_region"])

        if "stove" in body:
            return region(body, ["cook_region"]) or body

        if any(w in words for w in ("in", "into", "inside")):
            return region(body, ["contain_region", "inside_region"]) or body
        return body

    # Parse the requested order before performing physical actions.
    normalized = text
    for punctuation in (",", ".", ";", ":"):
        normalized = normalized.replace(punctuation, " ")
    tokens = normalized.split()
    verbs = {
        "pick", "take", "grab", "put", "place", "move",
        "stack", "open", "close", "shut"
    }
    if any(w in tokens for w in ("turn", "push", "pull", "press", "pour")):
        return api.fallback()

    starts = [i for i, word in enumerate(tokens) if word in verbs]
    if not starts:
        return api.fallback()

    selected = []
    operations = []
    last_drawer = None
    last_target = None

    for number, start in enumerate(starts):
        end = starts[number + 1] if number + 1 < len(starts) else len(tokens)
        verb = tokens[start]
        clause_tokens = tokens[start + 1:end]
        clause = " ".join(clause_tokens)

        if verb in ("open", "close", "shut"):
            target = drawer_region(clause, last_drawer)
            if target is None:
                return api.fallback()
            operations.append(("drawer", target, "open" if verb == "open" else "close"))
            last_drawer = target
            continue

        if verb in ("pick", "take", "grab"):
            hits = mentions(clause)
            selected = list(dict.fromkeys(h[2] for h in hits))
            # A source location is not another item to pick up.
            if any(w in clause_tokens for w in ("from", "on", "in")):
                item = resolve(clause)
                selected = [item] if item else []
            continue

        separators = [
            i for i, w in enumerate(clause_tokens)
            if w in ("in", "into", "inside", "on", "onto", "to")
        ]
        if not separators:
            return api.fallback()
        split = separators[0]
        source = " ".join(clause_tokens[:split])
        target_phrase = " ".join(clause_tokens[split:])
        target = destination(target_phrase, last_drawer, last_target)
        if target is None:
            return api.fallback()

        hits = mentions(source)
        items = list(dict.fromkeys(h[2] for h in hits)) if hits else selected
        if len(items) > 1 and not any(
            w in source.split() for w in ("and", "both", "all")
        ):
            item = resolve(source)
            items = [item] if item else []
        if not items:
            return api.fallback()

        for item in items:
            if item == target:
                return api.fallback()
            grasp = (
                "rim" if "bowl" in item else
                "thin_edge" if "book" in item else
                "standard"
            )
            operations.append(("place", item, target, grasp))
        selected = items
        last_target = target

    if not operations:
        return api.fallback()

    for operation in operations:
        if operation[0] == "drawer":
            api.drawer(operation[1], operation[2])
        else:
            api.place_with(operation[1], operation[2], operation[3])
