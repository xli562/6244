def run(api):
    import numpy as np

    text = " ".join(
        api.instruction.lower().replace("-", " ").replace(",", " , ").split()
    )
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug", "mug"
        ],
        "red coffee mug": ["red coffee mug", "red mug", "mug"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "cream cheese": ["cream cheese box", "cream cheese"],
        "black book": ["black book", "book"],
        "desk caddy": ["desk caddy", "caddy"],
        "flat stove": ["flat stove", "stove"],
        "white cabinet": ["white cabinet", "cabinet"],
        "wooden cabinet": ["wooden cabinet", "cabinet"],
        "wooden basket": ["wooden basket", "basket"],
    }

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        result = [base] + synonyms.get(base, [])
        for noun in ("basket", "bowl", "plate", "book", "cabinet", "caddy"):
            if noun in base.split():
                result.append(noun)
        return set(result)

    def mentions(sentence, pool=None):
        padded = " " + sentence + " "
        hits = []
        for name in bodies if pool is None else pool:
            for alias in aliases(name):
                needle = " " + alias + " "
                start = padded.find(needle)
                while start >= 0:
                    hits.append((start, start + len(needle) - 2, name, len(alias)))
                    start = padded.find(needle, start + 1)
        # A specific name takes precedence over generic names at the same location.
        hits = [
            h for h in hits
            if not any(
                q[0] <= h[0] and q[1] >= h[1] and q[3] > h[3]
                for q in hits
            )
        ]
        return sorted(set(hits))

    def unique_mentions(sentence):
        result = []
        for _, _, name, _ in mentions(sentence):
            if name not in result:
                result.append(name)
        return result

    def region(body, suffix):
        exact = body + "_" + suffix
        if exact in names:
            return exact
        return next(
            (n for n in names if n.startswith(body + "_") and n.endswith(suffix)),
            None,
        )

    def drawer_region(sentence, previous=None):
        cabinets = [n for n in bodies if "cabinet" in n]
        explicit = unique_mentions(sentence)
        cabinet = next((n for n in explicit if n in cabinets), None)
        if cabinet is None and len(cabinets) == 1:
            cabinet = cabinets[0]
        level = next(
            (w for w in ("top", "middle", "bottom") if w in sentence.split()),
            None,
        )
        if level is None and previous is not None:
            return previous
        candidates = [
            n for n in names
            if "region" in n
            and (cabinet is None or n.startswith(cabinet + "_"))
            and (level is None or "_" + level + "_" in n)
            and any("_" + w + "_" in n for w in ("top", "middle", "bottom"))
        ]
        return candidates[0] if len(candidates) == 1 else None

    def resolve_target(sentence, previous=None):
        if "drawer" in sentence:
            return drawer_region(sentence, previous)
        hits = mentions(sentence)
        if not hits:
            return previous if any(w in sentence.split() for w in ("it", "there")) else None

        last_start = max(h[0] for h in hits)
        choices = list(dict.fromkeys(h[2] for h in hits if h[0] == last_start))
        direction = next(
            (w for w in ("left", "right", "front", "back") if w in sentence.split()),
            None,
        )
        if len(choices) > 1:
            markers = [
                n for n in names
                if "region" in n and direction
                and direction in n.split("_")
                and any(
                    c.rsplit("_", 1)[0] in n for c in choices
                )
            ]
            if len(markers) != 1:
                return None
            body = api.nearest(markers[0], choices)
        else:
            body = choices[0]

        outside = any(
            phrase in sentence for phrase in
            ("next to", "to the left of", "to the right of", "in front of", "behind")
        )
        if "behind" in sentence:
            direction = "back"
        if direction and outside:
            return api.relative_target(body, direction, "outside")
        if direction and (
            "caddy" in body or "compartment" in sentence
            or "inside" in sentence or " in " in " " + sentence + " "
        ):
            return api.relative_target(body, direction, "inside")
        if "cabinet" in body and (
            "on top" in sentence or "on the top" in sentence
        ):
            return region(body, "top_side")
        if "basket" in body or "caddy" in body:
            return region(body, "contain_region") or body
        if "stove" in body:
            return region(body, "cook_region") or body
        if any(w in sentence.split() for w in ("in", "into", "inside")):
            return region(body, "contain_region") or body
        return body

    # Parse the whole request before taking action so unsupported requests can
    # be delegated without repeating an already completed operation.
    words = text.split()
    action_words = {"open", "close", "shut", "put", "place", "move", "insert"}
    if any(w in words for w in ("turn", "switch", "push", "pull", "stack")):
        return api.fallback()

    starts = [i for i, word in enumerate(words) if word in action_words]
    if not starts:
        return api.fallback()

    plan = []
    previous_items = []
    previous_target = None
    previous_drawer = None
    prefix = " ".join(words[:starts[0]])
    previous_items = unique_mentions(prefix)

    for index, start in enumerate(starts):
        end = starts[index + 1] if index + 1 < len(starts) else len(words)
        clause = " ".join(words[start:end])
        verb = words[start]

        if verb in ("open", "close", "shut"):
            if "drawer" not in clause and previous_drawer is None:
                return api.fallback()
            target = drawer_region(clause, previous_drawer)
            if target is None:
                return api.fallback()
            plan.append(("drawer", target, "open" if verb == "open" else "close"))
            previous_drawer = target
            previous_target = target
            continue

        target = resolve_target(clause, previous_drawer if "drawer" in clause else previous_target)
        if target is None:
            return api.fallback()

        target_body = next(
            (b for b in sorted(bodies, key=len, reverse=True)
             if target == b or target.startswith(b + "_")),
            None,
        )
        items = [n for n in unique_mentions(clause) if n != target_body]

        # "Pick the orange juice and place it in the basket."
        if not items:
            items = [n for n in previous_items if n != target_body]
        if not items:
            return api.fallback()

        for item in items:
            if "cabinet" in item or "stove" in item or "caddy" in item:
                return api.fallback()
            grasp = (
                "rim" if "bowl" in item
                else "thin_edge" if "book" in item
                else "standard"
            )
            plan.append(("place", item, target, grasp))
        previous_items = items
        previous_target = target
        if "drawer" in clause:
            previous_drawer = target

    for job in plan:
        if job[0] == "drawer":
            api.drawer(job[1], job[2])
        else:
            result = api.place_with(job[1], job[2], job[3])
            if result is False:
                return
