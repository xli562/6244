def run(api):
    import numpy as np

    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())

    # Retain the existing multi-task policy for non-pushing tasks.
    if "push" not in text or "plate" not in text:
        return api.fallback()

    bodies = [
        n for n in names
        if "region" not in n
        and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        result = [base]
        for word in ("stove", "cabinet", "caddy", "plate", "basket"):
            if word in base:
                result.append(word)
        return result

    def mentioned(name, phrase):
        return max(
            (len(a) for a in aliases(name) if a in phrase),
            default=0,
        )

    plates = [n for n in bodies if "plate" in n]
    direction = next(
        (d for d in ("front", "back", "left", "right")
         if "the " + d + " of" in text or d + " of" in text),
        None,
    )
    if not plates or direction is None:
        return api.fallback()

    reference_text = text.split(direction + " of", 1)[-1]
    references = [
        n for n in bodies if n not in plates and mentioned(n, reference_text)
    ]
    if not references:
        return api.fallback()

    reference = max(references, key=lambda n: mentioned(n, reference_text))
    target = api.relative_target(reference, direction, "outside")
    if target is None:
        return api.fallback()

    item = max(plates, key=lambda n: mentioned(n, text))
    if len(plates) > 1:
        source_text = text.split("push", 1)[-1].split(" to ", 1)[0]
        markers = [
            n for n in names
            if "region" in n and "plate" in n
            and any(d in source_text and d in n
                    for d in ("left", "right", "front", "back"))
        ]
        if len(markers) == 1:
            item = api.nearest(markers[0], plates)

    def position(name):
        return np.asarray(api.pos(name), dtype=float).copy()

    def move(point, steps):
        return api.move(np.asarray(point, dtype=float), steps=steps)

    # Push from behind the plate, measuring its actual displacement after
    # each stroke. Never grasp or lift the plate.
    api.grip(True)
    stalled = 0
    for attempt in range(9):
        start = position(item)
        destination = position(target)
        delta = destination[:2] - start[:2]
        distance = float(np.linalg.norm(delta))
        if distance < 0.025:
            break

        heading = np.array([delta[0] / distance, delta[1] / distance, 0.0])
        contact_z = start[2] + (0.004 if stalled == 0 else 0.0)
        approach = start - 0.115 * heading
        approach[2] = contact_z

        hand = np.asarray(api.eef(), dtype=float)
        clearance = max(hand[2], start[2] + 0.12)
        move([hand[0], hand[1], clearance], 5)
        above = approach.copy()
        above[2] = clearance
        move(above, 8)
        move(approach, 7)

        stroke = min(distance, 0.075)
        contact_offset = 0.045 if stalled == 0 else 0.025
        endpoint = start + (stroke - contact_offset) * heading
        endpoint[2] = contact_z
        move(endpoint, 14)

        after = position(item)
        progress = float(np.dot(after - start, heading))
        stalled = stalled + 1 if progress < 0.005 else 0

        # Withdraw horizontally before lifting away from the rim.
        hand = np.asarray(api.eef(), dtype=float)
        move(hand - 0.035 * heading, 4)
        hand = np.asarray(api.eef(), dtype=float)
        move(hand + np.array([0.0, 0.0, 0.10]), 5)

        if stalled >= 3:
            break

    api.grip(False)
