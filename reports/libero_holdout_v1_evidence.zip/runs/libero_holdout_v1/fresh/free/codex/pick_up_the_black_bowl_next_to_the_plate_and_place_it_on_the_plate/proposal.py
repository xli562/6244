def run(api):
    import numpy as np

    def norm(s):
        return " ".join(s.lower().replace("_", " ").replace("-", " ").split())

    text = norm(api.instruction).replace(".", " ").replace(",", " ")
    names = list(api.names())
    bodies = [
        n for n in names
        if n.rsplit("_", 1)[-1].isdigit()
        and "region" not in n
    ]

    mappings = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug", "cup"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug", "mug"
        ],
        "red coffee mug": ["red mug", "coffee mug", "mug"],
        "black book": ["book"],
        "cream cheese": ["cream cheese box"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["stove"],
        "desk caddy": ["caddy"],
        "wooden cabinet": ["cabinet"],
        "white cabinet": ["cabinet"],
        "glazed rim porcelain ramekin": ["ramekin"],
    }

    groups = {}
    for n in bodies:
        base = norm(n.rsplit("_", 1)[0])
        groups.setdefault(base, []).append(n)

    def mentions(s):
        hits = []
        padded = " " + s + " "
        for base, candidates in groups.items():
            aliases = [base] + mappings.get(base, [])
            for alias in aliases:
                needle = " " + alias + " "
                start = 0
                while True:
                    i = padded.find(needle, start)
                    if i < 0:
                        break
                    hits.append((i, i + len(alias), base, candidates))
                    start = i + 1
        # Prefer full object descriptions over their generic noun aliases.
        chosen = []
        for h in sorted(hits, key=lambda h: (-(h[1] - h[0]), h[0])):
            if not any(h[0] < q[1] and q[0] < h[1] for q in chosen):
                chosen.append(h)
        return sorted(chosen, key=lambda h: h[0])

    def nearest(region, candidates):
        if len(candidates) == 1:
            return candidates[0]
        return api.nearest(region, list(candidates))

    def marker(phrase):
        phrase = norm(phrase)
        matches = [
            n for n in names
            if n not in bodies and phrase in norm(n)
        ]
        return min(matches, key=len) if matches else None

    def resolve(hit, context):
        candidates = hit[3]
        if len(candidates) == 1:
            return candidates[0]

        # Source descriptions such as "the bowl next to the plate".
        for relation, key in (
            ("next to", "next to"),
            ("beside", "next to"),
            ("between", "between"),
            ("in front of", "front"),
            ("behind", "back"),
        ):
            at = context.find(relation)
            if at < 0:
                continue
            tail = context[at + len(relation):]
            refs = mentions(tail)
            if refs:
                noun = refs[0][2].split()[-1]
                region = marker(key + " " + noun)
                if relation == "between" and len(refs) > 1:
                    region = marker(
                        "between " + noun + " " + refs[1][2].split()[-1]
                    ) or region
                if region:
                    return nearest(region, candidates)
                if relation in ("next to", "beside"):
                    reference = refs[0][3][0]
                    return nearest(reference, candidates)

        for direction in ("left", "right", "front", "back"):
            noun = hit[2].split()[-1]
            if direction + " " + noun in context:
                region = marker(noun + " " + direction)
                if region:
                    return nearest(region, candidates)
        return candidates[0]

    def fixture_region(body, description, drawer=False):
        owned = [n for n in names if n.startswith(body + "_")]
        if drawer:
            level = next(
                (x for x in ("top", "middle", "bottom")
                 if x in description.split()), "bottom"
            )
            return next(
                (n for n in owned if n.endswith("_" + level + "_region")),
                None,
            )

        for direction in ("left", "right", "front", "back"):
            if direction in description.split():
                outside = any(
                    p in description
                    for p in ("next to", "beside", "outside", "of the")
                )
                relation = "outside" if outside else "inside"
                return api.relative_target(body, direction, relation)

        if "cabinet" in body and any(
            p in description for p in ("on", "top", "above")
        ):
            return next((n for n in owned if n.endswith("_top_side")), body)
        if "stove" in body:
            return next((n for n in owned if n.endswith("_cook_region")), body)
        if any(p in description.split() for p in ("in", "into", "inside")):
            return next(
                (n for n in owned if n.endswith("_contain_region")), body
            )
        return body

    def place(item, target):
        grasp = (
            "rim" if "bowl" in item
            else "thin_edge" if "book" in item
            else "standard"
        )
        api.place_with(item, target, grasp)

    # Unsupported manipulation is delegated before executing any partial plan.
    if any(
        phrase in text
        for phrase in (
            "turn on", "turn off", "switch on", "switch off",
            "push", "pull", "rotate", "pour",
        )
    ):
        return api.fallback()

    # Segment by action verbs, retaining noun conjunctions within each action.
    words = text.split()
    verbs = {"pick", "take", "grab", "put", "place", "move", "stack",
             "open", "close", "shut"}
    starts = [i for i, word in enumerate(words) if word in verbs]
    if not starts:
        return api.fallback()
    clauses = [
        " ".join(words[start:(starts[k + 1] if k + 1 < len(starts)
                              else len(words))])
        for k, start in enumerate(starts)
    ]

    pending = []
    last_target = None
    last_drawer = None
    plan = []

    for clause in clauses:
        verb = clause.split()[0]
        hits = mentions(clause)

        if verb in ("open", "close", "shut"):
            cabinets = [
                h for h in hits if "cabinet" in h[2]
            ]
            cabinet = (
                resolve(cabinets[-1], clause) if cabinets
                else next((n for n in bodies if "cabinet" in n), None)
            )
            if "drawer" not in clause and not (
                last_drawer and any(w in clause.split() for w in ("it", "them"))
            ):
                return api.fallback()
            explicit_level = any(
                x in clause.split() for x in ("top", "middle", "bottom")
            )
            region = (
                fixture_region(cabinet, clause, drawer=True)
                if cabinet and (explicit_level or last_drawer is None)
                else last_drawer
            )
            if region is None:
                return api.fallback()
            plan.append(("drawer", region,
                         "open" if verb == "open" else "close"))
            last_drawer = region
            continue

        if verb in ("pick", "take", "grab"):
            if not hits:
                return api.fallback()
            # Objects after a spatial preposition describe the source location.
            cutoff = len(clause)
            for phrase in (" next to ", " beside ", " from ", " between ",
                           " on ", " in ", " behind ", " near "):
                at = clause.find(phrase)
                if at >= 0:
                    cutoff = min(cutoff, at)
            source_hits = [h for h in hits if h[0] < cutoff]
            pending = []
            for h in source_hits:
                item = resolve(h, clause)
                if item not in pending:
                    pending.append(item)
            continue

        # The final placement preposition separates sources from destination.
        separators = (
            " on top of ", " onto ", " into ", " inside ", " on ",
            " in ", " to ", " beside ", " next to ",
        )
        boundaries = [
            (clause.rfind(p), p) for p in separators if p in clause
        ]
        if not boundaries:
            return api.fallback()
        boundary, prep = max(boundaries, key=lambda p: p[0])
        source_text = clause[:boundary]
        destination = clause[boundary:]
        source_hits = mentions(source_text)
        items = []
        for h in source_hits:
            item = resolve(h, source_text)
            if item not in items:
                items.append(item)
        if not items:
            items = list(pending)

        target_hits = mentions(destination)
        target = None
        if "drawer" in destination:
            cabinets = [h for h in target_hits if "cabinet" in h[2]]
            cabinet = (
                resolve(cabinets[-1], destination) if cabinets
                else next((n for n in bodies if "cabinet" in n), None)
            )
            if cabinet:
                explicit_level = any(
                    x in destination.split() for x in ("top", "middle", "bottom")
                )
                target = (
                    fixture_region(cabinet, destination, drawer=True)
                    if explicit_level or last_drawer is None else last_drawer
                )
                last_drawer = target
        elif target_hits:
            body = resolve(target_hits[-1], destination)
            target = fixture_region(body, destination)
        elif "it" in destination.split() or "there" in destination.split():
            target = last_drawer or last_target
        else:
            for phrase in ("table center", "table front"):
                if phrase in destination:
                    target = marker(phrase)

        if not items or target is None:
            return api.fallback()
        for item in items:
            if item != target:
                plan.append(("place", item, target))
        pending = items
        last_target = target

    if not plan:
        return api.fallback()

    for action, first, second in plan:
        if action == "drawer":
            api.drawer(first, second)
        else:
            place(first, second)
