def run(api):
    import numpy as np

    def clean(s):
        for c in "_-.,;:":
            s = s.replace(c, " ")
        return " ".join(s.lower().split())

    text = clean(api.instruction)
    names = list(api.names())
    bodies = [
        n for n in names
        if n.rsplit("_", 1)[-1].isdigit()
        and "region" not in n
    ]
    regions = [n for n in names if n not in bodies]

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "glazed rim porcelain ramekin": ["ramekin"],
        "porcelain mug": ["white mug", "mug"],
        "white yellow mug": [
            "white and yellow mug", "yellow and white mug", "yellow mug", "mug"
        ],
        "red coffee mug": ["red mug", "coffee mug", "mug"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "cream cheese": ["cream cheese box"],
        "black book": ["book"],
        "desk caddy": ["caddy"],
        "flat stove": ["stove"],
        "wooden cabinet": ["cabinet"],
        "white cabinet": ["cabinet"],
    }

    def aliases(n):
        base = clean(n.rsplit("_", 1)[0])
        return [base] + synonyms.get(base, [])

    def mentions(s, pool=None):
        """Keep specific noun matches; preserve instruction order."""
        padded = " " + s + " "
        hits = []
        for n in bodies if pool is None else pool:
            for a in aliases(n):
                needle = " " + a + " "
                start = padded.find(needle)
                while start >= 0:
                    hits.append((start, start + len(needle), n, len(a)))
                    start = padded.find(needle, start + 1)
        hits = [
            h for h in hits
            if not any(
                q[0] <= h[0] and q[1] >= h[1] and q[3] > h[3]
                for q in hits
            )
        ]
        hits.sort(key=lambda h: (h[0], -h[3]))
        groups = []
        for start, end, n, length in hits:
            if groups and groups[-1][0] == start:
                if n not in groups[-1][2]:
                    groups[-1][2].append(n)
            else:
                groups.append([start, end, [n]])
        return groups

    def position(n):
        return np.asarray(api.pos(n), dtype=float)

    def location(s):
        """Find a perceived source landmark, including between-regions."""
        words = set(clean(s).split())
        best, score = None, 0
        for n in regions:
            label = clean(n)
            tokens = label.split()
            if "between" in words and "between" not in tokens:
                continue
            if "between" in tokens:
                required = [
                    w for w in tokens[tokens.index("between") + 1:]
                    if w not in ("region", "and") and not w.isdigit()
                ]
                if "between" in words and all(w in words for w in required):
                    value = 100 + len(required)
                else:
                    continue
            else:
                useful = [
                    w for w in tokens
                    if w not in ("main", "table", "region", "contain", "side")
                    and not w.isdigit()
                ]
                if not useful or not all(w in words for w in useful):
                    continue
                value = len(useful)
                if any(w in useful for w in ("left", "right", "front", "back")):
                    value += 4
                if "next" in useful:
                    value += 4
            if value > score:
                best, score = n, value
        return best

    def choose(candidates, description):
        if len(candidates) == 1:
            return candidates[0]
        marker = location(description)
        if marker:
            return api.nearest(marker, candidates)

        # Geometric fallback when no named between-region exists.
        if "between" in description:
            refs = mentions(description.split("between", 1)[1])
            if len(refs) >= 2:
                a, b = refs[0][2][0], refs[1][2][0]
                midpoint = (position(a) + position(b)) / 2
                return min(
                    candidates,
                    key=lambda n: np.linalg.norm(position(n) - midpoint),
                )
        return candidates[0]

    def objects(s):
        # Nouns after spatial qualifiers describe the source, not extra cargo.
        cutoff = len(s)
        for phrase in (
            " between ", " next to ", " to the left of ",
            " to the right of ", " in front of ", " behind ",
            " on top of ", " on the ", " in the ",
        ):
            index = s.find(phrase)
            if index >= 0:
                cutoff = min(cutoff, index)
        return [
            choose(group[2], s)
            for group in mentions(s[:cutoff])
        ]

    def drawer_region(s):
        level = next(
            (w for w in ("bottom", "middle", "top") if w in s.split()),
            None,
        )
        candidates = [
            n for n in regions
            if ("cabinet" in n or "drawer" in n)
            and n.endswith("_region")
            and any("_" + w + "_" in n for w in ("bottom", "middle", "top"))
            and (level is None or "_" + level + "_" in n)
        ]
        if not candidates:
            return None
        if level is None and len(candidates) > 1:
            return None
        return candidates[0]

    def target(s):
        if "drawer" in s:
            return drawer_region(s)

        groups = mentions(s)
        if not groups:
            return location(s)
        reference = choose(groups[-1][2], s)

        direction = next(
            (w for w in ("left", "right", "front", "back") if w in s.split()),
            None,
        )
        if direction and ("caddy" in reference or "cabinet" in reference):
            outside = any(
                p in s for p in (
                    "next to", "to the left of", "to the right of",
                    "in front of", "behind", "outside",
                )
            )
            relation = "outside" if outside else "inside"
            return api.relative_target(reference, direction, relation)

        if "cabinet" in reference and (
            "on" in s.split() or "top" in s.split()
        ):
            return next(
                (n for n in regions if n == reference + "_top_side"), None
            )

        if any(w in s.split() for w in ("in", "into", "inside")):
            contain = reference + "_contain_region"
            if contain in names:
                return contain
        if "stove" in reference:
            cook = reference + "_cook_region"
            if cook in names:
                return cook
        if any(p in s for p in ("next to", "between", "behind", "in front of")):
            marker = location(s)
            if marker:
                return marker
        return reference

    # Parse the complete plan before executing, so unsupported instructions
    # can be delegated without duplicating partially completed actions.
    words = text.split()
    verbs = {"pick", "take", "grab", "put", "place", "open", "close"}
    if any(w in words for w in ("turn", "push", "pull", "stack", "pour")):
        return api.fallback()

    starts = [i for i, w in enumerate(words) if w in verbs]
    if not starts:
        return api.fallback()
    starts.append(len(words))
    plan = []
    held = []
    last_drawer = None

    for left, right in zip(starts[:-1], starts[1:]):
        verb = words[left]
        clause = " ".join(words[left + 1:right]).strip()
        while clause.endswith(" and") or clause.endswith(" then"):
            clause = clause.rsplit(" ", 1)[0]

        if verb in ("open", "close"):
            region = drawer_region(clause)
            if region is None and ("it" in clause.split() or not clause):
                region = last_drawer
            if region is None:
                return api.fallback()
            plan.append(("drawer", region, verb))
            last_drawer = region
            continue

        if verb in ("pick", "take", "grab"):
            held = objects(clause)
            if not held:
                return api.fallback()
            continue

        tokens = clause.split()
        splits = []
        for i, w in enumerate(tokens):
            if w in ("on", "onto", "in", "into", "inside"):
                if w == "in" and tokens[i:i + 3] == ["in", "front", "of"]:
                    continue
                splits.append(i)
            elif tokens[i:i + 2] == ["next", "to"]:
                splits.append(i)
        if not splits:
            return api.fallback()

        # The final placement preposition separates source qualifiers from
        # the destination, e.g. "bowl between ... and ... on the plate".
        split = splits[-1]
        source = " ".join(tokens[:split])
        destination = " ".join(tokens[split:])
        items = objects(source)
        if not items and any(w in source.split() for w in ("it", "them")):
            items = held[:]
        dest = target(destination)
        if dest is None and "drawer" in destination:
            dest = last_drawer
        if not items or dest is None:
            return api.fallback()
        for item in items:
            if item != dest:
                plan.append(("place", item, dest))
        held = items
        if "drawer" in destination:
            last_drawer = dest

    if not plan:
        return api.fallback()

    for kind, a, b in plan:
        if kind == "drawer":
            api.drawer(a, b)
        else:
            grasp = (
                "rim" if "bowl" in a
                else "thin_edge" if "book" in a
                else "standard"
            )
            api.place_with(a, b, grasp)
