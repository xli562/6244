import numpy as np
import math


def run(api):
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [
        n for n in names
        if n.rsplit("_", 1)[-1].isdigit()
        and "region" not in n and not n.endswith("_side")
    ]

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug", "mug"
        ],
        "red coffee mug": ["red mug", "coffee mug", "mug"],
        "cream cheese": ["cream cheese box"],
        "black book": ["book"],
        "desk caddy": ["caddy"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["stove"],
        "wooden cabinet": ["cabinet"],
        "white cabinet": ["cabinet"],
    }

    def words(s):
        return " ".join(s.replace("_", " ").split())

    def contains(s, phrase):
        return " " + phrase + " " in " " + s + " "

    def aliases(n):
        base = words(n.rsplit("_", 1)[0])
        return [base] + synonyms.get(base, [])

    def matches(s, pool):
        hits = []
        for n in pool:
            for a in aliases(n):
                start = 0
                while True:
                    i = s.find(a, start)
                    if i < 0:
                        break
                    j = i + len(a)
                    if (i == 0 or not s[i - 1].isalnum()) and (
                        j == len(s) or not s[j].isalnum()
                    ):
                        hits.append((i, j, n))
                    start = i + 1
        # A generic alias must not also match a more specific object phrase.
        return [
            h for h in hits
            if not any(
                k[0] <= h[0] and k[1] >= h[1]
                and k[1] - k[0] > h[1] - h[0]
                for k in hits
            )
        ]

    def region_hint(s):
        best, score = None, 0
        for n in names:
            if n in bodies:
                continue
            phrase = words(n)
            for prefix in ("main table ", "living room table ", "study table "):
                if phrase.startswith(prefix):
                    phrase = phrase[len(prefix):]
            phrase = phrase.replace(" region", "")
            variants = [phrase]
            if phrase in ("table center", "table front"):
                variants.append(phrase.replace("table ", ""))
            if phrase.startswith("plate "):
                variants.append(phrase[6:] + " plate")
            for v in variants:
                if contains(s, v) and len(v) > score:
                    best, score = n, len(v)
        return best

    def choose(candidates, context):
        candidates = list(dict.fromkeys(candidates))
        if not candidates:
            return None
        if len(candidates) == 1:
            return candidates[0]
        region = region_hint(context)
        if region:
            return api.nearest(region, candidates)
        return None

    def objects(s, context):
        hits = matches(s, bodies)
        groups = {}
        for start, end, n in hits:
            groups.setdefault((start, end), []).append(n)
        result = []
        for span in sorted(groups):
            candidates = groups[span]
            if contains(s, "both") or contains(s, "all"):
                selected = list(dict.fromkeys(candidates))
            else:
                item = choose(candidates, context)
                if item is None:
                    return None
                selected = [item]
            for item in selected:
                if item not in result:
                    result.append(item)
        return result

    def drawer_region(s):
        level = next(
            (v for v in ("bottom", "middle", "top") if contains(s, v)),
            None,
        )
        candidates = [
            n for n in names
            if ("cabinet" in n or "drawer" in n)
            and n.endswith("_region")
            and any("_" + v + "_" in n for v in ("bottom", "middle", "top"))
            and (level is None or "_" + level + "_" in n)
        ]
        return candidates[0] if len(candidates) == 1 else None

    def target_for(s):
        if "drawer" in s:
            return drawer_region(s)

        hits = matches(s, bodies)
        if not hits:
            return region_hint(s)

        last = max(h[0] for h in hits)
        candidates = [h[2] for h in hits if h[0] == last]
        body = choose(candidates, s)
        if body is None:
            return None

        direction = next(
            (d for d in ("left", "right", "front", "back") if contains(s, d)),
            None,
        )
        outside = any(
            phrase in s
            for phrase in ("next to", "beside", "outside", "to the left of",
                           "to the right of", "in front of", "behind")
        )
        if "behind" in s:
            direction = "back"
        inside = any(contains(s, p) for p in ("in", "into", "inside"))
        if direction and (outside or (
            inside and ("caddy" in body or "cabinet" in body)
        )):
            return api.relative_target(
                body, direction, "outside" if outside else "inside"
            )

        if ("cabinet" in body or "drawer" in body) and (
            "on" in s or "top" in s
        ):
            candidate = body + "_top_side"
            return candidate if candidate in names else None

        suffixes = (
            ["_contain_region", "_cook_region"]
            if inside else ["_cook_region"]
        )
        for suffix in suffixes:
            if body + suffix in names:
                return body + suffix
        return body

    # Compile the complete sequence before performing any physical action.
    tokens = text.replace(",", " , ").replace(".", " ").replace(";", " ; ").split()
    verbs = {"pick", "take", "put", "place", "move", "open", "close",
             "turn", "push", "pull", "stack"}
    starts = [
        i for i, token in enumerate(tokens)
        if token in verbs and not (
            token == "pick" and i + 1 < len(tokens) and tokens[i + 1] == "and"
        )
    ]
    if not starts:
        return api.fallback()

    plan = []
    source_context = ""
    previous_items = None
    previous_drawer = None

    for index, start in enumerate(starts):
        end = starts[index + 1] if index + 1 < len(starts) else len(tokens)
        verb = tokens[start]
        clause = " ".join(tokens[start + 1:end]).strip(" ,;")
        while clause.endswith(" and") or clause.endswith(" then"):
            clause = clause.rsplit(" ", 1)[0]

        if verb in ("pick", "take"):
            source_context = clause
            previous_items = objects(clause.split(" from ")[0], clause)
            if not previous_items:
                return api.fallback()
            continue

        if verb in ("open", "close"):
            region = drawer_region(clause)
            if region is None and any(
                contains(clause, p) for p in ("it", "drawer")
            ):
                region = previous_drawer
            if region is None:
                return api.fallback()
            previous_drawer = region
            plan.append(("drawer", region, verb))
            continue

        if verb not in ("put", "place", "move", "stack"):
            return api.fallback()

        padded = " " + clause + " "
        separators = [" onto ", " into ", " inside ", " on ", " in ", " to "]
        splits = [
            (padded.find(separator), separator)
            for separator in separators if separator in padded
        ]
        if not splits:
            return api.fallback()
        split, separator = min(splits, key=lambda pair: pair[0])
        item_text = padded[:split].strip()
        target_text = padded[split:].strip()

        context = source_context + " " + item_text
        items = objects(item_text.split(" from ")[0], context)
        if not items and any(
            contains(item_text, p) for p in ("it", "them", "these")
        ):
            items = previous_items
        target = target_for(target_text)
        if not items or target is None:
            return api.fallback()
        items = [item for item in items if item != target]
        if not items:
            return api.fallback()
        for item in items:
            grasp = (
                "rim" if "bowl" in item
                else "thin_edge" if "book" in item
                else "standard"
            )
            plan.append(("place", item, target, grasp))
        previous_items = items
        source_context = ""

    if not plan:
        return api.fallback()

    for operation in plan:
        if operation[0] == "drawer":
            api.drawer(operation[1], operation[2])
        else:
            api.place_with(operation[1], operation[2], operation[3])
