def run(api):
    import numpy as np

    text = " ".join(
        api.instruction.lower().replace("-", " ").replace(",", " ").split()
    )
    names = list(api.names())
    bodies = [
        n for n in names
        if n.rsplit("_", 1)[-1].isdigit()
        and "region" not in n
        and not n.endswith("_side")
    ]

    def words(s):
        return " ".join(s.replace("_", " ").split())

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "glazed rim porcelain ramekin": ["porcelain ramekin", "ramekin"],
        "porcelain mug": ["white mug", "mug", "cup"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug",
            "mug", "cup"
        ],
        "red coffee mug": ["red mug", "coffee mug", "mug", "cup"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["stove"],
        "wooden cabinet": ["cabinet"],
        "white cabinet": ["cabinet"],
        "desk caddy": ["caddy"],
        "black book": ["book"],
        "cream cheese": ["cream cheese box"],
        "wine bottle": ["bottle"],
    }

    aliases = {}
    for body in bodies:
        base = words(body.rsplit("_", 1)[0])
        options = [base] + synonyms.get(base, [])
        for generic in ("bowl", "plate", "basket", "book", "ramekin"):
            if generic in base.split():
                options.append(generic)
        aliases[body] = set(options)

    def mentions(s):
        padded = " " + s + " "
        hits = {}
        for body, options in aliases.items():
            for alias in options:
                needle = " " + alias + " "
                start = 0
                while True:
                    i = padded.find(needle, start)
                    if i < 0:
                        break
                    span = (i, i + len(alias))
                    hits.setdefault(span, set()).add(body)
                    start = i + 1
        spans = [
            span for span in hits
            if not any(
                other != span and other[0] <= span[0]
                and span[1] <= other[1]
                for other in hits
            )
        ]
        return [(a, b, sorted(hits[(a, b)])) for a, b in sorted(spans)]

    def nearest(region, candidates):
        if len(candidates) == 1:
            return candidates[0]
        return api.nearest(region, candidates)

    def named_region(fragment):
        candidates = [n for n in names if fragment in n]
        return min(candidates, key=len) if candidates else None

    def resolve(group, context):
        candidates = group[2]
        if len(candidates) == 1:
            return candidates[0]

        tail = context[group[1]:]
        refs = mentions(tail)
        # Resolve descriptions such as "bowl next to the ramekin".
        if refs and any(
            phrase in tail for phrase in
            ("next to", "near", "beside", "on the", "in the")
        ):
            reference = refs[0][2][0]
            base = reference.rsplit("_", 1)[0]
            short = base.split("_")[-1]
            marker = None
            for fragment in (
                "next_to_" + base + "_region",
                "next_to_" + short + "_region",
            ):
                marker = named_region(fragment)
                if marker:
                    break
            return nearest(marker or reference, candidates)

        for direction in ("left", "right", "front", "back"):
            if direction in context.split():
                for candidate in candidates:
                    base = candidate.rsplit("_", 1)[0]
                    marker = named_region(base + "_" + direction + "_region")
                    if marker:
                        return nearest(marker, candidates)

        # An unspecified duplicate has no reliable symbolic resolution.
        return None

    def drawer_region(s):
        level = next(
            (x for x in ("bottom", "middle", "top") if x in s.split()),
            None,
        )
        candidates = [
            n for n in names
            if "cabinet" in n and n.endswith("_region")
            and any("_" + x + "_region" in n
                    for x in ("bottom", "middle", "top"))
        ]
        if level:
            candidates = [
                n for n in candidates if "_" + level + "_region" in n
            ]
        return candidates[0] if len(candidates) == 1 else None

    def target_for(s, previous_target):
        if "drawer" in s:
            return drawer_region(s) or (
                previous_target if previous_target
                and previous_target.endswith("_region") else None
            )

        found = mentions(s)
        if not found:
            if any(w in s.split() for w in ("it", "there", "inside")):
                return previous_target
            return None

        reference = resolve(found[-1], s)
        if reference is None:
            return None

        direction = next(
            (d for d in ("left", "right", "front", "back")
             if d in s.split()),
            None,
        )
        if direction and ("caddy" in reference or "cabinet" in reference):
            outside = any(
                p in s for p in ("next to", "beside", "outside", "side of")
            )
            relation = "outside" if outside else "inside"
            return api.relative_target(reference, direction, relation)

        if "cabinet" in reference and (
            "on" in s.split() or "top" in s.split()
        ):
            return named_region(reference + "_top_side")

        if "stove" in reference:
            return named_region(reference + "_cook_region") or reference

        if any(w in s.split() for w in ("in", "into", "inside")):
            return named_region(reference + "_contain_region") or reference
        return reference

    # Split only at action verbs; keep spatial descriptions with their object.
    tokens = text.split()
    verbs = {"pick", "put", "place", "move", "transfer", "open", "close"}
    if any(w in tokens for w in ("turn", "push", "pull", "rotate", "stack")):
        return api.fallback()

    starts = [i for i, token in enumerate(tokens) if token in verbs]
    if not starts:
        return api.fallback()

    clauses = []
    for index, start in enumerate(starts):
        end = starts[index + 1] if index + 1 < len(starts) else len(tokens)
        clause = tokens[start:end]
        while clause and clause[-1] in ("and", "then"):
            clause.pop()
        clauses.append(" ".join(clause))

    pending = []
    previous_target = None
    previous_drawer = None
    plan = []

    for clause in clauses:
        verb = clause.split()[0]
        if verb in ("open", "close"):
            region = drawer_region(clause)
            if region is None and (
                "drawer" in clause or "it" in clause.split()
            ):
                region = previous_drawer
            if region is None:
                return api.fallback()
            plan.append(("drawer", region, verb))
            previous_drawer = region
            previous_target = region
            continue

        if verb == "pick":
            found = mentions(clause)
            if not found:
                return api.fallback()
            item = resolve(found[0], clause)
            if item is None:
                return api.fallback()
            pending = [item]
            continue

        # Use the final placement preposition, leaving source descriptions
        # such as "next to the ramekin" in the source phrase.
        separators = []
        for phrase in (" onto ", " into ", " inside ", " on ", " in ", " to "):
            start = 0
            while True:
                index = clause.find(phrase, start)
                if index < 0:
                    break
                separators.append((index, phrase))
                start = index + len(phrase)

        if not separators:
            return api.fallback()
        split, separator = max(separators, key=lambda p: p[0])
        source = clause[:split]
        destination = clause[split:]
        found = mentions(source)

        items = []
        if found:
            # Objects following a spatial qualifier describe the source's
            # location; they are not additional objects to pick up.
            cutoff = len(source)
            for phrase in (" next to ", " near ", " beside ", " from "):
                index = source.find(phrase)
                if index >= 0:
                    cutoff = min(cutoff, index)
            for group in found:
                if group[0] >= cutoff:
                    continue
                item = resolve(group, source)
                if item is None:
                    return api.fallback()
                if item not in items:
                    items.append(item)
        else:
            items = list(pending)

        target = target_for(destination, previous_target)
        if not items or target is None:
            return api.fallback()
        for item in items:
            if item == target:
                return api.fallback()
            plan.append(("place", item, target))
        pending = items
        previous_target = target

    if not plan:
        return api.fallback()

    for operation, first, second in plan:
        if operation == "drawer":
            api.drawer(first, second)
        else:
            grasp = (
                "rim" if "bowl" in first
                else "thin_edge" if "book" in first
                else "standard"
            )
            result = api.place_with(first, second, grasp)
            if result is False:
                return
