def run(api):
    import numpy as np

    def normalize(text):
        return " ".join(
            text.lower().replace("_", " ").replace("-", " ")
            .replace(",", " and ").replace(".", " ").split()
        )

    instruction = normalize(api.instruction)
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug", "cup"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug",
            "mug", "cup"
        ],
        "red coffee mug": ["red mug", "coffee mug", "mug", "cup"],
        "cream cheese": ["cream cheese box"],
        "black book": ["book"],
        "desk caddy": ["caddy"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["stove"],
        "white cabinet": ["cabinet"],
        "wooden cabinet": ["cabinet"],
        "wooden basket": ["basket"],
    }

    def aliases(name):
        base = normalize(name.rsplit("_", 1)[0])
        result = [base] + synonyms.get(base, [])
        for noun in ("bowl", "plate", "basket", "cabinet", "book", "mug"):
            if noun in base.split():
                result.append(noun)
        return list(set(result))

    def mentions(text, pool=None):
        padded = " " + text + " "
        hits = []
        for name in bodies if pool is None else pool:
            for alias in aliases(name):
                needle = " " + alias + " "
                start = padded.find(needle)
                while start >= 0:
                    hits.append((start, start + len(needle) - 1, name))
                    start = padded.find(needle, start + 1)
        # Generic aliases must not introduce other objects at a specific mention.
        hits = [
            h for h in hits
            if not any(
                k[0] <= h[0] and k[1] >= h[1]
                and k[1] - k[0] > h[1] - h[0]
                for k in hits
            )
        ]
        hits.sort(key=lambda h: h[0])
        result = []
        for _, _, name in hits:
            if name not in result:
                result.append(name)
        return result

    def region(body, fragments):
        for fragment in fragments:
            exact = body + "_" + fragment
            if exact in names:
                return exact
        return None

    def direction(text):
        return next(
            (word for word in ("left", "right", "front", "back")
             if word in text.split()), None
        )

    def choose(candidates, text):
        if len(candidates) == 1:
            return candidates[0]
        if not candidates:
            return None
        side = direction(text)
        if side:
            markers = [
                n for n in names
                if "region" in n and side in normalize(n).split()
                and any(
                    a in normalize(n)
                    for c in candidates for a in aliases(c)
                )
            ]
            if len(markers) == 1:
                return api.nearest(markers[0], candidates)
        return None

    def drawer_target(text, previous=None):
        fixtures = [
            n for n in mentions(text)
            if "cabinet" in n or "drawer" in n
        ]
        fixture = choose(fixtures, text)
        if fixture is None:
            all_fixtures = [n for n in bodies if "cabinet" in n]
            fixture = choose(all_fixtures, text)
        levels = [x for x in ("top", "middle", "bottom")
                  if x in text.split()]
        if not levels and previous is not None:
            return previous
        if fixture is None:
            return None
        if levels:
            return region(fixture, [levels[0] + "_region"])
        possible = [
            region(fixture, [level + "_region"])
            for level in ("top", "middle", "bottom")
        ]
        possible = [n for n in possible if n]
        return possible[0] if len(possible) == 1 else None

    def placement_target(text, previous=None):
        if "drawer" in text:
            return drawer_target(text, previous)

        candidates = mentions(text)
        if not candidates and previous and (
            "it" in text.split() or "there" in text.split()
        ):
            return previous
        body = choose(candidates, text)
        if body is None:
            # Allow an explicitly named perceived region.
            matches = [n for n in names if normalize(n) in text]
            return max(matches, key=len) if matches else None

        side = direction(text)
        if side:
            outside = any(
                phrase in text for phrase in
                ("next to", "beside", "to the left", "to the right",
                 "in front of", "behind")
            )
            if outside:
                return api.relative_target(body, side, "outside")
            inside = any(
                word in text.split()
                for word in ("in", "inside", "into", "compartment", "section")
            )
            if inside and ("caddy" in body or "cabinet" in body):
                return api.relative_target(body, side, "inside")

        if "cabinet" in body and (
            "on" in text.split() or "top" in text.split()
        ):
            return region(body, ["top_side"]) or body
        if "stove" in body:
            return region(body, ["cook_region"]) or body
        if any(w in text.split() for w in ("in", "into", "inside")):
            return region(body, ["contain_region"]) or body
        return body

    # Parse the complete action sequence before moving anything.
    words = instruction.split()
    verbs = {"pick", "take", "put", "place", "move", "open", "close",
             "shut", "turn", "switch", "push", "pull", "stack"}
    starts = [i for i, word in enumerate(words) if word in verbs]
    if not starts:
        return api.fallback()
    clauses = [
        " ".join(words[start:(starts[i + 1] if i + 1 < len(starts)
                              else len(words))])
        for i, start in enumerate(starts)
    ]

    plan = []
    held_references = []
    last_target = None
    last_drawer = None
    unsupported = False

    for clause in clauses:
        verb = clause.split()[0]
        if verb in ("pick", "take"):
            held_references = mentions(clause)
            continue

        if verb in ("open", "close", "shut"):
            target = drawer_target(clause, last_drawer)
            if target is None:
                unsupported = True
                break
            plan.append(("drawer", target,
                         "open" if verb == "open" else "close"))
            last_drawer = target
            last_target = target
            continue

        if verb not in ("put", "place", "move"):
            unsupported = True
            break

        separators = (
            " on top of ", " into ", " inside ", " onto ", " in ",
            " on ", " to ", " next to ", " beside ", " behind "
        )
        padded = " " + clause + " "
        splits = [
            (padded.find(sep), -len(sep), sep)
            for sep in separators if padded.find(sep) >= 0
        ]
        if not splits:
            if "there" in clause.split() and last_target:
                subject = clause
                target = last_target
            else:
                unsupported = True
                break
        else:
            index, _, separator = min(splits)
            subject = padded[:index].strip()
            target_text = padded[index:].strip()
            target = placement_target(target_text, last_target)

        items = mentions(subject)
        if not items and any(
            p in subject.split() for p in ("it", "them", "object")
        ):
            items = held_references[:]
        if target is None or not items:
            unsupported = True
            break

        # An unresolved generic reference is unsafe to interpret as "all".
        if len(items) > 1 and not any(
            w in subject.split() for w in ("and", "both", "all", "them")
        ):
            item = choose(items, subject)
            if item is None:
                unsupported = True
                break
            items = [item]

        for item in items:
            if item != target:
                plan.append(("place", item, target))
        held_references = items
        last_target = target
        if "drawer" in clause:
            last_drawer = target

    if unsupported or not plan:
        return api.fallback()

    for action, item, target in plan:
        if action == "drawer":
            api.drawer(item, target)
        else:
            grasp = (
                "rim" if "bowl" in item
                else "thin_edge" if "book" in item
                else "standard"
            )
            api.place_with(item, target, grasp)
