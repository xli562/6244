def run(api):
    import numpy as np

    text = " ".join(
        api.instruction.lower().replace("-", " ").replace(",", " ").split()
    )
    names = list(api.names())
    bodies = [
        n for n in names
        if n.rsplit("_", 1)[-1].isdigit()
        and "region" not in n and not n.endswith("_side")
    ]

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug", "cup"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug",
            "mug", "cup"
        ],
        "red coffee mug": ["red mug", "mug", "cup"],
        "black book": ["book"],
        "cream cheese": ["cream cheese box"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "desk caddy": ["caddy"],
        "flat stove": ["stove"],
        "wooden cabinet": ["cabinet", "drawer"],
        "white cabinet": ["cabinet", "drawer"],
    }

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        return [base] + synonyms.get(base, [])

    def mentions(s, pool=None):
        pool = bodies if pool is None else pool
        padded = " " + s + " "
        hits = []
        for name in pool:
            for alias in aliases(name):
                needle = " " + alias + " "
                start = 0
                while True:
                    at = padded.find(needle, start)
                    if at < 0:
                        break
                    hits.append((at, at + len(needle), name))
                    start = at + 1
        # Specific names take precedence over generic overlapping aliases.
        hits = [
            h for h in hits
            if not any(
                q[0] <= h[0] and q[1] >= h[1]
                and q[1] - q[0] > h[1] - h[0]
                for q in hits
            )
        ]
        result = []
        for _, _, name in sorted(hits):
            if name not in result:
                result.append(name)
        return result

    def resolve(s, pool=None):
        candidates = mentions(s, pool)
        if len(candidates) == 1:
            return candidates[0]
        if not candidates:
            return None
        for direction in ("left", "right", "front", "back"):
            if direction not in s.split():
                continue
            bases = [
                n.rsplit("_", 1)[0] for n in candidates
            ]
            markers = [
                n for n in names
                if "region" in n and direction in n.split("_")
                and any(base in n for base in bases)
            ]
            if len(markers) == 1:
                return api.nearest(markers[0], candidates)
        return None

    def region(body, suffixes):
        for suffix in suffixes:
            name = body + "_" + suffix
            if name in names:
                return name
        return None

    cabinets = [n for n in bodies if "cabinet" in n]
    last_drawer = None

    def drawer_region(s):
        nonlocal last_drawer
        cabinet = resolve(s, cabinets)
        if cabinet is None:
            if len(cabinets) != 1:
                return None
            cabinet = cabinets[0]
        level = next(
            (v for v in ("top", "middle", "bottom") if v in s.split()),
            None,
        )
        if level is None:
            return last_drawer
        result = region(cabinet, [level + "_region"])
        if result:
            last_drawer = result
        return result

    # Split only at action verbs, keeping coordinated object names together.
    verbs = {"open", "close", "shut", "put", "place", "move", "pick",
             "turn", "switch", "push", "pull", "stack"}
    words = text.split()
    starts = [i for i, w in enumerate(words) if w in verbs]
    if not starts:
        return api.fallback()
    clauses = []
    for j, start in enumerate(starts):
        end = starts[j + 1] if j + 1 < len(starts) else len(words)
        part = words[start:end]
        while part and part[-1] in ("and", "then"):
            part.pop()
        clauses.append(" ".join(part))

    plan = []
    held_items = []
    last_target = None

    for clause in clauses:
        verb = clause.split()[0]

        if verb in ("open", "close", "shut"):
            target = drawer_region(clause)
            if target is None:
                return api.fallback()
            plan.append(("drawer", target, "open" if verb == "open" else "close"))
            last_target = target
            continue

        if verb == "pick":
            held_items = mentions(clause)
            if not held_items:
                return api.fallback()
            continue

        if verb not in ("put", "place", "move", "stack"):
            return api.fallback()

        content = clause[len(verb):].strip()
        separators = [
            " on top of ", " to the left of ", " to the right of ",
            " in front of ", " at the back of ", " next to ",
            " into ", " inside ", " onto ", " on ", " in ", " to ",
        ]
        matches = [
            (content.find(sep), -len(sep), sep)
            for sep in separators if sep in content
        ]
        if matches:
            index, _, sep = min(matches)
            source = content[:index]
            destination = content[index + len(sep):]
            spatial = sep.strip() + " " + destination
        else:
            source = content
            destination = ""
            spatial = content

        items = mentions(source)
        if not items and any(w in source.split() for w in ("it", "them")):
            items = held_items
        if not items:
            return api.fallback()

        target = None
        if "drawer" in destination or "layer" in destination:
            target = drawer_region(destination)
        elif (
            not destination and ("inside" in content.split()
                                 or " in" == content[-3:])
        ):
            target = last_drawer
        elif destination.strip() in ("it", "there", "them"):
            target = last_target
        else:
            body = resolve(destination)
            if body:
                direction = next(
                    (d for d in ("left", "right", "front", "back")
                     if d in spatial.split()), None
                )
                inside = (
                    spatial.startswith("in ")
                    or spatial.startswith("inside ")
                    or spatial.startswith("into ")
                )
                if direction:
                    target = ("relative", body, direction,
                              "inside" if inside else "outside")
                elif inside:
                    target = region(body, ["contain_region"])
                    if target is None and body in cabinets:
                        target = drawer_region(destination)
                    if target is None:
                        target = body
                elif "top" in spatial.split():
                    target = region(body, ["top_side", "top_region"]) or body
                elif "stove" in body:
                    target = region(body, ["cook_region"]) or body
                else:
                    target = body

        if target is None:
            return api.fallback()
        for item in items:
            if item == target:
                return api.fallback()
            grasp = (
                "rim" if "bowl" in item else
                "thin_edge" if "book" in item else
                "standard"
            )
            plan.append(("place", item, target, grasp))
        held_items = items
        last_target = target

    if not plan:
        return api.fallback()

    # Resolve spatial regions when executing, after preceding fixture operations.
    for job in plan:
        if job[0] == "drawer":
            api.drawer(job[1], job[2])
        else:
            _, item, target, grasp = job
            if isinstance(target, tuple):
                _, reference, direction, relation = target
                target = api.relative_target(reference, direction, relation)
                if target is None:
                    return
            result = api.place_with(item, target, grasp)
            if result is False:
                return
