def run(api):
    import numpy as np

    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        result = [base]
        mappings = {
            "akita black bowl": ["black bowl", "bowl"],
            "porcelain mug": ["white mug", "mug"],
            "white yellow mug": [
                "white and yellow mug", "yellow and white mug", "yellow mug"
            ],
            "red coffee mug": ["red mug", "coffee mug"],
            "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
            "cream cheese": ["cream cheese box"],
            "flat stove": ["stove"],
            "desk caddy": ["caddy"],
            "black book": ["book"],
        }
        result.extend(mappings.get(base, []))
        for word in ("cabinet", "basket", "bowl", "plate", "book"):
            if word in base:
                result.append(word)
        if "cabinet" in base:
            result.append("drawer")
        return sorted(set(result), key=len, reverse=True)

    def mentions(phrase, pool=None):
        pool = bodies if pool is None else pool
        hits = []
        padded = " " + phrase + " "
        for name in pool:
            for alias in aliases(name):
                needle = " " + alias + " "
                start = padded.find(needle)
                if start >= 0:
                    hits.append((start, start + len(needle), name, len(alias)))
        # Prefer specific object names over generic aliases at the same location.
        hits.sort(key=lambda h: (-h[3], h[0]))
        chosen = []
        for hit in hits:
            if any(hit[0] < h[1] and h[0] < hit[1] for h in chosen):
                continue
            chosen.append(hit)
        chosen.sort()
        return list(dict.fromkeys(h[2] for h in chosen))

    def region(body, suffixes):
        for suffix in suffixes:
            candidate = body + "_" + suffix
            if candidate in names:
                return candidate
        return None

    def direction(phrase):
        words = phrase.split()
        return next((w for w in words if w in
                     ("left", "right", "front", "back")), None)

    def drawer_region(phrase):
        cabinets = [b for b in bodies if "cabinet" in b]
        explicit = mentions(phrase, cabinets)
        if not explicit and len(cabinets) != 1:
            return None
        cabinet = explicit[0] if explicit else cabinets[0]
        level = next(
            (w for w in phrase.split() if w in ("top", "middle", "bottom")),
            None,
        )
        if level is None:
            return None
        return region(cabinet, [level + "_region"])

    def resolve_target(phrase, previous_target):
        if phrase.strip(" .,") in ("it", "there", "them"):
            return previous_target

        found = mentions(phrase)
        if not found:
            return None
        body = found[-1]
        side = direction(phrase)

        # A cabinet's upper exterior is distinct from its top drawer.
        surface = any(s in phrase for s in (
            "on top of", "on the top of", "onto the top of",
            "on the cabinet", "on the drawer", "on top",
        ))
        if "cabinet" in body:
            if surface:
                return region(body, ["top_side"])
            if "drawer" in phrase or any(
                w in phrase.split() for w in ("bottom", "middle", "top")
            ):
                return drawer_region(phrase)

        outside = any(s in phrase for s in (
            "next to", "beside", "to the left of", "to the right of",
            "in front of", "behind",
        ))
        if "behind" in phrase:
            side = "back"
        if side and ("caddy" in body or outside):
            return api.relative_target(
                body, side, "outside" if outside else "inside"
            )

        if side and "plate" in body:
            plates = [b for b in bodies if "plate" in b]
            markers = [
                n for n in names if "plate" in n and side in n
                and "region" in n
            ]
            if markers:
                return api.nearest(markers[0], plates)

        if "stove" in body:
            return region(body, ["cook_region"]) or body
        if "basket" in body or "caddy" in body:
            return region(body, ["contain_region"]) or body
        if "wine_rack" in body and "top" in phrase:
            return region(body, ["top_region"]) or body
        if any(s in phrase for s in (" in ", "into", "inside")):
            return region(body, ["contain_region"]) or body
        return body

    # Split at action verbs, preserving their order and spatial wording.
    verbs = {
        "put", "place", "move", "stack", "open", "close", "shut",
        "turn", "pick", "take",
    }
    words = text.replace(",", " , ").replace(";", " ; ").split()
    starts = [i for i, word in enumerate(words) if word in verbs]
    if not starts:
        return api.fallback()
    clauses = [
        " ".join(words[start:starts[k + 1] if k + 1 < len(starts) else len(words)])
        for k, start in enumerate(starts)
    ]

    plan = []
    last_items = []
    last_target = None
    last_drawer = None

    for clause in clauses:
        verb = clause.split()[0]
        if verb in ("open", "close", "shut"):
            target = drawer_region(clause)
            if target is None and ("it" in clause.split() or "drawer" in clause):
                target = last_drawer
            if target is None:
                return api.fallback()
            plan.append(("drawer", target, "open" if verb == "open" else "close"))
            last_drawer = target
            continue

        if verb not in ("put", "place", "move", "stack"):
            return api.fallback()

        separators = (
            " onto ", " into ", " inside ", " on ", " in ",
            " next to ", " beside ", " to the ", " behind ",
        )
        matches = [(clause.find(s), s) for s in separators if s in clause]
        if not matches:
            return api.fallback()
        split, separator = min(matches, key=lambda pair: pair[0])
        source = clause[:split]
        destination = clause[split:]
        items = mentions(source)
        if not items and any(w in source.split() for w in ("it", "them")):
            items = last_items
        target = resolve_target(destination, last_target)
        if not items or target is None:
            return api.fallback()
        for item in items:
            if item != target:
                grasp = (
                    "rim" if "bowl" in item else
                    "thin_edge" if "book" in item else
                    "standard"
                )
                plan.append(("place", item, target, grasp))
        last_items = items
        last_target = target
        if "cabinet" in target and target.endswith("_region"):
            last_drawer = target

    # Resolve the entire plan before physically executing any part of it.
    for action in plan:
        if action[0] == "drawer":
            api.drawer(action[1], action[2])
        else:
            api.place_with(action[1], action[2], action[3])
