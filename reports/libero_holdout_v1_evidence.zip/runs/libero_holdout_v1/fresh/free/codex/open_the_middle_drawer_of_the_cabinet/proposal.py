def run(api):
    import numpy as np

    text = " ".join(
        api.instruction.lower().replace("-", " ").replace(",", " , ").split()
    )
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n
        and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        variants = {
            "akita black bowl": ["black bowl", "bowl"],
            "porcelain mug": ["white mug", "mug"],
            "white yellow mug": [
                "white and yellow mug", "yellow and white mug", "yellow mug"
            ],
            "red coffee mug": ["red mug"],
            "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
            "flat stove": ["stove"],
            "wooden cabinet": ["cabinet", "drawer"],
            "white cabinet": ["cabinet", "drawer"],
            "desk caddy": ["caddy"],
            "black book": ["book"],
            "cream cheese": ["cream cheese box"],
        }
        return [base] + variants.get(base, [])

    def mentions(s):
        padded = " " + s + " "
        hits = []
        for body in bodies:
            for alias in aliases(body):
                needle = " " + alias + " "
                start = padded.find(needle)
                while start >= 0:
                    hits.append((start, start + len(needle) - 1, body))
                    start = padded.find(needle, start + 1)
        hits.sort(key=lambda h: (-(h[1] - h[0]), h[0], h[2]))
        kept = []
        for hit in hits:
            if not any(hit[0] < h[1] and h[0] < hit[1] for h in kept):
                kept.append(hit)
        return sorted(kept)

    def region(body, suffixes):
        for suffix in suffixes:
            exact = body + "_" + suffix
            if exact in names:
                return exact
        return None

    def drawer_region(s, previous=None):
        level = next(
            (x for x in ("middle", "bottom", "top") if x in s.split()),
            None,
        )
        if level is None and previous is not None:
            return previous
        candidates = [
            n for n in names
            if ("cabinet" in n or "drawer" in n)
            and n.endswith("_region")
            and any("_" + x + "_region" in n
                    for x in ("top", "middle", "bottom"))
            and (level is None or "_" + level + "_region" in n)
        ]
        fixtures = [
            h[2] for h in mentions(s)
            if "cabinet" in h[2] or "drawer" in h[2]
        ]
        if fixtures:
            specific = [n for n in candidates if n.startswith(fixtures[-1] + "_")]
            if specific:
                candidates = specific
        return candidates[0] if len(candidates) == 1 else None

    # Build the complete ordered plan before starting physical actions.
    words = text.replace(".", " ").replace(";", " ").split()
    verbs = {"open", "close", "shut", "put", "place", "insert", "stack"}
    starts = [i for i, word in enumerate(words) if word in verbs]
    if not starts or any(
        phrase in text for phrase in
        ("turn on", "turn off", "switch on", "switch off")
    ):
        return api.fallback()

    plan = []
    previous_drawer = None
    previous_target = None
    previous_items = []

    for index, start in enumerate(starts):
        end = starts[index + 1] if index + 1 < len(starts) else len(words)
        verb = words[start]
        clause = " ".join(words[start + 1:end]).strip(" ,")
        if verb in ("open", "close", "shut"):
            target = drawer_region(clause, previous_drawer)
            if target is None:
                return api.fallback()
            plan.append(("drawer", target, "open" if verb == "open" else "close"))
            previous_drawer = target
            previous_target = target
            continue

        # The final placement preposition separates items from their destination.
        padded = " " + clause + " "
        separators = (
            " into ", " inside ", " onto ", " on top of ", " on ",
            " in ", " to ", " at ",
        )
        matches = [
            (padded.find(sep), sep)
            for sep in separators if padded.find(sep) >= 0
        ]
        if not matches:
            return api.fallback()
        split, separator = min(matches, key=lambda m: (m[0], -len(m[1])))
        source_text = padded[:split].strip()
        target_text = padded[split + len(separator):].strip()
        items = list(dict.fromkeys(h[2] for h in mentions(source_text)))
        if not items and any(w in source_text.split() for w in ("it", "them")):
            items = previous_items[:]
        if not items:
            # Handle "pick up X and place it ..." using the preceding text.
            prefix = " ".join(words[:start])
            earlier = mentions(prefix)
            if "it" in source_text.split() and earlier:
                items = [earlier[-1][2]]
        if not items:
            return api.fallback()

        target = None
        target_hits = mentions(target_text)
        target_body = target_hits[-1][2] if target_hits else None
        direction = next(
            (w for w in target_text.split()
             if w in ("left", "right", "front", "back")),
            None,
        )
        outside = any(
            phrase in target_text for phrase in
            ("next to", "left of", "right of", "in front of",
             "behind", "beside")
        )
        if "behind" in target_text:
            direction = "back"

        is_drawer = (
            "drawer" in target_text
            or ("layer" in target_text and
                any(x in target_text for x in ("top", "middle", "bottom")))
        )
        if is_drawer:
            target = drawer_region(target_text, previous_drawer)
            previous_drawer = target
        elif target_body and direction and "plate" in target_body:
            candidates = [n for n in bodies if "plate" in n]
            markers = [
                n for n in names
                if "plate" in n and direction in n and "region" in n
            ]
            if len(markers) == 1:
                target = api.nearest(markers[0], candidates)
        elif target_body and direction:
            target = api.relative_target(
                target_body, direction, "outside" if outside else "inside"
            )
        elif target_body:
            if "top" in target_text or separator == " on top of ":
                target = region(target_body, ("top_side", "top_region"))
            if target is None and separator in (" into ", " inside ", " in "):
                target = region(target_body, ("contain_region", "inside_region"))
            if target is None and "stove" in target_body:
                target = region(target_body, ("cook_region",))
            target = target or target_body
        elif any(w in target_text.split() for w in ("it", "there", "them")):
            target = previous_target

        if target is None or target in items:
            return api.fallback()
        for item in items:
            grasp = (
                "rim" if "bowl" in item else
                "thin_edge" if "book" in item else
                "standard"
            )
            plan.append(("place", item, target, grasp))
        previous_items = items
        previous_target = target

    for operation in plan:
        if operation[0] == "drawer":
            api.drawer(operation[1], operation[2])
        else:
            result = api.place_with(operation[1], operation[2], operation[3])
            if result is False:
                return
