import numpy as np


def run(api):
    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [
        n for n in names
        if n.rsplit("_", 1)[-1].isdigit()
        and "region" not in n
        and not n.endswith("_side")
    ]

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "glazed rim porcelain ramekin": ["porcelain ramekin", "ramekin"],
        "porcelain mug": ["white mug", "mug"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug", "mug"
        ],
        "red coffee mug": ["red mug", "coffee mug", "mug"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["stove"],
        "wooden cabinet": ["cabinet"],
        "white cabinet": ["cabinet"],
        "desk caddy": ["caddy"],
        "cream cheese": ["cream cheese box"],
        "black book": ["book"],
    }

    def position(name):
        return np.asarray(api.pos(name), dtype=float)

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        result = [base] + synonyms.get(base, [])
        words = base.split()
        if words:
            result.append(words[-1])
        return sorted(set(result), key=len, reverse=True)

    def mentions(phrase, pool=None):
        """Return nonoverlapping entity mentions, retaining duplicate candidates."""
        phrase = " " + phrase + " "
        hits = []
        for name in bodies if pool is None else pool:
            for alias in aliases(name):
                needle = " " + alias + " "
                start = phrase.find(needle)
                while start >= 0:
                    hits.append((start, start + len(needle) - 1, name))
                    start = phrase.find(needle, start + 1)
        spans = []
        for start, end, name in sorted(hits, key=lambda h: -(h[1] - h[0])):
            identical = next(
                (s for s in spans if s[0] == start and s[1] == end), None
            )
            if identical is not None:
                if name not in identical[2]:
                    identical[2].append(name)
            elif not any(start < s[1] and end > s[0] for s in spans):
                spans.append([start, end, [name]])
        return sorted(spans)

    def region_for(body, suffix):
        exact = body + "_" + suffix
        return exact if exact in names else None

    def spatial_region(phrase, body):
        direction = next(
            (d for d in ("left", "right", "front", "back")
             if d in phrase.split()), None
        )
        if direction is None:
            return None
        outside = any(p in phrase for p in (
            "next to", "beside", "to the left of", "to the right of",
            "in front of", "behind",
        ))
        inside = any(p in phrase for p in (
            " in ", " into ", "inside", "compartment", "section"
        ))
        if outside or inside:
            return api.relative_target(
                body, direction, "outside" if outside else "inside"
            )
        return None

    def choose(candidates, phrase, reference=None):
        if len(candidates) == 1:
            return candidates[0]
        if reference is not None:
            # A supporting body's centre identifies the stacked object.
            q = position(reference)
            return min(
                candidates,
                key=lambda n: (
                    np.linalg.norm(position(n)[:2] - q[:2])
                    + 0.25 * abs(position(n)[2] - q[2])
                    + (0.15 if position(n)[2] < q[2] - 0.025 else 0.0)
                ),
            )
        for direction in ("left", "right", "front", "back"):
            if direction in phrase.split():
                markers = [
                    n for n in names
                    if "region" in n and direction in n.split("_")
                    and any(
                        a.replace(" ", "_") in n
                        for candidate in candidates for a in aliases(candidate)
                    )
                ]
                if len(markers) == 1:
                    return api.nearest(markers[0], candidates)
        return None

    def source_items(phrase):
        found = mentions(phrase)
        if not found:
            return []
        result = []
        first = found[0]
        reference = None
        if len(found) > 1:
            between = (" " + phrase + " ")[first[1]:found[1][0]]
            if any(p in between for p in (
                " on ", " in ", " inside ", " from ", " above ", " near "
            )):
                reference = choose(found[1][2], phrase)
        if reference is not None:
            item = choose(first[2], phrase, reference)
            return [item] if item else []
        for start, end, candidates in found:
            item = choose(candidates, (" " + phrase + " ")[:end])
            if item is None:
                if "both" in phrase or "all" in phrase:
                    result.extend(candidates)
                else:
                    return []
            elif item not in result:
                result.append(item)
        return result

    def drawer_region(phrase):
        cabinets = [n for n in bodies if "cabinet" in n]
        explicit = mentions(phrase, cabinets)
        cabinet = (
            choose(explicit[0][2], phrase) if explicit
            else cabinets[0] if len(cabinets) == 1 else None
        )
        if cabinet is None:
            return None
        level = next(
            (d for d in ("bottom", "middle", "top") if d in phrase.split()),
            None,
        )
        if level is None:
            level = next(
                (d for d in ("bottom", "middle", "top") if d in text.split()),
                None,
            )
        return region_for(cabinet, level + "_region") if level else None

    def destination(phrase):
        if "drawer" in phrase:
            return drawer_region(phrase)
        found = mentions(phrase)
        if not found:
            return None
        body = choose(found[-1][2], phrase)
        if body is None:
            return None
        relative = spatial_region(" " + phrase + " ", body)
        if relative:
            return relative
        if "cabinet" in body and (
            "on" in phrase.split() or "top" in phrase.split()
        ):
            return region_for(body, "top_side")
        if "stove" in body:
            return region_for(body, "cook_region") or body
        if any(w in phrase.split() for w in ("in", "into", "inside")):
            return region_for(body, "contain_region") or body
        return body

    # Parse all actions before executing, so unsupported instructions can use
    # the previous policy without repeating partially completed work.
    words = text.split()
    verbs = {"pick", "take", "put", "place", "move", "open", "close"}
    if any(p in text for p in (
        "turn on", "turn off", "switch on", "switch off", "push", "pull"
    )):
        return api.fallback()
    starts = [i for i, w in enumerate(words) if w in verbs]
    if not starts:
        return api.fallback()

    actions = []
    held_description = ""
    last_target = None
    for k, start in enumerate(starts):
        end = starts[k + 1] if k + 1 < len(starts) else len(words)
        verb = words[start]
        clause = " ".join(words[start + 1:end]).strip(" ,.")
        while clause.endswith((" and", " then")):
            clause = clause.rsplit(" ", 1)[0]

        if verb in ("pick", "take"):
            held_description = clause
            continue

        if verb in ("open", "close"):
            region = drawer_region(clause)
            if region is None and ("it" in clause or "drawer" in clause):
                region = drawer_region(text)
            if region is None:
                return api.fallback()
            actions.append(("drawer", region, verb))
            continue

        # The last placement preposition separates a source description such
        # as "the bowl on the ramekin" from its destination.
        padded = " " + clause + " "
        separators = [
            " on top of ", " on ", " onto ", " into ", " inside ",
            " in ", " next to ", " beside ", " to ",
        ]
        splits = [
            (padded.rfind(sep), sep)
            for sep in separators if sep in padded
        ]
        if not splits:
            return api.fallback()
        split, sep = max(splits, key=lambda pair: pair[0])
        source = padded[:split].strip()
        target_phrase = padded[split:].strip()

        if source in ("it", "them", "these", "the object", ""):
            source = held_description
        items = source_items(source)
        target = destination(target_phrase)
        if target is None and any(
            w in target_phrase.split() for w in ("it", "there")
        ):
            target = last_target
        if not items or target is None or target in items:
            return api.fallback()

        for item in items:
            actions.append(("place", item, target))
        last_target = target
        held_description = source

    if not actions:
        return api.fallback()

    for kind, item, target in actions:
        if kind == "drawer":
            api.drawer(item, target)
        else:
            grasp = (
                "rim" if "bowl" in item
                else "thin_edge" if "book" in item
                else "standard"
            )
            api.place_with(item, target, grasp)
