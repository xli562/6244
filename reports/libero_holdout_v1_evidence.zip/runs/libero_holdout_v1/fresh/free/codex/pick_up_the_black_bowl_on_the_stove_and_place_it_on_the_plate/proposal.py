def run(api):
    import numpy as np

    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [
        n for n in names
        if n.rsplit("_", 1)[-1].isdigit()
        and "region" not in n and not n.endswith("_side")
    ]

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug", "mug"
        ],
        "red coffee mug": ["red coffee mug", "red mug", "mug"],
        "cream cheese": ["cream cheese box"],
        "black book": ["book"],
        "desk caddy": ["caddy"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["stove"],
        "wooden cabinet": ["cabinet"],
        "white cabinet": ["cabinet"],
        "woven basket": ["basket"],
    }

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        result = [base] + synonyms.get(base, [])
        for noun in ("bowl", "plate", "basket", "cabinet", "ramekin",
                     "book", "mug", "caddy"):
            if noun in base.split() and noun not in result:
                result.append(noun)
        return result

    def occurrences(phrase, alias):
        return (" " + alias + " ") in (" " + phrase.strip(" ,.;") + " ")

    def score(name, phrase):
        return max(
            [len(a) for a in aliases(name) if occurrences(phrase, a)] or [0]
        )

    def candidates(phrase):
        scored = [(score(n, phrase), n) for n in bodies]
        best = max([s for s, n in scored] or [0])
        return [n for s, n in scored if s == best and s > 0]

    def region(body, fragments):
        for fragment in fragments:
            exact = body + "_" + fragment
            if exact in names:
                return exact
        return body

    def marker(phrase):
        words = [
            w for w in phrase.replace(",", " ").split()
            if w not in ("the", "a", "an", "of", "to", "on", "in", "at",
                         "is", "that", "located", "sitting")
        ]
        options = [n for n in names if n not in bodies]
        ranked = [
            (sum(w in n.split("_") for w in words), n) for n in options
        ]
        best = max([s for s, n in ranked] or [0])
        winners = [n for s, n in ranked if s == best and s > 0]
        return winners[0] if len(winners) == 1 else None

    def resolve(phrase):
        # Separate the object's identity from its source-location qualifier.
        cuts = []
        for separator in (" on ", " in ", " inside ", " from ", " near ",
                          " next to ", " at "):
            index = phrase.find(separator)
            if index >= 0:
                cuts.append((index, separator))
        if cuts:
            index, separator = min(cuts)
            head, location = phrase[:index], phrase[index + len(separator):]
        else:
            head, location = phrase, ""

        options = candidates(head)
        if not options:
            options = candidates(phrase)
        if len(options) == 1:
            return options[0]
        if not options:
            return None

        if location:
            references = candidates(location)
            reference = references[0] if len(references) == 1 else marker(location)
            if reference:
                reference = region(reference, ("cook_region", "contain_region"))
                return api.nearest(reference, options)

        location_marker = marker(phrase)
        if location_marker:
            return api.nearest(location_marker, options)
        return None

    active_drawer = None

    def drawer_region(phrase):
        level = next(
            (w for w in ("bottom", "middle", "top") if w in phrase.split()),
            None,
        )
        cabinets = [n for n in bodies if "cabinet" in n]
        explicit = [n for n in cabinets if score(n, phrase)]
        if explicit:
            best = max(score(n, phrase) for n in explicit)
            cabinets = [n for n in explicit if score(n, phrase) == best]
        if level:
            options = [
                n for n in names
                if n.endswith("_" + level + "_region")
                and any(n.startswith(c + "_") for c in cabinets)
            ]
            if len(options) == 1:
                return options[0]
        return active_drawer

    def destination(phrase, prep):
        if "drawer" in phrase:
            return drawer_region(phrase)
        if phrase.strip(" ,.;") in ("it", "inside", "inside it", "there"):
            return active_drawer

        reference = resolve(phrase)
        if reference is None:
            return None

        direction = next(
            (d for d in ("left", "right", "front", "back")
             if d in phrase.split()), None
        )
        if direction:
            outside = (
                prep in ("next to", "beside")
                or "next to" in phrase or "side of" in phrase
                or "front of" in phrase or "back of" in phrase
            )
            inside = (
                prep in ("in", "into", "inside")
                or "compartment" in phrase
            )
            if outside or inside:
                return api.relative_target(
                    reference, direction, "outside" if outside else "inside"
                )

        if prep in ("in", "into", "inside"):
            return region(reference, ("contain_region",))
        if "cabinet" in reference:
            return region(reference, ("top_side",))
        if "stove" in reference:
            return region(reference, ("cook_region",))
        return reference

    # Build the complete ordered plan before issuing physical commands.
    tokens = text.replace(",", " , ").replace(".", " ").split()
    verbs = {"pick", "take", "grab", "put", "place", "move",
             "open", "close", "shut", "turn", "push", "pull", "stack"}
    starts = [i for i, word in enumerate(tokens) if word in verbs]
    if not starts:
        return api.fallback()

    clauses = []
    for j, start in enumerate(starts):
        end = starts[j + 1] if j + 1 < len(starts) else len(tokens)
        part = tokens[start:end]
        while part and part[-1] in ("and", "then", ","):
            part.pop()
        clauses.append((part[0], " ".join(part[1:])))

    pending = []
    plan = []
    for verb, phrase in clauses:
        if verb in ("turn", "push", "pull", "stack"):
            return api.fallback()

        if verb in ("open", "close", "shut"):
            target = drawer_region(phrase)
            if target is None:
                return api.fallback()
            active_drawer = target
            plan.append(("drawer", target,
                         "open" if verb == "open" else "close"))
            continue

        if verb in ("pick", "take", "grab"):
            source = phrase
            if source.startswith("up "):
                source = source[3:]
            source = source.replace(" up ", " ").removesuffix(" up")
            item = resolve(source)
            if item is None:
                return api.fallback()
            pending = [item]
            continue

        splits = []
        for prep in ("on top of", "next to", "inside", "into",
                     "onto", "beside", "on", "in", "to"):
            needle = " " + prep + " "
            index = phrase.rfind(needle)
            if index >= 0:
                splits.append((index, len(prep), prep))

        if not splits:
            if active_drawer and (
                phrase.endswith(" inside") or phrase.endswith(" in")
            ):
                source = phrase.rsplit(" ", 1)[0]
                target = active_drawer
            else:
                return api.fallback()
        else:
            # The last placement preposition follows any source qualifier.
            index, length, prep = max(splits)
            source = phrase[:index]
            target_phrase = phrase[index + length + 2:]
            target = destination(target_phrase, prep)

        if target is None:
            return api.fallback()

        source = source.strip(" ,;")
        if source in ("it", "them", "the object", "the objects"):
            items = list(pending)
        else:
            # Keep compound color names intact before considering a list.
            single = resolve(source)
            if single is not None:
                items = [single]
            else:
                parts = source.replace(" , ", " and ").split(" and ")
                items = [resolve(part) for part in parts]

        if not items or any(item is None for item in items):
            return api.fallback()
        for item in items:
            plan.append(("place", item, target))
        pending = items

    if not plan:
        return api.fallback()

    for operation, item, target in plan:
        if operation == "drawer":
            api.drawer(item, target)
        else:
            grasp = (
                "rim" if "bowl" in item
                else "thin_edge" if "book" in item
                else "standard"
            )
            api.place_with(item, target, grasp)
