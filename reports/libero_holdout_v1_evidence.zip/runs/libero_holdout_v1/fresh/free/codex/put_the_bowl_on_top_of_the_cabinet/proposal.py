def run(api):
    import numpy as np

    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [
        n for n in names
        if n.rsplit("_", 1)[-1].isdigit()
        and "region" not in n and not n.endswith("_side")
    ]

    def words(name):
        return name.replace("_", " ")

    def aliases(name):
        base = words(name.rsplit("_", 1)[0])
        result = [base]
        mappings = {
            "akita black bowl": ["black bowl", "bowl"],
            "porcelain mug": ["porcelain mug", "white mug", "mug"],
            "white yellow mug": [
                "white and yellow mug", "yellow and white mug", "yellow mug", "mug"
            ],
            "red coffee mug": ["red coffee mug", "red mug", "mug"],
            "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
            "black book": ["black book", "book"],
            "cream cheese": ["cream cheese box", "cream cheese"],
            "desk caddy": ["desk caddy", "caddy"],
            "flat stove": ["flat stove", "stove"],
        }
        result.extend(mappings.get(base, []))
        if "cabinet" in base:
            result.extend(["cabinet", "drawer"])
        return sorted(set(result), key=len, reverse=True)

    def mentions(sentence):
        padded = " " + sentence + " "
        hits = []
        for body in bodies:
            for alias in aliases(body):
                needle = " " + alias + " "
                start = padded.find(needle)
                while start >= 0:
                    hits.append((start, start + len(needle) - 1, body, alias))
                    start = padded.find(needle, start + 1)
        # Specific names suppress shorter generic matches at the same location.
        hits.sort(key=lambda h: (-(h[1] - h[0]), h[0]))
        selected = []
        for hit in hits:
            if not any(
                hit[0] < other[1] and other[0] < hit[1]
                for other in selected
            ):
                selected.append(hit)
        return sorted(selected)

    def region(body, suffixes):
        for suffix in suffixes:
            name = body + "_" + suffix
            if name in names:
                return name
        return None

    def direction(sentence):
        # Keep front/back/left/right as stated, in world-region semantics.
        for token in sentence.split():
            if token in ("left", "right", "front", "back"):
                return token
        return None

    def drawer_region(sentence):
        fixtures = [b for b in bodies if "cabinet" in b or "drawer" in b]
        explicit = [h[2] for h in mentions(sentence) if h[2] in fixtures]
        if explicit:
            fixture = explicit[-1]
        elif len(fixtures) == 1:
            fixture = fixtures[0]
        else:
            return None
        level = next(
            (x for x in ("bottom", "middle", "top") if x in sentence.split()),
            None,
        )
        if level:
            return region(fixture, [level + "_region"])
        available = [
            region(fixture, [x + "_region"])
            for x in ("bottom", "middle", "top")
        ]
        available = [x for x in available if x]
        return available[0] if len(available) == 1 else None

    # Split at action verbs, preserving coordinated object lists.
    verbs = {
        "put", "place", "move", "set", "stack", "insert",
        "open", "close", "shut", "turn",
    }
    tokens = text.replace(",", " , ").replace(".", " ").split()
    starts = [i for i, token in enumerate(tokens) if token in verbs]
    if not starts:
        return api.fallback()
    clauses = []
    for j, start in enumerate(starts):
        end = starts[j + 1] if j + 1 < len(starts) else len(tokens)
        clause = tokens[start:end]
        while clause and clause[-1] in ("and", "then", ","):
            clause.pop()
        clauses.append(" ".join(clause))

    plan = []
    previous_item = None
    previous_target = None
    previous_drawer = None

    for clause in clauses:
        verb = clause.split()[0]
        if verb == "turn":
            return api.fallback()

        if verb in ("open", "close", "shut"):
            target = drawer_region(clause)
            if target is None and ("it" in clause.split() or "drawer" in clause):
                target = previous_drawer
            if target is None:
                return api.fallback()
            plan.append(("drawer", target, "open" if verb == "open" else "close"))
            previous_drawer = target
            continue

        # The first destination preposition separates objects from destination.
        padded = " " + clause + " "
        connectors = (
            " on top of ", " onto ", " on ", " into ", " inside ",
            " in ", " to ", " next to ",
        )
        splits = [
            (padded.find(c), -len(c), c)
            for c in connectors if c in padded
        ]
        if not splits:
            return api.fallback()
        index, _, connector = min(splits)
        source_text = padded[:index].strip()
        destination = padded[index + len(connector):].strip()
        items = list(dict.fromkeys(h[2] for h in mentions(source_text)))
        if not items and previous_item and "it" in source_text.split():
            items = [previous_item]
        if not items:
            return api.fallback()

        target_hits = mentions(destination)
        target_body = target_hits[-1][2] if target_hits else None
        target = None
        inside = connector in (" in ", " into ", " inside ")

        if "drawer" in destination or "cabinet" in destination:
            # A surface on top of the drawer is distinct from its top compartment.
            surface = (
                connector == " on top of "
                or (not inside and (
                    "top of" in destination
                    or "top side" in destination
                    or "countertop" in destination
                    or " on " == connector
                    or " onto " == connector
                ))
            )
            if surface:
                fixtures = [
                    b for b in bodies if "cabinet" in b or "drawer" in b
                ]
                if target_body not in fixtures:
                    target_body = fixtures[0] if len(fixtures) == 1 else None
                if target_body:
                    target = region(target_body, ["top_side"])
            else:
                target = drawer_region(destination) or previous_drawer
                if target:
                    previous_drawer = target
        elif target_body:
            side = direction(destination)
            outside = (
                "next to" in clause or "beside" in clause
                or "in front of" in clause or "behind" in clause
                or "to the left of" in clause or "to the right of" in clause
            )
            if side and (inside or outside):
                target = api.relative_target(
                    target_body, side, "outside" if outside else "inside"
                )
            elif side and "plate" in target_body:
                markers = [
                    n for n in names
                    if "plate" in n and side in n and "region" in n
                ]
                plates = [b for b in bodies if "plate" in b]
                if len(markers) == 1:
                    target = api.nearest(markers[0], plates)
            if target is None:
                if inside:
                    target = region(target_body, ["contain_region"]) or target_body
                elif "stove" in target_body:
                    target = region(target_body, ["cook_region"]) or target_body
                else:
                    target = target_body
        elif previous_target and any(
            token in destination.split() for token in ("it", "there")
        ):
            target = previous_target

        if target is None:
            return api.fallback()
        for item in items:
            if item == target:
                return api.fallback()
            grasp = (
                "rim" if "bowl" in item
                else "thin_edge" if "book" in item
                else "standard"
            )
            plan.append(("place", item, target, grasp))
            previous_item = item
        previous_target = target

    for operation in plan:
        if operation[0] == "drawer":
            api.drawer(operation[1], operation[2])
        else:
            api.place_with(operation[1], operation[2], operation[3])
