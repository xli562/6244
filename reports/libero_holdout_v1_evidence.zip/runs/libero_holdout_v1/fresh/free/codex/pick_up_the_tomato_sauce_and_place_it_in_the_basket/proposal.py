def run(api):
    import numpy as np

    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug"
        ],
        "red coffee mug": ["red mug"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["stove"],
        "white cabinet": ["cabinet"],
        "wooden cabinet": ["cabinet"],
        "desk caddy": ["caddy"],
        "black book": ["book"],
        "cream cheese": ["cream cheese box"],
    }

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        return [base] + synonyms.get(base, [])

    def mentions(sentence, pool=None):
        pool = bodies if pool is None else pool
        padded = " " + sentence + " "
        hits = []
        for name in pool:
            for alias in aliases(name):
                needle = " " + alias + " "
                start = padded.find(needle)
                while start >= 0:
                    hits.append((start, start + len(needle), name))
                    start = padded.find(needle, start + 1)
        # A specific phrase takes precedence over a generic overlapping alias.
        hits.sort(key=lambda h: (-(h[1] - h[0]), h[0]))
        accepted = []
        for hit in hits:
            if not any(hit[0] < h[1] and h[0] < hit[1] for h in accepted):
                accepted.append(hit)
        accepted.sort()
        result = []
        for _, _, name in accepted:
            if name not in result:
                result.append(name)
        return result

    def region(body, suffix):
        exact = body + "_" + suffix
        if exact in names:
            return exact
        return next(
            (n for n in names if n.startswith(body + "_") and n.endswith(suffix)),
            None,
        )

    def drawer_region(sentence):
        levels = [s for s in ("top", "middle", "bottom") if s in sentence.split()]
        candidates = [
            n for n in names
            if "region" in n and ("cabinet" in n or "drawer" in n)
            and any("_" + level + "_" in n for level in
                    (levels or ["top", "middle", "bottom"]))
        ]
        refs = mentions(sentence)
        specific = [n for n in candidates if any(n.startswith(b + "_") for b in refs)]
        candidates = specific or candidates
        return candidates[0] if len(candidates) == 1 else None

    def destination(sentence, reference):
        if "drawer" in sentence:
            return drawer_region(sentence)

        words = sentence.split()
        direction = next(
            (w for w in words if w in ("left", "right", "front", "back")),
            None,
        )
        if direction:
            # Side-qualified plates refer to the plate at that observed location.
            if "plate" in reference:
                markers = [
                    n for n in names
                    if "plate" in n and "_" + direction + "_" in n
                ]
                plates = [n for n in bodies if "plate" in n]
                if markers and plates:
                    return api.nearest(markers[0], plates)

            outside = any(p in sentence for p in (
                "next to", "to the left of", "to the right of",
                "in front of", "behind", "left of", "right of",
            ))
            inside = any(p in sentence for p in (
                "inside", " into ", " in ", "compartment"
            ))
            if outside or inside:
                return api.relative_target(
                    reference, direction, "outside" if outside else "inside"
                )

        if any(p in sentence for p in ("on top", "top of")):
            return region(reference, "top_side") or reference
        if "stove" in reference:
            return region(reference, "cook_region") or reference
        if any(p in sentence for p in (" in ", " into ", "inside", "basket")):
            return region(reference, "contain_region") or reference
        return region(reference, "top_side") or reference

    # Split at action verbs while retaining conjunctions within object names.
    words = text.replace(",", " , ").replace(".", " ").split()
    verbs = {"pick", "grab", "take", "put", "place", "move",
             "open", "close", "shut", "turn", "push", "pull", "stack"}
    starts = [i for i, w in enumerate(words) if w in verbs]
    if not starts:
        return api.fallback()

    clauses = [
        " ".join(words[start:(starts[i + 1] if i + 1 < len(starts) else len(words))])
        for i, start in enumerate(starts)
    ]

    plan = []
    held_items = []
    last_target = None

    for clause in clauses:
        verb = clause.split()[0]
        refs = mentions(clause)

        if verb in ("turn", "push", "pull"):
            return api.fallback()

        if verb in ("open", "close", "shut"):
            target = drawer_region(clause)
            if target is None and last_target and (
                "drawer" in last_target or "cabinet" in last_target
            ):
                target = last_target
            if target is None:
                return api.fallback()
            plan.append(("drawer", target, "open" if verb == "open" else "close"))
            last_target = target
            continue

        if verb in ("pick", "grab", "take"):
            held_items = refs
            continue

        if verb not in ("put", "place", "move", "stack"):
            return api.fallback()

        if "drawer" in clause:
            target = drawer_region(clause)
            items = [n for n in refs if "cabinet" not in n and "drawer" not in n]
            items = items or held_items
        else:
            if refs:
                reference = refs[-1]
                target = destination(" " + clause + " ", reference)
                items = refs[:-1] or [n for n in held_items if n != reference]
            else:
                target = last_target
                items = held_items

        if not target or not items:
            return api.fallback()

        for item in items:
            grasp = (
                "rim" if "bowl" in item
                else "thin_edge" if "book" in item
                else "standard"
            )
            plan.append(("place", item, target, grasp))
        last_target = target
        held_items = []

    if not plan or held_items:
        return api.fallback()

    for operation in plan:
        if operation[0] == "drawer":
            api.drawer(operation[1], operation[2])
        else:
            api.place_with(operation[1], operation[2], operation[3])
