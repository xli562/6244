def run(api):
    import numpy as np

    text = " ".join(
        api.instruction.lower().replace("-", " ").replace(",", " ").split()
    ).strip(".")
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug", "mug"
        ],
        "red coffee mug": ["red coffee mug", "red mug", "mug"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["stove"],
        "white cabinet": ["cabinet"],
        "wooden cabinet": ["cabinet"],
        "desk caddy": ["desk caddy", "caddy"],
        "black book": ["black book", "book"],
        "cream cheese": ["cream cheese", "cream cheese box"],
        "bbq sauce": ["bbq sauce", "barbecue sauce"],
    }

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        result = [base] + synonyms.get(base, [])
        if base.endswith("basket"):
            result.append("basket")
        return list(set(result))

    def mentions(phrase):
        padded = " " + phrase + " "
        hits = []
        for body in bodies:
            for alias in aliases(body):
                needle = " " + alias + " "
                start = padded.find(needle)
                if start >= 0:
                    hits.append((start, start + len(needle), body))
        # A specific name takes precedence over a generic overlapping alias.
        hits = [
            h for h in hits
            if not any(
                g[0] <= h[0] and g[1] >= h[1]
                and g[1] - g[0] > h[1] - h[0]
                for g in hits
            )
        ]
        result = []
        for _, _, body in sorted(hits):
            if body not in result:
                result.append(body)
        return result

    def region(body, suffixes):
        for suffix in suffixes:
            exact = body + "_" + suffix
            if exact in names:
                return exact
        return None

    def drawer_region(phrase):
        level = next(
            (s for s in ("top", "middle", "bottom") if s in phrase.split()),
            None,
        )
        candidates = [
            n for n in names
            if "region" in n
            and ("cabinet" in n or "drawer" in n)
            and any("_" + s + "_" in n for s in ("top", "middle", "bottom"))
            and (level is None or "_" + level + "_" in n)
        ]
        fixtures = mentions(phrase)
        narrowed = [
            n for n in candidates if any(n.startswith(b + "_") for b in fixtures)
        ]
        candidates = narrowed or candidates
        return candidates[0] if len(candidates) == 1 else None

    def resolve(phrase):
        candidates = mentions(phrase)
        if len(candidates) <= 1:
            return candidates
        direction = next(
            (d for d in ("left", "right", "front", "back")
             if d in phrase.split()), None
        )
        if direction:
            markers = [
                n for n in names
                if "region" in n and direction in n.split("_")
                and any(
                    b.rsplit("_", 1)[0] in n
                    or b.rsplit("_", 1)[0].split("_")[-1] in n.split("_")
                    for b in candidates
                )
            ]
            if len(markers) == 1:
                return [api.nearest(markers[0], candidates)]
        return candidates

    # Defer unsupported manipulation before making any physical changes.
    if any(p in text for p in (
        "turn on", "turn off", "switch on", "switch off",
        "stack", "pour", "push", "rotate",
    )):
        return api.fallback()

    words = text.split()
    verbs = {"pick", "take", "grab", "put", "place", "move", "open", "close"}
    starts = [i for i, word in enumerate(words) if word in verbs]
    if not starts:
        return api.fallback()

    clauses = []
    for j, start in enumerate(starts):
        end = starts[j + 1] if j + 1 < len(starts) else len(words)
        part = words[start:end]
        while part and part[-1] in ("and", "then"):
            part.pop()
        clauses.append(part)

    plan = []
    held = []
    last_drawer = None
    drawer_state = {}

    for clause in clauses:
        verb = clause[0]
        phrase = " ".join(clause[1:])

        if verb in ("open", "close"):
            target = drawer_region(phrase)
            if target is None and phrase in ("it", "the drawer", "drawer"):
                target = last_drawer
            if target is None:
                return api.fallback()
            plan.append(("drawer", target, verb))
            drawer_state[target] = verb
            last_drawer = target
            continue

        if verb in ("pick", "take", "grab"):
            held = resolve(phrase)
            if not held:
                return api.fallback()
            continue

        separators = {"in", "into", "inside", "on", "onto", "to"}
        split = next(
            (i for i in range(1, len(clause)) if clause[i] in separators),
            None,
        )
        if split is None:
            return api.fallback()

        source_text = " ".join(clause[1:split])
        target_text = " ".join(clause[split:])
        items = resolve(source_text)
        if not items and any(
            p in source_text.split() for p in ("it", "them", "both")
        ):
            items = held[:]
        if not items:
            return api.fallback()

        if "drawer" in target_text:
            target = drawer_region(target_text)
            if target is None:
                target = last_drawer
            if target is None:
                return api.fallback()
            if drawer_state.get(target) != "open":
                plan.append(("drawer", target, "open"))
                drawer_state[target] = "open"
            last_drawer = target
        else:
            targets = resolve(target_text)
            if not targets and " on it" in " " + target_text:
                targets = held[:]
            if len(targets) != 1:
                return api.fallback()
            body = targets[0]
            direction = next(
                (d for d in ("left", "right", "front", "back")
                 if d in target_text.split()), None
            )
            external = any(s in target_text for s in (
                "next to", "beside", "to the left of", "to the right of",
                "in front of", "behind",
            ))
            if "behind" in target_text:
                direction = "back"
            if direction and (
                external or "caddy" in body or "compartment" in target_text
            ):
                target = api.relative_target(
                    body, direction, "outside" if external else "inside"
                )
                if target is None:
                    return api.fallback()
            elif any(w in target_text.split() for w in ("in", "into", "inside")):
                target = region(body, ["contain_region"]) or body
            else:
                target = region(body, ["top_side", "cook_region"]) or body

        for item in items:
            if item == target:
                return api.fallback()
            skill = (
                "rim" if "bowl" in item
                else "thin_edge" if "book" in item
                else "standard"
            )
            plan.append(("place", item, target, skill))
        held = items[:]

    if not plan:
        return api.fallback()

    for action in plan:
        if action[0] == "drawer":
            result = api.drawer(action[1], action[2])
        else:
            result = api.place_with(action[1], action[2], action[3])
        if result is False:
            return
