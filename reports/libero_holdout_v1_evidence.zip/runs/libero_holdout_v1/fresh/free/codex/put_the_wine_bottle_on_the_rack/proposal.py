def run(api):
    import numpy as np

    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [
        n for n in names
        if n.rsplit("_", 1)[-1].isdigit()
        and "region" not in n and not n.endswith("_side")
    ]

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug", "mug"
        ],
        "red coffee mug": ["red coffee mug", "red mug", "mug"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["stove"],
        "wine rack": ["wine rack", "rack"],
        "wine bottle": ["wine bottle", "bottle"],
        "wooden cabinet": ["wooden cabinet", "cabinet"],
        "white cabinet": ["white cabinet", "cabinet"],
        "desk caddy": ["desk caddy", "caddy"],
        "black book": ["black book", "book"],
        "cream cheese": ["cream cheese box", "cream cheese"],
        "moka pot": ["moka pot", "coffee pot"],
    }

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        result = [base] + synonyms.get(base, [])
        for noun in ("basket", "plate", "bowl", "book", "mug"):
            if noun in base.split():
                result.append(noun)
        return list(set(result))

    def mentions(clause):
        padded = " " + clause + " "
        hits = []
        for name in bodies:
            for alias in aliases(name):
                needle = " " + alias + " "
                start = 0
                while True:
                    index = padded.find(needle, start)
                    if index < 0:
                        break
                    hits.append((index, index + len(needle) - 1, name))
                    start = index + 1
        # A specific phrase takes precedence over a shorter overlapping alias.
        hits = [
            h for h in hits
            if not any(
                k[0] <= h[0] and k[1] >= h[1]
                and k[1] - k[0] > h[1] - h[0]
                for k in hits
            )
        ]
        groups = {}
        for start, end, name in hits:
            groups.setdefault((start, end), set()).add(name)
        result = []
        for (start, end), candidates in sorted(groups.items()):
            candidates = sorted(candidates)
            if len(candidates) == 1:
                chosen = candidates[0]
            else:
                context = padded[max(0, start - 40):end]
                markers = [
                    n for n in names
                    if "region" in n
                    and any(
                        side in context.split() and side in n.split("_")
                        for side in ("left", "right", "front", "back")
                    )
                    and any(
                        word in n.split("_")
                        for word in candidates[0].split("_")[:-1]
                    )
                ]
                if len(markers) != 1:
                    return None
                chosen = api.nearest(markers[0], candidates)
            result.append((start, end, chosen))
        return result

    def region(body, suffixes):
        for suffix in suffixes:
            candidate = body + "_" + suffix
            if candidate in names:
                return candidate
        return body

    def drawer_region(clause, previous=None):
        levels = [
            level for level in ("top", "middle", "bottom")
            if level in clause.split()
        ]
        level = levels[0] if levels else None
        candidates = [
            n for n in names
            if "cabinet" in n and n.endswith("_region")
            and any(n.endswith("_" + x + "_region")
                    for x in ("top", "middle", "bottom"))
            and (level is None or n.endswith("_" + level + "_region"))
        ]
        if previous in candidates:
            return previous
        return candidates[0] if len(candidates) == 1 else None

    def destination(body, clause, tail):
        words = tail.split()
        outside = any(
            phrase in tail for phrase in (
                "next to", "to the left of", "to the right of",
                "in front of", "behind", "beside"
            )
        )
        direction = next(
            (d for d in ("left", "right", "front", "back") if d in words),
            None
        )
        if "behind" in words:
            direction = "back"
        if direction and outside:
            return api.relative_target(body, direction, "outside")
        if direction and (
            "caddy" in body or "compartment" in tail
            or "inside" in words or " in " in " " + tail + " "
        ):
            return api.relative_target(body, direction, "inside")
        if "cabinet" in body and "drawer" in clause:
            return drawer_region(clause)
        if "cabinet" in body:
            return region(body, ["top_side"])
        if "rack" in body:
            return region(body, ["top_region", "top_side"])
        if "stove" in body:
            return region(body, ["cook_region"])
        if "basket" in body or "caddy" in body:
            return region(body, ["contain_region"])
        if "inside" in words or "into" in words or "in" in words:
            return region(body, ["contain_region"])
        return body

    # Compile the requested actions before performing any manipulation.
    words = text.replace(",", " , ").replace(".", " . ").split()
    verbs = {"put", "place", "move", "stack", "open", "close", "shut"}
    if any(phrase in text for phrase in (
        "turn on", "turn off", "switch on", "switch off"
    )):
        return api.fallback()

    starts = [i for i, word in enumerate(words) if word in verbs]
    if not starts:
        return api.fallback()
    starts.append(len(words))
    clauses = [
        " ".join(words[starts[i]:starts[i + 1]]).strip(" ,.")
        for i in range(len(starts) - 1)
    ]

    plan = []
    last_drawer = None
    last_item = None
    last_target = None

    for clause in clauses:
        verb = clause.split()[0]
        if verb in ("open", "close", "shut"):
            target = drawer_region(clause, last_drawer)
            if target is None:
                return api.fallback()
            plan.append(("drawer", target, "open" if verb == "open" else "close"))
            last_drawer = target
            continue

        hits = mentions(clause)
        if hits is None:
            return api.fallback()

        if "drawer" in clause:
            target = drawer_region(clause, last_drawer)
            items = [
                name for _, _, name in hits if "cabinet" not in name
            ]
            last_drawer = target
        elif len(hits) >= 2:
            target_body = hits[-1][2]
            target_start = hits[-1][0]
            # Retain spatial prepositions and compartment descriptions.
            source_end = hits[-2][1]
            tail = clause[max(0, source_end - 1):]
            target = destination(target_body, clause, tail)
            items = [
                name for start, _, name in hits
                if start < target_start and name != target_body
            ]
        elif len(hits) == 1 and any(
            phrase in clause for phrase in ("put it ", "place it ", "move it ")
        ):
            target = destination(hits[0][2], clause, clause)
            items = [last_item] if last_item else []
        elif len(hits) == 1 and any(
            phrase in clause for phrase in ("there", "on it", "into it", "in it")
        ):
            target = last_target
            items = [hits[0][2]]
        else:
            return api.fallback()

        if not items and last_item and " it " in " " + clause + " ":
            items = [last_item]
        if target is None or not items:
            return api.fallback()

        seen = set()
        for item in items:
            if item in seen:
                continue
            seen.add(item)
            grasp = (
                "rim" if "bowl" in item
                else "thin_edge" if "book" in item
                else "standard"
            )
            plan.append(("place", item, target, grasp))
            last_item = item
        last_target = target

    for action in plan:
        if action[0] == "drawer":
            api.drawer(action[1], action[2])
        else:
            api.place_with(action[1], action[2], action[3])
