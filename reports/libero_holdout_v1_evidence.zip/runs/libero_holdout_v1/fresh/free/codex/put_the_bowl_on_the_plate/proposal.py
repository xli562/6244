def run(api):
    import numpy as np

    text = " ".join(
        api.instruction.lower().replace("-", " ").replace(",", " , ").split()
    )
    names = list(api.names())
    bodies = [
        n for n in names
        if n.rsplit("_", 1)[-1].isdigit()
        and "region" not in n and not n.endswith("_side")
    ]

    def normalize(s):
        return " ".join(s.replace("_", " ").replace("-", " ").split())

    def aliases(n):
        base = normalize(n.rsplit("_", 1)[0])
        result = [base]
        mapping = {
            "akita black bowl": ["black bowl", "bowl"],
            "porcelain mug": ["white mug", "mug", "cup"],
            "white yellow mug": [
                "yellow and white mug", "white and yellow mug", "yellow mug",
                "mug", "cup",
            ],
            "red coffee mug": ["red mug", "coffee mug", "mug", "cup"],
            "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
            "flat stove": ["stove"],
            "desk caddy": ["desk caddy", "caddy"],
            "wooden cabinet": ["wooden cabinet", "cabinet"],
            "white cabinet": ["white cabinet", "cabinet"],
            "cream cheese": ["cream cheese", "cream cheese box"],
            "black book": ["black book", "book"],
        }
        result.extend(mapping.get(base, []))
        for word in ("bowl", "plate", "basket", "book", "rack", "bottle",
                     "cabinet", "caddy", "ramekin"):
            if word in base.split():
                result.append(word)
        return sorted(set(result), key=len, reverse=True)

    vocabulary = {n: aliases(n) for n in bodies}

    def mentions(s):
        padded = " " + s + " "
        hits = []
        for n in bodies:
            for alias in vocabulary[n]:
                needle = " " + alias + " "
                start = padded.find(needle)
                while start >= 0:
                    hits.append((start, start + len(needle) - 2, n, len(alias)))
                    start = padded.find(needle, start + 1)
        # Prefer specific names to generic aliases occupying the same phrase.
        hits.sort(key=lambda h: (-h[3], h[0]))
        kept = []
        for hit in hits:
            if not any(hit[0] <= h[1] and h[0] <= hit[1] for h in kept):
                kept.append(hit)
        return sorted(kept)

    def region(body, suffixes):
        for suffix in suffixes:
            exact = body + "_" + suffix
            if exact in names:
                return exact
        return None

    def direction(s):
        for word in s.split():
            if word.strip(".,") in ("left", "right", "front", "back"):
                return word.strip(".,")
        if "behind" in s:
            return "back"
        return None

    def locate_body(s, hits):
        if not hits:
            return None
        body = hits[-1][2]
        side = direction(s)
        base = body.rsplit("_", 1)[0]
        candidates = [n for n in bodies if n.rsplit("_", 1)[0] == base]
        if side and len(candidates) > 1:
            markers = [
                n for n in names
                if "region" in n and base in n and side in n
            ]
            if markers:
                return api.nearest(markers[0], candidates)
        return body

    def drawer_region(s, previous=None):
        fixtures = [h for h in mentions(s) if "cabinet" in h[2]]
        cabinet = fixtures[-1][2] if fixtures else None
        if cabinet is None:
            cabinets = [n for n in bodies if "cabinet" in n]
            if len(cabinets) == 1:
                cabinet = cabinets[0]
        level = next(
            (x for x in ("bottom", "middle", "top") if x in s.split()), None
        )
        if level is None and previous:
            return previous
        if cabinet and level:
            return region(cabinet, [level + "_region"])
        candidates = [
            n for n in names
            if n.endswith("_region") and "cabinet" in n
            and (level is None or "_" + level + "_" in n)
        ]
        return candidates[0] if len(candidates) == 1 else None

    # Split at action verbs, preserving conjunctions within object names.
    words = text.split()
    verbs = {"put", "place", "move", "open", "close", "shut", "turn"}
    starts = [i for i, word in enumerate(words) if word in verbs]
    if not starts or any(words[i] == "turn" for i in starts):
        return api.fallback()
    clauses = [
        " ".join(words[start:(starts[j + 1] if j + 1 < len(starts) else len(words))])
        for j, start in enumerate(starts)
    ]

    plan = []
    last_items = []
    last_drawer = None
    last_target = None

    for clause in clauses:
        verb = clause.split()[0]
        if verb in ("open", "close", "shut"):
            if "drawer" not in clause and not last_drawer:
                return api.fallback()
            target = drawer_region(clause, last_drawer)
            if target is None:
                return api.fallback()
            plan.append(("drawer", target, "open" if verb == "open" else "close"))
            last_drawer = target
            continue

        # The destination starts at the first placement preposition.
        tokens = clause.split()
        boundary = next(
            (i for i, w in enumerate(tokens[1:], 1)
             if w in ("on", "onto", "in", "into", "inside", "to")), None
        )
        if boundary is None:
            return api.fallback()
        source_text = " ".join(tokens[1:boundary])
        destination = " ".join(tokens[boundary:])
        source_hits = mentions(source_text)
        items = []
        for hit in source_hits:
            item = hit[2]
            if item not in items:
                items.append(item)
        if not items and any(w in source_text.split() for w in ("it", "them")):
            items = last_items[:]
        if not items:
            return api.fallback()

        if "drawer" in destination:
            target = drawer_region(destination, last_drawer)
            last_drawer = target
        elif last_drawer and (
            "inside it" in destination or "into it" in destination
            or destination.rstrip(" .") in ("in it", "inside", "in there")
        ):
            target = last_drawer
        else:
            target_hits = mentions(destination)
            reference = locate_body(destination, target_hits)
            if reference is None:
                target = last_target if any(
                    w in destination.split() for w in ("it", "there")
                ) else None
            else:
                side = direction(destination)
                inside = tokens[boundary] in ("in", "into", "inside")
                outside = any(
                    phrase in destination for phrase in
                    ("next to", "beside", "left of", "right of",
                     "in front of", "behind", "back of")
                )
                if side and (
                    outside or "caddy" in reference or "cabinet" in reference
                ):
                    target = api.relative_target(
                        reference, side, "outside" if outside else "inside"
                    )
                elif inside:
                    target = region(reference, ["contain_region"]) or reference
                elif "cabinet" in reference:
                    target = region(reference, ["top_side"])
                elif "stove" in reference:
                    target = region(reference, ["cook_region"]) or reference
                elif "rack" in reference:
                    target = region(reference, ["top_region", "top_side"]) or reference
                else:
                    target = reference
        if target is None or target in items:
            return api.fallback()
        for item in items:
            plan.append(("place", item, target))
        last_items = items
        last_target = target

    for operation, first, second in plan:
        if operation == "drawer":
            api.drawer(first, second)
        else:
            grasp = (
                "rim" if "bowl" in first else
                "thin_edge" if "book" in first else
                "standard"
            )
            api.place_with(first, second, grasp)
