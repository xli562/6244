def run(api):
    import numpy as np

    text = " ".join(api.instruction.lower().replace("-", " ").split()).strip(".")
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug", "cup"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug",
            "mug", "cup"
        ],
        "red coffee mug": ["red mug", "coffee mug", "mug", "cup"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["stove"],
        "black book": ["book"],
        "desk caddy": ["caddy"],
        "cream cheese": ["cream cheese box"],
        "wooden cabinet": ["cabinet"],
        "white cabinet": ["cabinet"],
    }

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        result = [base] + synonyms.get(base, [])
        for word in ("bowl", "plate", "basket", "book", "cabinet", "mug"):
            if word in base.split():
                result.append(word)
        return sorted(set(result), key=len, reverse=True)

    def occurrences(phrase, sentence):
        result = []
        start = 0
        while True:
            i = sentence.find(phrase, start)
            if i < 0:
                break
            end = i + len(phrase)
            if (i == 0 or not sentence[i - 1].isalnum()) and (
                end == len(sentence) or not sentence[end].isalnum()
            ):
                result.append((i, end))
            start = i + 1
        return result

    def mentions(sentence):
        hits = []
        for body in bodies:
            for alias in aliases(body):
                for a, b in occurrences(alias, sentence):
                    hits.append((a, b, body))
        # A specific name suppresses generic aliases at the same location.
        hits = [
            hit for hit in hits
            if not any(
                other[0] <= hit[0] and other[1] >= hit[1]
                and other[1] - other[0] > hit[1] - hit[0]
                for other in hits
            )
        ]
        groups = {}
        for a, b, body in hits:
            groups.setdefault((a, b), [])
            if body not in groups[(a, b)]:
                groups[(a, b)].append(body)
        return [(a, b, groups[(a, b)]) for a, b in sorted(groups)]

    def region(body, suffix):
        exact = body + "_" + suffix
        if exact in names:
            return exact
        return next(
            (n for n in names if n.startswith(body + "_") and n.endswith(suffix)),
            None,
        )

    def choose(candidates, sentence):
        if len(candidates) == 1:
            return candidates[0]
        directions = [
            d for d in ("left", "right", "front", "back")
            if occurrences(d, sentence)
        ]
        for direction in directions:
            markers = [
                n for n in names
                if "region" in n and direction in n.split("_")
                and any(
                    any(w in n.split("_") for w in c.split("_")[:-1])
                    for c in candidates
                )
            ]
            if len(markers) == 1:
                return api.nearest(markers[0], candidates)
        return None

    def drawer_region(sentence, previous=None):
        cabinets = [b for b in bodies if "cabinet" in b]
        explicit = [
            c for _, _, group in mentions(sentence) for c in group
            if c in cabinets
        ]
        cabinet = explicit[0] if explicit else (
            cabinets[0] if len(cabinets) == 1 else None
        )
        level = next(
            (s for s in ("bottom", "middle", "top") if occurrences(s, sentence)),
            None,
        )
        if level is None and previous:
            return previous
        if cabinet and level:
            return region(cabinet, level + "_region")
        return None

    # Split at action verbs, retaining coordinated object lists.
    verbs = {"put", "place", "move", "open", "close", "shut", "turn",
             "push", "pull", "stack", "insert", "pick"}
    words = text.split()
    starts = [i for i, word in enumerate(words) if word.strip(",.") in verbs]
    if not starts:
        return api.fallback()
    clauses = [
        " ".join(words[start:(starts[k + 1] if k + 1 < len(starts) else len(words))])
        .strip(" ,.")
        for k, start in enumerate(starts)
    ]

    # Resolve the whole plan before executing any physical operations.
    plan = []
    last_items = []
    last_target = None
    last_drawer = None
    pending_items = []

    for clause in clauses:
        verb = clause.split()[0]
        if verb in ("turn", "push", "pull"):
            return api.fallback()

        if verb in ("open", "close", "shut"):
            target = drawer_region(clause, last_drawer)
            if target is None:
                return api.fallback()
            plan.append(("drawer", target, "open" if verb == "open" else "close"))
            last_drawer = target
            continue

        hits = mentions(clause)
        if verb == "pick":
            pending_items = []
            for a, b, candidates in hits:
                item = choose(candidates, clause[:b])
                if item is None:
                    return api.fallback()
                if item not in pending_items:
                    pending_items.append(item)
            if not pending_items:
                return api.fallback()
            continue

        # Find the source/destination boundary without changing spatial wording.
        separators = [
            " into ", " inside ", " onto ", " on top of ", " on ",
            " in ", " to ", " next to ", " beside "
        ]
        boundaries = [
            (clause.find(s), s) for s in separators if s in clause
        ]
        if not boundaries:
            return api.fallback()
        boundary, separator = min(boundaries, key=lambda x: (x[0], -len(x[1])))
        source_text = clause[:boundary]
        target_text = clause[boundary + len(separator):]

        items = []
        for a, b, candidates in mentions(source_text):
            item = choose(candidates, source_text[:b])
            if item is None:
                return api.fallback()
            if item not in items:
                items.append(item)
        if not items:
            items = list(pending_items or last_items)
        if not items:
            return api.fallback()

        target = None
        if "drawer" in target_text:
            target = drawer_region(target_text, last_drawer)
            last_drawer = target
        else:
            target_hits = mentions(target_text)
            reference = None
            if target_hits:
                a, b, candidates = target_hits[-1]
                reference = choose(candidates, target_text)
                if reference is None:
                    return api.fallback()

            direction = next(
                (d for d in ("left", "right", "front", "back")
                 if occurrences(d, target_text)),
                None,
            )
            if reference and direction and not (
                "plate" in reference and len(target_hits[-1][2]) > 1
            ):
                outside = (
                    separator in (" next to ", " beside ")
                    or any(s in target_text for s in (
                        "next to", "beside", "of the", "of a", "in front of",
                        "behind"
                    ))
                )
                target = api.relative_target(
                    reference, direction, "outside" if outside else "inside"
                )
            elif reference:
                target = reference
                if "stove" in reference:
                    target = region(reference, "cook_region") or reference
                elif "cabinet" in reference and (
                    "top" in target_text or separator in (" on ", " on top of ")
                ):
                    target = region(reference, "top_side")
                elif separator in (" in ", " into ", " inside ") or (
                    "basket" in reference
                ):
                    target = region(reference, "contain_region") or reference
            elif target_text.strip(" ,.") in (
                "it", "it and", "there", "them", "it then"
            ):
                target = last_target or last_drawer

        if target is None or target in items:
            return api.fallback()
        for item in items:
            plan.append(("place", item, target))
        last_items = items
        last_target = target
        pending_items = []

    if pending_items or not plan:
        return api.fallback()

    for operation, item, target in plan:
        if operation == "drawer":
            api.drawer(item, target)
        else:
            grasp = (
                "rim" if "bowl" in item
                else "thin_edge" if "book" in item
                else "standard"
            )
            result = api.place_with(item, target, grasp)
            if result is False:
                return
