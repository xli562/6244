# Post-hoc retry gate for a frozen household robot program.
# Only uses dict .get, simple conditionals and numeric arithmetic.

TOTAL_MOTION_STEPS = 460      # budget for motion and observation
VERIFY_RESERVE = 40           # held back for final independent release verification
REGRASP_COST = 90             # conservative estimate of one full physical regrasp cycle
SAFETY_MARGIN = 30            # extra slack so a retry can never eat into verification
MAX_CORRECTIONS = 2           # shared per episode, including earlier corrections

XY_FAIL = 0.08                # metres; clearly off target, not a near miss
LIFT_FAIL = 0.01              # metres; object effectively never left the surface


def _num(receipt, key):
    value = receipt.get(key)
    if value is None:
        return None
    return value


def finish(receipt):
    if receipt is None:
        return None

    op = receipt.get("op")
    if op is None:
        return None

    remaining = _num(receipt, "remaining")
    xy_gap = _num(receipt, "xy_gap")
    max_lift = _num(receipt, "max_lift")
    if remaining is None or xy_gap is None or max_lift is None:
        return None

    # Respect the shared correction budget if it is reported.
    used = receipt.get("corrections_used")
    if used is not None and used >= MAX_CORRECTIONS:
        return None

    # Step budget: a retry must fit entirely outside the verification reserve.
    if remaining < 0:
        remaining = 0
    if remaining > TOTAL_MOTION_STEPS + VERIFY_RESERVE:
        remaining = TOTAL_MOTION_STEPS + VERIFY_RESERVE
    usable = remaining - VERIFY_RESERVE
    if usable < REGRASP_COST + SAFETY_MARGIN:
        return None

    # Failure must be unambiguous: both signals have to agree,
    # or one of them has to be far beyond its threshold.
    if xy_gap < 0:
        xy_gap = 0 - xy_gap
    far_off = xy_gap > XY_FAIL
    not_lifted = max_lift < LIFT_FAIL
    very_far_off = xy_gap > 2 * XY_FAIL

    if (far_off and not_lifted) or very_far_off:
        return "regrasp"
    return None


def run(api):
    return finish(api.last())
