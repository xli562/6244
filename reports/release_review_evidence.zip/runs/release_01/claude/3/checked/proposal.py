# Wrapper policy for a frozen household-robot program.
# Uses only dict .get, simple conditionals and numeric arithmetic.

RESERVE = 40               # steps kept for final independent release verification
SWITCH_STEPS = 120         # spare steps needed to justify switching skills
RELEASE_RETRY_STEPS = 80   # spare steps needed to reacquire and seat after a loss
REGRASP_STEPS = 150        # spare steps needed for an extra end-of-episode retry
MAX_CORRECTIONS = 2        # shared per episode: switch, retry_release, regrasp

STATE = {"used": 0, "last": -1}


def num(value, default):
    if value is None:
        return default
    if value != value:  # NaN
        return default
    return value


def mag(value):
    if value < 0:
        return 0 - value
    return value


def reset_episode():
    STATE["used"] = 0
    STATE["last"] = -1


def observe(remaining):
    # A clear jump up in remaining steps means a new episode has started.
    last = STATE.get("last", -1)
    if last >= 0 and remaining > last + 5:
        STATE["used"] = 0
    STATE["last"] = remaining


def can_correct(remaining, needed):
    if STATE.get("used", 0) >= MAX_CORRECTIONS:
        return False
    return remaining - RESERVE >= needed


def spend():
    STATE["used"] = STATE.get("used", 0) + 1


def read_remaining(record):
    raw = record.get("remaining")
    if raw is None or raw != raw:
        return 0
    observe(raw)
    return raw


def grasp_warning(event, remaining):
    if not can_correct(remaining, SWITCH_STEPS):
        return "continue"

    contacts = num(event.get("contacts"), 0)
    lift = num(event.get("lift"), 0)
    motion = mag(num(event.get("object_motion"), 0))
    tilt = mag(num(event.get("axis_change"), 0))
    misses = num(event.get("misses"), 0)
    wide = event.get("wide")
    options = event.get("local_options")

    empty_lift = contacts <= 0 and lift < 0.02
    disturbed = motion > 0.03 or tilt > 0.3
    strongly_disturbed = motion > 0.06 or tilt > 0.5

    switch = False
    if options == False and misses >= 1:
        switch = True        # native offsets exhausted
    elif strongly_disturbed:
        switch = True        # object clearly moving or tipping
    elif misses >= 2 and empty_lift:
        switch = True        # repeated empty lifts
    elif misses >= 2 and disturbed:
        switch = True        # repeated failure while disturbing the object
    elif misses >= 2 and wide and contacts < 2:
        switch = True        # rim grip likely needed
    elif misses >= 3:
        switch = True        # persistent failure

    if switch:
        spend()
        return "switch"
    # First failed lift with another native offset: keep the running skill.
    return "continue"


def settled_release(event, remaining):
    reason = event.get("reason")
    if not (reason == "lost_support" or reason == "drifted"):
        return "continue"

    previous = event.get("previous_support")
    support = event.get("support")
    drift = mag(num(event.get("drift"), 0))
    gap = mag(num(event.get("xy_gap"), 0))

    lost = False
    if previous == True and support == False:
        lost = True
    if reason == "lost_support" and support == False:
        lost = True
    if drift > 0.03:
        lost = True
    if gap > 0.05 and drift > 0.015:
        lost = True

    if lost and can_correct(remaining, RELEASE_RETRY_STEPS):
        spend()
        return "retry_release"
    return "continue"


def decide(event):
    if event is None:
        return "continue"
    phase = event.get("phase")
    remaining = read_remaining(event)
    if phase == "settled_release":
        return settled_release(event, remaining)
    if phase == "grasp" or phase == "carry":
        return grasp_warning(event, remaining)
    # 'release' warnings and unknown phases: do not interrupt; settled check covers loss.
    return "continue"


def finish(receipt):
    if receipt is None:
        reset_episode()
        return None
    if receipt.get("op") is None or receipt.get("remaining") is None:
        reset_episode()
        return None

    remaining = read_remaining(receipt)
    gap = mag(num(receipt.get("xy_gap"), 0))
    max_lift = num(receipt.get("max_lift"), 1)

    # Strongly failed-looking placement only.
    failed = gap >= 0.06 or (max_lift < 0.01 and gap >= 0.03)

    if failed and can_correct(remaining, REGRASP_STEPS):
        spend()
        return "regrasp"
    reset_episode()
    return None


def run(api):
    return finish(api.last())
