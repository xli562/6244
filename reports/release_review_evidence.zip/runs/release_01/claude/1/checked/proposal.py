# Policy wrapper for a frozen household-robot program.
# Uses only dict .get, simple conditionals and numeric arithmetic.

TOTAL_STEPS = 460          # motion + observation budget
RELEASE_RESERVE = 40       # held back for final independent release verification
MAX_CORRECTIONS = 2        # shared per episode, including earlier corrections

# Conservative step-cost estimates for each kind of correction.
REGRASP_COST = 140
RELEASE_RETRY_COST = 80
SWITCH_COST = 120

# Thresholds for placements that clearly look failed (deliberately strict).
FAIL_XY_GAP = 0.08         # m, item clearly off target
FAIL_MIN_LIFT = 0.005      # m, item never really left the surface

# Thresholds for grasp-phase decisions.
MOVE_LIMIT = 0.03          # m, object being pushed or dragged
TILT_LIMIT = 0.2           # axis change, object tipping
DRIFT_LIMIT = 0.03         # m, post-release drift that counts as loss

STATE = {'used': 0}


def corrections_used(record):
    reported = None
    if record is not None:
        reported = record.get('corrections')
    tracked = STATE.get('used', 0)
    if reported is None:
        return tracked
    if reported > tracked:
        return reported
    return tracked


def can_afford(remaining, cost):
    if remaining is None:
        return False
    return remaining - RELEASE_RESERVE >= cost


def spend():
    STATE['used'] = STATE.get('used', 0) + 1


def finish(receipt):
    if receipt is None:
        return None
    xy_gap = receipt.get('xy_gap')
    max_lift = receipt.get('max_lift')
    remaining = receipt.get('remaining')
    if xy_gap is None or max_lift is None or remaining is None:
        return None
    if corrections_used(receipt) >= MAX_CORRECTIONS:
        return None
    failed = False
    if xy_gap > FAIL_XY_GAP:
        failed = True
    if max_lift < FAIL_MIN_LIFT:
        failed = True
    if not failed:
        return None
    if not can_afford(remaining, REGRASP_COST):
        return None
    spend()
    return 'regrasp'


def decide_release(event):
    remaining = event.get('remaining')
    reason = event.get('reason')
    if reason != 'lost_support' and reason != 'drifted':
        return 'continue'
    lost = False
    if event.get('previous_support') and not event.get('support'):
        lost = True
    drift = event.get('drift')
    if drift is not None and drift > DRIFT_LIMIT:
        lost = True
    if not lost:
        return 'continue'
    if corrections_used(event) >= MAX_CORRECTIONS:
        return 'continue'
    if not can_afford(remaining, RELEASE_RETRY_COST):
        return 'continue'
    spend()
    return 'retry_release'


def decide(event):
    if event is None:
        return 'continue'
    phase = event.get('phase')
    if phase == 'settled_release':
        return decide_release(event)

    remaining = event.get('remaining')
    if corrections_used(event) >= MAX_CORRECTIONS:
        return 'continue'
    if not can_afford(remaining, SWITCH_COST):
        return 'continue'

    misses = event.get('misses', 0)
    contacts = event.get('contacts', 0)
    motion = event.get('object_motion', 0.0)
    axis = event.get('axis_change', 0.0)
    options = event.get('local_options')
    wide = event.get('wide')
    if misses is None:
        misses = 0
    if contacts is None:
        contacts = 0
    if motion is None:
        motion = 0.0
    if axis is None:
        axis = 0.0
    if axis < 0:
        axis = 0.0 - axis

    disturbed = motion > MOVE_LIMIT or axis > TILT_LIMIT

    # First failed lift with another native offset: keep the running skill.
    if misses <= 1 and options and not disturbed:
        return 'continue'

    switch = False
    if misses >= 2 and contacts == 0:
        switch = True                      # repeated empty lifts
    if disturbed and misses >= 1:
        switch = True                      # moving or tilting object
    if not options and misses >= 1:
        switch = True                      # native offsets exhausted
    if wide and contacts < 2 and misses >= 2:
        switch = True                      # rim grip likely needed

    if not switch:
        return 'continue'
    spend()
    return 'switch'


def run(api):
    return finish(api.last())
