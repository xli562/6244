# Conservative end-of-episode retry gate for a frozen household robot program.
# Returns 'regrasp' only for a clearly failed-looking placement with ample
# step budget left; otherwise returns None.

RESERVED_VERIFY_STEPS = 40     # held back for final independent release verification
RETRY_COST_STEPS = 120         # conservative budget for one regrasp + place + observe
MOTION_BUDGET_STEPS = 460      # total motion/observation steps per episode

FAIL_XY_GAP = 0.08             # object clearly off target (strong evidence only)
FAIL_MAX_LIFT = 0.01           # object effectively never left the surface
MIN_PLAUSIBLE_LIFT = 0.03      # lift needed before a large gap alone counts as failure


def finish(receipt):
    if receipt is None:
        return None

    op = receipt.get("op")
    remaining = receipt.get("remaining")
    xy_gap = receipt.get("xy_gap")
    max_lift = receipt.get("max_lift")

    # Only act on placement receipts carrying all fields.
    if op is None or remaining is None or xy_gap is None or max_lift is None:
        return None

    # Reject nonsensical values instead of guessing.
    if remaining < 0 or remaining > MOTION_BUDGET_STEPS + RESERVED_VERIFY_STEPS:
        return None
    if xy_gap < 0 or max_lift < 0:
        return None

    # Budget: one full retry must fit without touching the verification reserve.
    if remaining - RESERVED_VERIFY_STEPS < RETRY_COST_STEPS:
        return None

    # Strong failure evidence only.
    never_lifted = max_lift < FAIL_MAX_LIFT
    far_off_after_lift = xy_gap > FAIL_XY_GAP and max_lift >= MIN_PLAUSIBLE_LIFT
    far_off_and_low = xy_gap > FAIL_XY_GAP and max_lift < MIN_PLAUSIBLE_LIFT

    if never_lifted or far_off_after_lift or far_off_and_low:
        if xy_gap > FAIL_XY_GAP or never_lifted:
            return "regrasp"

    return None


def run(api):
    return finish(api.last())
