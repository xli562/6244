# Conservative end-of-episode retry gate for a frozen household robot program.
# finish() requests one extra physical regrasp only when the last placement
# clearly looks failed and enough step budget remains. Otherwise it returns None.

RESERVE_STEPS = 40      # held back for final independent release verification
RETRY_COST = 80         # conservative step estimate for one regrasp attempt
MAX_CORRECTIONS = 2     # shared per-episode cap, including earlier corrections
XY_GAP_FAIL = 0.08      # xy offset clearly beyond a normal placement
MIN_LIFT_OK = 0.02      # below this, the object was likely never lifted


def finish(receipt):
    if receipt is None:
        return None

    op = receipt.get("op")
    remaining = receipt.get("remaining")
    xy_gap = receipt.get("xy_gap")
    max_lift = receipt.get("max_lift")

    # Not a placement receipt, or incomplete: never retry.
    if op is None or remaining is None or xy_gap is None or max_lift is None:
        return None

    # Respect the shared correction cap when the count is reported.
    used = receipt.get("corrections_used")
    if used is not None:
        if not (used + 1 <= MAX_CORRECTIONS):
            return None

    # Budget check. Every comparison is written so NaN or bad values fall
    # through to None.
    if not (remaining - RESERVE_STEPS >= RETRY_COST):
        return None
    if not (xy_gap >= 0):
        return None

    missed_target = xy_gap > XY_GAP_FAIL
    never_lifted = max_lift < MIN_LIFT_OK

    if missed_target or never_lifted:
        return "regrasp"
    return None


def run(api):
    return finish(api.last())
