# Wrapper policy for a frozen household-robot program.
# Uses only dict .get, simple conditionals and numeric arithmetic.
# Does not keep state between calls. Thresholds are conservative so the
# shared episode correction budget (2) and the 40-step release reserve hold.

RELEASE_RESERVE = 40      # steps kept for final independent release verification
SWITCH_COST = 60          # rough cost of adopting the proposed intervention
RETRY_RELEASE_COST = 70   # reacquire and seat after an observed loss
REGRASP_COST = 110        # full extra physical retry at the end

MOTION_LIMIT = 0.03       # m, object pushed or dragged by the attempt
AXIS_LIMIT = 0.35         # object tilting or rotating
DRIFT_LIMIT = 0.03        # m, settled drift relative to release
GAP_LIMIT = 0.04          # m, settled xy gap that counts as misplaced
FINISH_GAP_STRONG = 0.08  # m, gap that alone looks clearly failed
FINISH_LIFT_MIN = 0.005   # m, below this the item was never really lifted


def _num(value, default):
    if value is None:
        return default
    return value


def _flag(value):
    if value:
        return True
    return False


def _affordable(remaining, cost):
    return remaining >= RELEASE_RESERVE + cost


def _decide_settled(event, remaining):
    reason = event.get('reason')
    if reason != 'lost_support' and reason != 'drifted':
        return 'continue'
    previous_support = _flag(event.get('previous_support'))
    support = _flag(event.get('support'))
    drift = _num(event.get('drift'), 0.0)
    xy_gap = _num(event.get('xy_gap'), 0.0)

    lost = previous_support and not support
    moved = drift > DRIFT_LIMIT or xy_gap > GAP_LIMIT
    if reason == 'lost_support' and not support:
        lost = True

    if (lost or moved) and _affordable(remaining, RETRY_RELEASE_COST):
        return 'retry_release'
    return 'continue'


def decide(event):
    if event is None:
        return 'continue'

    phase = event.get('phase')
    remaining = _num(event.get('remaining'), 0)

    if phase == 'settled_release':
        return _decide_settled(event, remaining)

    # Keep the release budget. With too little left, stay with the running skill.
    if not _affordable(remaining, SWITCH_COST):
        return 'continue'

    contacts = _num(event.get('contacts'), 0)
    object_motion = _num(event.get('object_motion'), 0.0)
    axis_change = _num(event.get('axis_change'), 0.0)
    misses = _num(event.get('misses'), 0)
    wide = _flag(event.get('wide'))
    local_options = _flag(event.get('local_options'))

    disturbed = object_motion > MOTION_LIMIT or axis_change > AXIS_LIMIT

    if phase == 'carry':
        # The item is slipping or gone while in transit.
        if contacts == 0 or disturbed:
            return 'switch'
        return 'continue'

    if phase == 'release':
        # Releasing is usually best left to the native skill unless the item is clearly moving.
        if disturbed and contacts < 2:
            return 'switch'
        return 'continue'

    # phase == 'grasp' (or unknown, handled the same conservative way)
    if disturbed:
        return 'switch'

    # First failed lift with another native offset available: continuing is cheaper and safer.
    if misses <= 1 and local_options:
        return 'continue'

    # The native skill has no offsets left after a real failure.
    if misses >= 1 and not local_options:
        return 'switch'

    # Repeated empty lifts.
    if misses >= 2 and contacts == 0:
        return 'switch'

    # A wide object that keeps failing likely needs a rim grip.
    if wide and misses >= 2 and contacts < 2:
        return 'switch'

    return 'continue'


def finish(receipt):
    if receipt is None:
        return None

    xy_gap = receipt.get('xy_gap')
    max_lift = receipt.get('max_lift')
    remaining = receipt.get('remaining')
    if xy_gap is None or max_lift is None or remaining is None:
        return None  # not a placement receipt

    if not _affordable(remaining, REGRASP_COST):
        return None

    clearly_off = xy_gap > FINISH_GAP_STRONG
    never_lifted = max_lift < FINISH_LIFT_MIN and xy_gap > GAP_LIMIT

    if clearly_off or never_lifted:
        return 'regrasp'
    return None


def run(api):
    return finish(api.last())
