def decide(event):
    if event is None:
        return 'continue'

    phase = event.get('phase')
    remaining = event.get('remaining', 0)

    # Missing shared episode accounting blocks additional corrections.
    if event.get('corrections', 2) >= 2:
        return 'continue'

    if phase == 'settled_release':
        if remaining < 120:  # 80 for reseating, 40 for verification.
            return 'continue'
        if event.get('previous_support', False):
            reason = event.get('reason')
            if reason == 'lost_support':
                if event.get('support') == False:
                    return 'retry_release'
            if reason == 'drifted':
                if event.get('drift', 0) > 0.04:
                    return 'retry_release'
        return 'continue'

    if phase == 'grasp':
        if remaining < 160:  # 120 for recovery, 40 for verification.
            return 'continue'

        misses = event.get('misses', 0)
        local_options = event.get('local_options', False)
        contacts = event.get('contacts', 0)
        lift = event.get('lift', 0)
        motion = event.get('object_motion', 0)
        axis_change = event.get('axis_change', False)

        if misses < 1:
            return 'continue'

        if misses == 1:
            if local_options:
                if motion < 0.02:
                    if not axis_change:
                        return 'continue'

        if axis_change:
            return 'switch'
        if motion >= 0.03:
            if lift < 0.02:
                return 'switch'
        if not local_options:
            return 'switch'
        if misses >= 2:
            if contacts == 0:
                if lift < 0.01:
                    return 'switch'
        if misses >= 3:
            if lift < 0.01:
                return 'switch'

        return 'continue'

    if phase == 'carry':
        if remaining >= 160:
            if event.get('default') == 'switch':
                return 'switch'

    return 'continue'


def finish(receipt):
    if receipt is None:
        return None
    if receipt.get('op') != 'place':
        return None
    if receipt.get('corrections', 2) >= 2:
        return None
    if receipt.get('remaining', 0) < 160:
        return None
    if receipt.get('xy_gap', 0) > 0.10:
        return 'regrasp'
    return None


def run(api):
    return finish(api.last())
