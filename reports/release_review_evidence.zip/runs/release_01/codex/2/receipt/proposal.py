def finish(receipt):
    if receipt is None:
        return None
    if receipt.get("op") != "place":
        return None
    if receipt.get("corrections", 2) >= 2:
        return None
    if receipt.get("remaining", 0) < 460 + 40:
        return None
    if receipt.get("xy_gap", 0) > 0:
        if receipt.get("max_lift", 1) == 0:
            return "regrasp"
    return None


def run(api):
    return finish(api.last())
