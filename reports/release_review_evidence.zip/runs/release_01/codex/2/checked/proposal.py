corrections = 0


def decide(event):
    global corrections

    if event is None:
        return 'continue'

    earlier = event.get('corrections', corrections)
    if earlier > corrections:
        corrections = earlier

    phase = event.get('phase')
    remaining = event.get('remaining', 0)

    if phase == 'settled_release':
        reason = event.get('reason')
        lost = False

        if event.get('previous_support', False):
            if reason == 'lost_support':
                if not event.get('support', True):
                    lost = True
            elif reason == 'drifted':
                if event.get('drift', 0) >= 0.04:
                    lost = True

        if lost and corrections < 2 and remaining >= 180:
            corrections = corrections + 1
            return 'retry_release'
        return 'continue'

    if phase == 'grasp':
        if corrections >= 2 or remaining < 140:
            return 'continue'

        misses = event.get('misses', 0)
        contacts = event.get('contacts', 0)
        lift = event.get('lift', 0)
        motion = event.get('object_motion', 0)
        options = event.get('local_options', False)
        tilted = event.get('axis_change', False)

        if misses < 1 or lift >= 0.03:
            return 'continue'

        if misses == 1 and options:
            if not tilted and motion < 0.03:
                return 'continue'

        switch = False
        if not options:
            switch = True
        elif tilted or motion >= 0.04:
            switch = True
        elif misses >= 2 and contacts == 0 and motion < 0.01:
            switch = True
        elif misses >= 3:
            if not event.get('wide', False):
                switch = True

        if switch:
            corrections = corrections + 1
            return 'switch'
        return 'continue'

    if phase == 'release':
        return 'continue'

    if event.get('default', 'continue') == 'switch':
        if corrections < 2 and remaining >= 140:
            corrections = corrections + 1
            return 'switch'

    return 'continue'


def finish(receipt):
    global corrections

    if receipt is None:
        return None

    earlier = receipt.get('corrections', corrections)
    if earlier > corrections:
        corrections = earlier

    op = receipt.get('op')
    if op != 'place' and op != 'placement':
        return None

    if corrections >= 2 or receipt.get('remaining', 0) < 180:
        return None

    gap = receipt.get('xy_gap', 0)
    lift = receipt.get('max_lift', 0)

    if gap >= 0.20 or (gap >= 0.10 and lift < 0.03):
        corrections = corrections + 1
        return 'regrasp'

    return None


def run(api):
    return finish(api.last())
