corrections_used = 0


def decide(event):
    global corrections_used

    if event is None:
        return "continue"

    earlier = event.get("corrections_used", event.get("corrections", 0))
    if earlier > corrections_used:
        corrections_used = earlier

    remaining = event.get("remaining", 0)
    phase = event.get("phase")
    if corrections_used >= 2 or remaining < 160:
        return "continue"

    if phase == "settled_release":
        reason = event.get("reason")
        if reason == "lost_support" or reason == "drifted":
            if event.get("previous_support", False):
                lost = not event.get("support", True)
                drifted = (
                    event.get("drift", 0) >= 0.05
                    and event.get("xy_gap", 0) >= 0.05
                )
                if lost or drifted:
                    corrections_used = corrections_used + 1
                    return "retry_release"
        return "continue"

    if phase == "grasp":
        misses = event.get("misses", 0)
        contacts = event.get("contacts", 0)
        lift = event.get("lift", 0)
        motion = event.get("object_motion", 0)
        tilted = event.get("axis_change", False)
        options = event.get("local_options", False)

        if misses < 1 or lift >= 0.03:
            return "continue"

        if misses == 1 and options and not tilted and motion < 0.03:
            return "continue"

        if event.get("wide", False) and contacts > 0:
            if options and not tilted and motion < 0.03 and misses < 3:
                return "continue"

        if not options or tilted or motion >= 0.03:
            corrections_used = corrections_used + 1
            return "switch"

        if misses >= 2 and contacts == 0 and lift < 0.01:
            corrections_used = corrections_used + 1
            return "switch"

        return "continue"

    if event.get("default", "continue") == "switch":
        corrections_used = corrections_used + 1
        return "switch"

    return "continue"


def finish(receipt):
    global corrections_used

    if receipt is None:
        return None

    earlier = receipt.get("corrections_used", receipt.get("corrections", 0))
    if earlier > corrections_used:
        corrections_used = earlier

    if corrections_used >= 2 or receipt.get("remaining", 0) < 160:
        return None

    op = receipt.get("op")
    if op != "place" and op != "placement":
        return None

    if receipt.get("xy_gap", 0) >= 0.10:
        if receipt.get("max_lift", 0) >= 0.03:
            corrections_used = corrections_used + 1
            return "regrasp"

    return None


def run(api):
    return finish(api.last())
