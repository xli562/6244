def finish(receipt):
    if receipt is None:
        return None
    if receipt.get("op") != "place":
        return None

    # Fail closed when the episode-wide correction count is unavailable.
    if receipt.get("corrections", 2) >= 2:
        return None
    if receipt.get("corrections", 2) < 0:
        return None

    # Allow 460 steps for the retry and preserve 40 for verification.
    if receipt.get("remaining", 0) < 460 + 40:
        return None

    # Conservative failure thresholds, assuming distances are in metres.
    if receipt.get("xy_gap", 0) > 0.10:
        if receipt.get("max_lift", 1) < 0.02:
            return "regrasp"
    return None


def run(api):
    return finish(api.last())
