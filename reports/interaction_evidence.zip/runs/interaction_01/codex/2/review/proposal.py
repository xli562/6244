import numpy as np


def run(api):
    def words(text):
        text = str(text).lower().replace("_", " ").replace("-", " ")
        return "".join(c if c.isalnum() else " " for c in text).split()

    names = list(api.names())
    catalog = api.catalog()
    entities = [
        n for n in names
        if catalog.get(n, {}).get("kind") in ("item", "fixture")
    ]
    regions = [
        n for n in names if catalog.get(n, {}).get("kind") == "region"
    ]
    region_set = set(regions)

    def position(name):
        return np.asarray(api.pos(name), dtype=float).copy()

    def parent(name):
        return catalog.get(name, {}).get("parent")

    def owned(region, owner):
        current, seen = region, set()
        while current and current not in seen:
            seen.add(current)
            current = parent(current)
            if current == owner:
                return True
        return region.startswith(owner + "_")

    def root_body(name):
        seen = set()
        while name in region_set and name not in seen:
            seen.add(name)
            p = parent(name)
            if not p:
                break
            name = p
        return name

    synonyms = {
        "akita black bowl": ["black bowl"],
        "porcelain mug": ["white mug", "porcelain cup"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug",
            "yellow mug", "yellow white mug"
        ],
        "red coffee mug": ["red mug"],
        "chefmate 8 frypan": ["frying pan", "fry pan", "pan"],
        "flat stove": ["stove", "burner"],
        "cream cheese": ["cream cheese box"],
        "moka pot": ["coffee pot", "moka"],
        "desk caddy": ["caddy", "organizer"],
    }
    generic = {
        "bowl", "mug", "cup", "plate", "book", "basket", "caddy",
        "cabinet", "stove", "rack", "bottle", "pan", "pot", "box",
        "table", "tray"
    }
    alias_map = {}
    for name in entities:
        base = words(name)
        if base and base[-1].isdigit():
            base = base[:-1]
        label = " ".join(base)
        aliases = [base]
        aliases.extend(words(a) for a in synonyms.get(label, []))
        aliases.extend([t] for t in base if t in generic)
        if "mug" in base:
            aliases.append(["cup"])
            for a in list(aliases):
                if "mug" in a:
                    aliases.append(["cup" if t == "mug" else t for t in a])
        if "frypan" in base:
            aliases.extend([["pan"], ["frypan"]])
        for alias in aliases:
            if alias:
                alias_map.setdefault(tuple(alias), set()).add(name)

    def mentions(tokens):
        matches = []
        for start in range(len(tokens)):
            for alias, candidates in alias_map.items():
                end = start + len(alias)
                if tuple(tokens[start:end]) == alias:
                    matches.append((start, end, candidates))
        matches.sort(key=lambda m: (-(m[1] - m[0]), m[0]))
        selected = []
        for match in matches:
            if not any(
                match[0] < other[1] and other[0] < match[1]
                for other in selected
            ):
                selected.append(match)
        return sorted(selected, key=lambda m: m[0])

    directions = ("left", "right", "front", "back")
    inside_preps = ("in", "into", "inside")
    fillers = {"the", "a", "an", "and", "then", "both", "all"}
    pronouns = {"it", "them", "these", "those", "there"}

    def choose(candidates, tokens):
        candidates = sorted(candidates)
        if not candidates:
            return None
        if len(candidates) == 1:
            return candidates[0]

        direction = next((t for t in tokens if t in directions), None)
        if direction:
            shared = set(words(candidates[0]))
            for n in candidates[1:]:
                shared &= set(words(n))
            shared = {t for t in shared if not t.isdigit()}
            markers = [
                r for r in regions
                if direction in words(r) and shared & set(words(r))
            ]
            if markers:
                marker = max(
                    markers,
                    key=lambda r: (
                        len(set(words(r)) & set(tokens)),
                        "init" not in words(r)
                    )
                )
                return api.nearest(marker, candidates)

        refs = [
            cs for _, _, cs in mentions(tokens)
            if not (set(cs) & set(candidates)) and len(cs) == 1
        ]
        if refs and any(t in tokens for t in ("near", "beside", "next")):
            reference = next(iter(refs[-1]))
            return min(
                candidates,
                key=lambda n: np.linalg.norm(
                    position(n)[:2] - position(reference)[:2]
                )
            )

        if direction:
            axis = 0 if direction in ("left", "right") else 1
            reverse = direction in ("right", "back")
            return sorted(
                candidates, key=lambda n: position(n)[axis], reverse=reverse
            )[0]
        return candidates[0]

    def mentioned_bodies(tokens):
        result = []
        spans = mentions(tokens)
        for index, (start, end, candidates) in enumerate(spans):
            lo = spans[index - 1][1] if index else 0
            hi = spans[index + 1][0] if index + 1 < len(spans) else len(tokens)
            context = tokens[lo:hi]
            # "Both A and B" must not select every instance of A.
            plural_group = (
                len(spans) == 1 and
                any(t in tokens for t in ("all", "both"))
            )
            selected = (
                sorted(candidates) if plural_group
                else [choose(candidates, context)]
            )
            for name in selected:
                if name and name not in result:
                    result.append(name)
        return result

    def item_mentions(tokens, state):
        selected = [
            n for n in mentioned_bodies(tokens)
            if catalog.get(n, {}).get("kind") == "item"
        ]
        if not selected and pronouns & set(tokens):
            selected = list(state["items"])
        return selected

    def is_drawer(region):
        if region not in region_set:
            return False
        owner = root_body(region)
        rw = words(region)
        return (
            ("cabinet" in words(owner) or "drawer" in rw)
            and any(v in rw for v in ("top", "middle", "bottom", "drawer"))
            and not any(v in rw for v in ("side", "init"))
        )

    def child_region(body, tokens, mode, state):
        children = [
            r for r in regions if owned(r, body) and "init" not in words(r)
        ]
        if "drawer" in tokens:
            level = next(
                (t for t in tokens if t in ("top", "middle", "bottom")), None
            )
            options = [
                r for r in children
                if is_drawer(r) and (level is None or level in words(r))
            ]
            if len(options) == 1:
                return options[0]
            if level is None and state["drawer"] in options:
                return state["drawer"]
            return None

        if mode == "inside":
            options = [
                r for r in children
                if any(t in words(r) for t in ("contain", "inside", "interior"))
            ]
        else:
            options = [
                r for r in children
                if not is_drawer(r)
                and "contain" not in words(r)
                and any(t in words(r) for t in ("side", "cook", "surface", "top"))
            ]
            top_side = [r for r in options if r.endswith("top_side")]
            if top_side:
                return top_side[0]
        if options:
            return max(
                options, key=lambda r: len(set(words(r)) & set(tokens))
            )
        return body

    def resolve_target(tokens, prep, state):
        bodies = mentioned_bodies(tokens)
        body = bodies[-1] if bodies else None
        level = next(
            (t for t in tokens if t in ("top", "middle", "bottom")), None
        )

        if "drawer" in tokens and body is None:
            if state["drawer"]:
                body = root_body(state["drawer"])
            else:
                cabinets = [n for n in entities if "cabinet" in words(n)]
                if len(cabinets) == 1:
                    body = cabinets[0]

        if body is None and pronouns & set(tokens):
            body = state["body"]
            if (
                prep in inside_preps and state["drawer"]
                and "top" not in tokens and level is None
                and not any(t in tokens for t in directions)
            ):
                return state["drawer"], root_body(state["drawer"])

        if body is None:
            content = set(tokens) - fillers - {
                "of", "to", "on", "in", "into", "at"
            }
            exact = [
                r for r in regions
                if content and content <= set(words(r))
                and "init" not in words(r)
            ]
            if len(exact) == 1:
                return exact[0], root_body(exact[0])
            return None, None

        direction = next((t for t in tokens if t in directions), None)
        compartment = any(t in tokens for t in ("compartment", "slot"))
        phrase = " " + " ".join(tokens) + " "
        explicit_outside = (
            "next" in tokens or "beside" in tokens
            or "adjacent" in tokens
            or any(
                s in phrase for s in (
                    " left of ", " right of ", " front of ",
                    " back of ", " behind "
                )
            )
        )
        if "behind" in tokens:
            direction = "back"
        if direction and "drawer" not in tokens:
            inside = (
                compartment or
                (prep in inside_preps and "side" in tokens
                 and not explicit_outside)
            )
            if inside or explicit_outside or (
                "side" in tokens and prep not in inside_preps
            ):
                relation = "inside" if inside else "outside"
                return api.relative_target(body, direction, relation), body

        mode = "inside" if (
            prep in inside_preps or compartment or "drawer" in tokens
        ) else "on"
        return child_region(body, tokens, mode, state), body

    def snapshot(state):
        return {
            "items": list(state["items"]),
            "body": state["body"],
            "target": state["target"],
            "drawer": state["drawer"]
        }

    def fallback():
        api.fallback()

    tokens = words(api.instruction)
    verbs = {
        "put", "place", "move", "insert", "stack", "set",
        "open", "close", "shut", "pick", "take",
        "turn", "switch", "push", "pull", "rotate", "lift"
    }
    starts = [i for i, token in enumerate(tokens) if token in verbs]
    if not starts:
        fallback()
        return

    # Temporal inversions need more interpretation than a left-to-right plan.
    if "before" in tokens or "after" in tokens:
        fallback()
        return

    clauses = [
        tokens[start:starts[i + 1] if i + 1 < len(starts) else len(tokens)]
        for i, start in enumerate(starts)
    ]
    state = {"items": [], "body": None, "target": None, "drawer": None}
    plan = []
    drawer_state = {}
    preps = {
        "in", "into", "inside", "on", "onto", "at",
        "beside", "next", "to", "behind"
    }

    def parse_placement(body_tokens, context):
        for i, token in enumerate(body_tokens):
            if token not in preps:
                continue
            left, right = body_tokens[:i], body_tokens[i + 1:]
            selected = item_mentions(left, context)
            if not selected:
                continue
            target_tokens = (
                [token] + right if token in ("beside", "next", "behind")
                else right
            )
            target, owner = resolve_target(target_tokens, token, context)
            if target and owner not in selected and target not in selected:
                return selected, target, owner, left, target_tokens, token
        return None

    # Validate the entire supported plan before making physical changes.
    try:
        for clause in clauses:
            verb = clause[0]
            body_tokens = list(clause[1:])
            while body_tokens and body_tokens[-1] in ("and", "then", "afterwards"):
                body_tokens.pop()

            if verb in ("turn", "switch", "push", "pull", "rotate", "lift"):
                fallback()
                return

            if verb in ("pick", "take"):
                selected = item_mentions(body_tokens, state)
                if not selected:
                    fallback()
                    return
                state["items"] = selected
                continue

            if verb in ("open", "close", "shut"):
                context = snapshot(state)
                if not mentioned_bodies(body_tokens) and "drawer" not in body_tokens:
                    target = state["drawer"]
                    owner = root_body(target) if target else None
                else:
                    target, owner = resolve_target(body_tokens, "inside", state)
                if not target or not is_drawer(target):
                    fallback()
                    return
                op = "open" if verb == "open" else "close"
                plan.append({"op": op, "target": target})
                drawer_state[target] = op
                state.update(target=target, body=owner, drawer=target)
                continue

            # Expand "put A on B and C on D", while retaining shared targets.
            groups = []
            pending = body_tokens
            while True:
                cut = None
                for i, token in enumerate(pending):
                    if token != "and":
                        continue
                    first = parse_placement(pending[:i], state)
                    second = parse_placement(pending[i + 1:], state)
                    if first and second:
                        cut = i
                        break
                if cut is None:
                    groups.append(pending)
                    break
                groups.append(pending[:cut])
                pending = pending[cut + 1:]

            for group in groups:
                context = snapshot(state)
                parsed = parse_placement(group, context)
                if parsed is None:
                    fallback()
                    return
                selected, target, owner, source_tokens, target_tokens, prep = parsed
                if is_drawer(target):
                    if drawer_state.get(target) != "open":
                        plan.append({"op": "open", "target": target})
                        drawer_state[target] = "open"
                    state["drawer"] = target

                plan.append({
                    "op": "placements",
                    "items": selected,
                    "source_tokens": source_tokens,
                    "target_tokens": target_tokens,
                    "prep": prep,
                    "context": context,
                    "target": target
                })
                state.update(items=selected, target=target, body=owner)
    except (ValueError, TypeError, KeyError):
        fallback()
        return

    if not plan:
        fallback()
        return

    def finite_number(value):
        try:
            return value is not None and bool(np.isfinite(float(value)))
        except (ValueError, TypeError):
            return False

    def placement_plausible(step, receipt):
        p, q = position(step["item"]), position(step["target"])
        if not np.all(np.isfinite(p)) or not np.all(np.isfinite(q)):
            return False
        # Recompute from live positions: receipt gaps may precede settling.
        gap = float(np.linalg.norm(p[:2] - q[:2]))
        tw = words(step["target"])
        tolerance = 0.06
        if "basket" in tw:
            tolerance = 0.085
        elif "caddy" in tw:
            tolerance = 0.045
        plausible = gap < tolerance and -0.065 < p[2] - q[2] < 0.19
        if not plausible:
            return False
        # Geometry is a stopping heuristic, never an official success signal.
        lift = receipt.get("max_lift")
        before = receipt.get("before_xyz")
        if finite_number(lift) and float(lift) < 0.008 and before is not None:
            before = np.asarray(before, dtype=float)
            if before.shape == (3,) and np.linalg.norm(p - before) < 0.008:
                return False
        return True

    def cost(entry):
        return 65 * len(entry["items"]) if entry["op"] == "placements" else 40

    def place(item, target, reserve):
        iw = words(item)
        grasp = (
            "rim" if "bowl" in iw else
            "thin_edge" if "book" in iw else "standard"
        )
        step = {"op": "place", "item": item, "target": target, "grasp": grasp}
        before = position(item)
        receipt = api.attempt(step)
        if placement_plausible(step, receipt):
            return True

        used = receipt.get("steps_used")
        retry_cost = max(65, int(used)) if finite_number(used) else 100
        lift = receipt.get("max_lift")
        after = position(item)
        hand = np.asarray(api.eef(), dtype=float)
        held = (
            finite_number(lift) and float(lift) > 0.025
            and after[2] > before[2] + 0.025
            and np.linalg.norm(after - hand) < 0.085
        )

        if held and api.remaining() > reserve + 55:
            # Verify that the object follows the fingers before carrying it.
            api.attempt({
                "op": "move", "xyz": (hand + [0, 0, 0.025]).tolist(),
                "steps": 6, "watch": item
            })
            lifted = position(item)
            new_hand = np.asarray(api.eef(), dtype=float)
            follows = (
                lifted[2] - after[2] > 0.008
                and np.linalg.norm((lifted - after) - (new_hand - hand)) < 0.025
            )
            if follows:
                offset = lifted - new_hand
                destination = position(target)
                for height, count in ((0.16, 14), (0.045, 12)):
                    api.attempt({
                        "op": "move",
                        "xyz": (destination - offset + [0, 0, height]).tolist(),
                        "steps": count, "watch": item
                    })
                api.attempt({"op": "grip", "closed": False, "watch": item})
                api.attempt({
                    "op": "move",
                    "xyz": (np.asarray(api.eef()) + [0, 0, 0.10]).tolist(),
                    "steps": 8, "watch": item
                })
                if placement_plausible(step, {}):
                    return True

        if api.remaining() <= reserve + retry_cost:
            return False
        receipt = api.attempt(step)
        return placement_plausible(step, receipt)

    acted = False
    for index, entry in enumerate(plan):
        if api.remaining() <= 0:
            return
        try:
            if entry["op"] != "placements":
                acted = True
                receipt = api.attempt(entry)
                # A stationary drawer can already be at the requested limit;
                # displacement alone cannot establish its absolute state.
                continue

            # Resolve location markers again after earlier objects/drawers move.
            context = entry["context"]
            target, owner = resolve_target(
                entry["target_tokens"], entry["prep"], context
            )
            items = item_mentions(entry["source_tokens"], context)
            if not target or not items or owner in items:
                return

            reserve = sum(cost(future) for future in plan[index + 1:])
            for item_index, item in enumerate(items):
                if api.remaining() <= 0:
                    return
                item_reserve = reserve + 65 * (len(items) - item_index - 1)
                acted = True
                if not place(item, target, item_reserve):
                    return
        except (ValueError, TypeError, KeyError):
            if not acted:
                fallback()
            return
