import numpy as np


def run(api):
    def words(text):
        text = str(text).lower().replace("-", " ").replace("_", " ")
        return "".join(c if c.isalnum() else " " for c in text).split()

    names = list(api.names())
    catalog = api.catalog()
    entities = [
        n for n in names
        if catalog.get(n, {}).get("kind") in ("item", "fixture")
    ]
    regions = [
        n for n in names if catalog.get(n, {}).get("kind") == "region"
    ]

    def pos(name):
        return np.asarray(api.pos(name), dtype=float).copy()

    def parent(name):
        return catalog.get(name, {}).get("parent")

    def owned(region, owner):
        current, seen = region, set()
        while current and current not in seen:
            seen.add(current)
            current = parent(current)
            if current == owner:
                return True
        return region.startswith(owner + "_")

    def root(name):
        seen = set()
        while name in regions and name not in seen:
            seen.add(name)
            p = parent(name)
            if not p:
                break
            name = p
        return name

    synonyms = {
        "akita black bowl": ["black bowl"],
        "porcelain mug": ["white mug", "porcelain cup"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug"
        ],
        "red coffee mug": ["red mug"],
        "chefmate 8 frypan": ["frying pan", "fry pan", "pan"],
        "flat stove": ["stove", "burner"],
        "cream cheese": ["cream cheese box"],
        "moka pot": ["coffee pot", "moka"],
        "desk caddy": ["caddy", "organizer"],
    }
    generic = {
        "bowl", "mug", "cup", "plate", "book", "basket", "caddy",
        "cabinet", "stove", "rack", "bottle", "pan", "pot", "box",
        "table", "tray"
    }
    alias_map = {}
    for name in entities:
        base = words(name)
        if base and base[-1].isdigit():
            base = base[:-1]
        aliases = [base]
        aliases.extend(words(a) for a in synonyms.get(" ".join(base), []))
        aliases.extend([t] for t in base if t in generic)
        if "mug" in base:
            aliases.append(["cup"])
        if "frypan" in base:
            aliases.extend([["pan"], ["frypan"]])
        for alias in aliases:
            if alias:
                alias_map.setdefault(tuple(alias), set()).add(name)

    def mentions(tokens):
        matches = []
        for start in range(len(tokens)):
            for alias, candidates in alias_map.items():
                end = start + len(alias)
                if tuple(tokens[start:end]) == alias:
                    matches.append((start, end, candidates))
        matches.sort(key=lambda m: (-(m[1] - m[0]), m[0]))
        selected = []
        for match in matches:
            if not any(
                match[0] < other[1] and other[0] < match[1]
                for other in selected
            ):
                selected.append(match)
        return sorted(selected, key=lambda m: m[0])

    directions = ("left", "right", "front", "back")

    def choose(candidates, tokens):
        candidates = sorted(candidates)
        if not candidates:
            return None
        if len(candidates) == 1:
            return candidates[0]
        direction = next((d for d in directions if d in tokens), None)
        if direction:
            shared = set(words(candidates[0]))
            for n in candidates[1:]:
                shared &= set(words(n))
            shared = {w for w in shared if not w.isdigit()}
            markers = [
                r for r in regions
                if direction in words(r) and shared & set(words(r))
            ]
            if markers:
                marker = max(
                    markers,
                    key=lambda r: len(set(words(r)) & set(tokens))
                )
                return api.nearest(marker, candidates)

        refs = [
            cs for _, _, cs in mentions(tokens)
            if not (set(cs) & set(candidates)) and len(cs) == 1
        ]
        if refs and any(t in tokens for t in ("near", "beside", "next")):
            reference = next(iter(refs[-1]))
            return min(
                candidates,
                key=lambda n: np.linalg.norm(pos(n)[:2] - pos(reference)[:2])
            )
        if direction:
            axis = 0 if direction in ("left", "right") else 1
            return sorted(
                candidates,
                key=lambda n: pos(n)[axis],
                reverse=direction in ("right", "back")
            )[0]
        return candidates[0]

    def mentioned_bodies(tokens):
        result = []
        spans = mentions(tokens)
        for index, (start, end, candidates) in enumerate(spans):
            lo = spans[index - 1][1] if index else 0
            hi = spans[index + 1][0] if index + 1 < len(spans) else len(tokens)
            context = tokens[lo:hi]
            if "all" in context or "both" in context:
                selected = sorted(candidates)
            else:
                selected = [choose(candidates, context)]
            for n in selected:
                if n and n not in result:
                    result.append(n)
        return result

    def child_region(body, tokens, mode):
        children = [r for r in regions if owned(r, body)]
        if not children:
            return body
        if "drawer" in tokens:
            level = next(
                (v for v in ("top", "middle", "bottom") if v in tokens), None
            )
            options = [
                r for r in children
                if "side" not in words(r)
                and "init" not in words(r)
                and (level in words(r) if level else
                     any(v in words(r) for v in ("top", "middle", "bottom")))
            ]
            return options[0] if len(options) == 1 else None

        if mode == "inside":
            options = [
                r for r in children
                if any(v in words(r) for v in ("contain", "inside", "interior"))
                and "init" not in words(r)
            ]
        else:
            options = [
                r for r in children
                if "init" not in words(r) and "contain" not in words(r)
                and any(v in words(r) for v in ("side", "cook", "surface", "top"))
            ]
            top_side = [r for r in options if r.endswith("top_side")]
            if top_side:
                return top_side[0]
        if options:
            return max(options, key=lambda r: len(set(words(r)) & set(tokens)))
        return body

    state = {"items": [], "target": None, "body": None, "drawer": None}

    def resolve_target(tokens, prep=None):
        bodies = mentioned_bodies(tokens)
        body = bodies[-1] if bodies else None
        if "drawer" in tokens and body is None:
            if state["drawer"]:
                body = root(state["drawer"])
            else:
                cabinets = [n for n in entities if "cabinet" in words(n)]
                if len(cabinets) == 1:
                    body = cabinets[0]

        if body is None and any(t in tokens for t in ("it", "there", "them")):
            body = state["body"]
            if "drawer" not in tokens and "top" not in tokens:
                if prep in ("in", "into", "inside") and state["drawer"]:
                    drawer = state["drawer"]
                    if body == root(drawer):
                        return drawer, root(drawer)

        if body is None:
            content = set(tokens) - {
                "the", "a", "an", "of", "to", "on", "in", "into", "at"
            }
            scored = [
                r for r in regions
                if content and content <= set(words(r)) and "init" not in words(r)
            ]
            if len(scored) == 1:
                return scored[0], root(scored[0])
            return None, None

        direction = next((d for d in directions if d in tokens), None)
        compartment = "compartment" in tokens or "slot" in tokens
        outside = (
            "next" in tokens or "beside" in tokens
            or ("side" in tokens and not compartment
                and prep not in ("in", "into", "inside"))
            or (direction is not None and
                ("of" in tokens or "to" in tokens) and
                not compartment and "drawer" not in tokens)
        )
        if direction and (outside or compartment):
            return api.relative_target(
                body, direction, "outside" if outside else "inside"
            ), body

        mode = "inside" if (
            prep in ("in", "into", "inside") or compartment or "drawer" in tokens
        ) else "on"
        return child_region(body, tokens, mode), body

    def is_drawer(region):
        return (
            region in regions
            and "cabinet" in words(root(region))
            and any(v in words(region) for v in ("top", "middle", "bottom"))
            and "side" not in words(region)
        )

    def fallback():
        api.fallback()

    tokens = words(api.instruction)
    # Temporal inversion and negation need more than sequential clause splitting.
    if any(t in tokens for t in ("before", "after", "until", "unless", "not")):
        fallback()
        return

    verbs = {
        "put", "place", "move", "insert", "stack", "set",
        "open", "close", "shut", "pick", "take",
        "turn", "switch", "push", "pull", "rotate", "lift"
    }
    starts = [i for i, token in enumerate(tokens) if token in verbs]
    if not starts:
        fallback()
        return
    clauses = [
        tokens[start:starts[i + 1] if i + 1 < len(starts) else len(tokens)]
        for i, start in enumerate(starts)
    ]
    plan, drawer_state = [], {}

    # Resolve the entire instruction before making physical changes.
    try:
        for clause in clauses:
            verb = clause[0]
            text = clause[1:]
            while text and text[-1] in ("and", "then", "afterwards"):
                text.pop()

            if verb in ("turn", "switch"):
                bodies = mentioned_bodies(text)
                body = bodies[-1] if bodies else state["body"]
                setting = next((t for t in text if t in ("on", "off")), None)
                if not body or "stove" not in words(body) or setting is None:
                    fallback()
                    return
                plan.append({"op": "stove", "target": body, "on": setting == "on"})
                state.update(body=body, target=child_region(body, [], "on"))
                continue

            if verb in ("push", "pull", "rotate", "lift"):
                fallback()
                return

            if verb in ("pick", "take"):
                selected = [
                    n for n in mentioned_bodies(text)
                    if catalog.get(n, {}).get("kind") == "item"
                ]
                if not selected and any(t in text for t in ("it", "them")):
                    selected = list(state["items"])
                if not selected:
                    fallback()
                    return
                state["items"] = selected
                continue

            if verb in ("open", "close", "shut"):
                if not mentioned_bodies(text) and "drawer" not in text:
                    target = state["drawer"]
                    owner = root(target) if target else None
                else:
                    target, owner = resolve_target(text, "inside")
                if not target or not is_drawer(target):
                    fallback()
                    return
                op = "open" if verb == "open" else "close"
                plan.append({"op": op, "target": target})
                drawer_state[target] = op
                state.update(target=target, body=owner, drawer=target)
                continue

            split = None
            for i, token in enumerate(text):
                if token not in (
                    "in", "into", "inside", "on", "onto", "at", "beside", "next", "to"
                ):
                    continue
                left, right = text[:i], text[i + 1:]
                selected = [
                    n for n in mentioned_bodies(left)
                    if catalog.get(n, {}).get("kind") == "item"
                ]
                if not selected and any(
                    t in left for t in ("it", "them", "these", "those")
                ):
                    selected = list(state["items"])
                if not selected:
                    continue
                target_text = [token] + right if token in ("beside", "next") else right
                target, owner = resolve_target(target_text, token)
                if target and target not in selected and owner not in selected:
                    split = selected, target, owner
                    break

            if split is None:
                fallback()
                return
            selected, target, owner = split
            if is_drawer(target):
                if drawer_state.get(target) != "open":
                    plan.append({"op": "open", "target": target})
                    drawer_state[target] = "open"
                state["drawer"] = target

            for item in selected:
                iw = words(item)
                grasp = (
                    "rim" if "bowl" in iw else
                    "thin_edge" if "book" in iw else "standard"
                )
                plan.append({
                    "op": "place", "item": item, "target": target, "grasp": grasp
                })
            state.update(items=selected, target=target, body=owner)
    except (ValueError, TypeError, KeyError):
        fallback()
        return

    if not plan:
        fallback()
        return

    def finite(value):
        return value is not None and np.isfinite(float(value))

    def plausible(step):
        p, q = pos(step["item"]), pos(step["target"])
        target_words = words(step["target"])
        tolerance = 0.06
        if "basket" in target_words:
            tolerance = 0.085
        elif "caddy" in target_words:
            tolerance = 0.045
        # Geometric evidence only; official termination is controlled by the API.
        return (
            np.linalg.norm(p[:2] - q[:2]) < tolerance
            and -0.065 < p[2] - q[2] < 0.19
        )

    def move(point, steps, watch):
        return api.attempt({
            "op": "move", "xyz": np.asarray(point, float).tolist(),
            "steps": steps, "watch": watch
        })

    def grip(closed, watch):
        return api.attempt({"op": "grip", "closed": closed, "watch": watch})

    def operate_stove(step):
        stove = step["target"]
        controls = [
            n for n in names
            if any(w in words(n) for w in ("switch", "knob", "button"))
            and owned(n, stove)
        ]
        if not controls:
            candidates = [
                n for n in names
                if any(w in words(n) for w in ("switch", "knob", "button"))
            ]
            controls = sorted(
                candidates, key=lambda n: np.linalg.norm(pos(n) - pos(stove))
            )
        center = pos(controls[0]) if controls else pos(stove) + [0, -0.105, 0.025]
        grip(False, stove)
        move(center + [0, 0, 0.09], 12, stove)
        move(center, 14, stove)
        grip(True, stove)
        api.action(
            [0, 0, 0, 0, 0, 1.0 if step["on"] else -1.0, 1], steps=18
        )
        grip(False, stove)
        move(np.asarray(api.eef(), float) + [0, 0, 0.12], 10, stove)

    for index, step in enumerate(plan):
        if api.remaining() <= 0:
            return
        if step["op"] == "stove":
            operate_stove(step)
            continue

        before = pos(step["item"]) if step["op"] == "place" else None
        try:
            receipt = api.attempt(step)
        except (ValueError, TypeError):
            if index == 0:
                fallback()
            return

        if step["op"] != "place":
            # Drawer displacement alone cannot establish its absolute joint state.
            continue
        if plausible(step):
            continue

        reserve = sum(
            130 if future["op"] == "place" else
            65 if future["op"] == "stove" else 150
            for future in plan[index + 1:]
        )
        used = receipt.get("steps_used")
        retry_cost = max(90, int(used)) if finite(used) else 140
        lift = receipt.get("max_lift")
        after = pos(step["item"])
        hand = np.asarray(api.eef(), dtype=float)
        held = (
            finite(lift) and float(lift) > 0.025
            and after[2] > before[2] + 0.025
            and np.linalg.norm(after - hand) < 0.085
        )

        if held and api.remaining() > reserve + 60:
            # Verify that the object follows the hand before completing transport.
            probe_before = pos(step["item"])
            move(hand + [0, 0, 0.025], 6, step["item"])
            probe_after = pos(step["item"])
            probe_hand = np.asarray(api.eef(), dtype=float)
            follows = (
                probe_after[2] - probe_before[2] > 0.008
                and np.linalg.norm(probe_after - probe_hand) < 0.085
            )
            if follows:
                offset = probe_after - probe_hand
                destination = pos(step["target"])
                move(destination - offset + [0, 0, 0.16], 14, step["item"])
                move(destination - offset + [0, 0, 0.045], 12, step["item"])
                grip(False, step["item"])
                move(
                    np.asarray(api.eef(), float) + [0, 0, 0.10],
                    8, step["item"]
                )
                if plausible(step):
                    continue

        if api.remaining() <= reserve + retry_cost:
            return
        try:
            receipt = api.attempt(step)
        except (ValueError, TypeError):
            return
        if not plausible(step):
            return
