import numpy as np


def run(api):
    def words(text):
        text = str(text).lower().replace("-", " ").replace("_", " ")
        return "".join(c if c.isalnum() else " " for c in text).split()

    names = list(api.names())
    catalog = api.catalog()
    entities = [
        n for n in names
        if catalog.get(n, {}).get("kind") in ("item", "fixture")
    ]
    regions = [
        n for n in names if catalog.get(n, {}).get("kind") == "region"
    ]

    def position(name):
        return np.asarray(api.pos(name), dtype=float).copy()

    def parent(name):
        return catalog.get(name, {}).get("parent")

    def owned(region, owner):
        current, seen = region, set()
        while current and current not in seen:
            seen.add(current)
            current = parent(current)
            if current == owner:
                return True
        return region.startswith(owner + "_")

    def root_body(name):
        seen = set()
        while name in regions and name not in seen:
            seen.add(name)
            p = parent(name)
            if not p:
                break
            name = p
        return name

    # These are vocabulary aliases, independent of tasks and scene identities.
    synonyms = {
        "akita black bowl": ["black bowl"],
        "porcelain mug": ["white mug", "porcelain cup"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug"
        ],
        "red coffee mug": ["red mug"],
        "chefmate 8 frypan": ["frying pan", "fry pan", "pan"],
        "flat stove": ["stove", "burner"],
        "cream cheese": ["cream cheese box"],
        "moka pot": ["coffee pot", "moka"],
        "desk caddy": ["caddy", "organizer"],
    }
    generic = {
        "bowl", "mug", "cup", "plate", "book", "basket", "caddy",
        "cabinet", "stove", "rack", "bottle", "pan", "pot", "box",
        "table", "tray"
    }
    alias_map = {}
    for name in entities:
        base = words(name)
        if base and base[-1].isdigit():
            base = base[:-1]
        label = " ".join(base)
        aliases = [base]
        aliases.extend(words(a) for a in synonyms.get(label, []))
        for token in base:
            if token in generic:
                aliases.append([token])
        if "mug" in base:
            aliases.append(["cup"])
        if "frypan" in base:
            aliases.extend([["pan"], ["frypan"]])
        for alias in aliases:
            if alias:
                alias_map.setdefault(tuple(alias), set()).add(name)

    def mentions(tokens):
        matches = []
        for start in range(len(tokens)):
            for alias, candidates in alias_map.items():
                end = start + len(alias)
                if tuple(tokens[start:end]) == alias:
                    matches.append((start, end, candidates))
        # A complete color/product phrase wins over its generic suffix.
        matches.sort(key=lambda m: (-(m[1] - m[0]), m[0]))
        selected = []
        for match in matches:
            if not any(
                match[0] < other[1] and other[0] < match[1]
                for other in selected
            ):
                selected.append(match)
        return sorted(selected, key=lambda m: m[0])

    directions = ("left", "right", "front", "back")

    def choose(candidates, tokens):
        candidates = sorted(candidates)
        if not candidates:
            return None
        if len(candidates) == 1:
            return candidates[0]

        direction = next((d for d in directions if d in tokens), None)
        if direction:
            shared = set(words(candidates[0]))
            for n in candidates[1:]:
                shared &= set(words(n))
            shared -= {"1", "2", "3", "4", "5"}
            markers = []
            for r in regions:
                rw = set(words(r))
                if direction in rw and shared & rw:
                    markers.append(r)
            if markers:
                marker = max(
                    markers,
                    key=lambda r: len(set(words(r)) & set(tokens))
                )
                return api.nearest(marker, candidates)

        # Location descriptions can identify otherwise identical objects.
        refs = [
            (a, b, cs) for a, b, cs in mentions(tokens)
            if not (set(cs) & set(candidates)) and len(cs) == 1
        ]
        if refs and any(t in tokens for t in ("near", "beside", "next")):
            reference = next(iter(refs[-1][2]))
            return min(
                candidates,
                key=lambda n: np.linalg.norm(
                    position(n)[:2] - position(reference)[:2]
                )
            )

        # For unresolved left/right/front/back descriptions use live geometry.
        if direction:
            axis = 0 if direction in ("left", "right") else 1
            reverse = direction in ("right", "back")
            return sorted(
                candidates, key=lambda n: position(n)[axis], reverse=reverse
            )[0]
        return candidates[0]

    def mentioned_bodies(tokens):
        result = []
        spans = mentions(tokens)
        for index, (start, end, candidates) in enumerate(spans):
            lo = spans[index - 1][1] if index else 0
            hi = spans[index + 1][0] if index + 1 < len(spans) else len(tokens)
            context = tokens[lo:hi]
            if "all" in context or "both" in context:
                selected = sorted(candidates)
            else:
                selected = [choose(candidates, context)]
            for n in selected:
                if n and n not in result:
                    result.append(n)
        return result

    def child_region(body, tokens, mode):
        children = [r for r in regions if owned(r, body)]
        if not children:
            return body

        if "drawer" in tokens:
            level = next(
                (v for v in ("top", "middle", "bottom") if v in tokens), None
            )
            options = [
                r for r in children
                if "side" not in words(r)
                and (level in words(r) if level else
                     any(v in words(r) for v in ("top", "middle", "bottom")))
            ]
            if len(options) == 1:
                return options[0]
            if level:
                return None
            return None

        if mode == "inside":
            options = [
                r for r in children
                if any(v in words(r) for v in ("contain", "inside", "interior"))
                and "init" not in words(r)
            ]
        else:
            options = [
                r for r in children
                if "init" not in words(r)
                and ("side" in words(r) or "cook" in words(r)
                     or "surface" in words(r) or "top" in words(r))
                and "contain" not in words(r)
            ]
            top_side = [r for r in options if r.endswith("top_side")]
            if top_side:
                return top_side[0]

        if options:
            return max(
                options, key=lambda r: len(set(words(r)) & set(tokens))
            )
        return body

    state = {
        "items": [], "target": None, "body": None, "drawer": None
    }

    def resolve_target(tokens, prep=None):
        bodies = mentioned_bodies(tokens)
        body = bodies[-1] if bodies else None

        if "drawer" in tokens and body is None:
            if state["drawer"]:
                body = root_body(state["drawer"])
            else:
                cabinets = [n for n in entities if "cabinet" in words(n)]
                if len(cabinets) == 1:
                    body = cabinets[0]

        if body is None and any(t in tokens for t in ("it", "there", "them")):
            body = state["body"]
            if "drawer" not in tokens and "top" not in tokens:
                if prep in ("in", "into", "inside") and state["drawer"]:
                    return state["drawer"], root_body(state["drawer"])

        if body is None:
            # Directly named regions that do not require a body reference.
            scored = []
            content = set(tokens) - {
                "the", "a", "an", "of", "to", "on", "in", "into", "at"
            }
            for r in regions:
                rw = set(words(r))
                if content and content <= rw and "init" not in rw:
                    scored.append(r)
            if len(scored) == 1:
                return scored[0], root_body(scored[0])
            return None, None

        direction = next((d for d in directions if d in tokens), None)
        outside = (
            "next" in tokens or "beside" in tokens
            or ("side" in tokens and "compartment" not in tokens
                and prep not in ("in", "into", "inside"))
            or (direction is not None and
                ("of" in tokens or "to" in tokens) and
                "compartment" not in tokens and "drawer" not in tokens)
        )
        compartment = "compartment" in tokens or "slot" in tokens
        if direction and (outside or compartment):
            relation = "outside" if outside else "inside"
            return api.relative_target(body, direction, relation), body

        mode = "inside" if (
            prep in ("in", "into", "inside") or compartment
            or "drawer" in tokens
        ) else "on"
        return child_region(body, tokens, mode), body

    def is_drawer(region):
        if region not in regions:
            return False
        owner = root_body(region)
        return (
            "cabinet" in words(owner)
            and any(v in words(region) for v in ("top", "middle", "bottom"))
            and "side" not in words(region)
        )

    def fallback():
        api.fallback()

    tokens = words(api.instruction)
    verbs = {
        "put", "place", "move", "insert", "stack", "set",
        "open", "close", "shut", "pick", "take",
        "turn", "switch", "push", "pull", "rotate", "lift"
    }
    starts = [i for i, token in enumerate(tokens) if token in verbs]
    if not starts:
        fallback()
        return

    clauses = [
        tokens[start:starts[i + 1] if i + 1 < len(starts) else len(tokens)]
        for i, start in enumerate(starts)
    ]
    plan = []
    drawer_state = {}

    # Compile everything before acting, so unsupported language can fall back
    # without replaying a partially executed sequence.
    try:
        for clause in clauses:
            verb = clause[0]
            body_tokens = clause[1:]
            while body_tokens and body_tokens[-1] in ("and", "then", "afterwards"):
                body_tokens.pop()

            if verb in ("turn", "switch", "push", "pull", "rotate", "lift"):
                fallback()
                return

            if verb in ("pick", "take"):
                selected = mentioned_bodies(body_tokens)
                selected = [
                    n for n in selected
                    if catalog.get(n, {}).get("kind") == "item"
                ]
                if not selected:
                    fallback()
                    return
                state["items"] = selected
                continue

            if verb in ("open", "close", "shut"):
                if not mentioned_bodies(body_tokens) and "drawer" not in body_tokens:
                    target = state["drawer"]
                    owner = root_body(target) if target else None
                else:
                    target, owner = resolve_target(body_tokens, "inside")
                if not target or not is_drawer(target):
                    fallback()
                    return
                op = "open" if verb == "open" else "close"
                plan.append({"op": op, "target": target})
                drawer_state[target] = op
                state.update(target=target, body=owner, drawer=target)
                continue

            split = None
            for i, token in enumerate(body_tokens):
                if token in ("in", "into", "inside", "on", "onto", "at",
                             "beside", "next", "to"):
                    left = body_tokens[:i]
                    right = body_tokens[i + 1:]
                    selected = mentioned_bodies(left)
                    selected = [
                        n for n in selected
                        if catalog.get(n, {}).get("kind") == "item"
                    ]
                    if not selected and any(
                        t in left for t in ("it", "them", "these", "those")
                    ):
                        selected = list(state["items"])
                    if not selected:
                        continue
                    target_tokens = (
                        [token] + right if token in ("beside", "next") else right
                    )
                    target, owner = resolve_target(target_tokens, token)
                    if target and target not in selected:
                        split = selected, target, owner
                        break

            if split is None:
                fallback()
                return

            selected, target, owner = split
            if is_drawer(target):
                if drawer_state.get(target) != "open":
                    plan.append({"op": "open", "target": target})
                    drawer_state[target] = "open"
                state["drawer"] = target

            for item in selected:
                iw = words(item)
                grasp = (
                    "rim" if "bowl" in iw else
                    "thin_edge" if "book" in iw else "standard"
                )
                plan.append({
                    "op": "place", "item": item,
                    "target": target, "grasp": grasp
                })
            state.update(items=selected, target=target, body=owner)
    except (ValueError, TypeError, KeyError):
        fallback()
        return

    if not plan:
        fallback()
        return

    def finite_number(value):
        return value is not None and np.isfinite(float(value))

    def placement_plausible(step, receipt):
        p = position(step["item"])
        q = position(step["target"])
        gap = receipt.get("xy_gap")
        if not finite_number(gap):
            gap = float(np.linalg.norm(p[:2] - q[:2]))
        target_words = words(step["target"])
        tolerance = 0.06
        if "basket" in target_words:
            tolerance = 0.085
        elif "caddy" in target_words:
            tolerance = 0.045
        # This is only a geometric stopping heuristic, not a success flag.
        return float(gap) < tolerance and -0.065 < p[2] - q[2] < 0.19

    for index, step in enumerate(plan):
        if api.remaining() <= 0:
            return
        before = position(step["item"]) if step["op"] == "place" else None
        try:
            receipt = api.attempt(step)
        except (ValueError, TypeError):
            if index == 0:
                fallback()
            return

        if step["op"] != "place":
            # Drawer skills perform their own physical handle acquisition.
            # A small displacement can also mean it was already open/closed.
            continue

        if placement_plausible(step, receipt):
            continue

        remaining_jobs = plan[index + 1:]
        reserve = sum(
            65 if future["op"] == "place" else 40
            for future in remaining_jobs
        )
        used = receipt.get("steps_used")
        retry_cost = max(65, int(used)) if finite_number(used) else 100
        lift = receipt.get("max_lift")
        after = position(step["item"])
        hand = np.asarray(api.eef(), dtype=float)

        # If the fingers still hold the lifted item, finish the transport
        # without spending another complete grasp cycle.
        held = (
            finite_number(lift) and float(lift) > 0.025
            and after[2] > before[2] + 0.025
            and np.linalg.norm(after - hand) < 0.085
        )
        if held and api.remaining() > reserve + 45:
            offset = after - hand
            destination = position(step["target"])
            for height, count in ((0.16, 14), (0.045, 12)):
                api.attempt({
                    "op": "move",
                    "xyz": (destination - offset + [0, 0, height]).tolist(),
                    "steps": count, "watch": step["item"]
                })
            api.attempt({
                "op": "grip", "closed": False, "watch": step["item"]
            })
            api.attempt({
                "op": "move",
                "xyz": (np.asarray(api.eef()) + [0, 0, 0.10]).tolist(),
                "steps": 8, "watch": step["item"]
            })
            if placement_plausible(step, {}):
                continue

        if api.remaining() <= reserve + retry_cost:
            return

        # Retry only the unresolved placement; preserve earlier work.
        receipt = api.attempt(step)
        if not placement_plausible(step, receipt):
            return
