import numpy as np
import math


def run(api):
    def words(value):
        value = str(value).lower()
        for c in "_-.,;:!?()":
            value = value.replace(c, " ")
        return value.split()

    text = words(api.instruction)
    names = list(api.names())
    catalog = api.catalog()
    bodies = [
        n for n in names
        if catalog.get(n, {}).get("kind") in ("item", "fixture")
    ]
    regions = [
        n for n in names if catalog.get(n, {}).get("kind") == "region"
    ]

    def position(name):
        return np.asarray(api.pos(name), dtype=float).copy()

    def owner(region):
        return catalog.get(region, {}).get("parent")

    def owned(body):
        return [r for r in regions if owner(r) == body]

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "porcelain cup"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug"
        ],
        "red coffee mug": ["red mug", "coffee mug"],
        "black book": ["book"],
        "cream cheese": ["cream cheese box"],
        "alphabet soup": ["alphabet soup can"],
        "tomato sauce": ["tomato sauce can"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["stove", "burner"],
        "desk caddy": ["caddy", "organizer"],
        "moka pot": ["moka", "coffee pot"],
        "wooden cabinet": ["cabinet"],
        "white cabinet": ["cabinet"],
    }

    aliases = {}
    for name in bodies:
        tokens = words(name)
        while tokens and tokens[-1].isdigit():
            tokens.pop()
        base = " ".join(tokens)
        variants = [base] + synonyms.get(base, [])
        if tokens:
            variants.append(tokens[-1])
        if tokens and tokens[-1] == "mug":
            variants.append("cup")
        aliases[name] = [words(v) for v in variants]

    def mentions(tokens, pool=None):
        """Longest noun phrases win; identical names remain ambiguous."""
        pool = bodies if pool is None else pool
        found = []
        i = 0
        while i < len(tokens):
            length = 0
            candidates = []
            for name in pool:
                for alias in aliases.get(name, []):
                    size = len(alias)
                    if size and tokens[i:i + size] == alias:
                        if size > length:
                            length, candidates = size, [name]
                        elif size == length and name not in candidates:
                            candidates.append(name)
            if length:
                found.append((i, i + length, candidates))
                i += length
            else:
                i += 1
        return found

    directions = ("left", "right", "front", "back")

    def choose(candidates, tokens, start=0, end=None):
        if len(candidates) == 1:
            return candidates[0]
        end = len(tokens) if end is None else end
        local = tokens[max(0, start - 4):min(len(tokens), end + 4)]
        direction = next((d for d in directions if d in local), None)
        if direction:
            common = set(words(candidates[0]))
            for candidate in candidates[1:]:
                common &= set(words(candidate))
            common -= {"1", "2", "3", "4", "5", "the"}
            markers = []
            for region in regions:
                rt = words(region)
                if direction in rt and common.intersection(rt):
                    markers.append(region)
            if markers:
                markers.sort(key=lambda r: (
                    "init" not in words(r), len(common.intersection(words(r)))
                ), reverse=True)
                return api.nearest(markers[0], candidates)
        # Refuse an unresolved semantic ambiguity instead of selecting by ID.
        raise ValueError("Ambiguous object")

    def entities(tokens, movable=False):
        pool = [
            n for n in bodies
            if not movable or catalog[n]["kind"] == "item"
        ]
        result = []
        for a, b, candidates in mentions(tokens, pool):
            selected = choose(candidates, tokens, a, b)
            if selected not in result:
                result.append(selected)
        return result

    def region_for(body, tags, excluded=()):
        candidates = [
            r for r in owned(body)
            if all(t in words(r) for t in tags)
            and not any(t in words(r) for t in excluded)
        ]
        if len(candidates) == 1:
            return candidates[0]
        if candidates:
            return min(candidates, key=lambda r: len(words(r)))
        return None

    def drawer_region(tokens, previous=None):
        level = next(
            (w for w in ("top", "middle", "bottom") if w in tokens), None
        )
        matches = mentions(tokens)
        cabinets = []
        for a, b, candidates in matches:
            eligible = [
                n for n in candidates
                if any(
                    any(k in words(r) for k in ("top", "middle", "bottom"))
                    and "side" not in words(r)
                    for r in owned(n)
                )
            ]
            if eligible:
                cabinets.append(choose(eligible, tokens, a, b))
        if not cabinets and previous in regions:
            if "side" not in words(previous):
                if level is None:
                    return previous
                cabinets = [owner(previous)]
        if not cabinets and previous in bodies:
            cabinets = [previous]
        if not cabinets:
            cabinets = [
                n for n in bodies
                if "cabinet" in words(n)
                or any("drawer" in words(r) for r in owned(n))
            ]
        if len(cabinets) != 1:
            raise ValueError("Unresolved drawer owner")
        cabinet = cabinets[0]
        candidates = [
            r for r in owned(cabinet)
            if "side" not in words(r)
            and "init" not in words(r)
            and (
                "drawer" in words(r)
                or any(k in words(r) for k in ("top", "middle", "bottom"))
            )
            and (level is None or level in words(r))
        ]
        if len(candidates) != 1:
            raise ValueError("Unresolved drawer level")
        return candidates[0]

    def destination(tokens, previous):
        phrase = " ".join(tokens)
        if "drawer" in tokens:
            return drawer_region(tokens, previous), True

        found = mentions(tokens)
        direction = next((d for d in directions if d in tokens), None)
        outside = (
            "next to" in phrase or "beside" in tokens
            or any(
                p in phrase
                for p in (
                    "left of", "right of", "front of", "behind",
                    "back of",
                )
            )
        )
        if "behind" in tokens:
            direction = "back"

        if found:
            # In "left of the caddy", the fixture is the reference.
            a, b, candidates = found[-1] if outside else found[0]
            body = choose(candidates, tokens, a, b)
        elif previous:
            body = owner(previous) if previous in regions else previous
        else:
            raise ValueError("Missing placement target")

        if direction and (
            outside or "compartment" in tokens or "section" in tokens
            or "caddy" in words(body)
        ):
            relation = "outside" if outside else "inside"
            target = api.relative_target(body, direction, relation)
            if target not in regions:
                raise ValueError("Missing spatial region")
            return target, False

        if "top" in tokens and (
            "on" in tokens or "onto" in tokens or "atop" in tokens
        ):
            target = region_for(body, ["top", "side"])
            if target:
                return target, False

        inside = any(w in tokens for w in ("in", "into", "inside"))
        if inside:
            target = (
                region_for(body, ["contain"])
                or region_for(body, ["inside"])
            )
            if target:
                return target, False
            compartments = [
                r for r in owned(body)
                if "contain" in words(r) and "init" not in words(r)
            ]
            if len(compartments) > 1:
                raise ValueError("Missing compartment direction")
        else:
            target = (
                region_for(body, ["cook"])
                or region_for(body, ["top", "side"])
                or region_for(body, ["top"], ["init"])
            )
            if target:
                return target, False
        return body, False

    verbs = {
        "put", "place", "set", "move", "insert", "stack", "deposit",
        "open", "close", "shut", "pick", "grab", "take",
        "turn", "switch", "push", "pull", "slide", "rotate", "lift",
    }
    starts = [i for i, token in enumerate(text) if token in verbs]

    def fallback():
        if api.remaining() > 0:
            api.fallback()

    if not starts:
        fallback()
        return

    # Resolve the whole plan before making physical changes.
    plan = []
    selected_items = []
    previous_target = None
    last_drawer = None
    drawer_state = {}
    try:
        for index, start in enumerate(starts):
            stop = starts[index + 1] if index + 1 < len(starts) else len(text)
            verb = text[start]
            clause = text[start + 1:stop]
            while clause and clause[-1] in ("and", "then"):
                clause.pop()

            if verb in ("pick", "grab", "take"):
                selected_items = entities(clause, movable=True)
                if not selected_items or index + 1 == len(starts):
                    raise ValueError("Unsupported standalone pickup")
                continue

            if verb in ("open", "close", "shut"):
                target = drawer_region(
                    clause, last_drawer or previous_target
                )
                op = "open" if verb == "open" else "close"
                plan.append({"op": op, "target": target})
                drawer_state[target] = op
                last_drawer = target
                previous_target = target
                continue

            if verb in ("turn", "switch"):
                if "on" not in clause and "off" not in clause:
                    raise ValueError("Unsupported rotation")
                candidates = [
                    n for n in entities(clause)
                    if "stove" in words(n)
                ]
                if not candidates and previous_target:
                    body = owner(previous_target) or previous_target
                    if "stove" in words(body):
                        candidates = [body]
                if len(candidates) != 1:
                    raise ValueError("Unsupported switch")
                plan.append({
                    "op": "stove",
                    "target": candidates[0],
                    "on": "on" in clause,
                })
                previous_target = candidates[0]
                continue

            if verb not in (
                "put", "place", "set", "move", "insert", "stack", "deposit"
            ):
                raise ValueError("Unsupported manipulation")

            prepositions = (
                "in", "into", "inside", "on", "onto", "atop",
                "to", "beside", "behind", "next",
            )
            split = next(
                (i for i, w in enumerate(clause) if w in prepositions), None
            )
            if split is None:
                raise ValueError("Missing placement relation")
            source = clause[:split]
            target_text = clause[split:]
            items = entities(source, movable=True)
            if not items and any(
                p in source for p in ("it", "them", "these", "those")
            ):
                items = list(selected_items)
            if not items:
                raise ValueError("Missing movable object")

            target, is_drawer = destination(target_text, previous_target)
            if is_drawer:
                if drawer_state.get(target) != "open":
                    plan.append({"op": "open", "target": target})
                    drawer_state[target] = "open"
                last_drawer = target

            for item in items:
                if item == target or item == owner(target):
                    raise ValueError("Self placement")
                grasp = (
                    "rim" if "bowl" in words(item)
                    else "thin_edge" if "book" in words(item)
                    else "standard"
                )
                plan.append({
                    "op": "place", "item": item,
                    "target": target, "grasp": grasp,
                })
            selected_items = items
            previous_target = target
    except (ValueError, TypeError, KeyError):
        fallback()
        return

    def observed_placement(step, receipt):
        item, target = step["item"], step["target"]
        p, q = position(item), position(target)
        gap = float(np.linalg.norm(p[:2] - q[:2]))
        container = owner(target) or target
        tolerance = 0.065
        if "basket" in words(container):
            tolerance = 0.10
        if "caddy" in words(container):
            tolerance = 0.045
        dz = float(p[2] - q[2])
        # This is only a conservative geometric check, not a success oracle.
        plausible = gap < tolerance and -0.065 < dz < 0.20
        return plausible, p, q

    def stove_operation(step):
        stove = step["target"]
        controls = [
            n for n in names
            if any(w in words(n) for w in ("switch", "knob", "button"))
            and (
                owner(n) == stove or stove in n
                or len([b for b in bodies if "stove" in words(b)]) == 1
            )
        ]
        if controls:
            control = min(
                controls,
                key=lambda n: np.linalg.norm(position(n) - position(stove))
            )
            center = position(control)
        else:
            center = position(stove) + np.array([0., -0.105, 0.025])
        api.attempt({"op": "grip", "closed": False})
        api.attempt({
            "op": "move", "xyz": (center + [0., 0., 0.09]).tolist(),
            "steps": 12,
        })
        api.attempt({"op": "move", "xyz": center.tolist(), "steps": 14})
        api.attempt({"op": "grip", "closed": True})
        sign = 1.0 if step["on"] else -1.0
        api.action([0., 0., 0., 0., 0., sign, 1.], steps=18)
        api.attempt({"op": "grip", "closed": False})
        api.attempt({
            "op": "move",
            "xyz": (np.asarray(api.eef()) + [0., 0., 0.12]).tolist(),
            "steps": 10,
        })

    for index, step in enumerate(plan):
        if api.remaining() <= 0:
            return

        if step["op"] == "stove":
            stove_operation(step)
            continue

        receipt = api.attempt(step)
        if step["op"] != "place":
            # A stationary drawer can already be at its requested endpoint.
            # Do not repeatedly pull or push based on displacement alone.
            continue

        plausible, p, q = observed_placement(step, receipt)
        if plausible:
            continue

        lift = receipt.get("max_lift")
        before = receipt.get("before_xyz")
        hand = np.asarray(api.eef(), dtype=float)
        held = (
            lift is not None and float(lift) > 0.025
            and before is not None
            and p[2] > float(before[2]) + 0.025
            and np.linalg.norm(p - hand) < 0.085
        )

        pending = len(plan) - index - 1
        reserve = 65 * pending
        if (
            held and step["grasp"] == "standard"
            and api.remaining() > reserve + 55
        ):
            offset = p - hand
            api.attempt({
                "op": "move",
                "xyz": (q - offset + [0., 0., 0.16]).tolist(),
                "steps": 16, "watch": step["item"],
            })
            api.attempt({
                "op": "move",
                "xyz": (q - offset + [0., 0., 0.045]).tolist(),
                "steps": 12, "watch": step["item"],
            })
            api.attempt({
                "op": "grip", "closed": False, "watch": step["item"]
            })
            api.attempt({
                "op": "move",
                "xyz": (np.asarray(api.eef()) + [0., 0., 0.10]).tolist(),
                "steps": 10, "watch": step["item"],
            })
            plausible, _, _ = observed_placement(step, receipt)
            if plausible:
                continue

        used = receipt.get("steps_used")
        retry_budget = max(65, int(used) if used is not None else 100)
        if api.remaining() > reserve + retry_budget + 10:
            api.attempt({
                "op": "grip", "closed": False, "watch": step["item"]
            })
            retry = api.attempt(step)
            plausible, _, _ = observed_placement(step, retry)
            if plausible:
                continue

        # Preserve action order: do not close a drawer over a failed insertion
        # or proceed to later placements after an unresolved manipulation.
        return
