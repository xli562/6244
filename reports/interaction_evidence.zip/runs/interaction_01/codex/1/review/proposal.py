import numpy as np
import math


def run(api):
    def words(value):
        value = str(value).lower()
        for c in "_-.,;:!?()":
            value = value.replace(c, " ")
        return value.split()

    text = words(api.instruction)
    names = list(api.names())
    catalog = api.catalog()
    bodies = [
        n for n in names
        if catalog.get(n, {}).get("kind") in ("item", "fixture")
    ]
    regions = [
        n for n in names if catalog.get(n, {}).get("kind") == "region"
    ]
    directions = ("left", "right", "front", "back")

    def position(name):
        return np.asarray(api.pos(name), dtype=float).copy()

    def owner(name):
        return catalog.get(name, {}).get("parent")

    def owned(body):
        return [r for r in regions if owner(r) == body]

    def fallback():
        if api.remaining() > 0:
            api.fallback()

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "white cup", "porcelain cup"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug",
            "yellow mug", "yellow and white cup", "white and yellow cup",
        ],
        "red coffee mug": ["red mug", "red cup", "coffee mug"],
        "black book": ["book"],
        "cream cheese": ["cream cheese box"],
        "alphabet soup": ["alphabet soup can"],
        "tomato sauce": ["tomato sauce can"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["stove", "burner"],
        "desk caddy": ["caddy", "organizer"],
        "moka pot": ["moka", "coffee pot"],
        "wooden cabinet": ["cabinet"],
        "white cabinet": ["cabinet"],
    }

    aliases = {}
    for name in bodies:
        tokens = words(name)
        while tokens and tokens[-1].isdigit():
            tokens.pop()
        base = " ".join(tokens)
        variants = [base] + synonyms.get(base, [])
        if tokens:
            variants.append(tokens[-1])
        if tokens and tokens[-1] == "mug":
            variants.append("cup")
        aliases[name] = [words(v) for v in variants]

    def mentions(tokens, pool=None):
        pool = bodies if pool is None else pool
        found = []
        i = 0
        while i < len(tokens):
            length, candidates = 0, []
            for name in pool:
                for alias in aliases.get(name, []):
                    size = len(alias)
                    if size and tokens[i:i + size] == alias:
                        if size > length:
                            length, candidates = size, [name]
                        elif size == length and name not in candidates:
                            candidates.append(name)
            if length:
                found.append((i, i + length, candidates))
                i += length
            else:
                i += 1
        return found

    def choose(candidates, tokens, start=0, end=None):
        if len(candidates) == 1:
            return candidates[0]
        end = len(tokens) if end is None else end

        # Prefer modifiers of this noun, rather than a later target noun.
        prefix = tokens[max(0, start - 4):start]
        suffix = tokens[end:min(len(tokens), end + 5)]
        direction = next(
            (w for w in reversed(prefix) if w in directions), None
        )
        if direction is None and not any(
            w in suffix for w in ("in", "into", "on", "onto")
        ):
            direction = next((w for w in suffix if w in directions), None)

        if direction:
            common = set(words(candidates[0]))
            for candidate in candidates[1:]:
                common &= set(words(candidate))
            common = {w for w in common if not w.isdigit()}
            markers = [
                r for r in regions
                if direction in words(r)
                and common.intersection(words(r))
                and owner(r) not in candidates
            ]
            if markers:
                def score(region):
                    rt = set(words(region))
                    return (
                        len(common & rt),
                        "init" not in rt,
                        -len(rt),
                    )
                markers.sort(key=score, reverse=True)
                if len(markers) == 1 or score(markers[0]) > score(markers[1]):
                    return api.nearest(markers[0], candidates)

        raise ValueError("Unresolved object reference")

    def entities(tokens, movable=False):
        pool = [
            n for n in bodies
            if not movable or catalog[n]["kind"] == "item"
        ]
        result = []
        for a, b, candidates in mentions(tokens, pool):
            selected = choose(candidates, tokens, a, b)
            if selected not in result:
                result.append(selected)
        return result

    def region_for(body, tags, excluded=()):
        candidates = [
            r for r in owned(body)
            if all(t in words(r) for t in tags)
            and not any(t in words(r) for t in excluded)
        ]
        if len(candidates) == 1:
            return candidates[0]
        if candidates:
            candidates.sort(key=lambda r: len(words(r)))
            if len(words(candidates[0])) < len(words(candidates[1])):
                return candidates[0]
        return None

    def drawer_regions(body):
        return [
            r for r in owned(body)
            if "side" not in words(r) and "init" not in words(r)
            and (
                "drawer" in words(r)
                or any(k in words(r) for k in ("top", "middle", "bottom"))
            )
        ]

    def drawer_region(tokens, previous=None):
        level = next(
            (w for w in ("top", "middle", "bottom") if w in tokens), None
        )
        cabinets = []
        for a, b, candidates in mentions(tokens):
            eligible = [n for n in candidates if drawer_regions(n)]
            if eligible:
                cabinet = choose(eligible, tokens, a, b)
                if cabinet not in cabinets:
                    cabinets.append(cabinet)

        if not cabinets and previous in regions:
            parent = owner(previous)
            if previous in drawer_regions(parent) and level is None:
                return previous
            if drawer_regions(parent):
                cabinets = [parent]
        if not cabinets and previous in bodies and drawer_regions(previous):
            cabinets = [previous]
        if not cabinets:
            cabinets = [
                n for n in bodies
                if (
                    "cabinet" in words(n)
                    or any("drawer" in words(r) for r in owned(n))
                )
                and drawer_regions(n)
            ]
        if len(cabinets) != 1:
            raise ValueError("Unresolved drawer owner")
        candidates = [
            r for r in drawer_regions(cabinets[0])
            if level is None or level in words(r)
        ]
        if len(candidates) != 1:
            raise ValueError("Unresolved drawer level")
        return candidates[0]

    def destination(tokens, previous):
        phrase = " ".join(tokens)
        if "drawer" in tokens:
            return drawer_region(tokens, previous), True

        found = mentions(tokens)
        direction = next((d for d in directions if d in tokens), None)
        if "behind" in tokens:
            direction = "back"

        compartment = any(
            w in tokens for w in ("compartment", "section", "inside", "into")
        )
        outside = (
            "next to" in phrase or "beside" in tokens
            or "behind" in tokens
            or any(p in phrase for p in (
                "left of", "right of", "front of", "back of",
                "left side of", "right side of",
                "front side of", "back side of",
            ))
        )
        # "In the right compartment of ..." must remain an inside relation.
        if "compartment" in tokens or "section" in tokens:
            outside = False

        if found:
            a, b, candidates = found[-1] if outside else found[0]
            body = choose(candidates, tokens, a, b)
        elif previous:
            body = owner(previous) if previous in regions else previous
        else:
            raise ValueError("Missing placement target")
        if body is None:
            raise ValueError("Missing region owner")

        if direction and (
            outside or compartment or "caddy" in words(body)
        ):
            relation = "outside" if outside else "inside"
            target = api.relative_target(body, direction, relation)
            if target not in regions:
                raise ValueError("Missing spatial region")
            return target, False

        if outside:
            raise ValueError("Unspecified outside direction")

        if "top" in tokens or "atop" in tokens:
            target = region_for(body, ["top", "side"])
            if target:
                return target, False

        inside = any(w in tokens for w in ("in", "into", "inside"))
        if inside:
            target = (
                region_for(body, ["contain"])
                or region_for(body, ["inside"])
            )
            if target:
                return target, False
            compartments = [
                r for r in owned(body)
                if "contain" in words(r) and "init" not in words(r)
            ]
            if len(compartments) > 1:
                raise ValueError("Missing compartment direction")
        else:
            target = (
                region_for(body, ["cook"])
                or region_for(body, ["top", "side"])
                or region_for(body, ["top"], ["init"])
            )
            if target:
                return target, False
        return body, False

    placement_verbs = {
        "put", "place", "set", "move", "insert", "stack", "deposit",
    }
    verbs = placement_verbs | {
        "open", "close", "shut", "pick", "grab", "take",
        "turn", "switch", "push", "pull", "slide", "rotate", "lift",
    }
    prepositions = {
        "in", "into", "inside", "on", "onto", "atop",
        "to", "beside", "behind", "next",
    }
    starts = [i for i, token in enumerate(text) if token in verbs]
    if not starts:
        fallback()
        return

    clauses = []
    for index, start in enumerate(starts):
        stop = starts[index + 1] if index + 1 < len(starts) else len(text)
        clause = text[start + 1:stop]
        while clause and clause[-1] in ("and", "then"):
            clause.pop()
        clauses.append((text[start], clause))

    # Expand elliptical placement conjunctions:
    # "put A on X and B in Y", while preserving "A and B in Y".
    expanded = []
    for verb, clause in clauses:
        if verb in placement_verbs:
            cut = None
            for i, token in enumerate(clause):
                if token != "and":
                    continue
                if not any(w in prepositions for w in clause[:i]):
                    continue
                tail = clause[i + 1:]
                split = next(
                    (j for j, w in enumerate(tail) if w in prepositions), None
                )
                if split is not None and mentions(tail[:split]):
                    cut = i
                    break
            if cut is not None:
                expanded.append((verb, clause[:cut]))
                expanded.append((verb, clause[cut + 1:]))
                continue
        expanded.append((verb, clause))

    plan = []
    selected_items = []
    previous_target = None
    last_drawer = None
    drawer_state = {}
    try:
        for index, (verb, clause) in enumerate(expanded):
            if verb in ("pick", "grab", "take"):
                # Source fixtures do not become the selected payload.
                source_end = next(
                    (i for i, w in enumerate(clause) if w == "from"),
                    len(clause),
                )
                selected_items = entities(clause[:source_end], movable=True)
                if not selected_items or index + 1 == len(expanded):
                    raise ValueError("Unsupported standalone pickup")
                continue

            if verb in ("open", "close", "shut"):
                target = drawer_region(clause, last_drawer or previous_target)
                op = "open" if verb == "open" else "close"
                plan.append({"op": op, "target": target})
                drawer_state[target] = op
                last_drawer = target
                previous_target = target
                continue

            if verb in ("turn", "switch"):
                if "on" not in clause and "off" not in clause:
                    raise ValueError("Unsupported rotation")
                candidates = [
                    n for n in entities(clause) if "stove" in words(n)
                ]
                if not candidates and previous_target:
                    body = owner(previous_target) or previous_target
                    if "stove" in words(body):
                        candidates = [body]
                if len(candidates) != 1:
                    raise ValueError("Unsupported switch")
                plan.append({
                    "op": "stove", "target": candidates[0],
                    "on": "on" in clause,
                })
                previous_target = candidates[0]
                continue

            if verb not in placement_verbs:
                raise ValueError("Unsupported manipulation")

            split = next(
                (i for i, w in enumerate(clause) if w in prepositions), None
            )
            if split is None:
                raise ValueError("Missing placement relation")
            source, target_text = clause[:split], clause[split:]
            items = entities(source, movable=True)
            if not items and any(
                p in source for p in ("it", "them", "these", "those")
            ):
                items = list(selected_items)
            if not items:
                raise ValueError("Missing movable object")

            target, is_drawer = destination(target_text, previous_target)
            if is_drawer:
                if drawer_state.get(target) != "open":
                    plan.append({"op": "open", "target": target})
                    drawer_state[target] = "open"
                last_drawer = target

            for item in items:
                if item == target or item == owner(target):
                    raise ValueError("Self placement")
                grasp = (
                    "rim" if "bowl" in words(item)
                    else "thin_edge" if "book" in words(item)
                    else "standard"
                )
                plan.append({
                    "op": "place", "item": item,
                    "target": target, "grasp": grasp,
                })
            selected_items = items
            previous_target = target
    except (ValueError, TypeError, KeyError):
        fallback()
        return

    def observed_placement(step):
        p, q = position(step["item"]), position(step["target"])
        container = owner(step["target"]) or step["target"]
        tolerance = 0.065
        if "basket" in words(container):
            tolerance = 0.10
        if "caddy" in words(container):
            tolerance = 0.045
        gap = float(np.linalg.norm(p[:2] - q[:2]))
        dz = float(p[2] - q[2])
        # Geometric evidence only; the environment owns terminal success.
        plausible = (
            np.all(np.isfinite(p)) and np.all(np.isfinite(q))
            and gap < tolerance and -0.065 < dz < 0.20
        )
        return plausible, p, q

    def stove_operation(step):
        stove = step["target"]
        controls = [
            n for n in names
            if any(w in words(n) for w in ("switch", "knob", "button"))
            and (
                owner(n) == stove or stove in n
                or len([b for b in bodies if "stove" in words(b)]) == 1
            )
        ]
        if controls:
            control = min(
                controls,
                key=lambda n: np.linalg.norm(position(n) - position(stove)),
            )
            center = position(control)
        else:
            center = position(stove) + np.array([0., -0.105, 0.025])
        api.attempt({"op": "grip", "closed": False})
        api.attempt({
            "op": "move", "xyz": (center + [0., 0., 0.09]).tolist(),
            "steps": 12,
        })
        api.attempt({"op": "move", "xyz": center.tolist(), "steps": 14})
        api.attempt({"op": "grip", "closed": True})
        sign = 1.0 if step["on"] else -1.0
        api.action([0., 0., 0., 0., 0., sign, 1.], steps=18)
        api.attempt({"op": "grip", "closed": False})
        api.attempt({
            "op": "move",
            "xyz": (np.asarray(api.eef()) + [0., 0., 0.12]).tolist(),
            "steps": 10,
        })

    costs = {"place": 100, "open": 65, "close": 55, "stove": 80}
    for index, step in enumerate(plan):
        if api.remaining() <= 0:
            return
        if step["op"] == "stove":
            stove_operation(step)
            continue

        receipt = api.attempt(step)
        used = receipt.get("steps_used")
        if used is not None and used > 0:
            costs[step["op"]] = max(
                40, int(0.5 * costs[step["op"]] + 0.5 * used)
            )

        if step["op"] != "place":
            # Zero displacement also occurs at an existing drawer endpoint.
            continue

        plausible, p, q = observed_placement(step)
        if plausible:
            continue

        reserve = sum(costs[s["op"]] for s in plan[index + 1:])
        lift = receipt.get("max_lift")
        before = receipt.get("before_xyz")
        hand = np.asarray(api.eef(), dtype=float)
        held = (
            lift is not None and float(lift) > 0.025
            and before is not None
            and p[2] > float(before[2]) + 0.025
            and np.linalg.norm(p - hand) < 0.085
        )

        if (
            held and step["grasp"] == "standard"
            and api.remaining() > reserve + 60
        ):
            offset = p - hand
            api.attempt({
                "op": "move",
                "xyz": (q - offset + [0., 0., 0.16]).tolist(),
                "steps": 16, "watch": step["item"],
            })
            # Re-read a target that may itself have moved.
            q = position(step["target"])
            api.attempt({
                "op": "move",
                "xyz": (q - offset + [0., 0., 0.045]).tolist(),
                "steps": 12, "watch": step["item"],
            })
            api.attempt({
                "op": "grip", "closed": False, "watch": step["item"],
            })
            api.attempt({
                "op": "move",
                "xyz": (np.asarray(api.eef()) + [0., 0., 0.10]).tolist(),
                "steps": 10, "watch": step["item"],
            })
            plausible, _, _ = observed_placement(step)
            if plausible:
                continue

        retry_budget = max(65, int(used) if used is not None else 100)
        if api.remaining() > reserve + retry_budget + 15:
            api.attempt({
                "op": "grip", "closed": False, "watch": step["item"],
            })
            api.attempt(step)
            plausible, _, _ = observed_placement(step)
            if plausible:
                continue

        # Preserve ordering and avoid closing over an unresolved insertion.
        return
