import numpy as np
import math


def run(api):
    def words(value):
        value = str(value).lower()
        for char in "_-.,;:!?()":
            value = value.replace(char, " ")
        return value.split()

    text = words(api.instruction)
    names = list(api.names())
    catalog = api.catalog()
    bodies = [
        n for n in names
        if catalog.get(n, {}).get("kind") in ("item", "fixture")
    ]
    regions = [
        n for n in names
        if catalog.get(n, {}).get("kind") == "region"
    ]

    def position(name):
        return np.asarray(api.pos(name), dtype=float).copy()

    def owner(name):
        return catalog.get(name, {}).get("parent")

    def owned(body):
        return [r for r in regions if owner(r) == body]

    def fallback():
        if api.remaining() > 0:
            api.fallback()

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "porcelain cup"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug"
        ],
        "red coffee mug": ["red mug", "coffee mug"],
        "black book": ["book"],
        "cream cheese": ["cream cheese box"],
        "alphabet soup": ["alphabet soup can"],
        "tomato sauce": ["tomato sauce can"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["stove", "burner"],
        "desk caddy": ["caddy", "organizer"],
        "moka pot": ["moka", "coffee pot"],
        "wooden cabinet": ["cabinet"],
        "white cabinet": ["cabinet"],
    }

    aliases = {}
    base_words = {}
    for name in bodies:
        tokens = words(name)
        while tokens and tokens[-1].isdigit():
            tokens.pop()
        base_words[name] = tokens
        base = " ".join(tokens)
        variants = [base] + synonyms.get(base, [])
        if tokens:
            variants.append(tokens[-1])
        if tokens and tokens[-1] == "mug":
            variants.append("cup")
        aliases[name] = [words(v) for v in variants if v]

    def mentions(tokens, pool=None):
        pool = bodies if pool is None else pool
        result = []
        index = 0
        while index < len(tokens):
            length, candidates = 0, []
            for name in pool:
                for alias in aliases.get(name, []):
                    size = len(alias)
                    if tokens[index:index + size] != alias:
                        continue
                    if size > length:
                        length, candidates = size, [name]
                    elif size == length and name not in candidates:
                        candidates.append(name)
            if length:
                result.append((index, index + length, candidates))
                index += length
            else:
                index += 1
        return result

    directions = ("left", "right", "front", "back")

    def choose(candidates, tokens, start=0, end=None):
        if not candidates:
            raise ValueError("Missing entity")
        if len(candidates) == 1:
            return candidates[0]
        end = len(tokens) if end is None else end

        # Prefer modifiers immediately adjacent to this noun phrase.
        prefix = tokens[max(0, start - 3):start]
        suffix = tokens[end:min(len(tokens), end + 4)]
        direction = next(
            (w for w in reversed(prefix) if w in directions), None
        )
        if direction is None:
            direction = next((w for w in suffix if w in directions), None)

        if direction:
            common = set(base_words[candidates[0]])
            for candidate in candidates[1:]:
                common &= set(base_words[candidate])
            markers = [
                r for r in regions
                if direction in words(r)
                and common.intersection(words(r))
                and owner(r) not in candidates
            ]
            if markers:
                def score(region):
                    rt = set(words(region))
                    return (
                        len(common & rt),
                        "init" not in rt,
                        -len(rt),
                    )
                markers.sort(key=score, reverse=True)
                if len(markers) == 1 or score(markers[0]) > score(markers[1]):
                    return api.nearest(markers[0], candidates)
                resolved = {api.nearest(r, candidates) for r in markers
                            if score(r) == score(markers[0])}
                if len(resolved) == 1:
                    return resolved.pop()
        raise ValueError("Ambiguous entity")

    def entities(tokens, movable=False):
        # Match against all bodies first: a fixture noun must not accidentally
        # resolve to an item sharing a generic alias.
        result = []
        for a, b, candidates in mentions(tokens):
            if movable:
                candidates = [
                    n for n in candidates
                    if catalog[n]["kind"] == "item"
                ]
            if not candidates:
                continue
            plural = (
                "both" in tokens or "all" in tokens
            ) and len(candidates) > 1
            selected = candidates if plural else [
                choose(candidates, tokens, a, b)
            ]
            for name in selected:
                if name not in result:
                    result.append(name)
        return result

    def region_for(body, tags, excluded=()):
        candidates = [
            r for r in owned(body)
            if all(t in words(r) for t in tags)
            and not any(t in words(r) for t in excluded)
        ]
        if len(candidates) == 1:
            return candidates[0]
        if candidates:
            lengths = [len(words(r)) for r in candidates]
            shortest = min(lengths)
            best = [
                r for r in candidates if len(words(r)) == shortest
            ]
            if len(best) == 1:
                return best[0]
        return None

    def drawer_candidates(body, level=None):
        return [
            r for r in owned(body)
            if "side" not in words(r)
            and "init" not in words(r)
            and (
                "drawer" in words(r)
                or any(k in words(r) for k in ("top", "middle", "bottom"))
            )
            and (level is None or level in words(r))
        ]

    def drawer_region(tokens, previous=None):
        level = next(
            (w for w in ("top", "middle", "bottom") if w in tokens), None
        )
        cabinets = []
        for a, b, candidates in mentions(tokens):
            eligible = [n for n in candidates if drawer_candidates(n)]
            if eligible:
                selected = choose(eligible, tokens, a, b)
                if selected not in cabinets:
                    cabinets.append(selected)
        if not cabinets and previous in regions:
            parent = owner(previous)
            if previous in drawer_candidates(parent):
                if level is None:
                    return previous
                cabinets = [parent]
        if not cabinets and previous in bodies:
            if drawer_candidates(previous):
                cabinets = [previous]
        if not cabinets:
            cabinets = [
                n for n in bodies
                if (
                    "cabinet" in words(n)
                    or "drawer" in words(n)
                    or any("drawer" in words(r) for r in owned(n))
                ) and drawer_candidates(n)
            ]
        if len(cabinets) != 1:
            raise ValueError("Unresolved drawer owner")
        candidates = drawer_candidates(cabinets[0], level)
        if len(candidates) != 1:
            raise ValueError("Unresolved drawer level")
        return candidates[0]

    def destination(tokens, previous):
        phrase = " ".join(tokens)
        if "drawer" in tokens:
            return drawer_region(tokens, previous), True

        found = mentions(tokens)
        direction = next((d for d in directions if d in tokens), None)
        outside = (
            "next to" in phrase or "beside" in tokens
            or any(p in phrase for p in (
                "left of", "right of", "front of", "behind", "back of"
            ))
        )
        if "behind" in tokens:
            direction = "back"

        if found:
            a, b, candidates = found[-1] if outside else found[0]
            body = choose(candidates, tokens, a, b)
        elif previous:
            body = owner(previous) if previous in regions else previous
        else:
            raise ValueError("Missing placement target")
        if body is None:
            raise ValueError("Missing target owner")

        if direction and (
            outside or "compartment" in tokens or "section" in tokens
            or "caddy" in words(body)
        ):
            target = api.relative_target(
                body, direction, "outside" if outside else "inside"
            )
            if target not in regions:
                raise ValueError("Missing spatial region")
            return target, False
        if outside:
            raise ValueError("Unresolved outside location")

        if "top" in tokens and any(
            w in tokens for w in ("on", "onto", "atop")
        ):
            target = region_for(body, ["top", "side"])
            if target:
                return target, False

        inside = any(w in tokens for w in ("in", "into", "inside"))
        if inside:
            # "Put it inside" can refer to a drawer just opened.
            if not found and previous in regions:
                if previous in drawer_candidates(owner(previous)):
                    return previous, True
            target = (
                region_for(body, ["contain"])
                or region_for(body, ["inside"])
            )
            if target:
                return target, False
            compartments = [
                r for r in owned(body)
                if "contain" in words(r) and "init" not in words(r)
            ]
            if len(compartments) > 1:
                raise ValueError("Missing compartment direction")
        else:
            target = (
                region_for(body, ["cook"])
                or region_for(body, ["top", "side"])
                or region_for(body, ["top"], ["init"])
            )
            if target:
                return target, False
        return body, False

    placement_verbs = {
        "put", "place", "set", "move", "insert", "stack", "deposit"
    }
    verbs = placement_verbs | {
        "open", "close", "shut", "pick", "grab", "take",
        "turn", "switch", "push", "pull", "slide", "rotate", "lift",
    }
    starts = [i for i, token in enumerate(text) if token in verbs]
    if not starts:
        fallback()
        return

    plan = []
    selected_items = []
    previous_target = None
    last_drawer = None
    drawer_state = {}

    try:
        for index, start in enumerate(starts):
            stop = starts[index + 1] if index + 1 < len(starts) else len(text)
            verb = text[start]
            clause = text[start + 1:stop]
            while clause and clause[-1] in ("and", "then"):
                clause.pop()

            if verb in ("pick", "grab", "take"):
                selected_items = entities(clause, movable=True)
                if not selected_items or index + 1 == len(starts):
                    raise ValueError("Unsupported standalone pickup")
                continue

            if verb in ("open", "close", "shut"):
                target = drawer_region(clause, last_drawer or previous_target)
                op = "open" if verb == "open" else "close"
                plan.append({"op": op, "target": target})
                drawer_state[target] = op
                last_drawer = previous_target = target
                continue

            if verb in ("turn", "switch"):
                if "on" not in clause and "off" not in clause:
                    raise ValueError("Unsupported rotation")
                candidates = [
                    n for n in entities(clause) if "stove" in words(n)
                ]
                if not candidates and previous_target:
                    body = owner(previous_target) or previous_target
                    if "stove" in words(body):
                        candidates = [body]
                if len(candidates) != 1:
                    raise ValueError("Unsupported switch")
                plan.append({
                    "op": "stove", "target": candidates[0],
                    "on": "on" in clause,
                })
                previous_target = candidates[0]
                continue

            if verb not in placement_verbs:
                raise ValueError("Unsupported manipulation")

            prepositions = {
                "in", "into", "inside", "on", "onto", "atop",
                "to", "beside", "behind", "next",
            }
            # Relations inside source descriptions are skipped when they do
            # not leave a resolvable destination.
            splits = [
                i for i, token in enumerate(clause)
                if token in prepositions
            ]
            parsed = None
            for split in splits:
                source, target_text = clause[:split], clause[split:]
                try:
                    items = entities(source, movable=True)
                    if not items and any(
                        p in source for p in ("it", "them", "these", "those")
                    ):
                        items = list(selected_items)
                    if not items:
                        continue
                    target, is_drawer = destination(
                        target_text, previous_target
                    )
                    if any(
                        item == target or item == owner(target)
                        for item in items
                    ):
                        continue
                    parsed = items, target, is_drawer
                    break
                except (ValueError, TypeError, KeyError):
                    continue
            if parsed is None:
                raise ValueError("Unresolved placement")

            items, target, is_drawer = parsed
            if is_drawer:
                if drawer_state.get(target) != "open":
                    plan.append({"op": "open", "target": target})
                    drawer_state[target] = "open"
                last_drawer = target

            for item in items:
                grasp = (
                    "rim" if "bowl" in words(item)
                    else "thin_edge" if "book" in words(item)
                    else "standard"
                )
                plan.append({
                    "op": "place", "item": item,
                    "target": target, "grasp": grasp,
                })
            selected_items = items
            previous_target = target
    except (ValueError, TypeError, KeyError):
        fallback()
        return

    def observed_placement(step):
        p, q = position(step["item"]), position(step["target"])
        container = owner(step["target"]) or step["target"]
        tolerance = 0.065
        if "basket" in words(container):
            tolerance = 0.10
        elif "caddy" in words(container):
            tolerance = 0.045
        gap = float(np.linalg.norm(p[:2] - q[:2]))
        dz = float(p[2] - q[2])
        return gap < tolerance and -0.065 < dz < 0.20, p, q

    def move(point, steps, watch=None):
        command = {
            "op": "move",
            "xyz": np.asarray(point, dtype=float).tolist(),
            "steps": min(steps, max(1, int(api.remaining()))),
        }
        if watch is not None:
            command["watch"] = watch
        return api.attempt(command)

    def stove_operation(step):
        stove = step["target"]
        controls = [
            n for n in names
            if any(w in words(n) for w in ("switch", "knob", "button"))
            and (
                owner(n) == stove or stove in n
                or len([b for b in bodies if "stove" in words(b)]) == 1
            )
        ]
        if controls:
            control = min(
                controls,
                key=lambda n: np.linalg.norm(position(n) - position(stove))
            )
            center = position(control)
        else:
            center = position(stove) + [0., -0.105, 0.025]
        api.attempt({"op": "grip", "closed": False})
        move(center + [0., 0., 0.09], 12)
        move(center, 14)
        api.attempt({"op": "grip", "closed": True})
        sign = 1.0 if step["on"] else -1.0
        api.action([0., 0., 0., 0., 0., sign, 1.], steps=18)
        api.attempt({"op": "grip", "closed": False})
        move(np.asarray(api.eef()) + [0., 0., 0.12], 10)

    def estimate(step):
        if step["op"] == "place":
            return 140
        if step["op"] == "stove":
            return 85
        return 180

    for index, step in enumerate(plan):
        if api.remaining() <= 0:
            return
        if step["op"] == "stove":
            stove_operation(step)
            continue

        receipt = api.attempt(step)
        if step["op"] != "place":
            # Drawer displacement alone does not reveal the endpoint:
            # an already open/closed drawer can legitimately remain still.
            continue

        plausible, p, q = observed_placement(step)
        if plausible:
            continue

        reserve = sum(estimate(s) for s in plan[index + 1:])
        lift = receipt.get("max_lift")
        before = receipt.get("before_xyz")
        hand = np.asarray(api.eef(), dtype=float)
        held = (
            lift is not None and float(lift) > 0.025
            and before is not None
            and p[2] > float(before[2]) + 0.025
            and np.linalg.norm(p - hand) < 0.085
        )

        if (
            held and step["grasp"] == "standard"
            and api.remaining() > reserve + 60
        ):
            item = step["item"]
            offset = p - hand
            move(q - offset + [0., 0., 0.16], 16, item)
            # Re-read the target in case contact moved its parent.
            q = position(step["target"])
            move(q - offset + [0., 0., 0.045], 12, item)
            api.attempt({"op": "grip", "closed": False, "watch": item})
            move(np.asarray(api.eef()) + [0., 0., 0.10], 10, item)
            plausible, _, _ = observed_placement(step)
            if plausible:
                continue

        used = receipt.get("steps_used")
        retry_budget = max(100, int(used) if used is not None else 140)
        if api.remaining() > reserve + retry_budget + 10:
            api.attempt({
                "op": "grip", "closed": False, "watch": step["item"]
            })
            api.attempt(step)
            plausible, _, _ = observed_placement(step)
            if plausible:
                continue

        # Stop before dependent operations, especially closing a drawer,
        # when the preceding placement remains geometrically unresolved.
        return
