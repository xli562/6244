import numpy as np
import math


def run(api):
    def words(s):
        s = str(s).lower()
        for c in "_-.,;:!?()":
            s = s.replace(c, " ")
        return " ".join(s.split())

    text = words(api.instruction)
    names = list(api.names())
    catalog = api.catalog()
    entities = [
        n for n in names
        if catalog.get(n, {}).get("kind") in ("item", "fixture")
    ]
    regions = [
        n for n in names if catalog.get(n, {}).get("kind") == "region"
    ]

    def pos(n):
        return np.asarray(api.pos(n), dtype=float).copy()

    def fallback():
        api.fallback()

    def base(n):
        t = words(n).split()
        while t and t[-1].isdigit():
            t.pop()
        return " ".join(t)

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug", "cup"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug",
            "yellow mug", "mug", "cup"
        ],
        "red coffee mug": ["red coffee mug", "red mug", "mug", "cup"],
        "black book": ["black book", "book"],
        "cream cheese": ["cream cheese box", "cream cheese"],
        "desk caddy": ["desk caddy", "caddy", "organizer"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["flat stove", "stove", "burner"],
        "moka pot": ["moka pot", "coffee pot"],
    }
    aliases = {}
    for n in entities:
        b = base(n)
        a = [b] + synonyms.get(b, [])
        if b:
            a.append(b.split()[-1])
        aliases[n] = sorted(set(a), key=len, reverse=True)

    def owned(region, body):
        current = region
        visited = set()
        while current and current not in visited:
            if current == body:
                return True
            visited.add(current)
            current = catalog.get(current, {}).get("parent")
        return region.startswith(body + "_")

    def direction(s):
        tokens = s.split()
        return next((d for d in ("left", "right", "front", "back")
                     if d in tokens), None)

    def disambiguate(candidates, phrase):
        candidates = list(dict.fromkeys(candidates))
        if len(candidates) == 1:
            return candidates[0]
        d = direction(phrase)
        if d:
            markers = [
                r for r in regions
                if d in words(r).split()
                and any(base(n).split()[-1] in words(r).split()
                        for n in candidates)
            ]
            if markers:
                markers.sort(key=lambda r: (
                    "init" not in words(r).split(), len(r)
                ))
                return api.nearest(markers[0], candidates)
            # Geometry is only a tie-breaker when no named location exists.
            axis = 0 if d in ("left", "right") else 1
            sign = 1 if d in ("left", "front") else -1
            return min(candidates, key=lambda n: sign * pos(n)[axis])
        for qualifier in ("top", "bottom", "middle"):
            if qualifier in phrase.split():
                ranked = sorted(candidates, key=lambda n: pos(n)[2])
                return ranked[{"bottom": 0, "middle": len(ranked) // 2,
                               "top": -1}[qualifier]]
        return sorted(candidates)[0]

    def mentions(phrase, pool=None):
        tokens = phrase.split()
        pool = entities if pool is None else pool
        matches = []
        for n in pool:
            for alias in aliases[n]:
                a = alias.split()
                for i in range(len(tokens) - len(a) + 1):
                    if tokens[i:i + len(a)] == a:
                        matches.append((i, i + len(a), n))
        # Long aliases claim their full span, so "white mug" cannot steal
        # the tail of "yellow and white mug".
        spans = {}
        for i, j, n in matches:
            spans.setdefault((i, j), []).append(n)
        occupied = set()
        accepted = []
        for (i, j), candidates in sorted(
            spans.items(), key=lambda x: (-(x[0][1] - x[0][0]), x[0][0])
        ):
            if any(k in occupied for k in range(i, j)):
                continue
            occupied.update(range(i, j))
            context = " ".join(tokens[max(0, i - 3):j])
            accepted.append((i, disambiguate(candidates, context)))
        return list(dict.fromkeys(n for _, n in sorted(accepted)))

    def drawer_region(phrase, previous=None):
        candidates = mentions(phrase)
        owners = [
            n for n in candidates
            if any(owned(r, n) and "side" not in words(r).split()
                   and any(k in words(r).split()
                           for k in ("top", "middle", "bottom"))
                   for r in regions)
        ]
        if not owners and previous is not None:
            owners = [catalog.get(previous, {}).get("parent")]
            owners = [n for n in owners if n in entities]
        if not owners:
            owners = [n for n in entities
                      if "cabinet" in words(n) or "drawer" in words(n)]
        level = next((x for x in ("top", "middle", "bottom")
                      if x in phrase.split()), None)
        options = [
            r for r in regions
            if any(owned(r, n) for n in owners)
            and "side" not in words(r).split()
            and "init" not in words(r).split()
            and any(x in words(r).split() for x in ("top", "middle", "bottom"))
            and (level is None or level in words(r).split())
        ]
        if previous in options and level is None:
            return previous
        if len(options) == 1:
            return options[0]
        if level is None:
            bottom = [r for r in options if "bottom" in words(r).split()]
            if len(bottom) == 1:
                return bottom[0]
        return None

    def target_for(phrase, previous_body, previous_drawer):
        if "drawer" in phrase.split():
            r = drawer_region(phrase, previous_drawer)
            if r is None:
                return None, None, None
            owner = catalog.get(r, {}).get("parent")
            return r, owner, r

        found = mentions(phrase)
        body = found[-1] if found else previous_body
        if body is None:
            return None, None, None

        d = direction(phrase)
        if d:
            outside = any(p in phrase for p in (
                "next to", "beside", "outside", "in front of", "behind",
                "to the left of", "to the right of", "on the left of",
                "on the right of"
            ))
            inside = ("compartment" in phrase or
                      (not outside and any(
                          p in phrase.split() for p in ("in", "inside", "into")
                      )))
            if outside or inside:
                r = api.relative_target(
                    body, d, "inside" if inside else "outside"
                )
                return r, body, None

        own = [r for r in regions if owned(r, body)
               and "init" not in words(r).split()]
        on_top = "on top" in phrase or "top of" in phrase
        inside = any(t in phrase.split() for t in ("in", "inside", "into"))
        preferred = (
            ["top side", "top region"] if on_top else
            ["contain region", "inside region"] if inside else
            ["cook region", "top side", "top region"]
        )
        for suffix in preferred:
            matches = [r for r in own if words(r).endswith(suffix)]
            if len(matches) == 1:
                return matches[0], body, None
        return body, body, None

    # Split only at action verbs; conjunctions inside object descriptions
    # remain intact.
    tokens = text.split()
    verbs = {"put", "place", "move", "open", "close", "pick", "take",
             "turn", "switch", "push", "pull", "stack", "insert"}
    starts = [i for i, t in enumerate(tokens) if t in verbs]
    if not starts:
        fallback()
        return
    clauses = [
        tokens[i:(starts[k + 1] if k + 1 < len(starts) else len(tokens))]
        for k, i in enumerate(starts)
    ]

    plan = []
    remembered_items = []
    previous_body = None
    previous_drawer = None
    drawer_state = {}
    unsupported = False

    for clause in clauses:
        verb = clause[0]
        while clause and clause[-1] in ("and", "then"):
            clause.pop()
        phrase = " ".join(clause[1:])

        if verb in ("pick", "take"):
            remembered_items = mentions(phrase, [
                n for n in entities
                if catalog.get(n, {}).get("kind") == "item"
            ])
            # A standalone pickup needs a different physical policy.
            if clause is clauses[-1]:
                unsupported = True
            continue

        if verb in ("open", "close"):
            r = drawer_region(phrase, previous_drawer)
            if r is None:
                unsupported = True
                break
            plan.append({"op": verb, "target": r})
            drawer_state[r] = verb
            previous_drawer = r
            previous_body = catalog.get(r, {}).get("parent")
            continue

        if verb not in ("put", "place", "move", "insert", "stack"):
            unsupported = True
            break

        split = next((i for i, t in enumerate(clause[1:], 1)
                      if t in ("in", "into", "inside", "on", "onto",
                               "to", "beside", "behind", "under")), None)
        if split is None:
            unsupported = True
            break
        source = " ".join(clause[1:split])
        destination = " ".join(clause[split:])
        if "under" in destination.split():
            unsupported = True
            break
        items = mentions(source, [
            n for n in entities if catalog.get(n, {}).get("kind") == "item"
        ])
        if not items and any(w in source.split() for w in ("it", "them")):
            items = remembered_items
        target, body, drawer = target_for(
            destination, previous_body, previous_drawer
        )
        if not items or target is None:
            unsupported = True
            break

        if drawer is not None and drawer_state.get(drawer) != "open":
            plan.append({"op": "open", "target": drawer})
            drawer_state[drawer] = "open"
        for item in items:
            if item == body:
                unsupported = True
                break
            b = words(item)
            grasp = ("rim" if "bowl" in b else
                     "thin_edge" if "book" in b else "standard")
            plan.append({
                "op": "place", "item": item,
                "target": target, "grasp": grasp
            })
        remembered_items = items
        previous_body = body
        if drawer is not None:
            previous_drawer = drawer

    # Delegate before performing any partial sequence.
    if unsupported or not plan:
        fallback()
        return

    def plausibly_placed(step, receipt):
        p, q = pos(step["item"]), pos(step["target"])
        gap = receipt.get("xy_gap")
        if gap is None:
            gap = float(np.linalg.norm(p[:2] - q[:2]))
        tolerance = 0.065
        if "caddy" in step["target"]:
            tolerance = 0.045
        elif "basket" in step["target"]:
            tolerance = 0.09
        # These are geometric diagnostics, not official success tests.
        return gap < tolerance and -0.07 < p[2] - q[2] < 0.20

    for index, step in enumerate(plan):
        if api.remaining() < 8:
            return
        receipt = api.attempt(step)
        if step["op"] != "place":
            displacement = receipt.get("delta_xyz")
            if displacement is not None:
                travel = float(np.linalg.norm(np.asarray(displacement)))
                # Tiny motion can also mean the drawer was already at its
                # requested limit; do not blindly repeat the operation.
                if not math.isfinite(travel):
                    return
            continue

        if plausibly_placed(step, receipt):
            continue

        left = len(plan) - index - 1
        cost = max(35, int(receipt.get("steps_used") or 70))
        reserve = sum(45 if s["op"] != "place" else 75
                      for s in plan[index + 1:])
        if api.remaining() < cost + reserve + 8:
            return

        # place_with-backed attempts can repair finger acquisition. Retry
        # only this placement, preserving the requested action sequence.
        second = api.attempt(step)
        if not plausibly_placed(step, second):
            return
