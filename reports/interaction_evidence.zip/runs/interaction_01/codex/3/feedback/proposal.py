import numpy as np
import math


def run(api):
    def words(value):
        s = str(value).lower()
        for c in "_-.,;:!?()":
            s = s.replace(c, " ")
        return " ".join(s.split())

    text = words(api.instruction)
    names = list(api.names())
    catalog = api.catalog()
    entities = [
        n for n in names
        if catalog.get(n, {}).get("kind") in ("item", "fixture")
    ]
    items_pool = [
        n for n in entities if catalog.get(n, {}).get("kind") == "item"
    ]
    regions = [
        n for n in names if catalog.get(n, {}).get("kind") == "region"
    ]

    def pos(n):
        return np.asarray(api.pos(n), dtype=float).copy()

    def base(n):
        tokens = words(n).split()
        while tokens and tokens[-1].isdigit():
            tokens.pop()
        return " ".join(tokens)

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug", "cup"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug",
            "yellow mug", "mug", "cup",
        ],
        "red coffee mug": ["red coffee mug", "red mug", "mug", "cup"],
        "black book": ["black book", "book"],
        "cream cheese": ["cream cheese box", "cream cheese"],
        "desk caddy": ["desk caddy", "caddy", "organizer"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["flat stove", "stove", "burner"],
        "moka pot": ["moka pot", "coffee pot"],
    }

    aliases = {}
    for n in entities:
        b = base(n)
        choices = [b] + synonyms.get(b, [])
        if b:
            choices.append(b.split()[-1])
        aliases[n] = sorted(set(choices), key=len, reverse=True)

    def owned(region, body):
        current = region
        visited = set()
        while current and current not in visited:
            if current == body:
                return True
            visited.add(current)
            current = catalog.get(current, {}).get("parent")
        return bool(body and region.startswith(body + "_"))

    def owner(region):
        current = catalog.get(region, {}).get("parent")
        visited = set()
        while current and current not in visited:
            if current in entities:
                return current
            visited.add(current)
            current = catalog.get(current, {}).get("parent")
        matches = [n for n in entities if owned(region, n)]
        return max(matches, key=len) if matches else None

    def direction(phrase):
        tokens = phrase.split()
        explicit = next(
            (d for d in ("left", "right", "front", "back") if d in tokens),
            None,
        )
        if explicit:
            return explicit
        if "behind" in tokens:
            return "back"
        return None

    def disambiguate(candidates, phrase):
        candidates = list(dict.fromkeys(candidates))
        if len(candidates) == 1:
            return candidates[0]
        d = direction(phrase)
        if d:
            markers = [
                r for r in regions
                if d in words(r).split()
                and any(base(n).split()[-1] in words(r).split()
                        for n in candidates)
            ]
            if markers:
                markers.sort(key=lambda r: (
                    "init" in words(r).split(),
                    any(owned(r, n) for n in candidates),
                    len(r),
                ))
                return api.nearest(markers[0], candidates)
            axis = 0 if d in ("left", "right") else 1
            sign = 1 if d in ("left", "front") else -1
            return min(candidates, key=lambda n: sign * pos(n)[axis])
        for qualifier in ("top", "bottom", "middle"):
            if qualifier in phrase.split():
                ranked = sorted(candidates, key=lambda n: pos(n)[2])
                index = {
                    "bottom": 0, "middle": len(ranked) // 2, "top": -1
                }[qualifier]
                return ranked[index]
        return sorted(candidates)[0]

    def mentions(phrase, pool=None):
        tokens = phrase.split()
        pool = entities if pool is None else pool
        spans = {}
        for n in pool:
            for alias in aliases[n]:
                a = alias.split()
                for i in range(len(tokens) - len(a) + 1):
                    if tokens[i:i + len(a)] == a:
                        spans.setdefault((i, i + len(a)), []).append(n)

        occupied = set()
        accepted = []
        for (i, j), candidates in sorted(
            spans.items(), key=lambda x: (-(x[0][1] - x[0][0]), x[0][0])
        ):
            if any(k in occupied for k in range(i, j)):
                continue
            occupied.update(range(i, j))
            context = " ".join(tokens[max(0, i - 3):j])
            if any(t in context.split() for t in ("both", "all")):
                selected = list(dict.fromkeys(candidates))
            else:
                selected = [disambiguate(candidates, context)]
            accepted.extend((i, n) for n in selected)
        return list(dict.fromkeys(n for _, n in sorted(accepted)))

    def drawer_region(phrase, previous=None):
        candidates = mentions(phrase)
        owners = [
            n for n in candidates
            if any(
                owned(r, n)
                and "side" not in words(r).split()
                and any(k in words(r).split()
                        for k in ("top", "middle", "bottom"))
                for r in regions
            )
        ]
        if not owners and previous is not None:
            p = owner(previous)
            if p is not None:
                owners = [p]
        if not owners:
            owners = [
                n for n in entities
                if any(t in words(n).split() for t in ("cabinet", "drawer"))
            ]
        level = next(
            (x for x in ("top", "middle", "bottom") if x in phrase.split()),
            None,
        )
        options = [
            r for r in regions
            if any(owned(r, n) for n in owners)
            and "side" not in words(r).split()
            and "init" not in words(r).split()
            and any(x in words(r).split() for x in ("top", "middle", "bottom"))
            and (level is None or level in words(r).split())
        ]
        if level is None and previous in options:
            return previous
        if len(options) == 1:
            return options[0]
        if level is None:
            bottom = [r for r in options if "bottom" in words(r).split()]
            if len(bottom) == 1:
                return bottom[0]
        return None

    def target_for(phrase, previous_body, previous_drawer):
        tokens = phrase.split()
        if "drawer" in tokens:
            r = drawer_region(phrase, previous_drawer)
            return (r, owner(r), r) if r else (None, None, None)

        found = mentions(phrase)
        body = found[-1] if found else previous_body
        if body is None:
            return None, None, None

        d = direction(phrase)
        outside = any(p in phrase for p in (
            "next to", "beside", "outside", "in front of", "behind",
            "to the left of", "to the right of", "on the left of",
            "on the right of", "left side of", "right side of",
            "front side of", "back side of",
        ))
        inside = (
            "compartment" in tokens
            or (not outside and any(t in tokens for t in ("in", "inside", "into")))
        )
        if d and (outside or inside):
            try:
                r = api.relative_target(
                    body, d, "inside" if inside else "outside"
                )
            except (ValueError, TypeError):
                return None, None, None
            if r in names:
                return r, body, None
            return None, None, None
        if outside:
            # A side-less "next to" is not an object-to-object placement.
            return None, None, None

        own = [
            r for r in regions
            if owned(r, body) and "init" not in words(r).split()
        ]
        on_top = "on top" in phrase or "top of" in phrase
        preferred = (
            ["top side", "top region"] if on_top else
            ["contain region", "inside region"] if inside else
            ["cook region", "top side", "top region"]
        )
        for suffix in preferred:
            matches = [r for r in own if words(r).endswith(suffix)]
            if len(matches) == 1:
                return matches[0], body, None
        return body, body, None

    tokens = text.split()
    verbs = {
        "put", "place", "move", "open", "close", "pick", "take",
        "turn", "switch", "push", "pull", "stack", "insert",
    }
    starts = [i for i, token in enumerate(tokens) if token in verbs]
    if not starts:
        api.fallback()
        return

    # Temporal inversion requires a richer parser; preserve the old policy.
    if "before" in tokens or "after" in tokens:
        api.fallback()
        return

    clauses = [
        tokens[i:(starts[k + 1] if k + 1 < len(starts) else len(tokens))]
        for k, i in enumerate(starts)
    ]

    plan = []
    remembered_items = []
    previous_body = None
    previous_drawer = None
    drawer_state = {}
    unsupported = False

    for clause_index, original_clause in enumerate(clauses):
        clause = list(original_clause)
        while clause and clause[-1] in ("and", "then"):
            clause.pop()
        verb = clause[0]
        phrase = " ".join(clause[1:])

        if verb in ("pick", "take"):
            remembered_items = mentions(phrase, items_pool)
            if not remembered_items or clause_index == len(clauses) - 1:
                unsupported = True
                break
            continue

        if verb in ("open", "close"):
            r = drawer_region(phrase, previous_drawer)
            if r is None:
                unsupported = True
                break
            plan.append({"op": verb, "target": r})
            drawer_state[r] = verb
            previous_drawer = r
            previous_body = owner(r)
            continue

        if verb in ("turn", "switch"):
            found = mentions(phrase)
            body = found[-1] if found else previous_body
            state = next((t for t in phrase.split() if t in ("on", "off")), None)
            if body is None or "stove" not in words(body).split() or state is None:
                unsupported = True
                break
            plan.append({"op": "stove", "target": body, "state": state})
            previous_body = body
            continue

        if verb not in ("put", "place", "move", "insert", "stack"):
            unsupported = True
            break

        split = next(
            (i for i, t in enumerate(clause[1:], 1)
             if t in ("in", "into", "inside", "on", "onto",
                      "to", "beside", "behind", "under")),
            None,
        )
        if split is None:
            unsupported = True
            break
        source = " ".join(clause[1:split])
        destination = " ".join(clause[split:])
        if "under" in destination.split():
            unsupported = True
            break
        items = mentions(source, items_pool)
        if not items and any(w in source.split() for w in ("it", "them")):
            items = list(remembered_items)
        target, body, drawer = target_for(
            destination, previous_body, previous_drawer
        )
        if not items or target is None or body in items:
            unsupported = True
            break

        if drawer is not None and drawer_state.get(drawer) != "open":
            plan.append({"op": "open", "target": drawer})
            drawer_state[drawer] = "open"

        for item in items:
            item_words = words(item).split()
            grasp = (
                "rim" if "bowl" in item_words else
                "thin_edge" if "book" in item_words else "standard"
            )
            plan.append({
                "op": "place", "item": item,
                "target": target, "grasp": grasp,
            })
        remembered_items = list(items)
        previous_body = body
        if drawer is not None:
            previous_drawer = drawer

    if unsupported or not plan:
        api.fallback()
        return

    def move(point, steps, watch=None):
        command = {
            "op": "move",
            "xyz": np.asarray(point, dtype=float).tolist(),
            "steps": min(steps, max(1, int(api.remaining()))),
        }
        if watch is not None:
            command["watch"] = watch
        return api.attempt(command)

    def grip(closed, watch=None):
        command = {"op": "grip", "closed": bool(closed)}
        if watch is not None:
            command["watch"] = watch
        return api.attempt(command)

    def turn_stove(step):
        stove = step["target"]
        controls = [
            n for n in names
            if any(w in words(n).split() for w in ("switch", "knob", "button"))
            and owned(n, stove)
        ]
        if not controls:
            controls = [
                n for n in names
                if any(w in words(n).split()
                       for w in ("switch", "knob", "button"))
            ]
        control = (
            min(controls, key=lambda n: np.linalg.norm(pos(n) - pos(stove)))
            if controls else None
        )
        center = pos(control) if control else pos(stove) + [0., -0.105, 0.025]
        grip(False)
        move(center + [0., 0., 0.09], 12)
        move(center, 14)
        grip(True)
        sign = 1.0 if step["state"] == "on" else -1.0
        api.action([0., 0., 0., 0., 0., sign, 1.], steps=18)
        grip(False)
        move(np.asarray(api.eef(), dtype=float) + [0., 0., 0.12], 10)

    def plausibly_placed(step):
        p, q = pos(step["item"]), pos(step["target"])
        if not np.all(np.isfinite(p)) or not np.all(np.isfinite(q)):
            return False
        target_words = words(step["target"]).split()
        tolerance = (
            0.045 if "caddy" in target_words else
            0.09 if "basket" in target_words else 0.065
        )
        return (
            np.linalg.norm(p[:2] - q[:2]) < tolerance
            and -0.07 < p[2] - q[2] < 0.20
        )

    def estimated_cost(step):
        if step["op"] == "place":
            return 140
        if step["op"] == "stove":
            return 80
        return 180

    for index, step in enumerate(plan):
        if api.remaining() < 8:
            return
        if step["op"] == "stove":
            turn_stove(step)
            continue

        receipt = api.attempt(step)
        if step["op"] != "place":
            displacement = receipt.get("delta_xyz")
            if displacement is not None:
                travel = float(np.linalg.norm(np.asarray(displacement)))
                if not math.isfinite(travel):
                    return
            continue

        if plausibly_placed(step):
            continue

        cost = max(60, int(receipt.get("steps_used") or 140))
        reserve = sum(estimated_cost(s) for s in plan[index + 1:])
        if api.remaining() < cost + reserve + 8:
            return

        # Retry only the unresolved placement; completed operations retain
        # their requested order. The placement skill repairs acquisition.
        api.attempt(step)
        if not plausibly_placed(step):
            return
