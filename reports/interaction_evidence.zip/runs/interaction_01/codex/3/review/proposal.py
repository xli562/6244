import numpy as np
import math


def run(api):
    def words(value):
        value = str(value).lower()
        for char in "_-.,;:!?()":
            value = value.replace(char, " ")
        return " ".join(value.split())

    text = words(api.instruction)
    names = list(api.names())
    catalog = api.catalog()
    entities = [
        n for n in names
        if catalog.get(n, {}).get("kind") in ("item", "fixture")
    ]
    regions = [
        n for n in names if catalog.get(n, {}).get("kind") == "region"
    ]
    movable = [
        n for n in entities if catalog.get(n, {}).get("kind") == "item"
    ]

    def pos(name):
        return np.asarray(api.pos(name), dtype=float).copy()

    def base(name):
        tokens = words(name).split()
        while tokens and tokens[-1].isdigit():
            tokens.pop()
        return " ".join(tokens)

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug", "cup"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug",
            "yellow mug", "mug", "cup",
        ],
        "red coffee mug": ["red coffee mug", "red mug", "mug", "cup"],
        "black book": ["black book", "book"],
        "cream cheese": ["cream cheese box", "cream cheese"],
        "desk caddy": ["desk caddy", "caddy", "organizer"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["stove", "burner"],
        "moka pot": ["moka pot", "coffee pot"],
    }
    aliases = {}
    for name in entities:
        b = base(name)
        values = [b] + synonyms.get(b, [])
        if b:
            values.append(b.split()[-1])
        aliases[name] = sorted(set(values), key=len, reverse=True)

    def owned(region, body):
        current, seen = region, set()
        while current and current not in seen:
            if current == body:
                return True
            seen.add(current)
            current = catalog.get(current, {}).get("parent")
        return region.startswith(body + "_")

    def owner(region):
        current, seen = region, set()
        while current and current not in seen:
            seen.add(current)
            current = catalog.get(current, {}).get("parent")
            if current in entities:
                return current
        matches = [n for n in entities if region.startswith(n + "_")]
        return max(matches, key=len) if matches else None

    def direction(phrase):
        tokens = phrase.split()
        for token in tokens:
            if token in ("left", "right", "front", "back"):
                return token
            if token == "behind":
                return "back"
        return None

    def disambiguate(candidates, context):
        candidates = list(dict.fromkeys(candidates))
        if not candidates:
            return None
        if len(candidates) == 1:
            return candidates[0]

        d = direction(context)
        if d:
            markers = []
            for region in regions:
                rt = words(region).split()
                if d not in rt:
                    continue
                # Location markers must describe the candidate type, rather
                # than a compartment belonging to an unrelated fixture.
                if owner(region) in entities:
                    continue
                scores = [
                    len(set(base(n).split()) & set(rt)) for n in candidates
                ]
                if max(scores or [0]) > 0:
                    markers.append((max(scores), region))
            if markers:
                markers.sort(key=lambda pair: (
                    -pair[0], "init" not in words(pair[1]).split(),
                    len(pair[1]), pair[1],
                ))
                return api.nearest(markers[0][1], candidates)

            axis = 0 if d in ("left", "right") else 1
            sign = 1 if d in ("left", "front") else -1
            return min(candidates, key=lambda n: sign * pos(n)[axis])

        for level in ("top", "middle", "bottom"):
            if level in context.split():
                ranked = sorted(candidates, key=lambda n: pos(n)[2])
                index = {
                    "bottom": 0, "middle": len(ranked) // 2, "top": -1
                }[level]
                return ranked[index]
        return sorted(candidates)[0]

    def mentions(phrase, pool=None):
        tokens = phrase.split()
        pool = entities if pool is None else pool
        spans = {}
        for name in pool:
            for alias in aliases[name]:
                a = alias.split()
                for i in range(len(tokens) - len(a) + 1):
                    if tokens[i:i + len(a)] == a:
                        spans.setdefault((i, i + len(a)), []).append(name)

        occupied, accepted = set(), []
        for (start, end), candidates in sorted(
            spans.items(),
            key=lambda pair: (-(pair[0][1] - pair[0][0]), pair[0][0]),
        ):
            if any(i in occupied for i in range(start, end)):
                continue
            occupied.update(range(start, end))
            # Do not borrow a direction from an earlier coordinated object.
            left = start
            while left > 0 and start - left < 4:
                if tokens[left - 1] in ("and", "then"):
                    break
                left -= 1
            right = end
            while right < len(tokens) and right - end < 4:
                if tokens[right] in ("and", "then"):
                    break
                right += 1
            context = " ".join(tokens[left:right])
            candidates = list(dict.fromkeys(candidates))
            if (
                len(candidates) > 1
                and direction(context) is None
                and any(t in context.split() for t in ("both", "all"))
            ):
                for name in sorted(candidates):
                    accepted.append((start, name))
            else:
                accepted.append((start, disambiguate(candidates, context)))
        return list(dict.fromkeys(n for _, n in sorted(accepted) if n))

    def drawer_region(phrase, previous=None):
        found = mentions(phrase)
        owners = [
            n for n in found
            if "cabinet" in words(n).split() or "drawer" in words(n).split()
        ]
        if not owners and previous:
            p = owner(previous)
            if p:
                owners = [p]
        if not owners:
            owners = [
                n for n in entities
                if "cabinet" in words(n).split()
                or "drawer" in words(n).split()
            ]
        level = next(
            (s for s in ("top", "middle", "bottom")
             if s in phrase.split()), None
        )
        options = [
            r for r in regions
            if any(owned(r, n) for n in owners)
            and "side" not in words(r).split()
            and "init" not in words(r).split()
            and any(s in words(r).split()
                    for s in ("top", "middle", "bottom"))
            and (level is None or level in words(r).split())
        ]
        if level is None and previous in options:
            return previous
        if len(options) == 1:
            return options[0]
        if level is None:
            bottom = [r for r in options if "bottom" in words(r).split()]
            if len(bottom) == 1:
                return bottom[0]
        return None

    def target_for(phrase, previous_body, previous_drawer):
        if "drawer" in phrase.split():
            region = drawer_region(phrase, previous_drawer)
            return (
                (region, owner(region), region)
                if region else (None, None, None)
            )

        found = mentions(phrase)
        body = found[-1] if found else previous_body
        if body is None:
            return None, None, None

        # "In it" after an explicit drawer operation refers to that drawer.
        inside = any(t in phrase.split() for t in ("in", "inside", "into"))
        if (
            not found and inside and previous_drawer
            and body == owner(previous_drawer)
            and "compartment" not in phrase
            and direction(phrase) is None
        ):
            return previous_drawer, body, previous_drawer

        d = direction(phrase)
        outside = any(s in phrase for s in (
            "next to", "beside", "outside", "in front of", "behind",
            "to the left of", "to the right of",
            "on the left of", "on the right of",
            "left side of", "right side of",
        ))
        compartment = "compartment" in phrase or "section" in phrase
        if d and (outside or inside or compartment):
            relation = "outside" if outside and not compartment else "inside"
            try:
                target = api.relative_target(body, d, relation)
            except (ValueError, TypeError):
                return None, None, None
            return target, body, None
        if outside:
            # An unspecified adjacent location cannot safely be replaced
            # with the reference object's own position.
            return None, None, None

        own = [
            r for r in regions
            if owned(r, body) and "init" not in words(r).split()
        ]
        on_top = "on top" in phrase or "top of" in phrase
        preferred = (
            ["top side", "top region"] if on_top else
            ["contain region", "inside region"] if inside else
            ["cook region", "top side", "top region"]
        )
        for suffix in preferred:
            options = [r for r in own if words(r).endswith(suffix)]
            if len(options) == 1:
                return options[0], body, None
        return body, body, None

    tokens = text.split()
    verbs = {
        "put", "place", "move", "open", "close", "pick", "take",
        "turn", "switch", "push", "pull", "stack", "insert",
    }
    starts = [i for i, t in enumerate(tokens) if t in verbs]
    if not starts or any(t in tokens for t in ("before", "after", "until")):
        api.fallback()
        return
    clauses = [
        tokens[i:starts[k + 1] if k + 1 < len(starts) else len(tokens)]
        for k, i in enumerate(starts)
    ]

    plan = []
    remembered_items = []
    previous_body = None
    previous_drawer = None
    drawer_state = {}
    unsupported = False

    for clause_index, clause in enumerate(clauses):
        while clause and clause[-1] in ("and", "then"):
            clause.pop()
        verb = clause[0]
        phrase = " ".join(clause[1:])

        if verb in ("pick", "take"):
            remembered_items = mentions(phrase, movable)
            # Defer pickup only when the next operation transports it.
            if (
                not remembered_items
                or clause_index + 1 == len(clauses)
                or clauses[clause_index + 1][0]
                not in ("put", "place", "move", "insert", "stack")
            ):
                unsupported = True
                break
            continue

        if verb in ("open", "close"):
            region = drawer_region(phrase, previous_drawer)
            if region is None:
                unsupported = True
                break
            plan.append({"op": verb, "target": region})
            drawer_state[region] = verb
            previous_drawer = region
            previous_body = owner(region)
            continue

        # Unsupported mechanisms use the previous physical policy, before
        # any part of this plan has changed the scene.
        if verb not in ("put", "place", "move", "insert", "stack"):
            unsupported = True
            break

        split = next(
            (i for i, t in enumerate(clause[1:], 1)
             if t in ("in", "into", "inside", "on", "onto",
                      "to", "beside", "behind", "under")), None
        )
        if split is None:
            unsupported = True
            break
        source = " ".join(clause[1:split])
        destination = " ".join(clause[split:])
        if "under" in destination.split():
            unsupported = True
            break

        items = mentions(source, movable)
        if not items and any(t in source.split() for t in ("it", "them")):
            items = list(remembered_items)
        target, body, drawer = target_for(
            destination, previous_body, previous_drawer
        )
        if not items or target is None or body in items:
            unsupported = True
            break

        if drawer and drawer_state.get(drawer) != "open":
            plan.append({"op": "open", "target": drawer})
            drawer_state[drawer] = "open"

        for item in items:
            item_words = words(item).split()
            grasp = (
                "rim" if "bowl" in item_words else
                "thin_edge" if "book" in item_words else "standard"
            )
            plan.append({
                "op": "place", "item": item,
                "target": target, "grasp": grasp,
            })
        remembered_items = list(items)
        previous_body = body
        previous_drawer = drawer

    if unsupported or not plan:
        api.fallback()
        return

    def plausible(step, receipt):
        p, q = pos(step["item"]), pos(step["target"])
        if not np.all(np.isfinite(p)) or not np.all(np.isfinite(q)):
            return False
        # Recompute from live positions: the target may itself have moved.
        gap = float(np.linalg.norm(p[:2] - q[:2]))
        target_words = words(step["target"]).split()
        tolerance = 0.065
        if "caddy" in target_words:
            tolerance = 0.045
        elif "basket" in target_words:
            tolerance = 0.09
        return gap < tolerance and -0.07 < float(p[2] - q[2]) < 0.20

    for index, step in enumerate(plan):
        if api.remaining() < 8:
            return
        receipt = api.attempt(step)

        if step["op"] != "place":
            delta = receipt.get("delta_xyz")
            if delta is not None:
                travel = float(np.linalg.norm(np.asarray(delta, dtype=float)))
                if not math.isfinite(travel):
                    return
            # No motion can mean an already-open or already-closed drawer.
            # The receipt does not justify blindly repeating that action.
            continue

        if plausible(step, receipt):
            continue

        cost = max(35, int(receipt.get("steps_used") or 70))
        reserve = sum(
            45 if later["op"] != "place" else 75
            for later in plan[index + 1:]
        )
        if api.remaining() < cost + reserve + 8:
            return

        # Retry the unresolved placement only. The placement skill handles
        # grasp repair, including rim and thin-edge acquisition.
        second = api.attempt(step)
        if not plausible(step, second):
            return
