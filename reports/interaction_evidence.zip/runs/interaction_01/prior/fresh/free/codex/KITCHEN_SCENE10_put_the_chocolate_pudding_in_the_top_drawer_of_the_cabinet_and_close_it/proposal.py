def run(api):
    import numpy as np

    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [
        n for n in names
        if n.rsplit("_", 1)[-1].isdigit()
        and "region" not in n and not n.endswith("_side")
    ]

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug"
        ],
        "red coffee mug": ["red mug"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["stove"],
        "wooden cabinet": ["cabinet"],
        "white cabinet": ["cabinet"],
        "desk caddy": ["caddy"],
        "black book": ["book"],
        "cream cheese": ["cream cheese box"],
    }

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        return [base] + synonyms.get(base, [])

    def mentions(s):
        hits = []
        padded = " " + s + " "
        for body in bodies:
            for alias in aliases(body):
                needle = " " + alias + " "
                start = padded.find(needle)
                while start >= 0:
                    hits.append((start, start + len(needle) - 1, body))
                    start = padded.find(needle, start + 1)
        # Prefer complete names over generic words within those names.
        hits = [
            h for h in hits
            if not any(
                q[0] <= h[0] and q[1] >= h[1]
                and q[1] - q[0] > h[1] - h[0]
                for q in hits
            )
        ]
        groups = {}
        for a, b, body in hits:
            groups.setdefault((a, b), []).append(body)
        result = []
        for (a, b), candidates in sorted(groups.items()):
            candidates = list(dict.fromkeys(candidates))
            if len(candidates) == 1:
                chosen = candidates[0]
            else:
                prefix = padded[max(0, a - 25):a].split()
                direction = next(
                    (w for w in reversed(prefix)
                     if w in ("left", "right", "front", "back")),
                    None,
                )
                bases = [c.rsplit("_", 1)[0] for c in candidates]
                markers = [
                    n for n in names
                    if "region" in n and direction
                    and direction in n
                    and any(base in n for base in bases)
                ]
                if len(markers) != 1:
                    return None
                chosen = api.nearest(markers[0], candidates)
            if chosen not in result:
                result.append(chosen)
        return result

    def region(body, suffix):
        exact = body + "_" + suffix
        return exact if exact in names else None

    def drawer_region(s, cabinet):
        levels = [w for w in ("top", "middle", "bottom") if w in s.split()]
        if len(levels) != 1:
            return None
        return region(cabinet, levels[0] + "_region")

    def style(item):
        if "bowl" in item:
            return "rim"
        if "book" in item:
            return "thin_edge"
        return "standard"

    # Leave unsupported articulated-object operations to the previous policy.
    if any(w in text for w in ("turn on", "turn off", "switch on", "switch off")):
        return api.fallback()

    words = text.replace(",", " ").replace(".", " ").split()
    verbs = {"put", "place", "move", "insert", "stack", "open", "close", "shut"}
    starts = [i for i, w in enumerate(words) if w in verbs]
    if not starts:
        return api.fallback()

    clauses = [
        " ".join(words[a:(starts[k + 1] if k + 1 < len(starts) else len(words))])
        for k, a in enumerate(starts)
    ]
    cabinets = [b for b in bodies if "cabinet" in b]
    full_mentions = mentions(text)
    if full_mentions is None:
        return api.fallback()
    named_cabinets = [b for b in full_mentions if b in cabinets]
    cabinet = (
        named_cabinets[0] if len(named_cabinets) == 1
        else cabinets[0] if len(cabinets) == 1 else None
    )

    plan = []
    active_drawer = None
    opened = set()
    last_items = []
    last_target = None

    # A preceding "pick up X" can establish the object for "put it ...".
    if starts[0]:
        preceding = mentions(" ".join(words[:starts[0]]))
        if preceding:
            last_items = [b for b in preceding if b not in cabinets]

    for clause in clauses:
        verb = clause.split()[0]
        if verb in ("open", "close", "shut"):
            if "drawer" not in clause and active_drawer is None:
                return api.fallback()
            target = (
                drawer_region(clause, cabinet) if cabinet else None
            ) or active_drawer
            if target is None:
                return api.fallback()
            operation = "open" if verb == "open" else "close"
            plan.append(("drawer", target, operation))
            active_drawer = target
            if operation == "open":
                opened.add(target)
            else:
                opened.discard(target)
            continue

        padded = " " + clause + " "
        separators = [
            " into ", " inside ", " onto ", " on top of ",
            " on ", " in ", " to ", " next to ",
        ]
        splits = [
            (padded.find(sep), -len(sep), sep)
            for sep in separators if sep in padded
        ]
        if not splits:
            return api.fallback()
        index, _, sep = min(splits)
        source_text = padded[:index]
        destination_text = padded[index + len(sep):]
        items = mentions(source_text)
        targets = mentions(destination_text)
        if items is None or targets is None:
            return api.fallback()
        if not items and any(
            w in source_text.split() for w in ("it", "them")
        ):
            items = last_items
        if not items:
            return api.fallback()

        if "drawer" in destination_text:
            target = (
                drawer_region(destination_text, cabinet) if cabinet else None
            ) or active_drawer
            if target is None:
                return api.fallback()
            # Insertion requires an accessible drawer, even when "open"
            # is implicit in the instruction.
            if target not in opened:
                plan.append(("drawer", target, "open"))
                opened.add(target)
            active_drawer = target
        else:
            if not targets:
                if last_target and "it" in destination_text.split():
                    target = last_target
                else:
                    return api.fallback()
            else:
                reference = targets[-1]
                directions = [
                    w for w in destination_text.split()
                    if w in ("left", "right", "front", "back")
                ]
                if directions:
                    direction = directions[-1]
                    outside = (
                        "next to" in clause or "beside" in clause
                        or "outside" in clause
                        or "of" in destination_text.split()
                    )
                    relation = "outside" if outside else "inside"
                    target = api.relative_target(reference, direction, relation)
                    if not target:
                        return api.fallback()
                    if "plate" in reference:
                        plates = [b for b in bodies if "plate" in b]
                        target = api.nearest(target, plates)
                elif reference in cabinets:
                    target = region(reference, "top_side")
                    if target is None:
                        return api.fallback()
                elif sep in (" into ", " inside ", " in "):
                    target = region(reference, "contain_region") or reference
                elif "stove" in reference:
                    target = region(reference, "cook_region") or reference
                else:
                    target = reference

        for item in items:
            if item == target or item in cabinets:
                return api.fallback()
            plan.append(("place", item, target))
        last_items = items
        last_target = target

    for operation, first, second in plan:
        if operation == "drawer":
            result = api.drawer(first, second)
        else:
            result = api.place_with(first, second, style(first))
        if result is False:
            return
