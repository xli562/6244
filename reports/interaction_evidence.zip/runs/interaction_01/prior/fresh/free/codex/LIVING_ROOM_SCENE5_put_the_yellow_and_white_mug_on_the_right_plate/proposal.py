def run(api):
    import numpy as np

    text = " ".join(
        api.instruction.lower().replace("-", " ").replace(",", " , ").split()
    )
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n
        and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    def normalize(s):
        return " ".join(s.replace("_", " ").replace("-", " ").split())

    synonyms = {
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug"
        ],
        "porcelain mug": ["white mug"],
        "red coffee mug": ["red mug"],
        "akita black bowl": ["black bowl", "bowl"],
        "black book": ["book"],
        "desk caddy": ["caddy"],
        "white cabinet": ["cabinet"],
        "wooden cabinet": ["cabinet"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["stove"],
        "cream cheese": ["cream cheese box"],
        "moka pot": ["coffee pot"],
    }

    def aliases(n):
        base = normalize(n.rsplit("_", 1)[0])
        result = [base] + synonyms.get(base, [])
        if "plate" in base:
            result.append("plate")
        if "basket" in base:
            result.append("basket")
        return list(set(result))

    def mentions(s, pool=None):
        """Longest overlapping phrase wins; retain ambiguity for resolution."""
        pool = bodies if pool is None else pool
        padded = " " + s + " "
        hits = []
        for n in pool:
            for alias in aliases(n):
                needle = " " + alias + " "
                start = 0
                while True:
                    p = padded.find(needle, start)
                    if p < 0:
                        break
                    hits.append((p, p + len(needle) - 1, n))
                    start = p + 1
        hits.sort(key=lambda h: (-(h[1] - h[0]), h[0]))
        selected = []
        for h in hits:
            if any(
                h[0] < old[1] and old[0] < h[1]
                and (h[0], h[1]) != (old[0], old[1])
                for old in selected
            ):
                continue
            if h not in selected:
                selected.append(h)
        return sorted(selected)

    def unique(seq):
        return list(dict.fromkeys(seq))

    def region_for(body, fragments):
        for fragment in fragments:
            exact = body + "_" + fragment
            if exact in names:
                return exact
            matches = [
                n for n in names
                if n.startswith(body + "_") and fragment in n
            ]
            if len(matches) == 1:
                return matches[0]
        return None

    def side_of(s):
        for word in s.split():
            if word in ("left", "right", "front", "back"):
                return word
        return None

    def resolve_body(candidates, description):
        candidates = unique(candidates)
        if len(candidates) == 1:
            return candidates[0]
        if not candidates:
            return None
        side = side_of(description)
        if side:
            markers = [
                n for n in names
                if "region" in n and side in n.split("_")
                and "init" not in n
            ]
            bases = [normalize(n.rsplit("_", 1)[0]) for n in candidates]
            markers = [
                n for n in markers
                if any(
                    any(w in n.split("_") for w in base.split())
                    for base in bases
                )
            ]
            if len(markers) == 1:
                return api.nearest(markers[0], candidates)
        return None

    def drawer_region(s, previous=None):
        level = next(
            (w for w in ("top", "middle", "bottom") if w in s.split()),
            None,
        )
        if level is None and previous is not None:
            return previous
        candidates = [
            n for n in names
            if "region" in n and "init" not in n
            and ("cabinet" in n or "drawer" in n)
            and (level is None or level in n.split("_"))
            and any(w in n.split("_") for w in ("top", "middle", "bottom"))
        ]
        fixture_hits = [
            h[2] for h in mentions(s)
            if "cabinet" in h[2] or "drawer" in h[2]
        ]
        if fixture_hits:
            candidates = [
                n for n in candidates
                if any(n.startswith(b + "_") for b in fixture_hits)
            ]
        return candidates[0] if len(candidates) == 1 else None

    def destination(s, previous_drawer):
        if "drawer" in s:
            return drawer_region(s, previous_drawer)

        hits = mentions(s)
        if not hits:
            if previous_drawer and any(
                w in s.split() for w in ("it", "inside", "there")
            ):
                return previous_drawer
            return None

        # The final noun phrase names the destination/reference.
        last = max(h[0] for h in hits)
        body = resolve_body([h[2] for h in hits if h[0] == last], s)
        if body is None:
            return None

        side = side_of(s)
        outside = any(
            p in s for p in (
                "next to", "beside", "outside", "to the left of",
                "to the right of", "in front of", "behind",
            )
        )
        if "behind" in s and side is None:
            side = "back"
        if side and ("caddy" in body or "cabinet" in body or outside):
            relation = "outside" if outside else "inside"
            return api.relative_target(body, side, relation)

        if "cabinet" in body and (
            "on" in s.split() or "top" in s.split()
        ):
            return region_for(body, ["top_side"])
        if "stove" in body:
            return region_for(body, ["cook_region"]) or body
        if any(w in s.split() for w in ("in", "into", "inside")):
            return region_for(body, ["contain_region"]) or body
        return body

    # Unsupported manipulation stays with the previous physical policy.
    if any(p in text for p in (
        "turn on", "turn off", "switch on", "switch off",
        "rotate", "pour", "push",
    )):
        return api.fallback()

    words = text.split()
    verbs = {"put", "place", "stack", "open", "close"}
    starts = [i for i, w in enumerate(words) if w in verbs]
    if not starts:
        return api.fallback()

    clauses = [
        " ".join(words[start:starts[i + 1] if i + 1 < len(starts) else len(words)])
        for i, start in enumerate(starts)
    ]
    plan = []
    previous_drawer = None
    previous_items = []

    for clause in clauses:
        verb = clause.split()[0]
        if verb in ("open", "close"):
            region = drawer_region(clause, previous_drawer)
            if region is None:
                return api.fallback()
            plan.append(("drawer", region, verb))
            previous_drawer = region
            continue

        # Split at the destination preposition, after the movable noun phrase.
        tokens = clause.split()
        split_at = next(
            (
                i for i in range(1, len(tokens))
                if tokens[i] in ("on", "onto", "in", "into", "inside",
                                 "to", "beside", "under")
            ),
            None,
        )
        if split_at is None:
            return api.fallback()

        source = " ".join(tokens[1:split_at])
        target_text = " ".join(tokens[split_at:])
        target = destination(target_text, previous_drawer)
        if target is None:
            return api.fallback()

        hits = mentions(source)
        items = []
        for location in sorted(set((h[0], h[1]) for h in hits)):
            candidates = [
                h[2] for h in hits if (h[0], h[1]) == location
            ]
            if len(candidates) > 1 and any(
                w in source.split() for w in ("both", "all")
            ):
                items.extend(candidates)
            else:
                item = resolve_body(candidates, source)
                if item is None:
                    return api.fallback()
                items.append(item)
        items = unique(items)
        if not items and any(w in source.split() for w in ("it", "them")):
            items = previous_items
        if not items:
            return api.fallback()
        for item in items:
            if target == item or target.startswith(item + "_"):
                return api.fallback()
            plan.append(("place", item, target))
        previous_items = items

    for kind, first, second in plan:
        if kind == "drawer":
            api.drawer(first, second)
        else:
            grasp = (
                "rim" if "bowl" in first
                else "thin_edge" if "book" in first
                else "standard"
            )
            result = api.place_with(first, second, grasp)
            if result is False:
                return
