def run(api):
    import numpy as np

    def normalize(text):
        return " ".join(
            text.lower().replace("_", " ").replace("-", " ")
            .replace(",", " ").replace(".", " ").split()
        )

    text = normalize(api.instruction)
    names = list(api.names())
    bodies = [
        n for n in names
        if n.rsplit("_", 1)[-1].isdigit()
        and "region" not in n and not n.endswith("_side")
    ]
    regions = [n for n in names if n not in bodies]

    alias_map = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug", "mug"
        ],
        "red coffee mug": ["red mug", "coffee mug", "mug"],
        "cream cheese": ["cream cheese box", "cream cheese"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["stove"],
        "wooden two layer shelf": ["cabinet shelf", "shelf"],
        "white cabinet": ["cabinet"],
        "desk caddy": ["desk caddy", "caddy"],
    }

    def aliases(name):
        base = normalize(name.rsplit("_", 1)[0])
        result = [base] + alias_map.get(base, [])
        for noun in (
            "book", "bowl", "mug", "plate", "basket", "cabinet",
            "shelf", "caddy", "bottle", "can", "pan",
        ):
            if noun in base.split():
                result.append(noun)
        return result

    def contains(phrase, fragment):
        return " " + fragment + " " in " " + phrase + " "

    def score(name, phrase):
        return max(
            [len(a.split()) * 100 + len(a)
             for a in aliases(name) if contains(phrase, a)] or [0]
        )

    def resolve(phrase, pool=None):
        pool = bodies if pool is None else pool
        scored = [(score(n, phrase), n) for n in pool]
        best = max([s for s, _ in scored] or [0])
        candidates = [n for s, n in scored if s == best and s > 0]
        if not candidates:
            return None
        if len(candidates) == 1:
            return candidates[0]

        directions = [
            d for d in ("left", "right", "front", "back")
            if contains(phrase, d)
        ]
        if len(directions) == 1:
            direction = directions[0]
            markers = [
                r for r in regions
                if direction in normalize(r).split()
            ]
            # Location labels identify the intended object without assuming
            # that world x corresponds to the user's left or right.
            ranked = []
            for marker in markers:
                label = normalize(marker)
                overlap = max(
                    len(a.split()) * 100 + len(a)
                    for n in candidates for a in aliases(n)
                    if contains(label, a)
                ) if any(
                    contains(label, a)
                    for n in candidates for a in aliases(n)
                ) else 0
                if overlap:
                    ranked.append((overlap, marker))
            if ranked:
                top = max(s for s, _ in ranked)
                matching = [r for s, r in ranked if s == top]
                if len(matching) == 1:
                    return api.nearest(matching[0], candidates)
        return None

    def region(body, suffixes):
        for suffix in suffixes:
            exact = body + "_" + suffix
            if exact in names:
                return exact
        return None

    def drawer_region(phrase):
        levels = [
            level for level in ("top", "middle", "bottom")
            if contains(phrase, level)
        ]
        cabinets = [n for n in bodies if "cabinet" in n]
        cabinet = resolve(phrase, cabinets)
        if cabinet is None and len(cabinets) == 1:
            cabinet = cabinets[0]
        if cabinet is None:
            return None
        possible = [
            region(cabinet, [level + "_region"])
            for level in (levels or ("top", "middle", "bottom"))
        ]
        possible = [r for r in possible if r is not None]
        return possible[0] if len(possible) == 1 else None

    def destination(phrase, relation, previous_drawer):
        if "drawer" in phrase:
            return drawer_region(phrase) or previous_drawer
        if phrase.strip() in ("it", "there", "inside it"):
            return previous_drawer

        body = resolve(phrase)
        if body is None:
            return None

        if relation in ("under", "underneath", "below"):
            return region(body, ["bottom_region", "lower_region"])

        if "on top" in phrase or relation == "on top of":
            return region(body, ["top_side", "top_region"]) or body

        direction = next(
            (d for d in ("left", "right", "front", "back")
             if contains(phrase, d)),
            None,
        )
        fixture = any(k in body for k in ("caddy", "cabinet", "shelf"))
        if direction and fixture:
            outside = (
                relation in ("next to", "beside", "to")
                or "next to" in phrase or "side of" in phrase
            )
            return api.relative_target(
                body, direction, "outside" if outside else "inside"
            )

        if relation in ("in", "into", "inside", "inside of"):
            return region(body, ["contain_region", "bottom_region"]) or body
        if "stove" in body:
            return region(body, ["cook_region"]) or body
        if "cabinet" in body or "shelf" in body:
            return region(body, ["top_side", "top_region"]) or body
        return body

    # Build the complete plan before issuing any physical commands.
    words = text.split()
    verbs = {"pick", "put", "place", "move", "open", "close", "turn"}
    starts = [i for i, word in enumerate(words) if word in verbs]
    if not starts:
        return api.fallback()
    clauses = []
    for j, start in enumerate(starts):
        end = starts[j + 1] if j + 1 < len(starts) else len(words)
        chunk = words[start:end]
        while chunk and chunk[-1] in ("and", "then"):
            chunk.pop()
        clauses.append(" ".join(chunk))

    plan = []
    pending = None
    last_drawer = None

    for clause in clauses:
        verb = clause.split()[0]
        if verb == "turn":
            return api.fallback()

        if verb in ("open", "close"):
            if "drawer" not in clause:
                return api.fallback()
            target = drawer_region(clause)
            if target is None and any(
                contains(clause, p) for p in ("it", "the drawer")
            ):
                target = last_drawer
            if target is None:
                return api.fallback()
            plan.append(("drawer", target, verb))
            last_drawer = target
            continue

        if verb == "pick":
            pending = resolve(clause)
            if pending is None:
                return api.fallback()
            continue

        separators = (
            "on top of", "inside of", "next to", "underneath",
            "inside", "into", "under", "below", "beside", "on", "in", "to",
        )
        hits = []
        padded = " " + clause + " "
        for prep in separators:
            token = " " + prep + " "
            index = padded.find(token)
            if index >= 0:
                hits.append((index, -len(prep), prep))
        if not hits:
            return api.fallback()
        index, _, prep = min(hits)
        source = padded[:index].strip()
        target_phrase = padded[index + len(prep) + 2:].strip()

        item = resolve(source)
        if item is None and (
            contains(source, "it") or contains(source, "them")
        ):
            item = pending
        if item is None:
            return api.fallback()

        target = destination(target_phrase, prep, last_drawer)
        if target is None or target == item:
            return api.fallback()

        grasp = (
            "thin_edge" if "book" in item
            else "rim" if "bowl" in item
            else "standard"
        )
        plan.append(("place", item, target, grasp))
        pending = item

    if not plan or clauses[-1].startswith("pick "):
        return api.fallback()

    for operation in plan:
        if operation[0] == "drawer":
            api.drawer(operation[1], operation[2])
        else:
            api.place_with(operation[1], operation[2], operation[3])
