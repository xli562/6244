def run(api):
    import numpy as np

    text = " ".join(
        api.instruction.lower().replace("-", " ").replace(",", " , ").split()
    )
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug"],
        "white yellow mug": [
            "white and yellow mug", "yellow and white mug", "yellow mug", "mug"
        ],
        "red coffee mug": ["red mug", "coffee mug", "mug"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "black book": ["black book", "book"],
        "desk caddy": ["desk caddy", "caddy"],
        "flat stove": ["flat stove", "stove"],
        "white cabinet": ["white cabinet", "cabinet"],
        "cream cheese": ["cream cheese", "cream cheese box"],
    }

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        return list(set([base] + synonyms.get(base, [])))

    def mentions(phrase, pool=None):
        """Keep specific mentions in preference to overlapping generic aliases."""
        padded = " " + phrase + " "
        hits = []
        for name in bodies if pool is None else pool:
            for alias in aliases(name):
                needle = " " + alias + " "
                start = padded.find(needle)
                while start >= 0:
                    hits.append((start, start + len(needle), name, len(alias)))
                    start = padded.find(needle, start + 1)
        hits.sort(key=lambda h: (-h[3], h[0]))
        selected = []
        for hit in hits:
            if not any(
                hit[0] < old[1] and old[0] < hit[1] and hit[3] < old[3]
                for old in selected
            ):
                selected.append(hit)
        selected.sort(key=lambda h: h[0])
        result = []
        for hit in selected:
            if hit[2] not in result:
                result.append(hit[2])
        return result

    def region_for(body, fragments):
        for fragment in fragments:
            exact = body + "_" + fragment
            if exact in names:
                return exact
            matches = [
                n for n in names
                if n.startswith(body + "_") and fragment in n
                and "init_region" not in n
            ]
            if len(matches) == 1:
                return matches[0]
        return None

    def resolve(phrase, pool=None):
        matches = mentions(phrase, pool)
        if len(matches) == 1:
            return matches[0]
        if not matches:
            return None
        # Resolve repeated objects through their perceived spatial markers.
        directions = [
            d for d in ("left", "right", "front", "back")
            if d in phrase.split()
        ]
        if len(directions) == 1:
            direction = directions[0]
            markers = [
                n for n in names
                if "region" in n and direction in n.split("_")
                and any(
                    b.rsplit("_", 1)[0] in n for b in matches
                )
            ]
            if len(markers) == 1:
                return api.nearest(markers[0], matches)
        return None

    def drawer_region(phrase, previous=None):
        level = next(
            (v for v in ("top", "middle", "bottom") if v in phrase.split()),
            None,
        )
        fixtures = [
            b for b in bodies if "cabinet" in b or "drawer" in b
        ]
        fixture = resolve(phrase, fixtures)
        if fixture is None and len(fixtures) == 1:
            fixture = fixtures[0]
        if level is None and previous is not None:
            return previous
        if fixture and level:
            return region_for(fixture, [level + "_region"])
        candidates = [
            n for n in names if "region" in n
            and "init_region" not in n
            and (level is None or level in n.split("_"))
            and ("drawer" in n or "cabinet" in n)
            and any(v in n.split("_") for v in ("top", "middle", "bottom"))
        ]
        return candidates[0] if len(candidates) == 1 else None

    def destination(phrase, previous_drawer):
        words = phrase.split()
        if "drawer" in words:
            return drawer_region(phrase, previous_drawer)

        body = resolve(phrase)
        if body is None:
            return None

        direction = next(
            (d for d in ("left", "right", "front", "back") if d in words),
            None,
        )
        outside = any(
            marker in phrase
            for marker in ("next to", "beside", "to the left of",
                           "to the right of", "in front of", "behind")
        )
        if "behind" in words:
            direction = "back"
        fixture = any(k in body for k in ("caddy", "cabinet", "basket"))
        if direction and (outside or fixture):
            return api.relative_target(
                body, direction, "outside" if outside else "inside"
            )

        inside = any(w in words for w in ("in", "into", "inside"))
        if inside:
            return region_for(body, ["contain_region", "inside_region"]) or body
        if "cabinet" in body or "drawer" in body:
            return region_for(body, ["top_side", "top_region"]) or body
        if "stove" in body:
            return region_for(body, ["cook_region"]) or body
        return body

    # Plan first, so an unsupported command can use the original policy
    # without repeating any already executed physical operations.
    verbs = {
        "pick", "take", "grab", "put", "place", "move", "insert",
        "open", "close", "shut", "turn", "switch", "push", "pull",
        "stack", "slide",
    }
    words = text.split()
    starts = [i for i, w in enumerate(words) if w in verbs]
    if not starts:
        return api.fallback()
    clauses = [
        words[start:(starts[j + 1] if j + 1 < len(starts) else len(words))]
        for j, start in enumerate(starts)
    ]

    plan = []
    held = []
    last_drawer = None
    unsupported = False

    for tokens in clauses:
        verb = tokens[0]
        phrase = " ".join(tokens[1:]).strip(" ,")
        if verb in ("pick", "take", "grab"):
            held = mentions(phrase)
            if not held:
                unsupported = True
                break
            continue

        if verb in ("open", "close", "shut"):
            region = drawer_region(phrase, last_drawer)
            if region is None:
                unsupported = True
                break
            last_drawer = region
            plan.append(("drawer", region, "open" if verb == "open" else "close"))
            continue

        if verb not in ("put", "place", "move", "insert"):
            unsupported = True
            break

        # Destination prepositions begin after the object description.
        split = next(
            (i for i, w in enumerate(tokens[1:], 1)
             if w in ("in", "into", "inside", "on", "onto", "next",
                      "beside", "behind", "to")),
            None,
        )
        if split is None:
            unsupported = True
            break
        source_text = " ".join(tokens[1:split])
        target_text = " ".join(tokens[split:])
        items = mentions(source_text)
        if not items and any(
            p in source_text.split() for p in ("it", "them", "these", "those")
        ):
            items = held[:]
        if len(items) > 1 and not any(
            p in source_text.split() for p in ("and", "both", "all", "them")
        ):
            item = resolve(source_text, items)
            items = [item] if item else []

        target = destination(target_text, last_drawer)
        if not items or target is None or target in items:
            unsupported = True
            break
        if "drawer" in target_text:
            last_drawer = target
        for item in items:
            plan.append(("place", item, target))
        held = items

    if unsupported or not plan:
        return api.fallback()

    for kind, first, second in plan:
        if kind == "drawer":
            api.drawer(first, second)
        else:
            grasp = (
                "rim" if "bowl" in first
                else "thin_edge" if "book" in first
                else "standard"
            )
            api.place_with(first, second, grasp)
