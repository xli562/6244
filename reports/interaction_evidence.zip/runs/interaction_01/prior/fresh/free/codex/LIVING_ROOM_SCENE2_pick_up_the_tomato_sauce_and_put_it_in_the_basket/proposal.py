def run(api):
    import numpy as np

    text = " ".join(
        api.instruction.lower().replace("-", " ").replace(",", " ").split()
    )
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug", "mug"
        ],
        "red coffee mug": ["red mug", "coffee mug", "mug"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["stove"],
        "desk caddy": ["caddy"],
        "white cabinet": ["cabinet"],
        "wooden cabinet": ["cabinet"],
        "cream cheese": ["cream cheese box"],
    }

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        result = [base] + synonyms.get(base, [])
        words = base.split()
        if words and words[-1] in (
            "bowl", "plate", "book", "basket", "cabinet", "mug"
        ):
            result.append(words[-1])
        return list(set(result))

    def mentions(fragment, pool=None):
        pool = bodies if pool is None else pool
        padded = " " + fragment + " "
        hits = []
        for name in pool:
            for alias in aliases(name):
                needle = " " + alias + " "
                start = padded.find(needle)
                while start >= 0:
                    hits.append((start, start + len(needle) - 1, name, alias))
                    start = padded.find(needle, start + 1)
        # Specific phrases take precedence over their generic suffixes.
        hits = [
            h for h in hits
            if not any(
                q[0] <= h[0] and q[1] >= h[1]
                and len(q[3]) > len(h[3])
                for q in hits
            )
        ]
        hits.sort(key=lambda h: (h[0], -len(h[3]), h[2]))
        result = []
        for h in hits:
            if h[2] not in result:
                result.append(h[2])
        return result

    def resolve(fragment, pool=None):
        candidates = mentions(fragment, pool)
        if len(candidates) == 1:
            return candidates[0]
        if not candidates:
            return None
        directions = [
            d for d in ("left", "right", "front", "back")
            if d in fragment.split()
        ]
        for direction in directions:
            markers = [
                n for n in names if "region" in n
                and direction in n.split("_")
                and any(
                    c.rsplit("_", 1)[0] in n
                    or c.split("_")[0] in n
                    for c in candidates
                )
            ]
            if len(markers) == 1:
                return api.nearest(markers[0], candidates)
        return None

    def drawer_region(fragment):
        levels = [
            level for level in ("top", "middle", "bottom")
            if level in fragment.split()
        ]
        if not levels:
            levels = [
                level for level in ("top", "middle", "bottom")
                if level in text.split()
            ]
        cabinet = resolve(fragment, [n for n in bodies if "cabinet" in n])
        candidates = [
            n for n in names
            if "region" in n
            and ("drawer" in n or "cabinet" in n)
            and any(level in n.split("_") for level in
                    (levels or ["top", "middle", "bottom"]))
            and (cabinet is None or n.startswith(cabinet + "_"))
            and "init" not in n
        ]
        return candidates[0] if len(candidates) == 1 else None

    def target_for(fragment):
        if "drawer" in fragment:
            return drawer_region(fragment)

        reference = resolve(fragment)
        if reference is None:
            return None

        direction = next(
            (d for d in ("left", "right", "front", "back")
             if d in fragment.split()), None
        )
        fixture = any(k in reference for k in ("caddy", "cabinet", "basket"))
        if direction and fixture:
            outside = any(
                phrase in fragment for phrase in
                ("next to", "beside", "to the left of", "to the right of",
                 "in front of", "behind")
            )
            return api.relative_target(
                reference, direction, "outside" if outside else "inside"
            )

        if "top of" in fragment or "on top" in fragment:
            candidate = reference + "_top_side"
            if candidate in names:
                return candidate

        if "stove" in reference:
            suffixes = ("_cook_region",)
        elif any(k in fragment.split() for k in ("in", "into", "inside")):
            suffixes = ("_contain_region", "_top_side")
        else:
            suffixes = ("_top_side", "_contain_region")
        for suffix in suffixes:
            if reference + suffix in names:
                return reference + suffix
        return reference

    words = text.split()
    verbs = {"pick", "put", "place", "stack", "open", "close", "turn"}
    starts = [i for i, word in enumerate(words) if word in verbs]
    if not starts:
        return api.fallback()

    clauses = []
    for index, start in enumerate(starts):
        end = starts[index + 1] if index + 1 < len(starts) else len(words)
        clauses.append((words[start], words[start + 1:end]))

    # Resolve the entire sequence before beginning physical execution.
    plan = []
    held_context = []
    last_target = None
    for verb, part in clauses:
        fragment = " ".join(part)
        if verb == "turn":
            return api.fallback()

        if verb in ("open", "close"):
            if "drawer" not in fragment and "drawer" not in text:
                return api.fallback()
            region = drawer_region(fragment)
            if region is None:
                return api.fallback()
            plan.append(("drawer", region, verb))
            continue

        if verb == "pick":
            selected = mentions(fragment)
            if not selected:
                return api.fallback()
            held_context = selected
            continue

        separators = [
            i for i, word in enumerate(part)
            if word in ("in", "into", "inside", "on", "onto",
                        "beside", "behind", "next")
        ]
        if not separators:
            return api.fallback()
        split = separators[0]
        source_text = " ".join(part[:split])
        destination_text = " ".join(part[split:])
        target = target_for(destination_text)
        if target is None and any(
            p in destination_text.split() for p in ("it", "there")
        ):
            target = last_target
        if target is None:
            return api.fallback()

        items = mentions(source_text)
        if not items and any(
            p in source_text.split() for p in ("it", "them")
        ):
            items = held_context
        if not items:
            return api.fallback()

        # A singular directional description identifies one of several copies.
        if len(items) > 1 and not any(
            w in source_text.split() for w in ("and", "both", "all")
        ):
            item = resolve(source_text)
            if item is None:
                return api.fallback()
            items = [item]

        for item in items:
            if item == target:
                return api.fallback()
            grasp = (
                "rim" if "bowl" in item else
                "thin_edge" if "book" in item else
                "standard"
            )
            plan.append(("place", item, target, grasp))
        held_context = items
        last_target = target

    if not plan:
        return api.fallback()

    for operation in plan:
        if operation[0] == "drawer":
            api.drawer(operation[1], operation[2])
        else:
            api.place_with(operation[1], operation[2], operation[3])
