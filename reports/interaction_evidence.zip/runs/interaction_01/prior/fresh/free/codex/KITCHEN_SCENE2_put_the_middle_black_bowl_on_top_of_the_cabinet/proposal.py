def run(api):
    import numpy as np

    text = " ".join(
        api.instruction.lower().replace("-", " ").replace(",", " ").split()
    ).rstrip(".")
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        result = [base]
        mappings = {
            "akita black bowl": ["black bowl", "bowl"],
            "porcelain mug": ["white mug", "mug"],
            "white yellow mug": [
                "yellow and white mug", "white and yellow mug", "yellow mug"
            ],
            "red coffee mug": ["red coffee mug", "red mug"],
            "cream cheese": ["cream cheese box", "cream cheese"],
            "black book": ["black book", "book"],
            "desk caddy": ["desk caddy", "caddy"],
            "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
            "flat stove": ["stove"],
            "wooden cabinet": ["wooden cabinet", "cabinet"],
            "white cabinet": ["white cabinet", "cabinet"],
        }
        result.extend(mappings.get(base, []))
        if base.endswith(" basket"):
            result.append("basket")
        return result

    def score(name, phrase):
        padded = " " + phrase + " "
        return max(
            [len(a) for a in aliases(name) if " " + a + " " in padded] or [0]
        )

    def markers(candidates, direction):
        result = []
        for n in names:
            words = n.split("_")
            if "region" not in words or direction not in words:
                continue
            if any(
                all(w in words for w in b.rsplit("_", 1)[0].split("_"))
                for b in candidates
            ):
                result.append(n)
        return result

    def resolve(phrase, excluded=()):
        candidates = [b for b in bodies if b not in excluded and score(b, phrase)]
        if not candidates:
            return []
        best = max(score(b, phrase) for b in candidates)
        candidates = [b for b in candidates if score(b, phrase) == best]
        if len(candidates) == 1:
            return candidates

        direction = next(
            (d for d in ("middle", "front", "back", "left", "right")
             if d in phrase.split()), None
        )
        if direction:
            regions = markers(candidates, direction)
            if regions:
                region = max(
                    regions,
                    key=lambda n: ("init_region" in n, len(n))
                )
                return [api.nearest(region, candidates)]
            if direction == "middle":
                points = np.array([api.pos(b) for b in candidates])
                axis = int(np.argmax(np.ptp(points[:, :2], axis=0)))
                order = np.argsort(points[:, axis])
                return [candidates[int(order[len(order) // 2])]]
            return []

        if any(w in phrase.split() for w in ("both", "all", "two", "three")):
            return candidates
        return []

    def region(body, suffix):
        exact = body + "_" + suffix
        return exact if exact in names else None

    def drawer_region(phrase, cabinet):
        level = next(
            (s for s in ("bottom", "middle", "top") if s in phrase.split()),
            None,
        )
        return region(cabinet, level + "_region") if level else None

    # Compile before acting so unsupported language can use the old policy
    # without repeating a partially executed sequence.
    tokens = text.split()
    verbs = {"put", "place", "pick", "open", "close"}
    starts = [i for i, w in enumerate(tokens) if w in verbs]
    if not starts or any(
        w in tokens for w in ("turn", "switch", "push", "pull", "stack")
    ):
        return api.fallback()

    clauses = [
        " ".join(tokens[start:(starts[k + 1] if k + 1 < len(starts) else len(tokens))])
        for k, start in enumerate(starts)
    ]
    plan = []
    previous_items = []
    previous_drawer = None

    for clause in clauses:
        words = clause.split()
        verb = words[0]

        if verb in ("open", "close"):
            cabinets = [
                b for b in bodies
                if "cabinet" in b and score(b, clause)
            ]
            if not cabinets:
                cabinets = [b for b in bodies if "cabinet" in b]
            target = None
            if len(cabinets) == 1:
                target = drawer_region(clause, cabinets[0])
            if target is None:
                target = previous_drawer
            if target is None:
                return api.fallback()
            plan.append(("drawer", target, verb))
            previous_drawer = target
            continue

        # "Pick up X and place it ..." is a single placement operation.
        if verb == "pick":
            previous_items = resolve(clause)
            if not previous_items:
                return api.fallback()
            continue

        separators = [
            " on top of ", " inside ", " into ", " onto ",
            " in ", " on ", " to ",
        ]
        found = [(clause.find(s), -len(s), s) for s in separators if s in clause]
        if not found:
            return api.fallback()
        at, _, sep = min(found)
        source_phrase = clause[len(verb):at].strip()
        target_phrase = clause[at + len(sep):].strip()
        items = resolve(source_phrase)
        if not items and any(
            p in source_phrase.split() for p in ("it", "them")
        ):
            items = previous_items
        if not items:
            return api.fallback()

        targets = resolve(target_phrase, excluded=items)
        if len(targets) != 1:
            return api.fallback()
        body = targets[0]
        target = body

        if "drawer" in target_phrase:
            target = drawer_region(target_phrase, body) or previous_drawer
            if target is None:
                return api.fallback()
            previous_drawer = target
        elif "cabinet" in body and (
            sep == " on top of " or "top" in target_phrase.split()
            or sep in (" on ", " onto ")
        ):
            target = region(body, "top_side")
            if target is None:
                return api.fallback()
        else:
            direction = next(
                (d for d in ("left", "right", "front", "back")
                 if d in target_phrase.split()), None
            )
            if direction and any(k in body for k in ("caddy", "cabinet")):
                outside = any(
                    p in target_phrase
                    for p in ("next to", "beside", "of the", "of ")
                )
                relation = "outside" if outside else "inside"
                target = api.relative_target(body, direction, relation)
                if target is None:
                    return api.fallback()
            elif sep in (" inside ", " into ", " in "):
                target = region(body, "contain_region") or body
            elif "stove" in body:
                target = region(body, "cook_region") or body

        for item in items:
            grasp = (
                "rim" if "bowl" in item
                else "thin_edge" if "book" in item
                else "standard"
            )
            plan.append(("place", item, target, grasp))
        previous_items = items

    if not plan:
        return api.fallback()

    for operation in plan:
        if operation[0] == "drawer":
            result = api.drawer(operation[1], operation[2])
        else:
            result = api.place_with(operation[1], operation[2], operation[3])
        if result is False:
            return
