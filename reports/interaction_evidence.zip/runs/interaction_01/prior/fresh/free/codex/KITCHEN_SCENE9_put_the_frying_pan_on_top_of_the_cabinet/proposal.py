def run(api):
    import numpy as np

    text = " ".join(api.instruction.lower().replace("-", " ").split())
    names = list(api.names())
    bodies = [
        n for n in names
        if n.rsplit("_", 1)[-1].isdigit()
        and "region" not in n
        and not n.endswith("_side")
    ]

    def words(name):
        parts = name.split("_")
        if parts[-1].isdigit():
            parts.pop()
        return " ".join(parts)

    def aliases(name):
        base = words(name)
        result = [base]
        groups = {
            "frypan": ["frying pan", "fry pan", "pan"],
            "flat_stove": ["stove"],
            "bowl": ["bowl"],
            "akita_black_bowl": ["black bowl"],
            "porcelain_mug": ["white mug", "mug"],
            "white_yellow_mug": [
                "yellow and white mug", "white and yellow mug", "yellow mug"
            ],
            "red_coffee_mug": ["red mug", "coffee mug"],
            "cream_cheese": ["cream cheese", "cream cheese box"],
            "book": ["book"],
            "desk_caddy": ["desk caddy", "caddy"],
            "basket": ["basket"],
            "plate": ["plate"],
            "cabinet": ["cabinet"],
            "wooden_two_layer_shelf": ["wooden shelf", "shelf"],
        }
        for key, values in groups.items():
            if key in name:
                result.extend(values)
        # Some LIBERO instructions call the two-layer fixture a cabinet.
        if "wooden_two_layer_shelf" in name:
            if not any("cabinet" in b for b in bodies):
                result.append("cabinet")
        return list(set(result))

    def mentions(sentence):
        padded = " " + sentence + " "
        hits = []
        for body in bodies:
            for alias in aliases(body):
                needle = " " + alias + " "
                start = padded.find(needle)
                while start >= 0:
                    hits.append((start, start + len(needle) - 1, body))
                    start = padded.find(needle, start + 1)
        # Prefer specific names over generic words within the same phrase.
        accepted = []
        for hit in sorted(hits, key=lambda h: h[1] - h[0], reverse=True):
            overlaps = [
                h for h in accepted
                if hit[0] < h[1] and h[0] < hit[1]
            ]
            if not overlaps or all(
                hit[:2] == h[:2] for h in overlaps
            ):
                accepted.append(hit)
        return sorted(accepted)

    def region(body, suffixes):
        for suffix in suffixes:
            candidate = body + "_" + suffix
            if candidate in names:
                return candidate
        return None

    def resolve_group(group, sentence):
        candidates = list(dict.fromkeys(h[2] for h in group))
        if len(candidates) == 1:
            return candidates[0]
        for direction in ("left", "right", "front", "back"):
            if direction not in sentence.split():
                continue
            markers = [
                n for n in names
                if "region" in n
                and direction in n.split("_")
                and any(
                    words(c).split()[-1] in n.split("_")
                    for c in candidates
                )
            ]
            if len(markers) == 1:
                return api.nearest(markers[0], candidates)
        return None

    # Split at action boundaries, retaining the user's action order.
    verbs = ("put", "place", "move", "open", "close", "shut",
             "turn", "switch", "stack")
    clauses = text
    for verb in verbs:
        for connector in (", and then ", " and then ", ", then ",
                          " then ", ", and ", " and ", ", "):
            clauses = clauses.replace(
                connector + verb + " ", "|" + verb + " "
            )
    clauses = [s.strip(" ,.") for s in clauses.split("|") if s.strip()]
    plan = []
    last_fixture = None
    last_target = None
    last_item = None
    last_drawer = None

    for clause in clauses:
        if clause.startswith(("turn ", "switch ")):
            return api.fallback()

        hits = mentions(clause)
        groups = []
        for hit in hits:
            if groups and groups[-1][0][:2] == hit[:2]:
                groups[-1].append(hit)
            else:
                groups.append([hit])

        resolved = []
        for group in groups:
            body = resolve_group(group, clause)
            if body is None:
                return api.fallback()
            if body not in resolved:
                resolved.append(body)

        fixtures = [
            b for b in resolved
            if any(k in b for k in ("cabinet", "shelf", "caddy"))
        ]
        fixture = fixtures[-1] if fixtures else last_fixture

        drawer_action = (
            clause.startswith(("open ", "close ", "shut "))
            and ("drawer" in clause or last_drawer is not None)
        )
        if "drawer" in clause or drawer_action:
            if fixture is None:
                available = [
                    b for b in bodies
                    if "cabinet" in b or "shelf" in b
                ]
                if len(available) == 1:
                    fixture = available[0]
            level = next(
                (v for v in ("bottom", "middle", "top")
                 if v in clause.split()), None
            )
            target = (
                region(fixture, [level + "_region"])
                if fixture and level else last_drawer
            )
            if target is None:
                return api.fallback()
            last_fixture, last_drawer = fixture, target
            if drawer_action:
                operation = "open" if clause.startswith("open ") else "close"
                plan.append(("drawer", target, operation))
                continue
        else:
            if not resolved:
                return api.fallback()
            target_body = resolved[-1] if len(resolved) >= 2 else last_target
            if target_body is None:
                return api.fallback()
            target = target_body

            outside = any(p in clause for p in (
                "next to", "beside", "to the left of", "to the right of",
                "in front of", "behind"
            ))
            inside = any(p in clause for p in (
                " inside ", " into ", " in ", "compartment"
            ))
            direction = next(
                (d for d in ("left", "right", "front", "back")
                 if d in clause.split()), None
            )
            if "behind" in clause:
                direction = "back"

            if direction and (outside or (
                inside and any(k in target_body for k in
                               ("caddy", "cabinet", "shelf"))
            )):
                target = api.relative_target(
                    target_body, direction, "outside" if outside else "inside"
                )
                if target is None:
                    return api.fallback()
            elif any(p in clause for p in ("on top of", "on the top of")):
                target = region(target_body, ["top_side"]) or target_body
            elif "stove" in target_body:
                target = region(target_body, ["cook_region"]) or target_body
            elif any(k in target_body for k in ("cabinet", "shelf")):
                level = next(
                    (v for v in ("bottom", "middle", "top")
                     if v in clause.split()), None
                )
                suffixes = (
                    [level + "_region"] if inside and level else
                    ["top_side"] if level in (None, "top") else
                    [level + "_region"]
                )
                target = region(target_body, suffixes)
                if target is None:
                    return api.fallback()
            elif inside or "basket" in target_body:
                target = region(target_body, ["contain_region"]) or target_body

            last_target = target_body
            if fixtures:
                last_fixture = fixtures[-1]

        items = [
            b for b in resolved
            if b != last_target and b != fixture
            and b != target
        ]
        if not items and last_item and any(
            p in " " + clause + " " for p in (" it ", " them ")
        ):
            items = [last_item]
        if not items:
            return api.fallback()
        for item in items:
            grasp = (
                "rim" if "bowl" in item else
                "thin_edge" if "book" in item else
                "standard"
            )
            plan.append(("place", item, target, grasp))
            last_item = item

    if not plan:
        return api.fallback()

    for action in plan:
        if action[0] == "drawer":
            api.drawer(action[1], action[2])
        else:
            result = api.place_with(action[1], action[2], action[3])
            if result is False:
                return
