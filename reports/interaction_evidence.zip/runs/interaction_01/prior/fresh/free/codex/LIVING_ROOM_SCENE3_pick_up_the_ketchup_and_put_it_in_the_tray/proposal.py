def run(api):
    import numpy as np

    text = api.instruction.lower().replace("-", " ").replace("_", " ")
    for punctuation in ",.;:":
        text = text.replace(punctuation, " ")
    text = " ".join(text.split())
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n
        and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    def words(s):
        return s.replace("_", " ").split()

    def contains(s, phrase):
        return (" " + phrase + " ") in (" " + s + " ")

    mappings = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["porcelain mug", "white mug", "mug", "cup"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug",
            "mug", "cup"
        ],
        "red coffee mug": ["red coffee mug", "red mug", "mug", "cup"],
        "wooden tray": ["wooden tray", "tray"],
        "cream cheese": ["cream cheese box", "cream cheese"],
        "black book": ["black book", "book"],
        "desk caddy": ["desk caddy", "caddy"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["flat stove", "stove"],
        "white cabinet": ["white cabinet", "cabinet"],
    }

    def aliases(n):
        base = n.rsplit("_", 1)[0].replace("_", " ")
        result = [base] + mappings.get(base, [])
        for noun in ("basket", "bowl", "plate", "book", "tray", "cabinet"):
            if noun in base.split():
                result.append(noun)
        return list(set(result))

    # Keep the most specific object mentions at each position.
    def mentions(s):
        tokens = s.split()
        hits = []
        for n in bodies:
            for alias in aliases(n):
                a = alias.split()
                for i in range(len(tokens) - len(a) + 1):
                    if tokens[i:i + len(a)] == a:
                        hits.append((i, i + len(a), n))
        hits = [
            h for h in hits
            if not any(
                q[0] <= h[0] and q[1] >= h[1]
                and q[1] - q[0] > h[1] - h[0]
                for q in hits
            )
        ]
        return sorted(set(hits))

    def resolve(s):
        hits = mentions(s)
        if not hits:
            return []
        result = []
        for start, end in sorted(set((a, b) for a, b, _ in hits)):
            candidates = sorted(set(
                n for a, b, n in hits if a == start and b == end
            ))
            if len(candidates) > 1:
                prefix = s.split()[max(0, start - 4):start]
                direction = next(
                    (v for v in reversed(prefix)
                     if v in ("left", "right", "front", "back")), None
                )
                if direction:
                    noun = s.split()[end - 1]
                    markers = [
                        n for n in names
                        if direction in words(n) and noun in words(n)
                        and ("region" in n or n.endswith("_side"))
                    ]
                    if markers:
                        candidates = [api.nearest(markers[0], candidates)]
                    else:
                        return []
                else:
                    return []
            if candidates[0] not in result:
                result.append(candidates[0])
        return result

    def region(body, suffixes):
        for suffix in suffixes:
            exact = body + "_" + suffix
            if exact in names:
                return exact
        return body

    def drawer_region(s):
        level = next(
            (v for v in ("top", "middle", "bottom") if contains(s, v)),
            None
        )
        cabinets = [n for n in resolve(s) if "cabinet" in n]
        pool = [
            n for n in names
            if "region" in n
            and ("drawer" in n or "cabinet" in n)
            and (level is None or level in words(n))
            and (not cabinets or n.startswith(cabinets[0] + "_"))
            and any(v in words(n) for v in ("top", "middle", "bottom"))
        ]
        return pool[0] if len(pool) == 1 else None

    def destination(s, previous):
        if "drawer" in s:
            return drawer_region(s)
        matches = resolve(s)
        body = matches[-1] if matches else previous
        if body is None:
            return None
        direction = next(
            (v for v in ("left", "right", "front", "back")
             if contains(s, v)), None
        )
        # "Left plate" identifies an object; "left of the stove" a region.
        spatial = (
            " of " in " " + s + " "
            or "side" in s or "compartment" in s
            or ("caddy" in body and direction is not None)
        )
        if direction and spatial:
            outside = any(
                phrase in s for phrase in
                ("next to", "beside", "outside", "left of", "right of",
                 "in front of", "behind", "back of")
            )
            inside = any(v in s for v in ("inside", "compartment"))
            relation = "inside" if inside or not outside else "outside"
            return api.relative_target(body, direction, relation)
        if "top" in s and ("cabinet" in body or "caddy" in body):
            return region(body, ["top_side", "top_region"])
        if "stove" in body:
            return region(body, ["cook_region"])
        if any(contains(s, v) for v in ("in", "into", "inside")):
            return region(body, ["contain_region"])
        if "tray" in body or "basket" in body:
            return region(body, ["contain_region"])
        return body

    # Build the complete action sequence before executing physical actions.
    tokens = text.split()
    verbs = {"pick", "put", "place", "move", "open", "close",
             "shut", "turn", "push", "pull", "stack", "insert"}
    starts = [i for i, t in enumerate(tokens) if t in verbs]
    if not starts or any(tokens[i] in {"turn", "push", "pull"} for i in starts):
        return api.fallback()
    starts.append(len(tokens))
    pending = []
    previous_target = None
    previous_drawer = None
    plan = []

    for k in range(len(starts) - 1):
        segment = tokens[starts[k]:starts[k + 1]]
        verb = segment[0]
        clause = " ".join(segment[1:])

        if verb == "pick":
            pending = resolve(clause)
            if not pending:
                return api.fallback()
            continue

        if verb in ("open", "close", "shut"):
            target = drawer_region(clause)
            if target is None and any(
                contains(clause, p) for p in ("it", "drawer")
            ):
                target = previous_drawer
            if target is None:
                return api.fallback()
            plan.append(("drawer", target, "open" if verb == "open" else "close"))
            previous_drawer = target
            continue

        split = next(
            (i for i, token in enumerate(segment[1:], 1)
             if token in ("in", "into", "inside", "on", "onto", "to",
                          "beside", "behind", "under", "over")),
            None
        )
        if split is None:
            return api.fallback()
        source_text = " ".join(segment[1:split])
        target_text = " ".join(segment[split:])
        if segment[split] in ("under", "over"):
            return api.fallback()
        items = resolve(source_text)
        if not items and (
            not source_text.strip(" ")
            or any(contains(source_text, p) for p in ("it", "them", "these"))
        ):
            items = pending
        target = destination(target_text, previous_target)
        if target is None and "drawer" in target_text:
            target = previous_drawer
        if not items or target is None:
            return api.fallback()
        for item in items:
            if item == target or target.startswith(item + "_"):
                return api.fallback()
            grasp = (
                "rim" if "bowl" in item else
                "thin_edge" if "book" in item else
                "standard"
            )
            plan.append(("place", item, target, grasp))
        pending = items
        target_bodies = resolve(target_text)
        if target_bodies:
            previous_target = target_bodies[-1]

    if not plan:
        return api.fallback()

    for action in plan:
        if action[0] == "drawer":
            api.drawer(action[1], action[2])
        else:
            api.place_with(action[1], action[2], action[3])
