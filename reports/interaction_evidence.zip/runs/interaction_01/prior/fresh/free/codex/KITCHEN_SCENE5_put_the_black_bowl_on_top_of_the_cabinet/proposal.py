def run(api):
    import numpy as np

    text = " ".join(
        api.instruction.lower().replace("-", " ").replace(",", " ").split()
    )
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n
        and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    synonyms = {
        "akita black bowl": ["black bowl", "bowl"],
        "porcelain mug": ["white mug", "mug"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug", "mug"
        ],
        "red coffee mug": ["red coffee mug", "red mug", "mug"],
        "cream cheese": ["cream cheese box"],
        "black book": ["book"],
        "desk caddy": ["caddy"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["stove"],
        "white cabinet": ["cabinet"],
        "wooden cabinet": ["cabinet"],
    }

    def aliases(name):
        base = name.rsplit("_", 1)[0].replace("_", " ")
        return [base] + synonyms.get(base, [])

    def mentions(sentence):
        padded = " " + sentence + " "
        hits = {}
        for body in bodies:
            for alias in aliases(body):
                needle = " " + alias + " "
                start = 0
                while True:
                    i = padded.find(needle, start)
                    if i < 0:
                        break
                    span = (i, i + len(needle) - 1)
                    hits.setdefault(span, []).append(body)
                    start = i + 1
        spans = sorted(hits, key=lambda s: (-(s[1] - s[0]), s[0]))
        chosen = []
        for span in spans:
            if not any(span[0] < b and a < span[1] for a, b in chosen):
                chosen.append(span)
        return [
            (a, b, list(dict.fromkeys(hits[(a, b)])))
            for a, b in sorted(chosen)
        ]

    def resolve(candidates, sentence, start):
        if len(candidates) == 1:
            return candidates[0]
        prefix = (" " + sentence + " ")[:start].split()
        direction = next(
            (w for w in reversed(prefix[-3:])
             if w in ("left", "right", "front", "back")),
            None,
        )
        if direction:
            markers = [
                n for n in names
                if "region" in n and direction in n.split("_")
                and any(c.rsplit("_", 1)[0] in n for c in candidates)
            ]
            if len(markers) == 1:
                return api.nearest(markers[0], candidates)
        return None

    def region(body, suffixes):
        for suffix in suffixes:
            candidate = body + "_" + suffix
            if candidate in names:
                return candidate
        return None

    def drawer_region(sentence, cabinet=None):
        level = next(
            (w for w in ("bottom", "middle", "top") if w in sentence.split()),
            None,
        )
        candidates = [
            n for n in names
            if n.endswith(("_bottom_region", "_middle_region", "_top_region"))
            and ("cabinet" in n or "drawer" in n)
            and (cabinet is None or n.startswith(cabinet + "_"))
            and (level is None or n.endswith("_" + level + "_region"))
        ]
        return candidates[0] if len(candidates) == 1 else None

    # Parse the complete plan before performing any physical action.
    words = text.split()
    verbs = {"put", "place", "move", "stack", "open", "close", "shut"}
    if any(w in words for w in ("turn", "switch", "push", "pull")):
        return api.fallback()

    starts = [i for i, w in enumerate(words) if w in verbs]
    if not starts:
        return api.fallback()
    clauses = [
        " ".join(words[start:starts[i + 1] if i + 1 < len(starts) else len(words)])
        for i, start in enumerate(starts)
    ]

    plan = []
    previous_items = []
    previous_target = None
    previous_drawer = None

    for clause in clauses:
        verb = clause.split()[0]
        hits = mentions(clause)

        if verb in ("open", "close", "shut"):
            cabinet = None
            for a, b, candidates in hits:
                selected = resolve(candidates, clause, a)
                if selected and "cabinet" in selected:
                    cabinet = selected
            target = drawer_region(clause, cabinet)
            if target is None and (
                "it" in clause.split() or "drawer" in clause.split()
            ):
                target = previous_drawer
            if target is None:
                return api.fallback()
            plan.append(("drawer", target, "open" if verb == "open" else "close"))
            previous_drawer = target
            continue

        padded = " " + clause + " "
        relations = [
            " on top of ", " to the left of ", " to the right of ",
            " in front of ", " to the front of ", " to the back of ",
            " behind ", " next to ", " inside ", " into ", " onto ",
            " in ", " on ",
        ]
        separators = [
            (padded.find(r), -len(r), r)
            for r in relations if padded.find(r) >= 0
        ]
        if not separators:
            return api.fallback()
        boundary, _, relation = min(separators)
        source_hits = [h for h in hits if h[0] < boundary]
        target_hits = [h for h in hits if h[0] >= boundary]
        items = []
        for a, b, candidates in source_hits:
            item = resolve(candidates, clause, a)
            if item is None:
                return api.fallback()
            if item not in items:
                items.append(item)
        if not items and any(
            w in padded[:boundary].split() for w in ("it", "them")
        ):
            items = previous_items[:]
        if not items:
            return api.fallback()

        destination = padded[boundary:]
        target_body = None
        if target_hits:
            a, b, candidates = target_hits[-1]
            target_body = resolve(candidates, clause, a)
            if target_body is None:
                return api.fallback()

        if "drawer" in destination:
            target = drawer_region(destination, target_body)
            if target is None:
                target = previous_drawer
            previous_drawer = target
        elif target_body is not None:
            direction = next(
                (w for w in destination.split()
                 if w in ("left", "right", "front", "back")),
                None,
            )
            if "behind" in destination:
                direction = "back"
            fixture = any(
                word in target_body for word in ("caddy", "cabinet", "shelf")
            )
            if direction and fixture:
                inside = (
                    relation in (" inside ", " into ", " in ")
                    and "next to" not in destination
                )
                target = api.relative_target(
                    target_body, direction, "inside" if inside else "outside"
                )
            elif "cabinet" in target_body and (
                relation in (" on ", " onto ", " on top of ")
            ):
                target = region(target_body, ["top_side"])
            elif relation in (" inside ", " into ", " in "):
                target = region(target_body, ["contain_region"]) or target_body
            elif "stove" in target_body:
                target = region(target_body, ["cook_region"]) or target_body
            else:
                target = target_body
        else:
            target = previous_target if any(
                w in destination.split() for w in ("it", "there")
            ) else None

        if target is None or target in items:
            return api.fallback()
        for item in items:
            grasp = (
                "rim" if "bowl" in item
                else "thin_edge" if "book" in item
                else "standard"
            )
            plan.append(("place", item, target, grasp))
        previous_items = items
        previous_target = target

    for action in plan:
        if action[0] == "drawer":
            result = api.drawer(action[1], action[2])
        else:
            result = api.place_with(action[1], action[2], action[3])
        if result is False:
            return
