def run(api):
    import numpy as np

    def normalize(text):
        for char in "_-.,;:!?":
            text = text.replace(char, " ")
        return " ".join(text.lower().split())

    instruction = normalize(api.instruction)
    names = list(api.names())
    bodies = [
        n for n in names
        if "region" not in n and not n.endswith("_side")
        and n.rsplit("_", 1)[-1].isdigit()
    ]

    alias_map = {
        "porcelain mug": ["white mug", "white cup", "porcelain cup"],
        "white yellow mug": [
            "yellow and white mug", "white and yellow mug", "yellow mug"
        ],
        "red coffee mug": ["red mug", "red cup"],
        "akita black bowl": ["black bowl"],
        "black book": ["book"],
        "desk caddy": ["caddy"],
        "chefmate 8 frypan": ["frying pan", "frypan", "pan"],
        "flat stove": ["stove"],
        "white cabinet": ["cabinet"],
        "cream cheese": ["cream cheese box"],
    }

    def aliases(name):
        base = normalize(name.rsplit("_", 1)[0])
        result = [base] + alias_map.get(base, [])
        for word in ("mug", "bowl", "plate", "basket", "book", "cabinet",
                     "caddy", "bottle", "pan"):
            if word in base.split():
                result.append(word)
        return result

    def mentions(text):
        """Keep specific names in preference to overlapping generic names."""
        padded = " " + text + " "
        hits = []
        for body in bodies:
            for alias in aliases(body):
                needle = " " + alias + " "
                start = padded.find(needle)
                while start >= 0:
                    hits.append((start, start + len(needle) - 1, body, alias))
                    start = padded.find(needle, start + 1)
        hits.sort(key=lambda h: (-(h[1] - h[0]), h[0]))
        selected = []
        for hit in hits:
            if any(hit[0] < h[1] and h[0] < hit[1] for h in selected):
                continue
            selected.append(hit)
        return sorted(selected, key=lambda h: h[0])

    def region(body, fragments):
        for fragment in fragments:
            exact = body + "_" + fragment
            if exact in names:
                return exact
            matches = [
                n for n in names
                if n.startswith(body + "_") and fragment in n
            ]
            if matches:
                return min(matches, key=len)
        return None

    def direction(text):
        words = text.split()
        return next(
            (w for w in reversed(words)
             if w in ("left", "right", "front", "back")),
            None,
        )

    def resolve_body(hit, text):
        body, alias = hit[2], hit[3]
        candidates = [n for n in bodies if alias in aliases(n)]
        if len(candidates) <= 1:
            return body
        side = direction(text)
        if side:
            markers = [
                n for n in names
                if "region" in n and alias.replace(" ", "_") in n
                and side in n.split("_") and "init" not in n
            ]
            if markers:
                return api.nearest(min(markers, key=len), candidates)
        return body

    def target_for(body, text):
        if "drawer" in text:
            level = next(
                (w for w in ("top", "middle", "bottom") if w in text.split()),
                "bottom",
            )
            return region(body, [level + "_region",
                                 level + "_contain_region"])
        if "top of" in text or "on top" in text:
            return region(body, ["top_side", "top_region"]) or body

        side = direction(text)
        if side:
            inside = (
                "compartment" in text
                or "inside" in text
                or "within" in text
                or (
                    "caddy" in body
                    and any(p in " " + text + " "
                            for p in (" in ", " into "))
                    and not any(p in text for p in
                                ("next to", "beside", "outside", "of the caddy"))
                )
            )
            outside = any(p in text for p in (
                "next to", "beside", "outside", "left of", "right of",
                "front of", "back of"
            ))
            if inside or outside or "caddy" in body:
                relation = "inside" if inside else "outside"
                result = api.relative_target(body, side, relation)
                if result:
                    return result
        if "stove" in body:
            return region(body, ["cook_region"]) or body
        if any(p in " " + text + " " for p in
               (" in ", " into ", " inside ", " within ")):
            return region(body, ["contain_region"]) or body
        if "basket" in body or "caddy" in body:
            return region(body, ["contain_region"]) or body
        return body

    def grasp_for(item):
        if "bowl" in item:
            return "rim"
        if "book" in item:
            return "thin_edge"
        return "standard"

    # Parse an ordered action list before issuing physical commands.
    words = instruction.split()
    starts = []
    placement_verbs = {"put", "place", "move", "set", "stack", "insert"}
    for i, word in enumerate(words):
        if word in placement_verbs or word in {"open", "close", "shut"}:
            starts.append(i)
        elif word == "pick" and i + 1 < len(words) and words[i + 1] == "up":
            starts.append(i)
        elif word == "turn":
            # The previous policy supplies the physical switch skill.
            return api.fallback()

    if not starts:
        return api.fallback()

    actions = []
    held_items = []
    previous_target = None
    previous_drawer = None

    for j, start in enumerate(starts):
        end = starts[j + 1] if j + 1 < len(starts) else len(words)
        text = " ".join(words[start:end])
        verb = words[start]
        hits = mentions(text)

        if verb == "pick":
            held_items = list(dict.fromkeys(
                resolve_body(h, text[:h[1]]) for h in hits
            ))
            continue

        if verb in {"open", "close", "shut"}:
            fixtures = [
                h[2] for h in hits
                if "cabinet" in h[2] or "drawer" in h[2]
            ]
            if not fixtures:
                fixtures = [b for b in bodies if "cabinet" in b]
            drawer = previous_drawer
            if fixtures and ("drawer" in text or drawer is None):
                drawer = target_for(fixtures[-1], text + " drawer")
            if drawer is None:
                return api.fallback()
            actions.append(("drawer", drawer,
                            "open" if verb == "open" else "close"))
            previous_drawer = drawer
            previous_target = drawer
            continue

        if not hits:
            if held_items and previous_target:
                for item in held_items:
                    actions.append(("place", item, previous_target))
                continue
            return api.fallback()

        # The final named entity is normally the destination. Earlier named
        # entities are movable objects, in their requested order.
        destination_hit = hits[-1]
        destination_body = resolve_body(destination_hit, text)
        destination_text = text

        items = []
        for hit in hits[:-1]:
            item = resolve_body(hit, text[:hit[1]])
            if item != destination_body and item not in items:
                items.append(item)

        if not items and held_items:
            items = [n for n in held_items if n != destination_body]

        if not items and previous_target and any(
            phrase in text for phrase in ("in it", "into it", "there", "inside it")
        ):
            items = list(dict.fromkeys(h[2] for h in hits))
            target = previous_target
        else:
            if not items:
                return api.fallback()
            # Exclude source-object qualifiers when interpreting the destination.
            first_item_end = max(
                (h[1] for h in hits[:-1] if h[2] in items), default=0
            )
            destination_text = text[first_item_end:]
            target = target_for(destination_body, destination_text)

        if target is None:
            return api.fallback()

        for item in items:
            actions.append(("place", item, target))
        held_items = items
        previous_target = target
        if "drawer" in destination_text:
            previous_drawer = target

    if not actions:
        return api.fallback()

    for kind, subject, destination in actions:
        if kind == "drawer":
            api.drawer(subject, destination)
        else:
            api.place_with(subject, destination, grasp_for(subject))
