import math
import numpy as np

ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl', 'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup', 'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup', 'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop', 'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy',
    'black_book': 'black book', 'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle', 'butter': 'butter box',
    'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet', 'wooden_cabinet': 'wooden cabinet',
    'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack', 'microwave': 'microwave oven',
    'basket': 'basket', 'plate': 'plate',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown', 'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'top', 'left', 'right',
        'front', 'back', 'behind', 'bottom', 'middle', 'compartment', 'compartments', 'section',
        'slot', 'side', 'its', 'that', 'is', 'please', 'then', 'next', 'at'}
VERBS = {'put', 'place', 'turn', 'switch', 'close', 'shut', 'open', 'pick', 'push', 'pull',
         'move', 'stack', 'lift', 'grab', 'take', 'set'}
PREPS = ('into', 'onto', 'inside', 'in', 'on', 'to', 'at', 'behind', 'next')
DIRS = {'left': 'left', 'right': 'right', 'front': 'front', 'back': 'back', 'behind': 'back'}
PARTS = ('compartment', 'compartments', 'section', 'slot', 'part')


def V(*a):
    return np.array(a, dtype=float)


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def E(api):
    return np.array(api.eef(), dtype=float)


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _words(s):
    return ''.join(c if c.isalnum() else ' ' for c in s.lower()).split()


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return w


def _spatial(api, names, raw, cands):
    for w in ('left', 'right', 'front', 'back'):
        if w in raw:
            head = _base(cands[0]).split('_')[-1]
            hints = [n for n in names if _is_region(n) and w in n.split('_') and head in n.split('_')]
            if hints:
                hp = P(api, hints[0])
                return sorted(cands, key=lambda c: np.linalg.norm(P(api, c)[:2] - hp[:2]))
            keyf = {'left': lambda p: -p[1], 'right': lambda p: p[1],
                    'front': lambda p: p[0], 'back': lambda p: -p[0]}[w]
            return sorted(cands, key=lambda c: keyf(P(api, c)))
    return sorted(cands)


def resolve(api, names, bodies, raw, exclude=()):
    W = set(w for w in raw if w not in STOP)
    if not W:
        return None
    best, cands = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, cands = s, [b]
        elif abs(s - best) < 1e-9:
            cands.append(b)
    if not cands:
        return None
    if len(cands) > 1:
        cands = _spatial(api, names, raw, cands)
    return cands[0]


def resolve_target(api, names, bodies, raw):
    obj = resolve(api, names, bodies, raw)
    if obj is None:
        return None
    regs = [n for n in names if _is_region(n) and n.startswith(obj + '_')]
    if not regs:
        return (obj, obj)
    R = set(raw)
    drawer = 'drawer' in R or 'drawers' in R
    best, bs = None, -1e9
    for r in regs:
        suf = r[len(obj) + 1:].split('_')
        toks = set(suf) - {'region', 'contain', 'side'}
        s = 3 * len(toks & R)
        if drawer and 'side' in suf:
            s -= 5
        if (not drawer) and 'top' in R and 'side' in suf:
            s += 2
        if not toks or toks <= {'cook', 'heating'}:
            s += 1
        if s > bs:
            bs, best = s, r
    return (best, obj)


def split_clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if (w == 'and' and (nxt in VERBS or nxt == 'then')) or w == 'then':
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return [c for c in out if c]


def split_items(ws):
    both = 'both' in ws
    has_the = any(ws[j] == 'and' and j + 1 < len(ws) and ws[j + 1] in ('the', 'a')
                  for j in range(len(ws)))
    parts = [[]]
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if w == 'and' and ((has_the and nxt in ('the', 'a')) or (both and not has_the)):
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


# ---------------------------------------------------------------- spatial targets
def spatial_relation(prep, tw):
    """returns (direction, relation) if the target is a spatial phrase, else None"""
    if prep == 'behind':
        return ('back', 'outside')
    for i, w in enumerate(tw):
        if w not in DIRS:
            continue
        d = DIRS[w]
        nx = tw[i + 1] if i + 1 < len(tw) else ''
        nx2 = tw[i + 2] if i + 2 < len(tw) else ''
        if nx in PARTS or (nx == 'side' and nx2 in PARTS):
            return (d, 'inside')
        if nx == 'of' or (nx == 'side' and nx2 == 'of') or w == 'behind':
            rel = 'inside' if prep in ('in', 'inside', 'into') else 'outside'
            return (d, rel)
    return None


def region_by_name(names, ref, d, rel):
    base = _base(ref)
    best, bs = None, -1e9
    for n in names:
        if not _is_region(n):
            continue
        t = n.split('_')
        if d not in t:
            continue
        s = 0.0
        if n.startswith(ref + '_'):
            s += 4 if rel == 'inside' else -1
        if base in n:
            s += 2
        if 'contain' in t:
            s += 2 if rel == 'inside' else -3
        elif rel == 'outside':
            s += 1
        s -= sum(1 for k in ('left', 'right', 'front', 'back', 'behind') if k in t and k != d)
        if s > bs:
            bs, best = s, n
    return best


def spatial_region(api, names, ref, d, rel):
    try:
        r = api.relative_target(ref, d, rel)
        if r:
            return str(r)
    except Exception:
        pass
    return region_by_name(names, ref, d, rel)


# ---------------------------------------------------------------- planning
def build_plan(api, names, bodies, words):
    ops = []
    last_item, last_target = None, None
    for c in split_clauses(words):
        while c and c[-1] == 'and':
            c = c[:-1]
        if not c:
            continue
        v, rest = c[0], c[1:]
        if v in ('turn', 'switch', 'push'):
            return None
        if v in ('close', 'shut', 'open'):
            if not rest or rest in (['it'], ['them']):
                tgt = last_target
            else:
                tgt = resolve_target(api, names, bodies, rest)
            if tgt is None:
                return None
            ops.append(('drawer', tgt, 'open' if v == 'open' else 'close'))
            last_target = tgt
            continue
        rest = [w for w in rest if w != 'up']
        idx = None
        for i, w in enumerate(rest):
            if w in PREPS and i > 0:
                idx = i
                break
        if idx is None:
            if v in ('pick', 'grab', 'lift', 'take'):
                it = resolve(api, names, bodies, rest)
                if it:
                    ops.append(('pick', it))
                    last_item = it
                continue
            return None
        prep = rest[idx]
        item_w, tw = rest[:idx], rest[idx + 1:]
        if prep == 'next' and tw and tw[0] == 'to':
            tw = tw[1:]
        tgt = None
        sp = spatial_relation(prep, tw)
        if sp is not None:
            ref = resolve(api, names, bodies, tw)
            if ref is not None:
                reg = spatial_region(api, names, ref, sp[0], sp[1])
                if reg:
                    tgt = (reg, ref)
        if tgt is None:
            if not tw or tw in (['it'], ['them']):
                tgt = last_target
            else:
                tgt = resolve_target(api, names, bodies, tw)
        if tgt is None:
            return None
        items = []
        for part in split_items(item_w):
            if part in (['it'], ['them']):
                it = last_item
            else:
                it = resolve(api, names, bodies, part, exclude=(tgt[1],))
            if it and it not in items:
                items.append(it)
        if not items:
            return None
        if ops and ops[-1][0] == 'pick' and ops[-1][1] in items:
            ops.pop()
        for it in items:
            ops.append(('place', it, tgt))
        last_item = items[-1]
        last_target = tgt
    return ops or None


# ---------------------------------------------------------------- execution
def grasp_kind(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


def placed_ok(api, item, name):
    try:
        ip, tp = P(api, item), P(api, name)
    except Exception:
        return True
    tol = 0.07
    if 'contain' in name:
        tol = 0.06 if 'caddy' in name else 0.08
    if 'basket' in name:
        tol = 0.08
    return np.linalg.norm(ip[:2] - tp[:2]) < tol and ip[2] > tp[2] - 0.06


def recover(api):
    api.grip(False)
    e = E(api)
    api.move(e + V(0, 0, 0.12), steps=15)


def drop_z(name):
    if 'basket' in name:
        return 0.11
    if 'caddy' in name:
        return 0.10
    if 'plate' in name:
        return 0.06
    if 'cook' in name:
        return 0.05
    return 0.08


def do_place(api, item, tgt):
    name = tgt[0]
    kind = grasp_kind(item)
    for _ in range(2):
        try:
            api.place_with(item, name, kind)
        except Exception:
            pass
        if placed_ok(api, item, name):
            return True
        try:
            recover(api)
        except Exception:
            pass
    if kind == 'standard':
        g = (0.0, 0.03, 0.02) if ('mug' in item or 'cup' in item) else (0.0, 0.0, 0.0)
        try:
            api.transfer(item, name, grasp=g, drop=(0.0, 0.0, drop_z(name)))
        except Exception:
            pass
        if placed_ok(api, item, name):
            return True
        recover(api)
    return False


def pick_only(api, item):
    p = P(api, item)
    if 'mug' in item or 'cup' in item:
        p = p + V(0, 0.03, 0.02)
    api.grip(False)
    api.move(p + V(0, 0, 0.12), steps=30)
    api.move(p, steps=25)
    api.grip(True)
    api.move(p + V(0, 0, 0.15), steps=25)


def run(api):
    names = list(api.names())
    bodies = [n for n in names if not _is_region(n)]
    words = _words(api.instruction)
    try:
        ops = build_plan(api, names, bodies, words)
    except Exception:
        ops = None
    if not ops:
        api.fallback()
        return
    for op in ops:
        try:
            if op[0] == 'drawer':
                api.drawer(op[1][0], op[2])
            elif op[0] == 'place':
                do_place(api, op[1], op[2])
            elif op[0] == 'pick':
                pick_only(api, op[1])
        except Exception:
            try:
                recover(api)
            except Exception:
                pass
