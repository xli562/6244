import math
import numpy as np

# ---------------------------------------------------------------- vocabulary
ALIAS = {
    'akita_black_bowl': 'black bowl',
    'black_bowl': 'black bowl',
    'white_bowl': 'white bowl',
    'red_bowl': 'red bowl',
    'porcelain_mug': 'white porcelain mug cup',
    'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup',
    'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop',
    'moka_pot': 'moka pot',
    'desk_caddy': 'desk caddy',
    'black_book': 'black book',
    'yellow_book': 'yellow book',
    'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can',
    'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle',
    'ketchup': 'ketchup bottle',
    'butter': 'butter box',
    'milk': 'milk carton',
    'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box',
    'salad_dressing': 'salad dressing bottle',
    'new_salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet',
    'wooden_cabinet': 'wooden cabinet',
    'wine_bottle': 'wine bottle',
    'wine_rack': 'wine rack',
    'microwave': 'microwave oven',
    'basket': 'basket',
    'plate': 'plate',
    'cookies': 'cookie cookies box',
    'glazed_rim_porcelain_ramekin': 'ramekin',
    'wooden_tray': 'wooden tray',
    'wooden_two_layer_shelf': 'wooden shelf',
    'white_storage_box': 'white storage box',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown',
          'wooden', 'pink', 'orange'}
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'top',
        'left', 'right', 'front', 'back', 'bottom', 'middle', 'compartment',
        'side', 'its', 'that', 'is', 'please', 'then', 'behind', 'rear',
        'center', 'centre', 'central', 'one', 'this', 'there'}
PRON = {'it', 'them', 'that', 'one', 'this', 'its', 'there'}
PLACEV = {'put', 'place', 'set', 'move', 'stack', 'drop', 'insert', 'transfer',
          'bring', 'return', 'deposit', 'lay', 'store', 'push', 'slide'}
PICKV = {'pick', 'grab', 'lift', 'take', 'grasp', 'fetch'}
OPENV = {'open'}
CLOSEV = {'close', 'shut'}
TURNV = {'turn', 'switch', 'toggle'}
VERBS = PLACEV | PICKV | OPENV | CLOSEV | TURNV | {'pull'}
LEAD = {'please', 'now', 'then', 'also', 'first', 'finally', 'next', 'and',
        'lastly', 'afterwards', 'after', 'that', '|'}
TPREP = ('onto', 'into', 'inside', 'in', 'on', 'atop')
OPREP = ('next', 'beside', 'near', 'behind', 'to', 'at', 'by')
MODW = {'on', 'in', 'inside', 'next', 'between', 'from', 'at', 'near', 'beside',
        'behind', 'by', 'out', 'under', 'that', 'which', 'closest', 'nearest',
        'located', 'sitting', 'lying', 'placed'}
DIRS = {'left': 'left', 'right': 'right', 'front': 'front', 'back': 'back',
        'behind': 'back', 'rear': 'back'}
COMPART = {'compartment', 'compartments', 'section', 'slot', 'drawer',
           'partition', 'cell'}
LEVELS = ('top', 'middle', 'bottom')
OUT_OFF = {'left': (0.0, 0.13, 0.05), 'right': (0.0, -0.13, 0.05),
           'front': (-0.13, 0.0, 0.05), 'back': (0.13, 0.0, 0.05)}


def V(*a):
    return np.array(a, dtype=float)


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return w


def _tokens(text):
    out, cur = [], ''
    for ch in str(text).lower():
        if ch.isalnum():
            cur += ch
        else:
            if cur:
                out.append(cur)
                cur = ''
            if ch in ',;.:':
                out.append('|')
    if cur:
        out.append(cur)
    return out


def _wordset(ws):
    W = set()
    for w in ws:
        if w in STOP or w in PRON or w == '|':
            continue
        W.add(w)
        if len(w) > 3 and w.endswith('s') and not w.endswith('ss'):
            W.add(w[:-1])
            if w.endswith('es'):
                W.add(w[:-2])
    return W


def is_drawer_region(n):
    t = str(n).split('_')
    return len(t) >= 2 and t[-1] == 'region' and t[-2] in LEVELS and 'init' not in t


# ---------------------------------------------------------------- context
class Ctx(object):
    def __init__(self, api):
        self.api = api
        self.names = [str(n) for n in api.names()]
        try:
            cat = api.catalog()
        except Exception:
            cat = None
        self.cat = cat if isinstance(cat, dict) else {}
        self.regions = [n for n in self.names if self.kind(n) == 'region']
        self.bodies = [n for n in self.names if self.kind(n) != 'region']

    def kind(self, n):
        info = self.cat.get(n)
        if isinstance(info, dict) and info.get('kind') in ('item', 'fixture', 'region'):
            return info['kind']
        return 'region' if _is_region(n) else 'body'

    def parent(self, n):
        info = self.cat.get(n)
        if isinstance(info, dict):
            return info.get('parent')
        return None

    def owns(self, obj, r):
        return self.parent(r) == obj or r.startswith(obj + '_')

    def regs_of(self, obj):
        return [r for r in self.regions
                if 'init' not in r.split('_') and self.owns(obj, r)]

    def pos(self, n):
        return np.array(self.api.pos(n), dtype=float)

    def eef(self):
        return np.array(self.api.eef(), dtype=float)

    def left(self):
        try:
            return int(self.api.remaining())
        except Exception:
            return 0


# ---------------------------------------------------------------- resolution
def candidates(ctx, ws, exclude=(), prefer=None):
    W = _wordset(ws)
    if not W:
        return []
    best, cands = -1e9, []
    for b in ctx.bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m + 2 * len((W & D) - COLORS) \
            - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, cands = s, [b]
        elif abs(s - best) < 1e-9:
            cands.append(b)
    if prefer and len(cands) > 1:
        pc = [c for c in cands if ctx.kind(c) == prefer]
        if pc:
            cands = pc
    return cands


def _spatial(ctx, raw, cands):
    cands = list(cands)
    if len(cands) < 2:
        return cands
    for w in raw:
        d = DIRS.get(w)
        if d is None:
            continue
        head = _base(cands[0]).split('_')[-1]
        hints = [n for n in ctx.regions
                 if d in n.split('_') and head in n.split('_')]
        if hints:
            hp = ctx.pos(hints[0])
            return sorted(cands, key=lambda c: np.linalg.norm(ctx.pos(c)[:2] - hp[:2]))
        keyf = {'left': lambda p: -p[1], 'right': lambda p: p[1],
                'front': lambda p: p[0], 'back': lambda p: -p[0]}[d]
        return sorted(cands, key=lambda c: keyf(ctx.pos(c)))
    if any(w in ('middle', 'center', 'centre', 'central') for w in raw):
        ps = dict((c, ctx.pos(c)) for c in cands)
        m = np.mean([p[:2] for p in ps.values()], axis=0)
        return sorted(cands, key=lambda c: np.linalg.norm(ps[c][:2] - m))
    return sorted(cands)


def _split_and(ws):
    out, cur = [], []
    for w in ws:
        if w in ('and', '|'):
            if cur:
                out.append(cur)
            cur = []
        else:
            cur.append(w)
    if cur:
        out.append(cur)
    return out


def region_match(ctx, ws):
    W = _wordset(ws)
    if not W:
        return None
    best, bs = None, 0.5
    for r in ctx.regions:
        t = set(r.split('_'))
        s = len(W & t) - (0.1 if 'init' in t else 0.0)
        if s > bs:
            best, bs = r, s
    return best


def ref_point(ctx, ws, exclude, depth):
    if not _wordset(ws):
        return None
    t = resolve_target(ctx, ws, '', exclude=exclude, depth=depth)
    if t is not None:
        try:
            return ctx.pos(t[0])
        except Exception:
            return None
    return None


def resolve_items(ctx, ws, exclude=(), prefer=None, plural=False, depth=0):
    ws = [w for w in ws if w not in ('up', '|')]
    cut = len(ws)
    for i, w in enumerate(ws):
        if i > 0 and w in MODW:
            cut = i
            break
    head, mod = ws[:cut], ws[cut:]
    cands = candidates(ctx, head, exclude, prefer)
    if not cands:
        cands = candidates(ctx, ws, exclude, prefer)
        mod = []
    if not cands:
        return []
    if not plural:
        for w in head:
            if len(w) > 3 and w.endswith('s') and not any(w in _desc(c) for c in cands):
                if any((w[:-1] in _desc(c)) or (w[:-2] in _desc(c)) for c in cands):
                    plural = True
    if plural or any(w in ('all', 'both', 'two', 'three') for w in head):
        return sorted(cands)
    if len(cands) == 1:
        return cands
    if mod and depth < 2:
        m = mod[1:]
        while m and m[0] in ('to', 'of', 'the', 'a', 'an', 'up', 'out'):
            m = m[1:]
        pts = []
        for g in _split_and(m):
            p = ref_point(ctx, g, set(exclude) | set(cands), depth + 1)
            if p is not None:
                pts.append(p)
        if pts:
            c = np.mean(pts, axis=0)
            return [min(cands, key=lambda x: np.linalg.norm(ctx.pos(x)[:2] - c[:2]))]
    return [_spatial(ctx, ws, cands)[0]]


def choose_region(ctx, obj, R, prep, mode):
    regs = ctx.regs_of(obj)
    if not regs:
        return obj
    has_drawers = any(is_drawer_region(r) for r in regs)
    drawer = ('drawer' in R or 'drawers' in R or mode in ('open', 'close')
              or (has_drawers and prep in ('in', 'into', 'inside')))
    lvl = any(w in R for w in LEVELS)
    try:
        op = ctx.pos(obj)
    except Exception:
        op = None
    best, bs = obj, -1e9
    for r in regs:
        suf = r[len(obj) + 1:].split('_') if r.startswith(obj + '_') else r.split('_')
        toks = set(suf) - {'region', 'contain', 'side'}
        s = 3 * len(toks & R)
        if 'side' in suf:
            if drawer:
                s -= 5
            elif 'top' in R or prep in ('on', 'onto', 'atop'):
                s += 2
        if not toks or toks <= {'cook', 'heating'}:
            s += 1
        if drawer and not lvl and is_drawer_region(r) and op is not None:
            try:
                d = float(np.linalg.norm(ctx.pos(r)[:2] - op[:2]))
            except Exception:
                d = 0.0
            s += (-10.0 * d) if mode == 'open' else (10.0 * d)
        if s > bs:
            bs, best = s, r
    return best


def resolve_target(ctx, ws, prep, exclude=(), mode=None, depth=0):
    """returns (target_name, owner, offset_or_None)"""
    objs = resolve_items(ctx, ws, exclude, None, False, depth)
    obj = objs[0] if objs else None
    R = set(ws)
    if obj is None:
        if 'drawer' in R or 'drawers' in R or mode in ('open', 'close'):
            for b in ctx.bodies:
                if any(is_drawer_region(r) for r in ctx.regs_of(b)):
                    obj = b
                    break
        if obj is None:
            r = region_match(ctx, ws)
            if r is None:
                return None
            return (r, ctx.parent(r) or r, None)
    return (choose_region(ctx, obj, R, prep, mode), obj, None)


def top_side(ctx, owner):
    for r in ctx.regs_of(owner):
        t = r.split('_')
        if 'side' in t and 'top' in t:
            return r
    return None


def rel_region(ctx, ref, d, rel):
    if ref is not None:
        try:
            r = ctx.api.relative_target(ref, d, rel)
            if isinstance(r, str) and (r in ctx.names or r in ctx.cat):
                return (r, ctx.parent(r) or ref, None)
        except Exception:
            pass
    cands = []
    for r in ctx.regions:
        t = r.split('_')
        if d not in t or 'init' in t:
            continue
        owned = ref is not None and ctx.owns(ref, r)
        if rel == 'inside':
            if owned or (ref is None and 'contain' in t):
                cands.append(r)
        else:
            if ref is not None and not owned and ('_' + _base(ref) + '_') in ('_' + r + '_'):
                cands.append(r)
    if cands:
        return (cands[0], ref or ctx.parent(cands[0]) or cands[0], None)
    return None


def pronoun_target(ctx, st, body, prep):
    fix, tgt = st.get('fix'), st.get('target')
    wants_top = 'top' in body
    if tgt is not None and is_drawer_region(tgt[0]):
        owner = tgt[1]
        if prep in ('on', 'onto', 'atop') and (wants_top or st.get('dstate') == 'close'):
            s = top_side(ctx, owner)
            if s:
                return (s, owner, None)
        return tgt
    if wants_top and fix:
        s = top_side(ctx, fix)
        if s:
            return (s, fix, None)
    if tgt is not None:
        return tgt
    if fix:
        return (choose_region(ctx, fix, set(body), prep, None), fix, None)
    return None


def parse_target(ctx, tw, st, exclude=()):
    prep = tw[0] if tw and tw[0] in TPREP + OPREP else ''
    body = list(tw[1:]) if prep else list(tw)
    while body and body[0] in ('to', 'of'):
        body = body[1:]
    d = rel = None
    refw = []
    if prep == 'behind':
        d, rel, refw = 'back', 'outside', body
    else:
        for i, w in enumerate(body):
            if w in DIRS:
                after = body[i + 1:]
                inside_prep = prep in ('in', 'into', 'inside')
                if w == 'front' and i == 0 and prep == 'in':
                    inside_prep = False
                if after and after[0] in COMPART:
                    rel = 'inside'
                    refw = after[after.index('of') + 1:] if 'of' in after else []
                elif after and after[0] == 'of':
                    rel = 'inside' if inside_prep else 'outside'
                    refw = after[1:]
                elif len(after) > 1 and after[0] in ('side', 'part', 'edge', 'half') \
                        and after[1] == 'of':
                    rel = 'inside' if inside_prep else 'outside'
                    refw = after[2:]
                if rel:
                    d = DIRS[w]
                break
    if rel:
        if not _wordset(refw):
            ref = st.get('fix')
        else:
            rs = resolve_items(ctx, refw, exclude)
            ref = rs[0] if rs else None
        r = rel_region(ctx, ref, d, rel)
        if r is not None:
            return r
        if ref is not None:
            if rel == 'outside':
                return (ref, ref, OUT_OFF[d])
            return (choose_region(ctx, ref, set(refw) | {d}, prep, None), ref, None)
    if not _wordset(body):
        return pronoun_target(ctx, st, body, prep)
    t = resolve_target(ctx, body, prep, exclude)
    if t is None and (set(body) & PRON):
        return pronoun_target(ctx, st, body, prep)
    return t


# ---------------------------------------------------------------- parsing
def split_clauses(words):
    out, cur = [], []
    n = len(words)
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < n else ''
        nxt2 = words[j + 2] if j + 2 < n else ''
        if w == 'then' or (w in ('and', '|') and (
                nxt in VERBS or nxt in ('then', 'please')
                or (nxt in LEAD and nxt2 in VERBS))):
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return [c for c in out if c]


def split_items(ws):
    both = 'both' in ws
    ws = [w for w in ws if w != 'both']
    has_the = any(ws[j] == 'and' and j + 1 < len(ws) and ws[j + 1] in ('the', 'a', 'an')
                  for j in range(len(ws)))
    parts, modded = [[]], False
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if w == 'and' and not modded and (
                (has_the and nxt in ('the', 'a', 'an')) or (both and not has_the)):
            parts.append([])
            continue
        if w in MODW and parts[-1]:
            modded = True
        parts[-1].append(w)
    return [p for p in parts if p], both


def split_target(rest):
    for i, w in enumerate(rest):
        if i > 0 and w in TPREP:
            return i
    for i, w in enumerate(rest):
        if i > 0 and w in OPREP:
            return i
    return None


def _pron_items(st, p):
    if 'them' in p and st['items']:
        return list(st['items'])
    return [st['item']] if st['item'] else []


def build_plan(ctx, words):
    ops = []
    st = {'item': None, 'items': [], 'target': None, 'fix': None, 'dstate': None}
    clauses = split_clauses(words)
    for ci, c in enumerate(clauses):
        while c and c[0] in LEAD:
            c = c[1:]
        while c and c[-1] in ('and', '|'):
            c = c[:-1]
        c = ['and' if w == '|' else w for w in c]
        if not c:
            continue
        vi = 0
        if c[0] not in VERBS:
            vi = next((i for i, w in enumerate(c) if w in VERBS), None)
            if vi is None:
                continue
        v, rest = c[vi], c[vi + 1:]
        has_next = ci + 1 < len(clauses)

        if v in TURNV:
            on = 'off' not in rest
            ow = [w for w in rest if w not in ('on', 'off')]
            obj = None
            if _wordset(ow):
                objs = resolve_items(ctx, ow, (), 'fixture')
                obj = objs[0] if objs else None
            else:
                obj = st['fix']
            if obj is None:
                obj = next((b for b in ctx.bodies if 'stove' in _desc(b)), None)
            if obj:
                ops.append(('turn', obj, on))
                st['fix'] = obj
                st['target'] = (choose_region(ctx, obj, set(), 'on', None), obj, None)
            continue

        drawerish = 'drawer' in rest or 'drawers' in rest
        tidx = split_target(rest)
        if v in OPENV or v in CLOSEV or (
                v in ('pull', 'push', 'slide') and tidx is None
                and (drawerish or not _wordset(rest))):
            action = 'open' if v in ('open', 'pull') else 'close'
            if 'closed' in rest or 'shut' in rest:
                action = 'close'
            if not _wordset(rest) and not drawerish:
                tgt = st['target']
                if tgt is None and st['fix']:
                    tgt = (choose_region(ctx, st['fix'], set(), '', action), st['fix'], None)
            else:
                tgt = resolve_target(ctx, rest, '', mode=action)
            if tgt:
                ops.append(('drawer', tgt, action))
                st['target'], st['fix'], st['dstate'] = tgt, tgt[1], action
            continue

        if v in PICKV:
            pr = [w for w in rest if w != 'up']
            ti = None
            for i, w in enumerate(pr):
                if i > 0 and w in ('into', 'onto'):
                    ti = i
                    break
            if ti is None or has_next:
                parts, both = split_items(pr)
                items = []
                for p in parts:
                    if not _wordset(p):
                        items += _pron_items(st, p)
                    else:
                        items += resolve_items(ctx, p, (), 'item', both and len(parts) == 1)
                items = [x for k, x in enumerate(items) if x and x not in items[:k]]
                for it in items:
                    ops.append(('pick', it))
                if items:
                    st['item'], st['items'] = items[-1], items
                continue
            rest = pr
            tidx = split_target(rest)

        if tidx is None:
            item_w, tw = rest, []
        else:
            item_w, tw = rest[:tidx], rest[tidx:]
        tgt = parse_target(ctx, tw, st) if tw else st['target']
        if tgt is None:
            continue
        parts, both = split_items(item_w)
        items = []
        for p in parts:
            if not _wordset(p):
                items += _pron_items(st, p)
            else:
                items += resolve_items(ctx, p, (tgt[1],), 'item', both and len(parts) == 1)
        if not items and ops and ops[-1][0] == 'pick':
            items = [ops[-1][1]]
        items = [x for k, x in enumerate(items) if x and x not in items[:k] and x != tgt[1]]
        while ops and ops[-1][0] == 'pick' and ops[-1][1] in items:
            ops.pop()
        for k, it in enumerate(items):
            ops.append(('place', it, tgt, k, len(items)))
        if items:
            st['item'], st['items'] = items[-1], items
        st['target'], st['fix'] = tgt, tgt[1]
    return ops


# ---------------------------------------------------------------- skills
def grasp_mode(item):
    b = _base(item)
    if 'book' in b:
        return 'thin_edge'
    if 'bowl' in b and 'drainer' not in b:
        return 'rim'
    return 'standard'


def grasp_offsets(item):
    b = _base(item)
    if 'mug' in b or 'cup' in b:
        return [(0.0, 0.03, 0.02), (0.0, -0.03, 0.02)]
    if 'bowl' in b:
        return [(0.0, 0.045, 0.01), (0.0, -0.045, 0.01)]
    return [(0.0, 0.0, 0.0), (0.0, 0.0, -0.01)]


def drop_for(name, k, n):
    z, off = 0.08, [0.0, 0.0]
    if 'basket' in name:
        z = 0.11
    elif 'caddy' in name:
        z = 0.10
    elif 'cook' in name:
        z = 0.05
    elif 'plate' in name:
        z = 0.06
    elif is_drawer_region(name):
        z = 0.06
    if n > 1 and ('basket' in name or 'contain' in name) and 'caddy' not in name:
        off[1] = 0.03 if k % 2 == 0 else -0.03
    return (off[0], off[1], z)


def is_held(ctx, item):
    try:
        return float(np.linalg.norm(ctx.eef() - ctx.pos(item))) < 0.06
    except Exception:
        return False


def placed_ok(ctx, item, name):
    ip, tp = ctx.pos(item), ctx.pos(name)
    t = name.split('_')
    tol, zhi = 0.07, 0.25
    if 'caddy' in t:
        tol = 0.05 if 'contain' in t else 0.07
    elif 'basket' in t or 'contain' in t:
        tol = 0.08
    elif is_drawer_region(name):
        tol, zhi = 0.09, 0.10
    elif 'side' in t:
        tol = 0.10
    elif name.endswith('_region'):
        tol = 0.08
    if np.linalg.norm(ip[:2] - tp[:2]) > tol:
        return False
    if ip[2] < tp[2] - 0.06 or ip[2] > tp[2] + zhi:
        return False
    if is_held(ctx, item) and ip[2] > tp[2] + 0.08:
        return False
    return True


def recover(api):
    api.grip(False)
    e = np.array(api.eef(), dtype=float)
    api.move(e + V(0, 0, 0.10), steps=12)


def attempt_place(ctx, item, name, g):
    api = ctx.api
    try:
        return api.attempt({'op': 'place', 'item': item, 'target': name, 'grasp': g})
    except (ValueError, TypeError):
        pass
    try:
        api.place_with(item, name, g)
        return None
    except (ValueError, TypeError):
        pass
    try:
        api.transfer(item, name)
    except (ValueError, TypeError):
        pass
    return None


def place_offset(ctx, item, ref, off):
    api = ctx.api
    for g in grasp_offsets(item):
        if ctx.left() < 60:
            break
        try:
            api.transfer(item, ref, grasp=g, drop=tuple(float(x) for x in off))
        except (ValueError, TypeError):
            pass
        goal = ctx.pos(ref) + np.array(off, dtype=float)
        ip = ctx.pos(item)
        if np.linalg.norm(ip[:2] - goal[:2]) < 0.06 and not is_held(ctx, item):
            return True
        recover(api)
    return False


def do_place(ctx, item, tgt, k, n):
    api = ctx.api
    name, owner, off = tgt
    if off is not None:
        return place_offset(ctx, item, name, off)
    if placed_ok(ctx, item, name):
        return True
    g0 = grasp_mode(item)
    seq = [g0, g0] if g0 == 'standard' else [g0, g0, 'standard']
    opened = False
    last_used = 120.0
    for g in seq:
        if ctx.left() < 45:
            return False
        r = attempt_place(ctx, item, name, g)
        if isinstance(r, dict):
            su = r.get('steps_used')
            if isinstance(su, (int, float)) and su > 0:
                last_used = float(su)
        if placed_ok(ctx, item, name):
            return True
        ip, tp = ctx.pos(item), ctx.pos(name)
        if is_held(ctx, item) and ip[2] > tp[2] + 0.05 \
                and np.linalg.norm(ip[:2] - tp[:2]) < 0.06:
            recover(api)                       # release over the target
            if placed_ok(ctx, item, name):
                return True
            ip = ctx.pos(item)
        elif is_held(ctx, item):
            recover(api)
        if (not opened and is_drawer_region(name) and ctx.left() > 200
                and np.linalg.norm(ip[:2] - tp[:2]) < 0.12 and ip[2] > tp[2] + 0.06):
            opened = True                      # landed on a closed drawer
            drawer_op(ctx, (name, owner, None), 'open')
        if ctx.left() < 0.75 * last_used:
            break
    if g0 == 'standard' and ctx.left() > 90:
        try:
            api.transfer(item, name, grasp=grasp_offsets(item)[0],
                         drop=drop_for(name, k, n))
        except (ValueError, TypeError):
            pass
        if placed_ok(ctx, item, name):
            return True
        if is_held(ctx, item):
            recover(api)
    return placed_ok(ctx, item, name)


def pick_only(ctx, item):
    api = ctx.api
    g = np.array(grasp_offsets(item)[0])
    p = ctx.pos(item) + g
    api.grip(False)
    api.move(p + V(0, 0, 0.12), steps=30)
    api.move(p, steps=25)
    api.grip(True)
    api.move(p + V(0, 0, 0.15), steps=25)


def drawer_dir(ctx, region, owner):
    rp = ctx.pos(region)
    op = ctx.pos(owner) if owner and owner != region else rp
    d = op[:2] - rp[:2]
    nd = np.linalg.norm(d)
    d = d / nd if nd > 0.03 else np.array([1.0, 0.0])
    return np.array([d[0], d[1], 0.0])


def push_close(ctx, name, owner):
    api = ctx.api
    rp = ctx.pos(name)
    d3 = drawer_dir(ctx, name, owner)
    start = rp - d3 * 0.20
    start[2] = rp[2] + 0.03
    e = ctx.eef()
    high = max(e[2], rp[2] + 0.15)
    api.move(V(e[0], e[1], high), steps=15)
    api.move(V(start[0], start[1], high), steps=30)
    api.grip(True)
    api.move(start, steps=25)
    api.move(start + d3 * 0.32, steps=60)
    back = start + d3 * 0.20
    api.move(back, steps=10)
    api.move(back + V(0, 0, 0.12), steps=15)


def pull_open(ctx, name, owner):
    api = ctx.api
    rp = ctx.pos(name)
    d3 = drawer_dir(ctx, name, owner)
    handle = rp - d3 * 0.13
    handle[2] = rp[2] + 0.04
    pre = handle - d3 * 0.08
    e = ctx.eef()
    api.grip(False)
    api.move(V(e[0], e[1], max(e[2], handle[2] + 0.12)), steps=15)
    api.move(pre + V(0, 0, 0.10), steps=30)
    api.move(pre, steps=20)
    api.move(handle, steps=20)
    api.grip(True)
    api.move(handle - d3 * 0.22, steps=50)
    api.grip(False)
    e = ctx.eef()
    api.move(e + V(0, 0, 0.10), steps=15)


def drawer_op(ctx, tgt, action):
    api = ctx.api
    name, owner = tgt[0], tgt[1]
    if not is_drawer_region(name) and owner:
        lv = [r for r in ctx.regs_of(owner) if is_drawer_region(r)]
        if lv:
            words = set(name.split('_'))
            name = choose_region(ctx, owner, words | {'drawer'}, '', action)
    if is_drawer_region(name):
        try:
            return api.attempt({'op': action, 'target': name})
        except (ValueError, TypeError):
            pass
        try:
            api.drawer(name, action)
            return None
        except (ValueError, TypeError):
            pass
    if action == 'open':
        pull_open(ctx, name, owner)
    else:
        push_close(ctx, name, owner)
    return None


def twist_knob(api, k, grasp_z, on):
    sgn = 1.0 if on else -1.0
    api.grip(False)
    e = np.array(api.eef(), dtype=float)
    api.move(V(e[0], e[1], max(e[2], grasp_z + 0.15)), steps=15)
    api.move(V(k[0], k[1], grasp_z + 0.10), steps=25)
    api.move(V(k[0], k[1], grasp_z), steps=20)
    api.grip(True)
    api.action([0, 0, 0, 0, 0, 0.35 * sgn, 1.0], steps=12)
    api.grip(False)
    e = np.array(api.eef(), dtype=float)
    api.move(e + V(0, 0, 0.10), steps=12)
    api.action([0, 0, 0, 0, 0, -0.35 * sgn, -1.0], steps=12)


def sweep_stove(api, sp, cp, on):
    sgn = 1.0 if on else -1.0
    e = np.array(api.eef(), dtype=float)
    api.move(V(e[0], e[1], max(e[2], cp[2] + 0.15)), steps=15)
    api.grip(True)
    lines = [(cp[0] - 0.07, cp[2] + 0.015),
             (min(sp[0], cp[0]) - 0.13, max(cp[2] - 0.015, sp[2] + 0.012))]
    for x, z in lines:
        a = V(x, cp[1] + 0.13 * sgn, z)
        b = V(x, cp[1] - 0.13 * sgn, z)
        api.move(V(a[0], a[1], cp[2] + 0.12), steps=25)
        api.move(a, steps=20)
        api.move(b, steps=45)
        api.move(V(b[0], b[1], cp[2] + 0.12), steps=15)


def turn_stove(ctx, stove, on):
    api = ctx.api
    kp = None
    for n in ctx.names:
        if (n.startswith(_base(stove)) or ctx.parent(n) == stove) and \
                any(k in n for k in ('knob', 'button', 'switch', 'dial')):
            try:
                kp = ctx.pos(n)
                break
            except Exception:
                kp = None
    cook = [r for r in ctx.regs_of(stove) if 'cook' in r]
    sp = ctx.pos(stove)
    cp = ctx.pos(cook[0]) if cook else sp + V(0, 0, 0.02)
    if kp is not None:
        twist_knob(api, kp, kp[2] + 0.005, on)
        return
    d = sp[:2] - cp[:2]
    nd = np.linalg.norm(d)
    if nd >= 0.025:
        if nd > 0.15:
            d = d / nd * 0.15
        k = V(sp[0] + d[0], sp[1] + d[1], cp[2])
        twist_knob(api, k, cp[2] + 0.005, on)
        return
    sweep_stove(api, sp, cp, on)


# ---------------------------------------------------------------- main
def run(api):
    ctx, ops = None, None
    try:
        ctx = Ctx(api)
        ops = build_plan(ctx, _tokens(api.instruction))
    except Exception:
        ops = None
    if not ops:
        try:
            api.fallback()
        except Exception:
            pass
        return
    for op in ops:
        if ctx.left() <= 5:
            return
        try:
            kind = op[0]
            if kind == 'turn':
                turn_stove(ctx, op[1], op[2])
            elif kind == 'drawer':
                drawer_op(ctx, op[1], op[2])
            elif kind == 'place':
                do_place(ctx, op[1], op[2], op[3], op[4])
            elif kind == 'pick':
                pick_only(ctx, op[1])
        except Exception:
            if ctx.left() <= 5:
                return
            try:
                recover(api)
            except Exception:
                return
