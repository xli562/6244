def run(api):
    raise ValueError("CLI program rejected: line 159: access to private attribute '_desc'")
