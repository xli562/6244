import math
import numpy as np

# ---------------------------------------------------------------- vocabulary
ALIAS = {
    'akita_black_bowl': 'black bowl',
    'black_bowl': 'black bowl',
    'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup',
    'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup',
    'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop',
    'moka_pot': 'moka pot',
    'desk_caddy': 'desk caddy',
    'black_book': 'black book',
    'yellow_book': 'yellow book',
    'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can',
    'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle',
    'ketchup': 'ketchup bottle',
    'butter': 'butter box',
    'milk': 'milk carton',
    'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box',
    'salad_dressing': 'salad dressing bottle',
    'white_cabinet': 'white cabinet',
    'wooden_cabinet': 'wooden cabinet',
    'wine_bottle': 'wine bottle',
    'wine_rack': 'wine rack',
    'microwave': 'microwave oven',
    'basket': 'basket',
    'plate': 'plate',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown',
          'wooden', 'pink', 'orange'}
DIRS = ('left', 'right', 'front', 'back')
LEVELS = ('top', 'middle', 'bottom')
STOP = {'the', 'a', 'an', 'of', 'it', 'them', 'both', 'and', 'to', 'up', 'top',
        'left', 'right', 'front', 'back', 'bottom', 'middle', 'compartment',
        'compartments', 'side', 'its', 'that', 'is', 'please', 'then', 'drawer',
        'drawers', 'on', 'in', 'into', 'onto', 'inside', 'next', 'beside', 'at',
        'this', 'there', 'region', 'area', 'surface', 'slot', 'slots', 'section',
        'hand', 'over', 'from', 'with', 'within', 'atop', 'edge'}
VERBS = {'put', 'place', 'turn', 'switch', 'close', 'shut', 'open', 'pick',
         'push', 'pull', 'move', 'stack', 'lift', 'grab', 'take', 'set', 'store',
         'insert', 'drop', 'bring', 'transfer', 'return', 'load', 'position',
         'leave', 'keep'}
PREPS = ('into', 'onto', 'inside', 'in', 'on', 'to', 'next', 'beside', 'atop',
         'at', 'within', 'over')
COMPART = {'compartment', 'compartments', 'slot', 'slots', 'section', 'inside',
           'within', 'contain', 'container'}
PRON = ('it', 'them', 'there', 'this')


def V(*a):
    return np.array(a, dtype=float)


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def E(api):
    return np.array(api.eef(), dtype=float)


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _words(s):
    s = ''.join(c if c.isalnum() else ' ' for c in str(s).lower())
    return s.split()


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return w


def _rem(api):
    try:
        return int(api.remaining())
    except Exception:
        return 1000


# ---------------------------------------------------------------- context
class Ctx(object):
    def __init__(self, api):
        self.api = api
        try:
            names = list(api.names())
        except Exception:
            names = []
        try:
            cat = dict(api.catalog() or {})
        except Exception:
            cat = {}
        alln = list(names)
        for k in cat:
            if k not in alln:
                alln.append(k)
        self.names = alln
        self.cat = cat
        self.bodies = [n for n in alln if self.kind(n) != 'region']
        its = [n for n in self.bodies if self.kind(n) == 'item']
        self.items = its or self.bodies
        self.last_items = []
        self.last_target = None
        self.last_fix = None

    def kind(self, n):
        c = self.cat.get(n)
        if isinstance(c, dict) and c.get('kind'):
            return c['kind']
        if _is_region(n):
            return 'region'
        b = _base(n)
        if any(k in b for k in ('cabinet', 'stove', 'rack', 'microwave',
                                'table', 'shelf', 'counter')):
            return 'fixture'
        return 'item'

    def parent(self, n):
        c = self.cat.get(n)
        if isinstance(c, dict):
            return c.get('parent')
        return None

    def regions_of(self, owner):
        out = []
        for n in self.names:
            if self.kind(n) != 'region':
                continue
            if self.parent(n) == owner or n.startswith(owner + '_'):
                if 'init' in n.split('_'):
                    continue
                out.append(n)
        return out


# ---------------------------------------------------------------- resolution
def _spatial(ctx, raw, cands):
    api = ctx.api
    for w in DIRS:
        if w in raw:
            head = _base(cands[0]).split('_')[-1]
            hints = [n for n in ctx.names if _is_region(n)
                     and w in n.split('_') and head in n.split('_')]
            if hints:
                try:
                    r = api.nearest(hints[0], list(cands))
                    if r in cands:
                        return r
                except Exception:
                    pass
                try:
                    hp = P(api, hints[0])
                    return min(cands, key=lambda c: np.linalg.norm(P(api, c)[:2] - hp[:2]))
                except Exception:
                    pass
            keyf = {'left': lambda p: -p[1], 'right': lambda p: p[1],
                    'front': lambda p: p[0], 'back': lambda p: -p[0]}[w]
            try:
                return min(cands, key=lambda c: keyf(P(api, c)))
            except Exception:
                return sorted(cands)[0]
    return sorted(cands)[0]


def resolve(ctx, raw, bodies, exclude=()):
    W = set(w for w in raw if w not in STOP)
    W |= set(w[:-1] for w in list(W) if w.endswith('s') and len(w) > 3)
    if not W:
        return None
    best, cands = -1e9, []
    for b in bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m = len(W & D)
        if m == 0:
            continue
        s = 3 * m - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, cands = s, [b]
        elif abs(s - best) < 1e-9:
            cands.append(b)
    if not cands:
        return None
    if len(cands) > 1:
        return _spatial(ctx, raw, cands)
    return cands[0]


def _suffix(owner, r):
    if r.startswith(owner + '_'):
        return r[len(owner) + 1:].split('_')
    return r.split('_')


def region_for(ctx, owner, words, drawer, prep):
    regs = ctx.regions_of(owner)
    if not regs:
        return owner
    R = set(words)
    best, bs = None, -1e9
    for r in regs:
        suf = _suffix(owner, r)
        toks = set(t for t in suf if not t.isdigit()) - {'region', 'contain', 'side'}
        s = 3.0 * len(toks & R)
        if 'side' in suf:
            if drawer:
                s -= 5
            elif 'top' in R:
                s += 2
            elif prep in ('on', 'onto', 'atop'):
                s += 1
        if not toks or toks <= {'cook', 'heating'}:
            s += 1
        if drawer and (toks & set(LEVELS)):
            s += 0.5
        if s > bs:
            bs, best = s, r
    return best


def rel_region(ctx, owner, dirw, rel):
    api = ctx.api
    try:
        r = api.relative_target(owner, dirw, rel)
    except Exception:
        r = None
    if isinstance(r, str) and r:
        return r
    if rel == 'inside':
        for n in ctx.regions_of(owner):
            if dirw in n.split('_'):
                return n
    else:
        b = _base(owner)
        for n in ctx.names:
            if (ctx.kind(n) == 'region' and b in n and dirw in n.split('_')
                    and not n.startswith(owner + '_')):
                return n
    return None


def parse_target(ctx, tw, prep, force_drawer=False):
    tw = [w for w in tw if w]
    dirw = next((w for w in tw if w in DIRS), None)
    drawer = force_drawer or any(w in ('drawer', 'drawers') for w in tw)
    compart = any(w in COMPART for w in tw)
    rel = None
    if dirw and not drawer:
        i = tw.index(dirw)
        nxt = tw[i + 1] if i + 1 < len(tw) else ''
        if compart:
            rel = 'inside'
        elif nxt in ('of', 'side', 'hand', 'edge'):
            rel = 'outside'
        elif prep in ('to', 'next', 'beside', 'at'):
            rel = 'outside'
    ows = [w for w in tw if w not in DIRS] if rel else tw
    owner = resolve(ctx, ows, ctx.bodies)
    if owner is None:
        content = [w for w in tw if w not in STOP]
        pron = any(w in PRON for w in tw)
        if (content and not pron) or ctx.last_fix is None:
            return None
        owner = ctx.last_fix
        extra = [w for w in tw if w in DIRS or w in LEVELS
                 or w in ('drawer', 'drawers')]
        if (not extra and not rel and ctx.last_target
                and ctx.last_target[1] == owner):
            return ctx.last_target
    if rel:
        r = rel_region(ctx, owner, dirw, rel)
        if r:
            return (r, owner)
    return (region_for(ctx, owner, tw, drawer, prep), owner)


# ---------------------------------------------------------------- parsing
def split_clauses(words):
    out, cur = [], []
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < len(words) else ''
        if (w == 'and' and (nxt in VERBS or nxt == 'then')) or w == 'then':
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return [c for c in out if c]


def split_items(ws):
    both = 'both' in ws
    has_the = any(ws[j] == 'and' and j + 1 < len(ws) and ws[j + 1] in ('the', 'a')
                  for j in range(len(ws)))
    parts = [[]]
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if w == 'and' and ((has_the and nxt in ('the', 'a')) or (both and not has_the)):
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def build_plan(ctx, words):
    ops = []
    for c in split_clauses(words):
        while c and c[-1] in ('and', 'then'):
            c = c[:-1]
        if not c:
            continue
        v = c[0]
        if v in ('turn', 'switch'):
            rest = c[1:]
            on = 'off' not in rest
            ow = [w for w in rest if w not in ('on', 'off')]
            content = [w for w in ow if w not in STOP]
            obj = resolve(ctx, ow, ctx.bodies) if content else ctx.last_fix
            if obj is None:
                st = [b for b in ctx.bodies if 'stove' in b]
                obj = st[0] if st else None
            if obj:
                ops.append(('turn', obj, on))
                ctx.last_fix = obj
            continue
        if v in ('close', 'shut', 'open'):
            mode = 'open' if v == 'open' else 'close'
            tgt = parse_target(ctx, c[1:], None, force_drawer=True)
            if tgt:
                ops.append(('drawer', mode, tgt))
                ctx.last_target = tgt
                ctx.last_fix = tgt[1]
            continue
        rest = c[1:] if v in VERBS else c
        rest = [w for w in rest if w != 'up']
        idx = None
        for i, w in enumerate(rest):
            if w in PREPS and i > 0:
                idx = i
                break
        if v in ('pick', 'grab', 'lift', 'take') and idx is None:
            it = resolve(ctx, rest, ctx.items)
            if it:
                ops.append(('pick', it))
                ctx.last_items = [it]
            continue
        if idx is None:
            item_w, tw, prep = rest, [], None
        else:
            item_w, tw, prep = rest[:idx], rest[idx + 1:], rest[idx]
        tgt = ctx.last_target if not tw else parse_target(ctx, tw, prep)
        if tgt is None:
            continue
        items = []
        for part in split_items(item_w):
            content = [w for w in part if w not in STOP]
            if not content and any(w in ('it', 'them') for w in part):
                its = list(ctx.last_items)
            else:
                it = resolve(ctx, part, ctx.items, exclude=(tgt[1],))
                its = [it] if it else []
            for it in its:
                if it not in items:
                    items.append(it)
        if not items:
            continue
        if ops and ops[-1][0] == 'pick' and ops[-1][1] in items:
            ops.pop()
        for it in items:
            ops.append(('place', it, tgt))
        ctx.last_items = items
        ctx.last_target = tgt
        ctx.last_fix = tgt[1]
    return ops


# ---------------------------------------------------------------- measured skills
def grasp_kind(item):
    b = _base(item)
    if 'bowl' in b:
        return 'rim'
    if 'book' in b:
        return 'thin_edge'
    return 'standard'


def place_tol(name):
    t = name.split('_')
    if 'caddy' in name:
        return 0.045
    if 'side' in t:
        return 0.15
    if 'region' in t and any(l in t for l in LEVELS):
        return 0.10
    if 'basket' in name or 'contain' in t:
        return 0.08
    if 'plate' in name:
        return 0.07
    return 0.08


def placed_ok(api, item, name, rec=None):
    try:
        ip, tp = P(api, item), P(api, name)
    except Exception:
        return False
    tol = place_tol(name)
    gap = np.linalg.norm(ip[:2] - tp[:2])
    if isinstance(rec, dict) and rec.get('xy_gap') is not None:
        try:
            gap = min(gap, float(rec['xy_gap']) + 0.01) if gap < tol * 1.5 else gap
        except Exception:
            pass
    if gap >= tol or ip[2] < tp[2] - 0.07:
        return False
    try:
        e = E(api)
        if np.linalg.norm(e - ip) < 0.05 and ip[2] > tp[2] + 0.15:
            return False
    except Exception:
        pass
    return True


def release_lift(api):
    try:
        api.attempt({'op': 'grip', 'closed': False})
    except (ValueError, TypeError):
        api.grip(False)
    e = E(api)
    xyz = [float(e[0]), float(e[1]), float(e[2] + 0.10)]
    try:
        api.attempt({'op': 'move', 'xyz': xyz, 'steps': 12})
    except (ValueError, TypeError):
        api.move(np.array(xyz), steps=12)


def is_drawer(ctx, name, owner):
    t = name.split('_')
    return (name != owner and ctx.kind(owner) == 'fixture' and 'side' not in t
            and any(l in t for l in LEVELS) and 'rack' not in owner)


def drawer_op(ctx, tgt, mode):
    api = ctx.api
    name, owner = tgt
    try:
        return api.attempt({'op': mode, 'target': name})
    except (ValueError, TypeError):
        pass
    try:
        return api.drawer(name, mode)
    except (ValueError, TypeError):
        pass
    if mode == 'close':
        push_close(api, tgt)
    else:
        pull_open(api, tgt)
    return None


def do_place(ctx, item, tgt):
    api = ctx.api
    name, owner = tgt
    g0 = grasp_kind(item)
    seq = [g0, g0]
    if g0 == 'rim':
        seq.append('standard')
    opened = False
    for i, g in enumerate(seq):
        if i > 0 and _rem(api) < 90:
            break
        rec = None
        try:
            rec = api.attempt({'op': 'place', 'item': item, 'target': name, 'grasp': g})
        except (ValueError, TypeError):
            try:
                api.place_with(item, name, g)
            except (ValueError, TypeError):
                try:
                    api.transfer(item, name)
                except (ValueError, TypeError):
                    pass
        if placed_ok(api, item, name, rec):
            return True
        if _rem(api) <= 0:
            return False
        release_lift(api)
        if (not opened) and is_drawer(ctx, name, owner) and _rem(api) > 160:
            opened = True
            drawer_op(ctx, tgt, 'open')
    return False


# ---------------------------------------------------------------- primitive fallbacks
def drawer_dir(api, region, owner):
    rp = P(api, region)
    op = P(api, owner) if owner else rp
    d = op[:2] - rp[:2]
    nd = np.linalg.norm(d)
    d = d / nd if nd > 0.03 else np.array([1.0, 0.0])
    return np.array([d[0], d[1], 0.0])


def push_close(api, tgt):
    name, owner = tgt
    rp = P(api, name)
    d3 = drawer_dir(api, name, owner)
    start = rp - d3 * 0.20
    start[2] = rp[2] + 0.03
    e = E(api)
    high = max(e[2], rp[2] + 0.15)
    api.move(V(e[0], e[1], high), steps=15)
    api.move(V(start[0], start[1], high), steps=30)
    api.grip(True)
    api.move(start, steps=25)
    api.move(start + d3 * 0.32, steps=60)
    back = start + d3 * 0.20
    api.move(back, steps=10)
    api.move(back + V(0, 0, 0.12), steps=15)


def pull_open(api, tgt):
    name, owner = tgt
    rp = P(api, name)
    d3 = drawer_dir(api, name, owner)
    handle = rp - d3 * 0.13
    handle[2] = rp[2] + 0.04
    pre = handle - d3 * 0.08
    e = E(api)
    api.grip(False)
    api.move(V(e[0], e[1], max(e[2], handle[2] + 0.12)), steps=15)
    api.move(pre + V(0, 0, 0.10), steps=30)
    api.move(pre, steps=20)
    api.move(handle, steps=20)
    api.grip(True)
    api.move(handle - d3 * 0.22, steps=50)
    api.grip(False)
    e = E(api)
    api.move(e + V(0, 0, 0.10), steps=15)


def pick_only(api, item):
    g = V(0.0, 0.03, 0.02) if ('mug' in item or 'cup' in item) else V(0, 0, 0)
    p = P(api, item) + g
    api.grip(False)
    api.move(p + V(0, 0, 0.12), steps=30)
    api.move(p, steps=25)
    api.grip(True)
    api.move(p + V(0, 0, 0.15), steps=25)


def twist_knob(api, k, grasp_z, on):
    sgn = 1.0 if on else -1.0
    api.grip(False)
    e = E(api)
    api.move(V(e[0], e[1], max(e[2], grasp_z + 0.15)), steps=15)
    api.move(V(k[0], k[1], grasp_z + 0.10), steps=25)
    api.move(V(k[0], k[1], grasp_z), steps=20)
    api.grip(True)
    api.action([0, 0, 0, 0, 0, 0.35 * sgn, 1.0], steps=12)
    api.grip(False)
    e = E(api)
    api.move(e + V(0, 0, 0.10), steps=12)
    api.action([0, 0, 0, 0, 0, -0.35 * sgn, -1.0], steps=12)


def sweep_stove(api, sp, cp, on):
    sgn = 1.0 if on else -1.0
    e = E(api)
    api.move(V(e[0], e[1], max(e[2], cp[2] + 0.15)), steps=15)
    api.grip(True)
    lines = [(cp[0] - 0.07, cp[2] + 0.015),
             (min(sp[0], cp[0]) - 0.13, max(cp[2] - 0.015, sp[2] + 0.012))]
    for x, z in lines:
        a = V(x, cp[1] + 0.13 * sgn, z)
        b = V(x, cp[1] - 0.13 * sgn, z)
        api.move(V(a[0], a[1], cp[2] + 0.12), steps=25)
        api.move(a, steps=20)
        api.move(b, steps=45)
        api.move(V(b[0], b[1], cp[2] + 0.12), steps=15)


def turn_stove(api, stove, names, on):
    kp = None
    for n in names:
        if n.startswith(_base(stove)) and any(k in n for k in ('knob', 'button', 'switch')):
            try:
                kp = P(api, n)
                break
            except Exception:
                pass
    if kp is None:
        for suf in ('_knob', '_button', '_knob_1', '_switch'):
            try:
                kp = P(api, stove + suf)
                break
            except Exception:
                kp = None
    cook = [n for n in names if n.startswith(stove + '_') and 'cook' in n]
    sp = P(api, stove)
    cp = P(api, cook[0]) if cook else sp + V(0, 0, 0.02)
    if kp is not None:
        twist_knob(api, kp, kp[2] + 0.005, on)
        return
    d = sp[:2] - cp[:2]
    nd = np.linalg.norm(d)
    if nd >= 0.025:
        if nd > 0.15:
            d = d / nd * 0.15
        k = V(sp[0] + d[0], sp[1] + d[1], cp[2])
        twist_knob(api, k, cp[2] + 0.005, on)
        return
    sweep_stove(api, sp, cp, on)


# ---------------------------------------------------------------- main
def run(api):
    ops = None
    ctx = None
    try:
        ctx = Ctx(api)
        ops = build_plan(ctx, _words(api.instruction))
    except Exception:
        ops = None
    if not ops:
        try:
            api.fallback()
        except Exception:
            pass
        return
    for op in ops:
        if _rem(api) <= 5:
            return
        try:
            kind = op[0]
            if kind == 'turn':
                turn_stove(api, op[1], ctx.names, op[2])
            elif kind == 'drawer':
                drawer_op(ctx, op[2], op[1])
            elif kind == 'place':
                do_place(ctx, op[1], op[2])
            elif kind == 'pick':
                pick_only(api, op[1])
        except Exception:
            if _rem(api) <= 0:
                return
            try:
                release_lift(api)
            except Exception:
                pass
