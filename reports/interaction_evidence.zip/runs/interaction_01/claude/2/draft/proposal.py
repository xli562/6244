def run(api):
    raise ValueError("CLI program rejected: Command '['/home/yuchaoq/.vscode-server/extensions/anthropic.claude-code-2.1.327-linux-x64/resources/native-binary/claude', '-p', '--model', 'claude-opus-5-5', '--effort', 'high', '--tools', '', '--strict-mcp-config', '--setting-sources', '', '--no-session-persistence', '--output-format', 'json']' timed out after 600 seconds")
