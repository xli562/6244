import math
import numpy as np

# Errors from invalid commands or names. Anything else (e.g. episode termination) propagates.
ERR = (ValueError, TypeError, LookupError, AttributeError, ArithmeticError)

# ---------------------------------------------------------------- vocabulary
ALIAS = {
    'akita_black_bowl': 'black bowl', 'black_bowl': 'black bowl', 'white_bowl': 'white bowl',
    'porcelain_mug': 'white porcelain mug cup', 'white_yellow_mug': 'white yellow mug cup',
    'red_coffee_mug': 'red coffee mug cup', 'chefmate_8_frypan': 'frying pan frypan skillet',
    'flat_stove': 'stove burner cooktop', 'moka_pot': 'moka pot', 'desk_caddy': 'desk caddy',
    'black_book': 'black book', 'yellow_book': 'yellow book', 'cream_cheese': 'cream cheese box',
    'alphabet_soup': 'alphabet soup can', 'tomato_sauce': 'tomato sauce can',
    'bbq_sauce': 'bbq barbecue sauce bottle', 'ketchup': 'ketchup bottle', 'butter': 'butter box',
    'milk': 'milk carton', 'orange_juice': 'orange juice carton',
    'chocolate_pudding': 'chocolate pudding box', 'salad_dressing': 'salad dressing bottle',
    'new_salad_dressing': 'salad dressing bottle', 'macaroni_and_cheese': 'macaroni cheese box',
    'cookies': 'cookie cookies box', 'popcorn': 'popcorn box',
    'glazed_rim_porcelain_ramekin': 'ramekin porcelain', 'white_cabinet': 'white cabinet',
    'wooden_cabinet': 'wooden cabinet', 'wine_bottle': 'wine bottle', 'wine_rack': 'wine rack',
    'microwave': 'microwave oven', 'basket': 'basket', 'plate': 'plate',
    'wooden_tray': 'wooden tray', 'white_storage_box': 'white storage box',
}
COLORS = {'white', 'black', 'red', 'yellow', 'blue', 'green', 'brown', 'wooden', 'pink', 'orange'}
DIRS = ('left', 'right', 'front', 'back')
LEVELS = ('top', 'middle', 'bottom')
MIDW = ('middle', 'center', 'centre', 'central')
COMPART = {'compartment', 'compartments', 'section', 'slot', 'partition'}
PRON = {'it', 'them', 'its', 'their', 'there', 'they'}
STOP = {'the', 'a', 'an', 'of', 'both', 'and', 'to', 'up', 'top', 'left', 'right', 'front',
        'back', 'bottom', 'middle', 'side', 'that', 'is', 'please', 'then', 'drawer', 'drawers',
        'in', 'on', 'into', 'onto', 'inside', 'next', 'behind', 'beside', 'at', 'over', 'from',
        'near', 'between', 'with', 'this', 'which', ',', 'by', 'under', 'atop', 'out', 'off',
        'also', 'now', 'finally', 'first', 'region', 'area', 'one', 'ones'} | COMPART | PRON
VERBS = {'put', 'place', 'turn', 'switch', 'close', 'shut', 'open', 'pick', 'push', 'pull',
         'move', 'stack', 'lift', 'grab', 'take', 'set', 'insert', 'drop', 'bring', 'store',
         'transfer', 'slide'}
PICKV = {'pick', 'grab', 'lift', 'take'}
PUSHV = {'push', 'slide'}
PREPS = ('into', 'onto', 'inside', 'in', 'on', 'to', 'behind', 'next', 'beside', 'over', 'at',
         'atop', 'under')
ON_PREPS = ('on', 'onto', 'atop', 'over', None)
LOCW = {'between', 'next', 'beside', 'near', 'on', 'in', 'inside', 'from', 'at', 'behind',
        'under', 'by', 'atop'}
LOCGEN = {'the', 'a', 'an', 'of', 'on', 'in', 'from', 'at', 'to', 'and', 'region', 'table',
          'inside', 'next', 'near', 'by', ','}
LOCSEG = {'the', 'a', 'an', 'one', 'side', 'most', 'far'} | set(DIRS) | set(MIDW)
COST = {'place': 150, 'open': 90, 'close': 90, 'turn': 130, 'pick': 90, 'push': 120}


def V(*a):
    return np.array(a, dtype=float)


def P(api, n):
    return np.array(api.pos(n), dtype=float)


def E(api):
    return np.array(api.eef(), dtype=float)


def _rem(api):
    try:
        return int(api.remaining())
    except ERR:
        return 500


def _base(n):
    t = n.split('_')
    while t and t[-1].isdigit():
        t.pop()
    return '_'.join(t)


def _is_region(n):
    return n.endswith('_region') or n.endswith('_side')


def _words(s):
    s = s.lower().replace(',', ' , ').replace(';', ' , ')
    s = ''.join(c if (c.isalnum() or c == ',') else ' ' for c in s)
    return s.split()


def _desc(b):
    base = _base(b)
    w = set(base.split('_'))
    if base in ALIAS:
        w |= set(ALIAS[base].split())
    return w


def _suffix(r, owner):
    if owner and r.startswith(owner + '_'):
        return r[len(owner) + 1:]
    return r


def _rtoks(r, owner=None):
    return set(_suffix(r, owner).split('_'))


def _mentions(ws):
    """True if the words name something (content word or pronoun)."""
    return any((w not in STOP) or (w in PRON) for w in ws)


# ---------------------------------------------------------------- scene model
class Ctx(object):
    def __init__(self, api):
        self.api = api
        self.spread = {}
        try:
            names = list(api.names())
        except ERR:
            names = []
        cat = {}
        try:
            c = api.catalog()
            if isinstance(c, dict):
                cat = c
        except ERR:
            cat = {}
        for n in cat:
            if n not in names:
                names.append(n)
        self.names = names
        self.kind, self.parent = {}, {}
        for n in names:
            info = cat.get(n)
            k = p = None
            if isinstance(info, dict):
                k, p = info.get('kind'), info.get('parent')
            if k not in ('item', 'fixture', 'region'):
                k = 'region' if _is_region(n) else 'item'
            self.kind[n], self.parent[n] = k, p
        self.bodies = [n for n in names if self.kind[n] != 'region']
        self.regions = [n for n in names if self.kind[n] == 'region']
        for r in self.regions:
            if self.parent.get(r) not in self.kind:
                pre = [b for b in self.bodies if r.startswith(b + '_')]
                self.parent[r] = max(pre, key=len) if pre else None

    def regions_of(self, owner):
        if owner is None:
            return []
        return [r for r in self.regions if self.parent.get(r) == owner]


def level_regions(ctx, owner):
    out = []
    for r in ctx.regions_of(owner):
        t = _rtoks(r, owner)
        if 'side' in t or 'init' in t:
            continue
        if t & set(LEVELS):
            out.append(r)
    return out


def openness(ctx, r, owner):
    return float(np.linalg.norm(P(ctx.api, r)[:2] - P(ctx.api, owner)[:2]))


def pick_level(ctx, owner, level, act):
    regs = level_regions(ctx, owner)
    if not regs:
        return None
    if level:
        for r in regs:
            if level in _rtoks(r, owner):
                return r
    order = lambda r: next((i for i, l in enumerate(LEVELS) if l in _rtoks(r, owner)), 9)
    try:
        if act == 'open':
            return min(regs, key=lambda r: (round(openness(ctx, r, owner) / 0.03), order(r)))
        if act in ('close', 'place'):
            return max(regs, key=lambda r: (round(openness(ctx, r, owner) / 0.03), -order(r)))
    except ERR:
        pass
    return min(regs, key=order)


def drawer_done(ctx, reg, owner, act):
    others = [r for r in level_regions(ctx, owner) if r != reg]
    if not others:
        return True
    try:
        o = openness(ctx, reg, owner)
        ref = min(openness(ctx, r, owner) for r in others)
    except ERR:
        return True
    if act == 'close':
        return o <= ref + 0.03
    return o >= ref + 0.06


# ---------------------------------------------------------------- resolution
def _match(w, D):
    if w in D:
        return 1, False
    if len(w) > 3 and w.endswith('es') and w[:-2] in D:
        return 1, True
    if len(w) > 3 and w.endswith('s') and w[:-1] in D:
        return 1, True
    return 0, False


def best_bodies(ctx, words, exclude=()):
    seq = [w for w in words if w not in STOP and w not in VERBS and not w.isdigit()]
    W = set(seq)
    if not W:
        return [], False
    head = seq[-1]
    best, cands, plural = -1e9, [], False
    for b in ctx.bodies:
        if b in exclude:
            continue
        D = _desc(b)
        m, pl = 0, False
        for w in W:
            a, p = _match(w, D)
            m += a
            pl = pl or p
        if m == 0:
            continue
        hb = 0.5 if _match(head, D)[0] else 0.0     # head noun breaks ties
        s = 3.0 * m + hb - len((D & COLORS) - W) - len((W & COLORS) - D)
        if s > best + 1e-9:
            best, cands, plural = s, [b], pl
        elif abs(s - best) < 1e-9:
            cands.append(b)
            plural = plural or pl
    return cands, (plural or 'both' in words)


def _spatial(ctx, words, cands):
    api = ctx.api
    cands = sorted(cands)
    if len(cands) < 2:
        return cands
    dirs = [w for w in words if w in DIRS]
    if not dirs:
        if set(words) & set(MIDW):
            pool = [b for b in ctx.bodies if _base(b) == _base(cands[0])]
            if len(pool) < 3:
                pool = [b for b in ctx.bodies if ctx.kind.get(b) == 'item']
            try:
                m = np.mean([P(api, b) for b in pool], axis=0)
                return sorted(cands, key=lambda c: float(np.linalg.norm(P(api, c)[:2] - m[:2])))
            except ERR:
                pass
        return cands
    w = dirs[0]
    heads = set(_base(c).split('_')[-1] for c in cands)
    hints = [r for r in ctx.regions if w in r.split('_') and heads & set(r.split('_'))]
    hints.sort(key=lambda r: len(r))
    if hints:
        try:
            n = api.nearest(hints[0], list(cands))
            if n in cands:
                return [n] + [c for c in cands if c != n]
        except ERR:
            pass
        try:
            hp = P(api, hints[0])
            return sorted(cands, key=lambda c: float(np.linalg.norm(P(api, c)[:2] - hp[:2])))
        except ERR:
            pass
    keyf = {'left': lambda p: -p[1], 'right': lambda p: p[1],
            'front': lambda p: p[0], 'back': lambda p: -p[0]}[w]
    try:
        return sorted(cands, key=lambda c: float(keyf(P(api, c))))
    except ERR:
        return cands


def loc_point(ctx, loc, exclude, depth):
    api = ctx.api
    if 'between' in loc:
        rest = loc[loc.index('between') + 1:]
        parts, cur = [], []
        for w in rest:
            if w == 'and':
                parts.append(cur)
                cur = []
            else:
                cur.append(w)
        parts.append(cur)
        pts = []
        for p in parts:
            r = resolve_item(ctx, p, exclude, depth + 1)
            if r:
                pts.append(P(api, r[0]))
        if len(pts) >= 2:
            return np.mean(pts[:2], axis=0)
    prep, tw = loc[0], loc[1:]
    if tw and tw[0] == 'to':
        tw = tw[1:]
    content = [w for w in tw if w not in STOP]
    if content:
        t = resolve_target(ctx, tw, prep, None, 'place', exclude, depth + 1)
        if t and t[0]:
            return P(api, t[0])
    key = [w for w in loc if w not in LOCGEN and w not in ('middle', 'centre', 'central')]
    if not key or all(w in DIRS for w in key):
        return None
    best, bs = None, 0
    for r in ctx.regions:
        s = len(set(key) & set(r.split('_')))
        if s > bs:
            best, bs = r, s
    return P(api, best) if best else None


def resolve_item(ctx, words, exclude=(), depth=0):
    words = [w for w in words if w != ',']
    cut, seen = None, False
    for i, w in enumerate(words):
        if seen and w in LOCW:
            cut = i
            break
        if w not in STOP:
            seen = True
    head = words[:cut] if cut is not None else words
    loc = words[cut:] if cut is not None else []
    cands, plural = best_bodies(ctx, head, exclude)
    if not cands and loc:
        cands, plural = best_bodies(ctx, words, exclude)
        loc = []
    if not cands:
        return []
    if len(cands) == 1:
        return cands
    if plural:
        return sorted(cands)
    if loc and depth < 2:
        try:
            ref = loc_point(ctx, loc, tuple(cands), depth)
        except ERR:
            ref = None
        if ref is not None:
            return [min(cands, key=lambda c: float(np.linalg.norm(P(ctx.api, c) - ref)))]
    return _spatial(ctx, words, cands)[:1]


def owner_from(ctx, R, last_ref, exclude, depth):
    content = [w for w in R if w not in STOP]
    if content:
        r = resolve_item(ctx, R, exclude, depth)
        return r[0] if r else None
    if last_ref:
        return last_ref[1] or (ctx.parent.get(last_ref[0]) if last_ref[0] else None)
    return None


def rel_region(ctx, owner, d, kind):
    try:
        r = ctx.api.relative_target(owner, d, kind)
        if isinstance(r, str) and r:
            return r
    except ERR:
        pass
    if kind == 'inside':
        for r in ctx.regions_of(owner):
            if d in _rtoks(r, owner):
                return r
    ob = set(_base(owner).split('_'))
    for r in ctx.regions:
        t = set(r.split('_'))
        if d in t and ob <= t and ctx.parent.get(r) != owner:
            return r
    return None


def default_region(ctx, owner, R, prep):
    regs = ctx.regions_of(owner)
    if not regs:
        return owner
    Rs = set(R)
    on = prep in ON_PREPS
    best, bs = owner, -1e9
    for r in regs:
        t = _rtoks(r, owner)
        s = 3.0 * len((t - {'region', 'side', 'contain', 'init'}) & Rs)
        if t & {'contain', 'cook', 'heating', 'interior'}:
            s += 2
        if 'side' in t:
            s += 2.5 if on else -3
        if 'top' in t:
            s += 0.5
        if prep == 'under':
            if t & {'bottom', 'under', 'lower'}:
                s += 3
            if 'top' in t:
                s -= 2
        if t & set(DIRS):
            s -= 0.5
        if 'init' in t:
            s -= 5
        if s > bs:
            bs, best = s, r
    return best


def resolve_target(ctx, R, prep, last_ref, act='place', exclude=(), depth=0):
    """returns (target_name, owner_body) or None"""
    R = [w for w in R if w != ',']
    Rs = set(R)
    content = [w for w in R if w not in STOP and w not in VERBS]
    pron = (not R) or bool(Rs & PRON)
    # spatial relations: compartment IN a fixture vs table location NEXT TO a fixture
    for i, w in enumerate(R):
        nxt = R[i + 1] if i + 1 < len(R) else ''
        d = None
        if w == 'behind':
            d, kind, ow = 'back', 'outside', R[i + 1:]
        elif w in DIRS and (nxt in COMPART or nxt in ('of', 'side')):
            ow = R[i + 1:]
            while ow and (ow[0] in COMPART or ow[0] in ('side', 'of')):
                ow = ow[1:]
            if nxt in COMPART or (Rs & COMPART):
                kind = 'inside'
            elif prep in ('in', 'into', 'inside') and w != 'front':
                kind = 'inside'
            else:
                kind = 'outside'
            d = w
        if d:
            owner = owner_from(ctx, ow, last_ref, exclude, depth)
            if owner:
                reg = rel_region(ctx, owner, d, kind)
                if reg:
                    return (reg, owner)
            break
    level = next((w for w in R if w in LEVELS), None)
    if Rs & {'drawer', 'drawers'}:
        owner = owner_from(ctx, R, last_ref, exclude, depth)
        if owner is None or not level_regions(ctx, owner):
            fx = [b for b in ctx.bodies if level_regions(ctx, b)]
            if fx:
                owner = fx[0]
        if owner is not None:
            reg = pick_level(ctx, owner, level, act)
            if reg:
                return (reg, owner)
    if not content:
        if not pron or last_ref is None:
            return None
        reg, owner = last_ref
        if owner is None and reg:
            owner = ctx.parent.get(reg)
        if 'top' in Rs and prep in ON_PREPS and owner and act == 'place':
            for r in ctx.regions_of(owner):
                t = _rtoks(r, owner)
                if 'side' in t and 'top' in t:
                    return (r, owner)
        if reg:
            return (reg, owner)
        if owner:
            return (default_region(ctx, owner, R, prep), owner)
        return None
    owner = owner_from(ctx, R, last_ref, exclude, depth)
    if owner is None:
        return None
    if act in ('open', 'close') and level_regions(ctx, owner):
        return (pick_level(ctx, owner, level, act), owner)
    return (default_region(ctx, owner, R, prep), owner)


# ---------------------------------------------------------------- parsing
def split_clauses(words):
    out, cur = [], []
    n = len(words)
    for j, w in enumerate(words):
        nxt = words[j + 1] if j + 1 < n else ''
        if w == 'then' or (w in ('and', ',') and (nxt in VERBS or nxt in ('then', 'and'))):
            if cur:
                out.append(cur)
            cur = []
            continue
        cur.append(w)
    if cur:
        out.append(cur)
    return out


def split_items(ws):
    if 'between' in ws:
        return [[w for w in ws if w != 'both']]
    both = 'both' in ws
    has_the = any(ws[j] == 'and' and j + 1 < len(ws) and ws[j + 1] in ('the', 'a', 'an')
                  for j in range(len(ws)))
    parts = [[]]
    for j, w in enumerate(ws):
        nxt = ws[j + 1] if j + 1 < len(ws) else ''
        if w == ',' or (w == 'and' and ((has_the and nxt in ('the', 'a', 'an'))
                                       or (both and not has_the))):
            parts.append([])
        elif w != 'both':
            parts[-1].append(w)
    return [p for p in parts if p]


def resolve_items(ctx, words, exclude, last_items):
    out = []
    for part in split_items(words):
        content = [w for w in part if w not in STOP]
        if not content:
            if any(w in PRON for w in part):
                out += [it for it in last_items if it not in out]
            continue
        for it in resolve_item(ctx, part, tuple(exclude) + tuple(out)):
            if it not in out:
                out.append(it)
    return out


def has_dest(rest):
    for j, w in enumerate(rest):
        if w in ('into', 'onto'):
            return True
        if w == 'to' and (j == 0 or rest[j - 1] not in ('next', 'close')):
            return True
    return False


def find_dest(ctx, rest, last_ref):
    """split a clause body into (item words, target); skips item locators like 'at the back'."""
    pidx = [i for i, w in enumerate(rest) if w in PREPS]
    for i in pidx:
        if not _mentions(rest[:i]):
            continue
        later = [j for j in pidx if j > i]
        seg = rest[i + 1:later[0]] if later else rest[i + 1:]
        if later and seg and all(x in LOCSEG for x in seg) and \
                any(x in DIRS or x in MIDW for x in seg):
            continue   # e.g. "the butter at the back in the top drawer"
        t = resolve_target(ctx, rest[i + 1:], rest[i], last_ref, 'place')
        if t:
            return rest[:i], t
    return rest, None


def build_plan(ctx, words):
    ops, last_items, last_ref, last_support = [], [], None, None
    for c in split_clauses(words):
        while c and c[-1] in ('and', 'then', ','):
            c = c[:-1]
        if not c:
            continue
        vi = next((i for i, w in enumerate(c) if w in VERBS), None)
        if vi is None:
            if not any(w in PREPS for w in c):
                continue
            v, rest = 'put', c
        else:
            v, rest = c[vi], c[vi + 1:]
        Rs = set(rest)
        if v in ('push', 'pull', 'slide') and Rs & {'drawer', 'drawers', 'door'}:
            shut = bool(Rs & {'closed', 'shut', 'close'})
            v = 'open' if (v == 'pull' or Rs & {'open', 'out'}) and not shut else 'close'
            rest = [w for w in rest if w not in ('closed', 'shut', 'close', 'open', 'out', 'in')]
        if v in ('turn', 'switch'):
            on = 'off' not in rest
            ow = [w for w in rest if w not in ('on', 'off')]
            obj = None
            if [w for w in ow if w not in STOP]:
                r = resolve_item(ctx, ow)
                obj = r[0] if r else None
            elif last_ref:
                obj = last_ref[1]
            if obj is None:
                st = [b for b in ctx.bodies if 'stove' in _desc(b)]
                obj = st[0] if st else None
            if obj:
                ops.append(('turn', obj, on))
                last_ref = (None, obj)
            last_support = None
            continue
        if v in ('open', 'close', 'shut'):
            act = 'open' if v == 'open' else 'close'
            tgt = resolve_target(ctx, rest, None, last_ref, act)
            if tgt:
                ops.append((act, tgt))
                last_ref = tgt
            last_support = None
            continue
        rest = [w for w in rest if w != 'up']
        if v in PICKV and not has_dest(rest):
            its = resolve_items(ctx, rest, (), last_items)
            if its:
                ops.append(('pick', its[0]))
                last_items = its[:1]
            last_support = None
            continue
        item_w, tgt = find_dest(ctx, rest, last_ref)
        if tgt is None:
            continue
        excl = (tgt[1],) if tgt[1] else ()
        plural_pron = bool(set(item_w) & {'them', 'they'})
        if plural_pron and last_support and not [w for w in item_w if w not in STOP] \
                and last_support not in excl:
            items = [last_support]     # move a freshly built stack by its base
        else:
            items = resolve_items(ctx, item_w, excl, last_items)
        if ops and ops[-1][0] == 'pick' and ops[-1][1] in items:
            ops.pop()
        kind = 'push' if v in PUSHV else 'place'
        for k, it in enumerate(items):
            ops.append((kind, it, tgt, k, len(items)))
        owner = tgt[1]
        last_support = None
        if items and owner and owner not in items and ctx.kind.get(owner) == 'item' and \
                (tgt[0] == owner or ctx.parent.get(tgt[0]) == owner):
            last_support = owner
        if items:
            last_items = items
        last_ref = tgt
    return ops


# ---------------------------------------------------------------- physical primitives (legacy)
def grasp_offsets(item):
    b = _base(item)
    if 'mug' in b or 'cup' in b:
        return [(0.0, 0.03, 0.02), (0.0, -0.03, 0.02)]
    if 'bowl' in b:
        return [(0.0, 0.045, 0.01), (0.0, -0.045, 0.01)]
    return [(0.0, 0.0, 0.0), (0.0, 0.0, -0.01)]


def item_radius(item):
    D = _desc(item)
    if D & {'plate', 'tray', 'frypan', 'pan', 'basket'}:
        return 0.10
    if D & {'bowl', 'ramekin'}:
        return 0.07
    if D & {'pot', 'mug', 'cup'}:
        return 0.05
    return 0.04


def recover(api):
    api.grip(False)
    e = E(api)
    api.move(e + V(0, 0, 0.10), steps=10)


def drawer_dir(api, region, owner):
    rp = P(api, region)
    op = P(api, owner) if owner else rp
    d = op[:2] - rp[:2]
    nd = np.linalg.norm(d)
    d = d / nd if nd > 0.03 else np.array([1.0, 0.0])
    return np.array([d[0], d[1], 0.0])


def push_close(api, name, owner):
    rp = P(api, name)
    d3 = drawer_dir(api, name, owner)
    start = rp - d3 * 0.20
    start[2] = rp[2] + 0.03
    e = E(api)
    high = max(e[2], rp[2] + 0.15)
    api.move(V(e[0], e[1], high), steps=15)
    api.move(V(start[0], start[1], high), steps=30)
    api.grip(True)
    api.move(start, steps=25)
    api.move(start + d3 * 0.32, steps=60)
    back = start + d3 * 0.20
    api.move(back, steps=10)
    api.move(back + V(0, 0, 0.12), steps=15)


def pull_open(api, name, owner):
    rp = P(api, name)
    d3 = drawer_dir(api, name, owner)
    handle = rp - d3 * 0.13
    handle[2] = rp[2] + 0.04
    pre = handle - d3 * 0.08
    e = E(api)
    api.grip(False)
    api.move(V(e[0], e[1], max(e[2], handle[2] + 0.12)), steps=15)
    api.move(pre + V(0, 0, 0.10), steps=30)
    api.move(pre, steps=20)
    api.move(handle, steps=20)
    api.grip(True)
    api.move(handle - d3 * 0.22, steps=50)
    api.grip(False)
    e = E(api)
    api.move(e + V(0, 0, 0.10), steps=15)


def twist_knob(api, k, grasp_z, on):
    sgn = 1.0 if on else -1.0
    api.grip(False)
    e = E(api)
    api.move(V(e[0], e[1], max(e[2], grasp_z + 0.15)), steps=15)
    api.move(V(k[0], k[1], grasp_z + 0.10), steps=25)
    api.move(V(k[0], k[1], grasp_z), steps=20)
    api.grip(True)
    api.action([0, 0, 0, 0, 0, 0.35 * sgn, 1.0], steps=12)
    api.grip(False)
    e = E(api)
    api.move(e + V(0, 0, 0.10), steps=12)
    api.action([0, 0, 0, 0, 0, -0.35 * sgn, -1.0], steps=12)


def sweep_stove(api, sp, cp, on):
    sgn = 1.0 if on else -1.0
    e = E(api)
    api.move(V(e[0], e[1], max(e[2], cp[2] + 0.15)), steps=15)
    api.grip(True)
    lines = [(cp[0] - 0.07, cp[2] + 0.015),
             (min(sp[0], cp[0]) - 0.13, max(cp[2] - 0.015, sp[2] + 0.012))]
    for x, z in lines:
        a = V(x, cp[1] + 0.13 * sgn, z)
        b = V(x, cp[1] - 0.13 * sgn, z)
        api.move(V(a[0], a[1], cp[2] + 0.12), steps=25)
        api.move(a, steps=20)
        api.move(b, steps=45)
        api.move(V(b[0], b[1], cp[2] + 0.12), steps=15)


def turn_stove(api, stove, names, on):
    kp = None
    for n in names:
        if n.startswith(_base(stove)) and any(k in n for k in ('knob', 'button', 'switch')):
            try:
                kp = P(api, n)
                break
            except ERR:
                pass
    if kp is None:
        for suf in ('_knob', '_button', '_knob_1', '_switch'):
            try:
                kp = P(api, stove + suf)
                break
            except ERR:
                kp = None
    cook = [n for n in names if n.startswith(stove + '_') and 'cook' in n]
    sp = P(api, stove)
    cp = P(api, cook[0]) if cook else sp + V(0, 0, 0.02)
    if kp is not None:
        twist_knob(api, kp, kp[2] + 0.005, on)
        return
    d = sp[:2] - cp[:2]
    nd = np.linalg.norm(d)
    if nd >= 0.025:
        if nd > 0.15:
            d = d / nd * 0.15
        k = V(sp[0] + d[0], sp[1] + d[1], cp[2])
        twist_knob(api, k, cp[2] + 0.005, on)
        return
    sweep_stove(api, sp, cp, on)


def pick_only(api, item):
    g = np.array(grasp_offsets(item)[0])
    p = P(api, item) + g
    api.grip(False)
    api.move(p + V(0, 0, 0.12), steps=30)
    api.move(p, steps=25)
    api.grip(True)
    api.move(p + V(0, 0, 0.15), steps=25)


# ---------------------------------------------------------------- measured skills
def grasp_modes(item):
    D = _desc(item)
    if 'bowl' in D and 'drainer' not in D:
        return ['rim', 'standard']
    if D & {'book', 'notebook'}:
        return ['thin_edge', 'standard']
    return ['standard']


def placed_ok(ctx, item, target, owner):
    api = ctx.api
    try:
        ip, tp = P(api, item), P(api, target)
    except ERR:
        return False
    t = _rtoks(target, owner)
    lv = level_regions(ctx, owner) if owner else []
    if ctx.kind.get(target) != 'region':
        tol = 0.075
    elif 'contain' in t:
        tol = 0.06 if t & set(DIRS) else 0.09
    elif target in lv:
        tol = 0.11
    elif 'side' in t:
        tol = 0.13
    else:
        tol = 0.085
    if np.linalg.norm(ip[:2] - tp[:2]) > tol:
        return False
    if ip[2] < tp[2] - 0.08 or ip[2] > tp[2] + 0.30:
        return False
    try:
        if np.linalg.norm(E(api) - ip) < 0.03 and ip[2] > tp[2] + 0.08:
            return False   # still in the fingers
    except ERR:
        pass
    sib = ctx.regions_of(owner) if owner and owner != target else []
    if target in sib and len(sib) > 1:
        use_xy = bool(t & set(DIRS))

        def dd(r):
            q = P(api, r)
            return float(np.linalg.norm((ip - q)[:2]) if use_xy else np.linalg.norm(ip - q))
        try:
            if min(sib, key=dd) != target:
                return False
        except ERR:
            pass
    return True


def attempt_place(ctx, item, target, mode):
    api = ctx.api
    try:
        obs = api.attempt({'op': 'place', 'item': item, 'target': target, 'grasp': mode})
        return obs if isinstance(obs, dict) else {}
    except ERR:
        pass
    for m in (mode, 'standard'):
        try:
            api.place_with(item, target, m)
            return {}
        except ERR:
            pass
    try:
        api.arrange([(item, target)])
        return {}
    except ERR:
        pass
    try:
        lift = api.transfer(item, target, grasp=grasp_offsets(item)[0], drop=(0, 0, 0.08))
        return {'max_lift': float(lift) if lift is not None else None}
    except ERR:
        return {}


def release_if_held(ctx, item):
    api = ctx.api
    try:
        e, ip = E(api), P(api, item)
        if np.linalg.norm(e - ip) < 0.06:
            api.grip(False)
            api.move(e + V(0, 0, 0.08), steps=8)
    except ERR:
        pass


def spread_ok(ctx, target, owner):
    """several items share one flat surface (burner, plate, cabinet top)"""
    t = _rtoks(target, owner) if ctx.kind.get(target) == 'region' else set()
    if t & {'contain', 'interior', 'heating'}:
        return False
    if owner and target in level_regions(ctx, owner):
        return False
    D = _desc(owner) if owner else set()
    if D & {'basket', 'tray', 'box', 'caddy', 'bowl', 'microwave', 'drawer'}:
        return False
    return True


def spread_place(ctx, item, target, owner):
    api = ctx.api
    try:
        ip, tp = P(api, item), P(api, target)
    except ERR:
        return False
    if target in ctx.spread:
        sgn = -ctx.spread[target]
    else:
        sgn = 1.0 if ip[1] >= tp[1] else -1.0
    ctx.spread[target] = sgn
    try:
        api.transfer(item, target, grasp=grasp_offsets(item)[0], drop=(0.0, 0.045 * sgn, 0.08))
    except ERR:
        return False
    return placed_ok(ctx, item, target, owner)


def push_item(ctx, item, target, owner):
    """slide an object across the table with closed fingers"""
    api = ctx.api
    r = item_radius(item)
    for k in range(3):
        if _rem(api) < 60:
            break
        ip, tp = P(api, item), P(api, target)
        d = tp[:2] - ip[:2]
        dist = float(np.linalg.norm(d))
        if dist < 0.025:
            break
        u = d / dist
        z = ip[2] + 0.01
        s = ip[:2] - u * (r + 0.05)
        f = tp[:2] - u * (r - 0.005)
        e = E(api)
        safe = max(e[2], ip[2] + 0.15)
        api.move(V(e[0], e[1], safe), steps=12)
        api.grip(True)
        api.move(V(s[0], s[1], safe), steps=25)
        api.move(V(s[0], s[1], z), steps=20)
        api.move(V(f[0], f[1], z), steps=int(min(80, 25 + dist * 120)))
        e = E(api)
        api.move(V(e[0], e[1], z + 0.12), steps=12)
        if placed_ok(ctx, item, target, owner):
            return True
    return placed_ok(ctx, item, target, owner)


def exec_drawer(ctx, act, tgt, reserve, retry=True):
    api = ctx.api
    reg, owner = tgt
    if owner is None and reg is not None:
        owner = ctx.parent.get(reg)
    lv = level_regions(ctx, owner) if owner else []
    if lv and reg not in lv:
        reg = pick_level(ctx, owner, None, act)
    if reg is None:
        reg = owner
    if reg is None:
        return False
    for t in range(2 if retry else 1):
        try:
            before = P(api, reg)
        except ERR:
            before = None
        obs = None
        try:
            obs = api.attempt({'op': act, 'target': reg})
            if not isinstance(obs, dict):
                obs = {}
        except ERR:
            try:
                api.drawer(reg, act)
                obs = {}
            except ERR:
                obs = None
        if obs is None:   # unsupported fixture: physical push/pull
            try:
                (pull_open if act == 'open' else push_close)(api, reg, owner)
            except ERR:
                pass
            return True
        moved = 0.0
        d = obs.get('delta_xyz')
        try:
            if d is not None:
                moved = float(np.linalg.norm(np.array(d, dtype=float)))
            if before is not None:
                moved = max(moved, float(np.linalg.norm(P(api, reg) - before)))
        except ERR:
            pass
        if moved > 0.02 or not lv or drawer_done(ctx, reg, owner, act):
            return True
        if _rem(api) < reserve + 100:
            return True
    return True


def exec_place(ctx, item, tgt, reserve, k=0, n=1):
    api = ctx.api
    target, owner = tgt
    modes = grasp_modes(item)
    mi, opened = 0, False
    drawerish = bool(owner) and target in level_regions(ctx, owner)
    tries = 3
    if n > 1 and spread_ok(ctx, target, owner) and _rem(api) > 150:
        if spread_place(ctx, item, target, owner):
            return True
        release_if_held(ctx, item)
        tries = 2
    for t in range(tries):
        if _rem(api) < 45:
            break
        try:
            z0 = P(api, item)[2]
        except ERR:
            z0 = None
        obs = attempt_place(ctx, item, target, modes[mi])
        if placed_ok(ctx, item, target, owner):
            return True
        lift = obs.get('max_lift') if isinstance(obs, dict) else None
        release_if_held(ctx, item)
        try:
            if z0 is not None and P(api, item)[2] < z0 - 0.15:
                return False   # fell off the table
        except ERR:
            pass
        if lift is not None and lift < 0.015:
            if mi + 1 < len(modes):
                mi += 1
        elif drawerish and not opened and _rem(api) > reserve + 150:
            exec_drawer(ctx, 'open', (target, owner), reserve, retry=False)
            opened = True
    return False


def execute(ctx, op, reserve):
    api = ctx.api
    k = op[0]
    if k == 'place':
        return exec_place(ctx, op[1], op[2], reserve, op[3], op[4])
    if k == 'push':
        if push_item(ctx, op[1], op[2][0], op[2][1]):
            return True
        release_if_held(ctx, op[1])
        return exec_place(ctx, op[1], op[2], reserve)
    if k in ('open', 'close'):
        return exec_drawer(ctx, k, op[1], reserve)
    if k == 'turn':
        turn_stove(api, op[1], ctx.names, op[2])
        return True
    if k == 'pick':
        pick_only(api, op[1])
        return True
    return False


# ---------------------------------------------------------------- main
def run(api):
    ops = None
    try:
        ctx = Ctx(api)
        ops = build_plan(ctx, _words(api.instruction))
    except ERR:
        ops = None
    if not ops:
        try:
            api.fallback()
        except ERR:
            pass
        return
    failed = []
    for i, op in enumerate(ops):
        if _rem(api) <= 0:
            return
        reserve = sum(COST.get(o[0], 100) for o in ops[i + 1:])
        try:
            ok = execute(ctx, op, reserve)
        except ERR:
            ok = False
            try:
                recover(api)
            except ERR:
                pass
        if not ok and op[0] in ('place', 'push'):
            failed.append(op)
    # order-free tasks only: one more pass over failed placements
    if failed and all(o[0] in ('place', 'push') for o in ops):
        for op in failed:
            if _rem(api) < 100:
                break
            try:
                if not placed_ok(ctx, op[1], op[2][0], op[2][1]):
                    execute(ctx, op, 0)
            except ERR:
                pass
