def run(api):
    import numpy as np

    cat = api.catalog()
    aliases = {
        "porcelain": "white", "frypan": "pan", "compartment": "contain",
        "compartments": "contain", "inside": "in", "into": "in",
        "onto": "on", "upper": "top", "lower": "bottom",
        "bottommost": "bottom", "topmost": "top", "rear": "back",
        "centre": "middle", "center": "middle", "books": "book",
        "bowls": "bowl", "plates": "plate", "mugs": "mug",
        "drawers": "drawer", "boxes": "box"
    }
    stop = set("the a an both all of to please then and box object objects".split())
    directions = set("left right front back top bottom middle".split())
    colors = set("white black red yellow blue green orange".split())

    def words(s):
        s = "".join(c if c.isalnum() else " " for c in s.lower())
        return [aliases.get(w, w) for w in s.split() if not w.isdigit()]

    def tokens(s):
        return set(words(s)) - stop

    def position(n):
        try:
            p = np.asarray(api.pos(n), dtype=float)
            return p if p.shape == (3,) and np.isfinite(p).all() else None
        except Exception:
            return None

    def parent(n):
        return cat.get(n, {}).get("parent")

    def label(n):
        t = tokens(n)
        p = parent(n)
        if p in cat:
            t |= tokens(p)
        if "region" in t and "init" not in t:
            if "cabinet" in t and t & {"top", "middle", "bottom"}:
                t.add("drawer")
        return t

    labels = {n: label(n) for n in cat}
    initial = {n: position(n) for n in cat}
    last, pending = None, None
    drawer_state = {}

    def owner(n):
        p = parent(n)
        if p in cat:
            return p
        candidates = [x for x in cat if x != n and n.startswith(x + "_")]
        return max(candidates, key=len) if candidates else n

    def axis(d):
        # Learn world directions from labelled scene regions when possible.
        opposite = {"left": "right", "right": "left",
                    "front": "back", "back": "front",
                    "top": "bottom", "bottom": "top"}
        vectors = []
        for a in cat:
            if d not in labels[a] or initial[a] is None:
                continue
            for b in cat:
                if opposite.get(d) not in labels[b] or initial[b] is None:
                    continue
                if labels[a] - {d} == labels[b] - {opposite[d]}:
                    v = initial[a] - initial[b]
                    if d not in ("top", "bottom"):
                        v = v.copy()
                        v[2] = 0
                    if np.linalg.norm(v) > .01:
                        vectors.append(v / np.linalg.norm(v))
        v = np.mean(vectors, axis=0) if vectors else np.array({
            "left": [-1., 0, 0], "right": [1., 0, 0],
            "front": [0, -1., 0], "back": [0, 1., 0],
            "top": [0, 0, 1.], "bottom": [0, 0, -1.]
        }[d])
        return v / max(np.linalg.norm(v), 1e-9)

    def resolve(text, source=False, reference=None):
        q = tokens(text)
        if not q:
            return None
        if q <= {"it", "there", "them", "this", "that", "top", "on", "in"}:
            n = reference or last
            if not n:
                return None
            if "top" in q:
                n = owner(n)
                return resolve(n + " top surface", reference=n) or n
            return n

        relation, anchor = None, None
        normalized = " ".join(words(text))
        for phrase, rel in (
            ("left of", "left"), ("right of", "right"),
            ("in front of", "front"), ("behind", "back"),
            ("closest to", "near"), ("nearest to", "near"), ("near", "near")
        ):
            if " " + phrase + " " in " " + normalized + " ":
                a, b = normalized.split(phrase, 1)
                anchor = resolve(b, reference=reference)
                if anchor:
                    relation, q = rel, tokens(a)
                break

        core = q - directions - {
            "in", "on", "surface", "drawer", "contain", "it", "there",
            "nearest", "closest", "near"
        }
        if not core and reference:
            core = labels[owner(reference)] - {"region", "init"}
        if not core and not q & {"drawer", "contain"}:
            return None

        scored = []
        for n, info in cat.items():
            t = labels[n]
            if "init" in t or (source and info["kind"] != "item"):
                continue
            if core and not core & t:
                continue
            if not core and not q & t & {"drawer", "contain"}:
                continue
            p = position(n)
            if p is None:
                continue
            score = 5 * len(core & t) - 6 * len(core - t)
            score -= 2 * len((t & colors) - q)
            score += 3 * len(q & directions & t)
            score -= 4 * len((q & directions) - t) if info["kind"] == "region" else 0
            if "drawer" in q:
                score += 8 if "drawer" in t else -8
            if "contain" in q:
                score += 6 if "contain" in t else -3
            if not source and info["kind"] == "region":
                score += 1
                if "top" in q or "surface" in q:
                    score += 9 if "side" in t else 0
                elif "drawer" not in q:
                    score += 3 if t & {"contain", "cook"} else 0
                    score -= 4 if "drawer" in t else 0

            for d in q & directions - {"middle"}:
                if d in t:
                    continue
                anchors = [
                    a for a in cat
                    if d in labels[a] and core & labels[a]
                    and initial[a] is not None
                ]
                if anchors:
                    score += max(
                        5 - 25 * np.linalg.norm(p[:2] - initial[a][:2])
                        for a in anchors
                    )
                else:
                    score += 2 * float(np.dot(p, axis(d)))
            if anchor:
                ap = position(anchor)
                if ap is None or n == anchor:
                    continue
                v = p - ap
                if relation == "near":
                    score -= 15 * np.linalg.norm(v)
                else:
                    projection = float(np.dot(v, axis(relation)))
                    if projection <= .015:
                        continue
                    score -= 3 * np.linalg.norm(v)
                    score += min(projection, .3)
            scored.append((score, n))
        return max(scored)[1] if scored else None

    def act(step):
        if api.remaining() <= 0:
            return {}
        for key in ("item", "target"):
            if key in step and position(step[key]) is None:
                return {}
        result = api.act(step)
        # Refresh observations after every physical action.
        for key in ("item", "target"):
            if key in step:
                position(step[key])
        api.remaining()
        return result if isinstance(result, dict) else {}

    def drawer(n):
        return n in labels and "drawer" in labels[n]

    def ensure_open(n):
        if not drawer(n) or drawer_state.get(n) == "open":
            return
        p = position(n)
        siblings = [
            position(x) for x in cat
            if x != n and drawer(x) and owner(x) == owner(n)
        ]
        siblings = [x for x in siblings if x is not None]
        closed = drawer_state.get(n) == "close"
        if p is not None and siblings:
            closed |= np.linalg.norm(
                p[:2] - np.median(np.array(siblings)[:, :2], axis=0)
            ) < .045
        if closed:
            r = act({"op": "open", "target": n})
            if r.get("executed"):
                drawer_state[n] = "open"

    def place(item, target):
        if not item or not target or item == target:
            return
        ensure_open(target)
        t = labels[item]
        grasps = (["thin_edge", "standard", "rim"] if t & {"book", "plate"}
                  else ["rim", "standard", "thin_edge"] if t & {"bowl", "mug", "cup"}
                  else ["standard", "rim", "thin_edge"])
        for grasp in grasps:
            if api.remaining() <= 0:
                break
            r = act({"op": "place", "item": item, "target": target,
                     "grasps": [grasp]})
            lift = r.get("max_lift")
            if not r.get("executed") or lift is None or lift > .015:
                break

    def sources(text):
        text = text.replace("both ", "").strip()
        parts = text.split(" and ")
        if len(parts) > 1:
            found = [resolve(p, source=True, reference=pending) for p in parts]
            if all(found) and len(set(found)) == len(found):
                return found
        if text in ("it", "them") and pending:
            return [pending]
        n = resolve(text, source=True, reference=pending)
        return [n] if n else []

    # Split at action verbs, preserving conjunctions inside object descriptions.
    verbs = {"put", "place", "move", "transfer", "set", "pick", "take",
             "open", "close", "shut", "turn", "switch", "push", "pull", "slide"}
    raw = api.instruction.lower()
    for mark in ",.;:\n":
        raw = raw.replace(mark, " and ")
    ws = raw.split()
    starts = [i for i, w in enumerate(ws) if w in verbs]
    clauses = []
    for j, i in enumerate(starts):
        end = starts[j + 1] if j + 1 < len(starts) else len(ws)
        part = ws[i:end]
        while part and part[-1] in ("and", "then"):
            part.pop()
        clauses.append(part)

    for clause in clauses:
        if api.remaining() <= 0:
            break
        verb, body = clause[0], " ".join(clause[1:])
        if verb in ("pick", "take") and not any(
            " " + p + " " in " " + body + " "
            for p in ("in", "into", "on", "onto")
        ):
            pending = resolve(body.replace("up ", "", 1), source=True)
            continue

        if verb in ("open", "close", "shut"):
            n = resolve(body, reference=last)
            if n and drawer(n):
                op = "close" if verb == "shut" else verb
                r = act({"op": op, "target": n})
                if r.get("executed"):
                    drawer_state[n] = op
                last = n
            continue

        if verb in ("turn", "switch", "push", "pull", "slide"):
            description = body
            for w in ("on", "off", "forward", "backward"):
                description = " ".join(x for x in description.split() if x != w)
            n = resolve(description, reference=last)
            if not n:
                continue
            d = next((x for x in ("left", "right", "front", "back")
                      if x in tokens(body)), None)
            delta = axis(d) * .12 if d else np.array([0., -.12, 0.])
            if verb == "pull" or "off" in body.split():
                delta = -delta
            controls = [x for x in cat if owner(x) == owner(n)
                        and labels[x] & {"knob", "button", "switch"}]
            target = controls[0] if len(controls) == 1 else n
            offset = [0., 0., 0.] if controls else [0., -.08, .04]
            act({"op": "stroke", "target": target,
                 "offset": offset, "delta": delta.tolist()})
            last = n
            continue

        bw = body.split()
        separators = [i for i, w in enumerate(bw)
                      if w in ("in", "into", "on", "onto", "inside")]
        if not separators:
            continue
        i = separators[0]
        source_text, target_text = " ".join(bw[:i]), " ".join(bw[i + 1:])
        if not source_text or not target_text:
            continue
        target = resolve(target_text, reference=last)
        if not target:
            continue
        items = sources(source_text)
        for item in items:
            place(item, target)
            pending = item
        if items:
            last = target
