def run(api):
    import numpy as np
    import math

    catalog = api.catalog()

    def words(text):
        return "".join(c.lower() if c.isalpha() else " " for c in text).split()

    tokens = {n: set(words(n)) for n in catalog}
    vocab = set().union(*tokens.values()) if tokens else set()
    synonyms = {
        "cup": ("mug",), "drawer": ("region",),
        "compartment": ("contain", "region"), "inside": ("contain",),
        "cabinet": ("cabinet",), "cupboard": ("cabinet",),
        "rear": ("back",), "upper": ("top",), "lower": ("bottom",),
        "center": ("middle",), "centre": ("middle",),
        "middle": ("middle", "center"), "frontmost": ("front",),
        "backmost": ("back",), "leftmost": ("left",),
        "rightmost": ("right",), "highest": ("top",),
        "lowest": ("bottom",), "container": ("contain",),
        "white": ("white", "porcelain"), "pan": ("frypan",),
        "cooktop": ("stove",), "burner": ("stove",),
    }
    spatial = {"left", "right", "front", "back", "top", "bottom", "middle"}
    filler = set(words(
        "a an the both all and of to into onto in on at from near beside "
        "that which is it them there this its up down please then "
        "put place move transfer pick set take grab insert return "
        "open close shut turn switch push slide pull"
    ))
    structural = {"region", "init", "contain", "side"}
    last_item = last_target = last_owner = None

    def position(name):
        p = np.asarray(api.pos(name), dtype=float)
        return p if p.shape == (3,) and np.all(np.isfinite(p)) else None

    def mapped(word):
        if word in spatial:
            return word
        for candidate in synonyms.get(word, (word,)):
            if candidate in vocab:
                return candidate
        return None

    def selector(kind, terms, parent=None):
        result = {"kind": kind, "terms": sorted(set(terms))}
        if parent is not None:
            result["parent"] = parent
        return result

    def candidates(intent):
        return [
            n for n, data in catalog.items()
            if data["kind"] == intent["kind"]
            and set(intent["terms"]) <= tokens[n]
            and ("parent" not in intent or data["parent"] == intent["parent"])
        ]

    def nominate(intent):
        names = candidates(intent)
        if not names:
            return None
        locations = {n: position(n) for n in names}
        if "near" in intent:
            anchor = position(intent["near"])
            if anchor is None:
                return None
            names = [n for n in names if locations[n] is not None]
            names.sort(key=lambda n: float(np.linalg.norm(locations[n] - anchor)))
        elif "axis" in intent:
            axis = "xyz".index(intent["axis"])
            names = [n for n in names if locations[n] is not None]
            names.sort(key=lambda n: float(locations[n][axis]))
            if intent["rank"] == "max":
                names.reverse()
            elif intent["rank"] == "median" and names:
                names = [names[len(names) // 2]]
        return names[0] if names else None

    def reference(name):
        if name is None:
            return None
        # References retain the previously established semantic identity.
        return name, dict(saved[name])

    saved = {}

    def resolve(phrase, destination=False, relation=None, drawer=False):
        nonlocal last_item, last_target, last_owner
        raw = words(phrase)
        if not raw:
            return None
        meaningful = [w for w in raw if w not in filler]
        if not meaningful:
            if not any(w in raw for w in ("it", "them", "there", "its")):
                return None
            ref = (last_owner or last_target) if destination else last_item
            if drawer:
                ref = last_target
            if ref is None:
                return None
            if not destination or drawer or relation not in ("on", "onto"):
                return reference(ref)
            meaningful = ["top"]
            raw = meaningful

        directions = {mapped(w) for w in meaningful} & spatial
        content = [
            mapped(w) for w in meaningful
            if mapped(w) is not None and mapped(w) not in spatial
            and w not in ("drawer", "compartment", "box", "object", "thing")
        ]

        # An owner is inferred from the noun phrase, never from a numeric suffix.
        owners = []
        for n, data in catalog.items():
            if data["kind"] not in ("fixture", "item"):
                continue
            overlap = set(content) & tokens[n]
            if overlap:
                owners.append((len(overlap), n))
        owners.sort(key=lambda pair: -pair[0])
        owner = None
        if owners and (len(owners) == 1 or owners[0][0] > owners[1][0]):
            owner = owners[0][1]
        if destination and meaningful == ["top"] and last_owner:
            owner = last_owner

        regions = [
            n for n, data in catalog.items()
            if data["kind"] == "region"
            and owner is not None and data["parent"] == owner
            and "init" not in tokens[n]
        ]
        use_region = destination and bool(regions)
        if drawer:
            use_region = True

        kind = "region" if use_region else "item"
        if destination and not use_region and owner:
            kind = catalog[owner]["kind"]

        pool = [
            n for n, data in catalog.items()
            if data["kind"] == kind
            and (not use_region or owner is None or data["parent"] == owner)
            and (not use_region or "init" not in tokens[n])
        ]
        if not pool:
            return None

        # Map synonyms against this role's candidates, retaining noun/color constraints.
        terms = []
        ignored = filler | {"drawer", "compartment", "box", "object", "thing"}
        for word in meaningful:
            if word in ignored or mapped(word) in spatial:
                continue
            choices = synonyms.get(word, (word,))
            available = [t for t in choices if any(t in tokens[n] for n in pool)]
            if not available:
                # Unknown descriptive words must not silently select an arbitrary object.
                if word not in ("small", "large", "little", "big"):
                    return None
                return None
            term = available[0]
            if word == "white" and "yellow" not in raw and "porcelain" in available:
                term = "porcelain"
            if not use_region or owner is None or term not in tokens[owner]:
                terms.append(term)

        if use_region:
            for direction in directions:
                if any(direction in tokens[n] for n in pool):
                    terms.append(direction)
            if drawer:
                if "region" in vocab:
                    terms.append("region")
                pool = [n for n in pool if "side" not in tokens[n]]
            elif relation in ("on", "onto") and any("side" in tokens[n] for n in pool):
                terms.extend(["top", "side"])
            elif not directions and any("contain" in tokens[n] for n in pool):
                terms.append("contain")

        if not terms and not (use_region and owner):
            return None
        intent = selector(kind, terms, owner if use_region else None)
        matches = candidates(intent)
        if drawer:
            matches = [n for n in matches if "side" not in tokens[n]]
        if not matches:
            return None

        # Prefer observed spatial labels to an assumed coordinate convention.
        for direction in directions:
            if direction in intent["terms"]:
                continue
            anchors = [
                n for n, data in catalog.items()
                if data["kind"] == "region" and direction in tokens[n]
                and set(terms) <= tokens[n]
                and (owner is None or not use_region or data["parent"] == owner)
            ]
            if len(anchors) == 1:
                intent["near"] = anchors[0]
            elif not anchors:
                axis, rank = {
                    "left": ("x", "min"), "right": ("x", "max"),
                    "front": ("y", "min"), "back": ("y", "max"),
                    "bottom": ("z", "min"), "top": ("z", "max"),
                    "middle": ("z", "median"),
                }[direction]
                intent.update(axis=axis, rank=rank)
            else:
                return None

        pick = nominate(intent)
        if pick is None:
            return None
        saved[pick] = dict(intent)
        return pick, intent

    def execute(step):
        if api.remaining() <= 0:
            return None
        for role in step["expect"]:
            if position(step[role]) is None:
                return None
        evidence = api.preview(step)
        if evidence is not None:
            for role in step["expect"]:
                record = evidence.get(role, {})
                if record.get("status") not in ("confirmed", "corrected"):
                    return None
                resolved = record.get("resolved")
                if isinstance(resolved, str) and resolved in catalog:
                    step[role] = resolved
        if api.remaining() <= 0:
            return None
        receipt = api.act(step)
        for role in step["expect"]:
            position(step[role])
        api.remaining()
        return receipt if receipt and receipt.get("executed") else None

    verbs = {
        "put", "place", "move", "transfer", "set", "insert", "return",
        "pick", "take", "grab", "open", "close", "shut",
        "turn", "switch", "push", "slide", "pull",
    }
    text = words(api.instruction)
    starts = [i for i, word in enumerate(text) if word in verbs]
    clauses = [
        text[start:(starts[j + 1] if j + 1 < len(starts) else len(text))]
        for j, start in enumerate(starts)
    ]
    pending = None
    receipts = []

    for clause in clauses:
        if api.remaining() <= 0:
            break
        verb, body = clause[0], clause[1:]
        while body and body[-1] in ("and", "then"):
            body.pop()
        if verb in ("pick", "take", "grab"):
            pending = " ".join(body)
            resolved = resolve(pending)
            if resolved:
                last_item = resolved[0]
            continue

        if verb in ("open", "close", "shut"):
            result = resolve(" ".join(body), True, drawer=True)
            if result is None:
                break
            target, intent = result
            receipt = execute({
                "op": "open" if verb == "open" else "close",
                "target": target, "expect": {"target": intent},
            })
            if receipt is None:
                break
            receipts.append(receipt)
            last_target = target
            last_owner = catalog[target]["parent"]
            continue

        if verb in ("turn", "switch", "push", "slide", "pull"):
            phrase = " ".join(w for w in body if w not in ("on", "off"))
            result = resolve(phrase, True)
            if result is None:
                break
            target, intent = result
            delta = np.zeros(3)
            direction = next((w for w in body if w in spatial), None)
            axis, sign = {
                "left": (0, -1), "right": (0, 1),
                "front": (1, -1), "back": (1, 1),
                "top": (2, 1), "bottom": (2, -1),
            }.get(direction, (1, -1 if "off" in body or verb == "pull" else 1))
            delta[axis] = sign * 0.10
            receipt = execute({
                "op": "stroke", "target": target,
                "offset": [0.0, 0.0, 0.02], "delta": delta.tolist(),
                "expect": {"target": intent},
            })
            if receipt is None:
                break
            receipts.append(receipt)
            last_target = target
            last_owner = catalog[target]["parent"] or target
            continue

        separators = [
            i for i, word in enumerate(body)
            if word in ("in", "into", "on", "onto", "to")
        ]
        if not separators:
            break
        split = separators[-1]
        relation = body[split]
        source = " ".join(body[:split])
        destination = " ".join(body[split + 1:])
        if words(source) in (["it"], ["up", "it"]) and pending:
            source = pending
        target_result = resolve(destination, True, relation)
        if target_result is None:
            break
        target, target_intent = target_result

        # Split coordinated objects only when both sides independently ground.
        source_words = words(source)
        sources = [source]
        for i, word in enumerate(source_words):
            if word == "and":
                left = " ".join(source_words[:i])
                right = " ".join(source_words[i + 1:])
                if resolve(left) and resolve(right):
                    sources = [left, right]
                    break

        failed = False
        for phrase in sources:
            item_result = resolve(phrase)
            if item_result is None:
                failed = True
                break
            item, item_intent = item_result
            if item == target:
                failed = True
                break
            grasps = (
                ["thin_edge", "standard", "rim"] if "book" in tokens[item]
                else ["standard", "rim", "thin_edge"]
            )
            step = {
                "op": "place", "item": item, "target": target,
                "grasps": grasps,
                "expect": {"item": item_intent, "target": target_intent},
            }
            receipt = execute(step)
            if receipt is None:
                failed = True
                break
            receipts.append(receipt)
            last_item = step["item"]
            last_target = step["target"]
            last_owner = catalog[last_target]["parent"] or last_target
        pending = None
        if failed:
            break
    return receipts
