def run(api):
    import numpy as np

    cat = api.catalog()
    names = list(cat)
    last_item = last_target = None
    drawer_state = {}
    stopped = False

    aliases = {
        "cup": "mug", "cups": "mug", "mugs": "mug", "bowls": "bowl",
        "plates": "plate", "books": "book", "compartments": "compartment",
        "lowest": "bottom", "upper": "top", "highest": "top",
        "lower": "bottom", "rear": "back", "uppermost": "top",
        "lowermost": "bottom", "centre": "middle", "center": "middle",
        "into": "in", "onto": "on", "shut": "close",
    }
    filler = set("the a an both all please then gently carefully of to".split())
    directions = set("left right front back top bottom middle".split())
    structural = set("in on inside drawer compartment shelf surface region side contain".split())

    def words(s):
        s = "".join(c.lower() if c.isalnum() else " " for c in s)
        return [aliases.get(w, w) for w in s.split() if not w.isdigit()]

    labels = {n: set(words(n)) for n in names}

    def position(n):
        try:
            p = np.asarray(api.pos(n), dtype=float)
            return p if p.shape == (3,) and np.all(np.isfinite(p)) else None
        except Exception:
            return None

    def parent(n):
        return cat[n].get("parent") if n in cat else None

    def vocabulary(n):
        out, seen = set(labels[n]), {n}
        p = parent(n)
        while p in cat and p not in seen:
            seen.add(p)
            out |= labels[p]
            p = parent(p)
        if "porcelain" in out:
            out |= {"white", "mug"}
        if "cabinet" in out and cat[n]["kind"] == "region":
            if out & {"top", "middle", "bottom"} and "side" not in out:
                out.add("drawer")
        if "contain" in out:
            out.add("compartment")
        return out

    vocab = {n: vocabulary(n) for n in names}

    def resolve(text, role="item"):
        q = [w for w in words(text) if w not in filler]
        if not q:
            return None
        if set(q) <= {"it", "them", "there", "this", "that", "one"}:
            return last_item if role == "item" else last_target

        # Resolve reference objects separately from the object being selected.
        reference = None
        relation = None
        for phrase in ("next to", "near", "beside", "closest to",
                       "left of", "right of", "in front of", "behind"):
            marker = words(phrase)
            for i in range(len(q) - len(marker) + 1):
                if q[i:i + len(marker)] == marker:
                    reference = resolve(" ".join(q[i + len(marker):]), "any")
                    relation = phrase
                    q = q[:i]
                    break
            if relation:
                break

        wanted = set(q)
        content = wanted - structural - directions - {"it", "there"}
        # "Top of it" refers to a support belonging to the previous target.
        owner = None
        if "it" in wanted and last_target:
            owner = parent(last_target) or last_target
            content |= vocab.get(owner, set()) - structural - directions

        candidates = []
        for n in names:
            kind, v = cat[n]["kind"], vocab[n]
            if role == "item" and kind != "item":
                continue
            if "init" in labels[n]:
                continue
            if role == "any" and kind == "region":
                continue
            if owner and n != owner and parent(n) != owner:
                continue
            overlap = content & v
            if content and not overlap:
                continue
            if not content and not owner:
                continue
            score = 5 * len(overlap) - 7 * len(content - v)
            score += 2 * len(wanted & directions & v)
            if "drawer" in wanted:
                score += 9 if "drawer" in v else -12
            if "compartment" in wanted:
                score += 7 if "contain" in v else -6
            if role == "target":
                if wanted & {"in", "inside"}:
                    score += 5 if "contain" in v or "drawer" in v else 0
                if "on" in wanted:
                    score += 6 if "side" in v and "top" in v else 0
                    score += 4 if "cook" in v else 0
                score += int(kind == "region")
            p = position(n)
            if p is None:
                continue
            candidates.append([score, n, p])
        if not candidates:
            return None

        # Ground repeated objects using live coordinates and labelled scene anchors.
        for entry in candidates:
            score, n, p = entry
            for d in wanted & directions:
                anchors = [
                    position(a) for a in names
                    if d in labels[a] and content & labels[a] and a != n
                ]
                anchors = [a for a in anchors if a is not None]
                if anchors:
                    score += 3 * np.exp(-min(np.linalg.norm(p - a) for a in anchors) / .12)
            if reference:
                rp = position(reference)
                if rp is not None:
                    diff = p - rp
                    if relation in ("near", "beside", "next to", "closest to"):
                        score -= 6 * np.linalg.norm(diff)
                    else:
                        axis, sign = {
                            "left of": (0, -1), "right of": (0, 1),
                            "in front of": (1, -1), "behind": (1, 1),
                        }[relation]
                        score += 4 if sign * diff[axis] > .01 else -8
            entry[0] = score
        best = max(x[0] for x in candidates)
        pool = [x for x in candidates if x[0] >= best - .5]
        for d in q:
            if d in directions and len(pool) > 1:
                axis, sign = {
                    "left": (0, -1), "right": (0, 1),
                    "front": (1, -1), "back": (1, 1),
                    "top": (2, 1), "bottom": (2, -1), "middle": (2, 0),
                }[d]
                center = np.median([x[2][axis] for x in pool])
                pool.sort(key=lambda x: sign * x[2][axis] if sign
                          else -abs(x[2][axis] - center), reverse=True)
                return pool[0][1]
        winner = max(candidates, key=lambda x: x[0])
        return winner[1] if winner[0] > 0 else None

    def act(step):
        nonlocal stopped
        if stopped or api.remaining() <= 0:
            return {}
        for key in ("item", "target"):
            if key in step and position(step[key]) is None:
                return {}
        before = api.remaining()
        receipt = api.act(step) or {}
        # Refresh observations after every physical action.
        for key in ("item", "target"):
            if key in step:
                position(step[key])
        if api.remaining() <= 0 or (not receipt.get("executed") and
                                    api.remaining() == before):
            stopped = True
        return receipt

    def split_items(text):
        tokens = words(text)
        for i, w in enumerate(tokens):
            if w == "and":
                left, right = " ".join(tokens[:i]), " ".join(tokens[i + 1:])
                a, b = resolve(left), resolve(right)
                if a and b and a != b:
                    return split_items(left) + split_items(right)
        n = resolve(text)
        return [n] if n else []

    def place(item, target):
        nonlocal last_item, last_target
        if not item or not target or item == target:
            return
        is_drawer = "drawer" in vocab[target]
        if is_drawer and drawer_state.get(target) != "open":
            r = act({"op": "open", "target": target})
            if r.get("executed"):
                drawer_state[target] = "open"
        v = vocab[item]
        grasps = (["thin_edge", "standard", "rim"] if "book" in v else
                  ["rim", "standard", "thin_edge"] if v & {"bowl", "plate"} else
                  ["standard", "rim", "thin_edge"])
        r = act({"op": "place", "item": item, "target": target,
                 "grasps": grasps})
        last_item, last_target = item, target
        # The skill tries the ordered grasps; retry only a lifted but incomplete move.
        gap, lift = r.get("xy_gap"), r.get("max_lift")
        if (r.get("executed") and gap is not None and lift is not None
                and gap > .10 and lift > .025 and api.remaining() > 80):
            act({"op": "place", "item": item, "target": target,
                 "grasps": grasps})

    tokens = words(api.instruction)
    verbs = {"put", "place", "move", "set", "insert", "open", "close",
             "turn", "switch", "push", "pull", "slide", "pick"}
    starts = [i for i, w in enumerate(tokens) if w in verbs]
    for k, start in enumerate(starts):
        if stopped or api.remaining() <= 0:
            break
        end = starts[k + 1] if k + 1 < len(starts) else len(tokens)
        verb, body = tokens[start], tokens[start + 1:end]
        while body and body[-1] in {"and", "then"}:
            body.pop()
        text = " ".join(body)
        if verb == "pick":
            last_item = resolve(text.replace("up ", "", 1)) or last_item
        elif verb in {"open", "close"}:
            target = resolve(text, "target")
            if target and "drawer" in vocab[target]:
                r = act({"op": verb, "target": target})
                if r.get("executed"):
                    drawer_state[target] = verb
                last_target = target
        elif verb in {"put", "place", "move", "set", "insert"}:
            # Prefer a complete source/destination parse over a bare preposition.
            choices = []
            for i, w in enumerate(body):
                if w in {"in", "inside", "on", "to"}:
                    items = split_items(" ".join(body[:i]))
                    target = resolve(" ".join(body[i:]), "target")
                    if items and target and target not in items:
                        choices.append((items, target))
            if choices:
                items, target = choices[-1]
                for item in dict.fromkeys(items):
                    place(item, target)
        elif verb in {"turn", "switch", "push", "pull", "slide"}:
            target = resolve(" ".join(w for w in body
                                     if w not in {"on", "off", "toward", "away"}),
                             "any")
            if not target:
                continue
            controls = [n for n in names if parent(n) == target
                        and vocab[n] & {"switch", "button", "knob"}]
            if controls:
                target = min(controls, key=lambda n: (
                    np.linalg.norm(position(n) - position(target))
                    if position(n) is not None else float("inf")))
            delta = np.array([0., -.08, 0.])
            if "right" in body:
                delta = np.array([.08, 0., 0.])
            elif "left" in body:
                delta = np.array([-.08, 0., 0.])
            elif "back" in body or verb == "pull":
                delta = -delta
            if "off" in body:
                delta = -delta
            act({"op": "stroke", "target": target,
                 "offset": [0., 0., .015], "delta": delta.tolist()})
            last_target = target
