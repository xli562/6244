def run(api):
    import numpy as np

    catalog = api.catalog()
    names = list(catalog)

    def words(text):
        return "".join(c if c.isalpha() else " " for c in text.lower()).split()

    tokens = {n: set(words(n)) for n in names}
    stop = set(words("a an the both all please carefully gently up down into onto "
                     "in on at to of from with and it them this that"))
    spatial = set(words("left right front back rear top bottom upper lower middle center"))
    aliases = {
        "rear": "back", "upper": "top", "lower": "bottom", "center": "middle",
        "cup": "mug", "saucepan": "pot", "espresso": "moka",
        "compartment": "contain", "inside": "contain", "interior": "contain",
        "shelf": "region", "drawer": "region", "surface": "side",
    }
    colors = set(words("black white yellow red blue green orange brown pink purple"))
    nouns = set(words("bowl mug cup plate pot pan frypan book bottle box basket "
                     "cabinet caddy stove rack cheese soup sauce butter milk pudding "
                     "ketchup juice drawer compartment shelf"))
    last_item = None
    last_target = None
    pending = None

    def position(n):
        try:
            p = np.asarray(api.pos(n), dtype=float)
            return p if p.shape == (3,) and np.all(np.isfinite(p)) else None
        except Exception:
            return None

    def distance(a, b):
        pa, pb = position(a), position(b)
        return float(np.linalg.norm(pa - pb)) if pa is not None and pb is not None else float("inf")

    def owner(n):
        return catalog[n].get("parent") if n in catalog else None

    def meaningful(text):
        return [w for w in words(text) if w not in stop]

    def match(text, kinds, parent=None):
        raw = meaningful(text)
        candidates = [
            n for n in names
            if catalog[n]["kind"] in kinds and (parent is None or owner(n) == parent)
        ]
        # Prefer literal vocabulary; use scene-supported synonyms where necessary.
        mapped = []
        for w in raw:
            if w in spatial:
                continue
            if any(w in tokens[n] for n in candidates):
                mapped.append(w)
            elif aliases.get(w):
                mapped.append(aliases[w])
            elif w == "white" and any("porcelain" in tokens[n] for n in candidates):
                mapped.append("porcelain")
        mapped = set(mapped)
        if not mapped:
            return None

        scored = []
        for n in candidates:
            hit = mapped & tokens[n]
            if not hit:
                continue
            # A color alone must never nominate an unrelated object.
            substantive = mapped - colors - {"region", "contain", "side"}
            if substantive and not (hit & substantive):
                continue
            missing = mapped - tokens[n]
            extra_colors = (tokens[n] & colors) - mapped
            score = 5 * len(hit) - 6 * len(missing) - 2 * len(extra_colors)
            scored.append((score, n, hit))
        if not scored:
            return None
        scored.sort(key=lambda v: (-v[0], v[1]))
        _, chosen, terms = scored[0]
        if mapped - tokens[chosen]:
            return None
        return chosen, sorted(terms)

    def ground(text, role="item", relation=None):
        nonlocal last_item, last_target
        raw = words(text)
        if not raw:
            return None
        if all(w in stop for w in raw):
            ref = last_item if role == "item" else last_target
            if not ref:
                return None
            return ref[0], dict(ref[1])

        parent = None
        source_anchor = None
        base = text
        if role == "item":
            for marker in (" from ", " on ", " in ", " near ", " beside "):
                if marker in " " + text + " ":
                    base, location = text.split(marker.strip(), 1)
                    loc = ground(location.strip(), "target")
                    if loc:
                        source_anchor = loc[0]
                    else:
                        return None
                    break

        # Explicit ownership is independent of the nominated child.
        if role != "item" and " of " in text:
            base, parent_text = text.split(" of ", 1)
            if words(parent_text) in (["it"], ["that"]):
                if last_target:
                    parent = owner(last_target[0]) or last_target[0]
            else:
                found = match(parent_text, {"fixture", "item"})
                parent = found[0] if found else None
            if parent is None:
                return None

        directions = [aliases.get(w, w) for w in words(base) if w in spatial]
        kinds = {"item"} if role == "item" else {"region", "fixture", "item"}
        found = match(base, kinds, parent)
        if found is None and parent is not None:
            children = [n for n in names if owner(n) == parent and catalog[n]["kind"] == "region"]
            desired = set(directions)
            children = [n for n in children if desired <= tokens[n]]
            if children:
                found = children[0], sorted(desired)
        if found is None:
            return None
        chosen, terms = found

        # Resolve a container to its requested usable region.
        if role != "item":
            container = parent or chosen
            children = [n for n in names
                        if owner(n) == container and catalog[n]["kind"] == "region"
                        and "init" not in tokens[n]]
            if children:
                requested = set(directions)
                region_words = set()
                if "drawer" in raw:
                    region_words.add("region")
                elif relation in ("in", "into", "inside") or "compartment" in raw:
                    region_words.add("contain")
                elif relation in ("on", "onto") or "top" in raw:
                    if any("side" in tokens[n] for n in children):
                        region_words.add("side")
                    elif any("cook" in tokens[n] for n in children):
                        region_words.add("cook")
                    else:
                        region_words.add("top")
                eligible = [n for n in children if requested | region_words <= tokens[n]]
                if eligible:
                    chosen = eligible[0]
                    terms = sorted(requested | region_words)
                    parent = container
                elif requested or region_words:
                    return None

        selector = {"kind": catalog[chosen]["kind"], "terms": terms}
        if parent is not None:
            selector["parent"] = parent
        if source_anchor:
            selector["near"] = source_anchor

        candidates = [n for n in names
                      if catalog[n]["kind"] == selector["kind"]
                      and set(terms) <= tokens[n]
                      and (parent is None or owner(n) == parent)]

        for direction in directions:
            if direction in tokens[chosen] and selector["kind"] == "region":
                if direction not in selector["terms"]:
                    selector["terms"] = selector["terms"] + [direction]
                candidates = [n for n in candidates if direction in tokens[n]]
                continue
            if source_anchor:
                continue
            variants = {direction, "rear" if direction == "back" else direction}
            anchors = [n for n in names
                       if catalog[n]["kind"] == "region"
                       and tokens[n] & variants
                       and (set(terms) - colors - {"region", "contain", "side"}) & tokens[n]]
            if anchors:
                anchors.sort(key=lambda n: (-len(set(terms) & tokens[n]), n))
                best = len(set(terms) & tokens[anchors[0]])
                anchors = [n for n in anchors if len(set(terms) & tokens[n]) == best]
                if len(anchors) != 1:
                    return None
                selector["near"] = anchors[0]
            else:
                axis, rank = {
                    "left": ("x", "min"), "right": ("x", "max"),
                    "front": ("y", "min"), "back": ("y", "max"),
                    "bottom": ("z", "min"), "top": ("z", "max"),
                    "middle": ("x", "median"),
                }[direction]
                selector.update(axis=axis, rank=rank)

        if not candidates:
            return None
        if "near" in selector:
            candidates.sort(key=lambda n: distance(n, selector["near"]))
        elif "axis" in selector:
            axis = "xyz".index(selector["axis"])
            if any(position(n) is None for n in candidates):
                return None
            candidates.sort(key=lambda n: float(position(n)[axis]))
            if selector["rank"] == "max":
                candidates.reverse()
            elif selector["rank"] == "median":
                candidates = [candidates[len(candidates) // 2]] + candidates
        chosen = candidates[0]
        return chosen, selector

    def execute(step):
        if api.remaining() <= 0:
            return None
        for role in step["expect"]:
            if position(step[role]) is None:
                return None
        evidence = api.preview(step)
        if evidence is not None:
            for role in step["expect"]:
                entry = evidence.get(role, {})
                if entry.get("status") not in ("confirmed", "corrected"):
                    return None
                resolved = entry.get("resolved")
                pick = resolved if isinstance(resolved, str) else entry.get("pick")
                if isinstance(pick, str) and pick in catalog:
                    step[role] = pick
        if api.remaining() <= 0:
            return None
        for role in step["expect"]:
            if position(step[role]) is None:
                return None
        return api.act(step)

    def objects(text):
        whole = ground(text)
        if whole:
            return [whole]
        chunks = text.replace(" both ", " ").split(" and ")
        if len(chunks) < 2:
            return []
        result = [ground(chunk) for chunk in chunks]
        return result if all(result) else []

    instruction = api.instruction.lower()
    for mark in ",.;":
        instruction = instruction.replace(mark, " then ")
    verbs = {"put", "place", "move", "transfer", "set", "pick", "take",
             "open", "close", "shut", "turn", "switch", "push", "slide"}
    ws = instruction.split()
    clauses, current = [], []
    i = 0
    while i < len(ws):
        w = ws[i]
        split = w == "then" or (
            w == "and" and i + 1 < len(ws) and ws[i + 1] in verbs
        )
        if split:
            if current:
                clauses.append(" ".join(current))
                current = []
        else:
            current.append(w)
        i += 1
    if current:
        clauses.append(" ".join(current))

    for clause in clauses:
        if api.remaining() <= 0:
            break
        ws = clause.split()
        if ws and ws[0] == "please":
            ws = ws[1:]
        if not ws:
            continue
        verb, rest = ws[0], " ".join(ws[1:])
        if verb in ("pick", "take"):
            pending = rest.removeprefix("up ").strip()
            refs = objects(pending)
            if len(refs) == 1:
                last_item = refs[0]
            continue

        if verb in ("open", "close", "shut"):
            ref = ground(rest, "target")
            if not ref or ref[1]["kind"] != "region":
                return
            step = {"op": "open" if verb == "open" else "close",
                    "target": ref[0], "expect": {"target": ref[1]}}
            receipt = execute(step)
            if not receipt or not receipt.get("executed"):
                return
            last_target = (step["target"], ref[1])
            continue

        if verb in ("turn", "switch", "push", "slide"):
            state = "off" if "off" in ws else "on"
            description = " ".join(w for w in rest.split() if w not in ("on", "off"))
            ref = ground(description, "target")
            if not ref:
                return
            # Prefer an explicitly named control when the scene exposes one.
            controls = [n for n in names if owner(n) == ref[0]
                        and tokens[n] & {"switch", "button", "knob"}]
            if len(controls) == 1:
                n = controls[0]
                ref = n, {"kind": catalog[n]["kind"],
                          "terms": sorted(tokens[n] & {"switch", "button", "knob"}),
                          "parent": owner(n)}
            direction = np.array([0.0, -0.08 if state == "on" else 0.08, 0.0])
            for word, vector in (
                ("left", [-0.08, 0, 0]), ("right", [0.08, 0, 0]),
                ("forward", [0, -0.08, 0]), ("backward", [0, 0.08, 0])
            ):
                if word in ws:
                    direction = np.array(vector, dtype=float)
            step = {"op": "stroke", "target": ref[0],
                    "offset": [0.0, 0.0, 0.02], "delta": direction.tolist(),
                    "expect": {"target": ref[1]}}
            receipt = execute(step)
            if not receipt or not receipt.get("executed"):
                return
            last_target = ref
            continue

        if verb not in ("put", "place", "move", "transfer", "set"):
            return
        parts = rest.split()
        boundaries = [i for i, w in enumerate(parts)
                      if w in ("in", "into", "on", "onto", "to", "inside")]
        if not boundaries:
            return
        # "from ... to ..." keeps the source description attached to the item.
        boundary = next((i for i in boundaries if parts[i] == "to"), boundaries[0])
        source = " ".join(parts[:boundary])
        destination = " ".join(parts[boundary + 1:])
        relation = parts[boundary]
        if source in ("it", "them") and pending:
            source = pending
        refs = objects(source)
        target = ground(destination, "target", relation)
        if not refs or not target:
            return
        for ref in refs:
            if ref[0] == target[0]:
                return
            ts = tokens[ref[0]]
            grasps = (["thin_edge", "standard", "rim"] if "book" in ts else
                      ["rim", "standard", "thin_edge"] if ts & {"bowl", "mug", "pot"}
                      else ["standard", "rim", "thin_edge"])
            step = {"op": "place", "item": ref[0], "target": target[0],
                    "grasps": grasps, "expect": {"item": ref[1], "target": target[1]}}
            receipt = execute(step)
            if not receipt or not receipt.get("executed"):
                return
            gap = receipt.get("xy_gap")
            # Only open a destination drawer after observed placement failure.
            drawer = (target[1]["kind"] == "region"
                      and ("drawer" in words(destination)
                           or "drawer" in tokens[target[0]]))
            if drawer and gap is not None and gap > 0.06:
                opened = execute({"op": "open", "target": step["target"],
                                  "expect": {"target": target[1]}})
                if not opened or not opened.get("executed"):
                    return
                receipt = execute(step)
                if not receipt or not receipt.get("executed"):
                    return
            last_item = (step["item"], ref[1])
            last_target = (step["target"], target[1])
        pending = None
