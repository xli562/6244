def run(api):
    import numpy as np

    cat = api.catalog()
    names = list(cat)
    history = {"item": None, "target": None, "drawer": None}
    opened = set()
    receipts = []
    aliases = {
        "porcelain": "white", "akita": "", "chefmate": "",
        "contain": "inside", "compartment": "inside", "container": "inside",
        "shut": "close", "upper": "top", "lower": "bottom",
        "centre": "middle", "center": "middle", "rear": "back",
        "nearest": "near", "closest": "near", "furthest": "far",
        "farthest": "far", "crimson": "red", "grey": "gray",
    }
    noise = set("a an the both all of please object objects one ones "
                "region init side up down onto into to on in at "
                "and then it them this that its".split())
    spatial = set("left right front back top bottom middle near far".split())
    colors = set("black white yellow red blue green orange gray brown".split())

    def words(s):
        s = str(s).lower()
        for c in "_-,.;:!?()/":
            s = s.replace(c, " ")
        return [aliases.get(w, w) for w in s.split()
                if not w.isdigit() and aliases.get(w, w)]

    def terms(s):
        return set(words(s)) - noise

    def pos(n):
        try:
            p = np.asarray(api.pos(n), dtype=float)
            return p if p.shape == (3,) and np.isfinite(p).all() else None
        except Exception:
            return None

    def snapshot():
        return {n: p for n in names if (p := pos(n)) is not None}

    def family(n):
        result, seen = [], set()
        while n in cat and n not in seen:
            seen.add(n)
            result.append(n)
            n = cat[n].get("parent")
        return result

    def tokens(n):
        return terms(" ".join(family(n)))

    def is_region(n):
        return cat[n].get("kind") == "region"

    def is_init(n):
        return "init" in n.lower().split("_")

    def drawer(n):
        t = tokens(n)
        return (is_region(n) and not is_init(n)
                and ("drawer" in t or
                     ("cabinet" in t and bool(t & {"top", "middle", "bottom"})
                      and "side" not in n.lower().split("_"))))

    def resolve(phrase, role="item", reference=None):
        q = terms(phrase)
        raw = words(phrase)
        if not q:
            if any(w in raw for w in ("it", "them", "this", "that")):
                return reference or history.get(role) or history["target"]
            return None
        P = snapshot()
        if role == "drawer":
            pool = [n for n in P if drawer(n)]
        elif role == "item":
            pool = [n for n in P if cat[n].get("kind") == "item"]
        else:
            pool = [n for n in P if not is_init(n)]
        core = q - spatial - {"inside", "drawer", "surface"}
        if not core and reference in cat:
            core = tokens(reference) - spatial - {"inside", "drawer", "surface"}
        scores = {}
        for n in pool:
            t = tokens(n)
            overlap = core & t
            if core and not overlap:
                continue
            if not core and role != "drawer" and reference is None:
                continue
            score = 7 * len(overlap) - 5 * len(core - t)
            score -= 5 * len((t & colors) - q) if q & colors else 0
            score += 2 * len(q & t & spatial)
            if role == "target":
                own = terms(n)
                inside = "inside" in q or any(w in raw for w in ("in", "into"))
                above = "top" in q or any(w in raw for w in ("on", "onto"))
                score += 5 if inside and "inside" in own else 0
                score += 5 if inside and drawer(n) else 0
                score += 6 if above and "top_side" in n else 0
                score += 4 if "stove" in t and "cook" in own else 0
                score -= 5 if above and drawer(n) else 0
                score -= 3 if not inside and "inside" in own else 0
            scores[n] = float(score)
        if not scores:
            return None

        # Named spatial markers establish the scene's own left/front conventions.
        for d in q & spatial:
            anchors = [n for n in P if d in terms(n)
                       and (not core or bool(core & tokens(n)))]
            if anchors:
                for n in scores:
                    dist = min(np.linalg.norm(P[n] - P[a]) for a in anchors)
                    scores[n] += 7 * np.exp(-dist / .12)
            elif len(scores) > 1:
                axis, sign = {
                    "left": (0, -1), "right": (0, 1),
                    "front": (1, -1), "back": (1, 1),
                    "top": (2, 1), "bottom": (2, -1),
                    "near": (1, -1), "far": (1, 1),
                    "middle": (2, 0),
                }[d]
                values = np.array([P[n][axis] for n in scores])
                lo, hi = values.min(), values.max()
                if hi - lo > .015:
                    for n in scores:
                        u = (P[n][axis] - lo) / (hi - lo)
                        scores[n] += 4 * (1 - abs(2*u - 1) if sign == 0
                                          else u if sign > 0 else 1-u)
        best = max(scores, key=scores.get)
        return best if scores[best] > 0 or not core else None

    def resolve_item(phrase):
        # Relational descriptions use live distances to a grounded landmark.
        for marker in (" to the left of ", " to the right of ",
                       " in front of ", " behind ", " next to ",
                       " near ", " closest to ", " farthest from "):
            if marker not in phrase:
                continue
            subject, landmark = phrase.split(marker, 1)
            ref = resolve(landmark, "target")
            P = snapshot()
            if ref not in P:
                return None
            q = terms(subject) - spatial
            candidates = [n for n in P
                          if cat[n].get("kind") == "item" and n != ref
                          and q and q <= tokens(n)]
            if not candidates:
                return None
            if "left" in marker or "right" in marker:
                sign = -1 if "left" in marker else 1
                candidates = [n for n in candidates
                              if sign * (P[n][0] - P[ref][0]) > .01]
            elif "front" in marker or "behind" in marker:
                sign = -1 if "front" in marker else 1
                candidates = [n for n in candidates
                              if sign * (P[n][1] - P[ref][1]) > .01]
            if not candidates:
                return None
            return sorted(candidates,
                          key=lambda n: np.linalg.norm(P[n] - P[ref]),
                          reverse="farthest" in marker)[0]
        return resolve(phrase, "item", history["item"])

    def act(step):
        # Refresh observations and budget immediately before every physical step.
        required = [step[k] for k in ("item", "target") if k in step]
        if api.remaining() <= 0 or any(pos(n) is None for n in required):
            return None
        receipt = api.act(step)
        receipts.append(receipt)
        for n in required:
            pos(n)
        api.remaining()
        return receipt if isinstance(receipt, dict) else {}

    def operate_drawer(n, op):
        if n is None:
            return
        r = act({"op": op, "target": n})
        if r is not None and r.get("executed"):
            if op == "open":
                opened.add(n)
            else:
                opened.discard(n)
        history["drawer"] = n
        history["target"] = n

    def needs_open(n):
        if n in opened:
            return False
        P = snapshot()
        siblings = [s for s in P if s != n and drawer(s)
                    and cat[s].get("parent") == cat[n].get("parent")]
        if siblings and n in P:
            closed_xy = np.median([P[s][:2] for s in siblings], axis=0)
            if np.linalg.norm(P[n][:2] - closed_xy) > .12:
                return False
        return True

    def place(item, target):
        if item is None or target is None or item == target:
            return
        if drawer(target) and needs_open(target):
            operate_drawer(target, "open")
        t = tokens(item)
        grasps = (["thin_edge", "standard", "rim"] if t & {"book", "plate"}
                  else ["rim", "standard", "thin_edge"] if t & {"bowl", "mug", "cup"}
                  else ["standard", "rim", "thin_edge"])
        for grasp in grasps:
            r = act({"op": "place", "item": item, "target": target,
                     "grasps": [grasp]})
            if r is None or not r.get("executed"):
                break
            lift = r.get("max_lift")
            gap = r.get("xy_gap")
            if gap is not None and gap < .045:
                break
            # Only a measured failure to lift licenses a new grasp attempt.
            if lift is None or lift > .015:
                break
        history["item"], history["target"] = item, target

    def sources(text):
        text = text.strip()
        for prefix in ("both ", "all "):
            if text.startswith(prefix):
                text = text[len(prefix):]
        chunks = text.split(" and ")
        result, pending = [], []
        for chunk in chunks:
            n = resolve_item(chunk)
            if n is None:
                pending.append(chunk)
                continue
            # "yellow and white mug" is one object; "red and blue bowls" may be two.
            if pending:
                combined = resolve_item(" and ".join(pending + [chunk]))
                if combined is not None:
                    n = combined
                pending = []
            if n not in result:
                result.append(n)
        return result

    text = api.instruction.lower().replace(";", " then ").replace(".", " then ")
    for old, new in (("onto ", "on "), ("into ", "in "),
                     ("shut ", "close "), ("switch ", "turn ")):
        text = text.replace(old, new)
    verbs = set("put place set move transfer bring insert stack pick "
                "open close turn push pull slide press toggle".split())
    tokens_ = text.split()
    clauses, current = [], []
    i = 0
    while i < len(tokens_):
        w = tokens_[i].strip(",")
        boundary = w == "then" or (
            w == "and" and i + 1 < len(tokens_)
            and tokens_[i + 1] in verbs)
        if boundary:
            if current:
                clauses.append(" ".join(current))
            current = []
        else:
            current.append(w)
        i += 1
    if current:
        clauses.append(" ".join(current))

    for clause in clauses:
        if api.remaining() <= 0:
            break
        parts = clause.split()
        while parts and parts[0] in ("please", "and"):
            parts.pop(0)
        if not parts:
            continue
        verb, body = parts[0], " ".join(parts[1:])
        if verb == "pick":
            history["item"] = resolve_item(body.removeprefix("up "))
            continue
        if verb in ("open", "close"):
            n = resolve(body, "drawer", history["drawer"])
            operate_drawer(n, verb)
            continue
        if verb in ("put", "place", "set", "move", "transfer", "bring", "insert", "stack"):
            # The destination preposition is usually the final one, except in
            # descriptions such as "on the plate next to the bowl".
            cuts = []
            for marker in (" on ", " in ", " to ", " inside "):
                start = 0
                while True:
                    j = body.find(marker, start)
                    if j < 0:
                        break
                    if body[j:].startswith((" in front of ", " to the left of ",
                                            " to the right of ")):
                        start = j + len(marker)
                        continue
                    cuts.append((j, marker))
                    start = j + len(marker)
            choice = None
            for j, marker in sorted(cuts):
                src = body[:j].split(" from ", 1)[0]
                dst = marker.strip() + " " + body[j + len(marker):]
                items = sources(src)
                reference = history["target"]
                if "top of it" in dst and reference in cat:
                    parent = cat[reference].get("parent")
                    reference = parent or reference
                target = resolve(dst, "target", reference)
                if items and target is not None:
                    choice = items, target
                    break
            if choice:
                for item in choice[0]:
                    place(item, choice[1])
            continue
        if verb in ("turn", "toggle", "press", "push", "pull", "slide"):
            control = body
            for w in ("on", "off", "forward", "backward", "left", "right"):
                control = " ".join(x for x in control.split() if x != w)
            target = resolve(control, "target", history["target"])
            if target is None:
                continue
            q = set(body.split())
            delta = np.array([0., 0., -.06])
            offset = np.array([0., 0., .03])
            if verb in ("push", "pull", "slide"):
                delta = np.array([0., .10 if verb == "push" else -.10, 0.])
                if q & {"left", "right"}:
                    delta = np.array([-.10 if "left" in q else .10, 0., 0.])
                offset = -delta * .5 + np.array([0., 0., .02])
            elif "stove" in tokens(target):
                controls = [n for n in names
                            if tokens(n) & {"knob", "switch", "button"}
                            and ("stove" in tokens(n) or target in family(n))]
                if controls:
                    target = min(controls, key=lambda n:
                                 np.linalg.norm(pos(n) - pos(target))
                                 if pos(n) is not None else float("inf"))
                else:
                    offset = np.array([0., -.10, .02])
                    delta = np.array([0., -.08 if "off" in q else .08, 0.])
            act({"op": "stroke", "target": target,
                 "offset": offset.tolist(), "delta": delta.tolist()})
            history["target"] = target
    return receipts
