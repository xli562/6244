def run(api):
    import numpy as np

    catalog = api.catalog()
    results = []
    memory = {"item": None, "target": None, "owner": None}

    def words(s):
        return "".join(c.lower() if c.isalpha() else " " for c in s).split()

    names = {n: set(words(n)) for n in catalog}
    vocabulary = set().union(*names.values()) if names else set()
    spatial = {
        "left": ("x", "min"), "right": ("x", "max"),
        "front": ("y", "min"), "back": ("y", "max"),
        "bottom": ("z", "min"), "top": ("z", "max"),
        "middle": ("z", "median"),
    }
    aliases = {
        "cup": ("mug", "cup"), "cups": ("mug", "cup"),
        "bowl": ("bowl",), "bowls": ("bowl",),
        "plate": ("plate",), "plates": ("plate",),
        "pan": ("frypan", "pan"), "skillet": ("frypan", "pan"),
        "pot": ("pot",), "stovetop": ("stove",),
        "cabinet": ("cabinet",), "cupboard": ("cabinet",),
        "caddy": ("caddy",), "organizer": ("caddy", "organizer"),
        "basket": ("basket",), "bin": ("bin", "basket"),
        "book": ("book",), "books": ("book",),
        "rear": ("back",), "upper": ("top",),
        "lower": ("bottom",), "center": ("middle", "center"),
        "centre": ("middle", "center"),
        "leftmost": ("left",), "rightmost": ("right",),
        "highest": ("top",), "lowest": ("bottom",),
        "white": ("white", "porcelain"),
    }
    ignored = set("""
        a an the both all each every of to into onto in on at from near
        beside next that which is are and then please object thing one
        box package container up down out away it them there its
    """.split())
    structural = {"drawer", "compartment", "shelf", "surface", "inside"}
    colors = set("black white yellow red blue green orange pink purple brown grey gray".split())

    def position(n):
        try:
            p = np.asarray(api.pos(n), dtype=float)
            return p if p.shape == (3,) and np.all(np.isfinite(p)) else None
        except Exception:
            return None

    def options(w):
        if w in aliases:
            return aliases[w]
        if w in vocabulary:
            return (w,)
        if w.endswith("s") and w[:-1] in vocabulary:
            return (w[:-1],)
        return (w,)

    def direction(ws):
        for w in ws:
            for v in options(w):
                if v in spatial:
                    return v
        return None

    def nominate(pool, selector):
        pool = [
            n for n in pool
            if catalog[n]["kind"] == selector["kind"]
            and set(selector["terms"]) <= names[n]
            and ("parent" not in selector
                 or catalog[n].get("parent") == selector["parent"])
        ]
        if not pool:
            return None
        if "near" in selector:
            a = position(selector["near"])
            measured = [(n, position(n)) for n in pool]
            measured = [(n, p) for n, p in measured if p is not None]
            if a is None or not measured:
                return None
            return min(measured, key=lambda q: np.linalg.norm(q[1] - a))[0]
        if "axis" in selector:
            axis = "xyz".index(selector["axis"])
            measured = [(n, position(n)) for n in pool]
            measured = [(n, p[axis]) for n, p in measured if p is not None]
            if not measured:
                return None
            measured.sort(key=lambda q: q[1])
            rank = selector["rank"]
            return measured[0 if rank == "min" else
                            -1 if rank == "max" else len(measured) // 2][0]
        return sorted(pool)[0]

    def resolve(text, kinds=("item", "fixture"), parent=None):
        ws = words(text)
        if not ws:
            return None
        d = direction(ws)
        concepts = [
            options(w) for w in ws
            if w not in ignored and w not in structural
            and not any(v in spatial for v in options(w))
        ]
        if not concepts:
            return None
        pool = [
            n for n, meta in catalog.items()
            if meta["kind"] in kinds
            and (parent is None or meta.get("parent") == parent)
            and all(set(group) & names[n] for group in concepts)
        ]
        if not pool:
            return None

        # Resolve vocabulary alternatives by descriptive specificity.
        requested_colors = set(ws) & colors
        def score(n):
            extra_colors = (names[n] & colors) - requested_colors
            return len(extra_colors), len(names[n]), n

        seed = min(pool, key=score)
        terms = sorted({
            next(v for v in group if v in names[seed]) for group in concepts
        })
        selector = {"kind": catalog[seed]["kind"], "terms": terms}
        if parent is not None:
            selector["parent"] = parent
        pool = [n for n in pool if catalog[n]["kind"] == selector["kind"]
                and set(terms) <= names[n]]

        if d:
            literal = [n for n in pool if d in names[n]]
            if literal:
                selector["terms"] = sorted(set(terms + [d]))
                pool = literal
            else:
                # Named scene locations outrank assumed world directions.
                anchors = [
                    n for n, meta in catalog.items()
                    if meta["kind"] == "region" and d in names[n]
                    and set(terms) <= names[n] and position(n) is not None
                ]
                if not anchors:
                    anchors = [
                        n for n, meta in catalog.items()
                        if meta["kind"] == "region" and d in names[n]
                        and {"mark", "marker", "anchor"} & names[n]
                        and position(n) is not None
                    ]
                if len(anchors) == 1:
                    selector["near"] = anchors[0]
                elif anchors:
                    return None
                else:
                    selector["axis"], selector["rank"] = spatial[d]
        pick = nominate(pool, selector)
        return (pick, selector) if pick else None

    def region(owner, text, relation):
        ws = words(text)
        d = direction(ws)
        children = [
            n for n, meta in catalog.items()
            if meta["kind"] == "region"
            and meta.get("parent") == owner
            and "init" not in names[n]
        ]
        if not children:
            return None
        terms = []
        if d:
            terms.append(d)
        if "drawer" in ws:
            children = [n for n in children if "side" not in names[n]]
        elif relation in ("in", "into", "inside") or "compartment" in ws:
            if any("contain" in names[n] for n in children):
                terms.append("contain")
            elif any("inner" in names[n] for n in children):
                terms.append("inner")
        elif relation in ("on", "onto", "atop"):
            for token in ("side", "cook", "surface", "top"):
                if any(token in names[n] for n in children):
                    terms.append(token)
                    break
        if not terms and len(children) != 1:
            return None
        if not terms:
            # Use a functional region word, never a serial or instance ID.
            terms = sorted(names[children[0]] & {
                "contain", "inner", "cook", "surface", "top", "region"
            })
        selector = {"kind": "region", "terms": terms, "parent": owner}
        pick = nominate(children, selector)
        return (pick, selector) if pick else None

    def destination(text, relation):
        ws = words(text)
        if not ws or set(ws) <= {"it", "there", "inside", "the", "of", "top", "on"}:
            if relation in ("on", "onto", "atop") and memory["owner"]:
                owner = memory["owner"]
                return region(owner[0], text, relation) or owner
            return memory["target"]
        owner_text = " ".join(w for w in ws if w not in structural
                              and not any(v in spatial for v in options(w)))
        owner = resolve(owner_text, ("fixture", "item"))
        if owner:
            wants_region = bool(set(ws) & structural) or relation in (
                "in", "into", "inside"
            )
            r = region(owner[0], text, relation)
            if r and (wants_region or catalog[owner[0]]["kind"] == "fixture"):
                memory["owner"] = owner
                return r
            direct = resolve(text, ("fixture", "item"))
            if direct:
                memory["owner"] = direct
                return direct
        return resolve(text, ("region",))

    def execute(op, roles, **extra):
        if any(value is None for value in roles.values()):
            results.append({"executed": False, "reason": "ungrounded role"})
            return None
        step = {"op": op, "expect": {}, **extra}
        for role, (pick, selector) in roles.items():
            if position(pick) is None:
                return None
            step[role] = pick
            step["expect"][role] = dict(selector)
        if api.remaining() <= 0:
            return None
        preview = api.preview(step)
        if preview is not None:
            for role in roles:
                evidence = preview.get(role, {})
                if evidence.get("status") not in ("confirmed", "corrected"):
                    results.append({"executed": False, "reason": "ambiguous role",
                                    "preview": preview})
                    return None
                pick = evidence.get("resolved") or evidence.get("pick")
                if isinstance(pick, str) and pick in catalog:
                    step[role] = pick
        # Refresh observations immediately before every physical action.
        if api.remaining() <= 0 or any(position(step[r]) is None for r in roles):
            return None
        receipt = api.act(step)
        results.append(receipt)
        if receipt and receipt.get("executed"):
            for role in roles:
                memory[role] = (step[role], step["expect"][role])
        return receipt

    verbs = {"put", "place", "move", "set", "insert", "pick", "take",
             "open", "close", "shut", "push", "pull", "slide", "turn", "switch"}
    tokens = words(api.instruction)
    starts = [i for i, w in enumerate(tokens) if w in verbs]
    clauses = []
    for j, start in enumerate(starts):
        end = starts[j + 1] if j + 1 < len(starts) else len(tokens)
        body = tokens[start + 1:end]
        while body and body[-1] in ("and", "then"):
            body.pop()
        clauses.append((tokens[start], body))

    def source(text):
        ws = words(text)
        if ws and set(ws) <= {"it", "them", "the", "one"}:
            return memory["item"]
        # Explicit source locations provide physical anchors.
        for i, w in enumerate(ws):
            if w in ("near", "beside", "from", "on", "at"):
                obj = resolve(" ".join(ws[:i]), ("item",))
                anchor = destination(" ".join(ws[i + 1:]), "at")
                if obj and anchor:
                    sel = dict(obj[1])
                    sel.pop("axis", None)
                    sel.pop("rank", None)
                    sel["near"] = anchor[0]
                    pick = nominate(list(catalog), sel)
                    return (pick, sel) if pick else None
                return None
        return resolve(text, ("item",))

    for verb, body in clauses:
        if api.remaining() <= 0:
            break
        text = " ".join(body)
        if verb in ("pick", "take"):
            memory["item"] = source(text)
            continue

        if verb in ("open", "close", "shut"):
            target = destination(text, "in")
            if target and target[1]["kind"] == "region":
                execute("open" if verb == "open" else "close", {"target": target})
            else:
                results.append({"executed": False, "reason": "drawer not grounded"})
            continue

        if verb in ("put", "place", "move", "set", "insert"):
            separators = [i for i, w in enumerate(body)
                          if w in ("in", "into", "on", "onto", "inside", "atop")]
            if not separators:
                results.append({"executed": False, "reason": "missing destination"})
                continue
            cut = separators[-1]
            relation = body[cut]
            src, dst = body[:cut], body[cut + 1:]
            # “on top of …” describes a support surface.
            if dst[:2] == ["top", "of"]:
                dst = dst[2:]
            target = destination(" ".join(dst), relation)
            groups, current = [], []
            for i, w in enumerate(src):
                if w == "and":
                    left = source(" ".join(current))
                    right = source(" ".join(src[i + 1:]))
                    if left and right:
                        groups.append(current)
                        current = []
                        continue
                current.append(w)
            groups.append(current)
            for group in groups:
                item = source(" ".join(group))
                if item and target:
                    item_words = names[item[0]]
                    grasps = (["thin_edge", "standard", "rim"]
                              if item_words & {"book", "card", "frame"}
                              else ["standard", "rim", "thin_edge"])
                    # The shared place skill handles ordered no-lift retries.
                    execute("place", {"item": item, "target": target}, grasps=grasps)
                else:
                    results.append({"executed": False, "reason": "ungrounded placement"})
            continue

        # Contact actions require an observable contact entity and direction.
        action_words = set(body)
        target_text = " ".join(w for w in body
                               if w not in {"on", "off", "toward", "towards"})
        target = resolve(target_text, ("item", "fixture", "region"))
        if not target:
            target = memory["target"] if action_words <= {"it"} else None
        d = direction(body)
        if verb in ("turn", "switch"):
            # A stove body does not establish its switch geometry.
            controls = [
                n for n in catalog
                if names[n] & {"switch", "button", "knob"}
                and target and (catalog[n].get("parent") == target[0])
            ]
            if len(controls) == 1 and d:
                n = controls[0]
                target = (n, {"kind": catalog[n]["kind"],
                              "terms": sorted(names[n] & {"switch", "button", "knob"}),
                              "parent": target[0]})
            else:
                results.append({"executed": False,
                                "reason": "control motion not established by scene"})
                continue
        if target and d:
            axis, rank = spatial[d]
            delta = np.zeros(3)
            delta["xyz".index(axis)] = -0.08 if rank == "min" else 0.08
            offset = -0.5 * delta
            execute("stroke", {"target": target},
                    offset=offset.tolist(), delta=delta.tolist())
        else:
            results.append({"executed": False, "reason": "contact direction ungrounded"})
    return results
