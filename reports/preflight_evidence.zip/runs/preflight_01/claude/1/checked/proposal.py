def run(api):
    raise ValueError("CLI program rejected: line 1: import of 're' is not allowed")
