def run(api):
    raise ValueError("CLI program rejected: line 8: use of 'getattr' is not allowed")
