def run(api):
    api.original()
    for _ in range(2):
        observed = api.last()
        if observed is None or observed["remaining"] <= 0:
            return
        if observed["max_lift"] <= 0:
            api.adjust("regrasp")
        elif observed["xy_gap"] > 0:
            api.adjust("align")
        else:
            return
