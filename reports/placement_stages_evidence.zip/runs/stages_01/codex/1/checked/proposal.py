# Conservative control-step reserves for recovery and completion.
ACQUIRE_STEPS = 120
ALIGN_STEPS = 50
FINISH_STEPS = 30
POSE_TOLERANCE = 0.02
LIFT_THRESHOLD = 0.02

adjustments = []


def choose(strategy, remaining, previous):
    used = list(previous)
    for recorded in adjustments:
        if recorded not in used:
            used.append(recorded)

    if len(used) >= 2 or strategy in used:
        return None

    required = ACQUIRE_STEPS if strategy == "regrasp" else ALIGN_STEPS
    if remaining < required + FINISH_STEPS:
        return None

    adjustments.append(strategy)
    return strategy


def checkpoint(event):
    remaining = min(500, event["remaining"])
    previous = event["previous"]
    reason = event["reason"]

    if reason in ("empty_grasp", "slip", "missed_release"):
        return choose("regrasp", remaining, previous)

    if reason == "off_target" and event["held"]:
        if max(event["xy_gap"], event["drift"]) > POSE_TOLERANCE:
            return choose("align", remaining, previous)

    return None


def run(api):
    adjustments.clear()
    api.original()

    while len(adjustments) < 2:
        observation = api.last()
        if observation is None:
            return

        remaining = min(500, observation["remaining"])
        gap = observation["xy_gap"]
        lift = observation["max_lift"]

        if observation["op"] in ("empty_grasp", "slip", "missed_release"):
            strategy = "regrasp"
        elif gap <= POSE_TOLERANCE:
            return
        elif lift <= LIFT_THRESHOLD:
            strategy = "regrasp"
        else:
            strategy = "align"

        strategy = choose(strategy, remaining, adjustments)
        if strategy is None:
            return

        api.adjust(strategy)
