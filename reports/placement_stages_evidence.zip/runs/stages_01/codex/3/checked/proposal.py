adjustments = []

REGRASP_STEPS = 120
ALIGN_STEPS = 60
POSITION_TOLERANCE = 0.02
LIFT_TOLERANCE = 0.01


def checkpoint(event):
    previous = list(event.get("previous", []))
    if len(previous) >= 2:
        return None

    remaining = event.get("remaining", 0)
    reason = event.get("reason")
    held = event.get("held", False)

    strategy = None
    if reason == "empty_grasp" or (reason == "slip" and not held):
        strategy = "regrasp"
    elif held and (
        reason in ("off_target", "slip")
        or event.get("xy_gap", 0) > POSITION_TOLERANCE
        or event.get("drift", 0) > POSITION_TOLERANCE
    ):
        strategy = "align"
    elif reason == "missed_release" and event.get("phase") == "release":
        strategy = "regrasp"

    if strategy is None or strategy in previous or strategy in adjustments:
        return None
    if len(adjustments) >= 2:
        return None

    required = REGRASP_STEPS if strategy == "regrasp" else ALIGN_STEPS
    if remaining < required:
        return None

    adjustments.append(strategy)
    return strategy


def run(api):
    adjustments.clear()
    api.original()

    while len(adjustments) < 2:
        observation = api.last()
        if observation is None:
            return

        remaining = observation.get("remaining", 0)
        lift = observation.get("max_lift", 0)
        gap = observation.get("xy_gap", 0)
        operation = observation.get("op")

        if operation in ("empty_grasp", "slip", "missed_release"):
            strategy = "regrasp"
        elif lift <= LIFT_TOLERANCE and gap > POSITION_TOLERANCE:
            strategy = "regrasp"
        elif gap > POSITION_TOLERANCE:
            strategy = "align"
        else:
            return

        if strategy in adjustments:
            return

        required = REGRASP_STEPS if strategy == "regrasp" else ALIGN_STEPS
        if remaining < required:
            return

        adjustments.append(strategy)
        api.adjust(strategy)
