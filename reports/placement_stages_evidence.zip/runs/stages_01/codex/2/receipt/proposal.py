def run(api):
    api.original()
    for _ in range(2):
        observation = api.last()
        if observation is None or observation["remaining"] <= 0:
            return
        if observation["max_lift"] <= 0:
            api.adjust("regrasp")
        elif observation["xy_gap"] > 0:
            api.adjust("align")
        else:
            return
