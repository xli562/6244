adjustments = []

REGRASP_STEPS = 100
ALIGN_STEPS = 40
MIN_LIFT = 0.02
POSE_TOLERANCE = 0.02


def checkpoint(event):
    previous = event.get("previous", [])
    if max(len(previous), len(adjustments)) >= 2:
        return None

    remaining = min(500, event.get("remaining", 0))
    reason = event.get("reason")
    held = event.get("held", False)
    strategy = None

    if reason in ("empty_grasp", "slip"):
        if remaining >= REGRASP_STEPS:
            strategy = "regrasp"
    elif reason == "missed_release":
        if remaining >= REGRASP_STEPS:
            strategy = "regrasp"
    elif reason == "off_target" and held:
        if remaining >= ALIGN_STEPS:
            strategy = "align"

    if strategy is None:
        return None
    if strategy in previous or strategy in adjustments:
        return None

    adjustments.append(strategy)
    return strategy


def run(api):
    adjustments.clear()
    api.original()

    while len(adjustments) < 2:
        observation = api.last()
        if observation is None:
            return

        remaining = min(500, observation.get("remaining", 0))
        lift = observation.get("max_lift")
        gap = observation.get("xy_gap")
        strategy = None

        if lift is not None and lift < MIN_LIFT:
            if remaining >= REGRASP_STEPS:
                strategy = "regrasp"
        elif gap is not None and gap > POSE_TOLERANCE:
            if remaining >= ALIGN_STEPS:
                strategy = "align"

        if strategy is None or strategy in adjustments:
            return

        adjustments.append(strategy)
        api.adjust(strategy)
