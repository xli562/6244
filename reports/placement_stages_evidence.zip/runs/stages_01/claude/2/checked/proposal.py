"""Recovery policy for a simulated pick-and-place robot.

run(api) runs the frozen prior once. If the placement missed, it applies up
to two shared corrections. checkpoint(event) makes the same decision for
in-placement faults. Both entry points use one decision function, so
deployments that only report at placement return still behave identically.
"""

MAX_ADJUSTMENTS = 2        # shared per-episode cap
REGRASP_STEPS = 160        # control steps reserved for a fresh acquisition
ALIGN_STEPS = 60           # control steps reserved for a held realignment
LIFT_MIN = 0.02            # metres; below this the item was never acquired
GAP_TOL = 0.02             # metres; xy error considered on target
MIN_IMPROVEMENT = 0.005    # metres; a correction gaining less is futile


def as_number(value, default=0.0):
    if isinstance(value, bool):
        return float(value)
    if isinstance(value, (int, float)):
        return float(value)
    return default


def strategy_name(entry):
    if isinstance(entry, str):
        return entry
    if isinstance(entry, dict):
        return entry.get("strategy") or entry.get("name")
    return None


def history(previous):
    if not isinstance(previous, (list, tuple)):
        return []
    names = []
    for entry in previous:
        name = strategy_name(entry)
        if name in ("regrasp", "align"):
            names.append(name)
    return names


def decide(phase, reason, remaining, held, xy_gap, previous):
    """Return 'regrasp', 'align' or None for a measured fault."""
    used = history(previous)
    if len(used) >= MAX_ADJUSTMENTS:
        return None
    remaining = int(as_number(remaining, 0))

    if reason in ("empty_grasp", "slip"):
        wanted = "regrasp"
    elif reason == "missed_release":
        wanted = "regrasp"
    elif reason == "off_target":
        if held:
            wanted = "align"
        else:
            wanted = "regrasp"
    elif not held and phase in ("grasp", "carry"):
        wanted = "regrasp"
    else:
        return None

    if wanted == "align" and as_number(xy_gap, GAP_TOL + 1.0) <= GAP_TOL:
        return None

    # A strategy that already ran once for this episode and left a fault is
    # treated as futile; do not spend budget repeating it.
    if wanted in used:
        return None

    needed = REGRASP_STEPS if wanted == "regrasp" else ALIGN_STEPS
    if remaining < needed:
        return None
    return wanted


def checkpoint(event):
    if not isinstance(event, dict):
        return None
    return decide(
        event.get("phase"),
        event.get("reason"),
        event.get("remaining", 0),
        bool(event.get("held", False)),
        event.get("xy_gap"),
        event.get("previous", []),
    )


def diagnose(info):
    """Map an api.last() report to (phase, reason, held), or None if placed."""
    op = info.get("op")
    lift = as_number(info.get("max_lift"), 0.0)
    gap = as_number(info.get("xy_gap"), GAP_TOL + 1.0)

    if "held" in info:
        held = bool(info.get("held"))
    else:
        held = op != "release" and lift >= LIFT_MIN

    if lift < LIFT_MIN and not held:
        return "grasp", "empty_grasp", False
    if op == "release":
        if gap > GAP_TOL:
            return "release", "missed_release", held
        return None
    if not held:
        return "carry", "slip", False
    if gap > GAP_TOL:
        return op if op in ("grasp", "carry") else "carry", "off_target", True
    return None


def run(api):
    result = api.original()
    applied = []
    last_gap = None

    while len(applied) < MAX_ADJUSTMENTS:
        info = api.last()
        if not isinstance(info, dict):
            break

        gap = as_number(info.get("xy_gap"), GAP_TOL + 1.0)
        if last_gap is not None and applied and last_gap - gap < MIN_IMPROVEMENT:
            break  # previous correction did not help; stop spending budget
        last_gap = gap

        found = diagnose(info)
        if found is None:
            break
        phase, reason, held = found

        prior = list(info.get("previous", [])) if isinstance(info.get("previous"), (list, tuple)) else []
        for name in applied:
            if len(history(prior)) < len(applied):
                prior.append(name)

        choice = decide(phase, reason, info.get("remaining", 0), held,
                        info.get("xy_gap"), prior)
        if choice is None:
            break

        outcome = api.adjust(choice)
        applied.append(choice)
        if outcome is not None:
            result = outcome

    return result
