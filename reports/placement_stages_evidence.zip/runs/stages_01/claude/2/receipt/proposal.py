"""Recovery policy for a simulated pick-and-place robot.

run(api) executes the frozen prior once, then uses up to two shared
adjustments to recover a missed placement. Only the public api methods are
used: original(), last(), adjust(strategy). The policy issues no motor
commands of its own.
"""

MAX_ADJUSTMENTS = 2

# The item counts as acquired once it has been lifted above this height.
LIFT_THRESHOLD = 0.02

# Any horizontal error larger than this is worth an alignment pass.
GAP_THRESHOLD = 0.005

# Skip an adjustment if fewer control steps than this are left.
MIN_STEPS_FOR_ADJUST = 20


def as_number(value):
    """Return value as a float, or None if it is not numeric."""
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    return None


def choose_strategy(info):
    """Pick 'regrasp', 'align', or None from a miss report."""
    max_lift = as_number(info.get("max_lift"))
    xy_gap = as_number(info.get("xy_gap"))
    op = info.get("op")
    op_text = op.lower() if isinstance(op, str) else ""

    # The item was never properly acquired, so grasp it again
    # using the observed collision geometry.
    if max_lift is not None and max_lift < LIFT_THRESHOLD:
        return "regrasp"

    # The item was carried but landed off target, so correct
    # its live pose against the destination.
    if xy_gap is not None and xy_gap > GAP_THRESHOLD:
        return "align"

    # The measurements are missing or ambiguous. Fall back to
    # the reported phase of the failed operation.
    if any(word in op_text for word in ("grasp", "pick", "lift", "acquire")):
        return "regrasp"
    if any(word in op_text for word in ("place", "release", "put", "drop", "move")):
        return "align"

    # No usable signal. Prefer aligning when there is any gap at all.
    if xy_gap is not None and xy_gap > 0.0:
        return "align"
    return None


def run(api):
    result = api.original()

    for _ in range(MAX_ADJUSTMENTS):
        info = api.last()
        if info is None:
            # Nothing was missed, so stop here.
            break
        if not isinstance(info, dict):
            break

        remaining = as_number(info.get("remaining"))
        if remaining is not None and remaining < MIN_STEPS_FOR_ADJUST:
            # Too few control steps left for a useful correction.
            break

        strategy = choose_strategy(info)
        if strategy is None:
            break

        result = api.adjust(strategy)

    return result
