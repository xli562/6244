"""Recovery policy: run the frozen prior, then spend up to two shared
adjustments fixing a missed placement within the control-step budget."""

MAX_ADJUSTMENTS = 2
LIFT_THRESHOLD = 0.02    # below this, the item was never really acquired
GAP_TOLERANCE = 0.01     # xy offset considered "on target"
MIN_STEPS = 1            # do not request an adjustment with no budget left


def as_number(value, default=0.0):
    if isinstance(value, (int, float)):
        return float(value)
    return default


def choose_strategy(report):
    op = str(report.get("op") or "").lower()
    max_lift = as_number(report.get("max_lift"))
    xy_gap = as_number(report.get("xy_gap"))

    # The item never left the surface (or the grasp op itself failed):
    # use the observed collision geometry to acquire it again.
    if max_lift < LIFT_THRESHOLD or "grasp" in op or "pick" in op:
        return "regrasp"

    # The item was carried but landed off target: correct its live pose.
    if xy_gap > GAP_TOLERANCE:
        return "align"

    # Lifted and nominally close, yet still reported as missed:
    # a live pose correction is the cheaper, safer fix.
    return "align"


def run(api):
    api.original()

    used = 0
    while used < MAX_ADJUSTMENTS:
        report = api.last()
        if report is None:
            return  # placement succeeded; nothing to fix

        remaining = as_number(report.get("remaining"))
        if remaining < MIN_STEPS:
            return  # control-step budget exhausted

        api.adjust(choose_strategy(report))
        used += 1
