LIFT_MIN = 0.02
GAP_TOL = 0.015
REGRASP_STEPS = 160
ALIGN_STEPS = 60
MAX_ADJUST = 2

PHASES = ("grasp", "carry", "release")
REASONS = ("empty_grasp", "slip", "off_target", "missed_release")
STRATEGIES = ("regrasp", "align")


def number(value, default=0.0):
    if isinstance(value, bool):
        return float(value)
    if isinstance(value, (int, float)):
        return float(value)
    return default


def history(previous):
    names = []
    for item in previous or []:
        if isinstance(item, str):
            name = item
        elif isinstance(item, dict):
            name = item.get("strategy") or item.get("op")
        else:
            name = None
        if name in STRATEGIES:
            names.append(name)
    return names


def allowed(strategy, remaining, done):
    if len(done) >= MAX_ADJUST:
        return False
    if done and done[-1] == strategy:
        return False
    cost = REGRASP_STEPS if strategy == "regrasp" else ALIGN_STEPS
    return remaining >= cost


def checkpoint(event):
    if not isinstance(event, dict):
        return None
    phase = event.get("phase")
    reason = event.get("reason")
    remaining = int(number(event.get("remaining"), 0))
    held = bool(event.get("held"))
    gap = number(event.get("xy_gap"))
    done = history(event.get("previous"))

    if reason in ("empty_grasp", "slip") or (not held and phase in ("grasp", "carry")):
        choice = "regrasp"
    elif reason == "missed_release":
        choice = "regrasp"
    elif reason == "off_target":
        if gap <= GAP_TOL:
            return None
        choice = "align" if held else "regrasp"
    else:
        return None

    if allowed(choice, remaining, done):
        return choice
    return None


def describe(info, done):
    op = info.get("op")
    lift = number(info.get("max_lift"))
    gap = number(info.get("xy_gap"))
    remaining = int(number(info.get("remaining"), 0))
    lifted = lift >= LIFT_MIN

    if op in REASONS:
        reason = op
        phase = "release" if op == "missed_release" else ("carry" if op == "off_target" else "grasp")
        held = op == "off_target" and lifted
    elif not lifted:
        reason, phase, held = "empty_grasp", "grasp", False
    elif gap > GAP_TOL and op == "carry":
        reason, phase, held = "off_target", "carry", True
    elif gap > GAP_TOL:
        reason, phase, held = "missed_release", "release", False
    else:
        return None

    return {
        "phase": op if op in PHASES else phase,
        "reason": reason,
        "remaining": remaining,
        "held": held,
        "lift": lift,
        "xy_gap": gap,
        "drift": number(info.get("drift")),
        "previous": list(done),
    }


def run(api):
    result = api.original()
    done = []
    while len(done) < MAX_ADJUST:
        info = api.last()
        if not isinstance(info, dict):
            break
        event = describe(info, done)
        if event is None:
            break
        decision = checkpoint(event)
        if decision is None:
            break
        result = api.adjust(decision)
        done.append(decision)
    return result
