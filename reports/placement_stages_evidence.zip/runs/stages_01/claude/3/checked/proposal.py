LIFT_MIN = 0.01
XY_TOL = 0.01
DRIFT_TOL = 0.005
REGRASP_COST = 150
ALIGN_COST = 60
MAX_ADJUSTMENTS = 2
PHASES = ("grasp", "carry", "release")
REASONS = ("empty_grasp", "slip", "off_target", "missed_release")
HELD_OPS = ("grasp", "carry", "hold", "held")


def number(value, default=0.0):
    if isinstance(value, bool):
        return default
    if isinstance(value, (int, float)):
        return value
    return default


def strategy_names(previous):
    names = []
    for item in previous or []:
        if isinstance(item, str):
            names.append(item)
        elif isinstance(item, dict):
            names.append(item.get("strategy") or item.get("name") or item.get("op"))
        else:
            names.append(str(item))
    return names


def affordable(strategy, remaining):
    cost = REGRASP_COST if strategy == "regrasp" else ALIGN_COST
    return remaining >= cost


def choose(strategy, used, remaining):
    if strategy in used:
        return None
    if not affordable(strategy, remaining):
        return None
    return strategy


def checkpoint(event):
    if not isinstance(event, dict):
        return None
    used = strategy_names(event.get("previous"))
    if len(used) >= MAX_ADJUSTMENTS:
        return None
    reason = event.get("reason")
    held = bool(event.get("held"))
    remaining = int(number(event.get("remaining"), 0))
    xy_gap = number(event.get("xy_gap"), 0.0)
    drift = number(event.get("drift"), 0.0)

    if reason in ("empty_grasp", "missed_release"):
        return choose("regrasp", used, remaining)
    if reason == "slip":
        if held and (xy_gap > XY_TOL or drift > DRIFT_TOL):
            return choose("align", used, remaining)
        if held:
            return None
        return choose("regrasp", used, remaining)
    if reason == "off_target":
        if xy_gap <= XY_TOL and drift <= DRIFT_TOL:
            return None
        if held:
            return choose("align", used, remaining)
        return choose("regrasp", used, remaining)
    return None


def event_from_last(last, previous):
    op = last.get("op")
    max_lift = number(last.get("max_lift"), 0.0)
    xy_gap = number(last.get("xy_gap"), 0.0)
    remaining = int(number(last.get("remaining"), 0))
    held = last.get("held")
    if held is None:
        held = op in HELD_OPS and max_lift >= LIFT_MIN

    if op in REASONS:
        reason = op
    elif max_lift < LIFT_MIN:
        reason = "empty_grasp"
    elif xy_gap > XY_TOL:
        reason = "missed_release" if op == "release" and not held else "off_target"
    else:
        reason = None

    if op in PHASES:
        phase = op
    elif reason == "empty_grasp":
        phase = "grasp"
    elif held:
        phase = "carry"
    else:
        phase = "release"

    return {
        "phase": phase,
        "reason": reason,
        "remaining": remaining,
        "held": bool(held),
        "lift": max_lift,
        "xy_gap": xy_gap,
        "drift": number(last.get("drift"), 0.0),
        "previous": list(previous),
    }


def run(api):
    api.original()
    previous = []
    while len(previous) < MAX_ADJUSTMENTS:
        last = api.last()
        if not isinstance(last, dict):
            return
        event = event_from_last(last, previous)
        if event["reason"] is None:
            return
        strategy = checkpoint(event)
        if strategy is None:
            return
        api.adjust(strategy)
        previous.append(strategy)
