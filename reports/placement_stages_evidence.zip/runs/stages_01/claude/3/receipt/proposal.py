LIFT_THRESHOLD = 0.02
GAP_THRESHOLD = 0.01
MIN_STEPS_FOR_ADJUST = 20
MAX_ADJUSTMENTS = 2


def as_number(value, default):
    if isinstance(value, bool):
        return default
    if isinstance(value, (int, float)):
        return float(value)
    return default


def choose_strategy(report, tried):
    op = str(report.get("op") or "").lower()
    max_lift = as_number(report.get("max_lift"), 0.0)
    xy_gap = as_number(report.get("xy_gap"), 0.0)

    lifted = max_lift >= LIFT_THRESHOLD
    acquisition_failed = (not lifted) or ("grasp" in op) or ("pick" in op)

    if acquisition_failed:
        if tried.count("regrasp") >= 1 and lifted:
            return "align"
        return "regrasp"

    if xy_gap > GAP_THRESHOLD:
        return "align"

    if "place" in op or "release" in op or "align" in op:
        return "align"

    return "align"


def run(api):
    result = api.original()
    tried = []

    while len(tried) < MAX_ADJUSTMENTS:
        report = api.last()
        if report is None or not isinstance(report, dict):
            return result

        remaining = as_number(report.get("remaining"), 0.0)
        if remaining < MIN_STEPS_FOR_ADJUST:
            return result

        strategy = choose_strategy(report, tried)
        tried.append(strategy)
        result = api.adjust(strategy)

    return result
