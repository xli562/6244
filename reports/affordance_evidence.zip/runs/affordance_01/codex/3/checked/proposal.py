def run(api):
    return api.original()


def reread(instruction, step, role):
    text = instruction.lower()
    verbs = {
        "put ": "place", "place ": "place", "move ": "place",
        "set ": "place", "insert ": "place", "pick up ": "pick",
        "open ": "open", "close ": "close", "push ": "stroke",
        "slide ": "stroke", "turn on ": "stroke", "turn off ": "stroke",
    }
    starts = [(i, v) for i in range(len(text))
              if i == 0 or text[i - 1] in " ,;.\n"
              for v in verbs if text.startswith(v, i)]
    selector = step.get("expect", {}).get(role, {})
    terms = selector.get("terms", [])
    quotes = []
    held = ""
    for index, (start, verb) in enumerate(starts):
        end = starts[index + 1][0] if index + 1 < len(starts) else len(text)
        a, b = start + len(verb), end
        while b > a and text[b - 1] in " ,;.\n":
            b -= 1
        for tail in (" and then", " and", " then"):
            if text[a:b].endswith(tail):
                b -= len(tail)
        if verbs[verb] == "pick":
            held = instruction[a:b].strip()
            continue
        if verbs[verb] != step.get("op"):
            continue
        cuts = [(text.rfind(p, a, b), len(p))
                for p in (" into ", " onto ", " in ", " on ", " to ")]
        cut, width = max(cuts)
        if verbs[verb] == "place":
            if cut < a:
                continue
            a, b = (a, cut) if role == "item" else (cut + width, b)
        elif role != "target":
            continue
        quote = instruction[a:b].strip()
        if role == "item" and quote.lower() == "it":
            quote = held
        if not quote or quote.lower() in ("it", "them", "that"):
            continue
        tokens = quote.lower().replace("-", " ").split()
        score = sum(term in tokens for term in terms)
        if score or not terms:
            quotes.append((score, quote))
    best = max((score for score, quote in quotes), default=-1)
    winners = list(dict.fromkeys(q for s, q in quotes if s == best))
    return winners[0] if len(winners) == 1 else ""


def retry(api, feedback):
    catalog, instruction = api.catalog(), api.instruction
    blocked = feedback.get("step") or {}
    evidence = feedback.get("evidence") or {}
    verbs = {"put": "place", "place": "place", "move": "place", "set": "place",
             "insert": "place", "open": "open", "close": "close",
             "push": "stroke", "slide": "stroke", "activate": "stroke",
             "deactivate": "stroke"}
    text = instruction.lower().replace("turn on", "activate").replace("turn off", "deactivate")
    for mark in ",;.":
        text = text.replace(mark, " ")
    operations = [verbs[w] for w in text.split() if w in verbs]
    operations = [blocked["op"]] if blocked.get("op") else operations
    cursors, previous = {}, {"item": "", "target": ""}
    for op in operations:
        if api.remaining() <= 0:
            return
        roles = ("item", "target") if op == "place" else ("target",)
        step = dict(blocked) if blocked else {"op": op}
        step["expect"] = dict(step.get("expect", {}))
        valid = True
        for role in roles:
            report = evidence.get(role, {}) if blocked else {}
            resolved = report.get("resolved")
            if resolved in catalog and report.get("status") in ("confirmed", "corrected"):
                step[role] = resolved
            if (blocked and role in step and role in step["expect"]
                    and report.get("status") in ("confirmed", "corrected")):
                continue
            phrases = api.phrases(op, role)
            quote = reread(instruction, step, role) if blocked else ""
            key = (op, role)
            index = cursors.get(key, 0)
            chosen = [quote] if quote else (phrases if blocked else phrases[index:index + 1])
            cursors[key] = index + 1
            matches = []
            compatible = api.options(op, role)
            for phrase in chosen:
                original = phrase
                for pronoun in ("it", "them", "that"):
                    if pronoun in phrase.lower().split() and previous[role]:
                        phrase = " ".join(previous[role] if w.lower() == pronoun else w
                                          for w in phrase.split())
                for match in api.suggest(op, role, phrase):
                    name = match["name"]
                    if name in compatible and op + "." + role in api.supports(name):
                        entry = (name, match["selector"], original)
                        if entry not in matches:
                            matches.append(entry)
            if len(matches) != 1:
                valid = False
                break
            step[role], step["expect"][role], phrase = matches[0]
            if not any(w in phrase.lower().split() for w in ("it", "them", "that")):
                previous[role] = phrase
        if not valid:
            return
        if op == "place":
            step.setdefault("grasps", ["standard", "rim", "thin_edge"])
        if op == "stroke" and ("offset" not in step or "delta" not in step):
            return
        for role in roles:
            api.pos(step[role])
        if api.remaining() <= 0 or not api.act(step).get("executed", False):
            return
