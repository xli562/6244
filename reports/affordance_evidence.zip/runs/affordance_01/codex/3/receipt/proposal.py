def run(api):
    import numpy as np
    cat, last, held, opened = api.catalog(), None, [], {}
    def norm(s):
        s = s.lower()
        for a, b in [('pick up', 'pick'), ('on top of', 'on top'), ('inside', 'in'),
                     ('into', 'in'), ('onto', 'on'), ('compartment', 'region'),
                     ('drawer', 'region'), ('porcelain', 'white'), ('frypan', 'pan')]:
            s = s.replace(a, b)
        for c in '_,.;:!?':
            s = s.replace(c, ' ')
        return ' '.join(s.split())
    dirs = {'left': (0, -1), 'right': (0, 1), 'front': (1, -1),
            'back': (1, 1), 'bottom': (2, -1), 'top': (2, 1)}
    stop = 'the a an both all of it them there and box in on to region side contain init then'.split()
    def words(s):
        return [w for w in norm(s).split() if w not in stop and w not in dirs and not w.isdigit()]
    def positions():
        return {n: np.asarray(api.pos(n), dtype=float) for n in cat}
    def resolve(text, target=False, surface=False):
        text = norm(text)
        if text in ('it', 'them', 'there'):
            return last if target else (held[0] if held else None)
        if 'it' in text.split() and last:
            base = cat[last]['parent'] or last
            text = text.replace('it', norm(base))
        if not words(text):
            return None
        reference, relation = None, None
        for rel in ('nearest to', 'closest to', 'next to', 'left of', 'right of', 'in front of', 'behind', 'near'):
            if ' ' + rel + ' ' in text:
                text, tail = text.split(' ' + rel + ' ', 1)
                reference, relation = resolve(tail, True), rel
                break
        p, w, scored = positions(), words(text), []
        for n, info in cat.items():
            label, parent = norm(n).split(), info['parent']
            if (not target and info['kind'] != 'item') or n == reference or 'init' in label:
                continue
            tokens = words(n) + (words(parent) if parent else [])
            overlap = sum(x in tokens for x in w)
            if not overlap:
                continue
            score = 8 * overlap - 7 * sum(x not in tokens for x in w)
            score -= .4 * sum(x not in w for x in words(n))
            if target:
                score += 2 * (info['kind'] == 'region')
                score += 3 * ('contain' in label and not surface)
                score += 7 * ('side' in label and surface) - 5 * ('contain' in label and surface)
            for d, (axis, sign) in dirs.items():
                if d in text.split():
                    score += 6 * (d in label) + sign * float(p[n][axis]) / (1 + abs(float(p[n][axis])))
                    anchors = [r for r in cat if d in norm(r).split() and 'init' in norm(r).split()
                               and all(x in words(r) for x in words(n))]
                    if anchors:
                        score += 4 / (1 + 30 * min(float(np.linalg.norm(p[n] - p[r])) for r in anchors))
            if reference:
                delta = p[n] - p[reference]
                score -= 3 * float(np.linalg.norm(delta))
                axis, sign = {'left of': (0, -1), 'right of': (0, 1), 'behind': (1, 1),
                              'in front of': (1, -1)}.get(relation, (0, 0))
                score -= 20 * (sign != 0 and sign * delta[axis] <= 0)
            scored.append((score, n))
        return max(scored)[1] if scored else None
    def act(step):
        positions()
        return api.act(step) if api.remaining() > 0 else {}
    text = norm(api.instruction)
    for a in 'white black red yellow blue green'.split():
        for b in 'white black red yellow blue green'.split():
            text = text.replace(a + ' and ' + b, a + ' ' + b)
    verbs = 'put place move set pick open close turn switch push slide'.split()
    for v in verbs:
        text = (' ' + text).replace(' ' + v + ' ', ' |' + v + ' ').strip()
    for clause in text.split('|'):
        parts = clause.split()
        if not parts or parts[0] not in verbs or api.remaining() <= 0:
            continue
        v, body = parts[0], parts[1:]
        while body and body[-1] in ('and', 'then'):
            body.pop()
        body = ' '.join(body)
        if v in ('open', 'close', 'turn', 'switch', 'push', 'slide'):
            target = resolve(' '.join(w for w in body.split() if w not in ('on', 'off')), True)
            if target:
                step = {'op': v, 'target': target} if v in ('open', 'close') else {
                    'op': 'stroke', 'target': target, 'offset': [0, 0, 0],
                    'delta': [0, -.08 if 'off' in body.split() else .08, 0]}
                receipt, last = act(step), target
                if v in ('open', 'close') and receipt.get('executed'):
                    opened[target] = v == 'open'
            continue
        source, dest, prep = body, None, ''
        for token in (' in ', ' on ', ' to '):
            if token in body:
                source, dest = body.rsplit(token, 1)
                prep = token.strip()
                break
        held = held[:] if source in ('it', 'them') else [n for n in [resolve(s) for s in source.split(' and ')] if n]
        target = resolve(dest, True, prep == 'on') if dest else None
        if not target or not held:
            continue
        if prep == 'in' and 'cabinet' in norm(cat[target]['parent'] or '') and not opened.get(target):
            opened[target] = bool(act({'op': 'open', 'target': target}).get('executed'))
        for item in held:
            if item == target or api.remaining() <= 0:
                continue
            grasps = ['thin_edge', 'standard', 'rim'] if 'book' in norm(item) else ['standard', 'rim', 'thin_edge']
            receipt = act({'op': 'place', 'item': item, 'target': target, 'grasps': grasps})
            positions()
            if not receipt.get('executed') or api.remaining() <= 0:
                break
        last = target
