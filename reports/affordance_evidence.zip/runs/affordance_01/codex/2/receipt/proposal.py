import numpy as np

def run(api):
    cat = api.catalog()
    aliases = dict(cup="mug", porcelain="white", cupboard="cabinet",
                   compartment="contain", inside="in", onto="on", into="in")
    directions = "left right front back top bottom middle".split()
    colors = "black white yellow red blue green orange brown".split()
    ignored = "the a an both all of it them and to up in on drawer region init side".split()
    def words(s):
        for c in "_,.;:!?-":
            s = s.lower().replace(c, " ")
        return [aliases.get(w, w) for w in s.split() if not w.isdigit()]
    def pos(n):
        return np.asarray(api.pos(n), dtype=float)
    def resolve(s, source=False, previous=None):
        ts = words(s)
        if not [w for w in ts if w not in ignored]:
            return previous if "it" in ts or "them" in ts else None
        anchor = relation = None
        for phrase in ("next to", "near", "left of", "right of", "in front of", "behind"):
            if " " + phrase + " " in " " + s + " ":
                head, tail = s.split(phrase, 1)
                anchor = resolve(tail, True) or resolve(tail)
                if anchor:
                    ts, relation = words(head), phrase
                break
        q = [w for w in ts if w not in ignored]
        core = [w for w in q if w not in directions]
        candidates = []
        for n, m in cat.items():
            if (source and m["kind"] != "item") or "init_region" in n:
                continue
            nt = words(n)
            if not any(w in nt for w in core):
                continue
            region = m["kind"] == "region"
            score = sum(5 if w in nt else -3 for w in core)
            score -= 6 * sum(w in nt and w not in q for w in colors)
            score += 4 * sum(w in nt and w in q for w in directions)
            if not source:
                score += 3 * (region and ("contain" in nt if "in" in ts else "side" in nt))
                score += 4 * (region and "cook" in nt and "stove" in q)
                if "drawer" in ts:
                    score += 8 if region and "side" not in nt else -12
                elif "top" in q:
                    score += 6 * ("side" in nt)
            if anchor:
                d = pos(n) - pos(anchor)
                axis = 0 if relation in ("left of", "right of") else 1
                sign = -1 if relation in ("left of", "in front of") else 1
                score -= float(np.linalg.norm(d))
                if relation not in ("near", "next to"):
                    score += 8 if sign * d[axis] > 0 else -8
            candidates.append((score, n))
        if not candidates:
            return None
        best = max(x[0] for x in candidates)
        pool = [n for score, n in candidates if score >= best - 0.5]
        for direction in directions:
            if direction not in q or len(pool) < 2:
                continue
            anchors = [n for n in cat if cat[n]["kind"] == "region"
                       and direction in words(n) and any(w in words(n) for w in core)]
            if anchors:
                return min(pool, key=lambda n: min(float(np.linalg.norm(pos(n)-pos(a))) for a in anchors))
            axis = 0 if direction in ("left", "right") else 1 if direction in ("front", "back") else 2
            values = [pos(n)[axis] for n in pool]
            goal = np.median(values) if direction == "middle" else (max(values) if direction in ("right", "back", "top") else min(values))
            return min(pool, key=lambda n: abs(pos(n)[axis] - goal))
        return max(candidates)[1]
    def act(step):
        if api.remaining() <= 0:
            return {}
        for k in ("item", "target"):
            if k in step:
                pos(step[k])
        receipt = api.act(step)
        for k in ("item", "target"):
            if k in step:
                pos(step[k])
        api.remaining()
        return receipt
    text = api.instruction.lower().replace("pick up", "pick").replace("on top of", "on top")
    verbs = "pick put place move transfer insert set stack open close turn switch push slide press".split()
    clauses = []
    for token in text.replace(",", " ").replace(".", " ").replace("then", " ").split():
        if token in verbs:
            clauses.append([token, []])
        elif clauses:
            clauses[-1][1].append(token)
    item = target = None
    opened = {}
    for verb, ts in clauses:
        while ts and ts[-1] == "and":
            ts.pop()
        phrase = " ".join(ts)
        if verb == "pick":
            item = resolve(phrase, True, item)
        elif verb in ("open", "close"):
            n = resolve(phrase if "it" in ts else phrase + " drawer", previous=target)
            if n and cat[n]["kind"] == "region":
                r = act(dict(op=verb, target=n))
                if r.get("executed"):
                    opened[n] = verb == "open"
                target = n
        elif verb in ("turn", "switch", "push", "slide", "press"):
            n = resolve(" ".join(w for w in ts if w not in ("on", "off")), previous=target)
            if n:
                delta = [0, 0, -0.05] if verb == "press" else [-0.10 if "off" in ts or "left" in ts else 0.10, 0, 0]
                act(dict(op="stroke", target=n, offset=[0, -0.10, 0.02], delta=delta))
                target = n
        else:
            cuts = [i for i, w in enumerate(ts) if w in ("in", "into", "inside", "on", "onto", "to")]
            if not cuts:
                continue
            i = cuts[0]
            dst = resolve(" ".join(ts[i:]), previous=target)
            if not dst:
                continue
            src = " ".join(ts[:i]).replace("both ", "")
            parts = [resolve(p, True, item) for p in src.split(" and ")]
            sources = parts if all(parts) else [resolve(src, True, item)]
            for n in dict.fromkeys(sources):
                if not n or n == dst:
                    continue
                grasps = ["thin_edge", "standard", "rim"] if "book" in words(n) else ["standard", "rim", "thin_edge"]
                for grasp in grasps:
                    r = act(dict(op="place", item=n, target=dst, grasps=[grasp]))
                    if not r.get("executed"):
                        break
                    lift, gap = r.get("max_lift"), r.get("xy_gap")
                    drawer = "drawer" in ts[i:] and cat[dst]["kind"] == "region"
                    if drawer and not opened.get(dst) and gap is not None and gap > 0.08:
                        o = act(dict(op="open", target=dst))
                        opened[dst] = bool(o.get("executed"))
                        if opened[dst]:
                            r = act(dict(op="place", item=n, target=dst, grasps=[grasp]))
                            lift = r.get("max_lift")
                    if lift is None or lift > 0.01:
                        break
                item = n
            target = dst
