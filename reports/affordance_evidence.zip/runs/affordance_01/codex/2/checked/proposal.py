def run(api):
    return api.original()


def reread(instruction, step, role):
    verbs = ("pick up", "turn on", "turn off", "put", "place", "move",
             "open", "close", "push")
    lower = instruction.lower()
    starts = [i for i in range(len(lower))
              if (i == 0 or lower[i - 1] in " \n;,.")
              and any(lower.startswith(v + " ", i) for v in verbs)]
    terms = step.get("expect", {}).get(role, {}).get("terms", [])
    quotes = []
    for j, start in enumerate(starts):
        end = starts[j + 1] if j + 1 < len(starts) else len(instruction)
        chunk = instruction[start:end].strip(" \n,;.")
        for tail in (" and then", " and", " then"):
            if chunk.lower().endswith(tail):
                chunk = chunk[:-len(tail)].rstrip()
        verb = next(v for v in verbs if chunk.lower().startswith(v + " "))
        body = chunk[len(verb):].strip()
        op = ("place" if verb in ("put", "place", "move", "pick up")
              else "stroke" if verb in ("turn on", "turn off", "push") else verb)
        if op != step.get("op"):
            continue
        cuts = [(body.lower().find(s), s) for s in
                (" on top of ", " into ", " inside ", " onto ", " in ", " on ")
                if s in body.lower()]
        if op == "place":
            if not cuts:
                candidates = [body] if verb == "pick up" and role == "item" else []
            else:
                i, sep = min(cuts)
                candidates = [body[:i]] if role == "item" else [body[i + len(sep):]]
                if role == "item":
                    # Only split a conjunction when both sides name an item.
                    source = candidates[0]
                    pieces = source.split(" and ")
                    nouns = ("bowl", "mug", "cup", "book", "plate", "bottle",
                             "box", "soup", "cheese", "sauce", "butter", "pot")
                    if len(pieces) > 1 and all(any(n in p.lower().split()
                                                 for n in nouns) for p in pieces):
                        candidates = pieces
        else:
            candidates = [body] if role == "target" else []
        for candidate in candidates:
            quote = candidate.strip()
            if quote.lower().startswith("both "):
                quote = quote[5:]
            ws = quote.lower().replace("-", " ").split()
            score = sum(t in ws for t in terms)
            if quote and quote.lower() not in ("it", "them") and score:
                quotes.append((score, quote))
    if not quotes:
        return ""
    best = max(score for score, quote in quotes)
    winners = list(dict.fromkeys(q for s, q in quotes if s == best))
    return winners[0] if len(winners) == 1 else ""


def retry(api, feedback):
    def choose(op, role, phrases):
        matches = {}
        options = api.options(op, role)
        for phrase in phrases:
            for result in api.suggest(op, role, phrase):
                name = result["name"]
                if name in options and op + "." + role in api.supports(name):
                    matches[name] = result
        return next(iter(matches.values())) if len(matches) == 1 else None

    def submit(step):
        for role in step["expect"]:
            api.pos(step[role])
        if api.remaining() <= 0:
            return False
        evidence = api.preview(step)
        if evidence is not None:
            if any(v["status"] == "unresolved" for v in evidence.values()):
                return False
            for role, check in evidence.items():
                if check.get("resolved") in api.options(step["op"], role):
                    step[role] = check["resolved"]
        if api.remaining() <= 0:
            return False
        receipt = api.act(step)
        for role in step["expect"]:
            api.pos(step[role])
        api.remaining()
        return bool(receipt["executed"])

    blocked = feedback.get("step", {})
    if blocked:
        step = dict(blocked)
        step["expect"] = dict(blocked.get("expect", {}))
        roles = ("item", "target") if step["op"] == "place" else ("target",)
        for role in roles:
            check = feedback.get("evidence", {}).get(role, {})
            if check.get("status") == "confirmed" and role in step["expect"]:
                continue
            quote = reread(api.instruction, step, role)
            match = choose(step["op"], role, [quote] if quote else api.phrases(step["op"], role))
            if not match:
                return
            step[role], step["expect"][role] = match["name"], match["selector"]
        submit(step)
        return
    text = api.instruction.lower().replace(";", " and ").replace(".", " and ")
    verbs = {"put": "place", "place": "place", "move": "place", "pick up": "place",
             "open": "open", "close": "close", "turn on": "stroke", "turn off": "stroke", "push": "stroke"}
    for verb in verbs:
        for join in (" and then ", " and ", " then "):
            text = text.replace(join + verb + " ", "|" + verb + " ")
    for clause in text.split("|"):
        verb = next((v for v in verbs if clause.strip().startswith(v + " ")), "")
        if not verb:
            return
        op = verbs[verb]
        step = {"op": op, "expect": {}}
        for role in (("item", "target") if op == "place" else ("target",)):
            phrases = api.phrases(op, role)
            scoped = [p for p in phrases if p.lower() in clause]
            match = choose(op, role, scoped or phrases)
            if not match:
                return
            step[role], step["expect"][role] = match["name"], match["selector"]
        if op == "place":
            step["grasps"] = ["standard", "rim", "thin_edge"]
        elif op == "stroke":
            step.update(offset=[0, 0, .02], delta=[0, -.08 if verb == "turn off" else .08, 0])
        if not submit(step):
            return
