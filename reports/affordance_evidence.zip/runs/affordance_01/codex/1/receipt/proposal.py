import numpy as np

def run(api):
    cat = api.catalog()
    spatial = "left right front back top bottom middle nearest farthest".split()
    colors = "black white red yellow blue green".split()
    stop = "the a an both and of to up please box object".split()
    def words(s):
        for a, b in [("_", " "), ("-", " "), (",", " "), (".", " "), ("cup", "mug"),
                     ("compartment", "region"), ("drawer", "region"), ("inside", "in")]:
            s = s.lower().replace(a, b)
        return [w for w in s.split() if not w.isdigit() and w not in stop]
    def pos(n):
        return np.asarray(api.pos(n), dtype=float)
    def resolve(s, destination=False, previous=None):
        q = words(s)
        if not q:
            return None
        if any(w in q for w in ["it", "them", "there"]):
            if previous is None:
                return None
            if not destination or not any(w in q for w in ["in", "on"]):
                return previous
            parent = cat[previous]["parent"]
            s = s.replace("it", parent if parent in cat else previous)
            s = s.replace("there", parent if parent in cat else previous)
            q = words(s)
        reference, relation = None, ""
        for marker in [" left of ", " right of ", " in front of ", " behind ", " nearest ", " near ", " next to "]:
            if marker in " " + s:
                base, ref = (" " + s).split(marker, 1)
                reference, relation, q = resolve(ref, True), marker.strip(), words(base)
                break
        identity = [w for w in q if w not in spatial + ["in", "on", "region", "from"]]
        candidates = []
        for n, m in cat.items():
            if "init_region" in n or (not destination and m["kind"] != "item"):
                continue
            t = words(n); parent = m["parent"]
            if parent in cat:
                t += words(parent)
            if "porcelain" in t:
                t += ["white", "mug"]
            if identity and not any(w in t for w in identity):
                continue
            if not identity and not any(w in t for w in q):
                continue
            p = pos(n); labels = []
            if m["kind"] == "item":
                anchors = [(float(np.linalg.norm(p - pos(a))), a) for a, v in cat.items()
                           if v["kind"] == "region" and "init" in words(a)]
                if anchors and min(anchors)[0] < .15:
                    labels = [w for w in words(min(anchors)[1]) if w in spatial]
            score = 7 * sum(w in t for w in identity) - 9 * sum(w not in t for w in identity)
            score += 4 * sum(w in t + labels for w in q if w in spatial)
            score -= 3 * sum(w in t and w not in q for w in colors)
            if destination:
                score += 2 * (m["kind"] == "region") + 6 * ("region" in q and m["kind"] == "region")
                score += 6 * ("on" in q and "top_side" in n) + 4 * ("in" in q and "contain" in t)
                score -= 5 * ("on" in q and "contain" in t)
            if reference:
                d = p - pos(reference); score -= float(np.linalg.norm(d))
                if relation in ["left of", "right of", "in front of", "behind"]:
                    axis = 0 if relation in ["left of", "right of"] else 1
                    score += 8 if d[axis] * (-1 if relation in ["left of", "in front of"] else 1) > 0 else -12
            for w, axis, sign in [("left", 0, -1), ("right", 0, 1), ("front", 1, -1), ("back", 1, 1), ("top", 2, 1), ("bottom", 2, -1)]:
                if w in q and w not in t + labels:
                    score += sign * float(p[axis])
            candidates.append((score, n))
        return max(candidates)[1] if candidates else None
    def act(step):
        for key in ["item", "target"]:
            if key in step:
                pos(step[key])
        if api.remaining() <= 0:
            return {}
        receipt = api.act(step)
        for key in ["item", "target"]:
            if key in step:
                pos(step[key])
        api.remaining()
        return receipt or {}
    text = " " + api.instruction.lower()
    for a, b in [("pick up", "pick"), ("place ", "put "), ("set ", "put "), ("onto ", "on "), ("into ", "in "), ("inside ", "in "), ("then", "and"), (";", " and "), ("turn on", "activate"), ("switch on", "activate"), ("turn off", "deactivate"), ("switch off", "deactivate")]:
        text = text.replace(a, b)
    for v in ["pick", "put", "open", "close", "activate", "deactivate", "push"]:
        text = text.replace(" " + v + " ", "|" + v + " ")
    held, last, opened = None, None, {}
    for clause in text.split("|"):
        parts = clause.strip(" ,.;").split()
        if not parts or api.remaining() <= 0:
            continue
        verb, body = parts[0], " ".join(parts[1:]).removesuffix(" and")
        if verb == "pick":
            held = resolve(body, previous=held)
        elif verb == "put":
            index, prep = max((body.rfind(" " + p + " "), p) for p in ["in", "on"])
            if index < 0:
                continue
            source, dest = body[:index], body[index + len(prep) + 2:]
            target = resolve(prep + " " + dest, True, last)
            fragments = source.replace("both ", "").split(" and ")
            separate = [resolve(s, previous=held) for s in fragments]
            items = separate if all(separate) and len(set(separate)) == len(separate) else [resolve(source, previous=held)]
            if target is None or not any(items):
                continue
            if "drawer" in dest and prep == "in" and not opened.get(target):
                opened[target] = bool(act({"op": "open", "target": target}).get("executed"))
            for item in dict.fromkeys(items):
                if item and item != target:
                    grasps = ["thin_edge", "standard", "rim"] if "book" in words(item) else ["standard", "rim", "thin_edge"]
                    act({"op": "place", "item": item, "target": target, "grasps": grasps})
                    held = item
            last = target
        elif verb in ["open", "close", "activate", "deactivate", "push"]:
            target = resolve(body, True, last)
            if target is None:
                continue
            if verb in ["open", "close"]:
                if act({"op": verb, "target": target}).get("executed"):
                    opened[target] = verb == "open"
            else:
                delta = [0, .08 if verb == "activate" else -.08, 0]
                if verb == "push":
                    delta = [-.10 if "left" in body else .10, 0, 0]
                    if "forward" in body or "back" in body:
                        delta = [0, .10 if "back" in body else -.10, 0]
                act({"op": "stroke", "target": target, "offset": [0, 0, 0], "delta": delta})
            last = target
