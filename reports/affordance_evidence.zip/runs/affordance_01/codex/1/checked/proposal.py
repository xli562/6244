def run(api):
    return api.original()


def clauses(text):
    verbs = {'put', 'place', 'move', 'transfer', 'insert', 'pick',
             'open', 'close', 'turn', 'push', 'slide'}
    words, spans, cursor = text.split(), [], 0
    for word in words:
        start = text.find(word, cursor)
        spans.append((start, start + len(word)))
        cursor = start + len(word)
    starts = [i for i, w in enumerate(words) if w.lower().strip('.,;') in verbs]
    for j, i in enumerate(starts):
        end = spans[starts[j + 1]][0] if j + 1 < len(starts) else len(text)
        body = text[spans[i][1]:end].strip(' ,.;')
        while body.lower().endswith((' and', ' then')):
            body = body.rsplit(' ', 1)[0].rstrip(' ,;')
        yield words[i].lower().strip('.,;'), body


def roles(body):
    matches = []
    for prep in (' on top of ', ' into ', ' inside ', ' onto ', ' in ', ' on ', ' to '):
        at = body.lower().rfind(prep)
        if at >= 0:
            matches.append((at, len(prep)))
    if not matches:
        return body, ''
    at, size = max(matches)
    return body[:at].strip(), body[at:at + size].lstrip() + body[at + size:]


def reread(instruction, step, role):
    quotes, op = [], step.get('op')
    for verb, body in clauses(instruction):
        compatible = (verb in ('put', 'place', 'move', 'transfer', 'insert')
                      if op == 'place' else verb in ('turn', 'push', 'slide')
                      if op == 'stroke' else verb == op)
        if not compatible:
            continue
        source, target = roles(body) if op == 'place' else ('', body)
        quote = source if role == 'item' else target
        if quote and not any(w in quote.lower().split() for w in ('it', 'them', 'this', 'that')):
            quotes.append(quote)
    quotes = list(dict.fromkeys(quotes))
    if len(quotes) == 1:
        return quotes[0]
    terms = step.get('expect', {}).get(role, {}).get('terms', [])
    scores = [(sum(t in q.lower().replace('-', ' ').split() for t in terms), q)
              for q in quotes]
    scores.sort(reverse=True)
    return scores[0][1] if scores and scores[0][0] > 0 and (
        len(scores) == 1 or scores[0][0] > scores[1][0]) else ''


def retry(api, feedback):
    blocked, jobs = feedback.get('step') or {}, []
    if blocked:
        jobs.append((dict(blocked), {}))
    else:
        previous_source, previous_target = '', ''
        for verb, body in clauses(api.instruction):
            if verb == 'pick':
                previous_source = body[3:] if body.lower().startswith('up ') else body
                continue
            op = 'place' if verb in ('put', 'place', 'move', 'transfer', 'insert') else (
                verb if verb in ('open', 'close') else 'stroke')
            source, target = roles(body) if op == 'place' else ('', body)
            if source.lower() in ('it', 'them'):
                source = previous_source
            target = ' '.join(previous_target if w.lower() == 'it' else w for w in target.split())
            if not target or (op == 'place' and not source):
                return
            pieces = [source]
            if op == 'place' and not api.suggest(op, 'item', source):
                pieces = source.replace('both ', '').split(' and ')
            for piece in pieces:
                jobs.append(({'op': op}, {'item': piece, 'target': target}))
            previous_source, previous_target = source or previous_source, target
    for step, phrases in jobs:
        op = step.get('op')
        if op not in ('place', 'open', 'close', 'stroke'):
            return
        step['expect'] = dict(step.get('expect', {}))
        for role in (('item', 'target') if op == 'place' else ('target',)):
            check = feedback.get('evidence', {}).get(role, {}) if blocked else {}
            if check.get('status') in ('confirmed', 'corrected') and role in step['expect']:
                step[role] = check.get('resolved') or check.get('pick') or step.get(role)
                continue
            phrase = phrases.get(role) or reread(api.instruction, step, role)
            scoped = api.phrases(op, role)
            if not phrase and len(scoped) == 1:
                phrase = scoped[0]
            if not phrase:
                return
            options, matches = api.options(op, role), []
            for candidate in api.suggest(op, role, phrase):
                name = candidate['name']
                if name in options and op + '.' + role in api.supports(name):
                    if candidate not in matches:
                        matches.append(candidate)
            if len(matches) != 1:
                return
            step[role], step['expect'][role] = matches[0]['name'], matches[0]['selector']
        if op == 'place':
            step.setdefault('grasps', ['standard', 'rim', 'thin_edge'])
        if op == 'stroke' and ('offset' not in step or 'delta' not in step):
            return
        if api.remaining() <= 0:
            return
        for role in step['expect']:
            api.pos(step[role])
        evidence = api.preview(step)
        if evidence is not None and any(v.get('status') == 'unresolved' for v in evidence.values()):
            return
        if api.remaining() <= 0:
            return
        receipt = api.act(step)
        for role in step['expect']:
            api.pos(step[role])
        if not receipt.get('executed') or api.remaining() <= 0:
            return
