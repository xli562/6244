VB = {'put', 'place', 'pick', 'close', 'open', 'turn', 'switch', 'move', 'set', 'take', 'grab', 'lift', 'shut', 'stack', 'drop'}
HOLD = {'pick', 'take', 'grab', 'lift'}
PREPS = [' on top of ', ' into ', ' inside ', ' onto ', ' in ', ' on ']
PRON = {'it', 'them', 'that', 'there'}
STOP = {'the', 'a', 'an', 'of', 'both', 'up', 'and', 'to', 'it', 'its', 'in', 'into', 'on', 'onto', 'inside', 'at', 'them'}
SYN = {'white': ['white', 'porcelain'], 'compartment': ['contain'], 'cup': ['mug', 'cup'], 'pan': ['frypan', 'pan'],
       'burner': ['stove', 'cook'], 'shelf': ['rack', 'shelf']}


def run(api):
    return api.original()


def toks(ph):
    return [t for t in (ph or '').lower().split() if t.isalpha() and t not in STOP]


def score(ph, name):
    ws = (name or '').lower().split('_')
    return sum(1 if any(w in SYN.get(t, [t, t[:-1]]) for w in ws) else -.3 for t in toks(ph))


def clauses(text):
    low = text.lower().replace(',', ' ').replace('.', ' ').replace(' then ', ' and  ')
    segs, out = [], []
    for s in low.split(' and '):
        w = s.split()
        if not w: continue
        if segs and w[0] not in VB: segs[-1] += ' and ' + s
        else: segs.append(s)
    for s in segs:
        s = s.strip(); w = s.split(); v = w[0]; rest = s[len(v):].strip()
        if rest.startswith('up '): rest = rest[3:].strip()
        d = {'op': 'place', 'items': [], 'prep': '', 'tgt': '', 'on': 'off' not in w}
        if v in ('turn', 'switch'):
            for k in ('on ', 'off '):
                if rest.startswith(k): rest = rest[len(k):]
            for k in (' on', ' off'):
                if rest.endswith(k): rest = rest[:-len(k)]
            d.update(op='stroke', tgt=rest.strip())
        elif v in ('open', 'close', 'shut'):
            d.update(op='open' if v == 'open' else 'close', tgt=rest)
        else:
            b = ' ' + rest + ' '; hs = sorted((b.find(p), -len(p), p) for p in PREPS if p in b)
            if v in HOLD or not hs: d.update(op='hold', items=[rest])
            else:
                i, _, p = hs[0]
                its = [x.strip() for x in b[:i].replace(' and the ', ' | the ').split(' | ')]
                d.update(prep=p.strip(), tgt=b[i + len(p):].strip(), items=[x[5:] if x.startswith('both ') else x for x in its])
        if out and d['items'] and d['items'][0] in PRON: d['items'] = out[-1]['items']
        if d['tgt'] in PRON:
            a = [e for e in out[::-1] if e['tgt'] and e['tgt'] not in PRON]
            if a: d['ant'] = (a[0]['tgt'], a[0]['op'])
        out.append(d)
    return out


def reread(instruction, step, role):
    role = {'source': 'item', 'destination': 'target'}.get(role, role)
    low, op = instruction.lower().replace(',', ' ').replace('.', ' '), step.get('op')
    cl = [d for d in clauses(instruction) if d['op'] == op]
    if not cl or (role == 'item' and op != 'place'): return ''
    if op == 'place':
        _, d, p = max(((score(p, step.get('item')) + .5 * score(d['tgt'], step.get('target')), d, p)
                       for d in cl for p in d['items']), key=lambda x: x[0])
        a = d.get('ant', ('', ''))
        if role == 'item': q = p
        elif d['tgt'] not in PRON: q = (d['prep'] + ' ' + d['tgt']).strip()
        else: q = '' if 'top' in d['prep'] or a[1] == 'close' else a[0]
    else:
        d = max(cl, key=lambda d: score(d.get('ant', (d['tgt'],))[0], step.get('target')))
        q = d.get('ant', (d['tgt'],))[0] if d['tgt'] in PRON else d['tgt']
    k = low.find(q) if q and q not in PRON else -1
    return instruction[k:k + len(q)] if k >= 0 else ''


def retry(api, feedback):
    st, ev, cl, last = dict(feedback.get('step') or {}), feedback.get('evidence') or {}, clauses(api.instruction), []
    def tphs(d):
        p, pr, a = d['tgt'], d['prep'], d.get('ant', ('', ''))[0]
        if p not in PRON: return [(pr + ' ' + p).strip(), p]
        return [x for x in [(pr + ' ' + p).strip(), (pr + ' ' + a).strip() if a else '', '' if 'top' in pr else a] if x]
    def pick(op, r, phs, hint=''):
        phs = [x for x in phs if x]; ap = api.phrases(op, r) or []; mine = {t for q in phs for t in toks(q)}
        rel = [p for p in ap if p not in phs and (set(toks(p)) & mine or score(p, hint) > 0)]
        if not phs and len(ap) == 1: rel = ap
        opts = set(api.options(op, r) or [])
        for p in phs + rel:
            s = [x for x in (api.suggest(op, r, p) or []) if not opts or x.get('name') in opts]
            if len(s) == 1 and s[0].get('selector'): return s[0]['name'], s[0]['selector']
        return None, None  # ties or no evidence: never default to the first candidate
    def build(d, ip='', keep={}, hint={}):
        s = {'op': d['op'], 'expect': {}}
        for r in (['item', 'target'] if d['op'] == 'place' else ['target']):
            if r in keep: s[r], s['expect'][r] = keep[r]; continue
            n, sel = pick(d['op'], r, [ip] if r == 'item' else tphs(d), hint.get(r) or '')
            if not n and r == 'target' and d['tgt'] in PRON and last and d['op'] + '.target' in (api.supports(last[0]) or []):
                n, sel = last
            if not n: return None
            s[r], s['expect'][r] = n, sel
        if d['op'] == 'stroke':
            s.update(offset=hint.get('offset') or [-.10, 0., .03], delta=hint.get('delta') or [0., .08 if d['on'] else -.08, 0.])
        if d['op'] == 'place': s['grasps'] = hint.get('grasps') or ['standard', 'rim', 'thin_edge']
        return s
    def go(s, d):
        if not s or api.remaining() < 15: return
        ant = d.get('ant', ('', ''))[0]
        if s['op'] == 'place' and ('drawer' in d['tgt'] or ('drawer' in ant and d['prep'] in ('in', 'into', 'inside'))) \
                and 'open.target' in (api.supports(s['target']) or []):
            api.act({'op': 'open', 'target': s['target'], 'expect': {'target': s['expect']['target']}})
        for _ in range(3):
            rc = api.act(s) or {}
            if s['op'] != 'place' or not rc.get('executed') or rc.get('max_lift') is None or rc['max_lift'] > .02 \
                    or api.remaining() < 15: break
            s['grasps'] = s['grasps'][1:] + s['grasps'][:1]
        if rc.get('executed'): last[:] = [s['target'], s['expect']['target']]
    if st.get('op') in ('place', 'open', 'close', 'stroke'):
        keep = {r: ((ev.get(r) or {}).get('resolved') or st[r], st['expect'][r]) for r in ('item', 'target')
                if r in st and r in (st.get('expect') or {}) and (ev.get(r) or {}).get('status') in ('confirmed', 'corrected')}
        cs = [(score(p, st.get('item')) + score(d['tgt'], st.get('target')), -i, d, p)
              for i, d in enumerate(cl) if d['op'] == st['op'] for p in (d['items'] or [''])]
        if cs:
            _, _, d, p = max(cs, key=lambda x: (x[0], x[1]))
            return go(build(d, p, keep, st), d)
    for d in cl:
        for p in (d['items'] if d['op'] == 'place' else [] if d['op'] == 'hold' else ['']):
            go(build(d, p), d)
