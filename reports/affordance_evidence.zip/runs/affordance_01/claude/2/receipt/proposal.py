import numpy as np

def run(api):
    cat, ALL = api.catalog(), {'item', 'fixture', 'region'}
    STOP = {'region', 'table', 'init', 'kitchen', 'living', 'room', 'study', 'floor'}
    SYN = {'white': ['porcelain'], 'compartment': ['contain'], 'pan': ['frypan'], 'skillet': ['frypan'], 'frying': ['frypan'],
           'cup': ['mug'], 'burner': ['stove'], 'cooktop': ['stove'], 'stovetop': ['stove']}
    VERBS = {'put', 'place', 'pick', 'move', 'close', 'open', 'turn', 'push', 'slide', 'set', 'take', 'grab', 'switch', 'press',
             'rotate', 'drop', 'stack', 'shut', 'lift', 'insert', 'bring', 'transfer', 'load', 'store', 'return'}
    PICKV, STROKEV = {'pick', 'take', 'grab', 'lift'}, {'turn', 'switch', 'push', 'slide', 'press', 'rotate'}
    MODS = {'next', 'between', 'near', 'beside', 'from', 'on', 'in', 'at', 'by', 'behind', 'under', 'inside', 'closest', 'nearest'}
    PREPS = {'in', 'into', 'on', 'onto', 'inside', 'to', 'atop'}
    FILL = {'the', 'a', 'an', 'up', 'down', 'please', 'that', 'which', 'is', 'are', 'sitting', 'located'}
    DIRS = {'left': np.array([0, 1., 0]), 'right': np.array([0, -1., 0]), 'front': np.array([-1., 0, 0]), 'back': np.array([1., 0, 0])}
    P = lambda n: np.array(api.pos(n), dtype=float)
    D = lambda n, ref: float(np.linalg.norm(P(n)[:2] - np.asarray(ref, dtype=float)[:2]))
    wset = lambda ws: set(ws) | {w[:-1] for w in ws if w.endswith('s')} | {s for w in ws for s in SYN.get(w, [])}
    act = lambda step: (api.act(step) or {}) if api.remaining() > 10 else {}
    parent = lambda t: cat[t]['parent'] or max([m for m in cat if t.startswith(m + '_')], key=len, default=t)
    kids = lambda t: [n for n in cat if cat[n]['kind'] == 'region' and 'init' not in n and (cat[n]['parent'] == t or n.startswith(t + '_'))]
    opened = set()

    def score(n, W):
        t = [x for x in n.split('_') if x not in STOP and not x.isdigit()]
        m = sum(x in W for x in t)
        return m - 0.3 * (len(t) - m) if m else -9.0

    def cands(ws, kinds, ex=()):
        W = wset(ws)
        c = sorted((score(n, W), n) for n in cat if cat[n]['kind'] in kinds and 'init' not in n and n not in ex)
        return sorted(n for s, n in c if s > c[-1][0] - 0.05) if c and c[-1][0] > 0 else []

    def pick(ties, ws, ref=None):
        if len(ties) > 1:
            for w in ws:
                if w in DIRS: return max(ties, key=lambda n: float(P(n) @ DIRS[w]))
            if ref is not None: return min(ties, key=lambda n: D(n, ref))
        return ties[0] if ties else None

    resolve = lambda ws, kinds, ref=None: pick(cands(ws, kinds), ws, ref)

    def split(ws):
        out, cur = [], []
        for w in ws + ['and']:
            if w != 'and': cur.append(w)
            elif cur: out, cur = out + [cur], []
        return out

    def items_of(src):
        many = 'both' in src or 'all' in src
        src = [w for w in src if w not in ('both', 'all')]
        i = next((i for i, w in enumerate(src) if w in MODS and i > 0), len(src))
        refs = [r for r in (resolve(s, ALL) for s in split([w for w in src[i + 1:] if w != 'to'])) if r]
        ref = np.mean([P(r) for r in refs], axis=0) if refs else None
        gs = [(cands(s, {'item'}), s) for s in split(src[:i])]
        ch = [pick(g, s, ref) for g, s in gs]
        if len(gs) > 1 and None not in ch and len(set(ch)) == len(ch) and min(score(c, wset(s)) for c, (g, s) in zip(ch, gs)) >= 0.65:
            return [(g, ref, s, False) for g, s in gs]
        s = src[:i]; g = cands(s, {'item'})
        if not g: return []
        tk = set(g[0].split('_'))
        pl = many or any(w.endswith('s') and w not in tk and w[:-1] in tk for w in s)
        return [(g, ref, s, pl and len(g) > 1)]

    def choose(g, t=None):
        ties, ref, ws, many = g
        if many or len(ties) < 2: return list(ties if many else ties[:1])
        if ref is not None or not t or any(w in DIRS for w in ws): return [pick(ties, ws, ref)]
        free = [n for n in ties if D(n, P(t)) > 0.07] or ties
        return [min(free, key=lambda n: D(n, P(t)))]

    def target(ws, last, prep, iref, ex):
        top = any(ws[i] == 'top' and ws[i + 1:i + 2] == ['of'] for i in range(len(ws)))
        if top: ws = [w for w in ws if w not in ('top', 'of')]
        if ('it' in ws or not ws) and last:
            t = parent(last) if top and cat[last]['kind'] == 'region' else last
        else: t = pick(cands(ws, {'fixture', 'item'} if top else ALL, ex), ws, iref)
        if t and prep != 'to' and cat[t]['kind'] == 'region' and 'table' in t.split('_'):
            t = pick(cands(ws, {'fixture', 'item'}, ex), ws, P(t)) or t
        if t and cat[t]['kind'] != 'region':
            prefs = ['top_side', 'top'] if top else (['contain'] if prep in ('in', 'into', 'inside') else ['cook', 'top_side', 'contain'])
            ks = kids(t)
            t = next((k for p in [w for w in ws if w in DIRS] + prefs for k in ks if p in k), t)
        return t

    def drawer(t):
        p = t.split('_')
        return cat[t]['kind'] == 'region' and len(p) > 2 and p[-1] == 'region' and p[-2] in ('top', 'middle', 'bottom') and any(k in t for k in ('cabinet', 'drawer', 'dresser'))

    def place(it, t):
        g = ['standard', 'thin_edge', 'rim'] if 'book' in it else ['standard', 'rim', 'thin_edge']
        for _ in range(3):
            r = act({'op': 'place', 'item': it, 'target': t, 'grasps': g})
            if not r.get('executed'): return
            lift, gap = r.get('max_lift'), r.get('xy_gap')
            if lift is not None and lift < 0.01: g = g[1:] + g[:1]; continue
            if gap is None: gap = D(it, P(t))
            if gap < 0.1 or api.remaining() < 60: return

    def stroke(v, ws, lt):
        j = next((i for i, w in enumerate(ws) if w in ('to', 'toward', 'towards')), len(ws))
        if 'it' in ws[:j] and lt: t = parent(lt) if cat[lt]['kind'] == 'region' else lt
        else: t = resolve([w for w in ws[:j] if w not in DIRS and w not in ('on', 'off')], ALL)
        if not t: return None
        rot = v in ('turn', 'switch', 'rotate', 'press')
        kn = [n for n in cat if (cat[n]['parent'] == t or n.startswith(t + '_')) and any(k in n for k in ('knob', 'button', 'switch', 'handle'))]
        tt = kn[0] if rot and kn else t
        e = resolve([w for w in ws[j + 1:] if w not in DIRS], ALL) if j < len(ws) else None
        d = sum([DIRS[w] for w in (ws if e is None else ws[:j]) if w in DIRS], np.zeros(3))
        if d.any(): tries = [d]
        elif e and e != t: tries = [None] * 3
        else:
            b = np.array([0, -1., 0]) if rot else np.array([1., 0, 0])
            b = -b if 'off' in ws else b
            tries = [b, -b, np.array([-b[1], b[0], 0.])]
        for u in tries:
            m = 0.15
            if u is None:
                u = P(e) + 0.12 * sum([DIRS[w] for w in ws[j + 1:] if w in DIRS], np.zeros(3)) - P(tt); u[2] = 0
                g = float(np.linalg.norm(u))
                if g < 0.05: break
                m = min(0.28, g + 0.03)
            u = u / np.linalg.norm(u)
            r = act({'op': 'stroke', 'target': tt, 'offset': [float(x) for x in -u * 0.08 + np.array([0, 0, 0.02])], 'delta': [float(x) for x in u * m]})
            dl = r.get('delta_xyz')
            if not r.get('executed') or (tries[0] is not None and (dl is None or len(tries) == 1 or np.linalg.norm(np.array(dl, dtype=float)) > 0.004)): break
        return t

    words = api.instruction.lower().replace(',', ' ').replace('.', ' ').replace(';', ' then ').split()
    cls, cur = [], []
    for i, w in enumerate(words):
        if w == 'then' or (w == 'and' and words[i + 1:i + 2] and (words[i + 1] in VERBS or words[i + 1] == 'then')):
            if cur: cls.append(cur)
            cur = []; continue
        cur.append(w)
    if cur: cls.append(cur)
    li, lt = [], None
    for c in cls:
        iv = next((i for i, w in enumerate(c) if w in VERBS), -1)
        v = {'shut': 'close'}.get(c[iv], c[iv]) if iv >= 0 else 'put'
        ws = [w for w in c[iv + 1:] if w not in FILL]
        if v in ('open', 'close'):
            t = lt if 'it' in ws and lt else resolve(ws, {'region', 'fixture'})
            if not t: continue
            r = act({'op': v, 'target': t})
            if not r.get('executed') and cat[t]['kind'] != 'region':
                dk = [n for n in kids(t) if n.split('_')[-2:-1] and n.split('_')[-2] in ('top', 'middle', 'bottom')]
                if dk: t = dk[0]; act({'op': v, 'target': t})
            (opened.add(t) if v == 'open' else opened.discard(t)); lt = t
        elif v in STROKEV:
            lt = stroke(v, ws, lt) or lt
        else:
            pv = ('into', 'onto') if v in PICKV else PREPS
            ks = [i for i, w in enumerate(ws) if w in pv and not (w == 'to' and i > 0 and ws[i - 1] in ('next', 'close'))]
            if not ks and v not in PICKV: ks = [i for i, w in enumerate(ws) if w == 'to']
            k = max(ks + [-1])
            src = ws[:k] if k >= 0 else ws
            gs = [(li, None, [], True)] if ('it' in src or 'them' in src) and li else items_of(src)
            its = [n for g in gs for n in choose(g)]
            if k < 0: li = its or li; continue
            t = target(ws[k + 1:], lt, ws[k], P(its[0]) if its else None, its)
            if not t: continue
            its = [n for g in gs for n in choose(g, t) if n != t]
            if not its: continue
            if drawer(t) and t not in opened: act({'op': 'open', 'target': t}); opened.add(t)
            for it in its: place(it, t)
            li, lt = its, t
