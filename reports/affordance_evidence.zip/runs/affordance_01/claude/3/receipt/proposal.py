import numpy as np

def run(api):
    cat = api.catalog()
    P = lambda n: np.array(api.pos(n), dtype=float)
    D = lambda a, b: float(np.linalg.norm(np.asarray(a, dtype=float) - np.asarray(b, dtype=float)))
    GEN = {'region', 'init', 'the', 'a', 'of', 'to'}
    AL = {'porcelain': ['white'], 'contain': ['in', 'into', 'inside', 'compartment'], 'side': ['on', 'onto'],
          'cook': ['on', 'onto'], 'heating': ['in', 'into', 'inside'], 'frypan': ['pan', 'skillet'],
          'chefmate': ['pan', 'frying'], 'top': ['upper'], 'bottom': ['lower'], 'pot': ['moka']}
    PICK = {'pick', 'grab', 'take', 'lift'}
    VERBS = PICK | {'put', 'place', 'close', 'open', 'shut', 'turn', 'switch', 'push', 'slide', 'move', 'stack', 'set', 'drop'}
    SP = {'left': (1, 1.0), 'right': (1, -1.0), 'front': (0, -1.0), 'back': (0, 1.0), 'rear': (0, 1.0)}
    nm = lambda w: w[:-1] if len(w) > 3 and w.endswith('s') and not w.endswith('ss') else w
    toks = lambda n: [nm(t) for t in n.split('_') if t not in GEN and not t.isdigit()]
    drawer = lambda n: (cat[n]['kind'] == 'region' and n.endswith('_region') and ('cabinet' in n or 'drawer' in n)
                        and any(t in n.split('_') for t in ('top', 'middle', 'bottom')))
    aj = lambda n: D(P(n)[:2], P(cat[n]['parent'])[:2]) if drawer(n) and cat[n].get('parent') in cat else 0.0
    def score(n, ws):
        s = sum(1.0 if (t in ws or any(a in ws for a in AL.get(t, []))) else -0.3 for t in toks(n))
        return s + (0.5 if 'drawer' in ws and drawer(n) else 0.0)
    def spatial(ties, ws):
        if len(ties) < 2: return None
        for w, (ax, sg) in SP.items():
            if w in ws:
                nouns = set(t for c in ties for t in toks(c))
                refs = [n for n in cat if 'table' in n.split('_') and w in n.split('_') and nouns & set(toks(n))]
                if refs: return min(ties, key=lambda c: D(P(c)[:2], P(refs[0])[:2]))
                return max(ties, key=lambda c: sg * P(c)[ax])
        return None
    def choose(cands, phrase, tb=None):
        ws = [nm(x) for x in phrase.split()]
        sc = {c: score(c, ws) for c in cands}
        if not sc: return None, -9.0, []
        top = max(sc.values()); ties = sorted(c for c in sc if sc[c] > top - 1e-6)
        ch = spatial(ties, ws)
        if ch is None and tb and len(ties) > 1: ch = min(ties, key=tb)
        return ch or ties[0], top, ties
    items = [n for n in cat if cat[n]['kind'] == 'item']
    tgts = [n for n in cat if not (cat[n]['kind'] == 'region' and ('table' in n.split('_') or 'init' in n.split('_')))]
    def ground(ip, loc):
        it, s, ties = choose(items, ip)
        lw = loc.split()
        if len(ties) < 2 or not lw: return it, s
        oth = [t for t in tgts if t not in ties]
        qs = loc.split(' and ') if 'between' in lw else [loc]
        a = [P(r[0]) for r in (choose(oth, q) for q in qs) if r[0] and r[1] > 0.5]
        if a: m = np.mean(a, axis=0); return min(ties, key=lambda c: D(P(c), m)), s
        if 'center' in lw or 'middle' in lw:
            m = np.mean([P(n) for n in items], axis=0); return min(ties, key=lambda c: D(P(c)[:2], m[:2])), s
        return choose(items, ip + ' ' + ' '.join(w for w in lw if w in SP))[0], s
    ok = lambda: api.remaining() > 15
    def place(it, tg):
        g = ['thin_edge', 'standard', 'rim'] if 'book' in it else ['standard', 'rim', 'thin_edge']
        k, tries = 0, 0
        while k < 3 and tries < 3 and ok():
            r = api.act({'op': 'place', 'item': it, 'target': tg, 'grasps': g[k:] + g[:k]}); tries += 1
            if not isinstance(r, dict) or not r.get('executed'): return
            lift, gap = r.get('max_lift'), r.get('xy_gap')
            if lift is not None and lift <= 0.02: k += 1
            elif gap is None or gap < 0.12: return
    ins = api.instruction.lower().replace(',', ' ').replace('.', ' ')
    cl = []
    for part in ins.split(' and '):
        w = [x for x in part.split() if x != 'then']
        if cl and (not w or w[0] not in VERBS): cl[-1] += ' and ' + ' '.join(w)
        else: cl.append(' '.join(w))
    PREPS = [' into ', ' in ', ' inside ', ' onto ', ' on ', ' to ', ' at ', ' over ', ' under ']
    st = {'np': '', 'items': [], 'dr': None}
    sub = lambda ws: ' '.join(st['np'] if x in ('it', 'them') else x for x in ws)
    opened = set()
    for ci, c in enumerate(cl):
        ws = c.split(); v = ws[0] if ws else ''
        if v in ('open', 'close', 'shut'):
            opn = v == 'open'
            if 'it' in ws and st['dr']: tg, s = st['dr'], 1.0
            else: tg, s, _ = choose([n for n in tgts if cat[n]['kind'] != 'item'], sub(ws), tb=lambda n: aj(n) if opn else -aj(n))
            if tg and s > 0 and ok():
                api.act({'op': 'open' if opn else 'close', 'target': tg})
                if opn: opened.add(tg)
                st['dr'] = tg
            st['np'] = ' '.join(ws[1:])
        elif v in ('turn', 'switch'):
            tg, s, _ = choose([n for n in cat if cat[n]['kind'] == 'fixture'], sub(ws))
            sg = -1.0 if 'off' in ws else 1.0
            if tg and s > 0 and ok():
                api.act({'op': 'stroke', 'target': tg, 'offset': [-0.1, 0.06 * sg, 0.03], 'delta': [0.0, -0.1 * sg, 0.0]})
            st['np'] = ' '.join(x for x in ws[1:] if x not in ('on', 'off'))
        elif v in ('push', 'slide'):
            k = min([c.find(p) for p in (' to ', ' toward') if c.find(p) > 0] or [len(c)])
            it, s, _ = choose(items, sub(c[:k].split()))
            if s <= 0.5 or not ok(): continue
            tg, s2, _ = choose([t for t in tgts if t != it], c[k:]) if k < len(c) else (None, 0.0, [])
            d = np.zeros(3)
            for w, (ax, sg) in SP.items():
                if w in ws: d[ax] += sg
            if 'forward' in ws: d[0] += 1.0
            far = bool(tg and s2 >= 1)
            if far: d = P(tg) - P(it); d[2] = 0.0
            if not d.any(): d[0] = 1.0
            L = min(0.25, D(d, np.zeros(3))) if far else 0.15
            d = d / np.linalg.norm(d)
            api.act({'op': 'stroke', 'target': it, 'offset': [float(x) for x in (-0.08 * d + np.array([0, 0, 0.02]))],
                     'delta': [float(x) for x in L * d]})
            st['np'] = ' '.join(ws[1:])
        else:
            pk = v in PICK and ci < len(cl) - 1
            PR = PREPS + ([' next ', ' between ', ' from ', ' near ', ' beside '] if pk else [])
            hits = [(c.find(p), p) for p in PR if c.find(p) > 0]
            cut = min(hits)[0] if hits else len(c)
            ip = [x for x in c[:cut].split() if x not in VERBS | {'up', 'the', 'both', 'a', 'an'}]
            ips = ' '.join(ip)
            if pk or not hits:
                if ip and 'it' not in ip and 'them' not in ip:
                    if pk: n, s = ground(ips, c[cut:])
                    else: n, s, _ = choose(items, ips)
                    st['items'], st['np'] = ([n] if s > 0.5 else []), ips
                continue
            if not ip or 'it' in ip or 'them' in ip: its = list(st['items'])
            else:
                parts = ips.split(' and ')
                ch = [choose(items, p)[:2] for p in parts]
                if len(parts) > 1 and min(s for _, s in ch) >= 1.5 and len(set(n for n, _ in ch)) == len(ch):
                    its = [n for n, _ in ch]
                else:
                    n, s, _ = choose(items, ips); its = [n] if s > 0.5 else []
            tp = sub(c[cut:].split())
            for it in its:
                tg, s, _ = choose([t for t in tgts if t != it], tp, tb=lambda t: D(P(t)[:2], P(it)[:2]) - 5 * aj(t))
                if not tg or s <= 0.5 or not ok(): continue
                if len(its) == 1 and ip and 'it' not in ip:
                    it = choose(items, ips, tb=lambda q: -D(P(q)[:2], P(tg)[:2]))[0]
                if drawer(tg) and tg not in opened and any(x in tp.split() for x in ('in', 'into', 'inside')):
                    api.act({'op': 'open', 'target': tg}); opened.add(tg)
                place(it, tg)
                if drawer(tg): st['dr'] = tg
            st['items'], st['np'] = its, ' '.join(tp.split()[1:])
