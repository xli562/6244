import numpy as np

VB = {'put', 'place', 'pick', 'close', 'open', 'turn', 'push', 'move', 'slide', 'set', 'take', 'stack', 'drop',
      'grab', 'shut', 'switch', 'insert'}
PR = {'in', 'into', 'on', 'onto', 'inside', 'atop'}
SP = {'left', 'right', 'front', 'back', 'top', 'bottom', 'middle', 'rear', 'center'}
ST = {'the', 'a', 'an', 'of', 'it', 'both', 'up', 'and', 'to', 'its', 'that', 'then', 'them', 'please', 'one', 'is'}
NP = {'open', 'close', 'shut', 'turn', 'switch', 'push', 'slide'}
SY = {'white': ['porcelain'], 'compartment': ['contain'], 'cup': ['mug'], 'mug': ['cup'], 'pan': ['frypan'],
      'skillet': ['frypan'], 'rear': ['back'], 'center': ['middle'], 'stove': ['burner']}


def run(api):
    return api.original()


def _w(s):
    t, out, i = s.lower(), [], 0
    for c in ',.;:!?()':
        t = t.replace(c, ' ')
    for w in t.split(' '):
        if w:
            out.append((w, i, i + len(w)))
        i += len(w) + 1
    return out


def _ph(t, sp):
    return t[sp[0]:sp[1]] if sp else ''


def _pure(t, sp):
    ws = _w(_ph(t, sp))
    return bool(ws) and all(x[0] in ST for x in ws)


def _plan(t):
    ws, cl, out, held, prev = _w(t), [], [], None, None
    sp = lambda s: (s[0][1], s[-1][2]) if s else None
    for k, x in enumerate(ws):
        if not cl or (x[0] in VB and (ws[k - 1][0] in ('and', 'then') or ',' in t[ws[k - 1][2]:x[1]])):
            while cl and cl[-1] and cl[-1][-1][0] in ('and', 'then'):
                cl[-1].pop()
            cl.append([])
        cl[-1].append(x)
    for c in [c for c in cl if c]:
        v, b, part = (c[0][0], c[1:], '') if c[0][0] in VB else ('put', c, '')
        if b and b[0][0] in ('up', 'on', 'off', 'down') and v in ('pick', 'turn', 'switch'):
            part, b = b[0][0], b[1:]
        if v in ('turn', 'switch') and not part:
            part = 'off' if 'off' in [x[0] for x in b] else 'on'
        if v in NP:
            its, tg = [], sp(b)
        else:
            k = next((i for i, x in enumerate(b) if x[0] in PR), None)
            if k is None:
                k = next((i for i, x in enumerate(b) if x[0] == 'to'), len(b))
            both, its, cur = 'both' in [x[0] for x in b[:k]], [], []
            for i, x in enumerate(b[:k]):
                if x[0] == 'and' and (both or (i + 1 < k and b[i + 1][0] in ('the', 'a', 'an'))):
                    its.append(cur)
                    cur = []
                elif x[0] != 'both':
                    cur.append(x)
            its, tg = [sp(s) for s in its + [cur] if s], sp(b[k + 1:])
        its = [held if _pure(t, s) and held else s for s in its]
        ante = prev if tg and set(x[0] for x in _w(_ph(t, tg))) & {'it', 'them'} else None
        out.append((v, part, its, tg, ante))
        if its:
            held = its[0] if (v in ('pick', 'take', 'grab') and not tg) else its[-1]
        if tg and not ante:
            prev = tg
    return out


def reread(instruction, step, role):
    t, op, want = instruction, step.get('op'), role in ('item', 'source')
    nm = lambda k: set(w for w in str(step.get(k) or '').lower().split('_') if w.isalpha())
    ov = lambda sp, n: sum(1 for x in _w(_ph(t, sp)) if x[0] not in ST and n & set([x[0]] + SY.get(x[0], [])))
    best, out = 0, ''
    for v, part, its, tg, ante in _plan(t):
        ts = ante if ante and _pure(t, tg) else (None if ante else tg)
        if op == 'place' and tg and v not in NP:
            for s in its:
                sc, q = ov(s, nm('item')) + ov(ts, nm('target')), (s if want else ts)
                if sc > best and q and not _pure(t, q):
                    best, out = sc, _ph(t, q)
        elif not want and ts and v in {'open': ('open',), 'close': ('close', 'shut'),
                                       'stroke': ('turn', 'switch')}.get(op, ()):
            sc = ov(ts, nm('target'))
            if sc > best:
                best, out = sc, _ph(t, ts)
    return out.strip()


def retry(api, feedback):
    fb, t = feedback or {}, api.instruction
    s0, ev = dict(fb.get('step') or {}), fb.get('evidence') or {}
    P = lambda n: np.array(api.pos(n), dtype=float)
    act = lambda st: api.act(st) if api.remaining() >= 12 else None
    done = lambda i, g: bool(i and g) and float(np.linalg.norm((P(i) - P(g))[:2])) < .05

    def choose(op, role, phs, g=None):
        opts = set(api.options(op, role) or [])
        for ph in [p for p in phs if p and p.strip()]:
            ss = [s for s in (api.suggest(op, role, ph) or []) if (not opts or s['name'] in opts)
                  and not (role == 'item' and done(s['name'], g))]
            if len(set(s['name'] for s in ss)) == 1:      # unique evidence only, never first-of-tie
                return ss[0]['name'], ss[0]['selector']
        return None, None

    def var(sp, ante):
        p, a = _ph(t, sp), _ph(t, ante)
        if not a:
            return [p]
        sub = lambda r: ' '.join(r if w.lower() in ('it', 'them') else w for w in p.split())
        tail = a.split(' of ')[-1]
        return ([a] if _pure(t, sp) else [p]) + [sub(a), sub(tail), tail]

    todo = []
    for v, part, its, tg, ante in _plan(t):
        if tg and v not in ('push', 'slide'):
            op = {'open': 'open', 'close': 'close', 'shut': 'close', 'turn': 'stroke', 'switch': 'stroke'}.get(v, 'place')
            for ip in (its if op == 'place' else [None]):
                todo.append((op, {'item': [_ph(t, ip)] if ip else [], 'target': var(tg, ante)}, part))

    def go(op, ph, part, keep):
        st, ex = {'op': op}, {}
        for role in ('target', 'item') if op == 'place' else ('target',):
            if role in keep:
                st[role], ex[role] = keep[role]
                continue
            ext = list(api.phrases(op, role) or [])
            st[role], ex[role] = choose(op, role, ph[role] + (ext if len(ext) == 1 or not ph[role] else []),
                                        st.get('target'))
            if not st[role]:
                return None
        st['expect'] = ex
        if op == 'stroke':
            g = -1 if part == 'off' else 1
            st.update({'offset': [-.06, .06 * g, .02], 'delta': [0., -.1 * g, 0.]})
        if op == 'place':
            if done(st['item'], st['target']):
                return None
            thin = set(st['item'].lower().split('_')) & {'book', 'plate', 'board'}
            st['grasps'] = ['standard', 'thin_edge', 'rim'] if thin else ['standard', 'rim', 'thin_edge']
            if 'drawer' in ' '.join(ph['target']).lower().split() and st['target'] in (api.options('open', 'target') or []):
                act({'op': 'open', 'target': st['target'], 'expect': {'target': ex['target']}})
        rc = act(st)
        if op == 'place' and rc and rc.get('executed') and rc.get('max_lift') is not None and rc['max_lift'] < .015:
            st['grasps'] = st['grasps'][1:] + st['grasps'][:1]
            rc = act(st)
        return rc

    if fb.get('reason') == 'blocked' and s0.get('op'):
        op, keep = s0['op'], {}
        for r in ('item', 'target'):
            e, x = ev.get(r) or {}, (s0.get('expect') or {}).get(r)
            if r in s0 and x and e.get('status') in ('confirmed', 'corrected'):
                keep[r] = (e.get('resolved') or s0[r], x)       # preserve verified roles
        rr = {r: reread(t, s0, r) for r in ('item', 'target')}
        k = next((i for i, d in enumerate(todo) if d[0] == op and
                  (rr['item'] in d[1]['item'] or rr['target'] in d[1]['target'])), None)
        d = todo[k] if k is not None else (op, {'item': [], 'target': []}, '')
        rc = go(op, {r: [rr[r]] + d[1][r] for r in ('item', 'target')}, d[2], keep)
        if op == 'place' and rc and rc.get('executed') and k is not None:
            for d2 in todo[k + 1:]:
                if d2[0] == 'close':
                    go(d2[0], d2[1], d2[2], {})
        return rc
    rc = None
    for op, ph, part in todo:
        rc = go(op, ph, part, {}) or rc
    return rc
