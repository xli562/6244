import numpy as np

def run(api):
    n_act = [0]
    try: plan(api, n_act)
    except Exception:
        if n_act[0] == 0 and api.remaining() > 0: api.original()

def plan(api, n_act):
    cat = api.catalog()
    GEN = set('region init contain table kitchen living room study the of a an to both all two up box compartment drawer cook it them on off'.split())
    SYN = {'porcelain': 'white', 'akita': 'black', 'frypan': 'pan', 'chefmate': 'pan', 'cup': 'mug', 'skillet': 'pan'}
    VERBS = set('put place pick open close shut turn switch push slide move grab take then stack set lift'.split())
    D = {'left': [0, 1, 0], 'right': [0, -1, 0], 'front': [-1, 0, 0], 'back': [1, 0, 0], 'top': [0, 0, 1], 'bottom': [0, 0, -1]}
    PK = lambda n: cat.get(cat[n]['parent'] or '', {}).get('kind')
    def act(s):
        n_act[0] += 1; r = api.act(s); return r if isinstance(r, dict) else {}
    def P(n):
        try: return np.array(api.pos(n), float)
        except Exception: return np.zeros(3)
    for a, b in (('left', 'right'), ('front', 'back')):          # calibrate directions from paired scene names
        for n in cat:
            m = n.replace(a, b)
            v = P(n) - P(m) if a in n.split('_') and m in cat else np.zeros(3)
            v[2] = 0
            if np.linalg.norm(v) > .02:
                u = v / np.linalg.norm(v); D[a], D[b] = list(u), list(-u); break
    def toks(n): return [t for t in n.split('_') if not t.isdigit() and t not in GEN]
    VOC = set(t for n in cat for t in toks(n))
    def norm(ws): return [w[:-1] if w.endswith('s') and w not in VOC and w[:-1] in VOC else w for w in ws]
    def score(pw, n):
        T = toks(n); m = sum(1 for t in T if t in pw or SYN.get(t) in pw)
        return m - .3 * (len(T) - m) if m else -9
    def res(ph, kinds, ref=None, many=False):
        ph, rel = ' ' + ph + ' ', None
        for r in (' next to ', ' near ', ' beside ', ' behind ', ' under ', ' on ', ' in ', ' at ', ' from '):
            if r in ph and ph.split(r, 1)[0].strip(): ph, rel = ph.split(r, 1); break
        pw = set(w for w in norm(ph.split()) if w not in GEN); pw |= set(SYN[w] for w in pw if w in SYN)
        rw = [w for w in (rel or '').split() if w not in GEN]
        if rw and all(w in D for w in rw): pw |= set(rw); rel = None
        S = {n: score(pw, n) + (.1 if cat[n]['kind'] == 'region' and PK(n) in ('item', 'fixture') else 0)
             for n in cat if 'init' not in n and cat[n]['kind'] in kinds}
        if not S or max(S.values()) <= 0: return [] if many else None
        T = [n for n in S if S[n] > max(S.values()) - .05]
        e = res(rel, ('item', 'fixture', 'region')) if rel else None
        anc, sp = (P(e) if e else ref), [w for w in pw if w in D]
        if sp: T.sort(key=lambda n: -sum(np.dot(P(n), D[w]) for w in sp))
        elif anc is not None: T.sort(key=lambda n: np.linalg.norm(P(n)[:2] - anc[:2]))
        if many: return T
        n = T[0]
        if cat[n]['kind'] == 'region' and PK(n) not in ('item', 'fixture'):   # table region -> object lying there
            O = [m for m in cat if 'init' not in m and cat[m]['kind'] in ('item', 'fixture') and score(pw - set(D), m) > 0]
            if O: n = min(O, key=lambda m: np.linalg.norm(P(m)[:2] - P(n)[:2]))
        return n
    def tgt(tp, top, last):
        n = last if tp.split() in (['it'], ['them'], ['there']) else res(tp + (' top side' if top else ''), ('item', 'fixture', 'region'))
        if n and top:
            b = n if cat[n]['kind'] != 'region' else (cat[n]['parent'] or n)
            k = [m for m in cat if cat[m]['parent'] == b and 'top' in m and 'side' in m]
            if k: n = k[0]
        if n and cat[n]['kind'] != 'region':
            k = [m for m in cat if cat[m]['parent'] == n and cat[m]['kind'] == 'region' and ('contain' in m or 'cook' in m)]
            if len(k) == 1: n = k[0]
        return n
    def place(it, tg):
        g = ['thin_edge', 'standard', 'rim'] if 'book' in it else ['standard', 'rim', 'thin_edge']
        dr = cat[tg]['kind'] == 'region' and 'side' not in tg and PK(tg) == 'fixture' and any(w in tg.split('_') for w in ('top', 'middle', 'bottom'))
        rt = 1
        for k in range(4):
            if api.remaining() <= 0: return
            r = act({'op': 'place', 'item': it, 'target': tg, 'grasps': g})
            if not r.get('executed', True): return
            ml, gap = r.get('max_lift'), r.get('xy_gap')
            if ml is not None and ml < .02: g = g[1:] + g[:1]; continue
            if gap is not None and gap > .08 and dr: act({'op': 'open', 'target': tg}); dr = False; continue
            if gap is not None and gap > .12 and rt: rt = 0; continue
            return
    w = api.instruction.lower().replace('.', ' ').replace(',', ' , ').replace("'s", ' ').split(); cls = [[]]
    for i, x in enumerate(w):
        nx = w[i + 1] if i + 1 < len(w) else ''
        if x == 'then' or (x in ('and', ',') and nx in VERBS): cls.append([])
        elif x not in ('please', 'also', 'finally'): cls[-1].append('and' if x == ',' else x)
    heads = set(toks(n)[-1] for n in cat if cat[n]['kind'] == 'item' and toks(n))
    last, held = None, None
    PREPS = (' on top of ', ' into ', ' inside ', ' onto ', ' in ', ' on ', ' to ', ' at ')
    for c in [c for c in cls if c]:
        if api.remaining() <= 0: break
        v, rest = c[0], ' '.join(x for x in c[1:] if x != 'up')
        if v in ('pick', 'grab', 'take', 'lift'):
            held = res(rest, ('item',)); last = held or last
        elif v in ('put', 'place', 'move', 'stack', 'set'):
            t = ' ' + rest + ' '
            hits = sorted((t.find(p), -len(p), p) for p in PREPS if p in t)
            if not hits: continue
            i0, _, p = hits[0]; ip, tp = t[:i0], t[i0 + len(p):]
            if ip.split() in (['it'], ['them'], []): its = [held or last] if (held or last) else []
            else:
                seg = ip.split(' and '); its = [seg[0]]
                for x in seg[1:]:
                    if its[-1].split() and (its[-1].split()[-1] in heads or x.split()[:1] in (['the'], ['a'], ['an'])): its.append(x)
                    else: its[-1] += ' and ' + x
            tg = tgt(tp, 'top of' in p, last); ref = P(tg) if tg else None; ws = ip.split()
            many = len(its) == 1 and its[0] not in cat and (any(x in ws for x in ('both', 'all', 'two')) or any(x.endswith('s') and x[:-1] in heads for x in ws))
            names = res(its[0], ('item',), ref, True) if many else [it if it in cat else res(it, ('item',), ref) for it in its]
            for n in names:
                if n and tg and n != tg and api.remaining() > 0: place(n, tg); held = n
            last = tg or last
        elif v in ('open', 'close', 'shut'):
            n = last if rest.split() in (['it'], ['them']) else res(rest, ('region', 'fixture'))
            n = n or next((m for m in cat if m.endswith('_top_region')), None)
            if n: act({'op': 'open' if v == 'open' else 'close', 'target': n}); last = n
        elif v in ('turn', 'switch'):
            ph = ' '.join(x for x in c[1:] if x not in ('on', 'off'))
            n = last if ph.split() == ['it'] else (res(ph, ('fixture', 'item')) or res(ph, ('region',)))
            if n:
                sg = -1 if 'off' in c else 1
                act({'op': 'stroke', 'target': n, 'offset': [-.08, 0.0, .03], 'delta': [0.0, .06 * sg, 0.0]}); last = n
        elif v in ('push', 'slide'):
            ph, dst, t = rest, None, ' ' + rest + ' '
            for p in (' toward the ', ' towards the ', ' to the ', ' to ', ' into '):
                if p in t: ph, dst = t.split(p, 1); break
            n = res(ph, ('item', 'fixture'))
            if not n: continue
            dw = [x for x in (dst or '').split() if x in D and x not in ('top', 'bottom')]
            e = res(dst, ('item', 'fixture', 'region')) if dst else None
            d = (P(e) if e else P(n)) + sum(np.array(D[x], float) * (.1 if e else .15) for x in dw) - P(n)
            d[2] = 0; nd = np.linalg.norm(d)
            if nd < 1e-3: continue
            d = d * min(1.0, .25 / nd); u = d / np.linalg.norm(d)
            act({'op': 'stroke', 'target': n, 'offset': [float(x) for x in (-u * .07 + np.array([0, 0, .02]))],
                 'delta': [float(x) for x in (d + u * .04)]}); last = n
