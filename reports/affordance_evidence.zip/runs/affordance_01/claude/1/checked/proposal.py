import numpy as np

VOPS = {'open': 'open', 'close': 'close', 'shut': 'close', 'put': 'place', 'place': 'place', 'move': 'place',
        'pick': 'place', 'set': 'place', 'stack': 'place', 'drop': 'place', 'grab': 'place', 'take': 'place',
        'turn': 'stroke', 'switch': 'stroke', 'push': 'stroke', 'slide': 'stroke', 'press': 'stroke'}
PREPS = [' on top of ', ' into ', ' inside ', ' onto ', ' in ', ' on ', ' at ', ' over ', ' to ']
STOP = {'the', 'a', 'an', 'of', 'both', 'up', 'its', 'that', 'this', 'it', 'them'}
SYN = {'compartment': ['contain'], 'drawer': ['region'], 'cup': ['mug'], 'pan': ['frypan'], 'rear': ['back'],
       'white': ['porcelain'], 'center': ['middle'], 'burner': ['stove'], 'stovetop': ['stove']}
ROLES = {'place': ('item', 'target'), 'open': ('target',), 'close': ('target',), 'stroke': ('target',)}
DIR = {'left': (0, 1, 0), 'right': (0, -1, 0), 'front': (-1, 0, 0), 'back': (1, 0, 0)}


def run(api):
    return api.original()


def clauses(instr):
    w = instr.lower().replace(',', ' ').replace('.', ' ').split()
    cl = [[]]
    for i, x in enumerate(w):
        nx = w[i + 1] if i + 1 < len(w) else ''
        if x in ('and', 'then') and (nx in VOPS or nx == 'then'):
            if cl[-1]: cl.append([])
        else: cl[-1].append(x)
    out, li, lt = [], '', ''
    for c in [c for c in cl if c]:
        v = c[0]; op = VOPS.get(v, out[-1][0] if out else 'place'); r = c[1:] if v in VOPS else c
        while r and r[0] in (('up', 'down', 'on', 'off') if op == 'stroke' else ('up', 'down')): r = r[1:]
        if op == 'stroke' and r[-1:] in (['on'], ['off']): r = r[:-1]
        s = ' ' + ' '.join(r) + ' '
        hits = sorted((s.find(p), -len(p), p) for p in PREPS if s.find(p) >= 0) \
            if op == 'place' or v in ('push', 'slide') else []
        p = hits[0][2] if hits else ''
        if hits: it, tg = s[:hits[0][0]].strip(), s[hits[0][0] + len(p):].strip()
        else: it, tg = (s.strip(), '') if op == 'place' else ('', s.strip())
        if op == 'stroke' and it: it, tg = '', it
        if it.split()[-1:] in (['it'], ['them']): it = li
        if tg.split()[-1:] in (['it'], ['them']): tg = '' if 'top' in p else lt
        out.append((op, it, tg)); li = it or li; lt = tg or lt
    return out


def score(ph, nm):
    return sum((1 if any(a in nm for a in SYN.get(w, []) + [w, w[:-1]]) else -0.3)
               for w in ph.split() if w not in STOP)


def reread(instruction, step, role):
    nm = [x for x in str(step.get(role, '')).lower().split('_') if x.isalpha()]
    ot = [x for x in str(step.get('target' if role == 'item' else 'item', '')).lower().split('_') if x.isalpha()]
    best, bs = '', -1e9
    for op, it, tg in clauses(instruction):
        if op != step.get('op'): continue
        ph, other = (it, tg) if role == 'item' else (tg, it)
        parts = ph.replace('both ', '').split(' and ') if role == 'item' else [ph]
        for part in [x.strip() for x in parts if x.strip()]:
            s = score(part, nm) + 0.5 * score(other, ot)
            if s > bs: best, bs = part, s
    low = instruction.lower().replace(',', ' ').replace('.', ' ')
    i = low.find(best) if best else -1
    return instruction[i:i + len(best)] if i >= 0 else ''


def retry(api, feedback):
    fb = feedback or {}; st = dict(fb.get('step') or {}); ev = fb.get('evidence') or {}
    P = lambda n: np.array(api.pos(n), float)
    done = lambda a, b: float(np.linalg.norm((P(a) - P(b))[:2])) < 0.05
    seq = [c[0] for c in clauses(api.instruction)]

    def cands(op, role, extra):
        opts = list(api.options(op, role) or [])
        def res(phs):
            out = []
            for ph in phs:
                sg = [s for s in (api.suggest(op, role, ph) or []) if not opts or s.get('name') in opts]
                out.append((sg[0]['name'], sg[0]['selector']) if len(set(s['name'] for s in sg)) == 1 else None)
            return out
        own = [p for p in (api.phrases(op, role) or []) if p and p.strip()]
        r = res(own)
        pron = all(p.lower().split()[-1] in ('it', 'them') for p in own)
        return r if any(r) or not pron else res([p for p in extra if p not in own])

    for op in dict.fromkeys([st['op']] if st.get('op') in ROLES else seq):
        if op not in ROLES or api.remaining() < 10: continue
        keep = {}
        if op == st.get('op'):
            for r in ROLES[op]:
                e = ev.get(r) if isinstance(ev.get(r), dict) else {}
                if e.get('status') in ('confirmed', 'corrected') and (st.get('expect') or {}).get(r):
                    keep[r] = (e.get('resolved') or st.get(r), st['expect'][r])
        R = {r: cands(op, r, [p for o in ROLES if o != op and r in ROLES[o] for p in (api.phrases(o, r) or [])])
             for r in ROLES[op]}
        R = {r: ([x or keep.get(r) for x in R[r]] or [keep.get(r)]) for r in R}
        if op == 'place':
            I, T = R['item'], R['target']
            if len(T) == 1: T = T * len(I)
            P2 = [(i, t) for i, t in zip(I, T) if i and t]
            for k, r in enumerate(('item', 'target')):
                if r not in keep: continue
                m = [p for p in P2 if p[k][0] == keep[r][0]]
                if not m and len(set(p[1 - k][0] for p in P2)) == 1: m = P2[:1]
                P2 = [(keep[r], p[1]) if k == 0 else (p[0], keep[r]) for p in m]
            P2 = [(i, t) for i, t in P2 if i[0] != t[0] and not done(i[0], t[0])]
            if not P2: continue
            i, t = P2[0]
            if fb.get('reason') == 'no_proposal' and 'open' not in seq and 'open.target' in (api.supports(t[0]) or []):
                api.act({'op': 'open', 'target': t[0], 'expect': {'target': t[1]}})
            g = ['rim', 'standard', 'thin_edge'] if set(i[0].lower().split('_')) & {'bowl', 'mug', 'cup'} \
                else ['standard', 'rim', 'thin_edge']
            return api.act({'op': 'place', 'item': i[0], 'target': t[0], 'grasps': g,
                            'expect': {'item': i[1], 'target': t[1]}})
        T = [t for t in R['target'] if t]
        if len(set(t[0] for t in T)) != 1: continue
        step = {'op': op, 'target': T[0][0], 'expect': {'target': T[0][1]}}
        if op == 'stroke':
            ws = api.instruction.lower().replace(',', ' ').split()
            d = sum((np.array(DIR[w], float) for w in ws if w in DIR), np.zeros(3))
            if set(ws) & {'push', 'slide'} and d.any():
                u = d / np.linalg.norm(d)
                step.update(offset=[float(x) for x in -0.1 * u], delta=[float(x) for x in 0.15 * u])
            else: step.update(offset=[-0.08, 0.0, 0.0], delta=[0.0, -0.08 if 'off' in ws else 0.08, 0.0])
            if op == st.get('op'): step.update({k: st[k] for k in ('offset', 'delta') if k in st})
        return api.act(step)
    return None
